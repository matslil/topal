"""Repeat failed broad validation using disk-backed, task-owned scratch files.

The three successful native VM/readback results remain original executions.
The failed tmpfs/quota batch is preserved unchanged and is not relabeled pass.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import VALIDATIONS,hashes,watched
matrix=cache/'process-mm-policy-failure-matrix'
raw=(matrix/'run.json').read_bytes();native=json.loads(raw)
assert not native['passed'] and native['exit_code']==101 and not native['source_changes_during_run']
assert native['source_hashes_before']==native['source_hashes_after']
assert len(native['cohorts'])==3 and all(c['exit_code']==c['readback']['exit_code']==0 for c in native['cohorts'])
failure=(matrix/'validation/compiler-units.stdout.log').read_text()
sections=re.findall(r'^---- (.*?) stdout ----\n(.*?)(?=^---- |\nfailures:\n|\Z)',failure,re.M|re.S)
assert len(sections)==89 and all('Disk quota exceeded' in body for _,body in sections)
output=cache/'process-mm-policy-failure-validation-recovery';output.mkdir(exist_ok=False)
scratch=cache/'process-mm-policy-failure-validation-tmp';scratch.mkdir(exist_ok=True)
before=hashes(watched());changed={k for k,v in native['source_hashes_before'].items() if before[k]!=v}
assert changed=={'linux-kernel/tools/process-memory/archive_policy_failure.py'}
report=dict(passed=False,exit_code=None,native_matrix=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),
    source_hashes_before=before,validation={},environment=dict(TMPDIR=str(scratch),RUST_MIN_STACK=os.environ.get('RUST_MIN_STACK')),
    earlier_failure=dict(test_cases=89,reason='All89 failure sections contain explicit Disk quota exceeded errors',
                         source='Preserved original matrix/validation/compiler-units.stdout.log'),
    scope='Fresh seven-command validation; disk-backed task scratch and two Rust test threads. Original3VM/native readers retained, not rerun. Host/cgroup protections and tmpfs quota remain unchanged.')
(output/'driver.py').write_bytes(Path(__file__).read_bytes())
start=time.monotonic();exit_code=0
for name,arguments in VALIDATIONS.items():
    arguments=list(arguments)
    if name=='compiler-units':arguments+=['--','--test-threads=2']
    command=['rtk','proxy']+arguments;began=time.monotonic()
    with (output/(name+'.stdout.log')).open('w') as out,(output/(name+'.stderr.log')).open('w') as err:
        result=subprocess.run(command,cwd=root,env=dict(os.environ,TMPDIR=str(scratch)),stdout=out,stderr=err)
    report['validation'][name]=dict(argv=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-began)
    (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    exit_code=result.returncode
    if exit_code:
        print((output/(name+'.stdout.log')).read_text()[-6000:],flush=True)
        print((output/(name+'.stderr.log')).read_text()[-3000:],flush=True)
        break
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
after=hashes(watched())
report.update(passed=exit_code==0 and before==after and len(report['validation'])==len(VALIDATIONS),exit_code=exit_code,
    source_hashes_after=after,source_changes_during_run=before!=after,elapsed_seconds=time.monotonic()-start,
    group=group,resources=resources)
(output/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['source_hashes_before','source_hashes_after']}),flush=True)
sys.exit(exit_code or int(not report['passed']))
