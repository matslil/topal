//! Linux x86 boot-protocol adapter for the initial systems artifact.

use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};

use object::{
    Architecture, BinaryFormat, Object as _, ObjectSegment as _, ObjectSymbol as _, SymbolKind,
};
use serde::{Deserialize, Serialize};

use crate::artifact::sha256;
use crate::systems_boot_resource::{
    X86_INITIAL_BOOT_RESOURCE_FILE, X86_INITIAL_BOOT_RESOURCE_MEMBER,
    X86_INITIAL_BOOT_RESOURCE_REVISION, X86_STATIC_BOOT_RESOURCE_MEMBER,
    generate_initial_boot_resource,
};
use crate::{
    CompileError, SYSTEMS_INITIAL_USER_IMAGE_FILE, SYSTEMS_KERNEL_FILE,
    SYSTEMS_STATIC_USER_IMAGE_FILE, SystemsArtifactProvenance, X86_SYSTEMS_ARTIFACT_REVISION,
    X86_SYSTEMS_DEADLINE_ENTRY, X86_SYSTEMS_DEBUG_BREAK_ENTRY, X86_SYSTEMS_KERNEL_ENTRY,
    X86_SYSTEMS_LOCAL_NOTIFICATION_ENTRY, X86_SYSTEMS_PROVIDER_REVISION,
    X86_SYSTEMS_USER_COPY_FAULT_SYMBOL,
};

pub const X86_LINUX_BOOT_ADAPTER_REVISION: &str =
    "topal.boot-adapter.linux-x86-protocol-2.15-q35/154";
pub const X86_LINUX_BOOT_PROTOCOL: u16 = 0x020f;
pub const X86_LINUX_SETUP_SECTORS: u8 = 4;
pub const X86_PROTECTED_PAYLOAD_ADDRESS: u64 = 0x0010_0000;
pub const X86_KERNEL_MINIMUM_ADDRESS: u64 = 0x0020_0000;
pub const X86_INITIAL_STACK_TOP: u64 = 0x0018_0000;
pub const X86_INITIAL_IDENTITY_LIMIT: u64 = 0x4000_0000;
pub const X86_BOOT_IMAGE_FILE: &str = "bzImage";
pub const X86_BOOT_PROVENANCE_FILE: &str = "boot-provenance.json";

const SETUP_BYTES: usize = 5 * 512;
const REAL_MODE_ENTRY_OFFSET: usize = 0x26c;
const REAL_MODE_CONTINUATION_SOURCE_OFFSET: usize = 0x300;
const REAL_MODE_CONTINUATION_RELOCATION_OFFSET: u16 = 0x7000;
const BOOT_PARAMS_E820_COUNT_OFFSET: u16 = 0x01e8;
const BOOT_PARAMS_E820_TABLE_OFFSET: u16 = 0x02d0;
const BOOT_PARAMS_E820_ENTRY_BYTES: u16 = 20;
const BOOT_PARAMS_E820_MAX_ENTRIES: u8 = 128;
const PAGE_TABLE_PML4_ADDRESS: u64 = 0x0010_1000;
const PAGE_TABLE_PDPT_ADDRESS: u64 = 0x0010_2000;
const PAGE_TABLE_PD_ADDRESS: u64 = 0x0010_3000;
const GDT_ADDRESS: u64 = 0x0010_4000;
const IDT_ADDRESS: u64 = 0x0010_5000;
const IDT_DESCRIPTOR_ADDRESS: u64 = 0x0010_6000;
const LOCAL_APIC_PD_ADDRESS: u64 = 0x0010_7000;
const TRANSITION_RESERVED_END: u64 = 0x0010_8000;
const HPET_MMIO_LEAF_ADDRESS: u64 = 0xfec0_0000;
const LOCAL_APIC_PAGE_ADDRESS: u64 = 0xfee0_0000;
const LOCAL_NOTIFICATION_VECTOR: usize = 0xf1;
const DEADLINE_VECTOR: usize = 0xf2;
const PAGE_FAULT_VECTOR: usize = 14;
const MAX_PROTECTED_PAYLOAD_BYTES: u64 = 64 * 1024 * 1024;

#[cfg(test)]
#[path = "systems_boot_image_fixture.rs"]
mod fixture;
#[cfg(test)]
pub(crate) use fixture::unpublished_component_fixture;

static NEXT_BOOT_STAGE: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct X86LinuxBootImageProvenance {
    pub schema: String,
    pub protocol: u16,
    pub setup_sectors: u8,
    pub protected_payload_address: u64,
    pub kernel_minimum_address: u64,
    pub initial_stack_top: u64,
    pub identity_map_limit: u64,
    pub local_apic_page_address: u64,
    pub target: String,
    pub board: String,
    pub machine_cpu: String,
    pub provider: String,
    pub linked_kernel_sha256: String,
    pub boot_image_sha256: String,
    pub boot_resource_schema: String,
    pub boot_resource_member: String,
    pub static_boot_resource_member: String,
    pub boot_resource_bytes: u64,
    pub boot_resource_sha256: String,
    pub initial_user_image_bytes: u64,
    pub initial_user_image_sha256: String,
    pub static_user_image_bytes: u64,
    pub static_user_image_sha256: String,
    pub protected_payload_bytes: u64,
    pub kernel_entry: u64,
    pub debug_break_entry: u64,
    pub local_notification_entry: u64,
    pub deadline_entry: u64,
    pub user_copy_fault_entry: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeneratedX86LinuxBootImage {
    pub bytes: Vec<u8>,
    pub boot_resource: Vec<u8>,
    pub provenance: X86LinuxBootImageProvenance,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PublishedX86LinuxBootImage {
    pub directory: PathBuf,
    pub image: PathBuf,
    pub boot_resource: PathBuf,
    pub provenance: PathBuf,
    pub record: X86LinuxBootImageProvenance,
}

struct KernelLoadSegment<'data> {
    address: u64,
    size: u64,
    executable: bool,
    data: &'data [u8],
}

/// Package a validated linked systems ELF as the approved Linux x86 `bzImage`.
///
/// # Errors
///
/// Returns an error when provenance does not match the kernel, ELF placement is
/// outside the approved initial layout, required entries are absent, or an
/// encoded boot-protocol field would overflow.
pub fn generate_x86_64_linux_boot_image(
    kernel: &[u8],
    artifact: &SystemsArtifactProvenance,
    initial_user_image: &[u8],
    static_user_image: &[u8],
) -> Result<GeneratedX86LinuxBootImage, CompileError> {
    validate_artifact_input(kernel, initial_user_image, static_user_image, artifact)?;
    let file = object::File::parse(kernel)
        .map_err(|error| CompileError::Tool(format!("cannot parse linked kernel ELF: {error}")))?;
    if file.format() != BinaryFormat::Elf
        || file.architecture() != Architecture::X86_64
        || !file.is_little_endian()
        || file.kind() != object::ObjectKind::Executable
    {
        return Err(CompileError::Tool(
            "boot adapter requires an executable little-endian ELF64 x86-64 kernel".into(),
        ));
    }
    let segments = collect_load_segments(&file)?;
    let kernel_entry = required_executable_symbol(&file, &segments, X86_SYSTEMS_KERNEL_ENTRY)?;
    if kernel_entry != file.entry() {
        return Err(CompileError::Tool(
            "kernel ELF entry does not select the generated bootstrap symbol".into(),
        ));
    }
    let debug_break_entry =
        required_executable_symbol(&file, &segments, X86_SYSTEMS_DEBUG_BREAK_ENTRY)?;
    let local_notification_entry =
        required_executable_symbol(&file, &segments, X86_SYSTEMS_LOCAL_NOTIFICATION_ENTRY)?;
    let deadline_entry = required_executable_symbol(&file, &segments, X86_SYSTEMS_DEADLINE_ENTRY)?;
    let user_copy_fault_entry =
        required_executable_symbol(&file, &segments, X86_SYSTEMS_USER_COPY_FAULT_SYMBOL)?;
    let mut protected = materialize_protected_payload(&segments)?;
    install_transition_support(
        &mut protected,
        kernel_entry,
        debug_break_entry,
        local_notification_entry,
        deadline_entry,
        user_copy_fault_entry,
    )?;
    pad_to(&mut protected, 16);

    let protected_size = u32::try_from(protected.len()).map_err(|_| {
        CompileError::Tool("protected payload exceeds the Linux boot header limit".into())
    })?;
    let syssize = protected_size.div_ceil(16);
    let setup = build_setup_header(syssize, protected_size)?;
    let mut bytes = Vec::with_capacity(setup.len() + protected.len());
    bytes.extend_from_slice(&setup);
    bytes.extend_from_slice(&protected);
    let linked_kernel_sha256 = sha256(kernel);
    let boot_image_sha256 = sha256(&bytes);
    let boot_resource = generate_initial_boot_resource(initial_user_image, static_user_image)?;
    Ok(GeneratedX86LinuxBootImage {
        bytes,
        boot_resource: boot_resource.clone(),
        provenance: X86LinuxBootImageProvenance {
            schema: X86_LINUX_BOOT_ADAPTER_REVISION.into(),
            protocol: X86_LINUX_BOOT_PROTOCOL,
            setup_sectors: X86_LINUX_SETUP_SECTORS,
            protected_payload_address: X86_PROTECTED_PAYLOAD_ADDRESS,
            kernel_minimum_address: X86_KERNEL_MINIMUM_ADDRESS,
            initial_stack_top: X86_INITIAL_STACK_TOP,
            identity_map_limit: X86_INITIAL_IDENTITY_LIMIT,
            local_apic_page_address: LOCAL_APIC_PAGE_ADDRESS,
            target: artifact.target.clone(),
            board: artifact.board.clone(),
            machine_cpu: artifact.machine_cpu.clone(),
            provider: artifact.provider.clone(),
            linked_kernel_sha256,
            boot_image_sha256,
            boot_resource_schema: X86_INITIAL_BOOT_RESOURCE_REVISION.into(),
            boot_resource_member: X86_INITIAL_BOOT_RESOURCE_MEMBER.into(),
            static_boot_resource_member: X86_STATIC_BOOT_RESOURCE_MEMBER.into(),
            boot_resource_bytes: u64::try_from(boot_resource.len()).map_err(|_| {
                CompileError::Tool("initial boot resource size exceeds provenance limits".into())
            })?,
            boot_resource_sha256: sha256(&boot_resource),
            initial_user_image_bytes: u64::try_from(initial_user_image.len()).map_err(|_| {
                CompileError::Tool("initial user image size exceeds provenance limits".into())
            })?,
            initial_user_image_sha256: sha256(initial_user_image),
            static_user_image_bytes: u64::try_from(static_user_image.len()).map_err(|_| {
                CompileError::Tool("static user image size exceeds provenance limits".into())
            })?,
            static_user_image_sha256: sha256(static_user_image),
            protected_payload_bytes: u64::from(protected_size),
            kernel_entry,
            debug_break_entry,
            local_notification_entry,
            deadline_entry,
            user_copy_fault_entry,
        },
    })
}

/// Atomically publish the generated boot image and its canonical provenance.
///
/// # Errors
///
/// Returns an error without publishing the destination when generation,
/// staging, provenance encoding, or the final directory rename fails.
pub fn publish_x86_64_linux_boot_image(
    kernel: &[u8],
    artifact: &SystemsArtifactProvenance,
    initial_user_image: &[u8],
    static_user_image: &[u8],
    destination: &Path,
) -> Result<PublishedX86LinuxBootImage, CompileError> {
    let generated =
        generate_x86_64_linux_boot_image(kernel, artifact, initial_user_image, static_user_image)?;
    let parent = destination.parent().unwrap_or_else(|| Path::new("."));
    fs::create_dir_all(parent).map_err(io_error("create boot-image parent", parent))?;
    if destination.exists() {
        return Err(CompileError::Io(format!(
            "boot-image destination already exists: {}",
            destination.display()
        )));
    }
    let stage = allocate_stage(parent)?;
    let result = (|| {
        let image = stage.join(X86_BOOT_IMAGE_FILE);
        fs::write(&image, &generated.bytes).map_err(io_error("write staged boot image", &image))?;
        let boot_resource = stage.join(X86_INITIAL_BOOT_RESOURCE_FILE);
        fs::write(&boot_resource, &generated.boot_resource)
            .map_err(io_error("write staged boot resource", &boot_resource))?;
        let mut encoded = serde_json::to_vec_pretty(&generated.provenance).map_err(|error| {
            CompileError::Tool(format!("cannot encode boot-image provenance: {error}"))
        })?;
        encoded.push(b'\n');
        let provenance = stage.join(X86_BOOT_PROVENANCE_FILE);
        fs::write(&provenance, encoded)
            .map_err(io_error("write staged boot provenance", &provenance))?;
        Ok::<(), CompileError>(())
    })();
    if let Err(error) = result {
        let _ = fs::remove_dir_all(&stage);
        return Err(error);
    }
    if let Err(error) = fs::rename(&stage, destination) {
        let _ = fs::remove_dir_all(&stage);
        return Err(CompileError::Io(format!(
            "cannot atomically publish x86 boot image {}: {error}",
            destination.display()
        )));
    }
    Ok(PublishedX86LinuxBootImage {
        directory: destination.to_owned(),
        image: destination.join(X86_BOOT_IMAGE_FILE),
        boot_resource: destination.join(X86_INITIAL_BOOT_RESOURCE_FILE),
        provenance: destination.join(X86_BOOT_PROVENANCE_FILE),
        record: generated.provenance,
    })
}

fn validate_artifact_input(
    kernel: &[u8],
    initial_user_image: &[u8],
    static_user_image: &[u8],
    artifact: &SystemsArtifactProvenance,
) -> Result<(), CompileError> {
    if artifact.schema != X86_SYSTEMS_ARTIFACT_REVISION
        || artifact.target != "x86_64-unknown-none"
        || artifact.board != "topal-qemu-pc-q35-10.2"
        || artifact.machine_cpu != "qemu64-v1"
        || artifact.provider != X86_SYSTEMS_PROVIDER_REVISION
    {
        return Err(CompileError::Tool(
            "boot adapter input provenance is outside the approved x86 QEMU profile".into(),
        ));
    }
    let expected = artifact
        .outputs
        .iter()
        .find(|output| output.identity == SYSTEMS_KERNEL_FILE)
        .ok_or_else(|| {
            CompileError::Tool("artifact provenance omits the linked kernel digest".into())
        })?;
    if expected.sha256 != sha256(kernel) {
        return Err(CompileError::Tool(
            "linked kernel bytes do not match artifact provenance".into(),
        ));
    }
    crate::systems_provider_object::inspect_linked_process_backing(kernel)?;
    if artifact.volatile_files
        != crate::systems_provider_object::volatile_file_profile(
            artifact.ram_page_pool_library.is_some(),
            artifact.inode_mode_library.is_some(),
            artifact
                .dispatch_library
                .as_ref()
                .is_some_and(|library| library.interface == "static-linux-dispatch-v6"),
        )
    {
        return Err(CompileError::Tool(
            "unqualified volatile filesystem ownership/capacity evidence".into(),
        ));
    }
    let expected = artifact
        .outputs
        .iter()
        .find(|output| output.identity == SYSTEMS_INITIAL_USER_IMAGE_FILE)
        .ok_or_else(|| {
            CompileError::Tool("artifact provenance omits the initial user-image digest".into())
        })?;
    if expected.sha256 != sha256(initial_user_image) {
        return Err(CompileError::Tool(
            "initial user-image bytes do not match artifact provenance".into(),
        ));
    }
    let expected = artifact
        .outputs
        .iter()
        .find(|output| output.identity == SYSTEMS_STATIC_USER_IMAGE_FILE)
        .ok_or_else(|| {
            CompileError::Tool("artifact provenance omits the static user-image digest".into())
        })?;
    if expected.sha256 != sha256(static_user_image) {
        return Err(CompileError::Tool(
            "static user-image bytes do not match artifact provenance".into(),
        ));
    }
    let file = object::File::parse(kernel).map_err(|e| CompileError::Tool(e.to_string()))?;
    let slots = [
        (artifact.kernel_library.is_some(), "kernel-library"),
        (artifact.time_library.is_some(), "time-library"),
        (artifact.image_library.is_some(), "image-library"),
        (artifact.dispatch_library.is_some(), "dispatch-library"),
        (
            artifact.process_identity_library.is_some(),
            "process-identity-library",
        ),
    ]
    .into_iter()
    .filter_map(|(present, slot)| present.then_some(slot))
    .collect::<Vec<_>>();
    crate::systems_policy_inputs::validate_slots(kernel, &slots)?;
    let exports = [
        crate::systems_library::EXPORT_SYMBOL,
        "topal_kernel_file_open_policy_v1",
    ];
    let present: Vec<_> = exports
        .into_iter()
        .filter(|name| file.symbol_by_name(name).is_some())
        .collect();
    let expected = artifact
        .kernel_library
        .as_ref()
        .map(|library| library.native_export.as_str());
    if present.as_slice() != expected.as_slice() {
        return Err(CompileError::Tool(
            "source-library code and selected binding disagree".into(),
        ));
    }
    if let Some(library) = &artifact.kernel_library {
        crate::systems_policy_inputs::validate_object_output(
            &artifact.outputs,
            "kernel-library",
            &library.object_sha256,
        )?;
        crate::systems_library::modules::validate_binding(
            &library.modules,
            &library.module_snapshot_sha256,
            &artifact.inputs,
            &artifact.outputs,
            "kernel-source-module:",
            "kernel-library.modules.json",
        )?;
        crate::systems_library::inspect_linked_library(kernel, library)?;
    }
    crate::systems_file_region_boot::validate(kernel, artifact)?;
    crate::systems_ram_page_region_boot::validate(kernel, artifact)?;
    crate::systems_inode_region_boot::validate(kernel, artifact)?;
    crate::systems_namespace_region_boot::validate(kernel, artifact)?;
    if artifact
        .dispatch_library
        .as_ref()
        .is_some_and(|library| library.interface == "static-linux-dispatch-v5")
        && artifact.inode_mode_library.is_none()
    {
        return Err(CompileError::Tool(
            "E-SYSTEMS-INODE-MODE: v5 dispatch requires its actual inode action binding".into(),
        ));
    }
    crate::systems_root_region_boot::validate(kernel, artifact)?;
    if artifact
        .dispatch_library
        .as_ref()
        .is_some_and(|library| library.interface == "static-linux-dispatch-v6")
        && artifact.namespace_runtime.is_none()
    {
        return Err(CompileError::Tool(
            "E-SYSTEMS-NAMESPACE: v6 dispatch requires its actual namespace action binding".into(),
        ));
    }
    crate::systems_region_library::validate_instance_namespaces(
        kernel,
        &[
            artifact.region_library.as_ref(),
            artifact.file_position_library.as_ref(),
            artifact.ram_page_pool_library.as_ref(),
            artifact.inode_mode_library.as_ref(),
            artifact.namespace_library.as_ref(),
        ],
    )?;
    let identity_interface = artifact
        .process_identity_library
        .as_ref()
        .map_or("process-identity-transition-v1", |r| r.interface.as_str());
    let identity_policy = match identity_interface {
        "process-identity-transition-v1" => {
            crate::systems_numeric_library::NumericPolicy::ProcessIdentity
        }
        "retained-process-identity-v1" => {
            crate::systems_numeric_library::NumericPolicy::RetainedIdentity
        }
        "structured-process-identity-v1" => {
            crate::systems_numeric_library::NumericPolicy::StructuredIdentity
        }
        _ => {
            return Err(CompileError::Tool(
                "unqualified process identity interface".into(),
            ));
        }
    };
    let retained_identity =
        identity_policy != crate::systems_numeric_library::NumericPolicy::ProcessIdentity;
    if [
        crate::systems_numeric_library::NumericPolicy::ProcessIdentity,
        crate::systems_numeric_library::NumericPolicy::RetainedIdentity,
        crate::systems_numeric_library::NumericPolicy::StructuredIdentity,
    ]
    .into_iter()
    .any(|policy| {
        policy != identity_policy && file.symbol_by_name(policy.native_export()).is_some()
    }) || file
        .symbol_by_name(crate::systems_numeric_library::STATE_SYMBOL)
        .is_some()
        != retained_identity
    {
        return Err(CompileError::Tool(
            "identity interface/store ownership bindings disagree".into(),
        ));
    }
    let dispatch_interface = artifact
        .dispatch_library
        .as_ref()
        .map_or("static-linux-dispatch-v1", |library| {
            library.interface.as_str()
        });
    let dispatch_policy = match dispatch_interface {
        "static-linux-dispatch-v1" => crate::systems_numeric_library::NumericPolicy::LinuxDispatch,
        "static-linux-dispatch-v2" => {
            crate::systems_numeric_library::NumericPolicy::LinuxDispatchV2
        }
        "static-linux-dispatch-v4" => {
            crate::systems_numeric_library::NumericPolicy::LinuxDispatchV4
        }
        "static-linux-dispatch-v5" => {
            crate::systems_numeric_library::NumericPolicy::LinuxDispatchV5
        }
        "static-linux-dispatch-v6" => {
            crate::systems_numeric_library::NumericPolicy::LinuxDispatchV6
        }
        "static-linux-dispatch-v3" => {
            crate::systems_numeric_library::NumericPolicy::LinuxDispatchV3
        }
        _ => return Err(CompileError::Tool("unqualified dispatch interface".into())),
    };
    if [
        crate::systems_numeric_library::NumericPolicy::LinuxDispatch,
        crate::systems_numeric_library::NumericPolicy::LinuxDispatchV2,
        crate::systems_numeric_library::NumericPolicy::LinuxDispatchV3,
        crate::systems_numeric_library::NumericPolicy::LinuxDispatchV4,
        crate::systems_numeric_library::NumericPolicy::LinuxDispatchV5,
        crate::systems_numeric_library::NumericPolicy::LinuxDispatchV6,
    ]
    .into_iter()
    .any(|policy| {
        policy != dispatch_policy && file.symbol_by_name(policy.native_export()).is_some()
    }) {
        return Err(CompileError::Tool(
            "duplicate or cross-version dispatch code binding".into(),
        ));
    }
    for (library, interface, policy, prefix, stem) in [
        (
            &artifact.time_library,
            "relative-sleep-deadline-v1",
            crate::systems_numeric_library::NumericPolicy::Deadline,
            "kernel-time-source-module:",
            "time-library",
        ),
        (
            &artifact.image_library,
            "static-elf64-header-v1",
            crate::systems_numeric_library::NumericPolicy::Elf64Header,
            "kernel-image-source-module:",
            "image-library",
        ),
        (
            &artifact.dispatch_library,
            dispatch_interface,
            dispatch_policy,
            "kernel-dispatch-source-module:",
            "dispatch-library",
        ),
        (
            &artifact.process_identity_library,
            identity_interface,
            identity_policy,
            "kernel-process-identity-source-module:",
            "process-identity-library",
        ),
    ] {
        let has_numeric = file.symbol_by_name(policy.native_export()).is_some();
        if has_numeric != library.is_some() {
            return Err(CompileError::Tool(
                "numeric code and artifact binding disagree".into(),
            ));
        }
        if let Some(library) = library {
            crate::systems_policy_inputs::validate_object_output(
                &artifact.outputs,
                stem,
                &library.object_sha256,
            )?;
            if library.interface != interface || library.native_export != policy.native_export() {
                return Err(CompileError::Tool(
                    "numeric source binding is in the wrong policy slot".into(),
                ));
            }
            crate::systems_library::modules::validate_binding(
                &library.modules,
                &library.module_snapshot_sha256,
                &artifact.inputs,
                &artifact.outputs,
                prefix,
                &format!("{stem}.modules.json"),
            )?;
            crate::systems_numeric_library::inspect_linked_numeric_library(kernel, library)?;
        }
    }
    if file
        .symbol_by_name("topal_x86_systems_numeric_arena")
        .is_some()
        != (artifact.time_library.is_some()
            || artifact.image_library.is_some()
            || artifact.dispatch_library.is_some()
            || artifact.process_identity_library.is_some())
    {
        return Err(CompileError::Tool(
            "numeric arena and complete policy set disagree".into(),
        ));
    }
    Ok(())
}

fn collect_load_segments<'data>(
    file: &object::File<'data>,
) -> Result<Vec<KernelLoadSegment<'data>>, CompileError> {
    let mut segments = file
        .segments()
        .map(|segment| {
            let data = segment.data().map_err(|error| {
                CompileError::Tool(format!("cannot read linked kernel segment: {error}"))
            })?;
            let (file_offset, _) = segment.file_range();
            let alignment = segment.align().max(1);
            if segment.address() < X86_KERNEL_MINIMUM_ADDRESS
                || alignment < 4096
                || segment.address() % alignment != file_offset % alignment
                || segment.size()
                    < u64::try_from(data.len()).map_err(|_| {
                        CompileError::Tool("kernel segment size does not fit u64".into())
                    })?
            {
                return Err(CompileError::Tool(format!(
                    "linked kernel segment at {:#x} violates the approved load layout",
                    segment.address()
                )));
            }
            let end = segment
                .address()
                .checked_add(segment.size())
                .ok_or_else(|| CompileError::Tool("kernel segment address overflows".into()))?;
            if end > X86_INITIAL_IDENTITY_LIMIT {
                return Err(CompileError::Tool(format!(
                    "linked kernel segment ends beyond the initial identity map: {end:#x}"
                )));
            }
            Ok(KernelLoadSegment {
                address: segment.address(),
                size: segment.size(),
                executable: segment.permissions().executable(),
                data,
            })
        })
        .collect::<Result<Vec<_>, _>>()?;
    if segments.is_empty() {
        return Err(CompileError::Tool(
            "linked kernel ELF contains no loadable segment".into(),
        ));
    }
    segments.sort_by_key(|segment| segment.address);
    for pair in segments.windows(2) {
        let first_end = pair[0].address + pair[0].size;
        if first_end > pair[1].address {
            return Err(CompileError::Tool(
                "linked kernel load segments overlap in physical memory".into(),
            ));
        }
    }
    Ok(segments)
}

fn required_executable_symbol(
    file: &object::File<'_>,
    segments: &[KernelLoadSegment<'_>],
    name: &str,
) -> Result<u64, CompileError> {
    let symbol = file.symbol_by_name(name).ok_or_else(|| {
        CompileError::Tool(format!("linked kernel omits required boot symbol `{name}`"))
    })?;
    let address = symbol.address();
    if symbol.kind() != SymbolKind::Text
        || symbol.size() == 0
        || !segments.iter().any(|segment| {
            segment.executable
                && address >= segment.address
                && address < segment.address + segment.size
        })
    {
        return Err(CompileError::Tool(format!(
            "linked kernel symbol `{name}` is not inside an executable load segment"
        )));
    }
    Ok(address)
}

fn materialize_protected_payload(
    segments: &[KernelLoadSegment<'_>],
) -> Result<Vec<u8>, CompileError> {
    let kernel_end = segments
        .iter()
        .map(|segment| segment.address + segment.size)
        .max()
        .expect("nonempty segments were checked");
    let protected_size = kernel_end - X86_PROTECTED_PAYLOAD_ADDRESS;
    if protected_size > MAX_PROTECTED_PAYLOAD_BYTES {
        return Err(CompileError::Tool(format!(
            "protected payload exceeds the initial {} MiB packaging limit",
            MAX_PROTECTED_PAYLOAD_BYTES / (1024 * 1024)
        )));
    }
    let protected_size = usize::try_from(protected_size)
        .map_err(|_| CompileError::Tool("protected payload does not fit host size".into()))?;
    let mut protected = vec![0; protected_size];
    for segment in segments {
        let offset =
            usize::try_from(segment.address - X86_PROTECTED_PAYLOAD_ADDRESS).map_err(|_| {
                CompileError::Tool("kernel segment offset does not fit host size".into())
            })?;
        let data_end = offset.checked_add(segment.data.len()).ok_or_else(|| {
            CompileError::Tool("kernel segment file extent overflows payload".into())
        })?;
        let memory_end = offset
            .checked_add(usize::try_from(segment.size).map_err(|_| {
                CompileError::Tool("kernel segment memory extent does not fit host size".into())
            })?)
            .ok_or_else(|| CompileError::Tool("kernel segment memory extent overflows".into()))?;
        if data_end > protected.len() || memory_end > protected.len() {
            return Err(CompileError::Tool(
                "kernel segment exceeds protected payload bounds".into(),
            ));
        }
        protected[offset..data_end].copy_from_slice(segment.data);
    }
    Ok(protected)
}

fn install_transition_support(
    protected: &mut [u8],
    kernel_entry: u64,
    debug_break_entry: u64,
    local_notification_entry: u64,
    deadline_entry: u64,
    user_copy_fault_entry: u64,
) -> Result<(), CompileError> {
    if X86_KERNEL_MINIMUM_ADDRESS < TRANSITION_RESERVED_END {
        return Err(CompileError::Tool(
            "approved transition and kernel ranges overlap".into(),
        ));
    }
    let transition = transition_code(kernel_entry)?;
    if transition.len() > 4096 {
        return Err(CompileError::Tool(
            "generated transition code exceeds its reserved page".into(),
        ));
    }
    protected[..transition.len()].copy_from_slice(&transition);
    install_page_tables(protected)?;
    install_gdt(protected)?;
    install_idt(
        protected,
        debug_break_entry,
        local_notification_entry,
        deadline_entry,
        user_copy_fault_entry,
    )?;
    Ok(())
}

fn transition_code(kernel_entry: u64) -> Result<Vec<u8>, CompileError> {
    let mut code = Vec::new();

    // 32-bit protected entry selected by setup_header.code32_start.
    code.extend_from_slice(&[0x66, 0xb8, 0x18, 0x00]);
    code.extend_from_slice(&[0x8e, 0xd8, 0x8e, 0xc0, 0x8e, 0xd0]);
    code.extend_from_slice(&[0xbc]);
    code.extend_from_slice(&narrow_u32(X86_INITIAL_STACK_TOP, "initial stack")?.to_le_bytes());
    code.extend_from_slice(&[0x0f, 0x20, 0xe0, 0x83, 0xc8, 0x20, 0x0f, 0x22, 0xe0]);
    code.push(0xb8);
    code.extend_from_slice(&narrow_u32(PAGE_TABLE_PML4_ADDRESS, "PML4")?.to_le_bytes());
    code.extend_from_slice(&[0x0f, 0x22, 0xd8]);
    code.push(0xb9);
    code.extend_from_slice(&0xc000_0080_u32.to_le_bytes());
    code.extend_from_slice(&[0x0f, 0x32, 0x0d]);
    code.extend_from_slice(&0x100_u32.to_le_bytes());
    code.extend_from_slice(&[0x0f, 0x30, 0x0f, 0x20, 0xc0, 0x0d]);
    code.extend_from_slice(&0x8000_0000_u32.to_le_bytes());
    code.extend_from_slice(&[0x0f, 0x22, 0xc0]);
    let far_jump_offset = code.len() + 1;
    code.extend_from_slice(&[0xea, 0, 0, 0, 0, 0x10, 0x00]);
    pad_to(&mut code, 16);
    let long_entry =
        X86_PROTECTED_PAYLOAD_ADDRESS
            .checked_add(u64::try_from(code.len()).map_err(|_| {
                CompileError::Tool("transition code length does not fit u64".into())
            })?)
            .ok_or_else(|| CompileError::Tool("long-mode entry address overflows".into()))?;
    code[far_jump_offset..far_jump_offset + 4]
        .copy_from_slice(&narrow_u32(long_entry, "long-mode entry")?.to_le_bytes());

    // 64-bit handoff: retain RSI, install the generated IDT, and jump to entry.
    code.extend_from_slice(&[0x66, 0xb8, 0x18, 0x00]);
    code.extend_from_slice(&[
        0x8e, 0xd8, 0x8e, 0xc0, 0x8e, 0xd0, 0x8e, 0xe0, 0x8e, 0xe8, 0xfc,
    ]);
    // SeaBIOS leaves the legacy PIC timer live. Mask both PICs before source
    // later restores IF; admitted interrupts are routed explicitly by APIC.
    code.extend_from_slice(&[0xb0, 0xff, 0xe6, 0x21, 0xe6, 0xa1]);
    code.extend_from_slice(&[0x48, 0xbc]);
    code.extend_from_slice(&X86_INITIAL_STACK_TOP.to_le_bytes());
    code.extend_from_slice(&[0x48, 0xb8]);
    code.extend_from_slice(&IDT_DESCRIPTOR_ADDRESS.to_le_bytes());
    code.extend_from_slice(&[0x0f, 0x01, 0x18, 0x31, 0xed, 0x31, 0xdb, 0x31, 0xff]);
    code.extend_from_slice(&[0x48, 0xb8]);
    code.extend_from_slice(&kernel_entry.to_le_bytes());
    code.extend_from_slice(&[0xff, 0xe0]);
    Ok(code)
}

fn install_page_tables(protected: &mut [u8]) -> Result<(), CompileError> {
    let pml4 = payload_offset(PAGE_TABLE_PML4_ADDRESS, 4096, protected.len())?;
    let pdpt = payload_offset(PAGE_TABLE_PDPT_ADDRESS, 4096, protected.len())?;
    let pd = payload_offset(PAGE_TABLE_PD_ADDRESS, 4096, protected.len())?;
    let apic_pd = payload_offset(LOCAL_APIC_PD_ADDRESS, 4096, protected.len())?;
    write_u64(protected, pml4, PAGE_TABLE_PDPT_ADDRESS | 0x3);
    write_u64(protected, pdpt, PAGE_TABLE_PD_ADDRESS | 0x3);
    write_u64(protected, pdpt + 3 * 8, LOCAL_APIC_PD_ADDRESS | 0x3);
    for index in 0..512_usize {
        let physical = u64::try_from(index)
            .map_err(|_| CompileError::Tool("page-table index does not fit u64".into()))?
            * 0x20_0000;
        write_u64(protected, pd + index * 8, physical | 0x83);
    }
    let apic_index = usize::try_from((LOCAL_APIC_PAGE_ADDRESS >> 21) & 0x1ff)
        .map_err(|_| CompileError::Tool("local-APIC page index does not fit host size".into()))?;
    let hpet_index = usize::try_from((HPET_MMIO_LEAF_ADDRESS >> 21) & 0x1ff)
        .map_err(|_| CompileError::Tool("HPET page index does not fit host size".into()))?;
    write_u64(
        protected,
        apic_pd + hpet_index * 8,
        HPET_MMIO_LEAF_ADDRESS | 0x9b,
    );
    write_u64(
        protected,
        apic_pd + apic_index * 8,
        LOCAL_APIC_PAGE_ADDRESS | 0x9b,
    );
    Ok(())
}

fn install_gdt(protected: &mut [u8]) -> Result<(), CompileError> {
    let gdt = payload_offset(GDT_ADDRESS, 48, protected.len())?;
    let descriptors = [
        0_u64,
        0x00cf_9a00_0000_ffff,
        0x00af_9a00_0000_ffff,
        0x00cf_9200_0000_ffff,
        0x00cf_f200_0000_ffff,
        0x00af_fa00_0000_ffff,
    ];
    for (index, descriptor) in descriptors.into_iter().enumerate() {
        write_u64(protected, gdt + index * 8, descriptor);
    }
    Ok(())
}

fn install_idt(
    protected: &mut [u8],
    debug_break_entry: u64,
    local_notification_entry: u64,
    deadline_entry: u64,
    user_copy_fault_entry: u64,
) -> Result<(), CompileError> {
    let idt = payload_offset(IDT_ADDRESS, 4096, protected.len())?;
    let gate = idt + 3 * 16;
    write_u16(
        protected,
        gate,
        u16::try_from(debug_break_entry & 0xffff)
            .map_err(|_| CompileError::Tool("debug entry low word does not fit u16".into()))?,
    );
    write_u16(protected, gate + 2, 0x10);
    protected[gate + 4] = 0;
    protected[gate + 5] = 0x8f;
    write_u16(
        protected,
        gate + 6,
        u16::try_from((debug_break_entry >> 16) & 0xffff)
            .map_err(|_| CompileError::Tool("debug entry middle word does not fit u16".into()))?,
    );
    write_u32(
        protected,
        gate + 8,
        u32::try_from(debug_break_entry >> 32)
            .map_err(|_| CompileError::Tool("debug entry high word does not fit u32".into()))?,
    );
    write_u32(protected, gate + 12, 0);

    let gate = idt + PAGE_FAULT_VECTOR * 16;
    write_u16(
        protected,
        gate,
        u16::try_from(user_copy_fault_entry & 0xffff).map_err(|_| {
            CompileError::Tool("user-copy fault entry low word does not fit u16".into())
        })?,
    );
    write_u16(protected, gate + 2, 0x10);
    protected[gate + 4] = 0;
    protected[gate + 5] = 0x8e;
    write_u16(
        protected,
        gate + 6,
        u16::try_from((user_copy_fault_entry >> 16) & 0xffff).map_err(|_| {
            CompileError::Tool("user-copy fault entry middle word does not fit u16".into())
        })?,
    );
    write_u32(
        protected,
        gate + 8,
        u32::try_from(user_copy_fault_entry >> 32).map_err(|_| {
            CompileError::Tool("user-copy fault entry high word does not fit u32".into())
        })?,
    );
    write_u32(protected, gate + 12, 0);

    let gate = idt + DEADLINE_VECTOR * 16;
    write_u16(
        protected,
        gate,
        u16::try_from(deadline_entry & 0xffff)
            .map_err(|_| CompileError::Tool("deadline entry low word does not fit u16".into()))?,
    );
    write_u16(protected, gate + 2, 0x10);
    protected[gate + 4] = 0;
    protected[gate + 5] = 0x8e;
    write_u16(
        protected,
        gate + 6,
        u16::try_from((deadline_entry >> 16) & 0xffff).map_err(|_| {
            CompileError::Tool("deadline entry middle word does not fit u16".into())
        })?,
    );
    write_u32(
        protected,
        gate + 8,
        u32::try_from(deadline_entry >> 32)
            .map_err(|_| CompileError::Tool("deadline entry high word does not fit u32".into()))?,
    );
    write_u32(protected, gate + 12, 0);

    let gate = idt + LOCAL_NOTIFICATION_VECTOR * 16;
    write_u16(
        protected,
        gate,
        u16::try_from(local_notification_entry & 0xffff).map_err(|_| {
            CompileError::Tool("local-notification entry low word does not fit u16".into())
        })?,
    );
    write_u16(protected, gate + 2, 0x10);
    protected[gate + 4] = 0;
    protected[gate + 5] = 0x8e;
    write_u16(
        protected,
        gate + 6,
        u16::try_from((local_notification_entry >> 16) & 0xffff).map_err(|_| {
            CompileError::Tool("local-notification entry middle word does not fit u16".into())
        })?,
    );
    write_u32(
        protected,
        gate + 8,
        u32::try_from(local_notification_entry >> 32).map_err(|_| {
            CompileError::Tool("local-notification entry high word does not fit u32".into())
        })?,
    );
    write_u32(protected, gate + 12, 0);

    let descriptor = payload_offset(IDT_DESCRIPTOR_ADDRESS, 10, protected.len())?;
    write_u16(protected, descriptor, 4095);
    write_u64(protected, descriptor + 2, IDT_ADDRESS);
    Ok(())
}

fn build_setup_header(syssize: u32, protected_size: u32) -> Result<Vec<u8>, CompileError> {
    let mut setup = vec![0; SETUP_BYTES];
    setup[0x1f1] = X86_LINUX_SETUP_SECTORS;
    write_u32(&mut setup, 0x1f4, syssize);
    write_u16(&mut setup, 0x1fa, 0xffff);
    write_u16(&mut setup, 0x1fe, 0xaa55);
    setup[0x200] = 0xeb;
    setup[0x201] = u8::try_from(REAL_MODE_ENTRY_OFFSET - 0x202)
        .map_err(|_| CompileError::Tool("real-mode setup entry exceeds short jump".into()))?;
    setup[0x202..0x206].copy_from_slice(b"HdrS");
    write_u16(&mut setup, 0x206, X86_LINUX_BOOT_PROTOCOL);
    setup[0x210] = 0xff;
    setup[0x211] = 0x81;
    write_u32(
        &mut setup,
        0x214,
        narrow_u32(X86_PROTECTED_PAYLOAD_ADDRESS, "protected payload")?,
    );
    write_u16(&mut setup, 0x224, 0xfe00);
    write_u32(&mut setup, 0x22c, 0x37ff_ffff);
    write_u32(&mut setup, 0x230, 4096);
    setup[0x234] = 0;
    setup[0x235] = 12;
    // XLF_KERNEL_64 advertises a separate loader entry at payload + 0x200.
    // This adapter enters long mode through its setup/protected transition;
    // it must not advertise the absent independent 64-bit loader route.
    write_u16(&mut setup, 0x236, 0);
    write_u32(&mut setup, 0x238, 2048);
    write_u64(&mut setup, 0x258, X86_PROTECTED_PAYLOAD_ADDRESS);
    write_u32(&mut setup, 0x260, protected_size);

    let continuation = real_mode_continuation_code()?;
    let code = real_mode_setup_code(continuation.len())?;
    let code_end = REAL_MODE_ENTRY_OFFSET + code.len();
    if code_end > usize::from(BOOT_PARAMS_E820_TABLE_OFFSET) {
        return Err(CompileError::Tool(
            "generated real-mode setup overlaps the E820 table".into(),
        ));
    }
    setup[REAL_MODE_ENTRY_OFFSET..code_end].copy_from_slice(&code);
    let continuation_end = REAL_MODE_CONTINUATION_SOURCE_OFFSET
        .checked_add(continuation.len())
        .ok_or_else(|| CompileError::Tool("real-mode continuation extent overflows".into()))?;
    if continuation_end > setup.len() {
        return Err(CompileError::Tool(
            "generated real-mode continuation exceeds the setup image".into(),
        ));
    }
    setup[REAL_MODE_CONTINUATION_SOURCE_OFFSET..continuation_end].copy_from_slice(&continuation);
    Ok(setup)
}

fn real_mode_setup_code(continuation_bytes: usize) -> Result<Vec<u8>, CompileError> {
    let mut code = vec![
        0xfa, // disable interrupts
        0x0e, 0x58, // derive setup base segment from CS - 0x20
        0x83, 0xe8, 0x20, 0x8e, 0xd8, 0x8e, 0xc0, 0x8e, 0xd0, 0xbc, 0x00, 0x7c, // setup stack
        0xfc, // copy forward
    ];

    // Copy the continuation out of the zeropage range which E820 overwrites.
    code.push(0xbe); // mov si, source
    code.extend_from_slice(
        &u16::try_from(REAL_MODE_CONTINUATION_SOURCE_OFFSET)
            .map_err(|_| CompileError::Tool("continuation source exceeds u16".into()))?
            .to_le_bytes(),
    );
    code.push(0xbf); // mov di, relocation
    code.extend_from_slice(&REAL_MODE_CONTINUATION_RELOCATION_OFFSET.to_le_bytes());
    code.push(0xb9); // mov cx, length
    code.extend_from_slice(
        &u16::try_from(continuation_bytes)
            .map_err(|_| CompileError::Tool("continuation length exceeds u16".into()))?
            .to_le_bytes(),
    );
    code.extend_from_slice(&[0xf3, 0xa4]); // rep movsb

    // Populate the Linux zeropage E820 table before leaving BIOS real mode.
    code.extend_from_slice(&[0x66, 0x31, 0xdb]); // xor ebx, ebx (continuation)
    code.extend_from_slice(&[0x31, 0xed]); // xor bp, bp (entry count)
    code.push(0xbf); // mov di, table offset
    code.extend_from_slice(&BOOT_PARAMS_E820_TABLE_OFFSET.to_le_bytes());
    let e820_loop = code.len();
    code.extend_from_slice(&[0x66, 0xb8, 0x20, 0xe8, 0x00, 0x00]); // eax = E820h
    code.extend_from_slice(&[0x66, 0xba, 0x50, 0x41, 0x4d, 0x53]); // edx = "SMAP"
    code.extend_from_slice(&[0x66, 0x31, 0xc9, 0xb1]); // ecx = entry size
    code.push(
        u8::try_from(BOOT_PARAMS_E820_ENTRY_BYTES)
            .map_err(|_| CompileError::Tool("E820 entry size exceeds imm8".into()))?,
    );
    code.extend_from_slice(&[0xcd, 0x15]);
    let carry_to_failure = short_jump_placeholder(&mut code, 0x72); // jc failure
    code.extend_from_slice(&[0x66, 0x3d, 0x50, 0x41, 0x4d, 0x53]);
    let signature_to_failure = short_jump_placeholder(&mut code, 0x75); // jne failure
    code.extend_from_slice(&[0x66, 0x83, 0xf9]);
    code.push(
        u8::try_from(BOOT_PARAMS_E820_ENTRY_BYTES)
            .map_err(|_| CompileError::Tool("E820 entry size exceeds imm8".into()))?,
    );
    let short_entry_to_failure = short_jump_placeholder(&mut code, 0x72); // jb failure
    code.extend_from_slice(&[0x45]); // inc bp
    code.extend_from_slice(&[0x83, 0xc7]); // add di, entry size
    code.push(
        u8::try_from(BOOT_PARAMS_E820_ENTRY_BYTES)
            .map_err(|_| CompileError::Tool("E820 entry size exceeds imm8".into()))?,
    );
    code.extend_from_slice(&[0x66, 0x85, 0xdb]); // test ebx, ebx
    let complete_to_done = short_jump_placeholder(&mut code, 0x74); // je done
    code.extend_from_slice(&[0x81, 0xfd]); // cmp bp, max
    code.extend_from_slice(&u16::from(BOOT_PARAMS_E820_MAX_ENTRIES).to_le_bytes());
    let continuation_to_loop = short_jump_placeholder(&mut code, 0x75); // jne loop
    let e820_failure = code.len();
    code.extend_from_slice(&[0x31, 0xed]); // any truncated result is unusable
    let e820_done = code.len();
    for jump in [
        carry_to_failure,
        signature_to_failure,
        short_entry_to_failure,
    ] {
        patch_short_jump(&mut code, jump, e820_failure)?;
    }
    patch_short_jump(&mut code, complete_to_done, e820_done)?;
    patch_short_jump(&mut code, continuation_to_loop, e820_loop)?;

    code.extend_from_slice(&[0x89, 0xe8, 0xa2]); // publish the complete entry count
    code.extend_from_slice(&BOOT_PARAMS_E820_COUNT_OFFSET.to_le_bytes());
    code.extend_from_slice(&[0x1e, 0x68]); // transfer to the relocated continuation
    code.extend_from_slice(&REAL_MODE_CONTINUATION_RELOCATION_OFFSET.to_le_bytes());
    code.push(0xcb); // retf with CS = boot-parameter segment
    Ok(code)
}

fn real_mode_continuation_code() -> Result<Vec<u8>, CompileError> {
    let mut code = vec![
        0xfa, 0x0e, 0x58, // derive all data segments from relocated CS
        0x8e, 0xd8, 0x8e, 0xc0, 0x8e, 0xd0, 0x66, 0x0f, 0xb7, 0xf0, 0x66, 0xc1, 0xe6, 0x04, 0xe4,
        0x92, 0x0c, 0x02, 0xe6, 0x92, // enable A20 through port 0x92
        0x2e, 0x0f, 0x01, 0x16,
    ];
    let descriptor_offset = usize::from(REAL_MODE_CONTINUATION_RELOCATION_OFFSET)
        .checked_add(code.len() + 2 + 10 + 8)
        .ok_or_else(|| CompileError::Tool("relocated GDT descriptor offset overflows".into()))?;
    code.extend_from_slice(
        &u16::try_from(descriptor_offset)
            .map_err(|_| CompileError::Tool("relocated GDT descriptor exceeds u16".into()))?
            .to_le_bytes(),
    );
    code.extend_from_slice(&[0x0f, 0x20, 0xc0, 0x66, 0x83, 0xc8, 0x01, 0x0f, 0x22, 0xc0]);
    code.extend_from_slice(&[0x66, 0xea]);
    code.extend_from_slice(
        &narrow_u32(X86_PROTECTED_PAYLOAD_ADDRESS, "protected payload")?.to_le_bytes(),
    );
    code.extend_from_slice(&0x08_u16.to_le_bytes());
    code.extend_from_slice(&47_u16.to_le_bytes());
    code.extend_from_slice(&narrow_u32(GDT_ADDRESS, "GDT")?.to_le_bytes());
    Ok(code)
}

fn short_jump_placeholder(code: &mut Vec<u8>, opcode: u8) -> usize {
    code.push(opcode);
    let displacement = code.len();
    code.push(0);
    displacement
}

fn patch_short_jump(
    code: &mut [u8],
    displacement_offset: usize,
    target: usize,
) -> Result<(), CompileError> {
    let origin = displacement_offset
        .checked_add(1)
        .ok_or_else(|| CompileError::Tool("real-mode jump origin overflows".into()))?;
    let displacement =
        i64::try_from(target).unwrap_or(i64::MAX) - i64::try_from(origin).unwrap_or(i64::MIN);
    code[displacement_offset] = i8::try_from(displacement)
        .map_err(|_| CompileError::Tool("real-mode short jump is out of range".into()))?
        .to_le_bytes()[0];
    Ok(())
}

fn narrow_u32(value: u64, description: &str) -> Result<u32, CompileError> {
    u32::try_from(value)
        .map_err(|_| CompileError::Tool(format!("{description} address does not fit u32")))
}

fn payload_offset(address: u64, size: usize, payload_len: usize) -> Result<usize, CompileError> {
    let offset = usize::try_from(address - X86_PROTECTED_PAYLOAD_ADDRESS)
        .map_err(|_| CompileError::Tool("transition address does not fit host size".into()))?;
    if offset.checked_add(size).is_none_or(|end| end > payload_len) {
        return Err(CompileError::Tool(
            "transition structure exceeds protected payload bounds".into(),
        ));
    }
    Ok(offset)
}

fn pad_to(bytes: &mut Vec<u8>, alignment: usize) {
    let remainder = bytes.len() % alignment;
    if remainder != 0 {
        bytes.resize(bytes.len() + alignment - remainder, 0);
    }
}

fn write_u16(bytes: &mut [u8], offset: usize, value: u16) {
    bytes[offset..offset + 2].copy_from_slice(&value.to_le_bytes());
}

fn write_u32(bytes: &mut [u8], offset: usize, value: u32) {
    bytes[offset..offset + 4].copy_from_slice(&value.to_le_bytes());
}

fn write_u64(bytes: &mut [u8], offset: usize, value: u64) {
    bytes[offset..offset + 8].copy_from_slice(&value.to_le_bytes());
}

fn allocate_stage(parent: &Path) -> Result<PathBuf, CompileError> {
    for _ in 0..100 {
        let sequence = NEXT_BOOT_STAGE.fetch_add(1, Ordering::Relaxed);
        let stage = parent.join(format!(
            ".topal-x86-boot-image-{}-{sequence}",
            std::process::id()
        ));
        match fs::create_dir(&stage) {
            Ok(()) => return Ok(stage),
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {}
            Err(error) => return Err(io_error("create boot-image stage", &stage)(error)),
        }
    }
    Err(CompileError::Io(
        "cannot allocate a unique x86 boot-image stage".into(),
    ))
}

fn io_error<'a>(
    action: &'static str,
    path: &'a Path,
) -> impl FnOnce(std::io::Error) -> CompileError + 'a {
    move |error| CompileError::Io(format!("cannot {action} {}: {error}", path.display()))
}

#[cfg(test)]
mod tests {
    use topal_language::compiler::{CompilerSystemsTargetSelection, analyze_systems_for_compiler};

    use super::*;
    use crate::{LlvmTools, qualified_x86_64_static_user_image_fixture};

    include!("systems_inode_binding_tests.rs");
    include!("systems_namespace_binding_tests.rs");

    const SOURCE: &str =
        include_str!("../../../linux-kernel/labs/qemu/x86_64/pre-frame-kernel-root.t");

    fn linked_kernel(parent: &Path) -> (Vec<u8>, Vec<u8>, Vec<u8>, SystemsArtifactProvenance) {
        linked_kernel_source(parent, SOURCE)
    }
    fn linked_kernel_source(
        parent: &Path,
        source_text: &str,
    ) -> (Vec<u8>, Vec<u8>, Vec<u8>, SystemsArtifactProvenance) {
        linked_kernel_source_with_namespace(parent, source_text, None)
    }
    fn linked_kernel_source_with_namespace(
        parent: &Path,
        source_text: &str,
        namespace_override: Option<&crate::SystemsSourceLibraryInput>,
    ) -> (Vec<u8>, Vec<u8>, Vec<u8>, SystemsArtifactProvenance) {
        let program = analyze_systems_for_compiler(
            source_text,
            &CompilerSystemsTargetSelection::initial_x86_64_qemu(),
        )
        .unwrap();
        let tools = LlvmTools::discover(None).unwrap();
        let source = crate::systems_library::load_source_library(
            program.kernel_library.as_ref().unwrap(),
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
        )
        .unwrap();
        let time = crate::systems_library::load_source_library(
            program.time_library.as_ref().unwrap(),
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
        )
        .unwrap();
        let image = crate::systems_library::load_source_library(
            program.image_library.as_ref().unwrap(),
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
        )
        .unwrap();
        let process_identity = crate::systems_library::load_source_library(
            program.process_identity_library.as_ref().unwrap(),
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
        )
        .unwrap();
        let dispatch = crate::systems_library::load_source_library(
            program.dispatch_library.as_ref().unwrap(),
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
        )
        .unwrap();
        let region = program.region_library.as_ref().map(|requirement| {
            crate::systems_library::load_source_library(
                requirement,
                &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
            )
            .unwrap()
        });
        let page = program.ram_page_pool_library.as_ref().map(|requirement| {
            crate::systems_library::load_source_library(
                requirement,
                &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
            )
            .unwrap()
        });
        let position = program.file_position_library.as_ref().map(|requirement| {
            crate::systems_library::load_source_library(
                requirement,
                &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
            )
            .unwrap()
        });
        let inode = program.inode_mode_library.as_ref().map(|requirement| {
            crate::systems_library::load_source_library(
                requirement,
                &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
            )
            .unwrap()
        });
        let namespace = program.namespace_library.as_ref().map(|requirement| {
            crate::systems_library::load_source_library(
                requirement,
                &Path::new(env!("CARGO_MANIFEST_DIR")).join("../../linux-kernel/kernel"),
            )
            .unwrap()
        });
        let linked = crate::publish_x86_64_systems_artifact_with_kernel_libraries(
            &program,
            &tools,
            None,
            Some(&qualified_x86_64_static_user_image_fixture()),
            crate::SystemsKernelLibraries {
                inode_mode: inode.as_ref(),
                namespace: namespace_override.or(namespace.as_ref()),
                ram_page_pool: page.as_ref(),
                file_position: position.as_ref(),
                region: region.as_ref(),
                policy: Some(&source),
                time: Some(&time),
                image: Some(&image),
                dispatch: Some(&dispatch),
                process_identity: Some(&process_identity),
            },
            &parent.join("linked"),
        )
        .unwrap();
        (
            fs::read(linked.kernel).unwrap(),
            fs::read(linked.initial_user_image).unwrap(),
            fs::read(linked.static_user_image.unwrap()).unwrap(),
            linked.record,
        )
    }

    fn temporary_parent() -> PathBuf {
        let path = std::env::temp_dir().join(format!(
            "topal-x86-boot-image-test-{}-{}",
            std::process::id(),
            NEXT_BOOT_STAGE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&path).unwrap();
        path
    }

    #[test]
    fn file_open_binding_boots_only_with_its_exact_export_and_tag_vocabulary() {
        // TOPAL-SYSTEMS-FILE-OPEN-PLAN-001: admission before boot publication.
        let parent = temporary_parent();
        let selected = SOURCE
            .replace("policy/boot-open-access.t", "policy/file-open-access.t")
            .replace(
                "export is boot-open-decision",
                "export is file-open-decision",
            )
            .replace(
                "interface is boot-open-decision-v1",
                "interface is file-open-decision-v1",
            );
        let (kernel, initial, user, artifact) = linked_kernel_source(&parent, &selected);
        generate_x86_64_linux_boot_image(&kernel, &artifact, &initial, &user).unwrap();
        for case in 0..5 {
            let mut wrong = artifact.clone();
            let binding = wrong.kernel_library.as_mut().unwrap();
            match case {
                0 => binding.interface = "boot-open-decision-v1".into(),
                1 => binding.native_export = crate::systems_library::EXPORT_SYMBOL.into(),
                2 => {
                    binding.source_tags.pop();
                }
                3 => binding.source_tags[7] = binding.source_tags[0],
                _ => wrong.kernel_library = None,
            }
            let output = parent.join(format!("rejected-{case}"));
            assert!(
                publish_x86_64_linux_boot_image(&kernel, &wrong, &initial, &user, &output).is_err()
            );
            assert!(!output.exists());
        }
        std::fs::remove_dir_all(parent).unwrap();
    }
    #[test]
    fn rejects_truncated_or_user_visible_child_backing_before_boot() {
        // TOPAL-SYSTEMS-STATIC-PROCESS-CHILD-001
        use object::{ObjectSection as _, ObjectSymbol as _};
        let parent = temporary_parent();
        let (kernel, initial, static_image, artifact) = linked_kernel(&parent);
        let file = object::File::parse(kernel.as_slice()).unwrap();
        let symbol = file
            .symbol_by_name(
                crate::systems_provider_object::X86_SYSTEMS_STATIC_PROCESS_DESCRIPTOR_TABLE_SYMBOL,
            )
            .unwrap();
        let (start, _) = file
            .section_by_name(".symtab")
            .unwrap()
            .file_range()
            .unwrap();
        let entry = start as usize + symbol.index().0 * 24;
        assert_eq!(symbol.size(), 0x4c000);
        for (field, value) in [
            (16, 8192_u64),
            (16, 0x3e000),
            (16, 0x43000),
            (16, u64::MAX),
            (8, 0x3ff000),
            (8, 0x400000),
            (8, 0x800001),
        ] {
            let mut changed = kernel.clone();
            changed[entry + field..entry + field + 8].copy_from_slice(&value.to_le_bytes());
            assert!(
                crate::systems_provider_object::inspect_linked_process_backing(&changed).is_err()
            );
            let mut provenance = artifact.clone();
            provenance
                .outputs
                .iter_mut()
                .find(|o| o.identity == SYSTEMS_KERNEL_FILE)
                .unwrap()
                .sha256 = sha256(&changed);
            assert!(
                generate_x86_64_linux_boot_image(&changed, &provenance, &initial, &static_image)
                    .is_err()
            );
        }
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn rejects_wrong_sparse_filesystem_capacity_private_layout_and_profile_evidence() {
        // TOPAL-SYSTEMS-VOLATILE-FILE-{OWNERSHIP,PERSONALITY}-001
        let parent = temporary_parent();
        let (kernel, initial, static_image, artifact) = linked_kernel(&parent);
        assert_eq!(artifact.volatile_files.private_umask_offset, 1664);
        assert_eq!(artifact.volatile_files.filesystem_bytes, 0x9000);
        assert_eq!(artifact.volatile_files.process_storage_bytes, 0x4c000);
        let value = serde_json::to_value(&artifact).unwrap();
        let mut missing = value.clone();
        missing.as_object_mut().unwrap().remove("volatile_files");
        assert!(serde_json::from_value::<SystemsArtifactProvenance>(missing).is_err());
        let changes = [
            ("schema", serde_json::json!("topal.volatile-file.x86_64/0")),
            ("process_storage_symbol", serde_json::json!("unowned")),
            ("process_storage_bytes", serde_json::json!(0x43000)),
            ("filesystem_offset", serde_json::json!(0x3e000)),
            ("filesystem_bytes", serde_json::json!(0x8000)),
            ("object_offset", serde_json::json!(0)),
            ("object_count", serde_json::json!(5)),
            ("object_bytes", serde_json::json!(120)),
            ("page_metadata_offset", serde_json::json!(256)),
            ("page_metadata_bytes", serde_json::json!(24)),
            ("resident_pages", serde_json::json!(9)),
            ("page_bytes", serde_json::json!(2048)),
            ("payload_offset", serde_json::json!(2048)),
            ("name_offset", serde_json::json!(1024)),
            ("name_bytes", serde_json::json!(128)),
            ("maximum_name_bytes", serde_json::json!(256)),
            ("directory_staging_offset", serde_json::json!(1536)),
            ("directory_staging_bytes", serde_json::json!(256)),
            ("private_umask_offset", serde_json::json!(32)),
            ("initial_umask", serde_json::json!(0)),
            ("transfer_staging_offset", serde_json::json!(1664)),
            ("transfer_quantum", serde_json::json!(4096)),
            ("maximum_file_offset", serde_json::json!(u64::MAX)),
            ("maximum_native_helper_stack_bytes", serde_json::json!(111)),
            ("timestamp_policy", serde_json::json!("constant")),
        ];
        for (field, changed) in changes {
            let mut altered = value.clone();
            altered["volatile_files"][field] = changed;
            let altered: SystemsArtifactProvenance = serde_json::from_value(altered).unwrap();
            assert!(
                generate_x86_64_linux_boot_image(&kernel, &altered, &initial, &static_image)
                    .is_err(),
                "{field}"
            );
        }
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn rejects_missing_cross_policy_or_incomplete_nominal_dispatch_binding() {
        // TOPAL-SYSTEMS-LINUX-DISPATCH-LIBRARY-001
        let parent = temporary_parent();
        let (kernel, initial, static_image, artifact) = linked_kernel(&parent);
        for mutation in 0..8 {
            let mut changed = artifact.clone();
            match mutation {
                0 => changed.dispatch_library = None,
                1 => std::mem::swap(&mut changed.dispatch_library, &mut changed.time_library),
                2 => {
                    changed.dispatch_library.as_mut().unwrap().source_tags.pop();
                }
                3 => {
                    let tags = &mut changed.dispatch_library.as_mut().unwrap().source_tags;
                    tags[0] = tags[1];
                }
                4 => changed.time_library.as_mut().unwrap().source_tags.push(0),
                5 => changed
                    .inputs
                    .retain(|i| !i.identity.starts_with("kernel-dispatch-source-module:")),
                6 => {
                    changed
                        .dispatch_library
                        .as_mut()
                        .unwrap()
                        .allocation
                        .bridge_bytes = 0
                }
                7 => {
                    changed
                        .dispatch_library
                        .as_mut()
                        .unwrap()
                        .native_invocation_save_bytes = 0
                }
                _ => unreachable!(),
            }
            assert!(
                generate_x86_64_linux_boot_image(&kernel, &changed, &initial, &static_image)
                    .is_err(),
                "mutation={mutation}"
            );
        }
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn rejects_structured_layout_domain_projection_and_transport_evidence_tampering() {
        // TOPAL-SYSTEMS-RETAINED-STRUCTURED-STATE-001; TOPAL-SYSTEMS-STRUCTURED-PROCESS-IDENTITY-001
        let parent = temporary_parent();
        let (kernel, initial, static_image, artifact) = linked_kernel(&parent);
        for mutation in 0..24 {
            let mut changed = artifact.clone();
            let library = changed.process_identity_library.as_mut().unwrap();
            let bound = library.retained_state.as_mut().unwrap();
            macro_rules! layout {
                () => {
                    bound.value_layout.as_mut().unwrap()
                };
            }
            match mutation {
                0 => bound.value_layout = None,
                1 => layout!().schema.push('x'),
                2 => layout!().llvm_type = layout!().llvm_type.replace("i1", "i8"),
                3 => layout!().numbers[0].minimum = 0,
                4 => layout!().numbers[0].maximum = u32::MAX as u64,
                5 => layout!().numbers[0].input_maximum = u64::MAX,
                6 => layout!().numbers[0].node_offset += 8,
                7 => layout!().numbers[1].pointer_offset += 8,
                8 => layout!().booleans[0].offset += 1,
                9 => layout!().booleans[0].indices.reverse(),
                10 => layout!().orders[0].offsets.reverse(),
                11 => layout!().orders[1].fields.reverse(),
                12 => {
                    layout!().zero_masks.pop();
                }
                13 => bound.maximum_prepared_validation_words = 261,
                14 => bound.maximum_projection_words = 11,
                15 => bound.maximum_value_bits = 32,
                16 => bound.maximum_source_numeric_read_operations = 8,
                17 => bound.maximum_source_result_record_words = 3,
                18 => bound.source_result_order_values = 2,
                19 => library.interface = "retained-process-identity-v1".into(),
                20 => layout!().graph_bytes = 40,
                21 => bound.source_result_boolean_values = 0,
                22 => {
                    layout!().numbers.remove(0);
                }
                23 => layout!().numbers[1].node_offset = layout!().numbers[0].node_offset,
                _ => unreachable!(),
            }
            assert!(
                generate_x86_64_linux_boot_image(&kernel, &changed, &initial, &static_image)
                    .is_err(),
                "mutation={mutation}"
            );
        }
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn rejects_incomplete_or_cross_policy_retained_state_certificates() {
        // TOPAL-SYSTEMS-RETAINED-NUMERIC-STATE-001; TOPAL-SYSTEMS-RETAINED-PROCESS-IDENTITY-001
        let parent = temporary_parent();
        let (kernel, initial, static_image, artifact) = linked_kernel(&parent);
        for mutation in 0..12 {
            let mut changed = artifact.clone();
            let identity = changed.process_identity_library.as_mut().unwrap();
            match mutation {
                0 => identity.retained_state = None,
                1 => identity.retained_state.as_mut().unwrap().schema.push('x'),
                2 => identity.retained_state.as_mut().unwrap().limit_bytes = 8192,
                3 => identity.retained_state.as_mut().unwrap().bank_count = 1,
                4 => {
                    identity
                        .retained_state
                        .as_mut()
                        .unwrap()
                        .maximum_retained_graph_bytes = 32
                }
                5 => {
                    identity
                        .retained_state
                        .as_mut()
                        .unwrap()
                        .maximum_prepared_validation_words = 260
                }
                6 => identity
                    .retained_state
                    .as_mut()
                    .unwrap()
                    .store_symbol
                    .push('x'),
                7 => identity.interface = "process-identity-transition-v1".into(),
                8 => identity.native_export = "topal_kernel_process_identity_transition_v1".into(),
                9 => identity
                    .retained_state
                    .as_mut()
                    .unwrap()
                    .publication_protocol
                    .push('x'),
                10 => {
                    changed.time_library.as_mut().unwrap().retained_state =
                        identity.retained_state.clone();
                }
                11 => {
                    identity
                        .retained_state
                        .as_mut()
                        .unwrap()
                        .maximum_retirement_words = 252
                }
                _ => unreachable!(),
            }
            assert!(
                generate_x86_64_linux_boot_image(&kernel, &changed, &initial, &static_image)
                    .is_err(),
                "mutation={mutation}"
            );
        }
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn rejects_missing_cross_policy_or_incomplete_identity_record_binding() {
        // TOPAL-SYSTEMS-NUMERIC-RESULT-RECORD-001; TOPAL-SYSTEMS-PROCESS-IDENTITY-LIBRARY-001
        let parent = temporary_parent();
        let (kernel, initial, static_image, artifact) = linked_kernel(&parent);
        for mutation in 0..10 {
            let mut changed = artifact.clone();
            match mutation {
                0 => changed.process_identity_library = None,
                1 => std::mem::swap(
                    &mut changed.process_identity_library,
                    &mut changed.time_library,
                ),
                2 => {
                    changed
                        .process_identity_library
                        .as_mut()
                        .unwrap()
                        .result_field_order
                        .pop();
                }
                3 => changed
                    .process_identity_library
                    .as_mut()
                    .unwrap()
                    .result_field_order
                    .reverse(),
                4 => {
                    changed
                        .process_identity_library
                        .as_mut()
                        .unwrap()
                        .result_order_suffix = false
                }
                5 => changed.time_library.as_mut().unwrap().result_order_suffix = true,
                6 => changed.inputs.retain(|i| {
                    !i.identity
                        .starts_with("kernel-process-identity-source-module:")
                }),
                7 => {
                    changed
                        .process_identity_library
                        .as_mut()
                        .unwrap()
                        .allocation
                        .bridge_bytes = 0
                }
                8 => {
                    changed
                        .process_identity_library
                        .as_mut()
                        .unwrap()
                        .native_invocation_save_bytes = 0
                }
                9 => changed
                    .process_identity_library
                    .as_mut()
                    .unwrap()
                    .source_tags
                    .push(0),
                _ => unreachable!(),
            }
            assert!(
                generate_x86_64_linux_boot_image(&kernel, &changed, &initial, &static_image)
                    .is_err(),
                "mutation={mutation}"
            );
        }
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn rejects_cross_policy_missing_or_undercharged_header_binding_before_boot() {
        // TOPAL-SYSTEMS-ELF64-HEADER-LIBRARY-001
        let parent = temporary_parent();
        let (kernel, initial, static_image, artifact) = linked_kernel(&parent);
        for mutation in 0..10 {
            let mut changed = artifact.clone();
            match mutation {
                0 => changed.image_library = None,
                1 => std::mem::swap(&mut changed.image_library, &mut changed.time_library),
                2 => {
                    changed
                        .image_library
                        .as_mut()
                        .unwrap()
                        .native_invocation_save_bytes = 0
                }
                3 => changed
                    .image_library
                    .as_mut()
                    .unwrap()
                    .machine_profile
                    .push_str("-unknown"),
                4 => changed
                    .inputs
                    .retain(|i| !i.identity.starts_with("kernel-image-source-module:")),
                5 => {
                    changed
                        .image_library
                        .as_mut()
                        .unwrap()
                        .allocation
                        .maximum_bytes = 65537
                }
                6 => changed.image_library.as_mut().unwrap().maximum_stack_bytes -= 8,
                7 => {
                    changed
                        .image_library
                        .as_mut()
                        .unwrap()
                        .allocation
                        .bridge_bytes -= 8
                }
                8 => {
                    changed
                        .image_library
                        .as_mut()
                        .unwrap()
                        .allocation
                        .maximum_bytes -= 8
                }
                9 => {
                    changed.image_library.as_mut().unwrap().functions[0].maximum_call_path_bytes -=
                        8
                }
                _ => unreachable!(),
            }
            assert!(
                generate_x86_64_linux_boot_image(&kernel, &changed, &initial, &static_image)
                    .is_err(),
                "mutation={mutation}"
            );
        }
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn generates_the_approved_linux_boot_header_and_transition_layout() {
        // TOPAL-COMP-SYSTEMS-ARTIFACT-001, LK-X64-BOOT-001.
        let parent = temporary_parent();
        let (kernel, initial_user_image, static_user_image, artifact) = linked_kernel(&parent);
        let generated = generate_x86_64_linux_boot_image(
            &kernel,
            &artifact,
            &initial_user_image,
            &static_user_image,
        )
        .unwrap();
        assert_eq!(generated.bytes[0x1f1], X86_LINUX_SETUP_SECTORS);
        assert_eq!(&generated.bytes[0x1fe..0x200], &[0x55, 0xaa]);
        assert_eq!(&generated.bytes[0x202..0x206], b"HdrS");
        assert_eq!(
            u16::from_le_bytes(generated.bytes[0x206..0x208].try_into().unwrap()),
            X86_LINUX_BOOT_PROTOCOL
        );
        assert_eq!(generated.bytes[0x211], 0x81);
        let real_mode =
            &generated.bytes[REAL_MODE_ENTRY_OFFSET..usize::from(BOOT_PARAMS_E820_TABLE_OFFSET)];
        assert!(real_mode.windows(2).any(|bytes| bytes == [0xcd, 0x15]));
        assert!(real_mode.windows(5).any(|bytes| {
            bytes
                == [
                    0x89,
                    0xe8,
                    0xa2,
                    BOOT_PARAMS_E820_COUNT_OFFSET.to_le_bytes()[0],
                    BOOT_PARAMS_E820_COUNT_OFFSET.to_le_bytes()[1],
                ]
        }));
        assert_eq!(
            &generated.bytes
                [REAL_MODE_CONTINUATION_SOURCE_OFFSET..REAL_MODE_CONTINUATION_SOURCE_OFFSET + 3],
            &[0xfa, 0x0e, 0x58]
        );
        assert_eq!(
            u32::from_le_bytes(generated.bytes[0x214..0x218].try_into().unwrap()),
            u32::try_from(X86_PROTECTED_PAYLOAD_ADDRESS).unwrap()
        );
        assert_eq!(
            u16::from_le_bytes(generated.bytes[0x236..0x238].try_into().unwrap()),
            0,
            "TOPAL-SYSTEMS-ARTIFACT-001: internal long-mode transition does not advertise an independent 64-bit loader entry"
        );
        let protected = &generated.bytes[SETUP_BYTES..];
        assert!(
            protected[..4096]
                .windows(6)
                .any(|bytes| bytes == [0xb0, 0xff, 0xe6, 0x21, 0xe6, 0xa1]),
            "long-mode handoff must mask both legacy PICs before source restores IF"
        );
        let pml4 =
            usize::try_from(PAGE_TABLE_PML4_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap();
        assert_eq!(
            u64::from_le_bytes(protected[pml4..pml4 + 8].try_into().unwrap()),
            PAGE_TABLE_PDPT_ADDRESS | 3
        );
        let gdt = usize::try_from(GDT_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap();
        assert_eq!(
            u64::from_le_bytes(protected[gdt + 32..gdt + 40].try_into().unwrap()),
            0x00cf_f200_0000_ffff
        );
        assert_eq!(
            u64::from_le_bytes(protected[gdt + 40..gdt + 48].try_into().unwrap()),
            0x00af_fa00_0000_ffff
        );
        let gate = usize::try_from(IDT_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap() + 3 * 16;
        assert_eq!(protected[gate + 5], 0x8f);
        let local_gate = usize::try_from(IDT_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap()
            + LOCAL_NOTIFICATION_VECTOR * 16;
        assert_eq!(protected[local_gate + 5], 0x8e);
        let page_fault_gate = usize::try_from(IDT_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap()
            + PAGE_FAULT_VECTOR * 16;
        assert_eq!(protected[page_fault_gate + 5], 0x8e);
        let deadline_gate = usize::try_from(IDT_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap()
            + DEADLINE_VECTOR * 16;
        assert_eq!(protected[deadline_gate + 5], 0x8e);
        let pdpt =
            usize::try_from(PAGE_TABLE_PDPT_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap();
        assert_eq!(
            u64::from_le_bytes(protected[pdpt + 24..pdpt + 32].try_into().unwrap()),
            LOCAL_APIC_PD_ADDRESS | 3
        );
        let apic_pd =
            usize::try_from(LOCAL_APIC_PD_ADDRESS - X86_PROTECTED_PAYLOAD_ADDRESS).unwrap();
        let hpet_index = usize::try_from((HPET_MMIO_LEAF_ADDRESS >> 21) & 0x1ff).unwrap();
        assert_eq!(
            u64::from_le_bytes(
                protected[apic_pd + hpet_index * 8..apic_pd + hpet_index * 8 + 8]
                    .try_into()
                    .unwrap()
            ),
            HPET_MMIO_LEAF_ADDRESS | 0x9b
        );
        let apic_index = usize::try_from((LOCAL_APIC_PAGE_ADDRESS >> 21) & 0x1ff).unwrap();
        assert_eq!(
            u64::from_le_bytes(
                protected[apic_pd + apic_index * 8..apic_pd + apic_index * 8 + 8]
                    .try_into()
                    .unwrap()
            ),
            LOCAL_APIC_PAGE_ADDRESS | 0x9b
        );
        assert_eq!(
            generated.provenance.local_notification_entry,
            u64::from(u16::from_le_bytes(
                protected[local_gate..local_gate + 2].try_into().unwrap()
            )) | (u64::from(u16::from_le_bytes(
                protected[local_gate + 6..local_gate + 8]
                    .try_into()
                    .unwrap()
            )) << 16)
                | (u64::from(u32::from_le_bytes(
                    protected[local_gate + 8..local_gate + 12]
                        .try_into()
                        .unwrap()
                )) << 32)
        );
        assert_eq!(
            generated.provenance.deadline_entry,
            u64::from(u16::from_le_bytes(
                protected[deadline_gate..deadline_gate + 2]
                    .try_into()
                    .unwrap()
            )) | (u64::from(u16::from_le_bytes(
                protected[deadline_gate + 6..deadline_gate + 8]
                    .try_into()
                    .unwrap()
            )) << 16)
                | (u64::from(u32::from_le_bytes(
                    protected[deadline_gate + 8..deadline_gate + 12]
                        .try_into()
                        .unwrap()
                )) << 32)
        );
        assert_eq!(generated.provenance.linked_kernel_sha256, sha256(&kernel));
        assert_eq!(
            generated.provenance.boot_image_sha256,
            sha256(&generated.bytes)
        );
        assert_eq!(
            generated.provenance.boot_resource_sha256,
            sha256(&generated.boot_resource)
        );
        assert_eq!(
            generated.provenance.boot_resource_schema,
            X86_INITIAL_BOOT_RESOURCE_REVISION
        );
        assert_eq!(
            generated.provenance.boot_resource_member,
            X86_INITIAL_BOOT_RESOURCE_MEMBER
        );
        assert_eq!(
            generated.provenance.static_boot_resource_member,
            X86_STATIC_BOOT_RESOURCE_MEMBER
        );
        assert_eq!(
            generated.provenance.static_user_image_sha256,
            sha256(&static_user_image)
        );
        fs::remove_dir_all(parent).unwrap();
    }

    #[test]
    fn atomically_publishes_a_deterministic_image_resource_and_provenance() {
        // TOPAL-SYSTEMS-ARTIFACT-001, TOPAL-SYSTEMS-QUALIFY-001.
        let parent = temporary_parent();
        let (kernel, initial_user_image, static_user_image, artifact) = linked_kernel(&parent);
        let first = publish_x86_64_linux_boot_image(
            &kernel,
            &artifact,
            &initial_user_image,
            &static_user_image,
            &parent.join("first"),
        )
        .unwrap();
        let second = publish_x86_64_linux_boot_image(
            &kernel,
            &artifact,
            &initial_user_image,
            &static_user_image,
            &parent.join("second"),
        )
        .unwrap();
        assert_eq!(fs::read_dir(&first.directory).unwrap().count(), 3);
        assert_eq!(
            fs::read(&first.image).unwrap(),
            fs::read(&second.image).unwrap()
        );
        assert_eq!(
            fs::read(&first.provenance).unwrap(),
            fs::read(&second.provenance).unwrap()
        );
        assert_eq!(
            fs::read(&first.boot_resource).unwrap(),
            fs::read(&second.boot_resource).unwrap()
        );
        let decoded: X86LinuxBootImageProvenance =
            serde_json::from_slice(&fs::read(&first.provenance).unwrap()).unwrap();
        assert_eq!(decoded, first.record);
        let expected_entry = artifact
            .placements
            .iter()
            .find(|placement| placement.symbol == X86_SYSTEMS_KERNEL_ENTRY)
            .unwrap()
            .address;
        assert_eq!(decoded.kernel_entry, expected_entry);
        fs::remove_dir_all(parent).unwrap();
    }
}
