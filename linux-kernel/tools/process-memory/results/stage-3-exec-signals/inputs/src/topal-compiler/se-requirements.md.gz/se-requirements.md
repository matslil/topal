# Native compiler requirements

These requirements refine `TOPAL-REQ-COMPILER-001`,
`TOPAL-REQ-NATIVE-PLATFORM-001`, `TOPAL-REQ-NATIVE-ABI-001`,
`TOPAL-REQ-NATIVE-ARTIFACT-001`, `TOPAL-REQ-NATIVE-DEBUG-001`, and
`TOPAL-REQ-LLVM-001`, `TOPAL-REQ-ARCH-TARGET-001`,
`TOPAL-REQ-ARCH-PROVENANCE-001`, `TOPAL-REQ-OPT-PROFILE-001`, and
`TOPAL-REQ-OPT-CONTROL-001`, plus `TOPAL-REQ-C-ABI-001`, for the admitted
`topalc` increments.

## TOPAL-COMP-ARCH-001 — Ordered typed compilation stages

The compiler shall coordinate source-module selection, shared frontend
analysis, target-specific LLVM lowering, LLVM verification, and atomic artifact
publication through distinct implementation stages. Only a checked frontend
program may enter a backend, and only the qualified LLVM backend may construct
the typed LLVM-module value accepted by the toolchain publisher. Source-module
filesystem policy shall use the shared module adapter. The backend shall not
invoke external tools or publish files, and the checked semantic model shall
not depend on LLVM spelling, target layout, or artifact paths.

## TOPAL-COMP-TARGET-001 — Linux x86-64 qualification

The hosted compiler shall accept `x86_64-unknown-linux-gnu`; the separately
qualified systems pipeline shall accept `x86_64-unknown-none` only with board
`topal-qemu-pc-q35-10.2`. Each shall emit its exact qualified data layout and
x86-64 CPU baseline, and every other target/profile combination shall be
rejected before creating output.

## TOPAL-COMP-TARGET-REGISTRY-001 — Qualified and model-only discovery

The compiler shall expose a deterministic source-free target listing under
registry `topal.target-qualification/1`. It shall report the executable
generic Linux x86-64 profile; the executable-qualified Topal x86-64 QEMU
systems profile; and the model-only x86-64 AVX2 and RISC-V/DSP examples with
target assignment, CPU/features, board, model source, status, and missing
qualification scopes. A selected model-only target, CPU, board, or model shall
fail before lowering with those details. Adding an entry shall not make it
executable-qualified or change the admitted code-generation targets without
separate qualification.

## TOPAL-COMP-SYSTEMS-CONTEXT-001 — Systems feature and target isolation

The compiler shall admit `systems` only for an explicitly selected qualified
freestanding systems target. It shall expose the sealed `lang systems`
vocabulary without adding grammar, retain the exact feature and authority
profile in the checked program, and reject a systems source paired with the
hosted Linux-process target or an ordinary source attempting to use systems
vocabulary. Until a systems target is executable-qualified, it shall reject
before lowering or output rather than approximate with host mechanisms.

The first semantic increment shall recognize only target
`x86_64-unknown-none`, board `topal-qemu-pc-q35-10.2`, and profile
`topal.systems.x86_64-qemu-pc-q35-10.2/1`. Its checked source model shall admit
the exact `TOPAL-SYSTEMS-VOCABULARY-001` artifact, entry, context, console,
debug-break, resume, and fatal forms. This semantic qualification shall expose
an abstract transition trace but shall not make the target available to object
or executable emission. The existing Linux-process compiler path shall
continue to reject `systems` source before lowering and publication.

The next checked-source increment shall require exactly one
`bounded-bootstrap-storage` artifact member with positive literal byte capacity
and power-of-two alignment no greater than capacity. It shall retain the
descriptor in the checked program, model its provision before bootstrap entry,
and reject missing, duplicate, malformed, or open storage declarations before
lowering. This source acceptance shall not assign a physical address, object
section, or executable qualification.

The boot-memory increment shall require the bootstrap handler to begin with an
exhaustive `context boot describe memory` decision. The success action shall
use only its memory-described context and the error action only its fatal-
capable failure context. The checked model shall retain conservative normalized
range semantics without exposing provider-native records or address authority.

The frame-allocation increment shall require the memory-described success path
to consume its context through an exhaustive `memory create frame allocator`
decision. The allocator success path shall accept only checked nonzero frame
counts and power-of-two frame alignments, track every returned extent affinely,
require same-allocator consuming release before any disposition, and reject
context reuse, extent escape, cross-allocator release, double release, and
unsupported dynamic or multi-extent forms before lowering.

The exact static-ELF frame-extent increment shall additionally admit only the
literal 503-frame, unit-aligned shape after the earlier three-frame extent is
returned. The checked root and x86-64 provider shall preserve one indivisible
owner, use checked frame-to-byte arithmetic, select the whole interval inside
one normalized E820 RAM run below 1 GiB, exclude the boot resource and retained
reservations, emit the exact ordered witness while ownership is live, and
consume whole release before continuing. Structural and negative tests shall
reject intermediate or larger counts, non-unit alignment, partial selection,
overlap, duplicate witness, and continuation with live ownership. No mapping
or byte-access authority shall be introduced.

The static-ELF mapping-resource increment shall admit only a nested literal
one-frame, unit-aligned metadata request while the exact 503-frame payload
extent remains live. The checker shall require the payload witness first, one
pair witness while both owners are live, metadata release before payload
release, fatal-only failures, and no later transition with either owner. The
x86-64 root shall pass the complete retained payload interval as opaque
provider exclusion evidence; provider lowering shall validate the exclusion,
select a complete disjoint E820 interval below 1 GiB, and publish no partial
ownership. Structural and negative tests shall reject overlap, unsupported
nesting, wrong order, hidden allocation, and incomplete unwind. Neither owner
shall acquire byte-access or leaf-publication authority in this increment.

The static-ELF initial-leaf increment shall check one consuming preparation of
the exact live payload and metadata identities into an opaque construction,
the exact ordered witness, consuming complete revocation, metadata release,
payload reclaim, and payload release before continuation. The semantic trace
shall retain distinct prepare, revoke, and reclaim operations. X86-64 lowering
shall revalidate both intervals, zero one 512-entry metadata page, write and
verify exactly 503 ordinal-matched present/user/writable/NX leaves with nine
absent entries, order inactive publication, clear and verify all entries on
revoke, and return the original extents in the checked order. Structural and
negative tests shall reject partial or wrong-role entries, active attachment,
wrong identity/order, duplicate transitions, and incomplete teardown.

The kernel-mapping increment shall accept only the approved static
read-write, non-executable normal-memory request. It shall consume the one live
frame extent into an affine mapping, admit statically bounded plain byte
store/load only through that mapping, require consuming unmap to return the
same extent before release, and reject wrong context, unsupported policy,
frame release while mapped, mapping escape, use after unmap, or disposition
with a live mapping before lowering.

The translation-space increment shall check the exact
`bootstrap-equivalent`/`provider-selected` request, exhaustive begin, commit,
and activation results, affine update and inactive-space identities, fatal-only
failures, and exclusive continuation through the refined success context. The
x86-64 lowering shall privately reserve complete E820 backing frames below the
qualified identity-map limit, construct and validate a replacement root,
activate it through a typed provider operation, structurally retain the table
construction and activation instruction, and reject incomplete lifecycle or
unsupported source before publication.

The active-translation-edit increment shall check exclusive begin/map/commit
and begin/unmap/commit lifecycles, the sealed provider-selected mapping policy,
provisional mapping and returned-frame states, refined-context continuation,
and fatal-only failures. The x86-64 lowering shall reserve non-overlapping E820
backing, construct a private 4 KiB mapping hierarchy, publish only at commit,
remove the mapping and retain the exact local invalidation instruction before
frame reuse, and structurally reject incomplete lifecycle or missing
publication/invalidation evidence.

The first critical-scope increment shall check exhaustive
`local-maskable-interrupts` entry, one affine refined context, fatal-only entry
failure, and consuming restoration before the continuation resumes. It shall
reject escape, use of the prior context, duplicate or out-of-order restore,
blocking, suspension, processor transfer, disposition, and completion while
the scope is live. The x86-64 provider shall privately capture the prior
maskable-interrupt state, disable local maskable interrupts, and restore that
exact state without exposing flags, registers, masks, or instructions to
source. Structural and pinned-QEMU evidence shall retain both provider paths
and ordered execution through the masked scope.

The first atomic-location increment shall check one aligned machine word in a
consumed bootstrap region, the sealed `cpu-shared` domain, explicit
`acquire-release` success and `acquire` failure compare/exchange orders, an
`acquire` load, exhaustive result branches, and consuming `atomic end` before
region release. It shall reject aliases, unsupported orders or domains,
out-of-bounds or misaligned words, duplicate end, and completion while the
location is live. The x86-64 provider shall privately initialize the selected
word, execute a locked compare/exchange, and perform the qualified acquire load
without exposing addresses, registers, encodings, or order implementation to
source. Structural and pinned-QEMU evidence shall retain the locked operation,
success/failure control flow, load, and ownership return.

The first external-interrupt increment shall check exactly one local-
notification handler, one affine send/wait lifecycle, one matching monotonic
observation, consuming completion, external-interrupt resume, and restoration
of the prior local mask state before bootstrap continuation. It shall reject
missing or duplicate entries, wait without send, context use while pending,
completion outside the handler, resume before completion, duplicate completion,
and live notification authority at ordinary completion. The x86-64 provider
shall privately install one interrupt gate, send one local-APIC self-
notification, execute an interrupt-safe wait, complete the controller event,
restore the interrupted register state, and return through the target interrupt
mechanism. Structural and pinned-QEMU evidence shall retain every transition
without exposing vectors, controller registers, frames, instructions, or mask
bits to source.

The first systems time increment shall check exactly two context-borrowing
`now` observations returning `Instant InitialMonotonicClock` after the local-
notification wait and before the time-success marker. It shall reject an
unknown clock, wrong context or classifier, missing or extra observation, and
misordered success. The x86-64 provider shall privately select and validate the
pinned Q35 HPET, map its device page in initial and replacement translations,
enable and read its 64-bit main counter, preserve monotonic wrap state, and
fail closed on regression. Structural and pinned-QEMU evidence shall retain
both reads, capability/period checks, state, and failure branches without
exposing target representation to source.

The first deadline-event increment shall check exactly one deadline formed
from the second qualified clock observation and `1[ms]`, one affine arm/wait
lifecycle, one matching typed handler, consuming completion, and resumption
before the deadline-success marker. It shall reject wrong-clock values, early
delivery, missing or duplicate operations, resume before completion, context
use while waiting, and live deadline authority at ordinary completion. The
x86-64 provider shall privately program one Q35 HPET comparator in one-shot
mode, route its event through the I/O APIC, enter a generated interrupt gate,
observe the same HPET clock no earlier than the scheduled instant, acknowledge
the event, and return through the target interrupt mechanism. Structural and
pinned-QEMU evidence shall retain each transition without exposing comparator,
route, vector, controller, frame, instruction, or acknowledgement details to
source.

The first context-transfer increment shall check exactly one 16 KiB,
16-byte-aligned bootstrap-reclaimable stack region, one static resumed-thread
entry, one affine suspended worker, one caller-to-worker transfer, terminal
retirement with no live worker obligations, exact caller resumption, and one
consuming stack reclamation before fatal disposition. It shall reject wrong
processor or entry, unsupported stack policy, duplicate or missing transition,
ordinary worker return, live obligations at retirement, and disposition with a
live suspended or completed context. The x86-64 provider shall privately build
an initial stack frame, save and restore the qualified callee-saved state and
stack position with local interrupts disabled, retain the active address space,
and resume the generated typed continuation. Structural and pinned-QEMU
evidence shall retain entry on the distinct stack and caller resumption without
exposing registers, stack pointers, frame layouts, continuation addresses, or
instructions to source.

The cooperative context increment shall check two disjoint 16 KiB stacks, one
handoff-once entry, one terminal entry, statically refined suspended and
retired results, source-selected cooperative/terminal/cooperative FIFO order,
and consuming reclamation of both stacks. The x86-64 provider shall keep two
private context records, save either dispatcher or worker state according to
the opaque transfer state, and generate both typed worker roots. Structural
and pinned-QEMU evidence shall prove the handoff, intervening terminal worker,
cooperative resumption, both retirements, and both reclamations without a
provider-owned run queue.

The bounded runnable-queue increment shall check capacity-two construction,
cooperative then terminal enqueue, three FIFO dequeues, suspended cooperative
re-enqueue, and empty consumption after both reclamations. Queue operations
shall remain source-owned typestate: they may be erased when statically proven
and shall add no provider symbol, call, relocation, instruction, or run queue.
Artifact evidence shall retain every queue transition and prove the provider
operation and undefined-dependency sets are unchanged.

The deadline-preemption increment shall check one atomic
context/deadline/dispatcher binding, one sealed worker preemption region, one
preempting deadline disposition, affine extraction and re-enqueue of the
interrupted worker, and later restoration before retirement and reclamation.
The x86-64 provider shall privately arm the qualified event, retain the saved
interrupt continuation in the bound context, restore the exact dispatcher,
and resume through the retained interrupt return only after source selects that
context again. Structural and pinned-QEMU evidence shall prove this causal
order without exposing interrupt frames, registers, stack pointers, vectors,
routes, or scheduler selection to source.

The one-shot completion increment shall check one fresh completion identity,
matching affine wait and signal authority, one third disjoint 16 KiB worker
stack, capacity-three FIFO selection, exact dispatcher registration, a
block-first outcome, signal after terminal reclamation, awakened enqueue,
resume immediately after the wait, all three context reclamations, and final
completion and queue consumption. The source-owned create, signal, queue, and
consume transitions shall add no provider-owned scheduler. The x86-64
provider shall keep the completion worker's context record and stack layout
private and lower only the checked opaque block/restore boundary. Structural
and pinned-QEMU evidence shall prove blocking, intervening terminal execution,
signalling, later source-selected resumption, retirement, and quiescence.

The initial user-execution increment shall check one PID-one probe, one affine
prepare/enter/complete lifecycle, one typed user-syscall entry, Linux x86-64
`getpid` followed by `exit_group(0)`, the exact return and terminal results,
and restoration of the bound kernel continuation. The source-owned semantic
model shall expose the syscall number and six arguments while keeping target
frames, registers, selectors, page-table encodings, stacks, and return
instructions private. The x86-64 provider shall lower the checked operations
to one fixed qualification-only user code page and NX stack, user privilege
entry, `SYSCALL` dispatch, exact `SYSRETQ` return, and terminal kernel-stack
restoration. Structural and pinned-QEMU evidence shall prove the complete
round trip before its success marker and quiescent fatal disposition.

The writable initial-data increment shall check the typed
`user mapping permit writable data` transition only after generation-two
RO/NX verification. Lowering shall restore the qualified data PTE's write
authority, retain NX, complete translation invalidation, and return one opaque
writable-data owner accepted by exact data-first unmap. The generated ELF shall
mark its data segment `PF_R | PF_W`; constructed code shall write and read back
one BSS byte before terminal success. The root shall emit the exact ordered
`TOPAL_KERNEL_USER_IMAGE_WRITABLE_DATA_OK` marker only after successful user
return. Structural tests shall reject code-role use, preverification use,
identity substitution, stale unmap, missing invalidation, or W+X permission.

The bounded multipage-executable increment shall accept a two-frame
`probe-code` extent and keep the one-frame `probe-data` extent distinct. The
x86-64 provider shall publish adjacent leaves for both code frames, copy and
compare the complete runtime-sized segment across their boundary, remove write
authority from both leaves before setting execute on either, invalidate both
virtual pages after permission or presence changes, and unmap and return the
original extent as one unit. The generated ELF entry and successful terminal
path shall execute from the second page. Structural and pinned-QEMU evidence
shall prove complete two-leaf lifecycle, no W+X phase, second-page execution,
exact return, and the ordered
`TOPAL_KERNEL_USER_IMAGE_MULTIPAGE_EXEC_OK` marker.

The bounded static-ELF plan increment shall derive one immutable checked plan
before any supplied executable metadata can influence artifact construction.
The parser shall validate the complete ELF64 header and bounded program-header
table, exact four R/RX/R/RW load roles, file/memory/page interval arithmetic,
page congruence and disjointness, entry containment, non-executable stack,
optional TLS and RELRO containment, no interpreter or W+X, and the x86-64
512-page one-leaf-table bound. Tests shall reproduce the pinned BusyBox-shaped
envelope without committing third-party bytes and shall reject each malformed
class independently. The existing sealed two-page runtime validator shall
remain stricter and shall not select a plan-only image.

The bounded static-ELF page-realization increment shall consume that checked
plan without reparsing ELF bytes. It shall require exact adjacency, derive one
future span-sized affine request with alignment one, enumerate every virtual
page and frame ordinal, start every page RW/NX, assign entry-stage RO/NX, RO/X,
or RW/NX including staged writable RELRO, and retain one whole-span zero followed by
the four exact file-copy intervals. Tests shall prove the pinned 503-page role
counts, complete ordered coverage, zero-before-copy, no W+X state, and rejection
of gaps or malformed inherited plans. It shall grant no runtime authority or
make the image selectable.

The supplied static-ELF artifact increment shall accept one
`--static-user-image PATH` only for qualified systems publication, read and
validate the complete input before creating publication state, and require the
exact approved 2,024,544-byte, eleven-program-header, 503-page x86-64 shape.
On success it shall publish those exact bytes as canonical `static-user.elf`
and bind that canonical name and SHA-256 digest in artifact provenance without
recording the host path. The option shall remain distinct from
`--initial-user-image`; omitting it shall preserve the existing output set and
selecting it shall add exactly one provenance-bound output. Unreadable,
duplicate, nonsystems, malformed, noncanonical-shape, partially written, or
unbound input shall fail before atomic publication. Tests shall use a
deterministic clean-room fixture with approved metadata and independent
payload bytes, cover rejected shape classes and exact-byte publication, and
prove that the current boot resource does not consume the new artifact.

The bounded static-ELF resident-header-variant increment shall admit exactly
the sectionless clean-room tuple or the pinned external tuple
`(e_shoff=0x1edea0, e_shentsize=64, e_shnum=23, e_shstrndx=22)` while keeping
every other ELF-header byte and the complete eleven-row program-header table
exact. Artifact validation shall prove the external section directory ends at
the complete 2,024,544-byte input boundary and reject mixed, third, overflowed,
or out-of-bounds tuples. Provider lowering shall byte-check the selected
coherent resident header and complete program-header table without parsing or
retaining the non-loadable section directory. Qualification shall preserve the
clean-room gate and separately require external digest
`7ae95c260622412ceba6eb9f45d68f616cdc091a1d71d6c0a08b5875bb2c31dd`,
bind the exact bytes through artifact and boot provenance, and run the complete
existing process and rollback evidence without committing or recording the
host path. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-RESIDENT-HEADER-VARIANTS-001` and `TK-DEC-192`.

The static-ELF boot-transport increment shall require the canonical
`static-user.elf` output and verify its artifact-provenance digest before boot
publication. It shall generate exactly one deterministic uncompressed newc
archive with ordered `init`, `static-user.elf`, and terminal records, copy both
payloads exactly, and bind the archive plus both member names, sizes, and
SHA-256 digests in boot provenance. The x86-64 provider shall validate the
extended handoff bounds, exact archive length, both headers and padding, the
terminal record, and the complete approved static ELF header/program-header
metadata while leaving caller-owned payload bytes unembedded. Frame allocation
shall exclude the whole enlarged resource. Tests shall reject missing,
unbound, changed, or reordered static input, prove exact two-member layout and
digest binding, and retain deterministic pinned-QEMU execution without making
the static member source-visible or runnable.

The bounded static-ELF payload-copy increment shall accept exactly one typed
consuming transition from the zeroed construction to a populated construction,
sealed source `retained-static-user-elf`, and sealed plan
`bounded-static-elf-four-loads`. X86-64 lowering shall revalidate the retained
boot handoff and static ELF metadata, copy the exact four approved intervals
to offsets `0`, `0x1000`, `0x18d000`, and `0x1e5660`, compare every copied
byte, verify every other byte through the complete `0x1f7000` payload remains
zero, and verify all 503 RW/NX leaves plus nine absent entries unchanged. The
checker and model shall require zero-before-copy, one exact copied witness,
populated-owner revocation, complete metadata-then-payload return, and no live
construction at disposition. Structural and pinned-QEMU tests shall reject
wrong owner, selector, plan, order, or early revocation and shall prove no
source-visible offset, address, byte, loop, or final permission authority.

The bounded static-ELF final-permission increment shall accept exactly one
typed consuming transition from the populated construction to a sealed
construction and only plan `bounded-static-elf-wx-relro`. X86-64 lowering
shall revalidate the complete populated payload, both resource extents, all
503 initial RW/NX leaves, and nine absent entries before replacing inactive
leaves with exactly 89 RO/NX, 396 RO/X, and 18 RW/NX entry-stage roles. It shall preserve
every payload-frame identity and ordinal, keep all nine remaining entries
absent, reject every W+X result, publish the complete update, and read back the
entire final table before success. The checker and model shall require
population-before-sealing, one exact permission witness, sealed-owner
revocation, complete metadata-then-payload return, and no live construction at
disposition. Structural and pinned-QEMU tests shall reject wrong owner, plan,
role, count, order, duplicate sealing, or early revocation and shall prove no
source-visible page ordinal, permission bit, address, loop, page-table entry,
or activation authority.

The bounded static-ELF hierarchy-extent increment shall admit exactly one typed
`static image construction reserve hierarchy` operation for a five-frame,
one-frame-aligned allocation while the sealed construction remains live.
X86-64 lowering shall fail closed through the fatal edge, preserve the payload and leaf-table identities,
select the complete hierarchy extent after and disjoint from both resources,
the boot resource, and active translation metadata, and return it only as one
whole affine extent. The checker and model shall require permission sealing
before allocation, one exact hierarchy witness while both authorities are
live, whole hierarchy release before construction revocation, and no live
extent at disposition. Structural and pinned-QEMU tests shall reject wrong
count, order, marker, split, early release, or early revocation and shall prove
that allocation grants no byte, mapping, attachment, activation, or entry
authority.

The bounded static-ELF address-space increment shall accept exact typed attach,
detach, and hierarchy-reclaim transitions over the sealed construction and
five-frame hierarchy extent. X86-64 lowering shall revalidate all extents and
final leaves, prove the root inactive, zero and verify the hierarchy, construct
and read back the exact supervisor bootstrap/MMIO hierarchy linked to the
existing user leaf table, and preserve every payload byte and leaf role.
Detach shall revalidate the same inactive shape, zero and verify the complete
hierarchy, return it through one affine reclaim and whole release, then admit
the existing metadata/payload revocation under the detached owner. Tests shall
reject wrong owner, layout, entry, leaf, root state, order, witness, partial
return, or live disposition and shall prove two deterministic pinned-QEMU
executions without activation, stack, entry, or execution authority.

The bounded static-ELF activation increment shall accept exact typed activate
and restore transitions over the attached construction. X86-64 lowering shall
revalidate the hierarchy, final leaves, retained bootstrap root, and exact
active/inactive root preconditions; switch to the static root with architectural
synchronization and readback; permit only the bounded supervisor witness
continuation; restore and read back the bootstrap root; and reproduce the
unchanged attached owner before detach. The checker and semantic model shall
reject wrong owner, policy, order, nested activation, detach or resource return
while active, wrong witness order, or live activation authority at disposition.
Structural and duplicate pinned-QEMU tests shall prove exact root-register
transitions, unchanged hierarchy/leaves/payload, restoration before teardown,
and no static entry, stack, TLS, user-mode, syscall, or BusyBox authority. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-ACTIVATION-001` and `TK-DEC-137`.

The bounded static-ELF entry-authority increment shall accept exact typed
authorize and revoke transitions over the restored attached construction.
X86-64 lowering shall revalidate the inactive hierarchy, final leaves, copied
ELF entry `0x004a6580`, entry-page ordinal 166, offset `0x580`, and immutable
user read/execute non-writable role without publishing any numeric address.
The checker and semantic model shall admit only policies
`validated-static-elf-entry` and `bounded-entry-qualification-rollback`, keep
the authority affine, reject activation, detach, return, duplication, wrong
witness order, or disposition while authorized, and reproduce the restored
owner only after exact revocation. Structural and duplicate pinned-QEMU tests
shall prove complete readback, unchanged payload/leaves/hierarchy/root state,
ordered authorization and revocation witnesses, and no stack, TLS, user-mode,
instruction-fetch, syscall, or BusyBox authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTRY-AUTHORITY-001` and `TK-DEC-138`.

The bounded static-ELF stack-slot increment shall accept exact typed authorize
and revoke transitions over the entry-authorized construction. X86-64 lowering
shall revalidate the inactive hierarchy, all 503 final image leaves, copied ELF
entry authority, all nine absent leaves, absent slot ordinal 511, immediate
absent guard ordinal 510, and provider-private aligned top `0x00800000` without
publishing an address, page-table index, or stack pointer. The checker and
semantic model shall admit only policies `bounded-linux-initial-stack-slot` and
`bounded-stack-slot-qualification-rollback`, keep both entry and slot authority
affine, reject entry revocation, activation, detach, return, duplication, wrong
witness order, or disposition while slot-authorized, and reproduce the
entry-authorized owner only after exact slot revocation. Structural and
duplicate pinned-QEMU tests shall prove complete readback, absent slot and
guard, unchanged payload/leaves/hierarchy/root state, ordered authorization and
revocation witnesses, and no stack backing, initialization, TLS, user-mode,
instruction-fetch, syscall, or BusyBox authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-STACK-SLOT-001` and `TK-DEC-139`.

The bounded static-ELF stack-backing increment shall admit one exact nested
`(1, 1)` physical-frame request while stack-slot authority is live. X86-64
lowering shall retain the static hierarchy identity, request at or above the
first frame after its exact five-frame extent, reuse complete E820 and boot-
reservation validation, keep the resulting backing identity opaque, and clear
it while restoring the hierarchy identity on exact whole release. The checker
and semantic model shall reject another shape, duplicate extent, partial or
misordered release, slot or entry revocation, teardown, or disposition while
backing is live. Structural and duplicate pinned-QEMU tests shall prove the
nested allocator floor, disjoint resource identities, one ordered witness,
whole release before slot revocation, and no zeroing, leaf publication, stack
pointer, initialization, TLS, user-mode, syscall, or BusyBox authority. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-STACK-BACKING-001` and `TK-DEC-140`.

The bounded static-ELF stack-zeroing increment shall accept one exact typed
zero transition over the slot-authorized construction and its live one-frame
backing. X86-64 lowering shall validate a nonzero page-aligned bounded frame,
clear exactly 512 forward qwords, execute one store fence, and compare exactly
512 forward qwords with zero before success. The checker and semantic model
shall accept only the exact owner, backing identity, and complete extent;
retain affine zeroed-backing ownership until whole release; and reject early
release, duplicate zeroing, slot or entry revocation, teardown, or disposition
while backing is live. Structural and duplicate pinned-QEMU tests shall prove
complete clear/readback, target ordering, unchanged hierarchy/leaves/payload,
one ordered witness, whole release before slot revocation, and no leaf
publication, stack pointer, process-entry initialization, TLS, user-mode,
syscall, or BusyBox authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-STACK-ZERO-001` and `TK-DEC-141`.

The bounded static-ELF stack-leaf increment shall accept one exact typed
publication from the zeroed-backing construction and one exact typed
revocation back to it. X86-64 lowering shall validate the inactive hierarchy,
current bootstrap root, all 503 final image leaves, absent guard and slot, and
complete zero backing; publish only leaf ordinal 511 as the exact backing with
present/user/writable/NX attributes; execute one store fence; and completely
read back the result. Revocation shall validate that exact leaf, erase only it,
execute one store fence, and completely revalidate the absent slot/guard,
unchanged image leaves, inactive hierarchy, current root, and zero backing.
The checker and semantic model shall preserve affine published-leaf ownership
and reject another owner/backing/access/extent/policy, duplicate publication,
early release, activation, teardown, or disposition while the leaf is live.
Structural and duplicate pinned-QEMU tests shall prove exact publication and
revocation, complete readback, preserved guard/image/hierarchy/root/backing,
ordered witnesses, and no stack pointer, process-entry initialization, TLS,
user-mode, syscall, or BusyBox authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-STACK-LEAF-001` and `TK-DEC-142`.

The bounded static-ELF stack-entry increment shall accept one exact typed
initialization from the published-stack-leaf construction and one exact typed
complete clearing back to it. X86-64 lowering shall validate the inactive
hierarchy, current bootstrap root, all final image leaves, exact RW/NX stack
leaf, absent guard, and complete zero backing; construct a 16-byte-aligned
Linux entry block with `argc` two, in-leaf `busybox` and `echo` strings,
terminated `argv`, empty terminated environment, and `AT_NULL`; execute one
store fence; and completely read back all content, pointer relations, and
otherwise-zero bytes. Clearing shall zero all 512 qwords, execute one store
fence, and completely revalidate zero backing plus unchanged leaf, hierarchy,
and root. The checker and semantic model shall preserve affine initialized-
stack ownership and reject another owner/backing/profile/extent/policy,
duplicate initialization, early leaf revocation or release, activation,
teardown, or disposition while initialized. Structural and duplicate pinned-
QEMU tests shall prove exact ABI content, complete readback and clearing,
preserved guard/image/hierarchy/root/leaf, ordered witnesses, and no exposed
stack pointer, further auxiliary-vector entries, TLS, user-mode, syscall, or
BusyBox execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-STACK-ENTRY-001` and `TK-DEC-143`.

The bounded static-ELF page-size auxiliary-vector increment shall accept one
exact typed addition from the minimal initialized stack-entry construction and
one exact typed removal back to it. X86-64 lowering shall completely validate
the minimal block and inactive translation obligations; clear the full frame;
reconstruct a 16-byte-aligned block with native `AT_PAGESZ` tag 6, value 4096,
and the exact prior arguments, empty environment, strings, and terminating
`AT_NULL`; fence; and completely read back all content and otherwise-zero
bytes. Removal shall validate the extended block, clear the full frame,
reconstruct the exact minimal block, fence, and completely read it back. The
checker and semantic model shall preserve affine page-size-fact ownership and
reject another owner/backing/value/policy, duplicate addition, early ordinary
clearing or leaf revocation, activation, release, teardown, or disposition.
Structural and duplicate pinned-QEMU tests shall prove exact tag/value/order,
complete reconstruction and rollback, preserved translation state, ordered
witnesses, and no exposed representation, further auxiliary-vector fact, TLS,
user-mode, syscall, or BusyBox execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-AUXV-PAGESZ-001` and `TK-DEC-144`.

The bounded static-ELF executable-entry auxiliary-vector increment shall
accept one exact typed addition from the page-size-qualified stack-entry
construction and one exact typed removal back to it. X86-64 lowering shall
completely validate the page-size block, inactive translation obligations,
resident static ELF header, exact executable leaf, and retained opaque entry
authority; prove executable containment; clear the full frame; reconstruct a
16-byte-aligned block with native `AT_ENTRY` tag 9, exact retained entry
`0x4a6580`, prior `AT_PAGESZ=(6,4096)`, arguments, empty environment, strings,
and terminating `AT_NULL`; fence; and completely read back all content,
relations, and otherwise-zero bytes. Removal shall validate the extended
block, clear the full frame, reconstruct the exact page-size block, fence, and
completely read it back. The checker and semantic model shall preserve affine
executable-entry-fact ownership and reject another owner/backing/value/policy,
duplicate addition, early page-size removal, ordinary clearing or leaf
revocation, activation, release, teardown, or disposition. Structural and
duplicate pinned-QEMU tests shall prove exact tag/value/order and executable
containment, complete reconstruction and rollback, preserved translation and
entry authority, ordered witnesses, and no exposed address or representation,
further auxiliary-vector fact, TLS, user-mode, syscall, or BusyBox execution
authority. This realizes `TOPAL-SYSTEMS-STATIC-ELF-AUXV-ENTRY-001` and
`TK-DEC-145`.

The bounded static-ELF program-header auxiliary-vector increment shall accept
one exact typed addition from the executable-entry-qualified stack construction
and one exact typed removal back to it. X86-64 lowering shall completely
validate that block, inactive translation obligations, resident static ELF
header, complete eleven-row program-header table, exact immutable header leaf,
and validated-plan agreement; clear the full frame; reconstruct a 16-byte-
aligned block with `AT_PHDR=(3,0x400040)`, `AT_PHENT=(4,56)`,
`AT_PHNUM=(5,11)`, all prior facts, arguments, empty environment, strings, and
terminating `AT_NULL`; fence; and completely read back all content, relations,
and otherwise-zero bytes. Removal shall validate the extended block, clear the
full frame, reconstruct the exact executable-entry-qualified block, fence, and
completely read it back. The checker and semantic model shall preserve affine
program-header-group ownership and reject another owner/backing/value/policy,
duplicate addition, early prior-fact removal, ordinary clearing or leaf
revocation, activation, release, teardown, or disposition. Structural and
duplicate pinned-QEMU tests shall prove exact tags, values, order, table
identity and bounds, complete reconstruction and rollback, preserved
translation and metadata authority, ordered witnesses, and no exposed address
or representation, further auxiliary-vector fact, TLS, user-mode, syscall, or
BusyBox execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-AUXV-PHDR-001` and `TK-DEC-146`.

The bounded static-ELF executable-name auxiliary-vector increment shall accept
one exact typed addition from the program-header-qualified stack construction
and one exact typed removal back to it. X86-64 lowering shall validate that
block, inactive translation obligations, exact stack leaf, and complete
`busybox\0` and `echo\0` objects; prove the executable-name identity equals
the existing `argv[0]` object; clear the full frame; reconstruct a 16-byte-
aligned block with `AT_EXECFN=(31,0x7fffe0)`, all prior facts, arguments,
strings, and terminating `AT_NULL`; fence; and completely read back all
content, aliases, and otherwise-zero bytes. Removal shall validate the
extended block, clear the full frame, reconstruct the exact program-header-
qualified block, fence, and completely read it back. The checker and semantic
model shall preserve affine executable-name-fact ownership and reject another
owner/backing/value/policy, duplicate addition, early prior-fact removal,
ordinary clearing or leaf revocation, activation, release, teardown, or
disposition. Structural and duplicate pinned-QEMU tests shall prove exact tag,
pointer, order, same-object aliasing, complete reconstruction and rollback,
preserved translation state, ordered witnesses, and no exposed pointer or
representation, further auxiliary-vector fact, TLS, user-mode, syscall, or
BusyBox execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-AUXV-EXECFN-001` and `TK-DEC-147`.

The bounded static-ELF credential auxiliary-vector increment shall accept one
exact typed addition from the executable-name-qualified stack construction and
one exact typed removal back to it. X86-64 lowering shall validate that block,
inactive translation obligations, exact stack leaf, complete argument strings,
and sealed PID-one process profile; clear the full frame; reconstruct a
16-byte-aligned block with ordered `AT_UID=(11,0)`, `AT_EUID=(12,0)`,
`AT_GID=(13,0)`, and `AT_EGID=(14,0)`, all prior facts, arguments, strings,
and terminating `AT_NULL`; fence; and completely read back all content,
relations, and otherwise-zero bytes. Removal shall validate the extended
block, clear the full frame, reconstruct the exact executable-name-qualified
block, fence, and completely read it back. The checker and semantic model
shall preserve affine credential-group ownership and reject another owner,
backing, value, policy, duplicate addition, early prior-fact removal, ordinary
clearing or leaf revocation, activation, release, teardown, or disposition.
Structural and duplicate pinned-QEMU tests shall prove exact tags, zero values,
order, profile agreement, complete reconstruction and rollback, preserved
translation state, ordered witnesses, and no exposed numeric identity or
representation, further auxiliary-vector fact, TLS, user-mode, syscall, or
BusyBox execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-AUXV-CREDENTIALS-001` and `TK-DEC-148`.

The bounded static-ELF non-secure auxiliary-vector increment shall accept one
exact typed addition from the credential-qualified stack construction and one
exact typed removal back to it. X86-64 lowering shall validate that block,
inactive translation obligations, exact stack leaf, complete argument strings,
sealed equal real/effective credentials, and absence of a privilege-changing
executable transition; clear the full frame; reconstruct a 16-byte-aligned
block with `AT_SECURE=(23,0)`, all prior facts, arguments, strings, and
terminating `AT_NULL`; fence; and completely read back all content, relations,
and otherwise-zero bytes. Removal shall validate the extended block, clear the
full frame, reconstruct the exact credential-qualified block, fence, and
completely read it back. The checker and semantic model shall preserve affine
security-fact ownership and reject another owner, backing, value, policy,
duplicate addition, early prior-fact removal, ordinary clearing or leaf
revocation, activation, release, teardown, or disposition. Structural and
duplicate pinned-QEMU tests shall prove exact tag, zero value, credential
agreement, complete reconstruction and rollback, preserved translation state,
ordered witnesses, and no exposed policy number or representation, further
auxiliary-vector fact, TLS, user-mode, syscall, or BusyBox execution authority.
This realizes `TOPAL-SYSTEMS-STATIC-ELF-AUXV-SECURE-001` and `TK-DEC-149`.

The bounded static-ELF userspace-accounting-rate increment shall accept one
exact typed addition from the secure-mode-qualified stack construction and one
exact typed removal back to it. X86-64 lowering shall validate that block,
inactive translation obligations, exact stack leaf, complete argument strings,
and the separation of Linux's baseline userspace accounting rate from hardware
and scheduler clocks; clear the full frame; reconstruct a 16-byte-aligned block
with `AT_CLKTCK=(17,100)`, all prior facts, arguments, strings, and terminating
`AT_NULL`; fence; and completely read back all content, relations, and
otherwise-zero bytes. Removal shall validate the extended block, clear the
full frame, reconstruct the exact secure-mode-qualified block, fence, and
completely read it back. The checker and semantic model shall preserve affine
clock-tick-rate ownership and reject another owner, backing, value, policy,
duplicate addition, early prior-fact removal, ordinary clearing or leaf
revocation, activation, release, teardown, or disposition. Structural and
duplicate pinned-QEMU tests shall prove exact tag and value, clock-identity
separation, complete reconstruction and rollback, preserved translation state,
ordered witnesses, and no exposed rate or representation, further auxiliary-
vector fact, TLS, user-mode, syscall, or BusyBox execution authority. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-AUXV-CLKTCK-001` and `TK-DEC-150`.

The bounded static-ELF native-platform increment shall accept one exact typed
addition from the clock-rate-qualified stack construction and one exact typed
removal back to it. X86-64 lowering shall validate that block, inactive
translation obligations, exact stack leaf, complete argument strings, and
prior facts; clear the full frame; reconstruct a 16-byte-aligned block with
native `AT_PLATFORM` pointing to one complete bounded `x86_64\0` string, all
prior facts, arguments, strings, and terminating `AT_NULL`; fence; and
completely read back all content, pointer containment, alias separation, and
otherwise-zero bytes. Removal shall validate the extended block, clear the
full frame, reconstruct the exact clock-rate-qualified block, fence, and
completely read it back. The checker and semantic model shall preserve affine
platform ownership and reject another owner, backing, value, policy, duplicate
addition, early prior-fact removal, ordinary clearing or leaf revocation,
activation, release, teardown, or disposition. Structural and duplicate pinned-
QEMU tests shall prove exact tag, pointer, string and termination, complete
reconstruction and rollback, executable-name separation, preserved translation
state, ordered witnesses, and no exposed platform representation, further
auxiliary-vector fact, TLS, user-mode, syscall, or BusyBox execution authority.
This realizes `TOPAL-SYSTEMS-STATIC-ELF-AUXV-PLATFORM-001` and `TK-DEC-151`.

The bounded static-ELF native hardware-capability increment shall accept one
exact typed addition from the platform-qualified stack construction and one
exact typed removal back to it. X86-64 lowering shall validate that block,
inactive translation obligations, exact stack leaf, complete argument and
platform strings, and prior facts; clear the full frame; reconstruct a 16-byte-
aligned block with native `AT_HWCAP=(16,0x178bfbfd)` and `AT_HWCAP2=(26,0)`,
all prior facts, strings, and terminating `AT_NULL`; fence; and completely read
back all content and otherwise-zero bytes. Removal shall validate the extended
block, clear the full frame, reconstruct the exact platform-qualified block,
fence, and completely read it back. The checker and semantic model shall
preserve affine capability-group ownership and reject another owner, backing,
value, policy, duplicate addition, early prior-fact removal, ordinary clearing
or leaf revocation, activation, release, teardown, or disposition. Structural
and duplicate pinned-QEMU tests shall prove exact tags and masks, complete
reconstruction and rollback, preserved strings and translation state, ordered
witnesses, and no exposed mask, CPUID, feature-bit, random, TLS, user-mode,
syscall, or BusyBox execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-AUXV-HWCAP-001` and `TK-DEC-152`.

The bounded static-ELF load-metadata increment shall accept one exact typed
addition from the hardware-capability-qualified stack construction and one
exact typed removal back to it. X86-64 lowering shall validate that block,
inactive translation obligations, exact stack leaf, complete strings, prior
facts, absent interpreter, and accepted ELF flags; clear the full frame;
reconstruct a 16-byte-aligned block with native `AT_BASE=(7,0)` and
`AT_FLAGS=(8,0)`, all prior facts and strings, and terminating `AT_NULL`; fence;
and completely read back all content and otherwise-zero bytes. Removal shall
validate the extended block, clear the full frame, reconstruct the exact
capability-qualified block, fence, and completely read it back. The checker and
semantic model shall preserve affine load-metadata ownership and reject another
owner, backing, value, policy, duplicate addition, early prior-fact removal,
ordinary clearing or leaf revocation, activation, release, teardown, or
disposition. Structural and duplicate pinned-QEMU tests shall prove exact tags
and explicit zero values, complete reconstruction and rollback, non-overlapping
block growth, preserved prior facts and translation state, ordered witnesses,
and no exposed value, header, random, TLS, user-mode, syscall, or BusyBox
execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-AUXV-LOAD-METADATA-001` and `TK-DEC-153`.

The bounded static-ELF random-slot-authority increment shall accept one exact
typed authorization from the load-metadata-qualified stack construction and
one exact typed revocation back to it. X86-64 lowering shall validate the
complete unchanged block, inactive translation obligations, exact stack leaf,
complete strings and prior facts; prove one naturally aligned 16-byte zero
destination and space for one future native tag-25 entry inside the same page;
and completely read back all content and otherwise-zero bytes without a store.
Revocation shall repeat the complete validation and restore the exact load-
metadata-qualified owner. The checker and semantic model shall preserve affine
random-slot authority and reject another owner, backing, value, extent,
policy, duplicate authorization, mutation, early prior-fact removal, ordinary
clearing or leaf revocation, activation, release, teardown, or disposition.
Structural and duplicate pinned-QEMU tests shall prove the zero destination,
alignment, complete bounds and non-overlap, unchanged deterministic block,
preserved translation state, ordered witnesses, and no exposed address, byte,
tag, pointer, entropy, TLS, user-mode, syscall, or BusyBox execution authority.
This realizes `TOPAL-SYSTEMS-STATIC-ELF-RANDOM-SLOT-001` and `TK-DEC-154`.

The bounded static-ELF prepared-process-retention increment shall accept one
exact typed transfer from the random-slot-authorized construction into an
opaque affine retained-process owner and one exact qualification restoration.
X86-64 lowering shall preserve the provider-private payload, metadata,
hierarchy, leaf, entry, and stack-backing identities in compiler-controlled
root state, close construction allocator state without resource release, and
restore the exact nested one-frame backing obligation. Both transitions shall
completely validate the inactive hierarchy, image, deterministic stack, future
random-object zeros, guard, and identity tuple without stores, fences,
invalidation, release, or activation. The checker and semantic model shall
reject another owner, backing, value, policy, duplicate retention, mutation,
early restore, resource reuse, teardown, or disposition. Structural and
duplicate pinned-QEMU tests shall prove complete survival, closed allocator
state, exact restoration, ordered witnesses, and no exposed resource, entropy,
TLS, user-mode, syscall, or BusyBox execution authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-PREPARED-RETENTION-001` and `TK-DEC-155`.

The bounded static-ELF retained-disjoint-work increment shall consume and return
the exact opaque retained-process owner while using the same sealed allocator
for one fresh aligned frame. X86-64 lowering shall prove the selected extent
disjoint from payload, leaf metadata, upper hierarchy, and stack backing,
release only the fresh frame, and completely revalidate all retained identities
and bytes before returning the owner. The checker and semantic model shall
reject another owner, request, policy, allocator, overlap, incomplete proof,
partial or wrong release, mutation, duplication, early restore, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove fresh allocation
and release, retained-state survival, exact later restoration, ordered witnesses,
and no exposed address, DMA, entropy, TLS, user-mode, syscall, or BusyBox
authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-RETAINED-DISJOINT-WORK-001` and `TK-DEC-156`.

The bounded static-ELF entropy-handoff increment shall consume the exact
retained-process owner and produce one opaque entropy-pending process owner,
then support one immediate qualification revocation back to the exact retained
owner. X86-64 lowering shall keep the complete provider-private resource tuple
in compiler-controlled root state and completely validate the inactive image,
hierarchy, deterministic stack, future random-object zeros, strings, guard, and
identities on both transitions without allocation, release, stores, fences,
invalidation, activation, extraction, or delivery. The checker and semantic
model shall reject another owner, process identity, policy, mutation,
duplication, early restore, output use, or recoverable failure. Structural and
duplicate pinned-QEMU tests shall prove exact transfer and rollback, unchanged
state, ordered witnesses, and no exposed address, entropy, TLS, user-mode,
syscall, or BusyBox authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-HANDOFF-001` and `TK-DEC-157`.

The bounded static-ELF entropy-acquisition-authority increment shall consume the
exact entropy-pending owner into one opaque acquisition owner bound to output
identity one and resulting generation two, then support one immediate
qualification revocation to the exact entropy-pending owner. X86-64 lowering
shall preserve the complete provider-private process tuple and completely
validate every retained identity and byte on both transitions without device
access, allocation, release, mutation, activation, extraction, output copy, or
delivery. The checker and semantic model shall reject another owner, output,
generation, policy, ordering, mutation, duplication, early handoff revocation,
output use, or recoverable failure. Structural and duplicate pinned-QEMU tests
shall prove exact transfer and rollback, unchanged process state, ordered
witnesses, and no exposed process or entropy representation, TLS, user-mode,
syscall, or BusyBox authority. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-ACQUISITION-AUTHORITY-001` and `TK-DEC-158`.

The bounded static-ELF entropy-device-coexistence increment shall consume and
return the exact acquisition owner around one sealed read-only initial entropy-
device observation. X86-64 lowering shall completely validate the retained
process, then use the existing generic PCI configuration boundary to require
the pinned Q35 virtio-rng identity at `0000:00:05.0` without a configuration
write, BAR access, DMA, negotiation, process mutation, release, activation, or
output use. The checker and semantic model shall reject another owner, device,
policy, ordering, duplicate observation, early rollback, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove complete
process validation before one real read, same-owner return, exact ordered
witness, and no exposed process, PCI, or entropy representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-DEVICE-COEXISTENCE-001` and `TK-DEC-159`.

The bounded static-ELF entropy-transport-discovery increment shall consume and
return the exact acquisition owner around the remaining sealed read-only
initial entropy-transport observations. X86-64 lowering shall completely
validate the retained process, then use the existing generic PCI configuration
boundary for the remaining 23 entries of the exact pinned Q35 virtio-rng
discovery sequence without a configuration write, BAR access, DMA,
negotiation, process mutation, release, activation, or output use. Together
with the preceding identity observation, the checker and semantic model shall
require the complete sequence and reject another owner, transport, policy,
coordinate, value, ordering, omission, duplicate observation, early rollback,
or recoverable failure. Structural and duplicate pinned-QEMU tests shall prove
complete process validation before real reads, same-owner return, exact ordered
witnesses, and no exposed process, capability, PCI, or entropy representation.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-TRANSPORT-DISCOVERY-001` and `TK-DEC-160`.

The bounded static-ELF entropy-transport-negotiation increment shall consume
and return the exact acquisition owner around one reversible write-capable
transport qualification. X86-64 lowering shall completely validate the
retained process, use the existing generic PCI-region boundary for the exact
16-access pinned Q35 virtio-rng negotiation, prove the mandatory version-one
feature and retained `FEATURES_OK`, then write and read back status zero. It
shall restore and verify the discovered zero BAR, offset, and length fields of
the provider-private configuration gateway after every access and shall not
consume the later ordinary transport sequence. The checker and
semantic model shall reject another owner, transport, policy, access, feature,
order, omission, duplicate, final status, early rollback, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove complete
process validation before real accesses, exact negotiation, reset, and gateway
rollback, same-owner return, later-sequence preservation, and no exposed
process, BAR, register, PCI, or entropy representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-TRANSPORT-NEGOTIATION-001` and `TK-DEC-161`.

The bounded static-ELF entropy-queue-discovery increment shall consume and
return the exact acquisition owner around one reversible queue qualification.
X86-64 lowering shall completely validate the retained process, replay the
exact 16-access pinned Q35 virtio-rng negotiation, execute the exact
five-access queue-discovery sequence, and prove queue zero exists with size
eight, disabled state, and notification identity zero. It shall then write and
read back status zero through the generic PCI-region boundary, restore and
verify the provider-private configuration gateway after every access, and
shall not consume the later ordinary transport sequence. The checker and
semantic model shall reject another owner, transport, queue, policy, access,
feature, order, omission, duplicate, queue fact, final state, early rollback,
or recoverable failure. Structural and duplicate pinned-QEMU tests shall prove
complete process validation before real accesses, exact negotiation, queue
discovery, reset, and gateway rollback, same-owner return, later-sequence
preservation, and no exposed process, BAR, register, queue, PCI, or entropy
representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-QUEUE-DISCOVERY-001` and `TK-DEC-162`.

The bounded static-ELF entropy-bus-master increment shall consume and return
the exact acquisition owner around one reversible device-initiation-authority
qualification. X86-64 lowering shall completely validate the retained process,
replay the exact negotiation and queue-discovery sequences, perform the exact
masked bus-master enable and inverse transitions with unmasked command bits
preserved, then write and read back status zero. It shall restore and verify
the provider-private configuration gateway after every region access and shall
not consume the later ordinary transport sequence. The checker and semantic
model shall reject another owner, device, policy, prerequisite access, masked
transition, order, omission, duplicate, unmasked-bit change, final state, early
rollback, or recoverable failure. Structural and duplicate pinned-QEMU tests
shall prove complete process validation before real accesses, exact
prerequisite replay, exact enable and inverse transitions, device and gateway
rollback, same-owner return, later-sequence preservation, and no exposed
process, command, PCI, DMA, or entropy representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-BUS-MASTER-001` and `TK-DEC-163`.

The bounded static-ELF entropy-DMA-buffer-coexistence increment shall consume
and return the exact acquisition owner around one transaction-scoped two-buffer
qualification. X86-64 lowering shall completely validate the retained process,
replay negotiation and queue discovery, enable bus mastering, qualify the exact
sealed control and payload requests, prove their aligned, disjoint, initially
zero backing, then reverse bus mastering and restore device and gateway state.
No candidate identity shall escape and the later ordinary sequence shall
remain unconsumed. The checker and semantic model shall reject another owner,
device, domain, policy, request, role, direction, visibility, order, omission,
duplicate, backing property, final state, early rollback, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove complete
process validation, exact prerequisite replay, both buffer qualifications,
complete rollback, same-owner return, later-sequence preservation, and no
exposed process, DMA, address, PCI, or entropy representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-DMA-BUFFER-COEXISTENCE-001` and `TK-DEC-164`.

The bounded static-ELF entropy-split-ring-coexistence increment shall consume
and return the exact acquisition owner around one transaction-scoped queue
construction. X86-64 lowering shall completely validate the retained process;
replay negotiation, queue discovery, bus mastering, and both DMA-buffer
qualifications; perform the exact opaque reference binding and four ordered
split-ring stores; then erase all five fields in reverse publication order,
including an exact 8-byte zero store for the reference field. It shall reverse
bus mastering and restore device and gateway state. No buffer identity or bound
address shall escape and the later ordinary sequence shall remain unconsumed.
The checker and semantic model shall reject another owner, device, domain,
queue, policy, field, width, offset, value, order, omission, duplicate, exposed
identity/address, nonzero final byte, early rollback, or recoverable failure.
Structural and duplicate pinned-QEMU tests shall prove complete process
validation, exact prerequisite replay, exact ring construction, reverse-order
erasure, complete rollback, same-owner return, later-sequence preservation, and
no exposed process, DMA, address, PCI, queue, or entropy representation. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-SPLIT-RING-COEXISTENCE-001` and
`TK-DEC-165`.

The bounded static-ELF entropy-DMA-preparation-coexistence increment shall
consume and return the exact acquisition owner around one transaction-scoped
payload-then-control ownership transfer. X86-64 lowering shall completely
validate the retained process, replay the exact prerequisite sequence through
ring construction, prepare payload then control, cancel unexposed ownership in
control-then-payload order, erase and read back the ring, and restore bus-
master, device, and gateway state. No DMA identity shall escape and the later
ordinary sequence shall remain unconsumed. The checker and semantic model shall
reject another owner, device, domain, queue, policy, ownership order, omission,
duplicate, escaped identity, final state, early rollback, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove the complete
transaction, same-owner return, later-sequence preservation, and no exposed
process, DMA, cache, mapping, PCI, queue, or entropy representation. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-DMA-PREPARATION-COEXISTENCE-001` and
`TK-DEC-166`.

The bounded static-ELF entropy-queue-address-coexistence increment shall
consume and return the exact acquisition owner around one transaction-scoped
three-reference publication. X86-64 lowering shall completely validate the
retained process, replay the exact prerequisite sequence through payload-then-
control DMA preparation, publish descriptor then driver then device-area
references, clear and read back those complete registers in reverse order,
cancel control then payload preparation, erase and read back the ring, and
restore bus-master, device, and gateway state. No DMA identity or resolved
reference shall escape and the later ordinary sequence shall remain
unconsumed. The checker and semantic model shall reject another owner, device,
domain, queue, transport, policy, publication or clearing order, omission,
duplicate, escaped identity, nonzero final register, final state, early
rollback, or recoverable failure. Structural and duplicate pinned-QEMU tests
shall prove the complete transaction, same-owner return, later-sequence
preservation, and no exposed process, DMA, address, PCI, queue, or entropy
representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-QUEUE-ADDRESS-COEXISTENCE-001` and
`TK-DEC-167`.

The bounded static-ELF entropy-queue-activation-coexistence increment shall
consume and return the exact acquisition owner around one transaction-scoped
empty activation. X86-64 lowering shall completely validate the retained
process, replay the exact prerequisite sequence through ring construction,
withdraw and verify the available index while CPU-owned, prepare and publish
both buffers, perform exact queue enablement and `DRIVER_OK` readback without
notification, reset the device, and prove status, queue enable, and every queue
address zero before DMA cancellation. It shall then erase and read back the
ring and restore bus-master and gateway state. No DMA identity or resolved
reference shall escape and the later ordinary sequence shall remain
unconsumed. The checker and semantic model shall reject another owner, device,
domain, queue, transport, policy, nonempty activation, notification, missing
readback, omission, duplicate, escaped identity, nonzero final state, early
rollback, or recoverable failure. Structural and duplicate pinned-QEMU tests
shall prove the complete transaction, same-owner return, later-sequence
preservation, and no exposed process, DMA, address, PCI, queue, or entropy
representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-QUEUE-ACTIVATION-COEXISTENCE-001` and
`TK-DEC-168`.

The bounded static-ELF entropy-request-completion-coexistence increment shall
consume and return the exact acquisition owner around one completed and erased
32-byte device request. X86-64 lowering shall completely validate the retained
process, replay the exact ordinary sequence through activated available work,
notify queue zero, observe and acknowledge the bounded signal, validate the
four used-ring facts, and return control then payload ownership. It shall
capture or credit no sample, reset and verify all transport state, overwrite
and read back the complete payload and every source- or device-written ring
field, reverse bus mastering, and restore gateway state. No payload byte, DMA
identity, or resolved reference shall escape and the later ordinary sequence
shall remain structurally unconsumed. The checker and semantic model shall
reject another owner, device, domain, queue, transport, policy, completion
fact, ownership order, early CPU access, missing acknowledgement, partial
erase, captured or credited sample, escaped byte or identity, nonzero final
state, or recoverable failure. Structural and duplicate pinned-QEMU tests shall
prove the complete transaction, same-owner return, later-sequence preservation,
and no exposed process, DMA, address, PCI, queue, or entropy representation.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-REQUEST-COMPLETION-COEXISTENCE-001` and
`TK-DEC-169`.

The bounded static-ELF entropy-sample-capture-coexistence increment shall
consume and return the exact acquisition owner around one captured and erased
raw sample. X86-64 lowering shall completely validate the retained process,
replay the exact ordinary sequence through payload ownership return, copy the
complete 32-byte payload into the sealed raw-sample storage with zero credit,
and preserve payload ownership. It shall expose no byte or sample identity,
assess or credit no entropy, reset and verify all transport state, overwrite
and read back the complete payload, ring, and raw-sample storage, reverse bus
mastering, and restore gateway state. The later ordinary sequence shall remain
structurally unconsumed. The checker and semantic model shall reject another
owner, device, domain, queue, transport, sample, range, credit, policy,
ordering, omission, duplicate, assessment, escaped byte or identity, partial
erase, nonzero final state, or recoverable failure. Structural and duplicate
pinned-QEMU tests shall prove exact capture, complete destruction, same-owner
return, later-sequence preservation, and no exposed process, DMA, address, PCI,
queue, or entropy representation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-SAMPLE-CAPTURE-COEXISTENCE-001` and
`TK-DEC-170`.

The bounded static-ELF entropy-sample-quality-coexistence increment shall
consume and return the exact acquisition owner around one assessed and erased
sample. X86-64 lowering shall completely validate the retained process and
replay the ordinary sequence through exact zero-credit capture. The checked
kernel policy shall apply only the sealed Q35 source/evidence, 32-byte extent,
1024/1024 quality, and 256-bit credit transition without emitting target trust
mechanics or inspecting bytes. Lowering shall reset and verify transport state,
overwrite and read back payload, ring, and assessed-sample storage, reverse bus
mastering, and restore gateway state. The checker and semantic model shall
reject every substituted fact, provider-selected trust, omission, duplicate,
escaped byte or authority, partial erase, nonzero final state, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove exact
assessment, complete destruction, same-owner return, and later-sequence
preservation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-SAMPLE-QUALITY-COEXISTENCE-001` and
`TK-DEC-171`.

The bounded static-ELF entropy-pool-lifecycle-coexistence increment shall
consume and return the exact acquisition owner around one complete pool
lifecycle. X86-64 lowering shall completely validate the retained process and
replay the ordinary sequence through exact assessed-sample creation. Checked
policy shall create the exact empty 256-bit pool, invoke the qualified BLAKE2s
conditioner for the exact first contribution, and transfer zero-to-256 credit
only after mixing. Lowering shall reset and verify transport state, overwrite
and read back payload, ring, sample, and pool storage, reverse bus mastering,
and restore gateway state. The checker and semantic model shall reject every
substituted fact, early credit, ordering error, omission, duplicate, escaped
byte or authority, partial erase, nonzero final state, or recoverable failure.
Structural and duplicate pinned-QEMU tests shall prove the complete lifecycle,
destruction, same-owner return, and later-sequence preservation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-POOL-LIFECYCLE-COEXISTENCE-001` and
`TK-DEC-172`.

The bounded static-ELF entropy-generator-lifecycle-coexistence increment shall
consume and return the exact acquisition owner around one complete generator
lifecycle. X86-64 lowering shall completely validate the retained process and
replay the ordinary sequence through the exact credited pool, initialize the
generation-one 32-byte ChaCha20 key, and extract only output range `[32, 64)`
from the exact counter-zero, nonce-zero block while advancing to generation
two. It shall deliver no output, reset and verify transport state, overwrite
and read back payload, ring, sample, pool, key, and output storage, reverse bus
mastering, and restore gateway state. The checker and semantic model shall
reject every substituted fact, ordering error, omission, duplicate, delivery,
escaped byte or authority, partial erase, nonzero final state, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove the complete
lifecycle, destruction, same-owner return, and later-sequence preservation.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ENTROPY-GENERATOR-LIFECYCLE-COEXISTENCE-001` and
`TK-DEC-173`.

The bounded static-ELF initial-random-delivery-coexistence increment shall
consume the exact acquisition owner and produce one affine randomized static-
process owner. X86-64 lowering shall completely validate the retained process,
replay the ordinary entropy sequence through exact first extraction, publish
one native tag-25 pair and distinct aligned 16-byte stack object, verify the
copy without exposing bytes, wipe the complete output, and destroy and verify
all remaining entropy, DMA, transport, bus-master, and gateway resources while
the process result remains live. A qualification-only inverse shall verify and
erase the complete object and pair and restore the exact acquisition owner
before existing rollback. The checker and semantic model shall reject every
substituted fact, ordering error, omission, duplicate, premature delivery,
overlap, escaped authority, partial copy or erase, nonzero inverse state, or
recoverable failure. Structural and duplicate pinned-QEMU tests shall prove
the persistent forward boundary, exact inverse, and later-sequence
preservation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-RANDOM-DELIVERY-COEXISTENCE-001` and
`TK-DEC-174`.

The bounded static-ELF process-entry increment shall consume the exact
randomized-process owner and produce one affine completed-process owner. X86-64
lowering shall completely revalidate the retained process, derive its entry
and initial stack from provider-private authorities, install a private static-
process syscall/continuation context, activate the retained address space,
enter CPL3, accept only `exit_group(0)`, and restore the exact kernel CR3, GS,
stack, and continuation before returning. It shall enter the pinned external
executable at its complete final Linux stack (`0x007ffe90`) while retaining the
clean-room fixture's exact pre-existing stack, preserve every non-result Linux
syscall register and provider System V callee-saved register, and clear all
private saved slots.
Lowering shall retain and restore CR4, enable only OSFXSR and OSXMMEXCPT after
checking CR0, initialize fresh x87/MXCSR/XMM state, and scrub it before return.
It shall zero and verify the bounded mutable stack prefix and normalize A/D bits
across all 503 image leaves plus the stack leaf before exact readback. The
qualification shall cover clean-room bytes and the digest-pinned external
BusyBox `echo` path without redistributing the external bytes. A qualification-
only inverse shall validate and clear the terminal context and restore the exact
randomized owner before the existing nested rollback. The checker and semantic
model shall reject every substituted owner, executable digest, header variant,
ABI, terminal result, policy, ordering error, duplicate entry, escaped native
state, changed process resource, incomplete restoration, nonzero inverse state,
or recoverable failure. Structural and duplicate pinned-QEMU tests shall prove
real `IRETQ` entry, native `SYSCALL` return, exact CR3 and SIMD restoration, the
affine forward/inverse lifecycle, and later-sequence preservation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-PROCESS-ENTRY-001`, `TK-DEC-175`, `TK-DEC-194`, and
`TK-DEC-195`.

The bounded static-ELF initial-break-query increment shall refine that exact
entry with `startup is initial-brk-query` and policy
`bounded-static-elf-initial-brk-query`. X86-64 lowering shall derive the initial
break by checked 4 KiB ceiling of the retained writable load segment's memory
end, admit exactly one native `brk(0)` from the sealed executable before
`exit_group(0)`, return the derived value, and retain no source-provided or
independently embedded address authority. The clean-room fixture shall compare
the complete returned `0x005f7000` value before terminal return. The
qualification inverse shall clear the private query-completion state. The
checker and semantic model shall reject every substituted startup service,
policy, request, result, ordering error, duplicate query, non-executable
continuation, changed process state, nonzero inverse state, or recoverable
failure. Structural and duplicate pinned-QEMU tests shall prove derivation from
the writable image, native dispatch, query-before-terminal ordering, affine
forward/inverse preservation, and later-sequence preservation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-BRK-QUERY-001` and `TK-DEC-176`.

The bounded static-ELF initial-break-growth increment shall refine that entry
with startup service `initial-brk-query-growth`, one distinct aligned zeroed
artifact reserve, and policy `bounded-static-elf-initial-brk-growth`. X86-64
lowering shall preserve the exact initial query, then accept one request for
`0x005f7d80`, publish and invalidate one user RW/NX leaf at `0x005f7000`,
return the request through `SYSRETQ`, and permit a first-byte store/load before
terminal exit. Terminal handling shall remove and verify the leaf, reset the
private break, erase and verify all 4,096 reserve bytes, and clear mapping
authority before returning. The qualification inverse shall prove and clear
query/growth completion. The checker and semantic model shall reject another
startup service, reserve, request, result, order, duplicate, early terminal,
permission, alias, partial publication, inaccessible byte, retained state,
partial erase, or recoverable failure. Structural and duplicate pinned-QEMU
tests shall prove distinct BSS ownership, exact leaf mechanics, query/growth/
terminal order, first-byte access, complete teardown, and later-sequence
preservation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-BRK-GROWTH-001` and `TK-DEC-177`.

The bounded static-ELF initial-x86-FS-base increment shall refine that entry
with startup service `initial-brk-query-growth-x64-fs-base` and policy
`bounded-static-elf-initial-x64-fs-base`. After the exact query and growth,
x86-64 lowering shall accept one native syscall 158 operation `0x1002` with
candidate `0x005f7400`, prove the complete byte lies in the live readable
anonymous break mapping, retain it privately, install `IA32_FS_BASE`, return
zero through `SYSRETQ`, and permit an FS-relative byte read before terminal
exit. Terminal handling shall require install completion, restore the exact
pre-entry physical FS base, clear the private selection, and preserve complete
heap rollback. The qualification inverse shall prove and clear query/growth/
install completion. The checker and semantic model shall reject another
startup service, operation, candidate, result, order, duplicate, early
terminal, unreadable base, non-executable continuation, wrong physical state,
failed relative access, retained selection, source-visible native detail, or
recoverable failure. Structural and duplicate pinned-QEMU tests shall prove the
exact native dispatch, provider installation, access, restoration, clearing,
and later-sequence preservation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-X64-FS-BASE-001` and `TK-DEC-178`.

The bounded static-ELF initial-clear-TID increment shall refine that entry with
startup service `initial-brk-query-growth-x64-fs-base-clear-tid` and policy
`bounded-static-elf-initial-clear-tid`. X86-64 lowering shall accept one native
syscall 218 candidate `0x005f76d0`, prove its complete writable word lies in the
live anonymous break mapping, retain it without dereference, and return TID one
through `SYSRETQ`. Terminal exit shall store and verify zero while the process
address space remains active, clear the candidate, emit no futex wake, and
preserve complete state and heap rollback. Checker, structural, negative, and
duplicate pinned-QEMU evidence shall reject another candidate, result, order,
duplicate, early terminal, invalid word, failed clear, retained state, native
source detail, or recoverable failure. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-CLEAR-TID-001` and `TK-DEC-179`.

The bounded static-ELF empty-robust-list increment shall refine startup with
service `initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list` and
policy `bounded-static-elf-initial-empty-robust-list`. X86-64 lowering shall
accept syscall 273 only for candidate `0x005f76e0` and length 24, prove the
complete readable head lies in the anonymous break mapping, retain it without
dereference, and return zero. Terminal handling shall copy and validate the
exact self-link, `-32` offset, and null pending pointer before restoration,
clear registration, perform no futex action, and preserve earlier teardown.
Negative, structural, and duplicate pinned-QEMU evidence shall enforce this
boundary. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-EMPTY-ROBUST-LIST-001` and `TK-DEC-180`.

The bounded static-ELF initial-`rseq` fallback increment shall refine startup
with service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback`
and policy `bounded-static-elf-initial-rseq-fallback`. The clean-room x86-64
payload shall issue native syscall 334 with candidate `0x005f7300`, length 33,
flags zero, and signature `0x53053053` immediately after robust-list
registration. The existing unsupported-call arm shall return exact `-ENOSYS`
without inspecting the arguments, touching user memory, retaining state, or
changing any prior process state; later implemented terminal dispatch shall
remain usable. Negative, structural, and duplicate pinned-QEMU evidence shall
enforce exact request order, result, state preservation, and continuation. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-INITIAL-RSEQ-FALLBACK-001` and `TK-DEC-181`.

The bounded static-ELF initial-stack-limit increment shall refine startup with
service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit`
and policy `bounded-static-elf-initial-stack-limit`. The clean-room x86-64
payload shall issue query-only syscall 302 for PID zero, selector 3, null new
limit, and exact writable stack candidate `0x007ffe60`. Lowering shall validate
the live state, executable continuation, exact request, and complete candidate;
publish the established 8 MiB soft limit and infinite hard limit; retain no
state; and return zero. The payload shall validate both words, balance its
temporary stack extent, and continue through terminal dispatch. Negative,
structural, and duplicate pinned-QEMU evidence shall enforce the boundary. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-INITIAL-STACK-LIMIT-001` and `TK-DEC-182`.

The bounded static-ELF initial-`readlinkat` fallback increment shall refine
startup with service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback`
and policy `bounded-static-elf-initial-readlinkat-fallback`. The clean-room
x86-64 payload shall issue native syscall 267 with `AT_FDCWD`, path candidate
`0x005bfdda`, output candidate `0x005fe000`, and length 4096 immediately after
the stack-limit query. The unsupported-call path shall return exact `-ENOSYS`
without inspecting arguments, touching user memory, retaining state, or
changing prior process state; later implemented terminal dispatch shall remain
usable. Negative, structural, and duplicate pinned-QEMU evidence shall enforce
exact request order, result, state preservation, and continuation. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-INITIAL-READLINKAT-FALLBACK-001` and
`TK-DEC-183`.

The bounded static-ELF initial-`getrandom` increment shall refine startup with
service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom`
and policy `bounded-static-elf-initial-getrandom`. Initial-random delivery
shall move output bytes 16 through 31 into one process-private affine
reservation before wiping provider output and destroying every other entropy
resource. The clean-room x86-64 payload shall then issue native syscall 318
with output candidate `0x005f5e68`, length eight, and nonblocking flag one.
Lowering shall validate the live startup state, sealed executable
continuation, exact request, available reservation, and complete writable
static destination; publish and verify the exact reserved prefix without a
value oracle; wipe the complete reservation; mark it consumed; and return
eight. Terminal handling shall require consumed zero state and clear the
marker before restoration. Negative, structural, and duplicate pinned-QEMU
evidence shall enforce exact provenance, request order, publication,
single-use consumption, destruction, and continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-GETRANDOM-001` and `TK-DEC-184`.

The bounded static-ELF reusable-`getrandom` increment shall refine startup with
service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated`
and policy `bounded-static-elf-reusable-getrandom`. Initial-random delivery
shall move both the 16-byte reserved first output and generation-two ChaCha20
key into one process-private affine service before provider-global entropy
teardown. The first call shall remain unchanged. Later valid calls of one
through 16 bytes shall validate flags and the complete writable static extent
before privileged-stack extraction, replace the persistent key before
publication, copy and verify the requested prefix, wipe the complete temporary
output, and retain only the successor key. Zero, `-EINVAL`, and `-EFAULT` paths
shall not evolve service state. The clean-room x86-64 payload shall add a second
eight-byte nonblocking request at `0x005f5e70`, observe no constant value, and
clear its scratch. Terminal handling shall erase and verify every private key,
output, reference, counter, and scratch byte and normalize every accepted
writable static leaf before restoration. Negative, structural, and duplicate
pinned-QEMU evidence shall enforce ownership, validation-before-evolution,
fast key erasure, repeated delivery, complete destruction, and continuation.
This realizes `TOPAL-SYSTEMS-STATIC-ELF-REUSABLE-GETRANDOM-001` and
`TK-DEC-185`.

The bounded static-ELF post-random-break-query increment shall refine startup
with service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query`
and policy `bounded-static-elf-post-random-brk-query`. After the reusable-random
witness, the clean-room x86-64 payload shall issue native syscall 12 with a
zero request and require exact current break `0x005f7d80`. Lowering shall
validate the live post-growth state and sealed executable continuation, return
the established byte-granular break, and preserve the anonymous reserve,
mapping, random service, and terminal rollback unchanged. Negative,
structural, and duplicate pinned-QEMU evidence shall enforce exact request,
result, order, nonmutation, and continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-POST-RANDOM-BRK-QUERY-001` and `TK-DEC-186`.

The bounded static-ELF post-random-break-growth increment shall refine startup
with service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth`
and policy `bounded-static-elf-post-random-brk-growth`. After the current-break
witness, the clean-room x86-64 payload shall request native break
`0x00618d80`, require that exact result, and write/read last admitted byte
`0x00618d7f`. Lowering shall consume one exact 34-frame anonymous extent, use
the separately owned fifth hierarchy frame as the high leaf table, retain 34
zero anonymous data frames, preserve the initial first-page behavior, publish
eight remaining leaves in the existing table and 25 in the high table, and
update the current break only after publication. Terminal handling shall
retain the disjoint high stack leaf, remove all anonymous leaves, clear and verify the complete
extent, and return it through the existing affine inverse. Negative,
structural, full-workspace, and duplicate pinned-QEMU evidence shall enforce
exact request, zero backing, hierarchy-boundary publication, last-byte access,
complete rollback, and continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-POST-RANDOM-BRK-GROWTH-001` and `TK-DEC-187`.

The bounded static-ELF post-random-break-page-alignment increment shall refine
startup with service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth-page-alignment`
and policy `bounded-static-elf-post-random-brk-page-alignment`. After the
cross-boundary growth witness, the clean-room x86-64 payload shall request
native break `0x00619000`, require that exact result, and write/read final newly
admitted byte `0x00618fff`. Lowering shall require current break `0x00618d80`,
the live 34-frame anonymous extent, the complete existing heap-leaf set, the
disjoint stack leaf, sealed executable continuation, and reusable-random
service; allocate no storage; edit no translation entry; and update only the
byte-granular break state. Terminal handling shall require the aligned state
before performing the complete existing rollback. Negative, structural,
full-workspace, and duplicate pinned-QEMU evidence shall enforce exact request,
nonallocation, mapping preservation, final-byte access, complete rollback, and
continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-POST-RANDOM-BRK-PAGE-ALIGNMENT-001` and `TK-DEC-188`.

The bounded static-ELF RELRO-protection increment shall refine startup with
service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth-page-alignment-relro-mprotect`
and policy `bounded-static-elf-relro-mprotect`. After the aligned-break witness,
the clean-room x86-64 payload shall request native `mprotect` for exact interval
`[0x005e5000, 0x005ed000)` with `PROT_READ` and require result zero. Lowering
shall require the live aligned-break phase, sealed executable continuation,
active checked hierarchy, exact eight-page GNU RELRO role with original affine
frames and RW/NX leaves, complete existing heap and disjoint stack state, and
reusable-random service. It shall replace exactly those leaves with RO/NX
leaves, preserve every frame, publish the complete edit, invalidate exactly the
eight target pages, read back the complete sealed interval, and advance only
the private startup phase. Terminal
handling shall require that phase before performing the complete existing
rollback. Negative, structural, full-workspace, and duplicate pinned-QEMU
evidence shall enforce exact request, entry and sealed role and frame validation,
bounded translation mutation and invalidation, complete rollback, and continuation.
This realizes `TOPAL-SYSTEMS-STATIC-ELF-RELRO-MPROTECT-001`, `TK-DEC-189`, and
`TK-DEC-193`.

The bounded static-ELF initial-process-name increment shall refine startup with
service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth-page-alignment-relro-mprotect-process-name`
and policy `bounded-static-elf-initial-process-name`. After the RELRO witness,
the clean-room x86-64 payload shall reuse the qualified temporary area below its initial stack,
request native `prctl(PR_GET_NAME)` into exact interval
`[0x007ffe60, 0x007ffe70)`, require result zero, verify the complete `busybox`
plus zero-padding field, erase the scratch, and restore its stack pointer.
Lowering shall require the live RELRO-confirmed phase, sealed executable
continuation, active hierarchy, exact writable stack leaf and output extent,
and reusable-random service. It shall publish the complete field from sealed
process metadata, retain no user pointer or mutable name state, and advance
only the private startup phase. Terminal handling shall require that phase
before performing the complete existing rollback. Negative, structural,
full-workspace, and duplicate pinned-QEMU evidence shall enforce exact request,
complete byte publication, stack bounds, nonretention, scratch clearing,
rollback, and continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-PROCESS-NAME-001` and `TK-DEC-190`.

The bounded static-ELF initial-`getuid` increment shall refine startup with
service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth-page-alignment-relro-mprotect-process-name-getuid`
and policy `bounded-static-elf-initial-getuid`. After the process-name witness,
the clean-room x86-64 payload shall issue native syscall 102, require result
zero, and continue. Lowering shall require the live process-name phase, sealed
executable continuation, active checked hierarchy, exact retained stack leaf,
and complete zero-valued `AT_UID`/`AT_EUID`/`AT_GID`/`AT_EGID` group. It shall
ignore native argument registers, retain no argument or mutable identity
state, and advance only the private startup phase. Terminal handling shall
require that phase before performing the complete existing rollback. Negative,
structural, full-workspace, and duplicate pinned-QEMU evidence shall enforce
exact dispatch, credential coherence, zero result, nonretention, rollback, and
continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-GETUID-001`,
`TOPAL-SYSTEMS-USER-IDENTITY-001`, and `TK-DEC-191`.

The bounded static-ELF initial-configuration-stat increment shall refine
startup with service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth-page-alignment-relro-mprotect-process-name-getuid-config-stat-miss`
and policy `bounded-static-elf-initial-config-stat-miss`. After the real-UID
witness, the clean-room x86-64 payload shall reserve scratch below its initial
vector, issue native syscall 262 with `AT_FDCWD`, an immutable
`/etc/busybox.conf` path, a complete 144-byte stack destination and flags zero,
require `-ENOENT`, restore its stack pointer, and continue. Lowering shall
require the live real-UID phase, sealed executable continuation, active checked
hierarchy, exact retained stack leaf, complete header-variant-bound immutable
path, and complete writable destination. It shall publish no bytes, retain no
argument or lookup state, and advance only the private startup phase. Clean-
room terminal handling shall require the absence phase and all later phases;
the pinned external root `echo` profile may skip from `getuid(0)` to its
mandatory output phase. Negative, structural, full-workspace, clean-QEMU, and external-QEMU
evidence shall enforce exact dispatch, complete path and range validation,
absence result, nonmutation, nonretention, header-bound terminal choice,
rollback, and continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-CONFIG-STAT-MISS-001` and `TK-DEC-196`.
The later owned frame selection instead applies
`TOPAL-COMP-SYSTEMS-USER-EXTENT-001`: admit the pathname and perform no output
admission or access on an absent lookup. The preceding sealed selection retains
the exact destination and placement witnesses above.

The bounded static-ELF initial-credential-tail increment shall refine startup
with service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth-page-alignment-relro-mprotect-process-name-getuid-config-stat-miss-credential-tail`
and policy `bounded-static-elf-initial-credential-tail`. After the configuration
miss, the clean-room x86-64 payload shall issue native syscalls 104, 106, and
105 in order, supply zero to the latter two, require zero after each, and
continue. Lowering shall require the
exact preceding phase, sealed executable continuation, active checked
hierarchy, exact retained stack leaf, and complete zero-valued
`AT_UID`/`AT_EUID`/`AT_GID`/`AT_EGID` group for every operation. It shall ignore
the `getgid` argument registers, require both setter arguments to equal the
sealed zero identities, retain no argument or mutable identity state, leave the
credential group unchanged, and advance only the exact private startup phase.
Clean-room terminal handling shall require this phase and its later output;
the pinned external root `echo` profile may skip this optional branch but must
complete output. Negative, structural, full-workspace, clean-QEMU, and
external-QEMU evidence shall enforce exact dispatch, ordering, credential
coherence, same-value setter requests, zero results, nonretention, rollback,
and continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-INITIAL-CREDENTIAL-TAIL-001`,
`TOPAL-SYSTEMS-USER-IDENTITY-001`, and `TK-DEC-197`.

The bounded static-ELF applet-newline increment shall refine startup with
service
`initial-brk-query-growth-x64-fs-base-clear-tid-empty-robust-list-rseq-fallback-stack-limit-readlinkat-fallback-getrandom-repeated-brk-query-growth-page-alignment-relro-mprotect-process-name-getuid-config-stat-miss-credential-tail-applet-newline-write`
and policy `bounded-static-elf-applet-newline-write`. After the credential tail,
the clean-room x86-64 payload shall construct a stack-local line feed, issue
native `write(1, candidate, 1)`, require result one, clear the byte, restore its
stack, and continue. Lowering shall require the exact phase, sealed executable
continuation, active checked hierarchy, and the header-profile-bound byte in
the retained stack leaf or pinned anonymous program-break mapping. It shall revalidate backing,
stage before output, require line feed, publish once, return one, retain no
pointer or staging, and advance only the private startup phase. The clean
profile shall require the credential-tail predecessor; the pinned external
root `echo` profile shall require the sealed `getuid(0)` predecessor. Both
shall require the output phase before terminal handling.
Negative, structural, full-workspace, clean-QEMU, and external-QEMU evidence
shall enforce dispatch, ordering, range and backing validation, staging,
payload equality, exact output and result, nonretention, rollback, and
continuation. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-APPLET-NEWLINE-WRITE-001`,
`TOPAL-SYSTEMS-USER-WRITE-001`, and `TK-DEC-198`.

The pinned static-BusyBox echo-profile increment shall seal profile
`bounded-static-elf-busybox-echo` and exact arguments `busybox`, `echo` in the
existing complete initial stack. All later stack facts, native process entry,
syscall returns, and rollback validation shall preserve those same strings and
pointer relations until complete clearing. After sealed `getuid(0)`, the pinned
external header shall skip its optional configuration and credential branch,
complete exactly one staged line-feed write, and call `exit_group(0)`; no
earlier terminal phase remains valid. The clean fixture shall retain its longer
optional branch before the same output and terminal phase.
Clean-room and external QEMU evidence shall each contain exactly one newline,
while the external executable stays digest-pinned and outside the repository.
Structural tests shall reject the former string bytes/profile and earlier
external terminal phases. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-ECHO-PROFILE-001` and `TK-DEC-199`.

The bounded static-process shell-getpid increment shall accept native x86-64
syscall 39 once, return the sealed PID one, retain no argument or mutable task
state, and advance only its private startup phase. The clean fixture shall
invoke it after newline output; the external echo profile may retain its
newline terminal path, and the future external shell profile shall bind it
directly to `getuid(0)`. Structural and QEMU evidence shall enforce exact
header-selected predecessor, executable continuation, retained hierarchy and
stack, result, nonretention, and rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-GETPID-001` and `TK-DEC-200`.

The bounded static-process shell-child-disposition increment shall accept one
native x86-64 `rt_sigaction` request for signal 17 after the shell-getpid
phase. It shall require no old-action output, native signal-set size eight,
the approved `SA_RESTORER` policy and child mask, complete readable candidate,
executable handler, trampoline, and continuation addresses, active checked
hierarchy and retained stack, and empty prior disposition. It shall copy and
validate the complete request, retain only private disposition state, return
zero, and advance one private startup phase. Terminal handling shall validate
and clear that state before rollback. The clean fixture shall construct and
erase the request; the external echo profile may retain its newline terminal
path, and a future external shell profile may bind the operation after
`getpid`. Structural and QEMU evidence shall enforce exact dispatch, fields,
ordering, state lifecycle, result, and rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-SIGCHLD-001` and `TK-DEC-201`.

The bounded static-process shell-getppid increment shall accept native x86-64
syscall 110 once after the child-disposition phase, return the sealed no-parent
value zero, retain no argument, lookup result, or mutable task state, and
advance only its private startup phase. It shall require executable
continuation, active checked hierarchy, retained stack, and the live child
disposition. The clean fixture shall require result zero; the external echo
profile may retain its newline terminal path, and a future external shell
profile may bind the observation after disposition installation. Structural
and QEMU evidence shall enforce exact dispatch, ordering, result,
nonretention, disposition preservation, and rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-GETPPID-001` and `TK-DEC-202`.

The bounded static-process empty-input shell increment shall accept exactly
native x86-64 `uname` into a checked stack extent, publish the established
390-byte identity, accept `getcwd(0x5f9460, 4096)`, publish `"/\0"`, return
two, then accept `ioctl(0, TCGETS, candidate)` with `-ENOTTY`, ordered
`rt_sigaction` observations for signals 2, 3, and 15, one native ignored
signal-3 installation, and `read(0, 0x5f8f60, 1023)` with result zero after
the shell-getppid phase. It shall publish complete zeroed 32-byte old actions
only to checked writable stack extents, validate and copy the ignored action,
retain only a private ignored-disposition fact, and clear it with the existing
child disposition at successful exit. The clean fixture shall continue in a
sealed executable island and require every result. The pinned external
profile shall select exact `busybox sh` arguments with an empty environment
and reach the same terminal phase. Structural and QEMU evidence shall enforce
dispatch, arguments, order, output, nonretention, disposition lifecycle,
sealed identity, directory, end-of-input, and rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-EMPTY-INPUT-001` and `TK-DEC-203`.

The bounded static-process sealed exit-command increment shall replace the
terminal empty-input result with one exact five-byte `exit\n` publication for
`read(0, 0x5f8f60, 1023)`, consume one fresh private input owner, return five,
and accept only immediate `exit_group(0)`. It shall validate the complete
writable destination before mutation, retain no pointer or readable input copy,
erase the process-visible bytes during terminal handling, and preserve the
existing disposition lifecycle and complete rollback. The clean fixture shall
verify and erase the same bytes before exit; the pinned external profile shall
select exact `busybox sh` arguments and execute the command. Structural and
QEMU evidence shall enforce input identity, dispatch, arguments, ordering,
complete copy, consumption, immediate exit, erasure, and rollback. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-SHELL-EXIT-COMMAND-001` and `TK-DEC-204`.

The bounded static-process sealed echo-command increment shall replace the
five-byte command with one exact sixteen-byte `echo topal\nexit\n` publication
for `read(0, 0x5f8f60, 1023)`, consume the fresh private input owner, return
sixteen, and accept only one exact six-byte descriptor-one `topal\n` write
before `exit_group(0)`. It shall validate the complete writable input and
readable output extents before access, stage and validate all output before
publication, retain no user pointer or readable private copy, require an exact
post-output phase at terminal handling, erase and prove erasure of every
command byte, and preserve the existing disposition lifecycle and complete
rollback. The clean fixture shall verify the same command, output, erasure, and
exit sequence; the pinned external profile shall execute the built-in command.
Structural and QEMU evidence shall enforce identity, dispatch, arguments,
ordering, complete copies, ownership, staging, publication, phase, terminal
erasure, and rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-ECHO-COMMAND-001` and `TK-DEC-205`.

The bounded static-process shell console-fstat increment shall accept native
x86-64 syscall 5 once for descriptor one and the exact checked clean-fixture
stack candidate after signal setup and before sealed command input. It shall
construct the complete approved 144-byte immutable console metadata in private
process staging, validate the complete destination before mutation, copy every
byte, clear and verify all staging, return zero, retain no user pointer, and
record one private observation without advancing the input-predecessor phase.
The later read and terminal paths shall require and clear the exact header-
profile-specific observation state; the external echo-command profile shall
require that it remains absent. The clean fixture shall validate every output
byte before its existing command sequence. Structural and QEMU evidence shall
enforce dispatch, arguments, phase, mapping, metadata, staging, publication,
erasure, profile distinction, lifecycle, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-CONSOLE-FSTAT-001` and `TK-DEC-206`.

The bounded static-process `/dev/tty` open-miss increment shall accept native
x86-64 syscall 257 once after the clean console-fstat observation and before
sealed command input. It shall require `AT_FDCWD`, the exact immutable clean-
fixture pathname candidate, `O_RDWR`, zero mode, complete `/dev/tty\0` bytes,
the live dispositions and checked hierarchy, and the unchanged input-
predecessor phase. It shall return `-ENOENT`, allocate no descriptor, retain no
pointer or lookup state, and publish one additional private observation without
advancing the phase. The read and terminal paths shall require the exact
header-profile-specific observation pair and clear both together at terminal
handling; the external echo-command profile shall require both absent.
Structural and QEMU evidence shall enforce dispatch, arguments, pathname,
mapping, result, nonallocation, ordering, lifecycle, profile distinction, and
unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-DEV-TTY-OPEN-MISS-001` and `TK-DEC-207`.

The bounded static-process standard-terminal-probe increment shall accept
exactly three native x86-64 syscall-16 requests after the clean `/dev/tty`
absence observation and before warning output or sealed input. It shall require
`TCGETS`, descriptors two, one, and zero in order, one complete checked 36-byte
initial-stack candidate, the live dispositions and checked hierarchy, the
unchanged input-predecessor phase, and both predecessor observations. Every
call shall return `-ENOTTY` without reading or changing the candidate or any
descriptor state. One private count shall advance only after complete
validation, and later clean input and terminal handling shall require count
three and clear it with the predecessor observations; the external echo profile
shall require all optional observations absent. Structural and QEMU evidence
shall enforce dispatch, arguments, extent, ordering, no-output effect, result,
count lifecycle, profile distinction, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-STANDARD-TERMINAL-PROBES-001` and `TK-DEC-208`.

The bounded static-process terminal-warning increment shall accept exactly
three native x86-64 syscall-1 requests after clean terminal-probe count three
and before later startup work or sealed input. It shall require descriptor two,
exact 4-, 40-, and 1-byte segments spelling `sh: can't access tty; job control
turned off\n`, complete checked readable initial-stack candidates, live
dispositions and hierarchy, unchanged input-predecessor phase, and all prior
observations. It shall stage and validate every complete segment before the
existing serial adapter publishes it, return each length, clear staging, and
retain no pointer or payload. One private count shall advance only after full
publication, and later clean input and terminal handling shall require count
three and clear it with all predecessor observations; the external echo profile
shall require all optional observations absent. Structural and QEMU evidence
shall enforce dispatch, contents, lengths, ordering, candidate extents,
staging-before-output, exact result and output, staging erasure, lifecycle,
profile distinction, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-TERMINAL-WARNING-001` and `TK-DEC-209`.

The bounded static-process mailbox-metadata increment shall accept exactly one
native x86-64 syscall-262 request after clean warning count three and before
banner output or sealed input. It shall require `AT_FDCWD`, immutable
`/var/spool/mail/root`, flags zero, one complete checked writable 144-byte
native-stat candidate in the retained initial stack, live dispositions and
hierarchy, unchanged input-predecessor phase, and all prior observations. It
shall return `-ENOENT` without changing the candidate, allocating a descriptor,
or retaining a pointer or path. One private fact shall publish only after
complete validation, and later clean input and terminal handling shall require
it and clear it with all predecessor observations; the external echo profile
shall require all optional observations absent. Structural and QEMU evidence
shall enforce dispatch, arguments, pathname, candidate extent, no-output
effect, result, nonallocation, lifecycle, profile distinction, and unchanged
rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-MAILPATH-STAT-MISS-001` and `TK-DEC-210`.

The bounded static-process shell-banner increment shall accept exactly one
native x86-64 syscall-1 request after the clean mailbox-absence fact and before
later profile lookup, prompt output, or sealed input. It shall require
descriptor one, the exact 109-byte BusyBox version and help banner, one complete
checked readable initial-stack candidate, live dispositions and hierarchy,
unchanged input-predecessor phase, and all prior observations. It shall copy
and validate all bytes in a fixed 112-byte private extent before the existing
serial adapter publishes them, return 109, erase and prove erasure of the whole
extent, and retain no pointer or payload. One private fact shall publish only
after complete output, and later clean input and terminal handling shall require
it and clear it with all predecessor observations; the external echo profile
shall require all optional observations absent. Structural and QEMU evidence
shall enforce dispatch, contents, length, candidate extent, staging-before-
output, exact result and output, staging erasure, lifecycle, profile
distinction, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-BANNER-001` and `TK-DEC-211`.

The bounded static-process post-banner-terminal increment shall accept exactly
one native x86-64 syscall-16 request after the clean banner fact and before
later startup work or sealed input. It shall require descriptor zero,
`TCGETS`, one complete checked writable 36-byte initial-stack candidate, live
dispositions and hierarchy, unchanged input-predecessor phase, and all prior
observations. It shall return `-ENOTTY` without reading or changing the
candidate, descriptor state, or retaining a pointer. One private fact shall
publish only after complete validation, and later clean input and terminal
handling shall require it and clear it with all predecessor observations; the
external echo profile shall require all optional observations absent.
Structural and QEMU evidence shall enforce dispatch, arguments, candidate
extent, no-output effect, result, lifecycle, profile distinction, and unchanged
rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-POST-BANNER-TERMINAL-PROBE-001` and `TK-DEC-212`.

The bounded static-process post-banner-current-directory increment shall
accept exactly one native x86-64 syscall-79 request after the clean post-banner
terminal fact and before later startup work or sealed input. It shall require
candidate `0x5f9460`, count 4096, complete checked anonymous-heap backing, live
dispositions and hierarchy, unchanged input-predecessor phase, and all prior
observations. It shall publish exactly `"/\0"`, return two, retain no pointer,
and leave process phase unchanged. One private fact shall publish only after
complete validation and publication, and later clean input and terminal
handling shall require it and clear it with all predecessor observations; the
external echo profile shall require all optional observations absent.
Structural and QEMU evidence shall enforce dispatch, arguments, checked heap,
complete output, result, lifecycle, profile distinction, and unchanged
rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-POST-BANNER-GETCWD-001` and `TK-DEC-213`.

The bounded static-process post-banner-effective-identity increment shall
accept exactly one native x86-64 syscall-107 request after the clean post-
banner current-directory fact and before profile, prompt, or sealed input. It
shall require the retained checked initial stack, live dispositions and
hierarchy, unchanged input-predecessor phase, all prior observations, and the
complete eight-word sealed real/effective user/group credential set. It shall
return zero, retain no argument or credential state, and leave process phase
unchanged. One fresh private fact shall publish only after complete validation,
and later clean input and terminal handling shall require it and clear it with
all predecessor observations; the external echo profile shall require every
optional observation absent. Structural and QEMU evidence shall enforce
dispatch, phase, complete credential coherence, result, lifecycle, profile
distinction, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-POST-BANNER-GETEUID-001` and `TK-DEC-214`.

The bounded static-process shell-profile-open increment shall accept exactly
one native x86-64 syscall-257 request after the clean post-banner effective-
identity fact and before later profile work or sealed input. It shall require
`AT_FDCWD`, exact sealed executable pathname `"/etc/profile\0"` at `0x4a6938`,
read-only flags, mode zero, the unused descriptor-three slot, an immutable
empty launch-owned file object, live dispositions and hierarchy, unchanged
input-predecessor phase, and all prior observations. It shall allocate one
process-owned read-only description, return three, retain no user pointer or
lookup scratch, and publish one private lifecycle fact. Later clean profile
work and terminal handling shall require the fact; teardown may revoke an
unclosed bounded description. The external echo profile shall require every
optional observation absent. Structural and QEMU evidence shall enforce
dispatch, arguments, pathname, object identity, allocation, result, lifecycle,
profile distinction, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-PROFILE-OPEN-001` and `TK-DEC-215`.

The bounded static-process shell-profile-metadata increment shall accept
exactly one native x86-64 syscall-5 request after the clean profile-open fact
and before profile input, close, or sealed input. It shall require descriptor
three, the live process-owned read-only description for the immutable empty
launch-owned profile, one exact complete writable 144-byte continuation-stack
candidate, live dispositions and hierarchy, unchanged input-predecessor phase,
and all prior observations. It shall construct the complete native regular-
file metadata in private staging, validate before user mutation, publish it,
erase and verify staging, return zero, retain no user pointer, and publish one
private completion fact. The value shall have stable identity two, link count
one, root ownership, mode `0100444`, zero size, blocks, timestamps, padding,
and unused fields, and preferred I/O size 4096. Later clean profile work and
terminal handling shall require the fact; teardown may revoke an unclosed
description. The external echo profile shall require every optional
observation absent. Structural and QEMU evidence shall enforce dispatch,
description identity, candidate extent, complete value, result, staging
erasure, lifecycle, profile distinction, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-PROFILE-FSTAT-001` and `TK-DEC-216`.

The bounded static-process shell-profile-EOF increment shall accept exactly
one native x86-64 syscall-0 request after the clean profile-metadata fact and
before profile close or sealed input. It shall require descriptor three, the
live process-owned read-only description for the immutable empty launch-owned
profile at position zero, the exact complete writable 128-byte continuation-
stack candidate, live dispositions and hierarchy, unchanged input-predecessor
phase, and all prior observations. It shall validate the complete candidate,
return zero without reading or changing any candidate byte or description
position, retain no user pointer, and publish one private completion fact.
Later clean profile work and terminal handling shall require the fact; teardown
may revoke an unclosed description. The clean fixture shall prove all 128 bytes
unchanged and then erased. The external echo profile shall require every
optional observation absent. Structural and QEMU evidence shall enforce
dispatch, description identity and position, candidate extent, bound, no-
output effect, result, lifecycle, profile distinction, and unchanged rollback.
This realizes `TOPAL-SYSTEMS-STATIC-ELF-SHELL-PROFILE-READ-001` and
`TK-DEC-217`.

The bounded static-process shell-profile-close increment shall accept exactly
one native x86-64 syscall-3 request after the clean profile-EOF fact and before
prompt or sealed input. It shall require descriptor three, the live process-
owned read-only description for the immutable empty launch-owned profile at
position zero, live dispositions and hierarchy, unchanged input-predecessor
phase, and all prior observations. It shall consume the description, free the
lowest nonstandard slot, preserve EOF history, return zero, retain no argument
or object state, and publish one distinct private closed-state fact after
proving the description absent. Later clean startup and terminal handling shall
require the description absent and close fact present; terminal handling shall
clear that fact. The external echo profile shall require every optional
observation absent. Structural and QEMU evidence shall enforce dispatch,
description identity and position, consumption, free-slot state, result,
lifecycle, profile distinction, and unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-PROFILE-CLOSE-001` and `TK-DEC-218`.

The bounded static-process shell-prompt increment shall accept exactly one
native x86-64 syscall-1 request after explicit clean profile close and before
command input. It shall require descriptor two, count four, the exact complete
readable continuation-stack segment `/ # `, live dispositions and hierarchy,
unchanged input-predecessor phase, absent profile description, live closed-
state history, fresh prompt fact, and all prior observations. It shall copy the
complete segment into empty private staging, validate before publication, emit
it in source order, erase and prove staging empty, return four, retain no user
pointer, and publish one private completion fact. Later clean input and
terminal handling shall require that fact; terminal handling shall clear it.
The clean fixture shall validate and erase its complete candidate. The external
echo profile shall require every optional observation absent. Structural and
QEMU evidence shall enforce dispatch, description state, candidate extent and
value, staging, output, result, erasure, lifecycle, profile distinction, and
unchanged rollback. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-PROMPT-001` and `TK-DEC-219`.

The bounded static-process shell-refill increment shall replace the one
combined clean command publication with two exact native x86-64 syscall-0
requests through the same checked anonymous buffer. After the initial prompt,
the first shall publish `echo topal\n` with zero sealed tail and return 11.
After exact `topal\n` output, one exact syscall-1 standard-error `/ # ` prompt
shall satisfy the existing complete checked-copy and staging-erasure contract
and publish a distinct fact. The second read shall replace the consumed first
command with `exit\n`, zero the sealed tail, and return 5. Both reads shall use
descriptor zero, requested count 1023, complete buffer and hierarchy checks,
live dispositions, exact predecessor state, and exclusive input-owner
transitions without retaining pointers. Clean terminal handling shall require
and validate the second publication, erase and prove the complete buffer,
consume its owner, and clear the second-prompt fact. The external echo profile
shall require the same second refill and terminal consumption while requiring
the optional clean prompt fact and all other clean observations absent.
Structural and QEMU evidence shall enforce dispatch, buffer and bound, exact
prefixes and zero tails, ownership, clean prompt ordering, results, terminal
erasure, profile distinction, and unchanged
rollback. This realizes `TOPAL-SYSTEMS-STATIC-ELF-SHELL-REFILL-INPUT-001` and
`TK-DEC-220`.

The bounded static-process shell-`pwd` increment shall extend the checked
command buffer to exact `echo topal\n`, `pwd\n`, and `exit\n` publications with
results 11, 4, and 5 and distinct affine input-owner states. After the `pwd`
publication, the clean profile shall admit one exact command-time native
x86-64 syscall-79 current-directory request through the complete checked
anonymous 4096-byte candidate at `0x005f_9460`, publish exact `/\0`, and return
two. The pinned external profile shall instead admit one syscall-5 descriptor-
one console-metadata request through the complete 144-byte stack candidate at
`0x007f_f370`, then one syscall-16 descriptor-one `TCGETS` request through the
exact 36-byte stack candidate at `0x007f_f2d0`; it shall return `-ENOTTY`
without mutating the terminal candidate and may then use its previously sealed
root fact. One following descriptor-one write shall validate and privately
stage exact `/\n`, publish two bytes, erase staging, and return two; its clean
candidate shall be `0x005f_9460` and its pinned external candidate shall be
`0x005f_9570`. The clean profile shall interpose an exact qualified prompt
before each command; the external profile shall require those optional
observations absent. Terminal handling shall require and erase the third
publication, consume its owner, clear every command-time fact, and preserve
complete rollback. Structural and QEMU evidence shall enforce one affine two-
base-page stack extent with both pages reserved, zeroed, mapped adjacent RW/NX,
verified, and released together; the initial ABI value shall remain in the
upper page and no stack growth or demand paging is admitted. Evidence shall
also enforce both profile variants, exact predecessor state, requests, values,
results, ownership, prompt and output ordering, erasure, and unchanged external
compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-PWD-COMMAND-001` and `TK-DEC-221`.

The bounded static-process shell-root-`cd` increment shall extend the checked
command buffer to exact `echo topal\n`, `cd /\n`, `pwd\n`, and `exit\n`
publications with results 11, 5, 4, and 5 and five distinct affine input-owner
states. After the `cd /` publication, both profiles shall admit one native
x86-64 syscall-80 current-directory change through a complete checked readable
two-byte candidate containing exact `/\0`; success shall return zero and
replace the prior private current-directory fact with a new sealed-root
generation without retaining a pointer or bytes. The later profile-specific
`pwd` sequence shall require that generation and preserve the exact clean
`getcwd`, external stdout `fstat`/`TCGETS`, application-owned `/\n`, and prompt
distinction of `TOPAL-SYSTEMS-STATIC-ELF-SHELL-PWD-COMMAND-001`. Its clean
output candidate shall remain exact; its pinned external output candidate may
move within the checked readable heap mapping `[0x005f7000, 0x00619000)`, but
shall retain a complete overflow-free two-byte extent, exact `/\n`, and count
and result two. Terminal handling shall require and erase the fourth
publication, consume its owner, clear all command-time and directory-generation
facts, and preserve complete rollback of the affine two-page stack. Structural
and QEMU evidence shall enforce exact predecessor state, requests, candidate
extent and value, result, state replacement, ownership, prompt and output
ordering, erasure, and unchanged external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-CD-ROOT-COMMAND-001` and `TK-DEC-222`.

The bounded static-process shell-root-directory-test increment shall extend the
checked command buffer to exact `echo topal\n`, `cd /\n`, `test -d /\n`,
`pwd\n`, and `exit\n` publications with results 11, 5, 10, 4, and 5 and six
distinct affine input-owner states. After the sealed-root generation has been
replaced, both profiles shall admit one native x86-64 syscall-262 request with
`AT_FDCWD`, flags zero, a complete checked readable two-byte pathname
containing exact `/\0`, and a complete checked writable 144-byte native
metadata candidate. Success shall publish a complete provider-sealed immutable
root-directory value with mode `040755`, root ownership, no device-special
identity, 4096-byte preferred I/O block, and coherent remaining fields; return
zero; retain no user pointer or bytes; and publish one private observation
fact. The application shall consume that value only for silent successful
`test -d /`, and the later profile-specific `pwd` sequence shall require the
fact. Terminal handling shall require and erase the fifth publication, consume
its owner, clear the directory generation, metadata observation, and all
command-time facts, and preserve complete rollback of the affine two-page
stack. Structural and QEMU evidence shall enforce exact predecessor state,
dispatch, complete transfers, pathname and metadata, result, observation and
ownership transitions, prompt and output ordering, erasure, and unchanged
external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-ROOT-DIRECTORY-TEST-001` and `TK-DEC-223`.

The bounded static-process shell-root-directory-condition increment shall
replace the third command with exact
`test -d / && echo root-directory\n`, preserving five publications, six
affine input-owner states, the clean prompt profile, and external prompt
absence. Both profiles shall complete the qualified exact-root metadata
request and consume its complete native value before issuing one x86-64
syscall-1 standard-output request for a complete checked readable 15-byte
candidate containing exact `root-directory\n`. The provider shall require the
exact predecessor and metadata-observation state, stage and compare the entire
candidate before output, publish only those bytes, return 15, erase staging,
retain no user pointer or bytes, and publish one private conditional-output
fact. The later profile-specific `pwd` sequence shall require that fact.
Terminal handling shall require and erase the fifth publication, consume its
owner, clear the directory generation, metadata and conditional-output
observations, and all command-time facts, and preserve complete rollback of
the affine two-page stack. Structural and QEMU evidence shall enforce exact
predecessor state, complete metadata consumption, application-selected output,
candidate extent and value, result, observation and ownership transitions,
prompt and output ordering, erasure, and unchanged external compatibility.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-ROOT-DIRECTORY-CONDITION-001` and `TK-DEC-224`.

The bounded static-process shell-missing-directory-condition increment shall
replace the third command with exact
`test -d /missing || echo missing\n`, preserving five publications, six affine
input-owner states, the clean prompt profile, and external prompt absence. Both
profiles shall issue one exact `AT_FDCWD` metadata request for `/missing\0`
with flags zero and a complete checked writable 144-byte native candidate. The
provider shall validate the exact predecessor, complete pathname, request
selectors, candidate extent, and sealed-root absence before returning exact
`-ENOENT`, leaving the entire candidate unchanged, retaining no user pointer or
bytes, and publishing one private missing-path fact.

After consuming that result, both applications shall select the false edge and
issue one x86-64 syscall-1 standard-output request for a complete checked
readable eight-byte candidate containing exact `missing\n`. The provider shall
require the missing-path fact, stage and compare the entire candidate before
output, publish only those bytes, return eight, erase staging, retain no user
pointer or bytes, and publish one private failed-condition-output fact. The
later profile-specific `pwd` sequence shall require that fact. Terminal
handling shall require and erase the fifth publication, consume its owner,
clear the directory generation, missing-path and failed-condition-output facts,
and all command-time facts, and preserve complete rollback of the affine
two-page stack. Structural and QEMU evidence shall enforce exact negative
lookup, unchanged failed-call output memory, application-selected output,
candidate extent and value, result, observation and ownership transitions,
prompt and output ordering, erasure, and unchanged external compatibility.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-MISSING-DIRECTORY-CONDITION-001` and
`TK-DEC-225`.

The bounded static-process shell-root-glob-enumeration increment shall replace
the third command with exact `echo /*\n`, preserving five publications, six
affine input-owner states, the clean prompt profile, and external prompt
absence. Both profiles shall open exact `/\0` relative to `AT_FDCWD` with
read-only, nonblocking, close-on-exec, directory-only flags as lowest-free
descriptor three. The provider shall retain one immutable sealed-root
description with private position and no host-derived state.

Both applications shall issue x86-64 syscall 217 on descriptor three through a
complete checked writable clean-stack or external-heap candidate and request
the qualified profile count. The provider shall stage and publish exact
coherent 24-byte `.` and `..` directory records, return 48, erase staging, and
advance the private position. A second exact request shall return EOF without
output. The applications shall explicitly close descriptor three; the
provider shall consume the description and free the slot while preserving
private enumeration history.

After consuming EOF and close, both applications shall retain the unmatched
glob and issue one syscall-1 standard-output request for complete exact `/*\n`.
The provider shall validate and stage the entire three-byte candidate before
output, return three, erase staging, retain no user pointer or bytes, and
publish one private glob-output fact. The later profile-specific `pwd` shall
require that fact. Terminal handling shall clear every enumeration,
description, output, and command-time fact and preserve complete rollback of
the affine two-page stack. Structural and QEMU evidence shall enforce exact
open flags and pathname, checked candidates, native records, position, EOF,
explicit close, application-selected output, observation and ownership
transitions, prompt ordering, erasure, and unchanged external compatibility.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-ROOT-GLOB-ENUMERATION-001` and `TK-DEC-226`.

The bounded static-process named-root-glob-match increment shall retain the
five exact commands and the complete qualified root-description lifecycle. It
shall refine sealed root with one immutable `bin` directory child at inode
four and update root's coherent link count to three without granting child
lookup, open, metadata, or enumeration authority.

Both profiles shall receive three exact ordered 24-byte native directory
records for `.`, `..`, and `bin`, with root inode three, child inode four,
offsets one through three, directory type, exact terminated names, and zero
padding. The provider shall return 72, erase private staging, advance the
description, return EOF on the second qualified request, and require explicit
close exactly as in the predecessor.

After EOF and close, both applications shall issue one syscall-1
standard-output request for complete exact `/bin\n`. The provider shall
validate and stage the entire five-byte candidate before output, return five,
erase staging, retain no user pointer or bytes, and publish one private
matched-glob fact. The later profile-specific `pwd` shall require that fact.
Terminal handling shall clear every enumeration, description, output, and
command-time fact and preserve complete rollback of the affine two-page stack.
Structural and QEMU evidence shall enforce coherent parent metadata, exact
child identity and records, position, EOF, close, application-selected output,
observation and ownership transitions, prompt ordering, erasure, and unchanged
external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-NAMED-ROOT-GLOB-MATCH-001` and `TK-DEC-227`.

The bounded static-process named-root-directory-condition increment shall
replace the third publication with exact
`echo /*; test -d /bin && echo bin-directory\n`. Both profiles shall first
complete the qualified root enumeration, close, and `/bin\n` output. They shall
then issue x86-64 syscall 262 for exact `/bin\0` relative to `AT_FDCWD`, zero
flags, and a complete checked 144-byte clean-stack or external-heap candidate.

The provider shall publish complete deterministic inode-four directory
metadata with link count two, mode `0755`, root ownership, zero size and times,
and 4,096-byte preferred transfer size. It shall verify the complete copy,
return zero, erase staging, retain no pointer or bytes, and publish one private
ordered metadata fact. After consuming it, both applications shall issue one
syscall-1 request for exact `bin-directory\n`; the provider shall validate and
stage all 14 bytes, publish them, return 14, erase staging, and record one
private condition-output fact.

The later prompt and profile-specific `pwd` shall require the named condition.
Terminal handling shall clear every child-metadata, enumeration, description,
output, and command-time fact and preserve complete rollback. Structural and
QEMU evidence shall enforce the combined 44-byte command, predecessor match,
exact lookup and metadata, application-selected output, ordered observations,
candidate and staging erasure, prompt distinction, and unchanged external
compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-NAMED-ROOT-DIRECTORY-CONDITION-001` and
`TK-DEC-228`.

The bounded static-process empty-bin-glob-enumeration increment shall replace
the third publication with exact
`echo /*; test -d /bin && echo /bin/*\n`. Both profiles shall first complete
the qualified root enumeration, `/bin\n` output, and complete named-child
metadata lookup. They shall then issue x86-64 syscall 257 for exact `/bin/\0`
relative to `AT_FDCWD`, flags `0x90800`, mode zero, and result three.

The provider shall bind descriptor three to one immutable inode-four directory
description at position zero and publish its complete qualified metadata on
syscall 5. It shall accept one syscall-217 request, stage coherent ordered
24-byte `.` and `..` records for inode four and parent inode three, copy and
verify all 48 bytes to a complete checked clean-stack or external-heap
candidate, erase staging, advance position, and return 48. A following request
shall return EOF with the candidate unchanged, and syscall 3 shall explicitly
consume the description.

After EOF and close, both applications shall issue one syscall-1 request for
exact `/bin/*\n`; the provider shall validate and stage all seven bytes,
publish them, return seven, erase staging, and record one private empty-bin-glob
output fact. The later prompt and profile-specific `pwd` shall require that
fact. Terminal handling shall clear every child-metadata, enumeration,
description, output, and command-time fact and preserve complete rollback.
Structural and QEMU evidence shall enforce the combined 37-byte command,
predecessor match and metadata, exact child open, metadata, records, EOF and
close, application-selected output, ordered observations, candidate and
staging erasure, prompt distinction, and unchanged external compatibility.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-EMPTY-BIN-GLOB-ENUMERATION-001` and
`TK-DEC-229`.

The bounded static-process bin-busybox-glob-match increment shall retain the
five qualified publications and exact third command
`echo /*; test -d /bin && echo /bin/*\n`. Both profiles shall first complete
the qualified root enumeration, `/bin\n` output, named-child metadata lookup,
exact `/bin/` open, and descriptor metadata query.

The provider shall add exactly one immutable inode-five regular-file `busybox`
entry beneath inode four. For the qualified syscall-217 request it shall stage
coherent ordered 24-byte `.` and `..` records followed by one aligned 32-byte
`busybox` record with next offset three and `DT_REG=8`; copy and verify all 80
bytes to the complete checked clean-stack or external-heap candidate; erase
staging; advance position; and return 80. A following request shall return EOF
with the candidate unchanged, and syscall 3 shall explicitly consume the
description. The entry identity shall grant no lookup, metadata, content, open,
or execution authority.

After EOF and close, both applications shall issue one syscall-1 request for
exact `/bin/busybox\n`; the provider shall validate and stage all thirteen
bytes, publish them, return thirteen, erase staging, and record one private
bin-busybox-glob output fact. The later prompt and profile-specific `pwd` shall
require that fact. Terminal handling shall clear every child-metadata,
enumeration, description, output, and command-time fact and preserve complete
rollback. Structural and QEMU evidence shall enforce the unchanged 37-byte
command, predecessor match and metadata, exact child-directory open, coherent
three-record transfer, EOF and close, application-selected matched output,
ordered observations, candidate and staging erasure, prompt distinction, and
unchanged external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-GLOB-MATCH-001` and `TK-DEC-230`.

The bounded static-process bin-busybox-file-condition increment shall replace
the third publication with the exact 80-byte command
`echo /*; test -d /bin && echo /bin/*; test -f /bin/busybox && echo busybox-file\n`.
Both profiles shall first complete all qualified root and child enumeration,
metadata, close, and output transitions.

They shall then issue x86-64 syscall 262 for exact `/bin/busybox\0` relative
to `AT_FDCWD`, flags zero, and a complete checked 144-byte clean-stack or
external-heap candidate. The provider shall publish immutable inode-five
regular-file metadata with link count one, mode `0555`, root ownership, zero
size, blocks and times, and 4,096-byte preferred transfer size. It shall verify
the complete copy, return zero, erase staging, and record one private ordered
file-metadata fact.

After consuming that fact, both applications shall issue one syscall-1 request
for exact `busybox-file\n`; the provider shall validate and stage all thirteen
bytes, publish them, return thirteen, erase staging, and record one private
file-condition output fact. The later prompt and profile-specific `pwd` shall
require that fact. Terminal handling shall clear every file-metadata,
enumeration, description, output, and command-time fact and preserve complete
rollback. Structural and QEMU evidence shall enforce the complete 80-byte
command, predecessor enumeration and output, exact lookup and metadata,
application-selected output, ordered observations, candidate and staging
erasure, prompt distinction, and unchanged external compatibility. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-FILE-CONDITION-001` and
`TK-DEC-231`.

The bounded shell profile may extend the same third publication to the exact
129-byte command ending in
`test -x /bin/busybox && echo busybox-executable\n`. Both clean and pinned
external profiles shall first complete the qualified regular-file metadata and
`busybox-file\n` output transitions. They shall then repeat x86-64 syscall 262
with `AT_FDCWD=-100`, exact `/bin/busybox\0`, the complete 144-byte candidate,
and flags zero, followed by syscall 107 with no arguments. The provider shall
republish the identical immutable inode-five mode `0555`, require all ordered
predecessor facts, return effective UID zero, and record private repeated-
metadata and credential facts.

After consuming that fact, both applications shall issue one syscall-1 request
for exact `busybox-executable\n`; the provider shall validate and stage all
nineteen bytes, publish them, return nineteen, erase staging, and record one
private executable-condition output fact. The later prompt and profile-specific
`pwd` shall require that fact. Terminal handling shall clear every access,
metadata, enumeration, description, output, and command-time fact and preserve
complete rollback. Structural and QEMU evidence shall enforce the complete
129-byte command, exact repeated metadata and credential requests,
application-selected output, ordered observations, staging erasure, prompt
distinction, and unchanged external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-EXECUTABLE-CONDITION-001` and
`TK-DEC-232`.

The bounded shell profile may extend the same third publication to the exact
176-byte command ending in
`test -s /bin/busybox && echo busybox-nonempty\n`. For this extended profile,
every inode-five metadata publication shall replace the predecessor's zero
size and blocks with size 2,024,544 and block count 3,955, bound to the complete
digest-checked static-user boot resource. All other metadata and every ordered
predecessor transition shall remain unchanged.

After `busybox-executable\n`, both profiles shall repeat x86-64 syscall 262
with `AT_FDCWD=-100`, exact `/bin/busybox\0`, the complete 144-byte candidate,
and flags zero. The provider shall require the executable-condition output and
all predecessor facts, republish the identical artifact-bound metadata, return
zero, and record one private repeated nonempty-metadata fact.

After consuming that fact, both applications shall issue one syscall-1 request
for exact `busybox-nonempty\n`; the provider shall validate and stage all
seventeen bytes, publish them, return seventeen, erase staging, and record one
private nonempty-condition output fact. The later prompt and profile-specific
`pwd` shall require that fact. Terminal handling shall clear both new facts and
every predecessor fact with complete rollback. Structural and QEMU evidence
shall enforce the complete 176-byte command, artifact-bound size, exact
repeated metadata request, application-selected output, observation ordering,
staging erasure, prompt distinction, and unchanged external compatibility.
This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-NONEMPTY-CONDITION-001` and
`TK-DEC-233`.

The bounded shell profile may extend the same third publication to the exact
216-byte command ending in
`exec 3</bin/busybox; echo busybox-open\n`. After every predecessor fact and
`busybox-nonempty\n`, both profiles shall issue x86-64 syscall 257 with
`AT_FDCWD=-100`, exact `/bin/busybox\0`, flags zero, and mode zero. The
provider shall validate the complete readable pathname, artifact-bound
inode-five identity, command owner, live process, and absence of a live
nonstandard description before binding lowest-free descriptor three to one
immutable read-only description at offset zero and returning three.

After the successful open, both applications shall issue one syscall-1
request for exact `busybox-open\n`; the provider shall validate and stage all
thirteen bytes, publish them, return thirteen, erase staging, and record one
private read-only-open output fact. The later prompt and profile-specific
`pwd` shall require that fact while descriptor three remains live. Terminal
handling shall prove and revoke the description, clear the new output fact
and every predecessor fact, and preserve complete rollback. Structural and
QEMU evidence shall enforce the complete 216-byte command, exact open
arguments and result, artifact identity, application-selected output,
description lifetime, observation ordering, staging erasure, prompt
distinction, and unchanged external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-READ-ONLY-OPEN-001` and
`TK-DEC-234`.

The bounded shell profile may extend the same third publication to the exact
263-byte command ending in
`echo busybox-open; IFS= read -r -n 4 -u 3 _ && echo busybox-read\n`.
After every predecessor fact and `busybox-open\n`, the clean profile shall
issue four direct x86-64 syscall-0 requests. The external profile shall first
issue syscall 16 twice with `TCGETS=0x5401` and once with `TCSETS=0x5402` on
descriptor three and its complete observed stack candidate; each shall return
`-ENOTTY`. Before every external read, syscall 7 shall receive one exact
eight-byte descriptor-three `POLLIN` entry, `nfds=1`, and timeout `-1`; shall
validate first-use zero or retained `POLLIN` in `revents`; shall publish
`POLLIN`; shall return one; and shall authorize only the next read.

Both profiles shall issue four ordered syscall-0 requests on descriptor three,
each with count one and the next byte of one complete writable candidate. The
provider shall validate the live immutable artifact-bound description,
current offset, sealed continuation, complete candidate, hierarchy, stack,
dispositions, command owner, exact profile-specific terminal-probe count, and
readiness state before returning exact bytes `0x7f`, `E`, `L`, and `F` through
private kernel staging, reading back each publication, erasing staging,
consuming any external readiness fact, and advancing the description from
offset zero to four. It shall retain no user pointer.

After the fourth successful read, the external profile shall issue one
`TCGETS` and one `TCSETS` request with the same checked `-ENOTTY` result.
Both applications shall then issue one syscall-1 request for exact
`busybox-read\n`; the provider shall validate and stage all thirteen bytes,
publish them, return thirteen, erase staging, and record one private
header-read output fact. The later prompt and profile-specific `pwd` shall
require that fact while descriptor three remains live at offset four.
Terminal handling shall prove and revoke the description, offset,
terminal-probe counter, and pending-readiness fact; clear the new output fact
and every predecessor fact; and preserve complete rollback. Structural and
QEMU evidence shall enforce the complete 263-byte command, exact
profile-specific terminal probes and readiness calls, four exact read arguments,
results and bytes, artifact identity, offset progression, application-selected
output, description lifetime, observation ordering, staging erasure, prompt
distinction, and unchanged external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-HEADER-READ-001` and
`TK-DEC-235`.

The bounded shell profile may extend the same third publication to the exact
294-byte command ending in
`echo busybox-read; exec 3<&-; echo busybox-close\n`. After every predecessor
fact and `busybox-read\n`, both profiles shall issue syscall 72 with descriptor
three, `F_DUPFD_CLOEXEC=0x406`, and minimum ten. The provider shall validate
the live artifact-bound description at offset four, exact command and minimum,
absence of a saved mapping, sealed continuation, hierarchy, stack,
dispositions, and command owner before binding lowest-available descriptor ten
to the same description, marking only that mapping close-on-exec, and returning
ten.

Both profiles shall then issue syscall 3 on descriptor three and syscall 3 on
descriptor ten. The first shall return zero, remove descriptor three, and
retain the immutable description and offset through descriptor ten. The second
shall return zero, remove descriptor ten, destroy the last description
reference, and revoke the offset, ordered terminal-probe counter, and readiness
state. After the second close, both applications shall issue one syscall-1
request for exact `busybox-close\n`; the provider shall validate and stage all
fourteen bytes, publish them, return fourteen, erase staging, and record one
private explicit-close output fact.

The later prompt and profile-specific `pwd` shall require the output fact and
absence of both nonstandard mappings and their description. Terminal handling
shall prove and clear the redirection and output facts with every predecessor
fact without revoking the destroyed description again, and shall preserve
complete rollback. Structural and QEMU evidence shall enforce the complete
294-byte command, exact duplicate arguments and result, shared-description
identity and offset, ordered closes and results, last-close destruction,
application-selected output, observation ordering, staging erasure, prompt
distinction, and unchanged external compatibility. This realizes
`TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-EXPLICIT-CLOSE-001` and
`TK-DEC-236`.

The bounded shell profile may retain the exact 294-byte third publication and
replace the fourth publication with exact `exec 3</bin/busybox;pwd\n`. After
every predecessor fact, `busybox-close\n`, and the profile-specific
following-prompt observation, both profiles shall issue syscall 257 with
`AT_FDCWD=-100`, exact `/bin/busybox`, flags zero, and mode zero. The provider
shall require the old descriptor-three and descriptor-ten mappings
and their description to be absent; validate the live process, sealed
continuation, hierarchy, stack, dispositions, command owner, full immutable
pathname, and artifact identity; then reuse lowest descriptor three for a
distinct immutable read-only description generation at offset zero and return
three. No old offset, mapping, close-on-exec flag, terminal-probe counter,
readiness fact, or description identity may survive into the new generation.

After the reopen, both applications shall execute the `pwd` segment in the
same publication. Its profile-specific pathname and output flow and the later
prompt shall require exactly the new descriptor-three description at offset
zero; no synthetic reopen-confirmation output shall be added.
Terminal handling shall prove and revoke the reopened mapping and description
exactly once, clear its generation, rights, offset, command-time facts, and every
predecessor fact without reviving or revoking the destroyed generation again,
and preserve complete rollback. Structural and QEMU evidence shall enforce the
exact 294-byte third and 24-byte fourth publications, old-generation absence,
exact second-open arguments and result, lowest-slot reuse, distinct description
generation, fresh offset and clean auxiliary state, the external profile's
resulting complete 144-byte console-stat candidate at exact `0x007f_f240` and
following complete 36-byte `TCGETS` candidate at exact `0x007f_f1a0`,
application-selected continuation into `pwd`,
observation ordering, prompt distinction, and unchanged external compatibility.
This realizes `TOPAL-SYSTEMS-STATIC-ELF-SHELL-BIN-BUSYBOX-REOPEN-001` and
`TK-DEC-237`.

The bounded static-process shell may preserve the first four reopen-profile
publications and replace its terminal publication with exact
`exec /bin/busybox true\n`, returning 23 from the final input read. Both
profiles shall then admit exactly one syscall-59 process-image replacement for
the same sealed `/bin/busybox` artifact. The provider shall completely validate
the exact pathname, argument vector `[/bin/busybox, true]`, ordered environment
strings `SHLVL=1`, `OLDPWD=/`, `PATH=/sbin:/usr/sbin:/bin:/usr/bin`, and `PWD=/`, all null
terminators and extents, live process state, artifact identity, hierarchy,
stack, dispositions, command owner, and replacement resources without retaining
user pointers.

Success shall not return. It shall consume the shell image generation while
preserving PID one, root credentials, sealed root current directory, standard
descriptions, and the reopened non-close-on-exec descriptor three. It shall
reset caught dispositions, FS/thread registrations, command state, old random
delivery, stack, heap, mutable image state, and replacement-sensitive mapping
permissions; restore the exact sealed ELF file bytes and zero-fill; construct a
fresh exact initial stack, auxiliary vector, and random generation; and enter
the same artifact at its validated entry as BusyBox `true`. The replacement
application shall traverse its ordinary startup sequence and terminate with
`exit_group(0)`. Terminal handling shall revoke the inherited description and
all fresh image resources exactly once and complete the existing affine
rollback. Structural and clean plus pinned-external QEMU evidence shall enforce
validation-before-consumption, nonreturn, generation distinction, reset state,
descriptor inheritance, startup, termination, cleanup, and rollback. This
realizes `TOPAL-SYSTEMS-STATIC-ELF-SHELL-BUSYBOX-TRUE-EXECVE-001` and
`TK-DEC-238`.

The reusable static-process realization shall replace exact later-argument
comparison with checked runtime transport of one through eight arguments and
at most 256 aggregate bytes including terminators. It shall enforce complete
path/vector/string/environment bounds and the declared Linux input errors,
erase private staging on every rejected prefix, preserve the original owner
until commit, and construct a fresh aligned ABI stack from the copied values.
Startup stack destinations and credential facts shall derive from complete
mapping extents and the new auxiliary-vector identity. Console write shall
stage caller-selected standard-output/error bytes with zero-length, descriptor,
size and access behavior matching the formal rule; it shall not compare output
with qualification payloads. Terminal cleanup shall retain the low eight status
bits and reclaim the same resources for every application status. Final shell
refill shall observe bounded serial input rather than fabricate a compiled exec
command, with the later probe input remaining a distinct observation.

Compiler and physical qualification shall cover runtime payload variation,
empty and maximum-sized arguments, count/aggregate overflow, inaccessible and
unterminated candidates, nonempty failed prefixes and retry on the unchanged
owner, fresh image state, descriptor inheritance, staged output/error atomicity,
register restoration, statuses zero/one, and full rollback. The external corpus
shall execute pinned BusyBox `true`, `false` and multi-argument `echo` through
the same services. This realizes `TK-DEC-239` and
`TOPAL-SYSTEMS-STATIC-PROCESS-EXEC-ARGUMENTS-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-EXEC-STACK-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-CONSOLE-WRITE-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-EXIT-STATUS-001`, and
`TOPAL-SYSTEMS-STATIC-PROCESS-COMMAND-INPUT-001`.

The reusable file-description realization shall implement `TK-DEC-240` and
`TOPAL-SYSTEMS-STATIC-PROCESS-FD-TABLE-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-FD-READ-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-FD-SEEK-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-FD-METADATA-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-FD-DUPLICATION-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-FD-FLAGS-001`, and
`TOPAL-SYSTEMS-STATIC-PROCESS-FD-CLOSE-001`
with a separately owned bounded table, shared description state, immutable
boot-member borrowing and checked native adapters. It shall enforce the
slot/reference-count invariant, lowest-slot allocation and native flag/error
behavior; preserve source and target on rejected operations; use complete live
writable/readable extent checks and private staging for file data/metadata;
preserve eligible aliases and positions across exec; and reclaim/wipe all
description state before outer rollback. Table construction shall consume the
predecessor single-description authority. Native file bytes shall remain
independent of process-writable image data. Clean and physical qualification
shall cover aliasing, replacement, flags, failed copies, offsets/EOF, exec
filtering, descriptor reuse and application-selected file consumption without
applet, payload or return-site oracles. Native table/backing arguments and
integer/layout choices shall remain closed provider details.

The reusable signal realization shall implement `TK-DEC-241`,
`TOPAL-SYSTEMS-STATIC-PROCESS-SIGNAL-ACTION-001` and
`TOPAL-SYSTEMS-STATIC-PROCESS-SIGNAL-MASK-001` with process-owned actions and
blocked state. It shall import and consume predecessor authority, stage
overlapping copies, enforce native validation order and normalization, retain
valid updates after old-value output faults, reset action metadata on exec
while retaining ignored handlers and blocked state, and erase all terminal
state. Clean tests shall cover these boundaries before external application
qualification. Registration shall treat handler/restorer values as opaque ABI
data and shall not establish delivery, frames or return semantics.

The read-only namespace realization shall implement `TK-DEC-242` and
`TOPAL-SYSTEMS-STATIC-PROCESS-PATH-{COPY,LOOKUP,OPEN,METADATA}-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-DIRECTORY-READ-001` and
`TOPAL-SYSTEMS-STATIC-PROCESS-CWD-001`. It shall retain immutable object and cwd
identities, use disjoint checked/erased pathname storage, enforce native copy/
allocation/lookup ordering, publish independent open descriptions atomically,
and make metadata, records and reads coherent. Clean executed cases shall cover
name boundaries, relative authority, errors, exhaustion, aliases/independent
positions and cookies, cwd/exec lifetime and erasure. External named-file and
directory consumers shall share these services; the existing corpus remains a
regression. Unqualified modes shall fail closed. Native encodings stay private.

The realtime-seconds realization shall implement `TK-DEC-243` and
`TOPAL-SYSTEMS-STATIC-PROCESS-REALTIME-SECONDS-001` with exclusive platform
acquisition, coherent/validated calendar samples, checked epoch conversion,
optional complete native output and erased staging. It shall qualify calendar
boundaries, actual declared RTC dates, return/output equality, null/bad outputs,
native registers, external directory-consumer setup and complete rollback.
Hardware ports and representations shall remain closed provider details.

The reusable prepared-root adapter shall realize `TK-DEC-244` and
`TOPAL-SYSTEMS-STATIC-PROCESS-ROOT-CREDENTIALS-001` using an imported private
identity witness, independent queries and idempotent root selections, preserved
native registers and exec identity, and complete terminal erasure. It shall
qualify repeated/reordered calls, native widths and metadata independence,
without using user-writable auxiliary data as authority or admitting other
identity changes.

The runtime-environment realization shall implement `TK-DEC-245`,
`TOPAL-SYSTEMS-STATIC-PROCESS-EXEC-ENVIRONMENT-001` and
`TOPAL-SYSTEMS-STATIC-PROCESS-EXEC-PAYLOAD-001`. It shall copy caller environments
into disjoint owned staging, preserve empty/null/duplicate data and arbitrary
argv[0], enforce declared vector/byte/copy errors, preserve pre-commit state and
erase every failed prefix. It shall derive vectors and above-RSP payloads from
copied counts/offsets, separate execution name from argv-zero data, preserve
generation-specific auxiliary/random facts and consume all staging before
entry. Executed cases shall cover limits, failed-prefix retry, pointer/value
transport, downward-stack writes, changed cwd/exported environments and full
reclamation. Native bounds/layout remain closed systems-provider details.

The repeated-exec adapter shall implement `TK-DEC-246` and
`TOPAL-SYSTEMS-STATIC-PROCESS-EXEC-REPEAT-001`. It shall validate the current
qualified generation independently of the original command phase, retain the
pristine executable authority, copy before every commit and repeat descriptor
filtering, signal reset, backing erasure/revocation and fresh stack/random
construction. Errors shall preserve the current generation; final cleanup
shall reclaim retained resources once. Executed repeated-entry and inherited
state witnesses shall cover later-generation failed retries and full rollback.
The complete backing precondition shall remain explicit until independently
broadened; no fixed replacement count shall authorize execution.

The deadline-entry correction shall implement `TK-DEC-248` and
`TOPAL-SYSTEMS-DEADLINE-EVENT-001` by filtering a completed event's raw target
notification before source dispatch. It shall acknowledge that notification
without repeating completion/preemption, restore the exact interrupted register
and frame image, and close the source/controller route on accepted completion.
Qualification shall inject a queued completed-event notification at worker
resumption, reject the predecessor behavior and complete ordinary context and
application/resource regressions. Native vectors and MMIO remain private.

The reusable process-observation adapter shall implement `TK-DEC-247`,
`TOPAL-SYSTEMS-STATIC-PROCESS-IDENTITY-001` and
`TOPAL-SYSTEMS-STATIC-PROCESS-UNAME-001`. It shall import the prepared process
identity privately, observe PID/TID/parent repeatedly without altering call
phase, and publish the selected immutable guest system record only after a
complete checked writable extent. It shall preserve non-result registers,
ignore unused arguments, retain no caller pointer and preserve identity across
exec and complete terminal erasure. Executed cases shall cover native bytes,
reordering, faults, replacement shells and full rollback. Native record and
selector details shall remain provider-owned.

The immutable boot-root open-access adapter shall implement `TK-DEC-249` and
`TOPAL-SYSTEMS-STATIC-PROCESS-PATH-OPEN-ACCESS-001`. It shall decode ordinary
access modes with qualified modifiers, preserve complete name-copy/allocation/
lookup/type/access ordering and retain the prepared read-only filesystem view.
Failed write-intent requests shall publish no handle, preserve process state
and erase private name copies. Executed cases shall cover native widths,
lookup/type/readonly and exhaustion errors, repeated inherited state, an
interactive replacement shell and full rollback. No native flags or user
command/prompt data shall grant writable authority or select kernel policy.

The bounded initial-output adapter shall accept Linux x86-64 `write` only for
descriptor one, an executable return continuation, a length of 1–256, and a
complete overflow-free candidate inside the provider's readable user mapping
set. It shall reject invalid requests before dereference or UART output, copy a
valid extent completely into fixed private kernel staging, publish exactly the
argument-selected prefix, return the requested count, and preserve the
continuation. It shall contain no exact payload or single-return-site oracle.
Structural and pinned-QEMU evidence shall prove range rejection, dynamic loop
bounds, staging before output, argument-derived return, and deterministic
execution of the existing 26-byte application witness.

The bounded initial-input adapter shall accept Linux x86-64 `read` only for
descriptor zero, an executable return continuation, a length of 1–256, and a
complete overflow-free candidate inside the provider's writable user mapping
set. It shall reject invalid requests before polling or user access, receive
exactly the requested bounded count into fixed private kernel staging, perform
a fault-contained copy of the complete staged prefix, return the requested
count, and preserve the continuation. It shall contain no exact input-value,
candidate, or single-return-site oracle. User code shall validate the
deterministic four-byte qualification input before stack disposal. Structural
and pinned-QEMU evidence shall prove range rejection, dynamic receive and copy
bounds, complete staging before user publication, argument-derived return, and
the ordered post-return witness.

The bounded initial-heap adapter shall lower Linux x86-64 syscall 12 only for a
live initial context and a return continuation inside the finalized executable
mapping. Image construction shall derive the initial break from runtime ELF
`p_memsz`, prove it lies inside the 4096-byte data page, zero the complete tail
from runtime `p_filesz` through the page end, and publish the break only after
successful construction. Dispatch shall keep current state provider-private,
return it for a zero query or unsupported request, and replace it only with an
in-range byte-granular request. Teardown shall clear it. Structural and pinned-
QEMU evidence shall prove runtime derivation, complete zeroing, query, grow,
write/read, shrink, rejected growth, exact returns, and state clearing.

The initial scalar-identity adapter shall lower Linux x86-64 syscall numbers
39, 102, 104, 107, 108, 110, and 186 only for a live initial context and a
return continuation inside the finalized executable mapping. It shall return
PID/TID one, parent PID zero, and real/effective UID/GID zero exactly as the
checked disposition declares and shall introduce no user-copy or retained
state. Structural and pinned-QEMU evidence shall prove every dispatch number,
broad executable-return validation, constant coherence, application result
checks, and terminal continuation.

The initial x86-64 stack adapter shall place native `AT_SECURE` with value zero
after the program-header facts and before the unique `AT_NULL`. It shall shift
the bounded block without changing the `argv[0]`/`AT_EXECFN` string alias.
Constructed code shall validate the pair, terminator, and exact enlarged block
consumption. Structural and pinned-QEMU evidence shall prove placement, value,
alias identity, stack alignment, and continued application execution.

The adapter shall place native `AT_CLKTCK` with value 100 after `AT_SECURE` and
before the unique `AT_NULL`, shift the bounded block while keeping the
executable-name string address fixed, and validate the pair, moved terminator,
and exact enlarged consumption in constructed code. Structural and pinned-QEMU
evidence shall prove order, value, fixed aliasing, alignment, and continuation.

The adapter shall place native `AT_PLATFORM` after `AT_CLKTCK` and before
`AT_NULL`, pointing to a distinct in-block NUL-terminated `x86_64` string while
keeping the executable-name address fixed. Constructed code shall validate the
tag, exact pointer, all bytes, terminator, alias separation, moved `AT_NULL`,
and exact enlarged consumption. Structural and pinned-QEMU evidence shall prove
the complete pointer-bearing fact and continued execution.

The initial x86-64 FS-base adapter shall lower syscall 158 only for operation
codes `0x1002` and `0x1003`, a live initial context, and a return continuation
inside the finalized executable mapping. `ARCH_SET_FS` shall validate zero or
a canonical base within the readable user mapping set, retain it privately,
install it for user return, and return zero. `ARCH_GET_FS` shall copy the same
private value to a validated writable eight-byte user extent under fault
recovery and return zero. Invalid base, destination, and operation paths shall
return Linux-compatible errors without changing retained state, and data-role
teardown shall clear it. Structural and pinned-QEMU evidence shall prove the
set/get/restore sequence, result and word checks, provider installation, fault-
contained output, and state clearing.

The initial clear-child-TID adapter shall lower Linux x86-64 syscall 218 only
for a live initial context and a return continuation inside the finalized
executable mapping. It shall accept null or one complete writable four-byte
candidate, retain it privately, and return TID one without dereference. The
terminal `exit_group(0)` path shall fault-contain a zero store to a nonnull
candidate and clear private state before publishing terminal lifecycle state.
Structural and pinned-QEMU evidence shall prove registration, exact return,
terminal store/clear ordering, and no retained state at data teardown.

The initial empty robust-list adapter shall lower Linux x86-64 syscall 273 only
for a live initial context, finalized executable return continuation, exact
length 24, and a complete readable 24-byte candidate. Registration shall
retain the candidate privately without access and return zero. Terminal exit
shall fault-contain a complete 24-byte copy, require the native list link to be
self-referential and the pending pointer null, and clear state before terminal
publication. Structural and pinned-QEMU evidence shall prove registration,
terminal copy and checks, state clearing, and teardown rejection.

The initial stack-limit adapter shall lower Linux x86-64 syscalls 97 and 302
only for a live initial context and finalized executable return continuation.
It shall accept selector 3; `prlimit64` shall additionally require PID zero or
one and a null new-limit pointer. Both shall validate a complete writable 16-
byte output extent, copy the native 8 MiB/`RLIM_INFINITY` pair under fault
recovery, retain no pointer, and return zero. Structural and pinned-QEMU
evidence shall prove both dispatch forms, argument rejection, shared complete
copy, exact application values, and results.

The initial signal-mask adapter shall lower Linux x86-64 syscall 14 only for a
live initial context and finalized executable return continuation. It shall
require native set size eight, stage a complete optional input word, remove
signal bits 8 and 18, apply query/block/unblock/replacement to one private word,
and optionally publish the complete prior word after update, with every user
transfer fault contained. It shall clear state during teardown. Structural and
pinned-QEMU evidence shall prove all operations, null candidates, exact values,
unblockable-bit removal, error checks, update-before-output ordering, and state
clearing.

The bounded runtime anonymous-page adapter shall lower one source-owned
single-frame reservation to a non-present provider-selected x86-64 user PTE.
Linux x86-64 syscall 9 shall admit only the bounded null-address, one-page-or-
smaller, RW, private-anonymous, descriptor-minus-one, zero-offset shape, zero
the complete frame before ordered RW/NX publication, and return the selected
address. Syscall 11 shall revoke that exact page with ordered invalidation and
succeed when it is already absent. Repeated generations shall remain
exclusive; terminal completion shall revoke an active page; source release
shall return the exact frame. Structural and pinned-QEMU evidence shall prove
absence before activation, complete zeroing, publication, direct access,
revocation, re-zeroed reuse, terminal state, and exact backing return.

The bounded anonymous-protection adapter shall dispatch Linux x86-64 syscall
10 only for the exact live anonymous page, a nonzero one-page-or-smaller range,
and `PROT_NONE`, `PROT_READ`, or `PROT_READ | PROT_WRITE`. It shall preserve
the active generation and backing contents while replacing the PTE with a
non-present, R/NX, or RW/NX state, perform ordered invalidation before return,
and retain private state sufficient for `munmap` and terminal cleanup from
every protection. Rejected requests shall preserve the prior PTE and state.
Structural and pinned-QEMU evidence shall prove every admitted transition,
retained contents across inaccessible state, active-map rejection while none,
revocation from a protected state, and non-executable publication.

The bounded anonymous-advice adapter shall dispatch Linux x86-64 syscall 28
only for the exact live anonymous page, a nonzero one-page-or-smaller range,
and `MADV_DONTNEED`. It shall zero the complete backing through kernel
authority while preserving the active generation and private none, read-only,
or read-write NX state. Rejected requests shall preserve prior bytes and state.
Structural and pinned-QEMU evidence shall prove advice while inaccessible,
overlapping-map rejection, restored full zero observation, later mutation, and
unchanged protection semantics.

The bounded userspace-clock adapter shall dispatch Linux x86-64 syscall 228
only for `CLOCK_MONOTONIC`, a live initial context, an executable return, and a
complete writable 16-byte candidate. It shall sample the qualified 64-bit Q35
HPET source once, validate its 10 ns period, normalize ticks to native seconds
and nanoseconds, and copy the complete staged pair under page-fault recovery.
Structural and pinned-QEMU evidence shall prove two calls, normalized fields,
nondecreasing order, exact zero results, private target details, and balanced
temporary storage.

The bounded userspace-resolution adapter shall dispatch Linux x86-64 syscall
229 only for `CLOCK_MONOTONIC` and an optional complete writable 16-byte
candidate. It shall return zero for null output, otherwise publish the native
zero-second/ten-nanosecond pair under page-fault recovery, retain no pointer,
and agree with the qualified HPET conversion. Structural and pinned-QEMU
evidence shall prove exact output, null-output success, and balanced storage.

The initial userspace syscall adapter shall return x86-64 Linux `-ENOSYS` for
every number not selected by an implemented dispatch arm. The fallback shall
return through the retained executable continuation without inspecting unused
arguments or changing state. Structural and pinned-QEMU evidence shall prove
one deliberate unsupported call, its exact result, and a later successful
implemented call.

The static-process provider shall realize `TOPAL-SYSTEMS-STATIC-PROCESS-CHILD-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-CHILD-WAIT-001` and
`TOPAL-SYSTEMS-STATIC-PROCESS-THREAD-REGISTRATION-001`: exclusive child/snapshot
storage, complete private parent restoration, copied slots/shared descriptions,
fork-like native creation, reusable opaque thread registrations, child exec/exit
and once-only checked wait publication. Actual mapping/backing, native register,
TLS/extended-state, boundary/failure and unmodified shell evidence shall qualify
the serialized finite-child profile without claiming general scheduling.

The resumable static pair shall implement owned native yield/handoff and
blocking child wait under `TK-DEC-255` and
`TOPAL-SYSTEMS-STATIC-PROCESS-PAIR-001`. It shall exchange complete private
process state without suspending a live kernel continuation, preserve shared
service histories, retain either process's descriptions across snapshot release,
exclude a waiting parent from runnable selection, validate status publication
in the restored parent mapping, and release inactive resources at outer-owner
termination. Independent ABI, state-model, GDB and unchanged-application evidence
shall qualify these boundaries without claiming general scheduling fairness.

The anonymous-pipe service shall implement `TK-DEC-256` and
`TOPAL-SYSTEMS-STATIC-PROCESS-PIPE-001`,
`TOPAL-SYSTEMS-STATIC-PROCESS-PIPE-TRANSFER-001` and
`TOPAL-SYSTEMS-STATIC-PROCESS-PIPE-WAIT-001` with shared owned FIFO
storage excluded from private snapshots, exact endpoint references, native pair
publication and rollback, checked byte transport, atomic-write/partial-transfer
boundaries and condition-bound read/write suspension. Readiness shall follow the
exact FIFO generation and peer lifetime; restored retries shall recheck authority
and current user permissions. Close/exec/child exit/parent termination shall
release endpoints and erase payload/metadata before reuse. Unsupported pipe/signal
profiles shall remain explicit. Independent model, native user/GDB, fault/capacity
and unchanged BusyBox command-substitution evidence shall qualify the result.

The systems publisher shall realize `TOPAL-SYSTEMS-NUMERIC-RUNTIME-001` and
`TOPAL-SYSTEMS-SLEEP-DEADLINE-LIBRARY-001` through ordinary declared-type export
selection, shared numeric algorithms, qualified kernel allocation/fatal hooks,
conservative complete stack/allocation proofs, explicitly borrowed invocation
storage, result conversion, exec retention and complete storage/binding erasure.
It shall reject unsupported or unbounded closure/resource inputs before atomic
publication. Source/runtime frames, arithmetic boundaries, high-water observations,
invalid bounds, wrong-policy rejection and full kernel rollback shall qualify
this profile; measurements alone shall not establish the required bounds.

The systems publisher shall realize `TOPAL-SYSTEMS-SOURCE-LIBRARY-001` and
`TOPAL-SYSTEMS-KERNEL-POLICY-BINDING-001`. It shall load an explicitly selected
relative source-library unit under `--library-root`, or consume an explicit
matching in-memory snapshot, and use the ordinary shared frontend for the public
export and complete reachable helper graph. The first profile shall admit only
Boolean/nominal-Enum pure acyclic direct calls and their local/decision forms,
rejecting unqualified values, effects, allocation, foreign dependencies and
imports before publication. Ordinary function lowering shall emit a separate
freestanding object with source/helper debug information and a private native
interface adapter. No hosted runtime, source assembly, TLS or writable library
data shall be linked. Red-zone/implicit floating-point use shall be disabled,
actual object/stack-size evidence shall prove the complete call-path cost fits
the 1024-byte caller reserve, and missing/dynamic/excess evidence shall fail.
The bound semantic open-policy interface shall normalize private Enum order,
receive only owned-view facts, preserve native ABI/state, retain its scoped
binding across exec and erase it at terminal return. A source choice shall not
grant missing resource rights. Publication shall bind exact source/interface,
instantiation, LLVM/object and stack evidence. Exhaustive finite inputs, guest
source/helper frames, Enum reordering, changed-source counterexamples, missing/
malformed inputs, native boundaries and complete rollback shall qualify it.
A declared import shall never use a fallback on failure; older roots without
this refinement retain their own declared contracts.

Under `TK-DEC-274`, finite/numeric immutable code and closed runtime bindings
shall realize `TOPAL-SYSTEMS-POLICY-LINKED-INPUTS-001`: complete object-owned
code/read-only sections, verified private boundaries, actual relocated-byte
binding and independent boot comparison. Correcting an outer kernel digest
shall not admit altered instructions, literals or tables. Existing source/native
interfaces, resource proofs, caller ownership and cleanup remain mandatory.

Under `TK-DEC-257`, the finite and numeric source-library publishers shall
validate a closed frozen ordinary module snapshot using
`TOPAL-SYSTEMS-SOURCE-MODULES-001`. They shall preserve shared selection,
visibility, overload/type identity and declared numeric export types; reject
imported type declarations and cross-unit nominal values in the initial module
profile; retain nominal adaptation at the finite root; reject
runtime initializers, profile escapes and missing/conflicting/extra dependencies;
include imported calls in existing native, stack and allocation qualification;
and publish exact module bytes plus identity/path/digest provenance. Filesystem
loading shall enforce contained non-symlink dependency trees and the 64-unit,
1-MiB-source and 4096-entry budgets, applying the byte budget to all scanned
source files as well. In-memory publication shall require all
dependency bytes explicitly and perform no ambient discovery. Changed-helper
execution, actual imported frames, malformed snapshots and complete kernel
rollback shall be tested.

The numeric publisher shall realize `TOPAL-SYSTEMS-NUMERIC-RECORDS-001` under
`TK-DEC-258`. It shall reuse ordinary Record construction, static selection,
reconstruction, branch and direct-call lowering; recursively bound every field;
charge actual evaluation without duplicate or omitted base/receiver/replacement
costs; and prove actual aggregate call/spill stack costs within the unchanged
reserves. It shall preserve field-order metadata while permitting an order-free
bound abstraction only for the order-insensitive admitted operations. Isolated
module checking shall construct exact structured argument classifiers without
caller-private declarations. Unsupported payloads, shape changes, reflection,
effects, escape and missing/excessive resource evidence shall reject publication.
Physical structured-helper execution, independent arithmetic, construction-order
variants, malformed/bounded cases and full erasure shall qualify the extension.

Under `TK-DEC-259`, the numeric publisher shall realize
`TOPAL-SYSTEMS-NUMERIC-ARRAYS-001` through shared finite List/Array/Optional
lowering and runtime. It shall retain exact lengths and per-entry bounds, charge
every evaluated operand and actual node/header/wrapper/conversion, preserve
Optional presence across joins and bound reachable branch costs. It shall bind
reviewed collection runtime bytes, restrict the retained helper closure and
include all actual calls in existing stack/allocation limits. Isolated imported
clients shall construct precise collection classifiers. Actual source Array
arguments, independently decoded entries, empty/out-of-bounds and exhaustion
cases, unchanged native arithmetic/state and full erasure shall qualify this
subset without granting persistent storage or native-memory authority.

Under `TK-DEC-260`, the publisher and process adapter shall realize
`TOPAL-SYSTEMS-ELF64-HEADER-LIBRARY-001`: an explicit image-policy source snapshot,
declared Array/Nat/Nat-to-Boolean export, caller-owned immutable input copying,
bounded native facts and checked scalar output. Shared lowering/algorithms,
distinct private symbol namespaces, complete bridge/source resource bounds,
source isolation and exact provenance shall remain required. Header/deadline
policies shall initialize and operate independently or share the exclusive arena
without retaining values across invocations. Exec refusal shall precede
close-on-exec/image/signal/generation commits, erase staging and preserve retained
state. All selected code/arena bindings shall be erased at termination. Actual
source bytes/frames, independent header decoding, controlled copied-byte refusal,
header-only operation, malformed inputs and changed-helper rejection shall
qualify the boundary alongside previous regressions.

Under `TK-DEC-261`, the numeric checker and process adapter shall realize
`TOPAL-SYSTEMS-NUMERIC-ENUMS-001` and
`TOPAL-SYSTEMS-LINUX-DISPATCH-LIBRARY-001`. The declared Nat-to-nominal-Enum
export shall retain full selector bounds and an exact named operation vocabulary,
independent of source tag order. Nominal branch bounds and zero-allocation tag
transport shall preserve ordinary semantics and existing subset exclusions.
The native bridge shall select a bound operation from the actual source result
after context capture/stack switch and before argument inspection or handler
entry. It shall preserve argument/context/SIMD facts, enforce complete independent
or shared policy ownership/bindings, and erase all temporary/terminal state.
No declared-source failure shall fall back to native selector dispatch. Exact
source/module/representation provenance and complete stack/allocation costs shall
qualify native routing, including dispatch-only operation, reordered tags,
unknown/full-width selectors, changed-source rejection and the existing corpus.

The static-process timing adapter shall realize
`TOPAL-SYSTEMS-STATIC-PROCESS-MONOTONIC-001` and
`TOPAL-SYSTEMS-STATIC-PROCESS-RELATIVE-SLEEP-001`. The root shall pass a private
binding to its owned initial clock, and native observations shall reuse the
qualified clock provider's wrap/regression protocol. Binding provenance,
shared history, exec retention, private binding erasure and owner return shall
be checked. Native gettime/getres shall normalize clock IDs, publish complete
checked normalized records, permit null resolution output and erase staging.
Relative nanosleep/clock_nanosleep shall copy and validate complete intervals,
retain pinned ktime conversion/addition saturation, round deadlines upward and
never report success before the resulting same-clock deadline. Normal completion
shall not inspect or modify remaining-time candidates. Invalid input shall
preserve resources/history; successful waits shall preserve every process
resource except legitimate clock observations. Independent physical witnesses
and standard utility runs shall qualify time/interval boundaries, elapsed waits,
native widths, exec lifetime and full rollback. Saturation paths shall receive
explicit arithmetic and controlled execution evidence. Absolute sleeps,
interruption, fairness and broader clocks shall remain separately qualified.

The static-process adapter shall extend that recoverable policy under
`TOPAL-SYSTEMS-STATIC-PROCESS-ENOSYS-001`: implemented dispatch arms shall win,
then unknown low-32-bit native selectors shall return exact `-ENOSYS` through
the existing saved-register-clearing SYSRET path. Unselected ABI-tag selectors
shall not select native implementations. Unused arguments shall not be read or
validated, startup phase and process resources shall remain unchanged, and the
process shall continue before and after exec. Independently encoded physical
witnesses shall check selector boundaries, invalid unused pointers, user-memory
canaries, preserved non-result registers and later implemented calls with full
terminal rollback. This shall add no new implemented syscall or core meaning.

The adapter shall dispatch Linux x86-64 syscall 24 as `sched_yield`, preserve
the sole live user context and all private state, and return zero without a
provider context-transfer operation. Structural and pinned-QEMU evidence shall
prove a dedicated arm, exact result, and continued implemented execution.

## TOPAL-COMP-SYSTEMS-CHECK-001 — Complete systems semantic checking

Before backend lowering, the checked compiler model shall validate special
entry kinds and dispositions, capability provenance, execution contexts,
observation/linearization protocols, address and mapping states, recovery
scopes, atomic and visibility orders, affine critical tokens, context transfer,
device and DMA protocols, storage, placement, and artifact obligations. Every
systems operation shall retain a stable semantic identity and required target
evidence; LLVM spelling shall not enter the checked model.

The first device refinement shall retain one PCI segment/BDF, aligned dword
register offset, expected value, and transaction identity in the checked model.
The checker shall reject out-of-range, misaligned, non-sealed, or unsupported
requests before lowering and shall not infer PCI enumeration or virtio policy.

The bounded virtio-PCI discovery refinement shall accept only the exact
24-transaction source sequence for the pinned function. It shall prove link
order, MSI-X traversal, virtio vendor/type headers, capability lengths, BAR
indices, BAR-relative offsets, region lengths, and the notification multiplier
before lowering. Each operation shall retain its request and monotonically
assigned transaction identity; duplicates, omissions, reordering, alternate
values, and reads outside the sequence shall be rejected.

The PCI region-register refinement shall retain the function, selected
configuration-access capability, BAR index, BAR-relative region, register
offset, width, direction, value, and monotonically assigned transaction
identity. It shall reject overflow, out-of-region access, unsupported widths,
and non-sealed requests. The bounded virtio negotiation shall accept only its
exact 16-operation sequence through confirmed `FEATURES_OK`, leave `DRIVER_OK`
clear for later queue setup, and reject omission, duplication, reordering,
substitution, or a status transition not confirmed by a following read.

The bounded virtio queue-discovery refinement shall accept only the exact five
operations after feature negotiation. It shall retain a distinct ordered
identity, exact two-byte width, and complete request for every queue fact. It
shall reject omissions, duplicates, reordering, substituted values, premature
queue access, and any attempt to derive DMA authority or `DRIVER_OK`.

The bounded PCI command refinement shall accept one masked word update only
after complete queue discovery. It shall retain the exact function, offset,
mask, pre-state, and post-state, reject malformed or substituted requests, and
reject omission or duplication before root completion.

The bounded DMA-buffer refinement shall accept exactly two ordered creation
requests only after bus-master authorization. It shall retain fresh opaque
identities, the pinned device and translation domain, exact size/alignment,
direction, visibility policy, and role; reject malformed, overlapping,
omitted, duplicated, reordered, or substituted requests; and leave both
buffers CPU-owned.

The bounded split-ring refinement shall accept exactly one opaque DMA-reference
binding and four ordered integer stores after both DMA buffers exist. It shall
retain buffer identities, offsets, widths, values, device/domain compatibility,
and CPU ownership; reject malformed, omitted, duplicated, reordered, or
substituted operations; and never materialize a DMA address in source state.

The bounded DMA-preparation refinement shall accept exactly two ordered
ownership transitions after split-ring construction: payload identity two,
then control identity one. It shall retain exact device/domain, direction,
visibility, role, and identity state; reject malformed, omitted, duplicated,
reordered, substituted, premature, or post-transfer CPU operations; and require
provider visibility evidence before each transition completes.

The bounded queue-address refinement shall accept exactly three ordered
PCI-region DMA-reference publications after both preparation transitions. It
shall retain the exact pinned common region, register, reference width,
device/domain, buffer identity, and in-buffer offset; reject malformed,
omitted, duplicated, reordered, substituted, or premature requests; and never
materialize the provider-selected reference in source state.

The bounded virtio queue-activation refinement shall accept exactly four
additional PCI-region transactions after complete queue-address publication.
It shall require queue-enable write/readback followed by `DRIVER_OK`
write/readback, reject malformed, omitted, duplicated, reordered, substituted,
or premature operations, and retain device ownership of both DMA buffers.

The bounded virtio queue-notification refinement shall accept exactly one
additional PCI-region write after verified queue activation. It shall require
the separate configuration-access capability, discovered notification
capability, and exact BAR, region, offset, width, and queue-zero value; reject
malformed, omitted, duplicated, reordered, substituted, or premature
notification; and retain device ownership of both DMA buffers without
fabricating completion.

The bounded virtio completion-signal refinement shall accept exactly one
additional PCI-region read-eventually-equals-one operation after queue
notification. It shall require the separate configuration-access capability,
discovered ISR capability, and exact BAR, region, offset, width,
queue-interrupt bit, and 1,000,000-attempt bound; reject malformed, omitted,
duplicated, reordered, substituted, premature, or unbounded observation; lower
exhaustion to checked failure; and retain device ownership without claiming
used-ring or payload validity.

The bounded virtio used-ring refinement shall accept exactly one control-buffer
DMA completion after the completion signal and exactly four subsequent integer
read-equals operations for used flags, index, descriptor identity, and length.
It shall preserve and validate the exact buffer/device/domain/direction/
visibility/role metadata, lower provider-managed device-to-CPU visibility
before any read, reject malformed or reordered operations, and keep the entropy
payload device-owned and inaccessible.

The bounded virtio payload-completion refinement shall accept exactly one
payload-buffer DMA completion after all four used-ring observations. It shall
validate and preserve the exact buffer/device/domain/direction/visibility/role
metadata, lower provider-managed device-to-CPU visibility before returning
authority, reject malformed or reordered completion, retain the control buffer
as CPU-owned, and emit no payload read or entropy-credit operation.

The bounded entropy-sample refinement shall accept exactly one fresh opaque
sample capture after payload completion. It shall validate sample and buffer
identities, exact offset/count, device/domain/direction/visibility/role facts,
and zero credited bits; preserve payload ownership; lower one complete exact
copy between provider-resolved opaque storage objects; expose no address or
byte value; and reject malformed, partial, duplicated, or reordered capture.

The bounded entropy-quality refinement shall accept exactly one assessment of
the captured raw sample. It shall validate the exact sample/source/evidence
identities, 32-byte extent, 1024/1024 quality, derived 256-bit credit, raw
pre-state, and capture ordering; preserve opaque bytes and affine identity;
model the transition as source-owned kernel policy with no provider operation;
and reject malformed, omitted, duplicated, reordered, substituted, or
premature assessment.

The bounded entropy-pool refinement shall accept exactly one empty-pool
creation after sample assessment. It shall validate pool identity one,
256-bit credit capacity, zero initial credit, and exact ordering; produce one
affine source-owned pool state without emitting provider code or storage; and
reject malformed, omitted, duplicated, reordered, substituted, or premature
creation.

The bounded entropy-mixing refinement shall accept exactly one first-generation
mix after empty-pool creation. It shall validate pool, sample, conditioner, and
contribution identity one; exact 32-byte input; 256-bit contribution; assessed
sample and empty-pool pre-states; and exact ordering. The provider shall
compute BLAKE2s-256 personalized by `TopalRNG`, publish all 32 opaque pool-state
bytes, wipe all 32 sample bytes, and return success only after both actions.
The root shall preserve zero pool credit and the separate affine contribution
token and shall reject malformed, partial, duplicated, reordered, substituted,
or premature mixing.

The bounded entropy-credit refinement shall accept exactly one provider-free
transfer after successful first-generation mixing. It shall validate pool,
contribution, and conditioner-origin identity one; prior credit zero;
transferred credit, capacity, and result 256; the mixed-but-uncredited pool and
live contribution pre-states; exact checked addition; and exact ordering. It
shall preserve opaque pool storage, consume the contribution, record the same
pool as credited, emit no provider operation, and reject malformed, omitted,
duplicated, reordered, substituted, overflowing, reused, or premature
transfer.

The bounded initial-CRNG refinement shall accept exactly one generator
initialization after contribution credit. It shall validate pool, generator,
and algorithm identity one; generation one; 32 key bytes; required and observed
credit 256; the credited-pool pre-state; and exact ordering. The provider shall
copy and verify all 32 opaque pool-state bytes into distinct generator storage,
wipe and verify all 32 consumed pool bytes, and return success only after both
actions. The root shall publish one ready affine generator and reject malformed,
partial, duplicated, reordered, substituted, or premature initialization.

The bounded CRNG-extraction refinement shall accept exactly one extraction
after generator initialization. It shall validate generator and algorithm
identity one; generations one and two; output identity one; a 64-byte block
split at offset 32 into 32 output bytes; zero counter and nonce; the ready
generation-one pre-state; and exact ordering. The provider shall compute the
standard 20-round ChaCha20 block, replace and verify the persistent key before
publishing and verifying opaque output, wipe and verify all temporary state,
and return success only after every action. The root shall publish ready
generation two and one affine output object and reject malformed, partial,
duplicated, reordered, substituted, or premature extraction.

The bounded initial-`AT_RANDOM` refinement shall accept exactly one opaque-
output delivery after extraction and before initial user-context entry. It
shall validate output, address-space, and Linux-interface identity one; source
extent 32; selected offset zero and extent 16; discarded offset 16 and extent
16; auxiliary tag 25; single-use policy; the prepared pre-state; and exact
ordering. The provider shall publish and verify one distinct bounded 16-byte
stack object, wipe and verify all 32 provider-output bytes, and return success
only after every action. The root shall permit entry only from the randomized
entry-ready state and reject malformed, partial, duplicated, reordered,
substituted, reused, or premature delivery.

The bounded initial-`getrandom` refinement shall accept one fresh extraction
from generator generation two to generation three and reserve opaque output
identity two for process, Linux interface, and user-random service identity one
before entry. It shall validate source extent 32, maximum request extent 16,
selected offset zero, discard partition, current Linux supported flag mask 7,
incompatible mask 6, and single-use policy. The x86-64 provider shall privately
map the service to syscall 318, preserve the reservation on zero, argument, and
range failures, copy and verify one successful 1–16-byte prefix, wipe and verify
all output storage, clear private reservation state, and reject partial,
duplicated, reordered, substituted, reused, or premature delivery.

The reusable process-`getrandom` refinement shall accept one checked binding
of generator identity one at generation three and the live initial reservation
into a process-lifetime service. It shall preserve output identity two for the
first success and lower later successes to the same qualified ChaCha20
extraction with key replacement before output publication. The x86-64 provider
shall validate complete arguments and user ranges before later extraction,
return and verify 1–16 bytes, wipe the full output after every success, retain
only the successor generator, and leave state unchanged for zero and rejected
calls. It shall execute two successful calls in ring 3 and wipe the unused
output, generator key, and private service state before process return.

The full-output process-`getrandom` refinement shall accept maximum delivery
extent 32 for both the initial reservation and reusable binding, with selected
offset zero and an empty discard partition. The x86-64 provider shall reject
larger requests before extraction, copy and verify all 32 bytes for the added
full-output call, wipe and verify the complete output, increment delivery state
only after success, and retain no output remainder. The ring-3 probe shall
preserve the preceding calls and read four qwords from the added request.

The bounded small-request `getrandom` refinement shall lower one exact checked
service expansion with output extent 32, maximum output count eight, maximum
delivery 256, and complete-request policy. The x86-64 provider shall validate
the full range before extraction, iterate at most eight fresh outputs in order,
replace the key before each publication, copy and verify every chunk, wipe each
complete output, and increment delivery state exactly once. The ring-3 probe
shall preserve prior calls, require a 256-byte return, and read the first and
last qwords without constraining them.

The bounded large-request `getrandom` refinement shall lower one subsequent
checked service expansion with output extent 32, maximum output count 16,
maximum delivery 512, and signal-free complete-request policy. The x86-64
provider shall preserve full-range validation before extraction, iterate at
most 16 fresh outputs in order, replace the key before every publication,
copy and verify every chunk, wipe every complete output, and increment delivery
state exactly once. The ring-3 probe shall preserve prior calls, require a
512-byte return, and read the first and last qwords without constraining them.

The initial standard-descriptor close refinement shall lower descriptor count
three and `EBADF` value nine through the checked Linux syscall-dispatch policy.
The x86-64 provider shall initialize one private live/closed state for
descriptors zero through two, map native syscall 3 to an atomic live-to-closed
transition, reject negative, out-of-range, and repeated close with `-EBADF`,
and make the existing bounded read/write arms consult the same state before any
input, user access, or output. The ring-3 image shall close standard input after
its final successful read, verify a later read and repeated close both return
`-EBADF`, and preserve terminal success. Provider-object and physical evidence
shall prove initialization, lookup, transition, rejection, complete teardown
clearing, and the ordered `TOPAL_KERNEL_USER_CLOSE_OK` observation.

The bounded initial-descriptor duplication refinement shall lower table count
three, `EBADF` value nine, `EMFILE` value 24, and the three fixed description
identities and access modes through checked dispatch policy. The x86-64
provider shall map native syscalls 32 and 33 to lowest-free duplication and
validation-before-replacement duplication, preserve aliases across one-slot
close, and make read/write authorize the mapped description. The ring-3 image
shall prove full-table rejection, zero-slot allocation, source-slot close
survival, alias restoration, write-only read rejection without input, invalid-
source nonreplacement, error-description replacement, exact close results,
and terminal clearing. Provider-object and physical evidence shall prove the
private mapping encoding, exact branches and returns, no premature state
change, and ordered `TOPAL_KERNEL_USER_DUP_OK` observation.

The bounded initial-descriptor metadata refinement shall lower `F_GETFD=1`,
`F_SETFD=2`, `F_GETFL=3`, `FD_CLOEXEC=1`, `O_RDONLY=0`, `O_WRONLY=1`, and
`EINVAL=22` through checked dispatch policy. The x86-64 provider shall map
native syscall 72, retain three private per-slot flags separately from
description identities, enforce lookup-before-command precedence, mask set
arguments, clear destination flags on duplication, and clear close/terminal
state. The ring-3 image and provider-object evidence shall prove access-mode
lookup, set/get, unsupported command, alias flag independence, `dup2` clearing,
closed-slot rejection, exact results, and ordered
`TOPAL_KERNEL_USER_FCNTL_OK` observation.

The bounded initial-descriptor `fstat` refinement shall lower one immutable
console metadata value and the native 144-byte x86-64 layout through checked
dispatch policy. The provider shall map syscall 5, look up description identity
before user access, validate a complete writable extent, privately stage every
field and zero byte, publish under generated fault recovery, and retain no user
pointer. The ring-3 image and provider-object evidence shall prove exact object,
ttyS0 device, character-mode, ownership, link, size, block, timestamp, padding,
alias-equality, `EBADF`, `EFAULT`, and ordered
`TOPAL_KERNEL_USER_FSTAT_OK` behavior.

The bounded initial-console terminal refinement shall lower `TCGETS=0x5401`,
`ENOTTY=25`, the native 36-byte x86-64 `termios` layout, raw zero-valued input,
output, and local flags, control flags `0x8bf`, line discipline zero, and only
`VMIN=1` through checked dispatch policy. The provider shall map native syscall
16, enforce descriptor-before-request-before-pointer precedence, privately
stage every byte, validate one complete writable extent, publish under
generated fault recovery, and retain no user pointer. Ring-3 and provider-
object evidence shall prove input/output equality, every exact byte, unknown-
request `ENOTTY`, closed-slot `EBADF`, invalid-candidate `EFAULT`, and ordered
`TOPAL_KERNEL_USER_TCGETS_OK` behavior.

The bounded initial-console geometry refinement shall lower
`TIOCGWINSZ=0x5413` and the native eight-byte x86-64 `winsize` layout through
checked dispatch policy. The provider shall retain descriptor-before-request-
before-pointer precedence, privately stage four zero unsigned 16-bit geometry
components, validate one complete writable extent, publish under generated
fault recovery, and retain no pointer. Ring-3 and provider-object evidence
shall prove input/output equality, every byte, closed-slot `EBADF`, invalid-
candidate `EFAULT`, retained unknown-request `ENOTTY`, and ordered
`TOPAL_KERNEL_USER_WINSIZE_OK` behavior.

The bounded initial-console seek refinement shall lower Linux x86-64 `lseek`
for the fixed descriptor table without allocating file-position state. The
provider shall map native syscall 8, resolve the slot before mode validation,
return `EBADF` for invalid or closed slots, return `ESPIPE` for modes zero
through four on a live console independently of the signed offset, and return
`EINVAL` for a larger unsigned mode on a live console. Ring-3 and provider-
object evidence shall prove input/output `SEEK_CUR`, unsupported live mode,
closed-slot precedence, absence of position mutation, and ordered
`TOPAL_KERNEL_USER_LSEEK_OK` behavior.

## TOPAL-COMP-SYSTEMS-X64-001 — Qualified x86-64 provider lowering

The first executable systems provider shall be native 64-bit x86-64 and shall
lower only checked systems operations for its recorded architecture, CPU,
feature, ABI/platform, board, and provider identities. It shall generate entry,
fault-recovery, context-transfer, privileged, atomic, ordering, and device
support without source assembly, instruction templates, programmer-selected
registers, or a generic intrinsic escape. AArch64 and RISC-V review evidence
shall not mark their backends executable-qualified.

For the bounded Q35 PCI observation, the x86-64 provider shall accept only the
sealed segment-zero `00:05.0` discovery requests, serialize each mechanism-1
address/data transaction, compare the request's exact expected value, and fail
terminally on mismatch. Structural evidence shall prove one generated call per
request and the shared `0xcf8` write/`0xcfc` read provider operation without
exposing either port to source.

For bounded PCI region access, the x86-64 provider shall configure the selected
Virtio PCI Configuration Access capability and access its data field using the
register's exact byte, word, or dword width. It shall serialize the complete gateway
transaction with other configuration accesses and shall not interpret common
configuration offsets, feature bits, status values, or queue facts. Structural evidence
shall prove the private mechanism-1 access sequences and one typed provider
call for each checked region transaction.

For the bounded bus-master authorization, the x86-64 provider shall serialize
one configuration-mechanism-1 word read, masked pre-state comparison, word
write preserving unmasked command bits, and word readback comparison. It shall
use the two-byte command field without writing adjacent PCI status and shall
remain unaware that bit two grants bus-master permission.

For the bounded DMA-buffer refinement, the x86-64 provider shall reserve two
distinct zero-initialized 4 KiB pages with 4 KiB alignment, prove their static
placement and non-overlap, and accept only the two checked creation calls. The
provider may use the Q35 identity-translated coherent domain but shall expose
neither page address to source and shall not publish either page to the device.

For bounded CPU-owned DMA construction, the x86-64 provider shall resolve only
checked opaque identities to the two provider data symbols. It shall perform
exact-width bounded stores and bind the payload's identity-translated address
into descriptor zero. Structural evidence shall prove every data-symbol
relocation, exact store width and offset, complete bounds checks, and absence of
an address return to source.

For bounded DMA device preparation, the x86-64 provider shall accept only the
checked payload-then-control sequence and preserve opaque identities in
provider-private state. It shall prove coherent identity-domain reachability
and emit a compiler/device ordering boundary before returning success.
Structural evidence shall prove exact argument checks, no buffer-address
return, and no hidden queue publication, enable, notification, or completion.

For bounded queue-address publication, the x86-64 provider shall privately
resolve the checked control-buffer symbol plus each admitted offset and write
the 64-bit value through the pinned configuration gateway as ordered low and
high dwords. Structural evidence shall prove exact region and argument checks,
three control-symbol relocations, six dword data writes, no address return, and
no hidden queue enablement or notification.

For bounded queue activation, the x86-64 provider shall reuse the qualified
configuration-gateway byte/word register access without interpreting the
virtio offsets or values. Structural evidence shall prove four typed calls,
exact access widths, serialized write/readback pairs, and no queue notification
or completion hidden in the provider.

For bounded queue notification, the x86-64 provider shall reuse the qualified
configuration-gateway word write without interpreting queue or notification
meaning. Structural evidence shall prove one typed call, capability-relative
region selection, exact width/value, serialized write, and no hidden readback,
completion, or ownership transition.

For bounded completion-signal observation, the x86-64 provider shall reuse the
qualified configuration-gateway byte read without interpreting ISR or queue
meaning. Structural evidence shall prove one typed call, exact capability-
relative region and expected value, serialized read/compare acknowledgement,
and no hidden ring access or ownership transition.

The first x86-64 provider increment shall derive a deterministic sealed plan
from the checked systems program. It shall bind the exact target, QEMU board,
profile, CPU baseline, platform ABI, LLVM data layout, ELF64 object format,
static relocation, small code model, bootstrap-storage placement, and every
initial semantic operation to one closed provider identity. Planning alone
shall not authorize lowering or publication.

The next provider increment shall generate a deterministic relocatable ELF64
object directly from that checked plan. It shall confine x86-64 encodings to a
private typed provider model, define no source-level instruction or register
interface, reserve the checked bootstrap storage as aligned uninitialized data,
retain exact target/provider provenance, and have no relocation or undefined
dependency. This partial provider object shall not by itself qualify target
selection, linking, publication, or boot.

## TOPAL-COMP-SYSTEMS-ARTIFACT-001 — Kernel artifact publication

The systems publisher shall use a distinct target/data-layout/object/relocation
profile, generate and retain semantic placement and entry roots, link without
host startup, syscalls, allocator, libc, dynamic loader, foreign runtime, or
ordinary process termination, and inspect the linked artifact before atomic
publication. It shall publish kernel, debug, map, and canonical provenance
outputs and pass the kernel digest to a separately qualified boot-image adapter.

The first linked-artifact increment shall lower checked handler operation order
and dispositions into a generated root object whose only undefined references
are sealed provider facilities. It shall link a static executable payload,
inspect its entry set, placements, dependencies, relocations, hosted sections,
debug companion, and map, and atomically publish one directory containing only
the kernel, debug, map, and canonical provenance outputs. This linked payload
shall not itself claim a boot protocol or executable-qualify the systems target.

The first boot-adapter increment shall validate that exact linked payload and
its provenance before generating a Linux x86 boot-protocol 2.15 image. It shall
materialize ELF load segments at their reviewed physical addresses, generate
the approved real-mode and long-mode transition structures without source
assembly, bind IDT vector 3 to the linked debug-break entry, and atomically
publish only the boot image and canonical adapter provenance. Structural
packaging alone shall not executable-qualify the systems target; qualification
requires separate execution under the pinned QEMU board and CPU.

The initial adapter shall advertise only its implemented setup/protected boot
route. Its `xloadflags` shall be zero: the internal transition into long mode
does not implement Linux's independent 64-bit loader entry at payload offset
`0x200`. This does not qualify that separate boot interface or remove it from
the broader kernel objective.

The initial user-image publication increment shall add exactly one canonical
ELF image to the atomic systems-artifact directory and bind its filename and
digest in artifact provenance. The boot adapter shall read that published
image, reject absence, digest mismatch, or an unbound output identity, and use
the exact verified bytes for the deterministic initial boot resource. It shall
not privately regenerate or silently substitute the user image. Unit tests
shall cover canonical output closure, repeatable publication, and tamper
rejection; pinned-QEMU evidence shall bind the published image digest through
the boot resource and completed user execution.

The supplied initial user-image increment shall accept
`--initial-user-image PATH` only for qualified systems publication. Before
creating publication state, the compiler shall read the complete file and
validate the current x86-64 bounded ELF envelope: exact file and ELF class,
machine, type, header, program-header, segment-layout, immutable-metadata, and
alignment facts; relational page-bounded executable and data/BSS sizes; and an
entry strictly inside the executable file extent. Executable payload and
initialized-data bytes shall remain caller authority. Successful publication
shall copy those exact bytes to the canonical image and bind them through the
existing content provenance without the host path. Unreadable, duplicate,
nonsystems, malformed, or out-of-profile input shall fail before publication.
Tests shall cover every rejected field class, path-independent repeatability,
a supplied payload distinct from the generated default, exact-byte boot
packaging, and deterministic pinned-QEMU execution.

The first executable bootstrap-region increment shall accept only an
exhaustively handled static allocation request whose capacity and alignment
are proven against the artifact pool. It shall check a closed success action
containing static in-bounds byte store/load, require consuming release on every
reachable success path, reject region escape or error-path access, and keep
dynamic or non-plain memory access unavailable. X86-64 lowering shall address
the generated bootstrap pool without exposing that address to source, execute
the load rather than constant-folding it, branch to the fatal provider on a
content mismatch, and retain structural plus pinned-QEMU evidence.

The first executable boot-memory increment shall consume the Linux x86
boot-protocol 2.15 `boot_params` handoff privately, validate the admitted E820
table, reject unsupported extension data, prove at least one complete
allocatable page remains after generated reservations, and branch to the
fatal provider on failure. The root object shall retain no source-visible
firmware layout, address, register, or instruction interface. The x86 boot
adapter shall populate the admitted zeropage table through a bounded BIOS E820
continuation chain before leaving real mode; incomplete or malformed
collection shall remain fail-closed.
Artifact inspection and pinned-QEMU evidence shall prove the success marker is
reachable only after validation.

## TOPAL-COMP-SYSTEMS-TEST-001 — Systems negative and physical evidence

Tests shall cover every systems rule's accepted model transitions and reject
wrong feature, artifact, context, authority, lifetime, order, target, and
provider before output. X86-64 tests shall inspect entry code, privileged
instruction confinement, sections, placement, relocations, symbols, undefined
dependencies, unwind/debug data, and absence of host mechanisms, then exercise
the target provider under the pinned QEMU board. The test record shall retain
all model, provider, toolchain, image, and board identities.

## TOPAL-COMP-OPT-PLAN-001 — Validated generic target plan

Before source lowering, the compiler shall resolve a typed optimization plan.
An omitted target shall select the built-in generic Linux x86-64 model only
when the build host has that architecture and platform. The compiler shall
validate and canonically hash that architecture model, select no optional CPU
features, and record its identity and digest plus the optimization-plan
revision in artifact evidence and provenance.

The CLI shall parse every standard optimization-profile spelling and the
target, CPU, board, and model controls defined by `TOPAL-OPT-PROFILE-001` and
`TOPAL-OPT-TARGET-001`. This increment shall accept `O0` and the separately
qualified `O1` runtime-pruning slice, the qualified target, and the generic CPU
selection; it shall reject every higher profile, specific or native CPU,
board, custom-model, or foreign selection before frontend or toolchain output
rather than ignore, approximate, or silently strengthen it.

## TOPAL-COMP-OPT-RUNTIME-DCE-001 — Target-qualified runtime global DCE

On the validated built-in generic Linux x86-64 model, `O1` shall enable only
`topal.runtime-global-dce/1`. The toolchain shall run LLVM `globaldce` followed
by verification, preserve LLVM roots and all transitively referenced
definitions, and retain the O0 backend so this pass remains isolated. LLVM-IR,
object, and executable output shall use the resulting module. Existing Topal
examples shall retain their exact result while unused private runtime
definitions and resulting output size decrease where applicable. Artifact
identity shall include the selected pass and profile.

## TOPAL-COMP-OPT-CONTROL-001 — Profile pipelines and explicit controls

Profiles O2, O3, Os, and Oz shall select `llvm.default-pipeline/22` with the
corresponding LLVM 22 default IR pipeline and qualified backend effort. The
compiler shall expose source-free optimization listing; ordered stable-ID
enable and disable controls; isolated selection; ordered goals; hard limits;
and deterministic JSON explanations to standard error or an explicit path.
Unknown or incompatible controls shall reject before output. Explanations shall
include conservative remarks for absent workload, hotness, and trip-count facts
without fabricating them. Artifact provenance and build identity shall include
the effective exposed optimization identities.

## TOPAL-COMP-OPT-TEST-MATRIX-001 — Profile and isolated-pass evidence

The native corpus runner shall default to every selected regression at O0 and
O2, compare each result with the interpreter, and permit an explicit single
profile only for focused diagnosis. A representative existing program shall
also run at O0, with `topal.runtime-global-dce/1` isolated, and at O2; the
variants shall produce the same result and demonstrate the expected IR and
artifact-size ordering. Compiler resource records shall use separate build and
execution identities for O0 and O2.

The optimized freestanding pipeline shall retain a private compiler-owned
`memset` implementation for LLVM-synthesized memory operations. It shall
disable switch lookup-table conversion while the static PIE has no loader for
absolute pointer relocations. Optimized executables shall retain no unintended
undefined runtime symbols or load-time relocation requirement.

## TOPAL-COMP-LLVM-001 — Verified LLVM 22 pipeline

The compiler shall locate an explicit or toolchain-provided LLVM 22 suite,
reject another major, assemble and verify every emitted module, use `llc` for
O0 object generation with frame pointers, and use LLD for executable linking.
Tool failure shall preserve the responsible command's diagnostics and shall not
publish a partial requested output.

## TOPAL-COMP-PLATFORM-001 — No implicit foreign runtime dependency

An executable shall define `_start`, perform complete standard-output writes
and termination through the Linux x86-64 syscall ABI, and use no startup files
or default libraries. It shall link as a static PIE without a dynamic
interpreter, `DT_NEEDED` entries, or undefined symbols unless an explicitly
selected shared C access library supplies the loader and object requirements
defined by `TOPAL-COMP-C-SHARED-001`.

## TOPAL-COMP-C-STATIC-001 — Checked static C access libraries

The compiler shall discover only explicitly selected generated access
libraries, decode the complete canonical `topal-c-abi/1` model from `module.t`,
require no parallel manifest, revalidate the header and archive SHA-256
digests, and accept only the
`x86_64-unknown-linux-gnu`/`sysv-amd64` profile. It shall lower a used C `int`
function through a private Topal adapter and external `ccc` call, diagnose an
out-of-range value without truncation, include the archive explicitly in the
no-default-library static link, and record both C inputs in artifact
dependencies. This realizes `TOPAL-C-ABI-CONTEXT-001` through
`TOPAL-C-ABI-PROVENANCE-001` for the closed static function subset.

## TOPAL-COMP-C-BINDGEN-001 — Clang-derived interface translation

`topal-c-bindgen` shall require Clang 22 and the qualified target, parse rather
than text-match C declarations, reject every declaration outside const,
non-variadic C functions with `int` parameters and C `int` or `void` results,
verify ELF x86-64 binary symbols with LLVM tools, and publish no partial
access-library directory after failure. Its canonical `module.t` shall include
every filename, digest, identity, and function property required by the
compiler and shall be the only emitted ABI description.

## TOPAL-COMP-C-SHARED-001 — Closed shared C access libraries

For `topal-c-abi-shared/1`, the translator and compiler shall verify an ELF
x86-64 shared object with a filename-matching SONAME and reject dynamic
dependencies, unresolved symbols, and load or unload initializers. Executable
linking shall name the declared object through `DT_NEEDED`, use the qualified
`/lib64/ld-linux-x86-64.so.2` interpreter and `$ORIGIN` runpath, and deploy the
exact digested object beside the executable without replacing a conflicting
SONAME. Artifact identity shall include the object digest and platform
requirements. This realizes `TOPAL-C-ABI-SHARED-001`.

## TOPAL-COMP-STANDARD-LIBRARY-SHARED-001 — Sealed standard-library object

`topalc std-library` shall build the qualified Linux x86-64 standard-library
slice as `libtopal-std.so.1` with ABI revision `topal-library/1`. The slice
manifest shall bind the complete canonical `std` source tree, language and
library major revisions, target triple, object format, data layout, one sealed
entry-table export, SONAME, export map, and shared-object digest. The ELF object
shall define only that public entry table and shall have no undefined symbol,
load/unload initializer, C/C++ runtime, or dynamic dependency.

For an application which explicitly selects both `use library std` and
`--std-library`, the compiler shall validate the canonical manifest, source
interface digest, payload digest, ELF identity, export, and closed dependency
set before linking. It shall deploy the exact object beside the executable,
use an origin-relative runpath, record the slice as one artifact dependency,
and emit exactly one Topal `DT_NEEDED` entry regardless of selected standard
modules or declarations. Source-specialized declarations remain permitted by
`TOPAL-LIB-SUBSTITUTION-001` and shall remain observationally equivalent to
the authoritative source.

This Linux slice shall not imply support for an unqualified FreeBSD or Windows
target; those target-qualified ELF and PE/COFF publishers remain required when
their compiler targets are admitted. Tests shall build, inspect, link, deploy,
execute, and validate dependency metadata for the slice. This realizes
`TOPAL-REQ-NATIVE-LIBRARY-001` and `TOPAL-LIB-NATIVE-SLICE-001`.

## TOPAL-COMP-O0-001 — Exact first-slice lowering

The first compiler increment shall lower Unit, Boolean, signed-64-bit-
representable exact Int values, static strings, positional products, immutable
bindings, explicit discard, eager Boolean operations, integer addition,
subtraction, multiplication, equality and ordering, ordinary nonrecursive
scalar functions, and complete Boolean decisions. It shall accept integer
operations only when shared static range evidence proves their exact result is
representable and shall reject every other construct with
`E-COMPILER-UNSUPPORTED`.

This requirement covers `TOPAL-SYN-CONTEXT-001`, `TOPAL-SYN-BIND-001`,
`TOPAL-SYN-STRING-001`,
`TOPAL-TYPE-PRODUCT-001`, `TOPAL-TYPE-BOOLEAN-001`,
`TOPAL-TYPE-EQUALITY-001`, `TOPAL-NUM-INT-001`, `TOPAL-NUM-ADD-001`,
`TOPAL-NUM-NEG-001`, `TOPAL-NUM-SUB-001`, `TOPAL-NUM-MUL-001`,
`TOPAL-NUM-COMPARE-001`, `TOPAL-FUNCTION-ORDINARY-001`, and
`TOPAL-DECISION-BOOLEAN-001` within the stated incremental boundary.

## TOPAL-COMP-DIAGNOSTIC-CONTROL-001 — Static diagnostic controls

The compiler shall accept legacy warning controls and structured
diagnostic-identity controls whose stack and next-statement structure the shared
parser has validated. Shared underflow, mismatch, missing-target, and unclosed-
stack diagnostics shall reach the compiler caller unchanged. Language errors
shall remain unsuppressible.

The checked compiler model shall erase valid controls after their static effect
has been accounted for. Because this increment emits no configurable compiler
warnings or severity-neutral diagnostics, it has no diagnostic event to filter;
future such diagnostics shall consult the active source identity and lexical
extent. LLVM IR and the executable shall contain no operation or state for an
erased control. Native tests shall cover both control spellings, shared invalid-
stack validation, exact interpreter/compiler output, absent runtime lowering,
freestanding artifacts, source debugging, the shared corpus, and separate
resource baselines.

This shall add no runtime diagnostic table, allocation, foreign dependency,
C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. This realizes
`TOPAL-COMPILER-DIAGNOSTIC-CONTROL-001` and `TOPAL-SYN-DIAG-001` for compiler
increment 1a.

## TOPAL-COMP-LINT-VARIANT-001 — Static lint language context

The compiler shall accept a v0.1 source context whose only canonical optional
feature is `lint`, preserve that feature in the checked program and in any
admitted static `lang context` value, and expose `lang lint` only in that
context. The exposed value shall be the empty, authority-free `lang lint`
namespace with classifier `Scope`; without the feature, the shared
`E-LINT-VARIANT` diagnostic shall be retained. Every other optional feature
shall remain rejected with `E-COMPILER-UNSUPPORTED`.

Linux x86-64 lowering may extend the private `Scope` enumeration with a stable
compiler-selected tag for canonical display and truthful DWARF/GDB inspection.
It shall add no runtime namespace or lint table, lookup, allocation, filesystem,
network, process, debugger, or application authority, foreign dependency,
C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision.

A future compiled-library interface shall identify the selected language
revision, canonical variant feature set, exposed vocabulary, and authority
profile independently of this private tag and native symbol spelling. Tests
shall compile the unchanged interpreter regression, compare exact output,
inspect checked context metadata and O0 LLVM, validate the shared corpus and
separate resource baselines, and verify freestanding ELF, DWARF, GDB, undefined
symbols, needed libraries, and relocations. This realizes
`TOPAL-COMPILER-LINT-VARIANT-001`, `TOPAL-SYN-CONTEXT-001`, and
`TOPAL-LINT-VARIANT-001` for compiler increment 1b.

## TOPAL-COMP-INT-001 — Arbitrary finite Int runtime

The compiler shall remove the increment-1 signed-64-bit admission boundary and
represent every admitted finite `Int` with dynamically sized exact storage. At
O0, literals, negation, absolute value, addition, subtraction, multiplication,
equality, ordering, function passage, decision joins, decimal output, and GDB
inspection shall preserve the normative value for operands of any size that
available address space can hold.

The private `topal-native/6` representation shall be canonical, immutable, and
hidden from foreign calling conventions. Its allocator and output routines
shall use only the qualified Linux x86-64 system-call boundary, detect mapping
failure, introduce no C/C++ runtime dependency or undefined helper symbol, and
retain allocated values safely until process termination. Reclamation beyond
that process-lifetime policy is deferred until reachability-bearing values are
admitted and shall not change source observations.

This requirement covers `TOPAL-NUM-INT-001`, `TOPAL-NUM-NEG-001`,
`TOPAL-NUM-ABS-001`, `TOPAL-NUM-ADD-001`, `TOPAL-NUM-SUB-001`,
`TOPAL-NUM-MUL-001`, `TOPAL-NUM-COMPARE-001`, and the applicable Int cases of
`TOPAL-TYPE-EQUALITY-001`.

It realizes `TOPAL-COMPILER-INT-001` for compiler increment 2a.

## TOPAL-COMP-EXACT-001 — Finite exact-number runtime

The compiler shall represent finite Rational values as immutable pairs of
canonical arbitrary-precision Int numerator and positive denominator objects.
It shall implement relocation-free literals and identities, closed and
specialization-proven construction, canonical Int embedding, exact Int and
Rational division, Rational negation, absolute value, addition, subtraction,
multiplication and powers, Int power, Euclidean modulo and quotient/modulo,
same-domain and mixed exact equality/ordering, direct three-way Comparison
values, textual output, function passage, and GDB inspection.

Normalization shall use exact greatest-common-divisor and division algorithms.
The implementation shall use no fixed source-value width, C/C++ runtime,
foreign allocator, arithmetic helper, load-time pointer relocation, or dynamic
loader. The compiler shall diagnose statically evident zero divisors and fail
closed on dynamic arithmetic-error paths until typed Result lowering is
implemented; generated code shall not terminate in place of an admitted Result.

This requirement covers `TOPAL-NUM-RATIONAL-001`,
`TOPAL-NUM-RATIONAL-CONSTRUCT-001`, `TOPAL-NUM-RATIONAL-LITERAL-001`,
`TOPAL-NUM-RAT-NEG-001`, the finite Rational case of `TOPAL-NUM-ABS-001`,
the admitted Int and Rational cases of `TOPAL-NUM-ZERO-001` and
`TOPAL-NUM-ONE-001`, `TOPAL-NUM-RAT-ADD-001`, `TOPAL-NUM-RAT-SUB-001`,
`TOPAL-NUM-RAT-MUL-001`, `TOPAL-NUM-RAT-DIV-001`,
`TOPAL-NUM-INT-RATIONAL-CONVERT-001`, `TOPAL-NUM-DIV-001`,
`TOPAL-NUM-DIVZERO-001`, `TOPAL-NUM-INT-MODULO-001`,
`TOPAL-NUM-INT-QUOTIENT-MODULO-001`, `TOPAL-NUM-POW-001`,
`TOPAL-NUM-RAT-POW-001`, `TOPAL-NUM-RAT-NEG-POW-001`,
`TOPAL-NUM-COMPARE-001`, `TOPAL-NUM-THREE-WAY-COMPARE-001`, and applicable
exact-number cases of `TOPAL-TYPE-EQUALITY-001` and
`TOPAL-TYPE-ORDERING-001`.

It realizes `TOPAL-COMPILER-EXACT-001` for compiler increment 2b.

## TOPAL-COMP-NAT-COMPARISON-001 — Nat comparison evidence

The compiler shall evaluate each admitted Nat comparison operand once and
forget its validated constraint evidence to the unchanged canonical
arbitrary-precision Int value. Equality, inequality, ordered predicates, and
three-way comparison between Nat values or mixed Nat/Int values shall use the
existing Int comparison. Mixed Nat/Rational comparison shall use the existing
canonical Int-to-Rational conversion and Rational comparison.

Evidence forgetting shall emit no runtime conversion, unsigned representation,
fixed-width narrowing, allocation, Nat-specific operation, or ABI change. The
original classified binding shall retain Nat DWARF identity. Nat shall also be
admitted recursively as same-classifier positional-product equality evidence.
This requirement covers `TOPAL-NUM-NAT-001`, `TOPAL-TYPE-CONSTRAINT-001`,
`TOPAL-TYPE-EQUALITY-001`, `TOPAL-TYPE-ORDERING-001`,
`TOPAL-NUM-COMPARE-001`, and `TOPAL-NUM-THREE-WAY-COMPARE-001`; it realizes
`TOPAL-COMPILER-NAT-COMPARISON-001` for compiler increment 2e.

## TOPAL-COMP-NAT-ARITHMETIC-001 — Nat arithmetic evidence

The checked compiler shall retain Nat for finite Nat addition and
multiplication. It shall retain Nat for subtraction only when operand range
evidence proves the result nonnegative; otherwise Nat subtraction and mixed
Nat/Int arithmetic shall forget evidence to Int. Lowering shall evaluate each
operand once and reuse the existing exact arbitrary-precision Int operation.

Tests shall cover dynamic Nat parameters, retained and forgotten result
classifiers, exact interpreter output, direct Int-runtime LLVM calls, Nat
DWARF identity, the compiler corpus, and resource baselines. This shall add no
unsigned representation, copy, validation operation, Nat-specific runtime,
foreign dependency, public ABI, or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-NAT-ARITHMETIC-001` and
`TOPAL-NUM-NAT-ARITHMETIC-001` for compiler increment 2e1.

## TOPAL-COMP-MODULAR-001 — Nominal modular numbers

The compiler shall collect admitted root-scope `ModNat` and `ModInt`
declarations whose modulus is given by a direct finite inclusive Int range,
retain their nominal identity and canonical bounds, and reject malformed or
cross-nominal operations. Checked construction shall require statically proven
in-range input until dynamic Result-producing construction is available.
Explicit `value modulo Type` shall accept an admitted Int value and reduce it
to the unique representative.

Wrapping addition, subtraction, multiplication, and negation shall use the
existing exact arbitrary-precision Int runtime before canonical reduction.
Equality, ordering, and three-way comparison shall compare canonical
representatives only for identical modular types. Canonical display shall
include the source type name. Private function passage, returns, and decision
joins shall retain the classifier while reusing the existing Int pointer
carrier; LLVM shall own its physical x86-64 call lowering.

DWARF shall give every modular declaration a distinct semantic typedef and
storage identity, and the bundled GDB renderer shall safely show both the type
name and canonical value. Tests shall compile the unchanged interpreter
modular-number regression, compare exact output, inspect checked and LLVM
lowering, reject invalid construction and nominal mixing, and verify undefined
symbols, needed libraries, relocations, and GDB parameter values.

This increment shall use only the existing Topal Linux syscall allocator and
writer. It adds no machine-width wraparound, LLVM-optimization dependency,
foreign allocator, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Named range operands, dynamic checked
construction, modular absolute value, persistent/public representation,
serialization, and compiled-library metadata remain deferred. This realizes
`TOPAL-COMPILER-MODULAR-001` and the admitted portions of
`TOPAL-NUM-MODULAR-TYPE-001`, `TOPAL-NUM-MODULAR-CONSTRUCT-001`,
`TOPAL-NUM-MODULAR-REDUCE-001`, and `TOPAL-NUM-MODULAR-ARITHMETIC-001` for
compiler increment 2f.

## TOPAL-COMP-MODULAR-CONSTRUCTION-001 — Named ranges and dynamic construction

The compiler shall accept a root modular declaration whose operand names an
earlier root binding initialized by a closed finite inclusive `Range Int`.
Resolution shall follow immutable source order and preserve the same exact
canonical bounds as direct range syntax; dynamic, cyclic, forward, malformed,
and non-range operands shall remain rejected.

For checked `Name value`, statically proven in-range inputs shall retain the
direct nominal value path and closed proven out-of-range inputs shall retain
the source diagnostic. Every other admitted Int shall be evaluated once and
compared against both arbitrary-precision inclusive bounds in generated LLVM
control flow. Success shall wrap the original Int pointer; rejection shall
produce the existing arithmetic Result/Error representation with code
`out-of-range`, lexical domain `root.Name(Int)`, and exact operand provenance.

`Result (Name, lang arithmetic ArithmeticErrorCode)` shall be admitted through
the existing private pointer call, return, projection, decision, display, and
Error-observation paths. Its DWARF header shall retain a nominally typed Name
payload so the bundled GDB renderer can validate and print success and failure
values. Tests shall use one unchanged interpreter/compiler regression, compare
exact output, inspect checked and LLVM control flow, and verify no undefined
symbol, needed library, dynamic relocation, or lost GDB type/value/frame.

This increment shall reuse only the existing exact Int comparison, Result,
Error, Linux syscall allocation, and writer facilities. It adds no C/C++
runtime, other-language standard library, public ABI, serialization contract,
or `topal-native/6` revision. Modular absolute value, persistent/public
representation, serialization, introspection, and compiled-library metadata
remain deferred. This realizes
`TOPAL-COMPILER-MODULAR-CONSTRUCTION-001` and completes the named-range and
dynamic-construction portions of `TOPAL-NUM-MODULAR-TYPE-001` and
`TOPAL-NUM-MODULAR-CONSTRUCT-001` for compiler increment 2f1.

## TOPAL-COMP-RESULT-001 — Dynamic arithmetic Results

The compiler shall represent an admitted arithmetic `Result` with an immutable
success-or-error tag and one statically classified payload. It shall represent
every intrinsic Error with its reporting domain, nominal arithmetic code,
absent detail and cause, and source file, line, and column provenance. The
private representation shall be versioned as `topal-native/6`, remain opaque to
foreign calling conventions, and be inspectable through the bundled GDB
renderer.

Dynamic finite Rational construction shall distinguish `division-by-zero` from
`indeterminate`. Dynamic Rational division and negative power, plus dynamic Int
modulo and quotient/modulo, shall return `division-by-zero` from their specified
reporting domains rather than terminate the process. Ordinary success values
shall satisfy explicit Result contracts, and returning or passing through a
failed Result shall preserve the complete Error unchanged.

This requirement covers `TOPAL-NUM-RATIONAL-CONSTRUCT-DYNAMIC-001`,
`TOPAL-NUM-INT-MODULO-001`, `TOPAL-NUM-INT-QUOTIENT-MODULO-001`,
`TOPAL-NUM-DYNAMIC-DIVZERO-001`, `TOPAL-NUM-RAT-NEG-POW-001`,
`TOPAL-NUM-ARITHMETIC-ERROR-001`, and the admitted function-contract and
propagation cases of `TOPAL-TYPE-RESULT-001`. It realizes
`TOPAL-COMPILER-RESULT-001` for compiler increment 2c-b1.

Exact checked Int construction and an Int-classified binding shall validate a
dynamically obtained Rational denominator, returning `not-representable` from
`root.Int(Rational)` without rounding or truncation. Checked Nat construction
shall preserve a nonnegative Int or return `out-of-range` from `root.Nat(Int)`.
A compatible classified binding shall project the success payload and return
the original complete Error immediately on failure.

These additions cover `TOPAL-NUM-RATIONAL-INT-EXACT-001`,
`TOPAL-NUM-RATIONAL-INT-VALIDATE-001`, `TOPAL-NUM-INT-CONSTRUCT-001`,
`TOPAL-NUM-NAT-CONSTRUCT-001`, and `TOPAL-TYPE-RESULT-PROJECT-001`. They realize
the remaining `TOPAL-COMPILER-RESULT-001` scope for compiler increment 2c-b2.

Result decisions shall evaluate their subject once, bind success or whole-Error
payloads only in the selected action, and execute only that action. Qualified
arithmetic Error-code matchers shall compare the stored nominal code rather
than the independent reporting domain, preserve source ordering, diagnose
unknown or duplicate codes, and require either a generic Error fallback or the
complete four-code vocabulary. Compatible String-valued actions shall use an
immutable native descriptor and merge without eager evaluation.

Selecting `code` or `domain` from an arithmetic Error shall return the stored
typed value without reconstructing or altering the Error. The compiler shall
represent literal String bytes, immutable descriptors with cached canonical
display spellings, Error fields, functions, decision joins, textual output,
DWARF, and GDB consistently under `topal-native/6`. Pointer-bearing descriptors
shall be constructed at run time so static no-loader PIEs retain no load-time
relocations. String display shall produce the canonical ordinary or
conflict-free tagged literal form using only the Topal Linux syscall runtime.

These additions cover `TOPAL-DECISION-RESULT-001`,
`TOPAL-DECISION-ERROR-CODE-001`, `TOPAL-ERROR-FIELD-001`, and the admitted
literal transport and display cases of `TOPAL-SYN-STRING-001`. They complete
compiler increment 2c-b3; generic Result/library composition and the remaining
String operations retain their later roadmap dispositions.

## TOPAL-COMP-ERROR-OPTIONAL-FIELDS-001 — Optional Error provenance fields

The compiler shall classify `detail`, `cause`, and `source` selection from an
admitted Error or failed Result as `Optional String`, `Optional Error`, and
`Optional SourceLocation`. It shall wrap the existing nullable detail and cause
slots without synthesizing information. A present source descriptor shall
produce a private immutable SourceLocation containing canonical Int pointers
for the stored one-based line and column; an absent descriptor shall produce
`None`. Selection shall not reconstruct or alter the Error.

The existing private Optional header shall carry all three results across
admitted decisions and private function boundaries. LLVM shall own physical
x86-64 call lowering while the frontend retains the payload classifier.
Canonical output shall render a present source as
`Some (line is N, column is N)`. DWARF shall describe SourceLocation and both
new Optional payload types, and the bundled GDB renderer shall safely render
them. Tests shall compile the unchanged interpreter composition regression,
compare its exact output, inspect the lowering and DWARF, and verify undefined
symbols, needed libraries, relocations, and GDB values.

SourceLocation and Optional allocations shall use only the existing Topal
Linux `mmap` boundary. The already reserved Error layout and private opaque-
pointer Optional layout remain `topal-native/6`; this increment adds no foreign
allocator, C/C++ runtime, other-language standard library, public ABI, or ABI
revision. This realizes `TOPAL-COMPILER-ERROR-OPTIONAL-FIELDS-001` and the
remaining field-selection portion of `TOPAL-ERROR-FIELD-001` for compiler
increment 2c-b5.

## TOPAL-COMP-CODE-001 — Qualified arithmetic ErrorCode values

The compiler shall resolve the four qualified values published by
`lang arithmetic` to the same closed nominal `ArithmeticErrorCode` identity and
sealed `i32` tags stored in compiled Error values. Direct values shall support
same-type equality, scalar function passage, canonical alternative-label
display through the Topal platform writer, DWARF enumerators, and GDB
inspection without a runtime namespace lookup or foreign-language dependency.
An unknown or incompletely qualified code shall not be reinterpreted as an
arithmetic code.

This requirement covers `TOPAL-NUM-ARITHMETIC-ERROR-001` and realizes
`TOPAL-COMPILER-ERROR-CODE-001` for compiler increment 2c-b4.

## TOPAL-COMP-GENERATOR-ERROR-CODE-001 — Qualified generator code value

The checked compiler shall resolve only `lang generator generator-closed` as
the sole initial alternative of the nominal
`lang generator GeneratorErrorCode` enum. It shall retain the exact nominal
identity through immutable bindings, same-type equality, decomposed products,
canonical output, DWARF, and GDB. Unknown, incomplete, and arithmetic-code names
shall not be accepted as this vocabulary.

The Linux x86-64 backend may reuse its private enum lowering with tag zero.
Constructing or observing the value shall not allocate or control a generator,
deliver a close signal, choose an `Error.domain`, or fabricate generator/yield
provenance. The tag shall remain compiler-private rather than a public,
foreign, persistent, serialized, or compiled-library identity; future library
metadata shall carry canonical vocabulary and alternative identities instead.
This increment shall admit no Generator classifier or function boundary,
generator state/storage, suspension/resumption, close delivery/handling, or
Error carrier. It shall require no generator runtime, allocator, foreign
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-GENERATOR-ERROR-CODE-001` and
`TOPAL-GENERATOR-ERROR-CODE-001` for compiler increment 5a.

## TOPAL-COMP-GENERATOR-ITERATE-CONSTRUCT-001 — Lazy iterate construction

The checked compiler shall admit exact `Generator Int Unit Unit` construction
from an `Int` initial expression and unary anonymous `Int -> Int` next
operation, followed optionally and directly by `take-while` with a unary
anonymous `Int -> Boolean` predicate. It shall evaluate the initial expression
once, retain the checked construction and anonymous bodies, invoke neither body
during construction, and print the canonical `<Generator Int Unit Unit>` final
observation.

An immutable local Generator binding shall be consumable at most once. Before
LLVM lowering, the checked boundary shall reject repeated, abandoned, or
explicitly discarded bindings; product containment; qualified access;
equality; decision joins; and function or library boundaries. The Linux x86-64
backend may lower the remaining construction-only binding to a private `i32`
observation token with semantic Generator DWARF, but that token shall encode no
seed, operation, capture, continuation, ownership, or stable identity. Future
compiled-library metadata shall describe the canonical Generator classifier,
captured operations, and evidence independently of target representation.

This increment shall perform no traversal, yield, resume, suspension, close
delivery, generator allocation, indirect call, or generator runtime operation.
It shall introduce no foreign dependency, C/C++ runtime, other-language
standard library, needed library, dynamic relocation, or `topal-native/6`
revision. This realizes
`TOPAL-COMPILER-GENERATOR-ITERATE-CONSTRUCT-001`,
`TOPAL-GENERATOR-ITERATE-001`, and `TOPAL-GENERATOR-TAKE-WHILE-001` for compiler
increment 5b.

## TOPAL-COMP-GENERATOR-UNFOLD-CONSTRUCT-001 — Lazy unfold construction

The checked compiler shall admit exact `Generator Int Unit Unit` construction
from a `List Int` seed expression and a unary anonymous
`List Int -> Optional (Int, List Int)` step operation. It shall preserve the
distinction between seed and yield classifiers, evaluate the seed once, retain
the checked seed and anonymous operation, invoke no step during construction,
and print the canonical `<Generator Int Unit Unit>` final observation.

The existing one-consumption local Generator boundary shall reject repeated,
abandoned, or explicitly discarded bindings; product containment; qualified
access; equality; decision joins; and function or library boundaries. A step
that captures another Generator shall also be rejected before LLVM. The Linux
x86-64 backend may reuse the private `i32` construction observation token with
semantic Generator DWARF. That token shall encode no seed, step, capture,
continuation, ownership, or stable identity. Future compiled-library metadata
shall carry the canonical Generator classifier, distinct seed and yield
classifiers, step signature, captured operations, and evidence independently
of a target representation adapter.

This increment shall perform no traversal, collection, yield, resume,
suspension, close delivery, Generator allocation, indirect call, or Generator
runtime operation. It shall introduce no foreign dependency, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library Generator ABI, or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-GENERATOR-UNFOLD-CONSTRUCT-001` and
`TOPAL-GENERATOR-UNFOLD-001` for compiler increment 5d.

## TOPAL-COMP-GENERATOR-UNFOLD-COLLECT-001 — Finite unfold collection

The checked compiler shall admit unary `collect` over an exact
`Generator Int Unit Unit` whose retained construction uses an immutable
`List Int` seed binding and exactly `uncons` of its unary `List Int` parameter
as the step. The Generator may be consumed directly or after linear local
moves. The seed shall have been evaluated once at construction. Collection
shall append every nonempty seed head to a fresh `List Int` in order, continue
with the corresponding tail, terminate without an entry at `Empty`, and leave
the source List unchanged.

An arbitrary step, step statements or captures, a seed whose evaluated
identity is unavailable to the specialization, and a Generator without local
construction provenance shall be rejected before LLVM. Provenance retained for
this proof shall remain compiler-private and shall not enter persistent,
serialized, public, foreign, or compiled-library metadata.

The Linux x86-64 backend shall use explicit current-seed and result-head/tail
LLVM SSA loop values and may allocate fresh immutable List nodes through the
Topal platform allocator. This required O0 semantic lowering shall materialize
no Optional, call no List `uncons` helper, use no construction token as state,
allocate no Generator object, and emit no callback, indirect call, or generic
Generator runtime. It shall introduce no foreign dependency, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library Generator ABI, or `topal-native/6` revision. Future library
metadata shall identify the canonical Generator, seed/yield classifiers, exact
step/evidence, linear ownership, and target adapter independently of this
specialization. This realizes
`TOPAL-COMPILER-GENERATOR-UNFOLD-COLLECT-001`,
`TOPAL-GENERATOR-UNFOLD-001`, and `TOPAL-GENERATOR-UNFOLD-COLLECT-001` for
compiler increment 5e.

## TOPAL-COMP-GENERATOR-ITERATE-COLLECT-001 — Finite iterate collection

The checked compiler shall admit unary `collect` only for a syntactically
direct exact `Generator Int Unit Unit` formed by `iterate` and bounded by
`take-while`. It shall evaluate the initial expression once, test each
candidate once before publication, append every accepted Int to a fresh
`List Int` in yield order, and invoke the next operation once afterward. A
rejected candidate shall neither enter the List nor cause another next
invocation. The resulting value shall use the already admitted List behavior
for equality, display, private passage, DWARF, and GDB.

An unbounded iterate, an indirect or stored Generator operand, and an anonymous
next or predicate body with an outer-value capture shall be rejected before
LLVM. The Linux x86-64 backend shall carry only the current arbitrary-precision
Int and private List head/tail as explicit SSA loop state, allocate immutable
List nodes through the Topal platform allocator, and use direct generated
control flow. It shall allocate no Generator object, use no construction token
as executable state, host recursion, indirect call, or generic Generator
runtime, and introduce no foreign dependency, C/C++ runtime, other-language
standard library, needed library, dynamic relocation, public/library Generator
ABI, or `topal-native/6` revision. Future compiled-library metadata shall
describe the canonical operation/evidence composition independently of this
specialization. This realizes
`TOPAL-COMPILER-GENERATOR-ITERATE-COLLECT-001`,
`TOPAL-GENERATOR-ITERATE-001`, `TOPAL-GENERATOR-TAKE-WHILE-001`, and
`TOPAL-GENERATOR-COLLECT-001` for compiler increment 5c.

## TOPAL-COMP-GENERATOR-ITERATE-FOREACH-001 — Bounded iterate traversal

The checked compiler shall admit a root `foreach` statement that consumes an
exact `Generator Int Unit Unit` retained from an Int-literal `iterate` with
capture-free unary `Int -> Int` next and `Int -> Boolean` `take-while`
operations. Its capture-free body shall bind the accepted Int and produce Unit.
The statement may bind its Unit result, optionally classified as Unit, or leave
that result unnamed.

Every candidate shall be tested once before visitation. Each accepted candidate
shall execute the body once and only then invoke next once. The first rejected
candidate shall execute neither body nor next, and traversal shall return Unit.
The source Generator shall be consumed through the existing local linearity
boundary. Dynamic initial values, unbounded or differently constructed
Generators, and captures in next, predicate, or body shall be rejected before
LLVM.

The Linux x86-64 backend shall carry the current arbitrary-precision Int as
explicit LLVM SSA loop state and emit direct predicate, body, and next blocks.
This required O0 semantic lowering shall expose the current body binding and
Unit result through DWARF/GDB, allocate no traversal collection or Generator
object, use no construction token as state, host recursion, callback, indirect
call, or generic Generator runtime, and introduce no foreign dependency,
C/C++ runtime, other-language standard library, needed library, dynamic
relocation, public/library Generator ABI, or `topal-native/6` revision. Future
library metadata shall identify canonical Generator, operation/predicate/body,
evidence, capture-layout, ownership, and target-adapter identities rather than
this specialization. This realizes
`TOPAL-COMPILER-GENERATOR-ITERATE-FOREACH-001`,
`TOPAL-GENERATOR-ITERATE-001`, `TOPAL-GENERATOR-TAKE-WHILE-001`, and
`TOPAL-GENERATOR-ITERATE-FOREACH-001` for compiler increment 5f.

## TOPAL-COMP-GENERATOR-SINGLE-YIELD-001 — Closed custom suspension

The checked compiler shall admit one root custom generator declaration with
one ordinary Character input, Character yield, Unit resume, and Unit final
result when its body is exactly one discarded yield of that input followed by
Unit. Applying the declaration shall evaluate and classify the initial operand
once, start a fresh linear Generator, retain the declaration identity and exact
yield as compile-session provenance, and expose the first suspension before
later source execution. The admitted exact body has no later computation.

Root foreach shall consume one locally bound instance, invoke its capture-free
Character-to-Unit action exactly once with the yielded Character, resume with
Unit, and return the distinct final Unit. The source shall use the existing
one-consumption local Generator boundary; repeated use and abandonment other
than the exact function-scope close admitted by
`TOPAL-COMP-GENERATOR-CLOSE-001` shall remain rejected. Declaration shapes not
covered by a later compiler rule, overloads, dynamic Character provenance,
direct traversal without a retained local, non-Unit actions, captures, and
function transfer except for the exact result admitted by
`TOPAL-COMP-CUSTOM-GENERATOR-RESULT-001` or library transfer boundaries shall be
rejected before LLVM.

The Linux x86-64 backend shall evaluate the initial Character once, lower the
proven single suspension and resumption as ordered inline code, and use the
compiler-private Generator observation token only for ownership and debugging,
not continuation state. This required O0 source-semantic lowering shall expose
the Generator and yielded Character bindings through DWARF/GDB. It shall add no
Generator object, state allocation, dispatcher, callback, indirect call,
unwind support, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library Generator ABI, or `topal-native/6` revision.
Future compiled-library metadata shall carry the canonical declaration,
Generator directions, suspension points, capture/effect evidence, ownership,
close behavior, and target-adapter identities rather than this specialization.
This realizes `TOPAL-COMPILER-GENERATOR-SINGLE-YIELD-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5g.

## TOPAL-COMP-GENERATOR-MULTIPLE-YIELD-001 — Repeated custom suspensions

The checked compiler shall generalize the admitted root Character generator to
one or more consecutive discarded yields of its sole initial Character followed
by final Unit. It shall retain the exact source-ordered yield sequence as
compile-session provenance. Application shall still evaluate the initial
operand exactly once and stop at the first suspension; each successful Unit
resumption shall advance to the next retained yield or the final Unit.

Root foreach shall consume one locally bound instance and invoke its
capture-free Character-to-Unit action exactly once for each yielded value in
source order. It shall resume with Unit after every action, including the final
action before returning Unit. Existing repeated-use and abandonment rejection
shall continue to apply. Exact pre-yield Unit completion is governed by
`TOPAL-COMP-GENERATOR-EARLY-RETURN-001`; ordinary statements between yields
other than the exact local activation admitted by
`TOPAL-COMP-GENERATOR-SUSPENSION-001`, different yield expressions, overloads,
dynamic Character provenance, captures, close handling, and function or
library boundaries shall remain rejected before LLVM.

The Linux x86-64 backend shall expand the finite proven sequence as ordered
inline action blocks with an erased Unit resumption between adjacent blocks.
This is mandatory O0 semantic lowering, not loop unrolling delegated to LLVM.
The existing compiler-private Generator observation token and debug-only
Character shadow may be reused, but no token shall act as continuation state.
Generated code shall add no Generator object or state allocation, dispatcher,
callback, indirect call, unwind support, C/C++ runtime, other-language standard
library, needed library, dynamic relocation, public/library Generator ABI, or
`topal-native/6` revision. Future compiled-library metadata shall describe the
ordered suspension graph and its canonical declaration/direction, effect,
ownership, close, and target-adapter evidence. This realizes
`TOPAL-COMPILER-GENERATOR-MULTIPLE-YIELD-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5h.

## TOPAL-COMP-GENERATOR-LOCAL-BINDING-001 — Exact local Character state

The checked compiler shall admit the existing custom Character generator when
its body begins with exactly one explicitly classified, immutable Character
binding whose value is the sole initial Character parameter, followed by one
or more consecutive discarded yields of that local and final Unit. Application
shall evaluate the initial operand once, evaluate the alias binding in the
generator scope before the first suspension, and retain the local identity and
exact Character value as compile-session provenance. The local shall remain
available to every retained yield and shall never enter the caller's checked
environment.

Root foreach shall preserve the existing linear consumption and ordered
action/Unit-resumption behavior. The Linux x86-64 backend shall materialize the
proven immutable Character value and expose a debug-only pointer shadow for the
local in a generator lexical DWARF scope before the first action. That shadow
may persist across the admitted yields but shall be out of scope after the
traversal. This mandatory O0 lowering shall not depend on optimization or
introduce a semantic continuation object, state allocation, dispatcher,
callback, indirect call, unwind support, C/C++ runtime, other-language standard
library, needed library, dynamic relocation, public/library Generator ABI, or
`topal-native/6` revision.

Unclassified or differently classified locals, non-identity initializers,
additional statements not admitted by `TOPAL-COMP-GENERATOR-SUSPENSION-001`,
dynamic Character provenance, captures, resume bindings other than the exact
Unit success binding admitted by `TOPAL-COMP-GENERATOR-RESUME-BINDING-001`,
close handling, and function or library boundaries shall remain rejected
before LLVM. Future compiled-library metadata shall encode
canonical local-state identities and types with the declaration, suspension
graph, directions, captures/effects, ownership/close behavior, and target
adapters rather than serialize this executable-local debug shadow. This
realizes `TOPAL-COMPILER-GENERATOR-LOCAL-BINDING-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-LOCAL-BINDING-001`,
`TOPAL-GENERATOR-SUSPEND-001`, and `TOPAL-GENERATOR-FOREACH-001` for compiler
increment 5i.

## TOPAL-COMP-GENERATOR-EARLY-RETURN-001 — Completion before suspension

The checked compiler shall admit the existing root custom Character generator
directions when the complete body is exactly final Unit and therefore reaches
its declared Unit result before any yield. Application shall evaluate and
classify the initial Character exactly once, create a fresh linear Generator,
and retain an empty suspension sequence plus completed Unit as compile-session
provenance. The absence of a yield shall not skip static checking of the
Character-to-Unit foreach action.

Root foreach shall consume one locally bound admitted instance, invoke the
action zero times, and produce the generator's final Unit directly. Repeated
use and abandonment shall remain rejected under the existing local linearity
boundary. Additional body statements, generator locals, explicit return, other
input/yield/resume/result classifiers, non-Unit final values, overloads,
captures, close handling, and function or library boundaries shall remain
rejected before LLVM unless another compiler rule admits them.

On Linux x86-64, the backend shall evaluate the initial Character once and
lower the empty suspension sequence and final Unit with no action block or
action-parameter debug storage. The compiler-private Generator observation
token may remain for ownership and GDB identity, but shall not represent a
continuation state. This mandatory O0 lowering shall not depend on dead-code
elimination or introduce a Generator object, state allocation, dispatcher,
callback, indirect call, unwind support, C/C++ runtime, other-language standard
library, needed library, dynamic relocation, public/library Generator ABI, or
`topal-native/6` revision. Future compiled-library metadata shall encode the
terminal-before-suspension graph, final value, directions, ownership/close
behavior, and target adapters canonically. This realizes
`TOPAL-COMPILER-GENERATOR-EARLY-RETURN-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-EARLY-RETURN-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5j.

## TOPAL-COMP-GENERATOR-FINAL-CHARACTER-001 — Distinct final Character

The checked compiler shall admit one root custom generator with a Character
input, Character yield, Unit resume, and Character final result when its body
is exactly one discarded yield of the initial parameter followed by an exact
closed Character literal. Application shall evaluate the initial Character
once, retain the yielded value and separate final value as compile-session
provenance, and stop at the yield without evaluating the final expression.

Direct root foreach over one locally bound admitted instance shall consume the
Generator, invoke its checked Character-to-Unit action exactly once with the
yielded Character, resume with Unit, then evaluate and produce the distinct
final Character. The final expression shall not be emitted before the action
and resumption. Existing repeated-use and abandonment rejection shall continue
to apply. Binding the non-Unit foreach result, zero or multiple yields, a local
alias, dynamic or non-Character final expressions, other directions, overloads,
captures, close handling, and function or library boundaries shall remain
rejected before LLVM.

On Linux x86-64, the backend shall lower the yield/action/resume sequence and
final Character materialization in that explicit order at O0. It may retain
the compiler-private Generator observation token and existing debug-only
yielded-Character shadow, but neither shall carry the final value or act as
continuation state. Generated DWARF shall expose the full
`Generator Character Unit Character` direction identity and yielded Character
to GDB. The lowering shall introduce no Generator object, state allocation,
dispatcher, callback, indirect call, unwind support, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library Generator ABI, or `topal-native/6` revision. Future
compiled-library metadata shall encode the result classifier and final-value
node alongside canonical declaration, direction, suspension, effect,
ownership/close, and target-adapter evidence. This realizes
`TOPAL-COMPILER-GENERATOR-FINAL-CHARACTER-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-FINAL-RETURN-001`,
`TOPAL-GENERATOR-SUSPEND-001`, and `TOPAL-GENERATOR-FOREACH-001` for compiler
increment 5k.

## TOPAL-COMP-GENERATOR-SUSPENSION-001 — Post-resume local activation

The checked compiler shall admit the Unit-final custom Character-generator
subset when its body contains one or more discarded yields of the sole initial
Character, then exactly one explicitly classified immutable Character binding
initialized from that initial parameter, one or more discarded yields of the
local, and final Unit. It shall retain the local identity, classifier, source
span, exact Character value, and the number of successful resumptions before
activation. Starting the generator shall stop at its first yield and shall not
evaluate the post-yield binding.

Direct root foreach over one locally bound admitted instance shall consume the
Generator, complete each prefix action and Unit resumption, activate the local
only after the last prefix resumption, then observe the local yields in source
order before final Unit. The local shall remain absent from the caller's
checked environment. A local without a later yield, a second local, a
non-identity initializer, a yield of the wrong active value, other ordinary
statements, dynamic Character provenance, captures, resume bindings other than
the exact Unit success binding admitted by
`TOPAL-COMP-GENERATOR-RESUME-BINDING-001`, close handling, and function or
library boundaries shall remain rejected before LLVM.

On Linux x86-64, the backend shall emit the completed prefix action and erased
Unit resumption before local materialization and its lexical DWARF declaration,
then emit that declaration before the next yield action at O0. The checked
resumption count shall guide source-order expansion but shall not become a
runtime program counter or public layout. This lowering shall not depend on
optimization or introduce a Generator object, semantic continuation state,
dispatcher, callback, indirect call, unwind support, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library Generator ABI, or `topal-native/6` revision. Future
compiled-library metadata shall identify each local activation transition
canonically with the declaration, directions, ordered suspension graph,
captures/effects, ownership/close behavior, and target adapters. This realizes
`TOPAL-COMPILER-GENERATOR-SUSPENSION-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-BODY-STATEMENT-001`,
`TOPAL-GENERATOR-LOCAL-BINDING-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5l.

## TOPAL-COMP-GENERATOR-RESUME-BINDING-001 — Exact Unit resumption

The checked compiler shall admit the root custom
`Generator Character Unit Unit` subset when its body is exactly one named,
optionally Unit-classified binding of `yield` applied to the sole initial
Character, followed by that binding as the final Unit expression. It shall
retain the yielded Character and a distinct Unit local whose activation follows
one successful resumption. Starting the generator shall stop at the yield
without introducing or evaluating the resume binding.

Direct root foreach over one locally bound admitted instance shall consume the
Generator, invoke its Character-to-Unit action once, resume with Unit, make
that Unit available under the generator-local name, and only then use it as the
final result. The name shall remain absent from the caller's checked
environment. A wrong or discarded binding name, non-Unit classifier, different
yielded value, additional yield or body statement, different final expression,
dynamic Character provenance, captures, close handling, and function or
library boundaries shall remain rejected before LLVM.

On Linux x86-64, the backend shall emit the action before a debug-only `i8`
shadow for the successfully resumed Unit and expose that binding as Unit to GDB
at its source line at O0. The erased success value shall not create semantic
continuation state or conflate ordinary Unit resumption with the distinct
`generator-closed` close edge. The lowering shall not depend on optimization or
introduce a Generator object, state machine, dispatcher, callback, indirect
call, unwind support, C/C++ runtime, other-language standard library, needed
library, dynamic relocation, public/library Generator ABI, or `topal-native/6`
revision. Future compiled-library metadata shall encode success and close
edges, resume-local activation, the declaration and directions, suspension
identity, captures/effects, ownership/close behavior, and target adapters
canonically. This realizes `TOPAL-COMPILER-GENERATOR-RESUME-BINDING-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-GENERATOR-RESUME-BINDING-001`, and `TOPAL-GENERATOR-FOREACH-001` for
compiler increment 5m.

## TOPAL-COMP-GENERATOR-CLOSE-001 — Exact function-scope abandonment

The checked compiler shall admit one call-specialized ordinary function whose
body binds one fresh instance of the exact single-yield custom
`Generator Character Unit Unit` and then reaches final Unit without consuming
it. The initial Character shall retain its exact caller provenance. Function
scope exit shall consume the suspended Generator, deliver `generator-closed`
with lexical domain `root`, retain the root generator declaration as separate
provenance, and complete the handler-free generator boundary before returning
Unit.

The checked function body shall contain an explicit custom close after the
Generator binding and before its final expression. Root abandonment, multiple
owned generators, multiple yields, generator locals, and close handlers or
other post-yield work except for the exact handler admitted by
`TOPAL-COMP-GENERATOR-CLOSE-HANDLER-001`, dynamic Character provenance without
call specialization, static or anonymous functions, explicit return, non-Unit
final results, Generator parameter/result transfer, and library boundaries
shall remain rejected before LLVM.

On Linux x86-64, the backend may erase the intrinsic close value and final Unit
for this handler-free, effect-free body after preserving their checked O0
order; the expected close signal has no source observer at the generator
boundary. The compiler-private ownership/debug token shall be consumed
conceptually and remain visible as `Generator Character Unit Unit` in the
function's DWARF scope. The lowering shall not introduce a Generator object,
continuation state, close dispatcher, callback, indirect call, unwind support,
C/C++ runtime, other-language standard library, needed library, dynamic
relocation, public/library Generator ABI, or `topal-native/6` revision. Future
compiled-library metadata shall encode the close site and lexical domain,
generator declaration provenance, close/success edges, suspension identity,
cleanup/effect evidence, ownership state, and target adapters canonically.
This realizes `TOPAL-COMPILER-GENERATOR-CLOSE-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-CLOSE-001`, and
`TOPAL-GENERATOR-ERROR-CODE-001` for compiler increment 5n.

## TOPAL-COMP-GENERATOR-CLOSE-HANDLER-001 — Exact close-result handling

The checked compiler shall generalize the admitted function-local custom close
to one root generator declaration whose body binds its sole Character yield
result and immediately selects a complete `Error`/`Ok` decision with Unit
actions. The checked generator construction shall retain the yield-result
binding, Error and Ok binding identities and spans, both branch actions, and
the nominal `lang generator GeneratorErrorCode` set containing
`generator-closed`.

When the exact generator is abandoned by the admitted ordinary Unit function,
its checked close shall deliver
`Error(domain = root, code = generator-closed)`, select and execute only the
Error action, finish the generator boundary, and then return the function's
final Unit. The successful Unit-resume action shall remain explicit metadata but
shall not execute on this close edge. Root abandonment, successful foreach,
qualified close-code patterns except for the exact matcher admitted by
`TOPAL-COMP-GENERATOR-CLOSE-CODE-PATTERN-001`, non-Unit handler actions, handler
work beyond the exact decision, multiple yields or owners, generator locals,
dynamic provenance, transfer boundaries, and library boundaries shall remain
rejected before LLVM.

On Linux x86-64, O0 lowering shall materialize the intrinsic failure through
Topal-owned Result/Error and allocator primitives, statically select its Error
payload, and preserve source order independently of LLVM optimization. DWARF
shall expose the yield Result and selected Error with the generator Error-code
vocabulary so GDB renders `generator-closed`, not an unrelated nominal code.
The lowering shall not introduce a Generator object, continuation state, close
dispatcher, callback, indirect call, unwind dependency, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library Generator ABI, or `topal-native/6` revision. Future
compiled-library metadata shall encode handler branches and binding activation
together with the close site/domain, declaration provenance, success/close
edges, suspension, cleanup/effect evidence, ownership state, and target adapters
canonically. This realizes `TOPAL-COMPILER-GENERATOR-CLOSE-HANDLER-001`,
`TOPAL-GENERATOR-CLOSE-HANDLER-001`, `TOPAL-GENERATOR-CLOSE-001`, and
`TOPAL-GENERATOR-ERROR-CODE-001` for compiler increment 5o.

## TOPAL-COMP-GENERATOR-CLOSE-CODE-PATTERN-001 — Qualified close-code selection

The checked compiler shall generalize the admitted exact close handler to one
qualified `Error ( code is lang generator generator-closed )` Unit rule before
its generic Error fallback, together with the complete Ok Unit rule. The
checked handler shall retain the qualified rule's nominal code-set identity,
alternative, source span, and action separately from the generic Error
binding/action and Ok binding/action.

For the statically known close edge, the backend shall select and execute only
the qualified code action. Selection shall use the nominal
`lang generator GeneratorErrorCode.generator-closed` identity, not the lexical
Error domain or generator declaration provenance. The generic Error fallback
binding and Ok binding shall remain inactive. O0 lowering may resolve this known
selection directly without a runtime decision switch, but shall still
materialize the Topal-owned Result/Error failure and preserve the nominal code
observation and action source location for GDB.

Other qualified codes or vocabularies, code rules after the generic Error
fallback, missing fallbacks, multiple qualified rules, non-Unit actions,
successful traversal, dynamic close results, multiple yields or owners,
transfer boundaries, and library boundaries shall remain rejected before LLVM.
The lowering shall not add a Generator object, continuation state, dispatcher,
callback, indirect call, unwind dependency, C/C++ runtime, other-language
standard library, needed library, dynamic relocation, public/library Generator
ABI, or `topal-native/6` revision. Future compiled-library metadata shall
preserve ordered nominal code matchers and actions together with fallback
bindings, success/close edges, domain and declaration provenance, suspension,
cleanup/effect evidence, ownership state, and target adapters canonically. This
realizes `TOPAL-COMPILER-GENERATOR-CLOSE-CODE-PATTERN-001`,
`TOPAL-GENERATOR-CLOSE-CODE-PATTERN-001`,
`TOPAL-GENERATOR-CLOSE-HANDLER-001`, and `TOPAL-DECISION-ERROR-CODE-001` for
compiler increment 5p.

## TOPAL-COMP-CUSTOM-GENERATOR-RESULT-001 — Specialized custom continuation result

The checked compiler shall admit an ordinary nonrecursive called function with
exactly one named Character parameter and result classifier
`Generator Character Unit Unit` when its statement-free body returns a fresh
instance of the exact single-yield custom generator admitted by
`TOPAL-COMP-GENERATOR-SINGLE-YIELD-001`, applied directly to that parameter. The
top-level call argument shall retain one exact Character. Function exit shall
transfer the fresh suspended continuation without close delivery; the caller
shall bind and consume it exactly once through the admitted root Character
foreach.

Each call shall create a distinct private specialization. The checked program
shall retain the generator declaration, exact Character, suspension/final
graph, and ownership transfer as provenance associated with that private
symbol. The caller shall evaluate its Character argument once. The callee shall
return the compiler-private Generator token, and caller traversal shall invoke
the Character-to-Unit action once, resume with Unit, and finish with Unit using
only that call's retained provenance. Distinct calls shall not share provenance.

On Linux x86-64, LLVM `fastcc` shall choose placement for the private Character
descriptor parameter and `i32` Generator result; the backend shall hard-code no
System V register placement. A debug-only Character parameter shadow shall keep
the source value inspectable through function return. DWARF and GDB shall expose
the Character parameter, Generator result classifier/value, caller traversal
Character, and both call frames.

Static, anonymous, recursive, nested, multiple-parameter, statement-bearing,
non-parameter-derived, multiple-yield, local-state, handled-close, unbound-result,
caller-close, and library paths shall remain rejected before LLVM. The lowering
shall introduce no Generator object or state allocation, dispatcher, callback,
indirect call, unwind dependency, C/C++ runtime, other-language standard
library, needed library, dynamic relocation, public/library calling convention
or Generator ABI, or `topal-native/6` revision. Future compiled-library metadata
shall encode the canonical declaration and directions, suspension/final graph,
construction evidence, capture/effect evidence, transfer/ownership/close state,
and target adapters rather than expose the compiler-session side table or
private token. This realizes `TOPAL-COMPILER-CUSTOM-GENERATOR-RESULT-001`,
`TOPAL-GENERATOR-FUNCTION-RESULT-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5q.

## TOPAL-COMP-CUSTOM-GENERATOR-PARAMETER-001 — Specialized custom continuation parameter

The checked compiler shall admit a top-level call to an ordinary nonrecursive
function with exactly one named `Generator Character Unit Unit` parameter and
Unit result when the argument is a named root binding constructed by the exact
single-yield custom generator admitted by
`TOPAL-COMP-GENERATOR-SINGLE-YIELD-001`. The function's executable body shall
consist only of one Character foreach over that parameter with a
Character-to-Unit action and final Unit. Argument evaluation shall transfer the
suspended continuation, consume the caller binding, and make the parameter its
sole owner. Successful traversal shall invoke the action once, resume with Unit,
reach final Unit, and return without close delivery.

Each call shall create a distinct private specialization. The checked program
shall map that call's retained declaration, exact Character, suspension/final
graph, and ownership edge to the parameter only while checking its body, then
restore the surrounding compiler-session provenance. Distinct calls shall not
share Characters or continuation provenance, and a caller shall not reuse the
consumed binding.

On Linux x86-64, LLVM `fastcc` shall choose placement for the private `i32`
Generator token parameter; the backend shall hard-code no System V register
placement. DWARF and GDB shall expose the Generator parameter, yielded Character,
and caller/callee frames. The token shall carry no public or semantic
continuation state.

Static, anonymous, recursive, nested, multiple-parameter, additional-body,
direct-expression-argument, multiple-yield, local-state, handled-close,
unconsumed-parameter, returned-parameter, repeated-use, and library paths shall
remain rejected before LLVM. The lowering shall introduce no Generator object
or state allocation, dispatcher, callback, indirect call, unwind dependency,
C/C++ runtime, other-language standard library, needed library, dynamic
relocation, public/library calling convention or Generator ABI, or
`topal-native/6` revision. Future compiled-library metadata shall encode the
canonical declaration and directions, suspension/final graph, construction
evidence, parameter transfer site, capture/effect evidence,
ownership/consumption/close state, action evidence, and target adapters rather
than expose the compiler-session side table or private token. This realizes
`TOPAL-COMPILER-CUSTOM-GENERATOR-PARAMETER-001`,
`TOPAL-GENERATOR-FUNCTION-PARAMETER-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5r.

## TOPAL-COMP-CUSTOM-GENERATOR-PARAMETER-CLOSE-001 — Closing a transferred custom parameter

The checked compiler shall extend the exact custom Generator parameter
specialization of `TOPAL-COMP-CUSTOM-GENERATOR-PARAMETER-001` to a
statement-free Unit function body that leaves the transferred parameter
unconsumed. Function exit shall consume and close that same suspended
continuation. The caller binding shall remain consumed, and neither caller nor
callee shall subsequently traverse or resume it.

The checked close node shall retain the callee parameter together with the
call-specialized custom construction provenance: declaration identity, exact
Character, directions, suspension/final graph, and ownership edge. Its close
domain shall be the lexical root namespace of the admitted function, separate
from the qualified generator declaration provenance. Distinct calls shall retain
distinct close provenance.

Because the admitted yield result is discarded and the exact continuation has
no handler, local state, cleanup, effect, or work after suspension, O0 lowering
may erase close delivery and final Unit after proving the explicit close node.
This erasure is semantic lowering, not an LLVM optimization. On Linux x86-64,
LLVM `fastcc` shall choose placement for the private `i32` Generator token
parameter; the backend shall hard-code no System V register placement. DWARF
and GDB shall preserve the Generator parameter and caller/callee frames through
the close edge.

Handled or bound-yield close, multiple yields, local state, cleanup/effects,
non-Unit results, explicit return, additional body statements, traversal before
exit, static/anonymous/recursive/nested/multiple-parameter calls,
direct-expression arguments, repeated caller use, and library paths shall remain
rejected before LLVM. The lowering shall introduce no Generator object or state
allocation, close dispatcher, callback, indirect call, unwind dependency, C/C++
runtime, other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Future compiled-library metadata shall encode the canonical
declaration and directions, suspension/final graph, construction evidence,
parameter transfer and close sites, lexical close domain,
capture/effect/cleanup evidence, ownership/consumption/close state, and target
adapters rather than expose the compiler-session provenance or private token.
This realizes `TOPAL-COMPILER-CUSTOM-GENERATOR-PARAMETER-CLOSE-001`,
`TOPAL-GENERATOR-FUNCTION-PARAMETER-001`, and `TOPAL-GENERATOR-CLOSE-001` for
compiler increment 5s.

## TOPAL-COMP-CUSTOM-GENERATOR-CHARACTER-RESULT-PARAMETER-001 — Transferred final Character

The checked compiler shall extend the exact custom Generator parameter
specialization of `TOPAL-COMP-CUSTOM-GENERATOR-PARAMETER-001` to one named
`Generator Character Unit Character` parameter and Character function result.
The argument shall be a named root binding of the exact single-yield,
distinct-final-Character generator admitted by
`TOPAL-COMP-GENERATOR-FINAL-CHARACTER-001`. The function body shall be exactly
a result-valued Character foreach over that parameter with a
Character-to-Unit action. Argument evaluation shall consume the caller binding
and transfer sole ownership to the callee.

Successful traversal shall invoke the action once with the retained yielded
Character, resume with Unit, evaluate the separately retained final Character,
and return that final Character as the ordinary function result. It shall not
deliver close. The checked program shall preserve the exact Generator
classifier, declaration, yield and final values, suspension/resumption order,
action, and ownership transfer for each private call specialization. Distinct
calls shall not share yielded or final provenance, and the caller shall not
reuse the consumed Generator binding.

On Linux x86-64, LLVM `fastcc` shall choose placement for the private `i32`
Generator token parameter and ordinary Character descriptor result; the
backend shall hard-code no System V register or return placement. O0 lowering
shall expand the action and Unit resumption before materializing and returning
the final Character, independently of LLVM optimization. DWARF and GDB shall
expose the complete Generator classifier, callee-owned parameter, yielded
Character, final Character result, and caller/callee frames.

Static, anonymous, recursive, nested, multiple-parameter, additional-body,
direct-expression-argument, multiple-yield, generator-local, handled or
unconsumed, alternate-result, repeated-use, returned-continuation, and library
paths shall remain rejected before LLVM. The lowering shall introduce no
Generator object or state allocation, dispatcher, callback, indirect call,
unwind dependency, C/C++ runtime, other-language standard library, needed
library, dynamic relocation, public/library calling convention or Generator
ABI, or `topal-native/6` revision. Future compiled-library metadata shall
encode the canonical classifier and directions, declaration, distinct
yield/final graph, construction and parameter-transfer sites, action,
capture/effect evidence, ownership/consumption/close state, and target adapters
rather than expose the compiler-session specialization or private token. This
realizes
`TOPAL-COMPILER-CUSTOM-GENERATOR-CHARACTER-RESULT-PARAMETER-001`,
`TOPAL-GENERATOR-FUNCTION-PARAMETER-001`,
`TOPAL-GENERATOR-FINAL-RETURN-001`, and `TOPAL-GENERATOR-FOREACH-001` for
compiler increment 5t.

## TOPAL-COMP-CUSTOM-GENERATOR-CHARACTER-RESULT-001 — Returning a continuation with final Character

The checked compiler shall extend the exact custom Generator result
specialization of `TOPAL-COMP-CUSTOM-GENERATOR-RESULT-001` to an ordinary
nonrecursive function whose result classifier is
`Generator Character Unit Character`. The function shall have exactly one
named Character parameter and a statement-free body that directly applies the
exact single-yield, distinct-final-Character generator admitted by
`TOPAL-COMP-GENERATOR-FINAL-CHARACTER-001` to that parameter. The top-level call
shall supply one exact Character and bind the returned continuation before
consuming it.

Function exit shall transfer the fresh continuation without close delivery.
The checked program shall associate the generator declaration, exact yielded
and final Characters, suspension/resumption graph, and ownership transfer with
the private call specialization. Caller traversal shall invoke the
Character-to-Unit action once, resume with Unit, then produce the separately
retained final Character. The caller binding shall be consumed exactly once,
and no result provenance shall be shared with another private specialization.

On Linux x86-64, LLVM `fastcc` shall choose placement for the ordinary
Character descriptor parameter and private `i32` Generator result; the backend
shall hard-code no System V register or return placement. The factory shall
return only the private ownership token. O0 caller lowering shall expand the
retained action and Unit resumption before materializing the final Character,
independently of LLVM optimization. DWARF and GDB shall expose the Character
factory parameter, complete Generator return classifier and value, yielded
Character, and caller/factory frames.

Static, anonymous, recursive, nested, multiple-parameter, statement-bearing,
non-parameter-derived, multiple-yield, generator-local, handled-close,
unbound-result, caller-close, parameter-transfer composition, repeated-use, and
library paths shall remain rejected before LLVM. The lowering shall introduce
no Generator object or state allocation, dispatcher, callback, indirect call,
unwind dependency, C/C++ runtime, other-language standard library, needed
library, dynamic relocation, public/library calling convention or Generator
ABI, or `topal-native/6` revision. Future compiled-library metadata shall encode
the canonical classifier and directions, declaration, distinct yield/final
graph, construction and function-result transfer sites, action, capture/effect
evidence, ownership/consumption/close state, and target adapters rather than
expose the compiler-session returned-provenance table or private token. This
realizes `TOPAL-COMPILER-CUSTOM-GENERATOR-CHARACTER-RESULT-001`,
`TOPAL-GENERATOR-FUNCTION-RESULT-001`, `TOPAL-GENERATOR-FINAL-RETURN-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5u.

## TOPAL-COMP-GENERATOR-STRING-INPUT-001 — Independent String initial input

The checked compiler shall admit a root custom generator whose one named
initial parameter is String while its directions are
`Generator Character Unit Unit`. Its body shall bind the result of
`empty? initial` to one named Boolean before one discarded yield of an exact
Character literal and a final Unit expression. One currently admitted String
expression shall start the generator, and the fresh result shall be bound and
consumed exactly once by a Character-to-Unit foreach action.

The checked program shall retain the String parameter independently of the
three Generator directions, the ordered pre-suspension block and Boolean
binding, the exact yielded Character, declaration and suspension spans, final
Unit, and the ownership edge. Generator application shall evaluate the String
operand once and execute its emptiness predicate before exposing the suspended
Generator binding. Traversal shall then invoke the action once, resume with
Unit, and complete with Unit. These steps shall hold with LLVM optimization
disabled and shall not depend on constant folding or dead-code elimination.

On Linux x86-64, the String descriptor and Boolean prefix value shall use the
existing `topal-native/6` representations, while the root-local Generator shall
remain a compiler-private `i32` ownership token. LLVM shall select target data
layout and instruction placement; the backend shall hard-code no AMD64
register convention. DWARF and GDB shall expose the String initial value while
the prefix executes, the Boolean prefix binding metadata, the complete
Generator value, the yielded Character, and the Topal entry frame.

Other initial classifiers, multiple parameters, alternate prefix operations,
unnamed or differently classified prefix bindings, computed or non-Character
yields, multiple yields, non-Unit resume or final directions, local state after
the yield, close handling, nested or ordinary-function construction, Generator
parameter/result transfer, repeated consumption, abandonment, libraries, and
external boundaries shall remain rejected before LLVM. The lowering shall
introduce no Generator object or semantic state allocation, dispatcher,
callback, indirect call, unwind dependency, C/C++ runtime, other-language
standard library, needed library, dynamic relocation, public/library calling
convention or Generator ABI, or `topal-native/6` revision. Future
compiled-library metadata shall encode the initial classifier separately from
all three directions, the ordered pre-suspension operation and binding,
declaration, suspension/yield/final graph, construction/action sites,
capture/effect evidence, ownership/consumption/close state, and target adapters
rather than expose the private token or checked-program node layout. This
realizes `TOPAL-COMPILER-GENERATOR-STRING-INPUT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-GENERATOR-FOREACH-001`, and `TOPAL-STRING-EMPTY-PREDICATE-001` for
compiler increment 5v.

## TOPAL-COMP-GENERATOR-STRING-YIELD-001 — Independent String yield direction

The checked compiler shall admit a root custom generator with one named String
initial parameter and directions `Generator String Unit Unit`. Its body shall
contain one or more consecutive discarded yields, each yielding either that
initial parameter or an exact String literal, followed by a final Unit
expression. One currently admitted String expression shall start the generator,
and the fresh result shall be bound and consumed exactly once by a String-to-Unit
foreach action.

The checked program shall retain the initial classifier separately from the
three Generator directions and shall retain ordered per-yield value provenance,
declaration and suspension spans, final Unit, action, and ownership edge.
Application shall evaluate the initial String expression exactly once. Traversal
shall deliver that retained descriptor for an initial-parameter yield,
materialize each exact literal at its suspension point, invoke the action and
resume with Unit after every yield, and complete with Unit. This source order
shall hold with LLVM optimization disabled and shall not depend on constant
folding, inlining, or dead-code elimination.

On Linux x86-64, yielded values shall use the existing `topal-native/6` String
descriptor while the root-local Generator remains a compiler-private `i32`
ownership token. LLVM shall select target data layout and instruction placement;
the backend shall hard-code no AMD64 register convention. DWARF and GDB shall
expose the complete Generator and each yielded String while its action executes,
plus the Topal entry frame.

Other input, yield, or resume classifiers; final classifiers beyond the exact
String result admitted by `TOPAL-COMP-GENERATOR-FINAL-STRING-001`; multiple
parameters; computed yields; intervening or post-suspension body state beyond
the exact one-discard continuation admitted by
`TOPAL-COMP-GENERATOR-RESUME-DISCARD-001`; close handling; nested or
ordinary-function construction; Generator parameter/result transfer; repeated
consumption; abandonment; libraries; and external boundaries shall remain
rejected before LLVM. The lowering shall introduce no Generator object or
semantic state allocation, dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator ABI, or
`topal-native/6` revision. Future compiled-library metadata shall encode the
initial and direction classifiers independently, ordered per-yield values and
provenance, declaration, suspension/final graph, construction/action sites,
capture/effect evidence, ownership/consumption/close state, and target adapters
rather than expose the private token or checked-program node layout. This
realizes `TOPAL-COMPILER-GENERATOR-STRING-YIELD-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-GENERATOR-FOREACH-001`, and `TOPAL-STRING-EMPTY-PREDICATE-001` for
compiler increment 5w.

## TOPAL-COMP-GENERATOR-FINAL-STRING-001 — Distinct final String

The checked compiler shall admit a root custom generator with one named String
initial parameter and directions `Generator String Unit String`. Its body shall
contain one or more consecutive discarded String yields in the forms admitted
by `TOPAL-COMP-GENERATOR-STRING-YIELD-001`, followed by one exact String literal
as its distinct final expression. One currently admitted String expression
shall start the generator, and the fresh result shall be bound and consumed
exactly once by a String-to-Unit foreach action whose expression result is the
final String.

The checked program shall retain the final String expression and classifier
separately from the initial value, ordered yield provenance, Unit resume
direction, declaration and suspension spans, action, and ownership edge.
Application shall evaluate the initial expression exactly once. Traversal shall
deliver every yield, invoke its action, resume with Unit, and only then
materialize and return the final String. This order shall hold with LLVM
optimization disabled and shall not depend on folding, inlining, or dead-code
elimination.

On Linux x86-64, the input, yielded, and final values shall use the existing
`topal-native/6` String descriptor while the root-local Generator remains a
compiler-private `i32` ownership token. LLVM shall select target data layout and
instruction placement; the backend shall hard-code no AMD64 register
convention. DWARF and GDB shall expose the complete
`Generator String Unit String` classifier and value, the yielded String during
its action, the final expression source location, and the Topal entry frame.

Nonliteral or initial-derived final values; other input, yield, resume, or final
classifiers; multiple parameters; computed yields; intervening body state;
close handling; nested or ordinary-function construction; Generator
parameter/result transfer; repeated consumption; abandonment; libraries; and
external boundaries shall remain rejected before LLVM. The lowering shall
introduce no Generator object or semantic state allocation, dispatcher,
callback, indirect call, unwind dependency, C/C++ runtime, other-language
standard library, needed library, dynamic relocation, public/library calling
convention or Generator ABI, or `topal-native/6` revision. Future
compiled-library metadata shall encode the initial and direction classifiers
independently, ordered yield provenance, the distinct final-value expression
and provenance, declaration, suspension/final graph, construction/action sites,
capture/effect evidence, ownership/consumption/close state, and target adapters
rather than expose the private token or checked-program node layout. This
realizes `TOPAL-COMPILER-GENERATOR-FINAL-STRING-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-GENERATOR-FINAL-RETURN-001`, and `TOPAL-GENERATOR-FOREACH-001` for
compiler increment 5x.

## TOPAL-COMP-GENERATOR-RESUME-DISCARD-001 — Post-resume discarded computation

The checked compiler shall admit a root custom generator with one named String
initial parameter and directions `Generator String Unit Unit` whose body
extends the yield forms of `TOPAL-COMP-GENERATOR-STRING-YIELD-001` with exactly
one discarded `empty? initial` computation. At least one yield shall precede
that computation and at least one yield shall follow it. The body shall end in
Unit. One currently admitted String expression shall start the generator, and
the fresh result shall be bound and consumed exactly once by a String-to-Unit
foreach action.

The checked program shall retain the computation as a typed continuation block
with its source span and exact successful-resumption ordinal, separately from
the initial value, ordered yield provenance, action, final Unit, and ownership
edge. Application shall evaluate the initial expression exactly once. Traversal
shall deliver and act on each preceding yield, resume it with Unit, execute the
discarded emptiness computation against the captured initial String, and only
then reach the following suspension. This order shall hold with LLVM
optimization disabled and shall not depend on folding, inlining, or dead-code
elimination.

On Linux x86-64, the initial and yielded values shall use the existing
`topal-native/6` String descriptor while the root-local Generator remains a
compiler-private `i32` ownership token. LLVM shall select target data layout and
instruction placement; the backend shall hard-code no AMD64 register
convention. DWARF and GDB shall expose the complete
`Generator String Unit Unit` classifier and value, each yielded String during
its action, the captured initial String during the post-resume computation, its
source location, and the Topal entry frame.

Bindings, more than one continuation computation, a computation before the
first or after the final yield, operands other than the initial parameter,
computed continuation expressions, non-Unit final values, other input, yield,
or resume classifiers, close handling, nested or ordinary-function
construction, Generator parameter/result transfer, repeated consumption,
abandonment, libraries, and external boundaries shall remain rejected before
LLVM. The lowering shall introduce no Generator object or semantic state
allocation, dispatcher, callback, indirect call, unwind dependency, C/C++
runtime, other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Future compiled-library metadata shall encode the initial and
direction classifiers independently, ordered yields, the continuation block
and successful-resumption ordinal, expression provenance and source sites,
declaration/suspension/final graph, action, capture/effect evidence,
ownership/consumption/close state, and target adapters rather than expose the
private token or checked-program node layout. This realizes
`TOPAL-COMPILER-GENERATOR-RESUME-DISCARD-001`,
`TOPAL-GENERATOR-BODY-STATEMENT-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5y.

## TOPAL-COMP-GENERATOR-EXPLICIT-RETURN-001 — Explicit return before suspension

The checked compiler shall admit a root custom generator with one named String
initial parameter and directions `Generator String Unit String` whose body
consists only of `return` applied to one exact String literal. One currently
admitted String expression shall start the generator, and the fresh result
shall be bound and consumed exactly once by a String-to-Unit foreach action
whose expression result is the explicitly returned String.

The checked program shall distinguish the explicit-return keyword and source
site from the typed String result expression, implicit final expressions,
empty ordered yield/continuation lists, action, and ownership edge. Application
shall evaluate the initial expression exactly once even when the return does
not reference it. Traversal shall recognize completion before the first
suspension, invoke the foreach action zero times, and directly materialize and
return the exact String. This order shall hold with LLVM optimization disabled
and shall not depend on folding, inlining, or dead-code elimination.

On Linux x86-64, the initial and returned values shall use the existing
`topal-native/6` String descriptor while the root-local Generator remains a
compiler-private `i32` ownership token. A debug-only pointer shadow may keep
the in-scope initial parameter inspectable without becoming semantic Generator
state. LLVM shall select target data layout and instruction placement; the
backend shall hard-code no AMD64 register convention. DWARF and GDB shall
expose the complete `Generator String Unit String` classifier and value, the
initial String at the explicit-return source location, and the Topal entry
frame. They shall not fabricate a yielded action value when no suspension is
reached.

Implicit zero-yield final expressions, nonliteral or initial-derived returns,
explicit return after a suspension beyond the exact case admitted by
`TOPAL-COMP-GENERATOR-RETURN-AFTER-YIELD-001`, Unit or other return classifiers,
additional body statements, multiple parameters, other input, yield, or resume
classifiers, close handling, nested or ordinary-function construction,
Generator parameter/result transfer, repeated consumption, abandonment,
libraries, and external boundaries shall remain rejected before LLVM. The
lowering shall introduce no Generator object or semantic state allocation,
dispatcher, callback, indirect call, unwind dependency, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Future compiled-library metadata shall encode explicit versus
implicit completion, return expression and keyword provenance, reachability
and empty-yield evidence, independent initial and direction classifiers,
declaration/construction/action sites, captures/effects,
ownership/consumption/close state, and target adapters rather than expose the
private token, debug shadow, or checked-program node layout. This realizes
`TOPAL-COMPILER-GENERATOR-EXPLICIT-RETURN-001`,
`TOPAL-GENERATOR-EXPLICIT-RETURN-001`, `TOPAL-GENERATOR-FINAL-RETURN-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5z.

## TOPAL-COMP-GENERATOR-RETURN-AFTER-YIELD-001 — Explicit return after resumption

The checked compiler shall admit a root custom generator with one named String
initial parameter and directions `Generator String Unit String` whose body
consists only of one discarded `yield initial` followed by `return` applied to
one exact String literal. One currently admitted String expression shall start
the generator, and the fresh result shall be bound and consumed exactly once by
a String-to-Unit foreach action whose expression result is the explicitly
returned String.

The checked program shall retain the initial-parameter yield and suspension,
the explicit-return keyword and source site, and the typed final String as
separate ordered provenance. Application shall evaluate the initial expression
exactly once. Traversal shall invoke the action exactly once with that retained
String, resume the generator with Unit, and only then materialize and return the
exact String literal. This order shall hold with LLVM optimization disabled and
shall not depend on folding, inlining, or dead-code elimination.

On Linux x86-64, the initial, yielded, and returned values shall use the
existing `topal-native/6` String descriptor while the root-local Generator
remains a compiler-private `i32` ownership token. A debug-only pointer shadow
may keep the initial parameter inspectable at the return site without becoming
semantic Generator state. LLVM shall select target data layout and instruction
placement; the backend shall hard-code no AMD64 register convention. DWARF and
GDB shall expose the complete `Generator String Unit String` classifier and
value, the yielded String during its action, the initial String at the explicit
return, and the Topal entry frame.

Literal or computed yields other than the initial parameter, multiple yields,
nonliteral or initial-derived returns, intervening statements, Unit or other
direction classifiers, multiple parameters, close handling, nested or
ordinary-function construction, Generator parameter/result transfer, repeated
consumption, abandonment, libraries, and external boundaries shall remain
rejected before LLVM. The lowering shall introduce no Generator object or
semantic state allocation, dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator ABI, or
`topal-native/6` revision. Future compiled-library metadata shall encode
explicit completion, ordered yield/resume/return provenance and reachability,
independent initial and direction classifiers, declaration/construction/action
sites, captures/effects, ownership/consumption/close state, and target adapters
rather than expose the private token, debug shadow, or checked-program node
layout. This realizes `TOPAL-COMPILER-GENERATOR-RETURN-AFTER-YIELD-001`,
`TOPAL-GENERATOR-EXPLICIT-RETURN-001`, `TOPAL-GENERATOR-RESUMPTION-001`, and
`TOPAL-GENERATOR-FOREACH-001` for compiler increment 5aa.

## TOPAL-COMP-GENERATOR-BOOLEAN-001 — Boolean generator directions

The checked compiler shall admit a root custom generator with one named
Boolean initial parameter and directions `Generator Boolean Unit Boolean` whose
body consists only of one discarded `yield initial` followed by `not initial`
as its distinct final expression. One currently admitted Boolean expression
shall start the generator, and the fresh result shall be bound and consumed
exactly once by a Boolean-to-Unit foreach action whose expression result is the
final Boolean.

The checked program shall retain the Boolean initial classifier separately
from all three Generator directions, the initial-parameter yield and
suspension, the typed final negation, action, and ownership edge. Application
shall evaluate the initial expression exactly once. Traversal shall invoke the
action exactly once with that retained Boolean, resume the generator with Unit,
and only then evaluate the final negation against the captured initial value.
This order shall hold with LLVM optimization disabled and shall not depend on
folding, inlining, or dead-code elimination.

Unoptimized LLVM IR shall retain the action negation before the final negation.
Mandatory target instruction selection may omit the unused action result only
because Boolean negation is total and effect-free; this shall not generalize to
an action with an observable effect. The independently emitted debug lifetime
anchor shall keep the yielded value inspectable even when no machine
instruction is selected for that pure result.

On Linux x86-64, each Boolean shall use LLVM `i1` in the existing private
`topal-native/6` representation while the root-local Generator remains a
compiler-private `i32` ownership token. A debug-only aligned `i1` stack shadow
may anchor the yielded value's source lifetime without becoming semantic
Generator state. LLVM shall select physical register or stack placement and
instruction selection; the backend shall hard-code no AMD64 register
convention. DWARF and GDB shall expose the complete
`Generator Boolean Unit Boolean` classifier and value, the yielded Boolean in
the foreach action scope, the captured initial Boolean at the final expression,
and the Topal entry frame.

Literal, computed, or multiple yields; a final expression other than
`not initial`; additional body statements; multiple parameters; other input,
yield, resume, or final classifiers; close handling; nested or
ordinary-function construction; Generator parameter/result transfer; repeated
consumption; abandonment; libraries; and external boundaries shall remain
rejected before LLVM. The lowering shall introduce no Generator object or
semantic state allocation, Boolean helper, dispatcher, callback, indirect
call, unwind dependency, C/C++ runtime, other-language standard library,
needed library, dynamic relocation, public/library calling convention or
Generator ABI, or `topal-native/6` revision. Future compiled-library metadata
shall encode independent initial and direction classifiers, ordered Boolean
expression and yield/resume/final provenance, declaration/construction/action
sites, captures/effects, ownership/consumption/close state, and target adapters
rather than expose the private token, debug shadow, or checked-program node
layout. This realizes `TOPAL-COMPILER-GENERATOR-BOOLEAN-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-FOREACH-001`, and
`TOPAL-GENERATOR-FINAL-RETURN-001` for compiler increment 5ab.

## TOPAL-COMP-GENERATOR-INT-001 — Arbitrary-precision Int generator directions

The checked compiler shall admit a root custom generator with one named Int
initial parameter and directions `Generator Int Unit Int` whose body consists
only of one discarded `yield initial` followed by `initial + 1` as its distinct
final expression. One currently admitted Int expression shall start the
generator, and the fresh result shall be bound and consumed exactly once by an
Int-to-Unit foreach action consisting only of a discarded `value + 1`.

The checked program shall retain the Int initial classifier separately from all
three Generator directions, the initial-parameter yield and suspension, both
typed additions and their exact-one operands, action, and ownership edge.
Application shall evaluate the initial expression exactly once. Traversal shall
invoke the action addition exactly once with that retained Int, resume the
generator with Unit, and only then evaluate the final addition against the
captured initial value. Both additions shall use the canonical arbitrary-
precision Int runtime and preserve all values exactly. This order and explicit
allocation-failure behavior shall hold with LLVM optimization disabled and
shall not depend on folding, inlining, or dead-code elimination.

Unoptimized LLVM IR shall retain two direct Int-addition calls in source order.
Unlike the total register-only Boolean action in
`TOPAL-COMP-GENERATOR-BOOLEAN-001`, LLVM shall not omit the discarded Int
action: arbitrary-precision addition can allocate and therefore can reach the
required platform-failure path. LLVM may optimize inside or around the calls
only when exact values, evaluation order, and allocation failure remain
observationally equivalent.

On Linux x86-64, every Int shall retain the existing private immutable
`topal-native/6` canonical sign-and-magnitude pointer representation while the
root-local Generator remains a compiler-private `i32` ownership token. LLVM
shall select pointer placement and call lowering from the target triple and
data layout; the backend shall hard-code no AMD64 register convention. Two
debug-only aligned pointer slots may anchor the yielded and captured-initial
source lifetimes without becoming semantic Generator state. DWARF, the Topal
GDB printer, and GDB shall expose the complete `Generator Int Unit Int`
classifier and value, the exact yielded Int in the foreach action scope, the
exact captured initial Int at the final expression, and the Topal entry frame.

Literal, computed, or multiple yields; a final expression other than
`initial + 1`; additional body statements; multiple parameters; other input,
yield, resume, or final classifiers; close handling; nested or
ordinary-function construction; Generator parameter/result transfer; repeated
consumption; abandonment; libraries; and external boundaries shall remain
rejected before LLVM. The lowering shall introduce no semantic Generator
object or state allocation, dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator ABI, or
`topal-native/6` revision. Existing Int values and arithmetic allocations shall
remain wholly owned by the Topal runtime and Linux syscall layer. Future
compiled-library metadata shall encode independent initial and direction
classifiers, ordered Int expression and yield/resume/final provenance, exact
numeric requirements, declaration/construction/action sites, captures/effects
including allocation failure, ownership/consumption/close state, native-
representation identity, and target adapters rather than expose the private
token, debug slots, Int object layout, or checked-program node layout. This
realizes `TOPAL-COMPILER-GENERATOR-INT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FINAL-RETURN-001` for compiler increment 5ac.

## TOPAL-COMP-GENERATOR-RATIONAL-001 — Exact Rational generator directions

The checked compiler shall admit a root custom generator with one named
Rational initial parameter and directions `Generator Rational Unit Rational`
whose body consists only of one discarded `yield initial` followed by
`initial + (Rational (1, 3))` as its distinct final expression. One currently
admitted Rational expression shall start the generator, and the fresh result
shall be bound and consumed exactly once by a Rational-to-Unit foreach action
consisting only of a discarded `value + (Rational (1, 3))`.

The checked program shall retain the Rational initial classifier separately
from all three Generator directions, the initial-parameter yield and
suspension, both typed additions, their exact one-third constructor provenance,
action, and ownership edge. Application shall evaluate and canonically
construct the initial expression exactly once. Traversal shall construct the
action addend and invoke the action addition exactly once with that retained
Rational, resume the generator with Unit, and only then construct the final
addend and evaluate the final addition against the captured initial value. All
constructors and additions shall use the canonical exact Rational and
arbitrary-precision Int runtime. This order and explicit allocation-failure
behavior shall hold with LLVM optimization disabled and shall not depend on
folding, inlining, or dead-code elimination.

Unoptimized LLVM IR shall retain three direct canonical Rational-construction
calls and two direct Rational-addition calls in source order. LLVM shall not
omit the discarded action construction or addition: both may allocate and
therefore can reach the required platform-failure path. LLVM may optimize
inside or around these calls only when exact canonical values, evaluation
order, and allocation failure remain observationally equivalent.

On Linux x86-64, every Rational shall retain the existing private immutable
`topal-native/6` pointer representation containing canonical arbitrary-
precision Int numerator and positive denominator pointers, while the root-local
Generator remains a compiler-private `i32` ownership token. LLVM shall select
pointer placement and call lowering from the target triple and data layout; the
backend shall hard-code no AMD64 register convention. Two debug-only aligned
pointer slots may anchor the yielded and captured-initial source lifetimes
without becoming semantic Generator state. DWARF, the Topal GDB printer, and
GDB shall expose the complete `Generator Rational Unit Rational` classifier and
value, the exact yielded Rational in the foreach action scope, the exact
captured initial Rational at the final expression, and the Topal entry frame.

Literal, converted, computed, or multiple yields; different Rational addends;
a final expression other than the exact declared addition; additional body
statements; multiple parameters; other input, yield, resume, or final
classifiers; close handling; nested or ordinary-function construction;
Generator parameter/result transfer; repeated consumption; abandonment;
libraries; and external boundaries shall remain rejected before LLVM. The
lowering shall introduce no semantic Generator object or state allocation,
dispatcher, callback, indirect call, unwind dependency, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Existing Rational/Int values and arithmetic allocations shall remain
wholly owned by the Topal runtime and Linux syscall layer. Future compiled-
library metadata shall encode independent initial and direction classifiers,
ordered Rational expression and yield/resume/final provenance, exact canonical
numerator/denominator and constructor requirements,
declaration/construction/action sites, captures/effects including allocation
failure, ownership/consumption/close state, native-representation identity, and
target adapters rather than expose the private token, debug slots,
Rational/Int object layouts, or checked-program node layout. This realizes
`TOPAL-COMPILER-GENERATOR-RATIONAL-001`, `TOPAL-COMPILER-EXACT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-GENERATOR-FINAL-RETURN-001` for compiler increment 5ad.

## TOPAL-COMP-GENERATOR-UNIT-001 — Payload-free Unit generator directions

The checked compiler shall admit a root custom generator with one named Unit
initial parameter and directions `Generator Unit Unit Unit` whose body consists
only of one discarded `yield initial` followed by `()` as its final expression.
One currently admitted Unit expression shall start the generator, and the fresh
result shall be bound and consumed exactly once by a Unit-to-Unit foreach action
consisting only of its named yielded parameter as an identity expression.

The checked program shall retain the Unit initial classifier separately from
all three Generator directions, the initial-parameter yield and suspension, the
named identity action, Unit resumption, distinct final Unit, and ownership edge.
Application shall evaluate the initial expression exactly once. Traversal shall
evaluate the action exactly once with the yielded Unit, resume the generator
with Unit, and only then evaluate the final Unit. This order shall hold with
LLVM optimization disabled and shall not depend on folding, inlining, or dead-
code elimination.

Because Unit has exactly one value and no runtime payload, unoptimized semantic
LLVM IR shall introduce no action call, payload operation, allocation, or
Generator runtime operation. Erasing those payload operations is a compiler
representation decision, not an LLVM optimization, and shall preserve the
checked action occurrence and source order. Debug LLVM IR shall contain two
aligned private `i8` lifetime slots: one anchors the yield and action sites, and
one initialized slot anchors the captured initial and final-expression site.
These slots and their stores shall be debug-only and shall not become semantic
Generator or Unit state. LLVM may eliminate or transform the debug-only
artifacts when permitted by the selected debug/optimization policy.

On Linux x86-64, Unit shall have no semantic native payload while the root-
local Generator remains a compiler-private `i32` ownership token. LLVM shall
select placement and call lowering from the target triple and data layout; the
backend shall hard-code no AMD64 register convention. DWARF and GDB shall
expose the complete `Generator Unit Unit Unit` classifier and value, the Unit
yielded into the foreach action, the captured initial Unit at the final
expression, ordered yield/action/resumption/final source locations, and the
Topal entry frame.

Literal or multiple yields; a final expression other than exact `()`;
additional body statements; an action other than the named identity expression;
multiple parameters; other input, yield, resume, or final classifiers; close
handling; nested or ordinary-function construction; Generator parameter/result
transfer; repeated consumption; abandonment; libraries; and external
boundaries shall remain rejected before LLVM. The lowering shall introduce no
semantic Generator object or state allocation, dispatcher, callback, indirect
call, unwind dependency, C/C++ runtime, other-language standard library, needed
library, dynamic relocation, public/library calling convention or Generator
ABI, or `topal-native/6` revision. Output shall remain wholly owned by the Topal
runtime and Linux syscall layer. Future compiled-library metadata shall encode
independent initial and direction classifiers, the zero-payload Unit identity,
ordered yield/action/resume/final provenance, representation erasure guarantees,
declaration/construction/action sites, captures/effects, ownership/consumption/
close state, native-representation identity, and target adapters rather than
expose the private token, debug slots, or checked-program node layout. This
realizes `TOPAL-COMPILER-GENERATOR-UNIT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, and `TOPAL-GENERATOR-FOREACH-001` for
compiler increment 5ae.

## TOPAL-COMP-GENERATOR-OPTIONAL-001 — Nominal Optional generator directions

The checked compiler shall admit a root custom generator with one named
`Optional Int` initial parameter and directions
`Generator Optional Int Unit Optional Int` whose body consists only of one
discarded `yield initial` followed by `None Int` as its final expression. One
currently admitted `Optional Int` expression shall start the generator; the
shared regression uses `(Some 7)`. The fresh result shall be bound and consumed
exactly once by a foreach action consisting only of the discarded equality
`candidate = (Some 7)` for its named yielded parameter.

The checked program shall retain the nominal Optional classifier and its Int
payload classifier separately from all three Generator directions, the
initial-parameter yield and suspension, the exact Some construction and
equality action, Unit resumption, distinct final None construction, and
ownership edge. Application shall construct the initial Optional exactly once.
Traversal shall pass that same immutable Optional value to the action, evaluate
the exact right operand and equality once, resume the generator with Unit, and
only then construct the final None value. This order shall hold with LLVM
optimization disabled and shall not depend on folding, inlining, or dead-code
elimination.

On Linux x86-64, the existing compiler-private Optional representation shall
remain an aligned pointer to Topal-owned tagged storage with an Int payload
pointer for Some and a null payload for None. The root-local Generator shall
remain a compiler-private `i32` ownership token. LLVM shall select placement
and call lowering from the target triple and data layout; the backend shall
hard-code no AMD64 register convention. Two aligned debug-only pointer shadows
shall preserve the yielded action value and captured initial lifetime. DWARF
and GDB shall expose the complete `Generator Optional Int Unit Optional Int`
classifier and value, the yielded `Some 7`, the captured initial `Some 7`,
ordered yield/action/resumption/final source locations, and the Topal entry
frame.

Literal or multiple yields; a final expression other than exact `None Int`;
additional body statements; another Optional payload, action, input, yield,
resume, or final classifier; close handling; nested or ordinary-function
construction; Generator parameter/result transfer; repeated consumption;
abandonment; libraries; and external boundaries shall remain
rejected before LLVM. The lowering shall introduce no semantic Generator
object or state allocation, dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator ABI, or
`topal-native/6` revision. Optional storage, allocation, equality, display, and
Linux syscalls shall remain wholly owned by Topal. Future compiled-library
metadata shall encode independent initial and direction classifiers, the
nominal Optional and payload identities, exact alternatives and action
operands, ordered yield/action/resume/final provenance, allocation-failure
effects, declaration and construction sites, captures/effects, ownership/
consumption/close state, native-representation identity, and target adapters
rather than expose the private token, debug slots, Optional/Int object layouts,
or checked-program node layout. This realizes
`TOPAL-COMPILER-GENERATOR-OPTIONAL-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-TYPE-OPTIONAL-BOUNDARY-001` for compiler increment 5af.

## TOPAL-COMP-GENERATOR-RESULT-001 — Exact Result generator directions

The checked compiler shall admit a root custom generator with one named
`Result (Rational, lang arithmetic ArithmeticErrorCode)` initial parameter and
matching yield and final directions, with Unit resumption. Its body shall
consist only of one discarded `yield initial` followed by
`initial / (Rational 0)`. The shared regression shall start the generator with
the exact proven-success expression `Rational 1`; the fresh result shall be
bound and consumed exactly once by a foreach action consisting only of the
discarded self-equality `candidate = candidate` for its named yielded
parameter.

The checked program shall retain the nominal Result and Rational success
identities separately in all three Generator directions, the proven-success
promotion, initial-parameter yield and suspension, reflexive action, Unit
resumption, structured fallible final division, source-located error
provenance, declaration provenance, and ownership edge. Application shall
evaluate and promote Rational 1 exactly once. Traversal shall pass that same
immutable successful Result to the action, prove its self-equality without
inspecting or duplicating the payload, resume with Unit, and only then perform
the exact division by zero and produce the structured failure Result. This
order shall hold with LLVM optimization disabled and shall not depend on
folding, inlining, or dead-code elimination.

On Linux x86-64, Result and Rational shall retain their existing Topal-owned
compiler-private pointer representations, and the root-local Generator shall
remain a compiler-private `i32` ownership token. LLVM shall derive placement,
alignment, and call lowering from the target triple and data layout; the
backend shall hard-code no AMD64 register convention. Two aligned debug-only
pointer shadows and four lifetime/source anchor stores shall keep the yielded
action value and captured initial inspectable. DWARF and GDB shall expose the
complete Result-bearing Generator classifier and value, the yielded successful
Rational 1 Result, captured initial Result, ordered yield/action/resumption/
final source locations, and the Topal entry frame.

Another Result success/error classifier, input expression or value, direction,
yield, final operation, divisor, or action; multiple yields; additional body
statements; general inlined Result projection/propagation; close handling;
nested or ordinary-function construction; Generator parameter/result transfer;
repeated consumption; abandonment; libraries; and external boundaries shall
remain rejected before LLVM. The lowering shall introduce no semantic
Generator object or state allocation, dispatcher, callback, indirect call,
unwind dependency, C/C++ runtime, other-language standard library, needed
library, dynamic relocation, public/library calling convention or Generator/
Result ABI, or `topal-native/6` revision. Result/Rational storage, allocation,
failure construction, display, and Linux syscalls shall remain wholly owned by
Topal. Future compiled-library metadata shall encode independent initial and
direction classifiers, nominal Result/success/error identities, success
evidence, fallible-operation and source-error provenance, ordered yield/action/
resume/final provenance, allocation-failure effects, declaration/construction
sites, captures/effects, ownership/consumption/close state, native-
representation identity, and target adapters rather than expose the private
token, debug slots, pointer/object layouts, or checked-program node layout.
This realizes `TOPAL-COMPILER-GENERATOR-RESULT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-TYPE-RESULT-001` for compiler increment 5ak.

## TOPAL-COMP-GENERATOR-COMPARISON-001 — Exact Comparison generator directions

The checked compiler shall admit a root custom generator with one named
`Comparison` initial parameter and directions
`Generator Comparison Unit Comparison`. Its body shall consist only of one
discarded `yield initial` followed by `3 <=> 2` as its final expression. The
shared regression shall start the generator with the exact expression
`1 <=> 2`; the fresh result shall be bound and consumed exactly once by a
foreach action consisting only of the discarded
`comparison = (1 <=> 2)` for its named yielded parameter.

The checked program shall retain the language-defined nominal `Comparison`
identity separately in all three Generator directions, both ordered Int
operands and three-way operations, the initial-parameter yield and suspension,
the exact equality action, Unit resumption, distinct final comparison,
declaration provenance, and ownership edge. Application shall evaluate
`1 <=> 2` exactly once. Traversal shall pass that same immutable Less value to
the action, independently evaluate the action's `1 <=> 2` once and compare the
two nominal values, resume the generator with Unit, and only then evaluate
`3 <=> 2` to produce Greater. This order shall hold with LLVM optimization
disabled and shall not depend on folding, inlining, or dead-code elimination.

On Linux x86-64, `Comparison` shall retain its existing compiler-private signed
`i32` values for Less, Equal, and Greater, and the root-local Generator shall
remain a compiler-private `i32` ownership token. LLVM shall derive placement,
alignment, and call lowering from the target triple and data layout; the
backend shall hard-code no AMD64 register convention. Two aligned debug-only
`i32` shadows and four lifetime/source anchor stores shall keep the yielded
action value and captured initial inspectable. DWARF and GDB shall expose the
complete `Generator Comparison Unit Comparison` classifier and value, the
yielded Less value, captured initial Less value, ordered yield/action/
resumption/final source locations, and the Topal entry frame.

Another input, action, final comparison, operand, direction, yield, or value;
multiple yields; additional body statements; close handling; nested or
ordinary-function construction; Generator parameter/result transfer; repeated
consumption; abandonment; libraries; and external boundaries shall remain
rejected before LLVM. The lowering shall introduce no semantic Generator
object or state allocation, dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator/Comparison
ABI, or `topal-native/6` revision. Int/Comparison allocation, comparison,
equality, display, and Linux syscalls shall remain wholly owned by Topal.
Future compiled-library metadata shall encode independent initial and direction
classifiers, nominal Comparison identity and ordered alternatives, operand and
operation provenance, ordered yield/action/resume/final provenance,
allocation-failure effects, declaration/construction sites, captures/effects,
ownership/consumption/close state, native-representation identity, and target
adapters rather than expose the private token, debug slots, scalar tags, or
checked-program node layout. This realizes
`TOPAL-COMPILER-GENERATOR-COMPARISON-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-DECISION-COMPARISON-001` for compiler increment 5al.

## TOPAL-COMP-GENERATOR-NESTED-OPTIONAL-001 — Recursive Optional product directions

The checked compiler shall admit a root custom generator with one named
`Optional (Int, String)` initial parameter and directions
`Generator Optional (Int, String) Unit Optional (Int, String)`. Its body shall
consist only of one discarded `yield initial` followed by
`Some (8, "done")`. The shared regression shall start the generator with exact
`Some (7, "item")`; the fresh result shall be bound and consumed exactly once
by a foreach action consisting only of the discarded
`candidate = (Some (7, "item"))` for its named yielded parameter.

The checked program shall retain the nominal Optional identity, Some
alternative, positional-product arity and order, and Int and String field
identities separately in all three Generator directions. It shall also retain
the initial-parameter yield and suspension, field-wise Optional equality
action, Unit resumption, distinct final product, declaration provenance, and
ownership edge. Application shall evaluate both initial payload fields once in
source order and construct one Optional. Traversal shall pass that same
immutable value to the action, construct the action operand once, compare tags
before observing Some payloads, compare payload fields in source order, resume
with Unit, and only then construct `Some (8, "done")`. This order shall hold at
LLVM O0 without relying on folding, inlining, or dead-code elimination.

On Linux x86-64, Optional shall retain its existing Topal-owned tagged pointer
header. Each admitted Some product payload shall use a Topal-owned aligned
16-byte allocation containing the existing Int and String pointers in source
order. The root-local Generator shall remain a compiler-private `i32` ownership
token. LLVM shall derive placement, alignment, and call lowering from the
target triple and data layout; the backend shall hard-code no AMD64 register
convention. Two aligned debug-only Optional pointer shadows shall preserve the
yielded action value and captured initial lifetime. DWARF and GDB shall expose
the complete recursive Generator classifier and value, the Optional product
classifier, ordered payload fields, both yielded/captured `Some (7, "item")`
values, ordered yield/action/resumption/final source locations, and the Topal
entry frame.

Another Optional payload, product arity, field order, input, action, final,
direction, yield, or value; None; multiple yields; additional body statements;
close handling; nested construction; ordinary-function construction or
Generator parameter/result transfer outside
`TOPAL-COMP-GENERATOR-NESTED-FUNCTION-BOUNDARY-001`; repeated consumption;
abandonment; libraries; and external
boundaries shall remain rejected before LLVM. The lowering shall introduce no
semantic Generator object or state allocation, generic Optional/product
dispatcher, callback, indirect call, unwind dependency, C/C++ runtime, other-
language standard library, needed library, dynamic relocation, public/library
calling convention or Generator/Optional/product ABI, or `topal-native/6`
revision. Optional, product, Int, and String allocation, equality, display, and
Linux syscalls shall remain wholly owned by Topal. Future compiled-library
metadata shall encode recursive classifiers, independent directions, nominal
alternatives, product arity/order, field identities, equality and ordered
yield/action/resume/final provenance, allocation-failure effects, declaration/
construction sites, captures/effects, ownership/consumption/close state,
native-representation identity, and target adapters rather than expose private
tokens, debug slots, object layouts, or checked-program nodes. This realizes
`TOPAL-COMPILER-GENERATOR-NESTED-OPTIONAL-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-TYPE-OPTIONAL-CONSTRUCT-001`, and `TOPAL-TYPE-PRODUCT-001` for compiler
increment 5am.

## TOPAL-COMP-GENERATOR-NESTED-RESULT-001 — Recursive Result product directions

The checked compiler shall admit a root custom generator with one named
`Result ((Int, String), lang arithmetic ArithmeticErrorCode)` initial parameter
and the same yield and result directions with Unit resumption. Its body shall
consist only of one discarded `yield initial` followed by `(8, "done")`. The
shared regression shall start the generator with exact `(7, "item")`; the fresh
result shall be bound and consumed exactly once by a foreach action consisting
only of the discarded `candidate = (7, "item")` for its named yielded
parameter. Each product shall satisfy its explicit Result contract as an
implicit success value.

The checked program shall retain the nominal Result and arithmetic-error
vocabulary identities, success alternative, positional-product arity and
order, and Int and String field identities separately in all three Generator
directions. It shall also retain the initial-parameter yield and suspension,
success-gated field equality action, Unit resumption, distinct final product,
declaration provenance, and ownership edge. Application shall evaluate both
initial payload fields once in source order and construct one successful
Result. Traversal shall pass that same immutable value to the action, construct
the action success operand once, inspect both success/error tags before
observing success payloads, compare payload fields in source order, resume with
Unit, and only then construct the successful `(8, "done")`. This order shall
hold at LLVM O0 without relying on folding, inlining, or dead-code elimination.

On Linux x86-64, Result shall retain its existing Topal-owned tagged pointer
header. Each admitted successful product payload shall use a Topal-owned
aligned 16-byte allocation containing the existing Int and String pointers in
source order. The root-local Generator shall remain a compiler-private `i32`
ownership token. LLVM shall derive placement, alignment, and call lowering
from the target triple and data layout; the backend shall hard-code no AMD64
register convention. Two aligned debug-only Result pointer shadows shall
preserve the yielded action value and captured initial lifetime. DWARF and GDB
shall expose the complete recursive Generator classifier and value, the Result
product classifier, ordered payload fields, both yielded/captured `(7,
"item")` values, ordered yield/action/resumption/final source locations, and
the Topal entry frame.

An Error value, another Result success type, product arity, field order, input,
action, final, direction, yield, or value; multiple yields; additional body
statements; close handling; nested construction; ordinary-function construction
or Generator parameter/result transfer outside
`TOPAL-COMP-GENERATOR-NESTED-FUNCTION-BOUNDARY-001`; repeated consumption; abandonment;
libraries; and external boundaries shall remain rejected before LLVM. The
lowering shall introduce no semantic Generator object or state allocation,
generic Result/product dispatcher, callback, indirect call, unwind dependency,
C/C++ runtime, other-language standard library, needed library, dynamic
relocation, public/library calling convention or Generator/Result/product ABI,
or `topal-native/6` revision. Result, product, Int, and String allocation,
equality, display, and Linux syscalls shall remain wholly owned by Topal.
Future compiled-library metadata shall encode recursive classifiers,
independent directions, nominal alternatives/error vocabularies, product
arity/order, field identities, success/error evidence, equality and ordered
yield/action/resume/final provenance, allocation-failure effects, declaration/
construction sites, captures/effects, ownership/consumption/close state,
native-representation identity, and target adapters rather than expose private
tokens, debug slots, object layouts, or checked-program nodes. This realizes
`TOPAL-COMPILER-GENERATOR-NESTED-RESULT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-TYPE-RESULT-001`, and `TOPAL-TYPE-PRODUCT-001` for compiler increment
5an.

## TOPAL-COMP-GENERATOR-FINAL-DECISION-001 — Post-resume final Boolean decision

The checked compiler shall admit a root custom generator with one named Boolean
initial parameter and directions `Generator Boolean Unit String`. Its body
shall consist only of one discarded `yield initial` followed by a complete
decision on `initial` whose `true` action is the exact String `"accepted"` and
whose `otherwise` action is the exact String `"rejected"`. The shared
regression shall start the generator with `true`; the fresh result shall be
bound and consumed exactly once by a foreach action consisting only of the
discarded `not value` for its named yielded parameter.

The checked program shall retain the independent Boolean yield and String
final directions, the initial-parameter suspension, action, Unit resumption,
decision subject and ordered alternatives/actions, declaration provenance, and
ownership edge. Application shall evaluate the initial Boolean once. Traversal
shall pass that same value to the action, resume with Unit, evaluate the
captured initial as the decision subject once, execute exactly the selected
String action, and return that String as the final/root value. LLVM O0 shall
retain a direct conditional branch, distinct true/false String blocks, and a
typed join without relying on folding, inlining, or dead-code elimination.

On Linux x86-64, the Boolean shall remain a private `i1`, each selected String
shall use the existing Topal-owned immutable descriptor, and the root-local
Generator shall remain a compiler-private `i32` ownership token. LLVM shall
derive placement, alignment, branch lowering, and calls from the target triple
and data layout; the backend shall hard-code no AMD64 register convention. An
aligned debug-only Boolean shadow shall preserve the yielded action value.
DWARF and GDB shall expose the complete Generator classifier and value, yielded
and captured Boolean values, ordered yield/action/decision source locations,
and the Topal entry frame.

Another input classifier, yield, action, decision subject, matcher order,
String action, direction, value, or final expression; multiple yields; additional body
statements; close handling; nested or ordinary-function construction;
Generator parameter/result transfer; repeated consumption; abandonment;
libraries; and external boundaries shall remain rejected before LLVM. The
lowering shall introduce no semantic Generator object or state allocation,
generic decision or Generator dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator/String ABI,
or `topal-native/6` revision. Boolean decisions, String construction/display,
and Linux syscalls shall remain wholly owned by Topal. Future compiled-library
metadata shall encode independent directions, ordered decision matchers/
actions, subject/final provenance, declaration/construction sites, captures/
effects, ownership/consumption/close state, native-representation identity,
and target adapters rather than expose private tokens, debug slots, LLVM
blocks, object layouts, or checked-program nodes. This realizes
`TOPAL-COMPILER-GENERATOR-FINAL-DECISION-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-GENERATOR-FINAL-RETURN-001`, and `TOPAL-DECISION-BOOLEAN-001` for
compiler increment 5ap.

## TOPAL-COMP-GENERATOR-NESTED-NONE-001 — Absent recursive Optional directions

The checked compiler shall admit a root custom generator with one named
`Optional (Int, String)` initial parameter and directions
`Generator Optional (Int, String) Unit Optional (Int, String)`. Its body shall
consist only of one discarded `yield initial` followed by
`None (Int, String)`. The shared regression shall start the generator with
exact `None (Int, String)`; the fresh result shall be bound and consumed exactly
once by a foreach action consisting only of the discarded
`candidate = (None (Int, String))` for its named yielded parameter.

The checked program shall retain the nominal Optional identity, None
alternative, positional-product arity and order, and Int and String field
identities separately in all three Generator directions despite the absence of
a payload. It shall also retain the initial-parameter yield and suspension,
tag-equality action, Unit resumption, distinct final None construction,
declaration provenance, and ownership edge. Application shall construct the
initial absent Optional once. Traversal shall pass that same immutable value to
the action, construct the absent action operand once, compare tags before any
payload observation, resume with Unit, and only then construct the final absent
Optional. This order shall hold at LLVM O0 without relying on folding, inlining,
or dead-code elimination.

On Linux x86-64, each admitted None shall use the existing Topal-owned Optional
tagged pointer header with no product-payload allocation. The root-local
Generator shall remain a compiler-private `i32` ownership token. LLVM shall
derive placement, alignment, and call lowering from the target triple and data
layout; the backend shall hard-code no AMD64 register convention. Two aligned
debug-only Optional pointer shadows shall preserve the yielded action value and
captured initial lifetime. DWARF and GDB shall expose the complete recursive
Generator classifier and value, the Optional product classifier and ordered
payload field types, both yielded/captured None values, ordered yield/action/
resumption/final source locations, and the Topal entry frame.

A Some value, mixed Some/None graph, another Optional payload, product arity,
field order, input, action, final, direction, yield, or value; multiple yields;
additional body statements; close handling; nested or ordinary-function
construction; Generator parameter/result transfer; repeated consumption;
abandonment; libraries; and external boundaries shall remain rejected before
LLVM. The lowering shall introduce no semantic Generator object or state
allocation, generic Optional/product dispatcher, callback, indirect call,
unwind dependency, C/C++ runtime, other-language standard library, needed
library, dynamic relocation, public/library calling convention or Generator/
Optional/product ABI, or `topal-native/6` revision. Optional tag construction/
equality, display, and Linux syscalls shall remain wholly owned by Topal.
Future compiled-library metadata shall encode recursive classifiers,
independent directions, nominal alternatives, product arity/order and field
identities, absence evidence, equality and ordered yield/action/resume/final
provenance, allocation-failure effects, declaration/construction sites,
captures/effects, ownership/consumption/close state, native-representation
identity, and target adapters rather than expose private tokens, debug slots,
object layouts, or checked-program nodes. This realizes
`TOPAL-COMPILER-GENERATOR-NESTED-NONE-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-TYPE-OPTIONAL-CONSTRUCT-001`, and `TOPAL-TYPE-PRODUCT-001` for compiler
increment 5ao.

## TOPAL-COMP-GENERATOR-RECURSIVE-NOMINAL-001 — Recursive nominal value directions

The checked compiler shall admit the declaration
`Choice is Enum (First, Second)` and a root custom generator with one named
`(Optional Choice, Result (Choice, lang arithmetic ArithmeticErrorCode))`
initial parameter and the same yield and result directions with Unit
resumption. Its body shall consist only of one discarded `yield initial`
followed by `(Some Second, Second)`. The shared regression shall start the
generator with exact `(Some First, First)`; the fresh result shall be bound and
consumed exactly once by a foreach action consisting only of the discarded
`candidate = (Some First, First)` for its named yielded parameter.

The checked program shall retain the nominal Choice identity and ordered First/
Second alternatives inside both recursive fields, the Optional and Result
identities, arithmetic error vocabulary, product arity/order, initial-parameter
yield and suspension, guarded structural-equality action, Unit resumption,
distinct final alternatives, declaration provenance, and ownership edge
separately in all three Generator directions. Application shall construct the
initial recursive product once. Traversal shall pass that same immutable value
to the action, separately construct its comparison operand, compare Optional
and Result tags before loading their boxed Choice tags, resume with Unit, and
only then construct the final recursive product. This order shall hold at LLVM
O0 without relying on folding, inlining, or dead-code elimination.

On Linux x86-64, each admitted Choice payload inside Optional or Result shall
use a Topal-owned aligned four-byte box composed with the existing tagged
pointer header; six boxes shall be constructed across input, action, and final
values. The product shall remain a private two-pointer aggregate and the root-
local Generator a compiler-private `i32` ownership token. LLVM shall derive
placement, alignment, and call lowering from the target triple and data layout;
the backend shall hard-code no AMD64 register convention. Two aligned debug-
only aggregate shadows shall preserve the yielded action value and captured
initial lifetime. DWARF and GDB shall expose the complete recursive Generator
classifier and value, ordered product members, Optional and Result classifiers,
the nested Choice identity and alternatives, yielded/captured values, ordered
yield/action/resumption/final source locations, and the Topal entry frame.

A None or error value, mixed alternative, another Enum declaration or order,
recursive field classifier, product arity/order, error vocabulary, input,
action, final, direction, yield, or value; multiple yields; additional body
statements; close handling; nested or ordinary-function construction;
Generator parameter/result transfer; repeated consumption; abandonment;
libraries; and external boundaries shall remain rejected before LLVM. The
lowering shall introduce no semantic Generator object or state allocation,
generic recursive/Optional/Result dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator/product/
Optional/Result/Choice ABI, or `topal-native/6` revision. Enum boxing, Optional
and Result construction/equality, display, and Linux syscalls shall remain
wholly owned by Topal. Future compiled-library metadata shall encode recursive
nominal identity, ordered alternatives, error vocabularies, product arity/order
and field identities, independent directions, success/absence evidence,
equality and ordered yield/action/resume/final provenance, allocation-failure
effects, declaration/construction sites, captures/effects, ownership/
consumption/close state, native-representation identity, and target adapters
rather than expose private tokens, debug slots, object layouts, or checked-
program nodes. This realizes
`TOPAL-COMPILER-GENERATOR-RECURSIVE-NOMINAL-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-TYPE-ENUM-001`, `TOPAL-TYPE-OPTIONAL-CONSTRUCT-001`,
`TOPAL-TYPE-RESULT-001`, and `TOPAL-TYPE-PRODUCT-001` for compiler increment
5aq.

## TOPAL-COMP-GENERATOR-LOCAL-FUNCTION-001 — Retained local declarations

The checked compiler shall admit the unchanged
`examples/language/custom-generator-local-function.t` regression: an exact
root `Generator Boolean Unit String` whose body declares local
`Choice is Enum (Accepted, Rejected)`, declares local
`label (value : Choice) -> String` with the complete accepted/rejected String
mapping, yields its named Boolean initial parameter once, and calls
`label Accepted` after Unit resumption. The fresh generator shall be consumed
exactly once by the discarded `not value` foreach action.

The checked model shall retain the local nominal identity and ordered
alternatives, local function signature and Enum decision, initial-parameter
yield, post-resume direct call and argument, source provenance, and ownership
edge separately. The local names shall be unavailable to the root and consumer
environments. Application shall evaluate the initial Boolean once. Traversal
shall run the action, resume with Unit, directly invoke the retained function,
and use its String result only afterward. The O0 IR shall preserve this order
without relying on an LLVM optimization.

The Linux x86-64 backend shall use the existing private `i32` representations
for Choice and the root-local Generator token. It shall emit `label` as an
internal, non-inlined `fastcc` definition with a direct call and no closure or
environment object. LLVM shall own target argument, return, stack, and register
placement. DWARF and GDB shall expose the complete Generator classifier and
value, yielded and captured Booleans, ordered yield/action/resume/call source
locations, the local function subprogram, its nominal Choice parameter and
Accepted value, and both the local-function and Topal entry frames.

Another local declaration, enum name/alternative/order, function signature or
body, capture, final call or argument, generator direction, action, yield,
result or ownership path; close handling; parameter/result transfer; repeated
consumption; abandonment; libraries; and external boundaries shall remain
rejected before LLVM. This shall add no semantic Generator object or state
allocation, closure environment, dispatcher, callback, indirect call, unwind
dependency, foreign runtime, C/C++ runtime, other-language standard library,
needed library, dynamic relocation, public/library calling convention,
Generator/function/Choice ABI, or `topal-native/6` revision. Future
compiled-library metadata shall encode lexical declaration identity and parent
scope, nominal alternatives, function signature and checked body graph,
capture set, suspension reachability, direct-call and ordered yield/action/
resume/final provenance, effects, ownership/consumption/close state,
native-representation identity, and target adapters rather than expose private
symbols, tags, tokens, debug slots, object layouts, or checked-program nodes.
This realizes `TOPAL-COMPILER-GENERATOR-LOCAL-FUNCTION-001`,
`TOPAL-GENERATOR-LOCAL-FUNCTION-001`, `TOPAL-GENERATOR-LOCAL-ENUM-001`,
`TOPAL-GENERATOR-SUSPEND-001`, `TOPAL-FUNCTION-ORDINARY-001`, and
`TOPAL-TYPE-ENUM-001` for compiler increment 5ar.

## TOPAL-COMP-GENERATOR-LOCAL-CLOSE-001 — Restored declarations on close

The checked compiler shall admit the unchanged
`examples/language/custom-generator-local-close-handler.t` regression: an
exact root `Generator Character Unit Unit` whose body declares local
`CloseChoice is Enum (Closed, Continued)`, declares the local ordinary
`cleanup (choice : CloseChoice) -> Unit`, binds one `yield initial` Result, and
handles its qualified `generator-closed`, fallback Error, and Ok alternatives.
An ordinary `abandon` function shall construct one fresh instance and close it
by reaching function-scope Unit without consuming the yielded Character.

The checked model shall retain the local nominal identity and alternatives,
local function signature and Unit body, yield-result decision and ordered
branches, direct cleanup calls and arguments, declaration and call provenance,
and ownership/close edge separately. Close delivery shall restore the same
generator-local declaration state that was active at suspension, select only
the qualified close branch, directly call `cleanup Closed`, and complete the
generator before `abandon` returns. The local names shall remain unavailable
to the root and consumer environments. This O0 order shall not rely on an LLVM
optimization.

On Linux x86-64, CloseChoice and the generator ownership token shall use
compiler-private `i32` representations. The backend shall emit `cleanup` as an
internal, non-inlined `fastcc` definition and invoke it directly after the
Topal-owned Result payload and code selection. A debugger-only aligned shadow
shall preserve the otherwise-unused enum parameter. LLVM shall derive machine
argument, return, stack, alignment, and register placement from the target
triple and data layout. DWARF and GDB shall expose the close Result and code,
the local function subprogram, its complete nominal CloseChoice parameter and
Closed value, ordered close/call locations, and the cleanup, abandon, and
Topal entry frames.

Another local declaration, enum name/alternative/order, function signature or
body, capture, yield, decision subject/branch/order/action, cleanup call or
argument, generator direction, result or ownership path; successful traversal,
multiple yields or owned generators; parameter/result transfer; libraries; and
external boundaries shall remain rejected before LLVM. This shall add no
semantic Generator object or state allocation, closure environment, close
dispatcher, callback, indirect call, unwind dependency, foreign runtime,
C/C++ runtime, other-language standard library, needed library, dynamic
relocation, public/library calling convention, Generator/function/Choice ABI,
or `topal-native/6` revision. Future compiled-library metadata shall encode
lexical declaration identity and parent scope, nominal alternatives, function
signature and checked body graph, capture set, suspension and close
reachability, ordered Result matchers and fallback, direct-call and close-site
provenance, lexical domain, effects, ownership/consumption state,
native-representation identity, and target adapters rather than expose private
symbols, tags, tokens, debug slots, object layouts, or checked-program nodes.
This realizes `TOPAL-COMPILER-GENERATOR-LOCAL-CLOSE-001`,
`TOPAL-GENERATOR-LOCAL-FUNCTION-001`, `TOPAL-GENERATOR-LOCAL-ENUM-001`,
`TOPAL-GENERATOR-CLOSE-001`, `TOPAL-GENERATOR-CLOSE-HANDLER-001`,
`TOPAL-GENERATOR-ERROR-CODE-001`, `TOPAL-FUNCTION-ORDINARY-001`, and
`TOPAL-TYPE-ENUM-001` for compiler increment 5as.

## TOPAL-COMP-GENERATOR-OVERLOAD-001 — Ordered inputs and typed traversal results

The checked compiler shall admit the unchanged
`examples/language/custom-generator-overloads.t` regression. It declares, in
source order, one `select (Int)` overload yielding Int and one
`select (Int, String)` overload yielding String; both resume with Unit and
return String. Application shall evaluate its argument once, flatten an
unlabeled positional product for the binary candidate, select the first
complete ordered classifier match, and bind the selected operands in
declaration order. The admitted calls shall use exact `7` and `(7, "item")`
inputs respectively. A duplicate ordered input signature shall be rejected even
when its yield, resume, result, or body differs.

The checked model shall retain each overload as a distinct declaration with
ordered input classifiers, parameters, captured values, yield/result
directions, body graph, declaration provenance, and ownership edge. The unary
traversal shall yield its Int input, run the exact increment action, resume
with Unit, and bind final String `"unary"`. The binary traversal shall observe
its Int prefix before yielding the captured suffix, run the exact String
emptiness action, resume with Unit, and bind final String `"binary"`. Each
typed foreach result binding shall be a fresh ordinary root binding available
only after traversal completion. All ordering shall hold at LLVM O0 without
folding, inlining, or dead-code elimination.

On Linux x86-64, the overload set and captured input vectors shall remain
checked compile-session data. Each root-local Generator shall use the existing
private `i32` ownership token, while Int and String retain their Topal-owned
pointer representations. LLVM shall derive physical placement and alignment
from the target triple and data layout; no AMD64 register convention shall be
hard-coded. Target-aligned debugger-only input and action shadows shall expose
both Generator classifiers, ordered binary inputs, yielded values, typed final
bindings, source locations, and the Topal entry frame in DWARF/GDB.

Other arities, classifiers, input values, bodies, directions, argument packaging, actions,
results, nested/function construction, parameter/result transfer, repeated
consumption, abandonment, close handling, libraries, and external boundaries
shall remain rejected before LLVM. This shall add no semantic Generator object
or state allocation, overload dispatcher, callback, indirect call, unwind
dependency, foreign runtime, C/C++ runtime, other-language standard library,
needed library, dynamic relocation, public/library calling convention,
Generator ABI, or `topal-native/6` revision. Future compiled-library metadata
shall encode declaration order, complete ordered input classifiers, packaging,
independent directions, body and suspension graphs, captures, effects,
ownership/consumption/close state, typed final-result provenance,
native-representation identity, and target adapters rather than private tokens,
debug slots, pointer layouts, or checked-program nodes. This realizes
`TOPAL-COMPILER-GENERATOR-OVERLOAD-001`, `TOPAL-GENERATOR-OVERLOAD-001`,
`TOPAL-GENERATOR-FOREACH-RESULT-001`, `TOPAL-GENERATOR-FINAL-RETURN-001`, and
`TOPAL-TYPE-PRODUCT-001` for compiler increment 5at.

## TOPAL-COMP-GENERATOR-FUNCTION-BOUNDARY-001 — Specialized scalar continuation transfer

The checked compiler shall admit the unchanged
`examples/language/custom-generator-generic-function-boundaries.t` regression.
Its exact `numbers` declaration shall be `Generator Int Unit String`, yield its
Int input once, resume with Unit, and return String `"done"`. The ordinary
single-Int `make` function shall return a fresh continuation without closing
it. The ordinary single-Generator `consume` function shall receive sole
ownership, traverse it once with the exact discarded `value + 1` action, bind
the final String, and return it. The root graph shall pass exact Int `7` through
`make`, bind the returned continuation, transfer it to `consume`, and print
`"done"`.

The checked model shall preserve the complete Generator classifier,
declaration, parameter-derived construction, exact call-specialized input,
single suspension, Unit resumption, final-result graph, function-result edge,
function-parameter edge, and once-only consumption as separate facts. The
returned-provenance specialization shall replace the factory-local input name
with the already evaluated exact caller operand before checking the consumer;
it shall not reevaluate the source call. Factory exit and consumer entry shall
not deliver close. Consumer action, resumption, final String construction, and
return shall remain ordered at LLVM O0 without relying on inlining, constant
folding, or dead-code elimination.

On Linux x86-64, the private factory shall lower as one Topal Int pointer to an
`i32` ownership token, and the private consumer as that token to one Topal
String pointer. LLVM `fastcc`, the target triple, and target data layout shall
select physical placement and alignment; no AMD64 register or return placement
shall be hard-coded. Target-aligned debug-only shadows shall keep the factory
Int, complete Generator consumer parameter, yielded Int action value, final
String binding, ordinary-function frames, and Topal entry frame visible in
DWARF/GDB.

Other Generator classifiers, inputs, declaration/body shapes, factory or
consumer forms, actions, results, arities, recursion, nesting, repeated use,
abandonment, close handling, packages, libraries, and external boundaries
shall remain rejected before LLVM. This shall add no semantic Generator object
or state allocation, runtime transfer/traversal dispatcher, callback, indirect
call, unwind dependency, foreign runtime, C/C++ runtime, other-language
standard library, needed library, dynamic relocation, public/library calling
convention, Generator ABI, or `topal-native/6` revision. Future compiled-library
metadata shall encode complete classifiers and directions, declaration and
body/suspension graphs, construction and transfer sites, exact or symbolic
captures, effects, ownership/consumption/close state, final-result provenance,
native-representation identity, and target adapters rather than private
specializations, tokens, debug slots, pointer layouts, or checked-program
nodes. This realizes `TOPAL-COMPILER-GENERATOR-FUNCTION-BOUNDARY-001`,
`TOPAL-GENERATOR-FUNCTION-CLASSIFIER-001`,
`TOPAL-GENERATOR-FUNCTION-RESULT-001`, and
`TOPAL-GENERATOR-FUNCTION-PARAMETER-001` for compiler increment 5au.

## TOPAL-COMP-GENERATOR-COMPOUND-FUNCTION-BOUNDARY-001 — Specialized positional-product continuation transfer

The checked compiler shall admit the unchanged
`examples/language/custom-generator-compound-function-boundaries.t` regression.
Its exact `pairs` declaration shall be
`Generator (Int, String) Unit (Int, String)`, yield its positional-product input
once, resume with Unit, and return `(8, "done")`. The ordinary `make` function
shall accept `(Int, String)` and return the fresh continuation without closing
it. The ordinary `consume` function shall receive sole ownership, traverse it
once with the exact discarded `value = (7, "item")` action, bind the final
product, and return it. The root graph shall pass exact `(7, "item")` through
`make`, bind the continuation, transfer it to `consume`, and print
`(8, "done")`.

The checked model shall preserve product arity, field order and classifiers in
the initial, yield, and final directions together with declaration,
parameter-derived construction, exact call-specialized input, suspension,
field-wise action, Unit resumption, final-result graph, both function-transfer
edges, and once-only consumption. The factory-local input name shall be
specialized to the already evaluated caller aggregate without reevaluation.
Factory exit and consumer entry shall not deliver close. Ordered Int equality,
String equality, final-product construction, and return shall hold at LLVM O0
without inlining, folding, or dead-code elimination.

On Linux x86-64, the private factory shall lower from the existing LLVM
aggregate of Topal-owned Int and String pointers to an `i32` ownership token;
the private consumer shall lower from that token to the aggregate. LLVM
`fastcc`, the target triple, and target data layout shall determine aggregate
placement, alignment, and return lowering; no AMD64 register or return
convention shall be hard-coded. Target-aligned debug shadows shall expose the
factory product, complete Generator parameter, yielded product, final product,
ordered `_0` and `_1` fields, ordinary-function frames, and Topal entry frame
in DWARF/GDB.

Other product shapes, field classifiers or order, inputs, declarations,
factories, consumers, actions, results, arities, recursion, nesting, repeated
use, abandonment, close handling, packages, libraries, and external boundaries
shall remain rejected before LLVM. This shall add no semantic Generator object
or state allocation, transfer/traversal dispatcher, callback, indirect call,
unwind dependency, foreign runtime, C/C++ runtime, other-language standard
library, needed library, dynamic relocation, public/library calling convention,
Generator/product ABI, or `topal-native/6` revision. Future compiled-library
metadata shall encode canonical product arity, order, field identities,
complete Generator directions, declaration/body/suspension graphs,
construction and transfer sites, exact or symbolic captures, field-wise
operations, effects, ownership/consumption/close state, final-result provenance,
native-representation identity, and target adapters rather than private
specializations, tokens, debug slots, aggregate layouts, or checked-program
nodes. This realizes
`TOPAL-COMPILER-GENERATOR-COMPOUND-FUNCTION-BOUNDARY-001`,
`TOPAL-GENERATOR-FUNCTION-CLASSIFIER-001`,
`TOPAL-GENERATOR-FUNCTION-RESULT-001`,
`TOPAL-GENERATOR-FUNCTION-PARAMETER-001`,
`TOPAL-GENERATOR-FOREACH-RESULT-001`, and `TOPAL-TYPE-PRODUCT-001` for compiler
increment 5av.

## TOPAL-COMP-GENERATOR-NESTED-FUNCTION-BOUNDARY-001 — Specialized recursive-value continuation transfer

The checked compiler shall admit the unchanged
`examples/language/custom-generator-nested-function-boundaries.t` regression.
Its exact `pairs` declaration shall be
`Generator Optional (Int, String) Unit Result ((Int, String), lang arithmetic ArithmeticErrorCode)`.
It shall yield its initial Some product once, resume with Unit, and return the
successful product `(8, "done")`. The ordinary `make` function shall accept
exact `Optional (Int, String)` and return the fresh continuation without
closing it. The ordinary `consume` function shall receive sole ownership,
traverse it with the exact discarded `value = (Some (7, "item"))` action, bind
the final Result, and return it. The root graph shall pass exact
`Some (7, "item")` through both transfer edges and print `(8, "done")`.

The checked model shall preserve the nominal Optional and Result identities,
arithmetic-error vocabulary, success evidence, positional-product arity and
field order, and independent Generator directions. It shall separately retain
declaration, parameter-derived construction, exact call-specialized input,
suspension, tag-gated and field-wise action, Unit resumption, final-result
graph, both function-transfer edges, and once-only consumption. The
factory-local input shall be replaced by the already evaluated caller Optional
without reevaluation. Factory exit and consumer entry shall not deliver close.
Optional tag checks, Int/String field equality, successful Result construction,
and return shall remain ordered at LLVM O0 without relying on inlining,
folding, or dead-code elimination.

On Linux x86-64, the private factory shall lower from the existing Topal-owned
Optional pointer to an `i32` ownership token, and the private consumer shall
lower from that token to the existing Topal-owned Result pointer. Product
payloads shall retain their Topal-owned aligned Int/String pointer storage.
LLVM `fastcc`, the target triple, and target data layout shall determine
placement and alignment; no AMD64 register or return convention shall be
hard-coded. A target-aligned factory parameter shadow shall retain the
otherwise compile-time-only input lifetime. DWARF/GDB shall expose the complete
Generator classifier, Optional and Result product classifiers, error
vocabulary, initial/yield/final values, ordinary-function frames, and Topal
entry frame.

Other nested classifiers, alternatives, product shapes, inputs, declarations,
factories, consumers, actions, results, arities, recursion, nesting, repeated
use, abandonment, close handling, packages, libraries, and external boundaries
shall remain rejected before LLVM. This shall add no semantic Generator object
or state allocation, transfer/traversal dispatcher, callback, indirect call,
unwind dependency, foreign runtime, C/C++ runtime, other-language standard
library, needed library, dynamic relocation, public/library calling convention,
Generator/Optional/Result/product ABI, or `topal-native/6` revision. Future
compiled-library metadata shall encode nominal wrapper identities and
alternatives, error vocabulary, recursive product arity/order/field identities,
complete Generator directions, declaration/body/suspension graphs,
construction and transfer sites, exact or symbolic captures, tag and
field-operation provenance, effects, ownership/consumption/close state,
final-result evidence, native-representation identity, and target adapters
rather than private specializations, tokens, debug slots, object layouts, or
checked-program nodes. This realizes
`TOPAL-COMPILER-GENERATOR-NESTED-FUNCTION-BOUNDARY-001`,
`TOPAL-GENERATOR-FUNCTION-CLASSIFIER-001`,
`TOPAL-GENERATOR-FUNCTION-RESULT-001`,
`TOPAL-GENERATOR-FUNCTION-PARAMETER-001`,
`TOPAL-GENERATOR-FOREACH-RESULT-001`, `TOPAL-TYPE-OPTIONAL-CONSTRUCT-001`,
`TOPAL-TYPE-RESULT-001`, and `TOPAL-TYPE-PRODUCT-001` for compiler increment
5aw.

## TOPAL-COMP-GENERATOR-LIST-FUNCTION-BOUNDARY-001 — Specialized List continuation transfer

The checked compiler shall admit the unchanged
`examples/language/custom-generator-list-values.t` regression. Its exact
`relay` declaration shall be `Generator List Int Unit List Int`, yield its
initial List once, resume with Unit, and return `initial append 9`. The ordinary
`make` function shall accept exact `List Int` and return the fresh continuation
without closing it. The ordinary `consume` function shall receive sole
ownership, traverse it with the exact discarded `entry-count values` action,
bind the final List, and return it. The root graph shall pass exact `one 7`
through both transfer edges and print
`Entry ( 7, Entry ( 9, Empty ) )`.

The checked model shall preserve recursive List identity, the exact Int element
classifier, immutable entry order, independent Generator directions,
declaration, parameter-derived construction, exact call-specialized input,
suspension, action, final append graph, both function-transfer edges, and once-
only consumption. The factory-local input shall be replaced by the already
evaluated caller List without reevaluation. Factory exit and consumer entry
shall not deliver close. The entry-count action shall complete before Unit
resumption, followed in order by final singleton allocation, immutable append,
and return at LLVM O0 without relying on inlining, folding, or dead-code
elimination.

On Linux x86-64, the private factory shall lower from the existing Topal-owned
`List Int` pointer to an `i32` ownership token, and the private consumer shall
lower from that token to the existing List pointer. LLVM `fastcc`, the target
triple, and target data layout shall determine physical placement and
alignment; no AMD64 register or return convention shall be hard-coded. A
target-aligned factory parameter shadow and List action/final-lifetime shadows
shall retain otherwise compile-time-only values. DWARF/GDB shall expose the
complete Generator classifier, initial, yielded and final Lists, ordinary-
function frames, and Topal entry frame.

Other List element classifiers, inputs, declarations, factories, consumers,
actions, final operations or values, yields, directions, arities, recursion,
nesting, repeated use, abandonment, close handling, packages, libraries, and
external boundaries shall remain rejected before LLVM. This shall add no
semantic Generator object/state allocation, transfer/traversal dispatcher,
callback, indirect call, unwind dependency, foreign runtime, C/C++ runtime,
other-language standard library, foreign allocator, needed library, dynamic
relocation, public/library calling convention, Generator/List ABI, or
`topal-native/6` revision. Future compiled-library metadata shall encode
recursive nominal List identity, element classifier, immutable operation and
allocation effects, complete Generator directions, declaration/body/suspension
graph, construction and transfer sites, exact or symbolic captures,
action/final-operation provenance, ownership/consumption/close state, native-
representation identity, and target adapters rather than private
specializations, tokens, node pointers/layouts, debug slots, or checked-program
nodes. This realizes
`TOPAL-COMPILER-GENERATOR-LIST-FUNCTION-BOUNDARY-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`,
`TOPAL-GENERATOR-FUNCTION-CLASSIFIER-001`,
`TOPAL-GENERATOR-FUNCTION-RESULT-001`,
`TOPAL-GENERATOR-FUNCTION-PARAMETER-001`,
`TOPAL-GENERATOR-FOREACH-RESULT-001`, `TOPAL-TYPE-LIST-CONSTRUCT-001`,
`TOPAL-LIST-APPEND-001`, and `TOPAL-LIST-ENTRY-COUNT-001` for compiler increment
5ax.

## TOPAL-COMP-GENERATOR-PRODUCT-001 — Exact positional-product generator directions

The checked compiler shall admit a root custom generator with one named
`(Int, String)` initial parameter and directions
`Generator (Int, String) Unit (Int, String)`. Its body shall consist only of one
discarded `yield initial` followed by `(8, "done")` as its final expression. The
shared regression starts the generator with `(7, "item")`; the fresh result
shall be bound and consumed exactly once by a foreach action consisting only of
the discarded `value = (7, "item")` for its named yielded parameter.

The checked program shall retain positional-product arity, source field order,
the Int and String field classifiers separately in all three Generator
directions, the initial-parameter yield and suspension, field-wise equality
action, Unit resumption, distinct final product, declaration provenance, and
ownership edge. Application shall evaluate both initial fields once from left
to right. Traversal shall pass that same immutable product to the action,
compare its Int and String fields in order, resume with Unit, and only then
materialize `(8, "done")` as the final product. This order shall hold with LLVM
optimization disabled and shall not depend on folding, inlining, or dead-code
elimination.

On Linux x86-64, the product shall use the existing compiler-private LLVM
aggregate of Topal-owned Int and String pointers, and the root-local Generator
shall remain a compiler-private `i32` ownership token. LLVM shall derive
aggregate placement, alignment, and call lowering from the target triple and
data layout; the backend shall hard-code no AMD64 register convention. Two
aligned debug-only product shadows and four lifetime/source anchor stores shall
keep the yielded action value and captured initial inspectable. DWARF and GDB
shall expose the complete
`Generator (Int, String) Unit (Int, String)` classifier and value, ordered `_0`
and `_1` product members, the yielded `(7, "item")`, captured initial
`(7, "item")`, ordered yield/action/resumption/final source locations, and the
Topal entry frame.

Another product arity, field classifier, order, literal, or direction; literal
or multiple yields; a final expression or action other than the exact products
above; labeled products; additional body statements; close handling; nested
construction; ordinary-function construction or Generator parameter/result
transfer outside `TOPAL-COMP-GENERATOR-COMPOUND-FUNCTION-BOUNDARY-001`; repeated
consumption; abandonment; libraries; and external boundaries shall remain
rejected before LLVM. The lowering shall introduce no semantic Generator
object or state allocation, dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator/product
ABI, or `topal-native/6` revision. Product equality/display, Int/String storage,
and Linux syscalls shall remain wholly owned by Topal. Future compiled-library
metadata shall encode independent initial and direction classifiers,
positional-product arity and ordered field identities, field equality, ordered
yield/action/resume/final provenance, allocation-failure effects, declaration
and construction sites, captures/effects, ownership/consumption/close state,
native-representation identity, and target adapters rather than expose the
private token, debug slots, aggregate/pointer layouts, or checked-program node
layout. This realizes `TOPAL-COMPILER-GENERATOR-PRODUCT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-TYPE-PRODUCT-001` for compiler increment 5aj.

## TOPAL-COMP-GENERATOR-ENUM-001 — Exact nominal Enum generator directions

The checked compiler shall admit the exact prior declaration
`Choice is Enum (First, Second)` followed by a root custom generator with one
named `Choice` initial parameter and directions
`Generator Choice Unit Choice`. Its body shall consist only of one discarded
`yield initial` followed by `Second` as its final expression. The shared
regression starts the generator with `First`; the fresh result shall be bound
and consumed exactly once by a foreach action consisting only of the discarded
`choice = First` for its named yielded parameter.

The checked program shall retain the nominal Choice identity, ordered First and
Second alternatives and private tags separately from all three Generator
directions, the initial-parameter yield and suspension, exact equality action,
Unit resumption, distinct final alternative, declaration provenance, and
ownership edge. Application shall evaluate its initial expression exactly once.
Traversal shall pass that same immutable Choice value to the action, compare it
with First once, resume with Unit, and only then produce Second as the final
Choice value. This order shall hold with LLVM optimization disabled and shall
not depend on folding, inlining, or dead-code elimination.

On Linux x86-64, Choice shall retain its existing compiler-private `i32` tag
representation, and the root-local Generator shall remain a compiler-private
`i32` ownership token. LLVM shall select placement and call lowering from the
target triple and data layout; the backend shall hard-code no AMD64 register
convention. Two aligned debug-only `i32` shadow slots and four lifetime/source
anchor stores shall keep the yielded action value and captured initial
inspectable even when LLVM folds the constant equality and final tag selection.
DWARF and GDB shall expose the complete `Generator Choice Unit Choice`
classifier and value, the Choice alternatives, yielded First, captured initial
First, ordered yield/action/resumption/final source locations, and the Topal
entry frame.

Another Enum declaration, alternatives, order, or direction; literal or
multiple yields; a final expression or action other than the exact alternatives
above; additional body statements; close handling; nested or ordinary-function
construction; Generator parameter/result transfer; repeated consumption;
abandonment; libraries; and external boundaries shall remain rejected before
LLVM. The lowering shall introduce no semantic Generator object or state
allocation, dispatcher, callback, indirect call, unwind dependency, C/C++
runtime, other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Enum comparison, display, and Linux syscalls shall remain wholly
owned by Topal. Future compiled-library metadata shall encode independent
initial and direction classifiers, nominal Enum identity, ordered alternative
identities and tags, equality operands, ordered yield/action/resume/final
provenance, declaration/construction sites, captures/effects, ownership/
consumption/close state, native-representation identity, and target adapters
rather than expose the private token, debug slots, tag layout, or checked-
program node layout. This realizes `TOPAL-COMPILER-GENERATOR-ENUM-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-TYPE-ENUM-001` for compiler increment 5ai.

## TOPAL-COMP-GENERATOR-NAT-001 — Exact Nat generator directions

The checked compiler shall admit a root custom generator with one named `Nat`
initial parameter and directions `Generator Nat Unit Nat` whose body consists
only of one discarded `yield initial` followed by `initial + 1` as its final
expression. One currently admitted `Nat` expression shall start the generator;
the shared regression uses the statically proven construction `Nat 7`. The
fresh result shall be bound and consumed exactly once by a foreach action
consisting only of the discarded `value + 1` for its named yielded parameter.

The checked program shall retain the Nat refinement identity separately from
its underlying exact Int representation and from all three Generator
directions, the proof-bearing input construction, initial-parameter yield and
suspension, exact action and final additions, Unit resumption, and ownership
edge. Application shall evaluate its initial expression exactly once. For the
shared closed input, construction shall preserve the nonnegative proof without
a runtime validation call. Traversal shall pass that same immutable Nat value
to the action, add exact one once, resume with Unit, and only then add exact one
to the captured initial for the final Nat value `8`. This order shall hold with
LLVM optimization disabled and shall not depend on folding, inlining, or dead-
code elimination.

On Linux x86-64, Nat shall retain its existing compiler-private representation
as an aligned pointer to Topal-owned arbitrary-precision Int storage; the
nonnegative constraint shall not introduce a native unsigned-integer ABI. The
root-local Generator shall remain a compiler-private `i32` ownership token.
LLVM shall select placement and call lowering from the target triple and data
layout; the backend shall hard-code no AMD64 register convention. Two aligned
debug-only pointer shadows shall preserve the yielded action value and captured
initial lifetime. DWARF and GDB shall expose the complete
`Generator Nat Unit Nat` classifier and value, the yielded Nat `7`, the
captured initial Nat `7`, ordered yield/action/resumption/final source
locations, and the Topal entry frame.

Literal or multiple yields; a final expression or action other than the exact
increments; additional body statements; another input, yield, resume, or final
classifier; general Nat arithmetic outside this exact graph; close handling;
nested or ordinary-function construction; Generator parameter/result transfer;
repeated consumption; abandonment; libraries; and external boundaries shall
remain rejected before LLVM. The lowering shall introduce no semantic Generator
object or state allocation, dispatcher, callback, indirect call, unwind
dependency, C/C++ runtime, other-language standard library, needed library,
dynamic relocation, public/library calling convention or Generator ABI,
unsigned machine arithmetic, or `topal-native/6` revision. Exact integer
storage, allocation, addition, display, and Linux syscalls shall remain wholly
owned by Topal. Future compiled-library metadata shall encode independent
initial and direction classifiers, Nat refinement/proof and underlying Int
identities, validation provenance, exact addition operands, ordered yield/
action/resume/final provenance, allocation-failure effects, declaration/
construction sites, captures/effects, ownership/consumption/close state,
native-representation identity, and target adapters rather than expose the
private token, debug slots, Int object layout, or checked-program node layout.
This realizes `TOPAL-COMPILER-GENERATOR-NAT-001`,
`TOPAL-GENERATOR-DECLARATION-001`, `TOPAL-GENERATOR-SUSPEND-001`, and
`TOPAL-NUM-NAT-CONSTRUCT-001` for compiler increment 5ah.

## TOPAL-COMP-GENERATOR-RANGE-001 — Exact Range generator directions

The checked compiler shall admit a root custom generator with one named
`Range Int` initial parameter and directions
`Generator Range Int Unit Range Int` whose body consists only of one discarded
`yield initial` followed by `initial and (5 ..= 15)` as its final expression.
One currently admitted `Range Int` expression shall start the generator; the
shared regression uses `0 ..= 10`. The fresh result shall be bound and consumed
exactly once by a foreach action consisting only of the discarded membership
`5 in interval` for its named yielded parameter.

The checked program shall retain the Range classifier and nominal Int endpoint
classifier separately from all three Generator directions, the initial-
parameter yield and suspension, exact membership action, Unit resumption,
distinct final inclusive-bound construction and intersection, and ownership
edge. Application shall evaluate and construct its initial expression exactly
once. Traversal shall pass that same immutable Range value to the action,
evaluate membership once, resume the generator with Unit, and only then
construct `5 ..= 15` and intersect it with the initial value. The resulting
inclusive range shall be `5 ..= 10` for the shared source. This order shall
hold with LLVM optimization disabled and shall not depend on folding, inlining,
or dead-code elimination.

On Linux x86-64, the existing compiler-private Range representation shall
remain an aligned pointer to Topal-owned finite storage containing Int endpoint
pointers and inclusion flags. The root-local Generator shall remain a compiler-
private `i32` ownership token. LLVM shall select placement and call lowering
from the target triple and data layout; the backend shall hard-code no AMD64
register convention. Two aligned debug-only pointer shadows shall preserve the
yielded action value and captured initial lifetime. DWARF and GDB shall expose
the complete `Generator Range Int Unit Range Int` classifier and value, the
yielded `0 ..= 10`, the captured initial `0 ..= 10`, ordered yield/action/
resumption/final source locations, and the Topal entry frame.

Literal or multiple yields; a final expression other than the exact
intersection; additional body statements; another endpoint, action, input,
yield, resume, or final classifier; close handling; nested or ordinary-function
construction; Generator parameter/result transfer; repeated consumption;
abandonment; libraries; and external boundaries shall remain rejected before
LLVM. The lowering shall introduce no semantic Generator object or state
allocation, dispatcher, callback, indirect call, unwind dependency, C/C++
runtime, other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Range/Int storage, allocation, membership, intersection, display, and
Linux syscalls shall remain wholly owned by Topal. Future compiled-library
metadata shall encode independent initial and direction classifiers, the
nominal endpoint identity, exact bounds, inclusivity, membership and
intersection operands, ordered yield/action/resume/final provenance,
allocation-failure effects, declaration/construction sites, captures/effects,
ownership/consumption/close state, native-representation identity, and target
adapters rather than expose the private token, debug slots, Range/Int object
layouts, or checked-program node layout. This realizes
`TOPAL-COMPILER-GENERATOR-RANGE-001`, `TOPAL-GENERATOR-DECLARATION-001`,
`TOPAL-GENERATOR-SUSPEND-001`, `TOPAL-RANGE-BOUNDS-001`, and
`TOPAL-RANGE-CLASSIFIER-001` for compiler increment 5ag.

## TOPAL-COMP-FUNCTION-001 — Scalar overloads and static functions

The compiler shall preserve source-ordered overload sets whose admitted
ordinary or static declarations have nullary, unary, or positional-product
scalar inputs. Declarations with identical input classifiers and staticness
shall be rejected regardless of parameter names or result classifiers. An
application shall analyze its arguments once and select the first header whose
input classifiers are statically proven applicable, including the admitted
lossless exact-number classifications and conversions; result context shall not
alter selection.

Every selected overload shall have a distinct checked call-graph identity,
private LLVM function, DWARF subprogram, parameters, and invocation-local
bindings. A static function body shall select only static callees, while root
and ordinary bodies may call ordinary or static declarations. Staticness shall
not create a public ABI distinction or permit compile-time execution to alter
observable behavior at O0.

Complete explicitly classified headers in one declaration scope shall be
collected before selected bodies are checked, permitting an admitted acyclic
body to call a later function declaration. Depth-first instantiation shall place
that callee before its caller in the checked program and emitted module while
ordinary value initializers remain source-ordered. DWARF and GDB shall retain
both source functions and their nested runtime frames.

These additions cover the admitted scalar cases of
`TOPAL-FUNCTION-STATIC-NULLARY-001`, `TOPAL-FUNCTION-STATIC-UNARY-001`,
`TOPAL-FUNCTION-STATIC-BINARY-001`, `TOPAL-FUNCTION-BLOCK-001`,
`TOPAL-FUNCTION-ORDINARY-001`, `TOPAL-FUNCTION-CALL-CHAIN-001`,
`TOPAL-FUNCTION-LOCAL-SCOPE-001`, `TOPAL-FUNCTION-OVERLOAD-001`,
and `TOPAL-FUNCTION-FORWARD-DECLARATION-001`. Dynamic structural applicability,
function values, nested functions, remaining recursion and its overload-identity
rules, and other function forms remain in later increment-3 dispositions.

## TOPAL-COMP-ROOT-NAMESPACE-001 — Direct executable-root qualification

For the admitted single-source application subset, the checked compiler model
shall recognize `root` as the executable root Scope value and shall resolve a
directly qualified root function from the collected root declarations before
ordinary source-ordered overload selection. The remaining operands shall be
analyzed once under the existing call rules, and a same-named lexical binding
shall not intercept the qualified root member. Binding or displaying `root`
shall not copy, flatten, or execute its declarations, and canonical display
shall match the interpreter's `<namespace root>` observation.

The backend shall render the sealed root identity through the Topal-owned Linux
writer and lower a qualified call directly to the selected private function.
DWARF/GDB shall retain the selected source function, typed argument, call site,
and runtime frame at O0. This shall require no runtime namespace lookup, Scope
object allocation, foreign dependency, C/C++ runtime, other-language standard
library, public tag ABI, or `topal-native/6` revision.

Qualified namespace-alias lookup, classified Scope bindings, root data-member
lookup, `use`, published interfaces, generators, package loading, and
compiled-library resolution remain rejected in this increment. This requirement
covers the direct-value and qualified-function subset of
`TOPAL-NAMESPACE-ROOT-001` and realizes
`TOPAL-COMPILER-ROOT-NAMESPACE-001` for compiler increment 6a.

## TOPAL-COMP-NAMESPACE-USE-001 — Static root namespace use

At source root, the checked compiler model shall accept `use root` and `use`
of an already retained root alias. It shall require the operand to be Scope,
preserve the same concrete root identity and source-position declaration
snapshot for optional binding, and diagnose a non-Scope operand with the shared
`E-USE-NON-NAMESPACE`. Subsequent qualified function or data selection shall
use the existing retained namespace facts without flattening them into lexical
lookup.

The backend shall erase the `use` operation itself. An observed binding shall
reuse the existing private Scope tag, display, and DWARF/GDB type, while
qualified functions remain direct private calls and qualified data retain their
original already-evaluated storage identity. Native tests shall cover the
existing interpreter regression, root and alias operands, non-Scope rejection,
exact output, checked snapshots, absent use/namespace runtime IR, freestanding
artifacts, source frames, Scope/value debugging, the shared corpus, and separate
resource baselines.

This shall add no lookup table, allocation, indirect dispatch, filesystem or
process-global resolution, foreign dependency, C/C++ runtime, other-language
standard library, public Scope ABI, or `topal-native/6` revision.
Multi-component or non-root published paths, nested namespaces, generator
members, function-body `use`, packages, source/compiled libraries, and public
interface metadata remain rejected. This realizes
`TOPAL-COMPILER-NAMESPACE-USE-001` and `TOPAL-NAMESPACE-USE-001` for compiler
increment 6b3a.

## TOPAL-COMP-LIBRARY-DEPENDENCY-001 — Dependency-only library selection

The checked compiler shall accept the `std` and `advent-of-code` v0.1 library
declarations in the source-root dependency prefix and shall reproduce the
shared unavailable-library, version, duplicate, and ordering diagnostics.
When no selected-library member is referenced, lowering shall erase the
declaration completely while the source digest continues to cover it.

Native tests shall compile the shared standard-library harness and the first
data-transfer application, compare their exact interpreter output, validate
freestanding ELF/DWARF, prove absent library/namespace runtime IR, and retain
empty artifact dependency metadata. This shall add no linked dependency,
initializer, authority, filesystem lookup during execution, public interface,
or `topal-native/6` revision. Qualified library members and source/compiled
library loading remain rejected rather than being replaced by compiler-owned
semantics. This realizes `TOPAL-COMPILER-LIBRARY-DEPENDENCY-001`,
`TOPAL-SYN-LIBRARY-001`, and `TOPAL-LIB-DEPENDENCY-001` for compiler increment
6b4.

## TOPAL-COMP-LIBRARY-SOURCE-001 — Qualified source-library functions

For selected v0.1 libraries, the compiler shall discover referenced ordinary
module files below the configured library root, parse them as Topal source, and
resolve qualified terminals only from published functions. A compiled
published function may call unpublished helpers in the same module. Qualified
Function aliases, packaged parameters, source overload ordering, and recursive
Nat adaptation shall use the shared checked model rather than compiler-owned
library definitions.

Each contributing module shall produce one sorted native-artifact dependency
entry containing its canonical path identity and SHA-256 source digest. The
application source digest shall exclude appended dependency text, while the
build identity shall include all dependency identities and digests. Lowering
shall specialize the selected source closure into direct private calls and add
no runtime namespace, runtime filesystem access, indirect call, foreign
dependency, public ABI, or `topal-native/6` revision.

Tests shall cover published and private visibility, module-local helper calls,
qualified aliases, the firewall and REST-controller data-transfer programs,
exact interpreter output, dependency metadata, direct LLVM calls,
freestanding ELF/DWARF, the compiler corpus, and resource baselines. This
realizes `TOPAL-COMPILER-LIBRARY-SOURCE-001`, `TOPAL-LIB-SOURCE-001`, and
`TOPAL-NAMESPACE-USE-001` for compiler increment 6b5.

## TOPAL-COMP-LIBRARY-MODULE-SELECTION-001 — Selective source graph

The compiler shall select ordinary source files only for complete qualified
module paths and shall select a `module.t` facade only for a function that the
facade publishes. Nested references shall not pull prefix facades into artifact
dependencies. Unselected declarations may contain compiler-deferred language
forms; a selected declaration and its reachable same-module helper closure
shall be checked before any output is published.

Multi-source parsing shall preserve a leading hashbang at every dependency
boundary while dependency SHA-256 values continue to cover the exact original
bytes. Closed recursive evidence adaptation shall support independently valid
Tuple and Record fields at function arguments/results, classified bindings,
and equality without copying values, losing infinity evidence, or changing the
native ABI.

Tests shall cover exact facade-versus-nested discovery, source hashbangs,
deferred unused declarations, dependency identities/digests, the device I2C,
network-address, and HTTP standard-library conformance programs, exact
interpreter output, direct LLVM calls, freestanding ELF/DWARF, the compiler
corpus, and resource baselines. This realizes
`TOPAL-COMPILER-LIBRARY-MODULE-SELECTION-001`, `TOPAL-LIB-SOURCE-001`, and
`TOPAL-NAMESPACE-USE-001` for compiler increment 6b6.

## TOPAL-COMP-LIBRARY-GENERIC-001 — Source-generic specialization

The checked compiler shall infer consistent concrete classifier substitutions
for selected source-library Function parameters bound by `Type`, `TotalOrder`,
and their later occurrences inside admitted Optional, List, Range, and Tuple
classifiers. TotalOrder substitutions shall require independently supported
ordering evidence. Substitutions shall cover overload selection, parameters,
the authoritative source body, same-module helper calls, and results; invalid
or inconsistent substitutions shall reject before LLVM or artifact output.

The backend shall lower each selected concrete instance as an existing private
direct call without runtime type descriptors, generic dispatch, indirect calls,
compiler-owned standard-library semantics, foreign dependencies, public ABI, or
native ABI revision. Optional List payloads shall reuse the admitted private
pointer carrier. Tests shall cover Int and Rational ordering, tuple results,
Optional presence and fallback, Range observations, a packaged generic List
operation through a private generic helper, exact interpreter output, capability
rejection without an artifact, selective dependency metadata, freestanding
ELF/DWARF, the compiler corpus, and bounded validation. This realizes
`TOPAL-COMPILER-LIBRARY-GENERIC-001`, `TOPAL-LIB-SOURCE-001`,
`TOPAL-TYPE-CALL-001`, and `TOPAL-CAPABILITY-COMPOSE-001` for compiler increment
6b7.

## TOPAL-COMPILER-STANDARD-LIBRARY-PARITY-001 — Standard facade parity

The compiler shall compile the unchanged standard-library facade application
with the same observable result as the interpreter. Source specialization
shall preserve generic substitutions through callable results, including named
and anonymous `Optional` and `Result` transformations, same-module helpers,
and generic result classifiers. Result decisions in a Result-returning context
shall lift successful values and forwarded Error values without replacing the
original Error provenance.

An ordinary Int iterate factory may return its fresh linear Generator through
a selected source-library Function boundary. A caller may retain that exact
provenance through a binding, apply a finite `take-while`, and collect it once.
Finite List folds shall admit Boolean state over Int entries and Optional state
whose payload equals the entry classifier; lowering shall retain the existing
private Boolean, Optional, List, and Result carriers and direct-call/loop
structure.

Tests shall compile `library/application.t`, execute both implementations, and
compare exact output while retaining selective `std` dependency metadata and
freestanding ELF/DWARF validation. This shall add no runtime type descriptor,
generic dispatch, callback ABI, foreign dependency, public ABI, or native ABI
revision. This realizes `TOPAL-COMPILER-STANDARD-LIBRARY-PARITY-001`,
`TOPAL-LIB-SOURCE-001`, `TOPAL-TYPE-CALL-001`,
`TOPAL-COLLECTION-FOLD-001`, and `TOPAL-GENERATOR-TAKE-WHILE-001`.

## TOPAL-COMP-LIBRARY-OPTIONAL-AGGREGATE-001 — Generic queue boundary

The checked compiler shall admit the concrete `(Int, List Int)` Optional
payload produced by generic queue decomposition and preserve its Tuple and List
classifiers through construction, private Function passage, decisions,
bindings, equality, and fallback selection. The backend shall box the payload
as two source-ordered target pointers, publish it only after initialization,
and load it only on the present branch. LLVM and DWARF shall agree on the
private target layout.

Tests shall promote the unchanged transfer-queues standard-library conformance
program, compare exact interpreter output, inspect direct private calls and the
two-pointer Optional payload path, verify selective source dependencies,
freestanding ELF/DWARF, the complete compiler corpus, and resource baselines.
This shall add no public aggregate ABI, generic descriptor or dispatch, indirect
call, foreign dependency, host collection, or native ABI revision. This realizes
`TOPAL-COMPILER-LIBRARY-OPTIONAL-AGGREGATE-001`,
`TOPAL-COMPILER-LIBRARY-GENERIC-001`, `TOPAL-TYPE-OPTIONAL-001`, and
`TOPAL-TYPE-PRODUCT-001` for compiler increment 6b8.

## TOPAL-COMP-LIBRARY-STRING-PAIR-FOLD-001 — Store lookup fold

The checked compiler shall admit a finite left fold over the existing private
`List (String, String)` node layout with `Optional String` state and an admitted
source Function action. It shall retain exact state/entry classifiers, evaluate
the action once per source-ordered entry, and return the initial state for an
empty List. The backend shall lower the fold as one direct LLVM loop loading
the two String pointers and next pointer at target-derived offsets, with no
callback ABI, indirect call, host iterator, or foreign collection runtime.

List and finite-container `entry-count` expressions shall retain `Nat` evidence
through checked bindings and private Function results while reusing the exact
integer carrier. Tests shall promote the unchanged store-memory conformance
program, cover absent/known/duplicate lookup, count and guarantee checks, exact
interpreter output, direct loop LLVM, selective dependencies, freestanding
ELF/DWARF, compiler corpus, and resource baselines. This realizes
`TOPAL-COMPILER-LIBRARY-STRING-PAIR-FOLD-001`, `TOPAL-COLLECTION-FOLD-001`,
`TOPAL-LIST-ENTRY-COUNT-001`, and `TOPAL-NUM-NAT-001` for compiler increment
6b9.

## TOPAL-COMP-LIBRARY-NAT-PAIR-FOLD-001 — Span gather fold

The checked compiler shall admit contextual `List (Nat, Nat)` construction,
private Function parameters, and finite source-library folds with exact Nat
state. Contextual typing shall recursively retain Nat evidence for both pair
fields and the initial state. The backend shall reuse the arbitrary-precision
integer pointer carrier and immutable 24-byte private pair/next node, load both
fields in source order, and execute one direct LLVM loop without Tuple payload
allocation, a callback ABI, indirect calls, host iteration, or a foreign
collection runtime.

Tests shall promote the unchanged data-spans conformance program, cover empty
and nonempty lists, zero and very large Nat spans, projection, bound and overlap
checks, exact gathered length, selective dependency discovery, exact
interpreter output, checked Nat evidence, direct loop LLVM, compiler corpus,
freestanding ELF/DWARF, and resource baselines. This realizes
`TOPAL-COMPILER-LIBRARY-NAT-PAIR-FOLD-001`, `TOPAL-COLLECTION-FOLD-001`,
`TOPAL-TYPE-LIST-CONSTRUCT-001`, and `TOPAL-NUM-NAT-001` for compiler increment
6b10.

## TOPAL-COMP-LIBRARY-STRING-LIST-FOLD-001 — Build graph closure

The checked compiler shall admit exact `List String` state through finite
source-library folds over String entries and String-pair edges. The backend
shall retain the existing private immutable layouts, pass state and entries to
direct specialized actions, and lower every fold as a finite source-ordered
LLVM loop. Exact String `contains-entry` shall be allocation-free. String List
`append` shall copy the immutable left prefix once and terminate it in a fresh
entry, without callback ABIs, indirect calls, host collections, or foreign
runtimes.

Tests shall promote the unchanged build-graph conformance program and cover
direct and transitive dependents, independent units, changed-unit retention,
cycles, duplicate suppression, empty inputs, exact interpreter output, direct
fold IR, runtime containment/append fragments, selective dependencies,
freestanding ELF/DWARF, compiler corpus, and resource baselines. This realizes
`TOPAL-COMPILER-LIBRARY-STRING-LIST-FOLD-001`, `TOPAL-COLLECTION-FOLD-001`,
`TOPAL-LIST-APPEND-001`, and `TOPAL-LIST-CONTAINS-ENTRY-001` for compiler
increment 6b11.

## TOPAL-COMP-LIST-NESTED-INT-001 — Nested Int Lists

The checked compiler shall admit exact `List List Int` construction, private
Function passage, entry count, and recursive equality. The backend shall use
one immutable two-pointer outer node, reuse the existing private `List Int`
representation and comparator, emit finite outer and inner loops, and retain
classifier-specific LLVM/DWARF identities. The context-free `one` constructor
shall also infer `List String` from a String operand and lower through the
existing String List node layout.

Focused checked-model and LLVM tests shall cover nested construction, direct
private passage, count, recursive equality, inferred String singleton
construction, runtime selection, DWARF identity, and absence of indirect calls
or foreign dependencies. This realizes `TOPAL-COMPILER-LIST-NESTED-INT-001`,
`TOPAL-TYPE-LIST-CONSTRUCT-001`, `TOPAL-TYPE-LIST-RECURSIVE-001`,
`TOPAL-TYPE-LIST-EQUALITY-001`, and `TOPAL-LIST-ONE-001` for compiler increment
6b12.

## TOPAL-COMP-NAMESPACE-FUNCTION-ALIAS-001 — Static function namespace aliases

For the admitted source-root subset, the checked compiler model shall retain an
immutable namespace snapshot when `root` or an existing alias is bound, with or
without an explicit `Scope` classifier. The snapshot shall preserve the root
identity, function declarations visible at the binding statement, complete
source-ordered overload sets, ordinary/static distinction, and the same facts
through a finite alias chain. Later declarations shall remain absent from an
earlier snapshot, and same-named caller bindings shall not intercept or combine
with qualified member selection.

Qualified function applications shall select from those captured declarations
and lower to the existing direct private LLVM call. The Scope value shall keep
its canonical display and target-exact DWARF enum identity, while captured
declarations remain checked frontend facts rather than runtime data. Native and
GDB tests shall cover alias observation, typed aliases, chaining, overload
selection, snapshot exclusion, exact output, and retained source call frames.

The implementation shall introduce no runtime namespace lookup, indirect call,
Scope allocation, foreign dependency, C/C++ runtime, other-language standard
library, public ABI, or `topal-native/6` revision. Data and generator members,
non-root alias bindings, general Scope function boundaries, `use`, packages,
and source/compiled libraries remain rejected. This requirement covers the
function-bearing subset of `TOPAL-NAMESPACE-ALIAS-001`,
`TOPAL-NAMESPACE-SNAPSHOT-001`, `TOPAL-NAMESPACE-OVERLOAD-001`,
`TOPAL-NAMESPACE-CLASSIFIER-001`, and `TOPAL-NAMESPACE-ALIAS-CHAIN-001`, and
realizes `TOPAL-COMPILER-NAMESPACE-FUNCTION-ALIAS-001` for increment 6b1.

## TOPAL-COMP-NAMESPACE-DATA-001 — Stable root data snapshots

The checked compiler model shall assign every admitted source-root binding a
stable internal storage identity distinct from its source/debug name. A binding
shall enter the live root data-member set only after its initializer has been
analyzed, and a root alias shall capture the data-member set visible at that
statement. Alias chains shall preserve that set, later root bindings shall not
retroactively enter it, and a published root binding shall have identical
single-application lookup behavior without becoming a native export.

Direct root and alias data selection in source-root executable blocks shall
produce a reference to the original binding identity. A lexical binding with
the same source name shall remain distinct, and code generation shall evaluate
the original initializer exactly once. DWARF/GDB shall retain source names and
the observable Scope alias even though LLVM environment keys use the stable
identities. Native tests shall cover alias chains, earlier snapshots versus the
live root, typed Scope aliases, publication, lexical shadow exclusion, exact
output, and freestanding artifact inspection.

This shall add no runtime namespace lookup/table, Scope allocation, foreign
dependency, C/C++ runtime, other-language standard library, public data ABI, or
`topal-native/6` revision. Function-body root-data access, nested qualified Scope
members, general Scope function boundaries, generators, `use`, packages, and
source/compiled libraries remain rejected by increment 6b2a. This realizes
`TOPAL-COMPILER-NAMESPACE-DATA-001` for increment 6b2a under
`TOPAL-NAMESPACE-ROOT-001`, `TOPAL-NAMESPACE-ALIAS-001`,
`TOPAL-NAMESPACE-SNAPSHOT-001`, `TOPAL-NAMESPACE-CLASSIFIER-001`, and
`TOPAL-NAMESPACE-ALIAS-CHAIN-001`.

## TOPAL-COMP-NAMESPACE-BOUNDARY-001 — Specialized Scope parameters

For an ordinary function called with the live source `root` Scope, a retained
root alias, or an already-specialized Scope parameter, the checked model shall
specialize each `Scope` parameter with the concrete namespace identity,
source-position declaration snapshot, function overload sets, and represented
data members. Qualified function calls shall use the existing direct
specialization path. For each non-discarded Scope parameter, the frontend shall
carry every data member with an admitted private representation as an exact
hidden argument, so direct selection and transitive Scope-parameter forwarding
reference the original already-evaluated value without caller-frame lookup. It
shall diagnose a missing selected member and a selected member that lacks an
admitted private representation.

The Linux x86-64 backend shall retain the explicit sealed `i32` Scope value and
append exact typed hidden parameters under private `fastcc`; definitions and
calls shall have identical LLVM types, and LLVM shall own physical register,
stack, and aggregate classification. It shall preserve the explicit Scope
parameter and material hidden arguments in DWARF/GDB at O0. Tests shall cover
the shared interpreter regression, data selection, direct qualified functions,
forwarding, stale alias rejection, single initializer execution, native
artifacts, source frames, and separate resource baselines.

This shall add no runtime namespace lookup/table, indirect dispatch, Scope or
environment allocation, foreign dependency, C/C++ runtime, other-language
standard library, public Scope ABI, or `topal-native/6` revision. Scope results
or escape, function-local live-root arguments, nested/non-root namespaces,
generator members, `use`, and compiled-library environments remain deferred.
Exact root and root-alias package fields are governed by
`TOPAL-COMP-SCOPE-PACKAGED-FIELD-001`; all other Scope package forms remain
deferred. This realizes `TOPAL-COMPILER-NAMESPACE-BOUNDARY-001` and
`TOPAL-NAMESPACE-FUNCTION-BOUNDARY-001` for increment 6b2b1.

## TOPAL-COMP-NAMESPACE-GENERATOR-001 — Static qualified generator application

For a source-root `root` value or retained root alias, the checked compiler
model shall include every generator declaration visible in that namespace
snapshot, preserving namespace identity, source-ordered overloads, declared
directions, checked body graph, and source provenance. A qualified application
shall resolve only in that captured generator set, apply the existing checked
generator rules, evaluate each input exactly once, and create a fresh affine
continuation with the same ownership and close obligations as an unqualified
application. A declaration introduced after an alias binding shall remain
absent from that alias while remaining available through a later live `root`.

The initial Linux x86-64 subset shall qualify every custom-generator graph that
the compiler otherwise admits; the unchanged
`examples/language/namespace-generator.t` regression exercises the existing
single-Character-yield O0 path, and checked tests shall also cover qualified
overload preservation. Namespace selection shall be complete before LLVM
lowering; the backend shall reuse the selected checked graph and inline
suspension traversal while preserving Scope, Generator, yielded values, and
source locations in DWARF/GDB. Native tests shall cover alias and direct-root
selection, snapshot exclusion, fresh linear consumption, exact interpreter
output, freestanding artifacts, and separate resource baselines.

This shall add no runtime namespace lookup/table, continuation object,
callback, indirect dispatch, foreign dependency, C/C++ runtime, other-language
standard library, public generator ABI, or `topal-native/6` revision. A future
compiled-library interface that publishes such a member shall carry stable
namespace and revision identity, visibility, the generator overload signature,
checked directions and body graph, capture/effect/linearity/ownership facts,
close and suspension behavior, semantic representation identity, and a
versioned target adapter; it shall not expose compiler-private tags or symbols
as portable identity. Non-root/external namespaces, Scope parameters or results
whose selected members are generators, generator shapes the compiler does not
otherwise admit, dynamic or escaping qualified generator values, packages, and
source/compiled libraries remain deferred. This realizes
`TOPAL-COMPILER-NAMESPACE-GENERATOR-001` and
`TOPAL-NAMESPACE-GENERATOR-001` for increment 6b2b2a.

## TOPAL-COMP-FUNCTION-ROOT-DATA-001 — Private live-root data capture

For an ordinary root function called directly from the source entry frame, the
checked model shall resolve each exact `root member` data selection against the
live root bindings whose initializers have completed at the call position. It
shall admit supported private machine values even when their declarations
follow the function declaration, isolate the qualified selection from
same-named parameters or lexical captures, and reuse the original once-evaluated
root storage value.

The frontend shall append referenced members in root declaration order as exact
private capture arguments and parameters named `root member`. The Linux x86-64
backend shall emit matching `fastcc` definitions and calls and leave physical
register, stack, and aggregate placement to LLVM. Full O0 DWARF/GDB shall expose
the ordinary function frame, explicit parameters, root capture classifiers, and
values. Tests shall cover the shared interpreter regression, a function declared
before its root data, lexical shadow isolation, initializer order, checked-model
capture order and rejection boundaries, exact IR, freestanding artifacts,
source debugging, the shared corpus, and separate resource baselines.

This shall add no global root storage, namespace/capture table, initializer
replay, lookup, allocation, function pointer, indirect call, foreign dependency,
C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Exact scalar forwarding is governed by
`TOPAL-COMP-FUNCTION-ROOT-DATA-FORWARD-001`. Aggregate values beyond
`TOPAL-COMP-AGGREGATE-ENVIRONMENT-001`, callable, Scope, Generator, constraint,
or evidence members; anonymous/escaping functions; other qualified-root forms;
and public/library root environments remain deferred.
Future compiled-library metadata shall preserve canonical
source-session namespace identity, selection/call positions, member stable
identity, visibility/declaration order, classifier/semantic representation,
capture order/lifetime/effects, and a versioned target adapter independently of
private capture names, LLVM types/symbols, and physical placement. This realizes
`TOPAL-COMPILER-FUNCTION-ROOT-DATA-001` and `TOPAL-NAMESPACE-ROOT-001` for
increment 6b2b2b.

## TOPAL-COMP-FUNCTION-ROOT-DATA-FORWARD-001 — Private live-root data forwarding

For a finite acyclic chain of statically named ordinary root functions reached
from the source entry frame, the checked model shall compute transitive exact
`root member` selections before instantiating the outer function. It shall
append every required supported private machine value to each intermediate
function's hidden capture group in root declaration order and forward the same
already-evaluated value at every direct call edge. The live root snapshot shall
be the one visible at the outer entry-frame call position, and same-named
ordinary parameters or locals shall remain isolated in every frame.

The Linux x86-64 backend shall emit matching exact `fastcc` definitions and
calls and leave physical placement to LLVM. Full O0 DWARF/GDB shall expose all
explicit and forwarded parameters accurately in the active function and every
suspended caller frame. Target-aligned debug-only stack shadows may preserve
call-clobbered values without adding semantic storage. Tests shall cover a
three-frame shared regression, interpreter modes, reversible history, checked
capture order and call arguments, unresolved overload-selection rejection,
exact direct IR, artifact-free failure, freestanding ELF/DWARF, every GDB frame,
the shared corpus, and separate resource baselines.

This shall add no global root storage, namespace/capture/environment table,
initializer replay, lookup, allocation, function pointer, indirect call,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Overload forwarding beyond
`TOPAL-COMP-OVERLOAD-ENVIRONMENT-001`, recursive forwarding beyond
`TOPAL-COMP-RECURSIVE-SCALAR-ENVIRONMENT-001`, local named Function forwarding
beyond `TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001`, anonymous functions,
aggregate environments beyond
`TOPAL-COMP-AGGREGATE-ENVIRONMENT-001`, otherwise unsupported root members,
defining-context forwarding beyond
`TOPAL-COMP-CONTEXT-CAPTURE-FORWARD-001`, escape, and
public/library environments remain deferred. Future compiled-library metadata
shall preserve canonical source-session namespace identity, every selection and
call edge, callee identity/overload, member stable identity,
visibility/declaration order, classifier/semantic representation, capture
order/lifetime/effects, and a versioned target adapter independently of private
names, LLVM types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-FUNCTION-ROOT-DATA-FORWARD-001` and
`TOPAL-NAMESPACE-ROOT-001` for increment 6b2b2c.

## TOPAL-COMP-NAMED-FUNCTION-VALUE-001 — Retained named function values

The checked compiler model shall admit an already-visible ordinary or static
root function in value position, retaining its source identity, visible
declarations, source-ordered overload set, and staticness. Binding and rebinding
that Function value shall preserve the retained candidates. Applying an alias
shall use the original function name for overload, recursion, specialization,
and diagnostics and shall not restart lookup at the alias or caller scope.

The program model shall expose a deterministic module-local name table so
expression tags, canonical `<fn name>` display, and Function DWARF enumerators
agree. LLVM lowering shall nevertheless call the selected private `fastcc`
symbol directly; neither the tag nor a native pointer shall dispatch the call.
Native and GDB tests shall cover exact execution, retained value identity,
typed aliases, binding chains, snapshot overload exclusion, lexical shadowing,
Function display, argument inspection, and source frames.

The implementation shall introduce no indirect call, closure allocation,
Function runtime, foreign dependency, C/C++ runtime, other-language standard
library, public callable ABI, or `topal-native/6` revision. Symbolic callables,
anonymous functions/captures, Function parameters/results, namespace selection
of function-valued data, and published callable interfaces remain rejected.
This realizes `TOPAL-COMPILER-NAMED-FUNCTION-VALUE-001` and the admitted portion
of `TOPAL-FUNCTION-VALUE-001` for compiler increment 3b2-b5j.

## TOPAL-COMP-SYMBOLIC-CALLABLE-VALUE-001 — Direct symbolic Function values

The checked compiler model shall admit `+`, `-`, and `<=>` in value position,
retain the exact symbolic identity through unclassified or `Function`-classified
bindings and binding chains, and reject invalid application arity with the
ordinary no-applicable-overload diagnostic. Bound binary application shall
unpack one two-field positional product before using the existing numeric and
comparison checks; bound `-` shall additionally retain unary negation.

The module-local Function observation table shall include `+`, `-`, and `<=>`
in deterministic order after named functions whenever Function values are
used. Canonical output and DWARF/GDB shall retain those spellings. Code generation
shall lower the selected callable directly to the existing LLVM operation or
Topal-owned numeric primitive and shall not dispatch through the observation
tag. Native tests shall cover exact add, unary/binary subtraction, three-way
comparison, Function classification, binding chains, display, and debugging.

This shall add no function pointer, indirect call, Function runtime, closure
allocation, foreign dependency, C/C++ runtime, other-language standard library,
public callable ABI, or `topal-native/6` revision. Other symbolic callables,
Function parameters/results, anonymous functions/captures, and published
callable interfaces remain rejected. This realizes
`TOPAL-COMPILER-SYMBOLIC-CALLABLE-VALUE-001` and the admitted portion of
`TOPAL-FUNCTION-CALLABLE-VALUE-001` for compiler increment 3b2-b5k.

## TOPAL-COMP-SYMBOLIC-CALLABLE-EXPANDED-001 — Complete symbolic Function values

The checked compiler model shall admit `=`, `!=`, `<`, `>`, `<=`, `>=`, `*`,
`/`, `/%`, `%`, `^`, `..`, `<..`, `..=`, and `<..=` in value position in
addition to the existing `+`, `-`, and `<=>` values. Bindings and private
Function parameter/result specializations shall retain each exact callable.
Binary application shall unpack one two-field positional product and reuse the
existing checked operation so conversions, fallibility, result classifiers,
range endpoint policy, and diagnostics remain identical to direct syntax.

The module-local observation table shall retain the existing first three tags,
append every newly admitted canonical spelling deterministically, and observe
source `!=` as canonical `/=`. LLVM lowering shall emit the already-selected
direct operation or Topal-owned runtime primitive. Native tests shall cover all
new identities, exact interpreter parity, private Function result passage,
stable tags, direct IR, freestanding artifacts, full O0 DWARF/GDB values and
frames, the shared corpus, and separate resource baselines.

This shall add no function pointer, indirect call, Function runtime, closure
allocation, foreign dependency, C/C++ runtime, other-language standard library,
public callable ABI, or `topal-native/6` revision. Dynamic selection, aggregate
containment, escape, publication, and library metadata/adapters remain deferred.
This realizes `TOPAL-COMPILER-SYMBOLIC-CALLABLE-EXPANDED-001`,
`TOPAL-FUNCTION-CALLABLE-VALUE-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5t.

## TOPAL-COMP-FUNCTION-PARAMETER-001 — Specialized private Function inputs

The checked compiler model shall admit a scalar `Function` parameter for an
admitted named or symbolic Function argument. Caller analysis shall attach the
retained callable facts to that argument, and callee specialization shall bind
those facts to the source parameter. Applying the parameter shall select the
retained declaration vector or symbolic operation without restarting lookup.
Bound arguments shall preserve the same facts, and distinct callable arguments
may instantiate distinct private versions of one source function.

The LLVM parameter shall be the exact private i32 observation tag used by the
caller, while the specialized body shall contain the already-selected direct
call or operation. Since executable computation need not read the tag, full O0
debugging shall retain it in a target-aligned debug-only stack shadow associated
with the source parameter and Function DWARF type. Native and GDB tests shall
cover direct and bound symbolic inputs, retained named inputs, multiple
specializations, exact signature/calls, parameter value, and nested frame.

This shall add no tag dispatch, function pointer, indirect call, closure
allocation, Function runtime, foreign dependency, C/C++ runtime, other-language
standard library, public callable ABI, or `topal-native/6` revision. Function
results, aggregate Function boundaries, anonymous functions/captures, remaining
symbolic callables, and published callable interfaces remain rejected. This
realizes `TOPAL-COMPILER-FUNCTION-PARAMETER-001` and the admitted boundary
portion of `TOPAL-FUNCTION-CALLABLE-VALUE-001`, `TOPAL-FUNCTION-VALUE-001`, and
`TOPAL-TYPE-CALL-001` for compiler increment 3b2-b5l.

## TOPAL-COMP-ANONYMOUS-DIRECT-001 — Private direct anonymous functions

The checked compiler model shall retain an inferred anonymous function with
binding-only parameter patterns as a Function value carrying its source body,
arity, construction identity, and the lexical bindings it would capture. A
non-capturing value shall be applicable after binding or when supplied directly
to an admitted private `Function` parameter. The call site shall infer a unary
parameter from its direct operand or multiple parameters from one exact-arity
positional product, preserving left-to-right evaluation. Body analysis shall
bind those inferred classifiers before inferring its result and shall preserve
left-to-right, no-hidden-precedence symbolic application semantics.

Each application shall specialize one private anonymous `fastcc` function and
emit a direct call. A deterministic module-private Function observation tag
shall provide canonical `<anonymous fn/N>` display and Function DWARF identity
without controlling the call. Full O0 debugging shall expose each anonymous
source frame and inferred parameter names and values. Native tests shall cover
unary and product invocation, exact output, contextual Function-parameter use,
left-associative mixed symbolic application, invalid arity, display, source
frames, private direct IR, and freestanding artifact properties.

This requirement alone does not admit lexical data captures or anonymous
product parameter patterns; unsupported forms shall fail before LLVM lowering.
This increment shall add no function pointer, indirect call, closure allocation,
closure or Function runtime, foreign dependency, C/C++ runtime, other-language
standard library, public callable ABI, or `topal-native/6` revision. Escaping
closures, Function results and aggregate boundaries outside their dedicated
requirements, and published callable interfaces remain rejected. This realizes
`TOPAL-COMPILER-ANONYMOUS-DIRECT-001` and the admitted portion of
`TOPAL-FUNCTION-ANONYMOUS-001`, `TOPAL-SYN-GRAMMAR-001`, and
`TOPAL-TYPE-CALL-001` for compiler increment 3b2-b5m.

## TOPAL-COMP-NESTED-FUNCTION-001 — Private direct nested lexical functions

The checked compiler model shall admit an unpublished ordinary nested function
declared as a direct statement of an ordinary non-static function body. It
shall bind that function from its declaration point, retain its source
declaration, and apply it by direct name within the same invocation scope or by
an exact local alias governed by
`TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001`.
It shall snapshot every visible immutable lexical data value with an admitted
private representation, excluding names shadowed by explicit nested
parameters, and shall reject any attempted value escape. A call shall reuse
each already-evaluated captured value and shall not access storage in another
native frame.

Each application shall specialize a compiler-private nested `fastcc` function.
Its exact signature shall contain source parameters followed by deterministic
exact typed capture parameters, with the identical prototype at every emitted
definition and call. LLVM shall own physical x86-64 register, stack, and
aggregate placement. Full O0 debugging shall expose the nested source frame,
source parameters, and material captures as named arguments. Native tests shall
cover the existing interpreter regression, exact execution, capture forwarding,
value-escape rejection, private direct IR, freestanding artifacts, source
frames, argument values, the shared corpus, and separate resource baselines.
Exact local alias calls and exact defining-context/live-root parameters are
governed by `TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001`; those environment
parameters shall not be duplicated as lexical captures.

This shall add no caller-frame reference, environment allocation/runtime,
function pointer, indirect call, foreign dependency, C/C++ runtime,
other-language standard library, public closure ABI, or `topal-native/6`
revision. Declarations inside nested lexical/decision blocks and published,
static, measured, constrained, or effectful nested functions; nested overloads,
recursion, sibling calls, visible/active named-callable collisions, anonymous
captures, Scope/Function/Constraint/refined captures, context/root environments
beyond `TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001`, escaping closures, and
public/library closure metadata remain rejected. This realizes
`TOPAL-COMPILER-NESTED-FUNCTION-001` and `TOPAL-FUNCTION-NESTED-001` for compiler
increment 3b2-b5p.

## TOPAL-COMP-FUNCTION-RESULT-001 — Specialized private Function results

The checked compiler model shall admit an exact `Function` result from an
ordinary or static root function when the result has retained named-root or
symbolic callable facts already supported by the compiler. A specialized
`Function` parameter may pass those same facts through the result. Calls and
subsequent binding chains shall retain the callable facts independently of the
machine tag, and later application shall lower from those facts without
runtime dispatch or renewed name lookup.

Each specialization shall return the existing deterministic i32 Function
observation tag from its exact private `fastcc` signature. The caller shall use
a direct i32-returning call, and named or symbolic application shall remain a
direct private call or direct operation. Full O0 debugging shall expose the
Function parameter, returned Function locals, and source frames using
target-aligned debug-only stack shadows where otherwise-dead tags would lose a
stable GDB location. Native tests shall cover named and symbolic pass-through,
binding chains, exact output, rejection boundaries, private direct IR,
freestanding artifacts, DWARF validation, GDB values/frames, the shared corpus,
and separate resource baselines.

Capturing anonymous results are governed by
`TOPAL-COMP-FUNCTION-CAPTURE-RESULT-001`; exact aggregate containment is
governed by `TOPAL-COMP-FUNCTION-AGGREGATE-001` and
`TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001`. Nested, dynamically computed, and
published Function results outside those rules remain rejected. This shall add
no function pointer, indirect call, closure
allocation/runtime, foreign dependency, C/C++ runtime, other-language standard
library, public callable ABI, or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-FUNCTION-RESULT-001` and the admitted
result-boundary portions of `TOPAL-FUNCTION-CALLABLE-VALUE-001`,
`TOPAL-FUNCTION-VALUE-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5q.

## TOPAL-COMP-ANONYMOUS-CAPTURE-001 — Private anonymous captures and results

The checked compiler model shall admit a bound inferred anonymous function that
captures immutable lexical data with complete admitted private representations
when it is applied directly in the same defining invocation. It shall retain
the construction-time storage identities, append their already-evaluated values
in deterministic lexical-name order after the explicit operands, and bind the
anonymous body only to exact hidden capture parameters. A missing defining
storage identity, caller shadow, callable or namespace capture, or unsupported
representation shall fail before LLVM lowering.

An ordinary or static root function may return a non-capturing inferred
anonymous Function. Result callable facts shall retain its body, source arity,
construction identity, static context, and empty capture set separately from
the returned observation tag. A later binding and application shall specialize
that body and produce one direct private call. Capturing anonymous Functions at
private Function parameters are governed by
`TOPAL-COMP-FUNCTION-CAPTURE-PARAMETER-001`; admitted private capturing results
are governed by `TOPAL-COMP-FUNCTION-CAPTURE-RESULT-001`.

LLVM definitions and calls shall use matching private `fastcc` signatures with
source parameters followed by exact capture parameters, leaving physical
x86-64 placement to LLVM. A non-capturing result shall retain the existing i32
Function return. Full O0 DWARF/GDB shall expose the anonymous frame, explicit
parameters, source-named captures, and returned Function local. Native tests
shall cover exact output, checked capture/result models, unsupported escapes,
exact IR, direct calls, artifact independence, DWARF validation, debugger
values/frames, the shared corpus, and separate resource baselines.

This shall add no environment object, function pointer, indirect call, closure
or Function runtime, foreign dependency, C/C++ runtime, other-language standard
library, public callable ABI, or `topal-native/6` revision. Capturing results or
Function-boundary arguments outside
`TOPAL-COMP-FUNCTION-CAPTURE-RESULT-001` and
`TOPAL-COMP-FUNCTION-CAPTURE-PARAMETER-001`, capture-bearing aggregate
containment outside `TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001`, dynamic escape,
publication, and library metadata/adapters remain deferred.
This realizes `TOPAL-COMPILER-ANONYMOUS-CAPTURE-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, `TOPAL-FUNCTION-VALUE-001`, and
`TOPAL-TYPE-CALL-001` for compiler increment 3b2-b5r.

## TOPAL-COMP-FUNCTION-CAPTURE-PARAMETER-001 — Private captured Function parameters

The checked compiler model shall admit a capturing anonymous Function or a
non-escaping nested lexical Function at an ordinary private `Function`
parameter. The exact callable facts shall remain separate from the i32
observation tag. Every immutable capture shall already have an admitted private
function-boundary representation and shall contain neither Generator nor
Function. The caller shall forward the already-evaluated capture values after
the source parameters in deterministic retained order. A specialized callee
may forward the same facts and values through another ordinary Function
parameter without re-evaluation while the defining lifetime remains active.

The frontend shall remap each capture storage identity to an exact hidden
parameter at every boundary, reject missing or shadowed storage, and specialize
the retained anonymous or nested body at its eventual application. A nested
Function value may receive one deterministic module-private observation tag,
but lowering shall emit only direct calls. Hidden forwarding parameters shall
remain absent from source DWARF, while the Function parameter, actual anonymous
or nested frame, explicit operands, and material source-named captures remain
inspectable.

Tests shall cover multiple scalar captures, an admitted Tuple capture, a root
anonymous capture, function-local anonymous and nested construction, transitive
forwarding, exact output in every interpreter mode, reversible debugging,
checked capture remapping, direct private IR, captured-result composition,
freestanding artifact properties, full O0 GDB values/frames, the shared corpus,
and separate resource baselines. This shall add no environment object or
allocation, function pointer, indirect call, callback, closure or Function
runtime, foreign dependency, C/C++ runtime, other-language standard library,
public callable ABI, or `topal-native/6` revision. Capturing Function results
outside `TOPAL-COMP-FUNCTION-CAPTURE-RESULT-001`, capture-bearing aggregate
containment outside `TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001`, dynamic
selection or escape, recursive or overloaded nested callable values,
unsupported captured state, publication, and library metadata/adapters remain
deferred. Future library metadata shall describe
callable and capture identities, ordered classifiers, lifetime/effects,
representation identities, and target adapters rather than the private hidden-
parameter layout. This realizes
`TOPAL-COMPILER-FUNCTION-CAPTURE-PARAMETER-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, `TOPAL-FUNCTION-NESTED-001`,
`TOPAL-FUNCTION-VALUE-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5w.

## TOPAL-COMP-FUNCTION-CAPTURE-RESULT-001 — Private captured Function results

The checked compiler model shall admit a capturing anonymous Function as the
exact result of an ordinary or static private specialization when its body,
construction identity, and all immutable capture facts remain known. Every
capture shall have an already-admitted complete private function-boundary
representation and contain neither Generator nor Function. A specialized
Function parameter carrying those facts may be returned, and an admitted
captured result may be forwarded through another admitted private Function
result or parameter.

Each generated factory shall return one exact aggregate containing the i32
Function observation tag followed by the already-evaluated capture values in
retained order. Its caller shall issue one direct `fastcc` call, decompose the
aggregate into deterministic compiler-only SSA storage, and retain the callable
facts separately. Eventual application shall specialize the anonymous body and
pass those returned values after its explicit operands. It shall neither replay
capture initializers nor dispatch on the observation tag. LLVM shall own the
physical x86-64 aggregate return convention.

Source DWARF shall continue to describe the factory result and binding as
`Function`; private returned transport fields shall have no source variables.
The eventual anonymous frame shall expose explicit operands and material
captures under their source names. Tests shall cover scalar and Tuple captures,
root and function-local factories, Function-parameter pass-through, transitive
result forwarding, exact output in every interpreter mode, reversible
debugging, checked capture remapping, exact direct IR, unsupported-result
edges, freestanding artifacts, full O0 GDB values/frames, the shared corpus,
and separate resource baselines.

This shall add no heap or environment object, environment pointer, allocation,
function pointer, indirect call, callback, closure or Function runtime, foreign
dependency, C/C++ runtime, other-language standard library, public callable
ABI, or `topal-native/6` revision. Immediate exact result application is
governed by `TOPAL-COMP-FUNCTION-RESULT-CHAIN-001`. Exact nested Function escape
is governed by `TOPAL-COMP-NESTED-FUNCTION-ESCAPE-001`. Function-valued or
otherwise unsupported captures, dynamic selection,
capture-bearing aggregate containment outside
`TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001`, publication, and library
metadata/adapters remain deferred. Future library metadata shall describe
callable identity, ordered capture identities/classifiers, lifetime/effects,
representation identities, and target adapters rather than this private
aggregate transport.
This realizes `TOPAL-COMPILER-FUNCTION-CAPTURE-RESULT-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, `TOPAL-FUNCTION-VALUE-001`, and
`TOPAL-TYPE-CALL-001` for compiler increment 3b2-b5x.

## TOPAL-COMP-FUNCTION-RESULT-CHAIN-001 — Exact Function-result application chains

The checked compiler model shall fold left-associative application when an
admitted application returns an exact Function and a following operand applies
that result. It shall support flat prefix and explicitly parenthesized chains
for retained named, symbolic, non-capturing anonymous, and admitted capturing
anonymous results. Each intermediate shall be evaluated once in source order,
with callable facts retained separately from the observation tag in
compiler-only storage. Captured aggregate fields extracted from a result shall
remain available to the immediate anonymous specialization.

LLVM shall receive only the existing exact direct `fastcc` definitions and
calls. The observation tag shall not dispatch application, and neither the
factory nor capture initializers may be replayed. A non-Function intermediate
or incompatible retained operand shall be rejected before lowering. Source
DWARF shall expose the ordinary factory, returned named function, and anonymous
capture frames but no compiler-only chain binding.

Tests shall cover flat and parenthesized chains, scalar and Tuple captures,
closed anonymous results, named and symbolic pass-through, scalar and product
operands, exact output in every interpreter mode, reversible debugging,
checked-model structure, once-only direct IR, rejection after a non-Function
intermediate, freestanding artifacts, full O0 GDB values/frames, the shared
corpus, and separate resource baselines. This shall add no allocation,
environment object, function pointer, indirect call, callback, closure or
Function runtime, foreign dependency, C/C++ runtime, other-language standard
library, public callable ABI, or `topal-native/6` revision. Aggregate-contained
Function values outside `TOPAL-COMP-FUNCTION-AGGREGATE-001`, dynamically
selected Function values, nested escape outside
`TOPAL-COMP-NESTED-FUNCTION-ESCAPE-001`, publication, and library
metadata/adapters remain deferred. This realizes
`TOPAL-COMPILER-FUNCTION-RESULT-CHAIN-001`,
`TOPAL-FUNCTION-CALLABLE-VALUE-001`, `TOPAL-FUNCTION-VALUE-001`, and
`TOPAL-TYPE-CALL-001` for compiler increment 3b2-b5y.

## TOPAL-COMP-FUNCTION-AGGREGATE-001 — Exact private Function aggregates

The checked compiler model shall retain recursive structural facts for Tuple
and Record values containing Function fields. Each Function leaf shall retain
one exact named, symbolic, or anonymous callable identity separately from its
private observation tag. Binding, direct Record selection, and anonymous
product destructuring shall recover those facts without replaying aggregate or
field construction. Local selection may apply a capturing anonymous Function
while all captures remain in their defining lifetime.

The capture-free base case permits an ordinary private function parameter or
result to carry a recursively nested Tuple or Record when every Function leaf
is exact at the call site. Specialization shall propagate those recursive facts
into the callee or back to the caller. Capture-bearing aggregate boundaries are
governed by `TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001`. Missing, opaque, or
branch-selected facts and Function containment outside Tuple, Record, the exact
Optional path of `TOPAL-COMP-OPTIONAL-FUNCTION-001`, or the exact nominal Sum
path of `TOPAL-COMP-SUM-FUNCTION-001`, or the exact Result-success path of
`TOPAL-COMP-RESULT-FUNCTION-001`, or the exact finite List-entry paths of
`TOPAL-COMP-LIST-FUNCTION-001`, or the exact fixed-size Array-entry paths of
`TOPAL-COMP-ARRAY-FUNCTION-001`, or the exact String-keyed Map-value paths of
`TOPAL-COMP-MAP-FUNCTION-001` shall fail before LLVM lowering.

The backend shall represent each Function leaf with its existing private i32
observation tag inside the recursively exact aggregate. Definitions and calls
shall use matching direct `fastcc` prototypes, while LLVM owns physical x86-64
aggregate argument and result coercion. Application shall use retained checked
facts to emit the selected direct operation or function call; tags shall never
dispatch. DWARF/GDB shall expose recursively accurate Tuple/Record source
values and their Function identities.

Tests shall cover local captured containment; named, symbolic, and
non-capturing anonymous values; recursive Tuple/Record bindings, parameters,
results, selections, and destructuring; checked structure; exact direct IR;
every interpreter mode and reversible history; the shared corpus and separate
resource baselines; freestanding ELF and DWARF validation; and full O0 GDB
values/frames.

This shall add no closure object, environment pointer, allocation, function
pointer, indirect call, callback, dispatch table, foreign dependency, C/C++
runtime, other-language standard library, public aggregate/callable ABI, or
`topal-native/6` revision. Dynamic aggregate boundaries, capture-bearing
boundaries outside `TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001`, other aggregate
constructors, escape, publication, and library adapters remain deferred. Future
compiled-library metadata shall encode every Function field's canonical
aggregate path, callable identity, ordered captures and classifiers,
construction lifetime, effects, representation identity, and target adapter
independently of private LLVM types and observation tags. This realizes
`TOPAL-COMPILER-FUNCTION-AGGREGATE-001`,
`TOPAL-ABSTRACTION-FUNCTION-BOUNDARY-001`, `TOPAL-FUNCTION-VALUE-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, `TOPAL-FUNCTION-CALLABLE-VALUE-001`,
`TOPAL-TYPE-PRODUCT-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5aa.

## TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001 — Captured private Function aggregates

The checked compiler model shall admit exact recursively nested Tuple and
Record parameters whose Function leaves are capturing anonymous Functions or
nested Functions, and results whose Function leaves are capturing anonymous
Functions or exact nested Functions under
`TOPAL-COMP-NESTED-FUNCTION-ESCAPE-001`. Every leaf shall retain its exact
callable identity, ordered capture facts, and canonical zero-based-Tuple-index,
Record-label, Optional-payload, nominal-Sum-alternative, Result-success,
zero-based List/Array-entry, or semantic exact String-keyed Map-value path.
Paths and their captures shall be traversed depth-first from left to right; Map
paths shall use first-key occurrence order after collision resolution. Optional,
Sum, Result, List, Array, and Map edges shall satisfy their respective
exact-container requirements.

For each specialized parameter, the frontend shall append every path-ordered
capture after the source-visible aggregate argument and bind those operands to
the selected callable's capture storage. For each result, it shall retain the
source aggregate and append the same path-ordered capture values to one
compiler-private result aggregate. Calls, bindings, transitive forwarding,
Record selection, and recursive anonymous product destructuring shall recover
the captures without replaying the aggregate, fields, or capture initializers.
Function-containing capture state, Generator state, opaque or dynamically
selected callable facts, and values outside the represented private lifetime
shall fail before LLVM lowering.

The backend shall emit matching direct private `fastcc` definitions and calls,
leaving x86-64 physical argument/result placement to LLVM and the qualified
target data layout. Source aggregates shall retain recursively accurate DWARF
types and Function members. Hidden transport shall not appear as source
aggregate fields or compiler-named variables; invoked anonymous and nested
frames shall expose captures under source names.

Tests shall cover multiple captured Record leaves, a captured Tuple leaf,
parameter-to-result forwarding, recursive destructuring, a nested Function
parameter, exact nested escape under `TOPAL-COMP-NESTED-FUNCTION-ESCAPE-001`,
rejected Function-containing capture state, checked path ordering, exact direct
IR, all interpreter modes and reversible history, the shared corpus and separate
resource baselines, freestanding ELF/DWARF validation, and full O0 GDB aggregate
values and capture frames.

This shall add no closure object, environment pointer, allocation, function
pointer, indirect call, callback, dispatch table, foreign dependency, C/C++
runtime, other-language standard library, public aggregate/callable ABI, or
`topal-native/6` revision. Dynamic Function selection, other aggregate
constructors, escaping nested Functions outside
`TOPAL-COMP-NESTED-FUNCTION-ESCAPE-001`, persistent storage, publication, and
public library adapters remain deferred. Future compiled-library metadata shall
encode the canonical aggregate path; callable and capture identities; capture
classifiers and order; construction lifetime; effects; representation identity;
and target adapter independently of private LLVM aggregates, observation tags,
and the current hidden-operand layout. This realizes
`TOPAL-COMPILER-FUNCTION-AGGREGATE-CAPTURE-001`,
`TOPAL-COMPILER-FUNCTION-AGGREGATE-001`,
`TOPAL-ABSTRACTION-FUNCTION-BOUNDARY-001`, `TOPAL-FUNCTION-VALUE-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, `TOPAL-FUNCTION-NESTED-001`,
`TOPAL-TYPE-PRODUCT-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5ab.

## TOPAL-COMP-NESTED-FUNCTION-ESCAPE-001 — Exact private nested Function escape

The checked compiler model shall admit an exact nonrecursive, nonoverloaded
nested ordinary Function as a scalar Function result, a Function leaf of a
recursively nested Tuple or labeled Record result, or an exact present Optional
payload under `TOPAL-COMP-OPTIONAL-FUNCTION-001`, an exact selected Sum payload
under `TOPAL-COMP-SUM-FUNCTION-001`, or an exact arithmetic Result success under
`TOPAL-COMP-RESULT-FUNCTION-001`, or exact finite List entries under
`TOPAL-COMP-LIST-FUNCTION-001`, or exact fixed-size Array entries under
`TOPAL-COMP-ARRAY-FUNCTION-001`, or exact String-keyed Map values under
`TOPAL-COMP-MAP-FUNCTION-001` within one compilation unit.
It shall retain the nested declaration identity separately from its observation
tag and retain each already-evaluated immutable lexical, defining-context, and
live-root capture with its exact classifier, storage identity, and source name.
Function- or Generator-containing capture state, missing lifetime storage,
opaque facts, and dynamic selection shall remain `E-COMPILER-UNSUPPORTED`.
Separate factory invocations shall retain independent capture snapshots.

Scalar results shall reuse the exact tag-plus-capture return representation of
`TOPAL-COMP-FUNCTION-CAPTURE-RESULT-001`. Tuple, Record, Optional, Sum, and
Result results shall reuse
the canonical Function-leaf path ordering and extended result aggregate of
`TOPAL-COMP-FUNCTION-AGGREGATE-CAPTURE-001`. The caller shall extract every
field once into compiler-only SSA storage. Binding, private Function
parameter/result forwarding, aggregate forwarding/selection/destructuring, and
immediate result application shall remap those values without replaying the
factory, aggregate, or capture initializers.

The backend shall emit matching direct private `fastcc` prototypes and calls,
with the explicit source operands followed by the returned captures. It shall
never dispatch on the Function tag or consult the ended factory frame. LLVM
shall own AMD64 aggregate classification and physical placement from the
qualified target data layout, and correctness shall require no optimization.
Source DWARF shall expose the factory result and bindings as `Function`, retain
ordinary Tuple/Record layouts, omit hidden transport fields, and expose nested
parameters and captures under source names in active and suspended frames.

Tests shall cover distinct factory invocations; scalar, Tuple, context, and
root captures; scalar and Record results; transitive forwarding; immediate
application; exact interpreter output and reversible history; checked capture
paths; direct IR; unsupported Function-valued capture rejection without
artifacts; freestanding ELF/DWARF; full O0 GDB values/frames; the shared corpus;
and separate interpreter/compiler resource baselines.

This shall add no heap, closure/environment object, environment pointer,
allocation, function pointer, indirect call, callback, runtime dispatcher,
global context/root state, caller-frame lookup, foreign dependency, C/C++
runtime, other-language standard library, public ABI, or `topal-native/6`
revision. Recursive, overloaded, sibling-dependent, opaque, dynamically
selected, persistently stored, or published nested Functions remain deferred.
Future library metadata shall retain canonical source-session, lexical-scope,
nested-declaration, callable, aggregate-path, capture
identity/order/classifier/representation/lifetime, effect, and versioned
target-adapter facts independently of observation tags, compiler-private names,
LLVM types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-NESTED-FUNCTION-ESCAPE-001` for increments 3b2-b5ar, 6b2b2i,
and 6c2g.

## TOPAL-COMP-OPTIONAL-FUNCTION-001 — Exact private Optional Function environments

The checked compiler model shall admit an exact `Optional Function` as a local
value, ordinary private parameter or result, package field, or recursively
contained Tuple/Record field. It shall represent exact absence explicitly and,
for `Some`, retain one exact named, symbolic, anonymous, or admitted nested
callable identity independently of both runtime tags. Opaque or branch-selected
present identity shall remain `E-COMPILER-UNSUPPORTED` before artifact
publication.

The backend shall use the existing Topal Optional header and allocator. A
present payload shall box the existing private i32 Function observation value;
an absent value shall have no payload. An exhaustive decision shall attach the
retained present callable facts to its `Some` binding and lower eventual
application as one direct specialized `fastcc` call. Display, DWARF, and the GDB
printer shall retain the source `Optional Function` classifier and exact
Function observation without exposing compiler facts or hidden captures.

For a present capturing callable, the checked model shall add an Optional
payload edge to its canonical Function path. Private parameters shall pass the
source Optional pointer followed by ordered captures. Private results shall
return that pointer followed by the same captures; the caller shall extract and
remap them exactly once. This path shall compose with exact nested Function
escape and recursively enclosing Tuple/Record values. Function- or
Generator-containing capture state shall remain unsupported.

Repeated anonymous-pattern identity shall compare Optional presence and the
boxed Function observation before any captures. If both present payloads retain
the same callable identity, the compiler shall append and compare corresponding
captures with admitted exact equality. A different callable or presence shall
mismatch without requiring an unselected capture schema. No user Equality or
allocation identity shall participate.

Tests shall cover named, symbolic, anonymous, and nested present payloads;
absence; independent captured factories; direct `Some` application; private
parameter/result, package, Tuple, and Record passage; repeated match/mismatch;
display; all interpreter modes and reversible history; checked Optional paths;
direct IR; artifact-free opaque/capture rejection; freestanding ELF/DWARF;
full O0 GDB Optional/callable frames; the shared corpus; and separate
interpreter/compiler resource baselines.

This shall add no closure/environment object, environment pointer, function
pointer, indirect call, callback, dispatch table, caller-frame lookup, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Allocation shall remain the existing Topal-owned
process-lifetime Optional representation. Opaque or dynamically selected
Optional callables, persistent storage, publication, and Function containment
in containers other than exact nominal Sums governed by
`TOPAL-COMP-SUM-FUNCTION-001` remain deferred. Future library metadata shall retain
canonical source-session/scope, callable/declaration, Optional payload and
enclosing aggregate paths, presence/selection proof, ordered capture
identity/classifier/representation/lifetime, effect, container representation,
and versioned target-adapter facts independently of private observation tags,
header layout, compiler names, LLVM types/symbols, debug shadows, and physical
placement. This realizes `TOPAL-COMPILER-OPTIONAL-FUNCTION-001` for increments
3b2-b5as, 6b2b2j, and 6c2h.

## TOPAL-COMP-SUM-FUNCTION-001 — Exact private nominal Sum Function environments

The checked compiler model shall admit an exact labeled Union or positional
Variant with a Function-bearing payload as a local value, ordinary private
parameter or result, package field, or recursively contained Tuple/Record
field. It shall retain the exact selected alternative and complete active
payload facts independently of the runtime tag. Every active Function leaf
shall retain one exact named, symbolic, anonymous, or admitted nested callable
identity. Opaque or branch-selected alternatives or callables shall remain
`E-COMPILER-UNSUPPORTED` before artifact publication.

The backend shall preserve the existing exact private tag-plus-payload Sum
aggregate. A complete decision shall attach retained active payload facts to
its binding and lower eventual Function application as one direct specialized
`fastcc` call. It shall add the semantic alternative name to each active
Function leaf's canonical capture path. Private parameters shall pass the
source aggregate followed by ordered captures; private results shall return the
aggregate followed by those captures for one-time caller extraction and
remapping. The path shall compose with enclosing Tuple/Record values and exact
nested Function escape.

Repeated anonymous-pattern identity shall compare nominal tags and only the
active payload, including the Function observation before captures. When both
operands retain the same selected alternative and callable identity, the
compiler shall compare corresponding captures using admitted exact equality.
A different tag or callable shall mismatch without observing inactive slots or
granting general source Equality to the Function-bearing Sum.

Tests shall cover labeled and positional Sums; named, symbolic, anonymous, and
nested Function payloads; payload-free and non-Function alternatives; distinct
factory snapshots; decision application; private parameter/result, package,
Tuple, and Record passage; repeated match/mismatch; display; all interpreter
modes and reversible history; exact checked paths and direct IR; artifact-free
opaque/capture rejection; freestanding ELF/DWARF; full O0 GDB Sum/callable
frames; the shared corpus; and separate interpreter/compiler resource
baselines.

This shall add no closure/environment object, environment pointer, function
pointer, indirect call, callback, dispatch table, caller-frame lookup,
allocation, foreign dependency, C/C++ runtime, other-language standard library,
public ABI, or `topal-native/6` revision. Function- or Generator-containing
capture state, recursive Sums, opaque or dynamically selected Sum callables,
persistent storage, publication, and Function containment in other containers
remain deferred. Future library metadata shall retain canonical
source-session/scope and nominal Sum identity, labeled/positional form, ordered
alternative/payload schema, active-alternative proof, callable/declaration and
aggregate paths, ordered capture identity/classifier/representation/lifetime,
effects, Sum representation, and versioned target-adapter facts independently
of private tags, inactive layout, compiler names, LLVM types/symbols, debug
shadows, and physical placement. This realizes
`TOPAL-COMPILER-SUM-FUNCTION-001` for increments 3b2-b5at, 6b2b2k, and 6c2i.

## TOPAL-COMP-RESULT-FUNCTION-001 — Exact private Result Function environments

The checked compiler model shall admit an exact
`Result (Function, lang arithmetic ArithmeticErrorCode)` as a local value,
ordinary private parameter or result, package field, or recursively contained
Tuple/Record field. It shall retain one exact named, symbolic, anonymous, or
admitted nested callable identity and complete capture facts conditionally for
the success payload while allowing the runtime success/Error tag to remain
dynamic. Opaque or branch-selected success callables shall remain
`E-COMPILER-UNSUPPORTED` before artifact publication.

The backend shall preserve the existing Topal-owned Result pointer. Success
shall box the private i32 Function observation value; failure and contextual
projection shall preserve the complete original Error. A complete decision
shall attach retained callable facts only to its `Ok` binding and lower
eventual application as one direct specialized `fastcc` call. It shall add a
Result-success edge to the callable capture path. Private parameters shall pass
the source pointer followed by ordered captures; private results shall return
the pointer followed by those captures for one-time caller extraction and
remapping.

Every Error exit from a capture-bearing Result Function shall return the same
private aggregate shape with representation-valid zero carriers in hidden
capture fields. It shall not evaluate skipped callable or capture initializers,
and neither caller nor callee shall expose or consume those carriers on the
Error path. Source Result values, structured Error provenance, successful
Function observations, and eventual source-named captures shall remain fully
visible to DWARF/GDB without exposing hidden fields.

Tests shall cover named, symbolic, anonymous, and nested success payloads; a
dynamically propagated original Error; distinct factory snapshots; `Ok`
application and `Error` handling; private parameter/result, package, Tuple, and
Record passage; display; all interpreter modes and reversible history; checked
Result-success paths and direct IR including aggregate Error exits;
artifact-free opaque/capture rejection; freestanding ELF/DWARF; full O0 GDB
Result/callable frames; the shared corpus; and separate interpreter/compiler
resource baselines.

This shall add no closure/environment object, environment pointer, function
pointer, indirect call, callback, dispatch table, caller-frame lookup, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Allocation shall remain limited to the existing
process-lifetime Result object and successful i32 payload box. Function- or
Generator-containing capture state, opaque or dynamically selected success
callables, general Result Function equality/repeated identity, recursive Result
Function payloads, persistent storage, publication, and Function containment
in other containers remain deferred. Future library metadata shall retain the
canonical source-session/scope, Result success classifier and Error-code
vocabulary, conditional-success proof, Error propagation semantics,
callable/declaration and aggregate paths, ordered capture
identity/classifier/representation/lifetime, effects, Result representation,
and versioned target-adapter facts independently of private headers,
observation tags, failure-path zero carriers, compiler names, LLVM
types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-RESULT-FUNCTION-001` for increments 3b2-b5au, 6b2b2l, and
6c2j.

## TOPAL-COMP-LIST-FUNCTION-001 — Exact private finite List Function environments

The checked compiler model shall admit an exact finite `List Function`
constructed from `Entry` and `Empty` as a local value, ordinary private
parameter or result, package field, or recursively contained Tuple/Record
field. It shall retain exact length and one source-ordered named, symbolic,
anonymous, or admitted nested callable identity per entry. Opaque,
branch-selected, transformed, or otherwise inexact entry sequences or
identities shall remain `E-COMPILER-UNSUPPORTED` before artifact publication.

The backend shall preserve Topal-owned singly linked List nodes. A Function
node shall store the private i32 observation followed by the aligned next
pointer; `Empty` shall remain null, and capture snapshots shall not be embedded
in source nodes. A complete List decision shall attach the first entry facts to
the first binding and the remaining ordered facts to the rest binding, then
lower eventual application as one direct specialized `fastcc` call. Display,
DWARF, and the GDB printer shall retain exact source List and Function
observations without exposing compiler facts.

Every Function entry shall add its zero-based source index to its canonical
capture path. Private parameters shall pass the source List pointer followed by
entry- and capture-ordered values. Private results shall return the pointer
followed by those values for one-time caller extraction and remapping. This path
shall compose with enclosing Tuple/Record values and exact nested Function
escape. Distinct entries and factory calls shall retain independent snapshots.
Function- or Generator-containing capture state shall remain unsupported.

Tests shall cover empty, named, symbolic, anonymous, and nested entries;
multiple positions and independent factory snapshots; complete decision
application; private parameter/result, package, Tuple, and Record passage;
display; all interpreter modes and reversible history; checked List-entry paths
and direct IR; artifact-free opaque/capture/repeated-identity rejection;
freestanding ELF/DWARF; full O0 GDB List/callable frames; the shared corpus;
and separate interpreter/compiler resource baselines.

This shall add no closure/environment object, environment pointer, function
pointer, indirect call, callback, dispatch table, caller-frame lookup, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Allocation shall remain the existing Topal-owned
process-lifetime List nodes. General List Function equality/repeated identity,
operations that lose exact entry facts, opaque or dynamically selected entries,
persistent storage, publication, recursive element classifiers, and Function
containment in other collection representations remain deferred. Future
library metadata shall retain canonical source-session/scope, exact length and
entry order, callable/declaration and aggregate paths, ordered capture
identity/classifier/representation/lifetime, effects, List representation and
ownership, and versioned target-adapter facts independently of node offsets,
private observation tags, compiler names, LLVM types/symbols, debug shadows,
and physical placement. This realizes `TOPAL-COMPILER-LIST-FUNCTION-001` for
increments 3b2-b5av, 6b2b2m, and 6c2k.

## TOPAL-COMP-ARRAY-FUNCTION-001 — Exact private fixed-size Array Function environments

The checked compiler model shall admit an exact finite `List Function`
collected as `Array N Function`, where `N` is the exact retained count, as a
local value, ordinary private parameter or result, package field, or recursively
contained Tuple/Record field. It shall retain the exact extent and one
source-ordered named, symbolic, anonymous, or admitted nested callable identity
per entry. Opaque, branch-selected, transformed, or otherwise inexact entry
sequences or identities shall remain `E-COMPILER-UNSUPPORTED` before artifact
publication.

The backend shall preserve the existing Topal-owned 16-byte Array header: an
i64 entry count followed by a pointer to the immutable source List nodes.
Collection shall not copy or enlarge those nodes, and capture snapshots shall
not be embedded in the header or entries. Exact checked access shall produce
the ordinary `Optional Function`: an in-bounds index shall attach the indexed
callable facts to `Some`, while an out-of-bounds index shall produce `None`.
Eventual application shall lower as one direct specialized `fastcc` call.
Display, DWARF, and the GDB printer shall retain exact source Array and Function
observations without exposing compiler facts.

Every Function entry shall add its zero-based Array index to its canonical
capture path. Private parameters shall pass the source Array pointer followed
by entry- and capture-ordered values. Private results shall return the pointer
followed by those values for one-time caller extraction and remapping. This path
shall compose with enclosing Tuple/Record values and exact nested Function
escape. Distinct entries and factory calls shall retain independent snapshots.
Function- or Generator-containing capture state shall remain unsupported.

Tests shall cover zero and nonzero extents; named, symbolic, anonymous, and
nested entries; multiple positions and independent factory snapshots;
in-bounds and out-of-bounds access with complete Optional decisions; count,
emptiness, private parameter/result, package, Tuple, and Record passage;
display; all interpreter modes and reversible history; checked Array-entry
paths and direct IR; artifact-free opaque/capture/repeated-identity rejection;
freestanding ELF/DWARF; full O0 GDB Array/callable frames; the shared corpus;
and separate interpreter/compiler resource baselines.

This shall add no closure/environment object, environment pointer, function
pointer, indirect call, callback, dispatch table, caller-frame lookup, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Allocation shall remain the existing process-lifetime
List nodes, one Array header, and the ordinary in-bounds Optional Function box.
General Array Function equality/repeated identity, dynamic indexing, operations
that lose exact entry facts, opaque or dynamically selected entries, persistent
storage, publication, recursive element classifiers, and Function containment
in other collection representations remain deferred. Future library metadata
shall retain canonical source-session/scope, exact extent and entry order,
source collection relationship, callable/declaration and aggregate paths,
ordered capture identity/classifier/representation/lifetime, effects,
Array/List representation and ownership, and versioned target-adapter facts
independently of headers, node offsets, private observation tags, compiler
names, LLVM types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-ARRAY-FUNCTION-001` for increments 3b2-b5aw, 6b2b2n, and 6c2l.

## TOPAL-COMP-MAP-FUNCTION-001 — Exact private String-keyed Map Function environments

The checked compiler model shall admit an exact nonempty
`List (String, Function)` collected as `Map (String, Function)` under
`reject`, `keep-first`, or `keep-last` as a local value, ordinary private
parameter or result, package field, or recursively contained Tuple/Record
field. It shall require every source key to be exact, resolve the collision
policy, and retain one named, symbolic, anonymous, or admitted nested callable
identity per surviving key in first-key occurrence order. Empty, opaque,
computed-key, branch-selected, transformed, or otherwise inexact Maps or
callables shall remain `E-COMPILER-UNSUPPORTED` before artifact publication.

The backend shall preserve the existing Topal-owned 16-byte Map header and
24-byte linked nodes. Each node shall retain the String pointer, ordinary i32
Function observation in its value slot, and next pointer. Capture snapshots
shall not be embedded in the header or nodes. `reject` shall diagnose duplicate
exact keys; `keep-first` shall retain the first callable/captures; `keep-last`
shall retain the last callable/captures at the first key's node position. Exact
lookup shall produce the ordinary `Optional Function`: a present key shall
attach only its retained callable facts to `Some`, while a missing key shall
produce `None`. Eventual application shall lower as one direct specialized
`fastcc` call. Display, DWARF, and the GDB printer shall retain source Map,
String-key, and Function observations without exposing compiler facts.

Every surviving Function value shall add its exact String key as a semantic
Map-value edge to its canonical capture path. Private parameters shall pass the
source Map pointer followed by resolved entry- and capture-ordered values.
Private results shall return the pointer followed by those values for one-time
caller extraction and remapping. This path shall compose with enclosing
Tuple/Record values and exact nested Function escape. Distinct keys and factory
calls shall retain independent snapshots. Function- or Generator-containing
capture state shall remain unsupported.

Tests shall cover nonempty named, symbolic, anonymous, and nested values; all
collision policies; present and missing exact-key lookup with complete Optional
decisions; count, emptiness, private parameter/result, package, Tuple, and
Record passage; independent factory snapshots; display; all interpreter modes
and reversible history; checked semantic Map-value paths and direct IR;
artifact-free empty/opaque-key/opaque-map/capture/repeated-identity rejection;
freestanding ELF/DWARF; full O0 GDB Map/callable frames; the shared corpus; and
separate interpreter/compiler resource baselines.

This shall add no closure/environment object, environment pointer, function
pointer, indirect call, callback, dispatch table, caller-frame lookup, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Allocation shall remain the existing process-lifetime
source List nodes, Map nodes and header, and ordinary present Optional Function
box. Empty Map Function collection remains deferred until shared typed-empty
Map semantics are implemented. General Map Function equality/repeated identity,
dynamic lookup, operations that lose exact key/value facts, Function keys,
other key classifiers, opaque or dynamically selected values, persistent
storage, publication, recursive contained classifiers, and Function containment
in other unordered collections remain deferred. Future library metadata shall
retain canonical source-session/scope, collision policy, exact key set and
resolved order, source collection relationship, callable/declaration and
semantic key-based aggregate paths, ordered capture
identity/classifier/representation/lifetime, effects, Map/List representation
and ownership, and versioned target-adapter facts independently of headers,
node offsets, private observation tags, compiler names, LLVM types/symbols,
debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-MAP-FUNCTION-001` for increments 3b2-b5ax, 6b2b2o, and 6c2m.

## TOPAL-COMP-ANONYMOUS-PRODUCT-001 — Private anonymous product patterns

The checked compiler model shall admit a flat positional product parameter
pattern in any position of a directly applied inferred anonymous Function. It
shall require one exact Tuple operand of matching arity for each product
pattern, bind fields in lexical source order, preserve the source parameter
arity, and compose with same-invocation immutable captures and non-capturing
anonymous Function parameters/results already admitted by the compiler.

The frontend shall evaluate the complete application operand exactly once.
Opaque Tuple locals and function results and the outer positional product of a
multi-parameter call shall use a compiler-private lexical value before field
projection. Direct Tuple constructions may retain sound field facts for body
checking, but no initializer or field expression may be replayed. A non-Tuple,
field-count mismatch, repeated binding outside
`TOPAL-COMP-ANONYMOUS-REPEATED-PATTERN-001`, or unsupported field representation
shall fail before anonymous-body or LLVM lowering.

LLVM definitions and calls shall use matching private `fastcc` signatures with
ordinary binding parameters and flattened product fields in lexical order,
followed by exact capture parameters. LLVM shall own physical x86-64 placement.
Full O0 DWARF/GDB shall expose non-discarded product fields as source-named
parameters, material captures, the anonymous frame, and callers. Tests shall
cover direct call-result materialization, bound captures, non-capturing
Function results, mixed product/scalar patterns, exact output, rejection
boundaries, once-only IR, artifact independence, DWARF validation, GDB
values/frames, all interpreter modes, reversible debugging, the shared corpus,
and separate resource baselines.

Recursive product patterns are governed by
`TOPAL-COMP-ANONYMOUS-NESTED-PATTERN-001`. This shall add no product-pattern
object, environment object, function pointer,
indirect call, closure or Function runtime, foreign dependency, C/C++ runtime,
other-language standard library, public aggregate or callable ABI, or
`topal-native/6` revision. Aggregate repeated-name patterns,
capturing Function boundaries outside
`TOPAL-COMP-FUNCTION-CAPTURE-PARAMETER-001` and
`TOPAL-COMP-FUNCTION-CAPTURE-RESULT-001`, other escape, aggregate containment
outside `TOPAL-COMP-FUNCTION-AGGREGATE-001`, publication, and library
metadata/adapters remain deferred. This realizes
`TOPAL-COMPILER-ANONYMOUS-PRODUCT-001`, `TOPAL-FUNCTION-ANONYMOUS-001`,
`TOPAL-TYPE-PRODUCT-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5s.

## TOPAL-COMP-ANONYMOUS-NESTED-PATTERN-001 — Recursive anonymous product patterns

The syntax, interpreter, and checked compiler model shall admit a finite
positional product pattern recursively in any field of an inferred anonymous
Function parameter. Every product node shall require one exact Tuple with the
same arity and recursively visit binding/discard leaves depth-first from left
to right. A non-Tuple or mismatched field count at any depth shall fail before
body entry and before LLVM lowering.

The frontend shall evaluate the complete application operand once, retain one
compiler-private outer value when projection is required, and derive nested
fields only through recursive Tuple projections. It shall preserve top-level
source Function arity separately from the flattened leaf parameter list.
Existing repeated-name exact-identity guards and discard semantics shall apply
across all leaves. The pattern shall compose with immutable captures, mixed
top-level parameters, and capturing anonymous Function results already admitted
by their exact private boundaries.

LLVM definitions and calls shall use matching direct private `fastcc`
signatures containing admitted leaves in lexical order followed by captures,
with all physical x86-64 placement owned by LLVM. DWARF/GDB shall expose each
non-discarded leaf under its source name and omit compiler-only projection
storage. Tests shall cover opaque nested Tuple results, both nesting directions,
mixed parameters, captures, a capturing Function result, repeated names and
discard, non-Tuple and nested-arity rejection, checked structure, once-only
direct IR, exact interpreter modes and reversible history, freestanding
artifacts, full O0 GDB values/frames, the shared corpus, and separate resource
baselines.

This shall add no pattern object, allocation, environment object, function
pointer, indirect call, callback, closure or Function runtime, foreign
dependency, C/C++ runtime, other-language standard library, public aggregate
or callable ABI, or `topal-native/6` revision. Named-function header patterns,
aggregate containment outside `TOPAL-COMP-FUNCTION-AGGREGATE-001`, dynamic
escape/selection, publication, and library metadata/adapters remain deferred.
This realizes
`TOPAL-COMPILER-ANONYMOUS-NESTED-PATTERN-001`,
`TOPAL-COMPILER-ANONYMOUS-PRODUCT-001`, `TOPAL-FUNCTION-ANONYMOUS-001`,
`TOPAL-TYPE-PRODUCT-001`, `TOPAL-TYPE-MATCH-001`, and `TOPAL-TYPE-CALL-001` for
compiler increment 3b2-b5z.

## TOPAL-COMP-ANONYMOUS-REPEATED-PATTERN-001 — Exact repeated anonymous pattern names

The checked compiler model shall admit a repeated non-discard name across
ordinary scalar parameters and positional-product leaves of an inferred
anonymous Function, including recursive leaves under
`TOPAL-COMP-ANONYMOUS-NESTED-PATTERN-001`. The first occurrence shall be the
only body binding and debug parameter. Every later occurrence shall retain its
consumed private ABI
operand and record a lexical exact-identity guard against that first parameter.
Repeated `_` occurrences shall remain independent discards.

Both operands shall have one exact admitted scalar classifier: `Unit`,
`Completed`, `Effect`, `Type`, `Function`, `Boolean`, `Int`, `Nat`, one modular
type, `Rational`, `Comparison`, `ErrorCode`, one Enum type, `Character`, or
`String`. Identity shall use the existing same-representation direct comparison
without evidence forgetting, conversion, user Equality selection, canonical
equivalence, or approximation. A classifier mismatch shall fail in the checked
model. An opaque product-producing call and every field expression shall still
execute exactly once before any guard.

LLVM shall compare the private parameters in lexical guard order before the
body. Failure shall call a Topal-owned diagnostic helper which writes
`E-ANONYMOUS-PATTERN-IDENTITY` through the Linux syscall writer and exits 65.
Success shall continue directly into the anonymous body. Full O0 DWARF/GDB
shall show one source parameter for the first occurrence and the direct guarded
frame. Tests shall cover product and cross-parameter repetition, opaque product
materialization, Int, String, and Function identities, interpreter parity and
mismatch diagnostics, checked classifier rejection, direct guarded IR,
freestanding execution, GDB values/frames, the shared corpus, and separate
resource baselines.

This shall add no pattern object, matching table, function pointer, indirect
call, closure or Function runtime, foreign dependency, C/C++ runtime,
other-language standard library, public aggregate or callable ABI, or
`topal-native/6` revision. Aggregate repeated identity is governed by
`TOPAL-COMP-ANONYMOUS-REPEATED-AGGREGATE-001`. Ordinary named-function header
repetition, publication, and library
metadata/adapters remain deferred. This realizes
`TOPAL-COMPILER-ANONYMOUS-REPEATED-PATTERN-001`, `TOPAL-TYPE-MATCH-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5u.

## TOPAL-COMP-ANONYMOUS-REPEATED-AGGREGATE-001 — Exact repeated aggregate values

The checked compiler model shall admit a repeated anonymous-pattern name with
the same exact Tuple, Record, Optional, or List classifier when that classifier
already has both an admitted private function-boundary representation and
complete exact compiler equality. The initial boundary shall include recursive
equality-capable Tuple and Record values over admitted non-Function leaves;
`Optional Int`, `Optional Rational`, `Optional String`, and `Optional (Int,
String)`; `List Int`; and `List List (Int, String)`.

The first occurrence shall remain the sole source binding and DWARF parameter.
Every later occurrence shall retain its complete exact private parameter and a
lexically ordered pre-body guard. Tuple fields and canonical Record fields shall
compare recursively; Optional tags and present payloads shall compare exactly;
and Lists shall compare entries in order and require equal length. Lowering
shall reuse existing direct field comparisons and Topal-owned Optional/List
primitives without conversion, evidence forgetting, user Equality selection,
canonical equivalence, approximation, allocation identity, or inactive
representation data. A failed guard shall use the existing Topal-owned syscall
diagnostic and exit 65.

Tests shall cover opaque Tuple construction, canonical Records, Optional and
List values, exact interpreter modes and mismatch diagnostics, checked-model
metadata, structural guarded IR, native success and failure, freestanding
artifact properties, full O0 aggregate GDB observation, reversible debugging,
the shared corpus, and separate resource baselines. This shall add no generic
aggregate matcher, pattern table, allocation, callback, indirect dispatch,
foreign dependency, C/C++ runtime, other-language standard library, public
aggregate ABI, or `topal-native/6` revision. Sum identity is governed by
`TOPAL-COMP-ANONYMOUS-REPEATED-SUM-001`. Result, Range, Generator, refined,
authority-bearing, and Function-containing aggregate identity outside
`TOPAL-COMP-ANONYMOUS-REPEATED-FUNCTION-AGGREGATE-001`; ordinary named-function
header repetition;
publication; and library metadata/adapters remain deferred. This realizes
`TOPAL-COMPILER-ANONYMOUS-REPEATED-AGGREGATE-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-PATTERN-001`, `TOPAL-TYPE-MATCH-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5v.

## TOPAL-COMP-ANONYMOUS-REPEATED-FUNCTION-AGGREGATE-001 — Exact capture-free Function aggregate values

The checked compiler model shall admit a repeated anonymous-pattern name with
the same exact recursively nested Tuple or Record classifier containing
Function leaves when every Function leaf retains one exact capture-free
callable identity and every other leaf has existing exact compiler equality.
It shall preserve complete recursive structural facts for the first and later
occurrences and reject missing or opaque callable facts before LLVM lowering.
Capture-bearing leaves shall be governed by
`TOPAL-COMP-ANONYMOUS-REPEATED-CAPTURED-FUNCTION-AGGREGATE-001`.

The first occurrence shall remain the sole body binding and DWARF parameter.
Every later occurrence shall retain its complete recursive private aggregate
operand and a lexically ordered pre-body guard. Direct recursive Tuple/Record
comparison shall compare each Function observation field as i32 without using
that field for dispatch. Definitions and calls shall use matching exact private
`fastcc` aggregate signatures, with physical AMD64 placement left to LLVM's
qualified target data layout. Failure shall reuse the Topal-owned syscall
diagnostic and exit 65.

Tests shall cover named, symbolic, and non-capturing anonymous Function leaves,
nested Tuple/Record values, exact interpreter modes, native success and mismatch
failure, checked structural facts, direct guarded IR, freestanding artifact
properties, full O0 aggregate GDB observation,
reversible debugging, the shared corpus, and separate resource baselines. This
shall add no closure or environment object, allocation, generic matcher,
pattern table, function pointer, indirect call, callback, dispatch table,
foreign dependency, C/C++ runtime, other-language standard library, public
aggregate/callable ABI, or `topal-native/6` revision. Dynamic aggregate
selection, Function containment outside admitted Tuple/Record/Optional/Sum/Result/List/Array/Map paths, ordinary named-function
header repetition, publication, and library adapters remain deferred.
Compiled-library metadata
shall eventually encode canonical aggregate paths and stable
callable/representation identities without serializing private LLVM types,
observation tags, or target-specific argument placement. This realizes
`TOPAL-COMPILER-ANONYMOUS-REPEATED-FUNCTION-AGGREGATE-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-AGGREGATE-001`,
`TOPAL-COMPILER-FUNCTION-AGGREGATE-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-PATTERN-001`, `TOPAL-TYPE-MATCH-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5ac.

## TOPAL-COMP-ANONYMOUS-REPEATED-CAPTURED-FUNCTION-001 — Exact captured anonymous Function values

The checked compiler model shall admit a repeated scalar Function pattern when
both operands retain the same anonymous source identity, the same ordered
represented capture schema, and exact compiler equality for every capture. It
shall canonicalize the anonymous source identity across private
specializations, retain both capture snapshots without re-evaluation, and
reject missing, inconsistent, or non-equality capture facts before LLVM.

The first Function occurrence shall remain the sole body binding and DWARF
parameter. The later occurrence shall retain its source observation field and
ordered captures as hidden parameters. Lowering shall compare the source field
first and the captures in order with existing exact direct comparisons, then
reuse the Topal-owned mismatch diagnostic and exit 65. The private definition
and call shall use matching exact `fastcc` prototypes, with physical AMD64
placement left to LLVM's qualified target data layout. Observation tags shall
remain non-dispatching and shall not become semantic library identities.

Tests shall cover same-source equal and unequal captures, canonical source
identity across specializations, non-equality capture rejection before artifact
publication, checked-model guard metadata, direct ordered IR, interpreter modes
and reversible history, the shared corpus, separate resource baselines,
freestanding ELF/DWARF properties, and full O0 GDB values/frames. This shall add
no closure or environment object, allocation, pattern table, function pointer,
indirect call, dispatch table, foreign dependency, C/C++ runtime,
other-language standard library, public callable ABI, or `topal-native/6`
revision. Captured named identity is governed by
`TOPAL-COMP-ANONYMOUS-REPEATED-CAPTURED-NAMED-FUNCTION-001`. Unsupported capture
classifiers, publication, and library adapters remain deferred. Future
compiled-library metadata shall encode stable callable
source identity plus the ordered capture schema/classifiers, equality
requirements, representation identity, lifetime/effects, and target adapter;
it shall not serialize private observation tags, hidden parameter names, LLVM
types, or target-specific placement. This realizes
`TOPAL-COMPILER-ANONYMOUS-REPEATED-CAPTURED-FUNCTION-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-PATTERN-001`, `TOPAL-TYPE-MATCH-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5ad.

## TOPAL-COMP-ANONYMOUS-REPEATED-CAPTURED-NAMED-FUNCTION-001 — Exact captured named Function values

The checked compiler model shall admit a repeated scalar Function pattern when
both operands retain the same stable captured named declaration identity, the
same ordered represented capture schema, and exact compiler equality for every
required capture. The initial boundary shall be a non-escaping nested lexical
Function used within its defining invocation. It shall identify that callable
by source name and declaration identity across private specializations. When
declaration identities differ, the observation-field guard shall make the
values unequal without requiring capture transport. Missing declaration facts,
inconsistent required schemas, and required non-equality capture state shall
fail before LLVM or artifact publication.

The first Function occurrence shall remain the sole source binding and DWARF
parameter. When identities match, both capture snapshots shall follow source
parameters as deterministic hidden operands. Lowering shall compare the source
identity first and captures in retained order, then reuse the Topal-owned
mismatch diagnostic and exit 65. Matching private definitions and calls shall
use exact `fastcc` prototypes while LLVM owns physical AMD64 placement.
Observation fields shall remain non-dispatching and source offsets shall not
become semantic library identities.

Tests shall cover a captured nested Function repeated and directly invoked,
different captured nested declaration identities without unnecessary capture
equality, same-declaration non-equality capture rejection before artifact
publication, checked-model guards, direct ordered IR, interpreter modes and
reversible history, the shared corpus, separate resource baselines,
freestanding ELF/DWARF properties, and full O0 GDB values/frames. This shall add
no closure or environment object, allocation, pattern table, function pointer,
indirect call, dispatch table, foreign dependency, C/C++ runtime,
other-language standard library, public callable ABI, or `topal-native/6`
revision. Escaping nested Functions, unsupported capture classifiers, ordinary
named-function header repetition, publication, and library adapters remain
deferred. Future compiled-library metadata shall encode stable
declaration/source identity, ordered capture schemas and classifiers, semantic
equality requirements, representation identity, lifetime/effects, and target
adapters; it shall not serialize source offsets, private observation tags,
hidden operand names or layout, LLVM types, or target-specific placement. This
realizes
`TOPAL-COMPILER-ANONYMOUS-REPEATED-CAPTURED-NAMED-FUNCTION-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-CAPTURED-FUNCTION-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-PATTERN-001`, `TOPAL-FUNCTION-NESTED-001`,
`TOPAL-TYPE-MATCH-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5af.

## TOPAL-COMP-ANONYMOUS-REPEATED-CAPTURED-FUNCTION-AGGREGATE-001 — Exact captured Function aggregate values

The checked compiler model shall admit a repeated anonymous-pattern name with
the same exact recursively nested Tuple or Record classifier containing
captured Function leaves when both operands retain complete callable facts.
Ordinary fields shall retain their existing semantic-order structural guards.
When every corresponding Function leaf has the same stable named, symbolic,
nested, or canonical anonymous source identity, the model shall forward both
path-ordered capture snapshots, require the same capture schema at each path,
and require exact compiler equality for each represented capture classifier. If
any callable identity differs, its observation-field guard shall make the
aggregate unequal without requiring capture transport. Missing callable facts,
inconsistent schemas, and required non-equality capture state shall fail before
LLVM or artifact publication.

The first aggregate occurrence shall remain the sole source binding and DWARF
parameter. Its captures and, when required, the later occurrence's captures
shall follow source parameters as deterministic hidden operands ordered by
canonical aggregate path and capture order. Lowering shall compare ordinary
aggregate fields first and required capture pairs afterward, then reuse the
Topal-owned mismatch diagnostic and exit 65. Matching private definitions and
calls shall use exact `fastcc` prototypes while LLVM owns physical AMD64
placement. Observation fields shall remain non-dispatching.

Tests shall cover captured anonymous Function leaves in Record and nested
Tuple/Record values, captured nested named leaves, equal and unequal capture
payloads, callable-identity mismatch without unnecessary capture equality,
non-equality capture rejection before artifact publication when identities
match, checked-model path/capture guards, direct ordered IR, interpreter modes
and reversible history, the shared corpus, separate resource baselines,
freestanding ELF/DWARF properties, and full O0 GDB values/frames. This shall add
no closure or environment object, allocation, pattern table, function pointer,
indirect call, dispatch table, foreign dependency, C/C++ runtime,
other-language standard library, public aggregate/callable ABI, or
`topal-native/6` revision. Dynamic aggregate selection, Function containment
outside admitted Tuple/Record/Optional/Sum/Result/List/Array/Map paths, unsupported capture classifiers, ordinary named-function
header repetition, publication, and library adapters remain deferred. Future
compiled-library metadata shall encode canonical aggregate paths, stable
callable identities, ordered capture schemas and classifiers, semantic equality
requirements, representation identity, lifetime/effects, and target adapters;
it shall not serialize private observation tags, hidden operand names or layout,
LLVM types, or target-specific placement. This realizes
`TOPAL-COMPILER-ANONYMOUS-REPEATED-CAPTURED-FUNCTION-AGGREGATE-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-FUNCTION-AGGREGATE-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-CAPTURED-FUNCTION-001`,
`TOPAL-COMPILER-FUNCTION-AGGREGATE-CAPTURE-001`, `TOPAL-TYPE-MATCH-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5ae.

## TOPAL-COMP-ANONYMOUS-REPEATED-SUM-001 — Exact nominal Sum repeated identity

The checked compiler model shall admit a repeated anonymous-pattern name with
one exact nominal Union or positional Variant classifier when every possible
payload has existing exact compiler identity or recursively satisfies this
requirement. Tuple and Record fields may contain such a Sum recursively. The
model shall retain nominal identity and ordered alternative/payload schemas;
distinct declarations with structurally equal alternatives shall not match.
Function, Range, Result, refined, authority-bearing, and other payloads without
admitted exact identity shall fail before LLVM or artifact publication.

Lowering shall compare tags first. Unequal tags shall reach the existing Topal-
owned mismatch diagnostic and exit 65 without payload comparison. Equal tags
shall use LLVM `switch` to compare only the active alternative payload through
existing direct recursive comparisons and merge the result through an `i1`
`phi`. Inactive private fields shall neither be observed nor influence source
identity. This compiler-only guard shall not claim the general source Equality
capability for Sums.

Each operand shall retain the existing exact private aggregate in matching
`fastcc` caller and callee prototypes while LLVM owns physical AMD64 aggregate
and control-flow lowering. The first occurrence shall be the sole source
binding and DWARF parameter with its nominal Sum classifier and active value.
Tests shall cover labeled Union and positional Variant values; payload-free,
Int, String, Tuple, and nested Sum alternatives; same-value success; same-tag
payload mismatch; distinct-tag short-circuit;
unsupported payload rejection; checked-model facts; direct `switch`/`phi` IR;
interpreter modes and reversible history; the shared corpus; separate resource
baselines; freestanding ELF/DWARF properties; and full O0 GDB values/frames.

This shall add no generic matcher, Sum-equality runtime, pattern table,
allocation, callback, indirect dispatch, foreign dependency, C/C++ runtime,
other-language standard library, public aggregate ABI, or `topal-native/6`
revision. General derived Sum Equality is governed by
`TOPAL-COMP-SUM-EQUALITY-001`; recursive Sum declarations, Function-containing
Sums, persistent storage, publication, and library adapters remain deferred.
Future compiled-library metadata shall encode stable nominal
identity, positional/labeled form, ordered alternatives, payload schemas,
semantic identity/equality requirements, representation identity, and target
adapters; it shall not serialize private tags, inactive storage, LLVM types, or
target-specific placement. This realizes
`TOPAL-COMPILER-ANONYMOUS-REPEATED-SUM-001`,
`TOPAL-COMPILER-ANONYMOUS-REPEATED-PATTERN-001`, `TOPAL-TYPE-MATCH-001`,
`TOPAL-FUNCTION-ANONYMOUS-001`, and `TOPAL-TYPE-CALL-001` for compiler increment
3b2-b5ag.

## TOPAL-COMP-PACKAGED-OPERAND-001 — Closed scalar packaged operand

The checked compiler model shall admit exactly one packaged function operand
whose fields have admitted scalar classifiers. A full positional product shall
map to fields in declaration order. A labeled product shall be a
declaration-order prefix containing every required field, and omitted trailing
fields shall have closed defaults. The frontend shall preserve one-time
evaluation by retaining supplied declaration/source order followed by omitted
default order, adapt every field to its declared classifier, and distinguish
semantic missing/unknown/type failures from compiler-unsupported package
shapes.

The frontend shall normalize an admitted package into its source field list.
LLVM definitions and calls shall use the same exact flattened private `fastcc`
prototype, leaving physical x86-64 placement to LLVM. Full O0 DWARF/GDB shall
show each field as a source-named parameter with its value and the ordinary
function frame. Native tests shall cover the existing interpreter regression,
default and explicit/positional field supply, invalid and unsupported shapes,
exact IR, execution, artifact independence, and debugger observation.

The emitted IR shall use no `byval`, `sret`, `inalloca`, or `preallocated`
attribute and no package runtime or allocation. General label association is
governed by `TOPAL-COMP-PACKAGED-ASSOCIATION-ORDER-001`. Two or mixed packages
are governed by `TOPAL-COMP-COMPOUND-PACKAGED-OPERAND-001`. Exact capture-free
Tuple and Record fields are governed by
`TOPAL-COMP-STRUCTURED-PACKAGED-FIELD-001`; exact nominal Sum fields are
governed by `TOPAL-COMP-SUM-PACKAGED-FIELD-001`; exact direct Function fields
are governed by `TOPAL-COMP-FUNCTION-PACKAGED-FIELD-001`; exact
Function-containing Tuple and Record fields are governed by
`TOPAL-COMP-FUNCTION-AGGREGATE-PACKAGED-FIELD-001`. Exact represented List,
Optional, Result, and Range fields are governed by
`TOPAL-COMP-CONTAINER-PACKAGED-FIELD-001`. Exact Array, Set, Bag, and Map fields
are governed by `TOPAL-COMP-COLLECTION-PACKAGED-FIELD-001`. Exact root and
root-alias Scope fields are governed by
`TOPAL-COMP-SCOPE-PACKAGED-FIELD-001`. Other non-scalar
fields,
nested package declarations, opaque package values, and invocation-dependent
defaults remain rejected until their complete evaluation, storage, and public
ABI rules are implemented. This shall add no foreign
dependency, C/C++ runtime, other-language standard library, public aggregate
ABI, or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-PACKAGED-OPERAND-001`, `TOPAL-FUNCTION-PACKAGED-OPERAND-001`,
and `TOPAL-TYPE-CALL-001` for compiler increment 3b2-b5n.

## TOPAL-COMP-PACKAGED-ASSOCIATION-ORDER-001 — Label-based scalar package association

The checked compiler model shall extend the single admitted scalar package so a
labeled argument may supply each unique known field in any source order and may
omit a closed-defaulted field at any declaration position. It shall require
every nondefaulted field and reject unknown labels, duplicate labels, and
classifier mismatches before LLVM lowering or artifact publication.

The frontend shall retain every supplied expression exactly once in labeled
source order. If declaration order differs, it shall nest compiler-private
immutable bindings in source order and form the direct call from adapted local
references permuted into declaration order. Omitted closed defaults shall be
evaluated once in declaration order after supplied expressions. The private
bindings shall have no source-level or DWARF identity.

LLVM definitions and calls shall retain the existing matching flattened
private `fastcc` prototype in declaration order, with AMD64 register and stack
placement left to LLVM. GDB shall expose only the source fields, classifiers,
values, and function frame. Tests shall cover reordered supplied calls,
non-trailing omission, source-order function-call evaluation, positional
parity, unknown and duplicate rejection, exact IR, all interpreter modes,
reversible debugging, the shared corpus and separate resource baselines,
freestanding ELF/DWARF properties, and O0 GDB values/frames.

This shall add no package aggregate at the call boundary, `byval`, `sret`,
`inalloca`, `preallocated`, package runtime, allocation, foreign dependency,
C/C++ runtime, other-language standard library, public aggregate ABI, or
`topal-native/6` revision. Future compiled-library metadata shall encode stable
field identities, declaration order, default semantics and dependencies,
evaluation effects, representation identity, and target adapters independently
of compiler-private binding names, LLVM types, and physical placement. Two or
mixed packages are governed by `TOPAL-COMP-COMPOUND-PACKAGED-OPERAND-001`.
Exact capture-free Tuple and Record fields are governed by
`TOPAL-COMP-STRUCTURED-PACKAGED-FIELD-001`; exact nominal Sum fields are
governed by `TOPAL-COMP-SUM-PACKAGED-FIELD-001`; exact direct Function fields
are governed by `TOPAL-COMP-FUNCTION-PACKAGED-FIELD-001`; exact
Function-containing Tuple and Record fields are governed by
`TOPAL-COMP-FUNCTION-AGGREGATE-PACKAGED-FIELD-001`. Exact represented List,
Optional, Result, and Range fields are governed by
`TOPAL-COMP-CONTAINER-PACKAGED-FIELD-001`. Exact Array, Set, Bag, and Map fields
are governed by `TOPAL-COMP-COLLECTION-PACKAGED-FIELD-001`. Exact root and
root-alias Scope fields are governed by
`TOPAL-COMP-SCOPE-PACKAGED-FIELD-001`. Other non-scalar
fields,
nested package declarations, opaque package values, invocation- or
capture-dependent defaults, and public package adapters remain deferred. This
realizes
`TOPAL-COMPILER-PACKAGED-ASSOCIATION-ORDER-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5ai.

## TOPAL-COMP-COMPOUND-PACKAGED-OPERAND-001 — Two and mixed scalar packages

The checked compiler model shall admit a closed scalar package in either or
both of a function's two syntactic operand positions. An unpackaged operand
mixed with a package shall have an admitted non-callable scalar classifier.
Both source operands remain mandatory. Names shall be unique across all fields
and unpackaged operands. Unknown or duplicate labels, missing required fields,
classifier mismatches, and duplicate parameter names shall reject before LLVM
lowering or artifact publication.

The frontend shall retain every explicit ordinary operand and package field
exactly once in global source order: left operand before right operand and each
product's fields in source order. Omitted closed defaults shall execute after
all explicit values, in operand and field declaration order. The normalized
direct call shall receive ordinary operands and package fields in operand order,
with fields in declaration order. Compiler-private ordering bindings shall have
no source-level or DWARF identity.

LLVM definitions and calls shall use one matching flattened private `fastcc`
parameter per ordinary operand or package field, leaving physical AMD64
register and stack placement to LLVM. GDB shall expose only the source
parameters/fields, classifiers, values, and ordinary function frame. Tests
shall cover package/package, package/scalar, scalar/package, arbitrary label
order, closed defaults, positional parity, global source-order calls, invalid
labels and duplicate names, exact IR, all interpreter modes, reversible
debugging, the shared corpus and separate resource baselines, freestanding
ELF/DWARF properties, and O0 GDB values/frames.

This shall add no package aggregate at the call boundary, `byval`, `sret`,
`inalloca`, `preallocated`, package runtime, allocation, foreign dependency,
C/C++ runtime, other-language standard library, public aggregate ABI, or
`topal-native/6` revision. Future compiled-library metadata shall preserve
syntactic-operand partition/order beside stable field identities and order,
default semantics/dependencies, evaluation effects, representation identity,
and target adapters, independently of compiler-private names, LLVM types, and
physical placement. Exact capture-free Tuple and Record fields are governed by
`TOPAL-COMP-STRUCTURED-PACKAGED-FIELD-001`; exact nominal Sum fields are
governed by `TOPAL-COMP-SUM-PACKAGED-FIELD-001`; exact direct Function fields
are governed by `TOPAL-COMP-FUNCTION-PACKAGED-FIELD-001`; exact
Function-containing Tuple and Record fields are governed by
`TOPAL-COMP-FUNCTION-AGGREGATE-PACKAGED-FIELD-001`. Exact represented List,
Optional, Result, and Range fields are governed by
`TOPAL-COMP-CONTAINER-PACKAGED-FIELD-001`. Exact Array, Set, Bag, and Map fields
are governed by `TOPAL-COMP-COLLECTION-PACKAGED-FIELD-001`. Exact root and
root-alias Scope fields are governed by
`TOPAL-COMP-SCOPE-PACKAGED-FIELD-001`. Other Function-containing aggregates,
other non-scalar fields, nested package
declarations, opaque compound package values, invocation- or capture-dependent
defaults, recursive compound signatures, and public package adapters remain
deferred. This realizes
`TOPAL-COMPILER-COMPOUND-PACKAGED-OPERAND-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5aj.

## TOPAL-COMP-STRUCTURED-PACKAGED-FIELD-001 — Exact Tuple and Record package fields

The checked compiler model shall admit exact capture-free Tuple and Record
classifiers as fields of one- or two-operand packages when their recursively
composed leaf classifiers are already supported by the private function ABI.
Supplied values and closed defaults shall undergo the same exact structural
adaptation as ordinary private aggregate parameters. Function-containing Tuple
and Record fields are governed by
`TOPAL-COMP-FUNCTION-AGGREGATE-PACKAGED-FIELD-001`. Unsupported leaves,
mismatched shapes, and non-closed defaults shall reject before LLVM lowering or
artifact publication.

The frontend shall retain each explicit structured field once in the source
order established by the package rules, evaluate structured closed defaults
after explicit values in operand/field declaration order, and pass each complete
field in operand/field declaration order. A structured field shall remain one
source field and one exact private parameter; its internal components shall not
become package fields. Compiler-private ordering bindings shall have no source
or DWARF identity.

LLVM definitions and calls shall use matching exact aggregate `fastcc`
parameters and leave physical AMD64 placement to LLVM. GDB shall expose the
source field name, complete recursively structured classifier/value, and
ordinary function frame. Tests shall cover one-package and mixed two-operand
calls, Tuple and Record fields, reordered once-only function calls, a closed
Record default, positional parity, opaque and unsupported-field rejection,
exact aggregate IR, all interpreter modes, reversible debugging, the shared
corpus and separate resource baselines, freestanding ELF/DWARF properties, and
O0 GDB values/frames.

This shall add no package-level aggregate, `byval`, `sret`, `inalloca`,
`preallocated`, package runtime, allocation beyond an existing value
representation, foreign dependency, C/C++ runtime, other-language standard
library, public aggregate ABI, or `topal-native/6` revision. Future
compiled-library metadata shall preserve complete canonical structural
classifiers and representation identities beside operand/field/default/effect
semantics and target adapters. Exact Function-containing Tuple and Record fields
are governed by `TOPAL-COMP-FUNCTION-AGGREGATE-PACKAGED-FIELD-001`. Nested
package declarations, opaque whole-package values, dependent defaults,
recursive structured package signatures, public adapters, and other unsupported
non-scalar fields remain deferred. Exact nominal Sum fields are governed by
`TOPAL-COMP-SUM-PACKAGED-FIELD-001`; exact direct Function fields are governed
by `TOPAL-COMP-FUNCTION-PACKAGED-FIELD-001`. This realizes
`TOPAL-COMPILER-STRUCTURED-PACKAGED-FIELD-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5ak.

## TOPAL-COMP-SUM-PACKAGED-FIELD-001 — Exact nominal Sum package fields

The checked compiler model shall admit an exact nominal Sum classifier as a
field of one- or two-operand packages when every alternative payload is already
supported by the private Sum function ABI and contains no Function value or
capture environment. Supplied values and closed defaults shall retain exact
nominal identity, tag, and active payload through ordinary classifier
adaptation. Unsupported payloads, nominal mismatches, and non-closed defaults
shall reject before LLVM lowering or artifact publication.

The frontend shall retain each explicit Sum field once in package source order,
evaluate closed Sum defaults afterward in operand/field declaration order, and
pass each complete Sum in operand/field declaration order. A Sum field shall
remain one source field and one exact private tag-plus-payload parameter;
alternatives and payload components shall not become package fields.
Compiler-private ordering bindings shall have no source or DWARF identity.

LLVM definitions and calls shall use matching exact Sum `fastcc` parameters and
leave physical AMD64 placement to LLVM. GDB shall expose the source field name,
nominal classifier, active alternative/payload value, and ordinary function
frame. Tests shall cover one-package and mixed two-operand calls, reordered
once-only calls, a closed Sum default, positional parity, opaque and
unsupported-Function-payload rejection, exact Sum IR, all interpreter modes, reversible
debugging, the shared corpus and separate resource baselines, freestanding
ELF/DWARF properties, and O0 GDB values/frames.

This shall add no package-level aggregate, payload decomposition, `byval`,
`sret`, `inalloca`, `preallocated`, package runtime, allocation beyond the
existing Sum representation, foreign dependency, C/C++ runtime, other-language
standard library, public aggregate ABI, or `topal-native/6` revision. Future
compiled-library metadata shall preserve canonical nominal identity, complete
alternatives/payload classifiers, representation identity,
operand/field/default/effect semantics, and target adapters. Nested package
declarations, opaque whole-package values, Function-containing Sum payloads
outside `TOPAL-COMP-SUM-FUNCTION-001`, dependent defaults, recursive Sum
package signatures, public adapters, and other unsupported non-scalar fields
remain deferred. This realizes
`TOPAL-COMPILER-SUM-PACKAGED-FIELD-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5al.

## TOPAL-COMP-FUNCTION-PACKAGED-FIELD-001 — Exact direct Function package fields

The checked compiler model shall admit an exact Function value as a direct
field of a one- or two-operand package when its callable identity and any
represented immutable capture snapshot are already admitted by the private
Function parameter ABI. Supplied values and closed defaults shall retain the
same named, symbolic, anonymous, or non-escaping nested callable facts used by
an ordinary Function parameter. Opaque, dynamically selected, escaping, or
otherwise unrepresentable callable values shall reject before LLVM lowering or
artifact publication.

The frontend shall preserve each explicit Function initializer once in package
source order. A compiler-private ordering binding shall retain exact callable
and capture facts beside the runtime Function observation tag, and the direct
call shall permute that retained value into operand/field declaration order.
One source Function field shall remain one source parameter; any deterministic
hidden capture parameters required by the existing specialized callable
boundary shall not become package fields or source parameters.

LLVM definitions and calls shall use matching private `fastcc` Function-tag and
capture parameters and leave physical AMD64 placement to LLVM. Callee
application shall remain a direct specialized call without function-pointer
dispatch. GDB shall expose the source field identity/value and ordinary frame,
while compiler-private bindings and hidden capture transport remain absent from
source debugging. Tests shall cover reordered once-only Function-returning and
scalar calls, a closed symbolic default, positional parity, mixed operands,
captured callable forwarding, opaque-package rejection, direct IR, all
interpreter modes, reversible debugging, the shared corpus and separate
resource baselines, freestanding ELF/DWARF properties, and O0 GDB values/frames.

This shall add no package aggregate, function pointer, indirect call, closure
allocation/runtime, `byval`, `sret`, `inalloca`, `preallocated`, foreign
dependency, C/C++ runtime, other-language standard library, public callable ABI,
or `topal-native/6` revision. Future compiled-library metadata shall preserve
callable source/declaration identity, overload set, capture schema and equality,
representation/lifetime/effect semantics, operand/field/default semantics, and
target adapters. Exact Function-containing Tuple and Record fields are governed
by `TOPAL-COMP-FUNCTION-AGGREGATE-PACKAGED-FIELD-001`. Function containment in
other aggregates, dynamic escape/selection, nested package declarations, opaque
whole-package values, dependent defaults, recursive callable package
signatures, public adapters, and other unsupported fields remain deferred. This
realizes
`TOPAL-COMPILER-FUNCTION-PACKAGED-FIELD-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5am.

## TOPAL-COMP-FUNCTION-AGGREGATE-PACKAGED-FIELD-001 — Exact Function aggregate package fields

The checked compiler model shall admit an exact Tuple or Record containing one
or more Function leaves as a complete package field when its full structural
classifier, callable identities, and immutable capture snapshots are already
admitted by the private Function aggregate parameter boundary. Every Function
leaf shall retain exact named, symbolic, anonymous, or non-escaping nested
callable facts. Missing, opaque, dynamically selected, escaping, or otherwise
unrepresentable callable facts shall reject before LLVM lowering or artifact
publication.

For every compiler-private package-ordering binding, the frontend shall retain
the aggregate's complete recursive structural fact tree, canonical Function
paths, callable identities, and capture facts beside the runtime aggregate.
Each explicit initializer shall execute once in package source order. Closed
aggregate defaults shall execute afterward in operand/field declaration order,
and each complete aggregate shall remain one source field and one private
aggregate parameter rather than being decomposed into package fields.

LLVM definitions and calls shall use the existing exact target-derived
aggregate type followed by deterministic canonical-path-ordered hidden capture
parameters under matching private `fastcc` prototypes. LLVM shall own physical
AMD64 aggregate classification and placement. Callee application shall remain
a direct specialization without function-pointer dispatch. GDB shall expose
the one complete source Tuple or Record field and ordinary frame while private
ordering bindings and hidden captures remain absent from source debugging.

Tests shall cover reordered once-only scalar and Function-aggregate-producing
calls, capture-free Record and capture-bearing Tuple fields, a closed symbolic
Function-aggregate default, exact output, opaque whole-package artifact-free
rejection, recursive checked facts, exact direct IR, all interpreter modes,
reversible debugging, the shared corpus and separate resource baselines,
freestanding ELF/DWARF properties, and O0 GDB aggregate values/frames.

This shall add no package-level aggregate, member decomposition, function
pointer, indirect call, closure allocation/runtime, `byval`, `sret`, `inalloca`,
`preallocated`, foreign dependency, C/C++ runtime, other-language standard
library, public callable/aggregate ABI, or `topal-native/6` revision. Future
compiled-library metadata shall preserve complete canonical aggregate
classifiers and representation identities, Function-leaf paths and
source/declaration identities, overload sets, capture schemas and equality,
lifetime/effect semantics, operand/field/default semantics, and target adapters
independently of private binding names, LLVM types, tags, and physical
placement. Optional Function fields are governed by
`TOPAL-COMP-OPTIONAL-FUNCTION-001`; exact nominal Sum Function fields are
governed by `TOPAL-COMP-SUM-FUNCTION-001`; exact arithmetic Result Function
fields are governed by `TOPAL-COMP-RESULT-FUNCTION-001`; exact finite List
Function fields are governed by `TOPAL-COMP-LIST-FUNCTION-001`; exact fixed-size
Array Function fields are governed by `TOPAL-COMP-ARRAY-FUNCTION-001`; exact
nonempty String-keyed Map Function fields are governed by
`TOPAL-COMP-MAP-FUNCTION-001`. Function
containment in other aggregates; dynamic escape/selection; dependent defaults;
nested package declarations;
recursive callable package signatures; persistent storage; publication; and
public adapters remain deferred. This realizes
`TOPAL-COMPILER-FUNCTION-AGGREGATE-PACKAGED-FIELD-001`,
`TOPAL-COMPILER-FUNCTION-AGGREGATE-001`,
`TOPAL-COMPILER-FUNCTION-AGGREGATE-CAPTURE-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5an.

## TOPAL-COMP-CONTAINER-PACKAGED-FIELD-001 — Exact represented container package fields

The checked compiler model shall admit exact List, Optional, Result, and Range
classifiers as complete fields of one- or two-operand packages when each exact
classifier is already admitted by its private function parameter boundary. The
contained element, value, success/error-domain, or endpoint classifiers shall
remain within that existing represented boundary and shall contain no Function
value or capture environment under this requirement. Exact `Optional Function`
fields are instead governed by `TOPAL-COMP-OPTIONAL-FUNCTION-001`; exact
arithmetic `Result Function` fields are governed by
`TOPAL-COMP-RESULT-FUNCTION-001`; exact finite `List Function` fields are
governed by `TOPAL-COMP-LIST-FUNCTION-001`; exact fixed-size `Array Function`
fields are governed by `TOPAL-COMP-ARRAY-FUNCTION-001`; exact nonempty
`Map (String, Function)` fields are governed by
`TOPAL-COMP-MAP-FUNCTION-001`. Unsupported contained
classifiers and mismatched container classifiers shall reject before
LLVM lowering or artifact publication.

The frontend shall retain every explicit represented-container initializer
once in package source order with its exact checked classifier. A closed
default whose analyzed value already has the exact declared container
classifier shall execute afterward in operand/field declaration order. Direct
calls shall pass each complete source field in operand/field declaration order.
Implicit context-dependent construction or lifting of a differently classified
default, including a bare success value into Result, remains rejected in this
increment.

LLVM definitions and calls shall use one matching private pointer-carrier
`fastcc` parameter per source field and leave physical AMD64 placement to LLVM.
Contained values shall not become package fields. Package normalization shall
add no allocation or alter the existing process-lifetime ownership of List
nodes. GDB shall expose the complete List, Optional, Result, and Range source
fields and ordinary frame while private ordering bindings remain absent from
source debugging.

Tests shall cover all four represented container families, reordered once-only
container-producing calls, one exact closed Optional default, exact output,
unsupported-field artifact rejection, checked classifier retention, matching
direct pointer-carrier IR, all interpreter modes, reversible debugging, the
shared corpus and separate resource baselines, freestanding ELF/DWARF
properties, and O0 GDB values/frames.

This shall add no package aggregate, contained-value decomposition, `byval`,
`sret`, `inalloca`, `preallocated`, package runtime, allocation beyond existing
container construction, foreign dependency, C/C++ runtime, other-language
standard library, public container ABI, or `topal-native/6` revision. Future
compiled-library metadata shall preserve the canonical generic constructor,
contained classifier or Result error domain, Range endpoint classifier,
representation/lifetime/default/effect semantics, stable operand/field
identities and order, and target adapters independently of compiler-private
binding names, LLVM pointer types, and physical placement. Function-containing
containers outside exact `Optional Function`, arithmetic `Result Function`,
finite `List Function`, and fixed-size `Array Function`, unsupported List
elements and container payloads, context-dependent defaults, nested package declarations,
opaque whole-package values, recursive package signatures, persistent storage,
publication, and public adapters remain deferred. This realizes
`TOPAL-COMPILER-CONTAINER-PACKAGED-FIELD-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5ao.

## TOPAL-COMP-COLLECTION-PACKAGED-FIELD-001 — Exact represented collection package fields

The checked compiler model shall recognize exact `Array (N, Int)`, `Set Int`,
`Bag Int`, and `Map (String, Int)` private function parameter and result
classifiers, with a statically parsed nonnegative Array extent, and admit those
values as complete fields of one- or two-operand packages. Other element,
key, or value classifiers and mismatched collection classifiers shall reject
before LLVM lowering or artifact publication rather than being accepted from
their pointer carrier alone. Exact `Array (N, Function)` fields are instead
governed by `TOPAL-COMP-ARRAY-FUNCTION-001`; exact nonempty
`Map (String, Function)` fields are governed by
`TOPAL-COMP-MAP-FUNCTION-001`.

The frontend shall retain every explicit collection-producing initializer once
in package source order with its exact constructor and extent/element/key/value
classifier facts. Direct calls shall pass each complete source field in
operand/field declaration order. Closed defaults remain governed by the
existing exact checked-default rule; constructions not already analyzable as
the declared collection classifier shall remain rejected.

LLVM definitions and calls shall use one matching private pointer-carrier
`fastcc` parameter per source field and leave physical AMD64 placement to LLVM.
Entries, keys, values, multiplicities, and collision state shall not become
package fields. Package normalization shall add no allocation or alter the
existing process-lifetime ownership of collection construction. GDB shall
expose the complete Array, Set, Bag, and Map source fields and ordinary frame
while private ordering bindings remain absent from source debugging.

Tests shall cover all four exact collection families, reordered once-only
collection-producing calls, positional parity, exact output, unsupported or
mismatched classifier artifact rejection, checked classifier retention,
matching direct pointer-carrier IR, all interpreter modes, reversible
debugging, the shared corpus and separate resource baselines, freestanding
ELF/DWARF properties, and O0 GDB values/frames.

This shall add no package aggregate, entry decomposition, `byval`, `sret`,
`inalloca`, `preallocated`, package runtime, allocation beyond existing
collection construction, foreign dependency, C/C++ runtime, other-language
standard library, public collection ABI, or `topal-native/6` revision. Future
compiled-library metadata shall preserve the canonical constructor; Array
extent; element or key/value classifiers; ordering, uniqueness, multiplicity,
and collision semantics; representation/lifetime/default/effect semantics;
stable operand/field identities and order; and target adapters independently
of compiler-private binding names, LLVM pointer types, and physical placement.
Function-containing collections outside exact `Array (N, Function)` and
nonempty exact `Map (String, Function)`, other generic specializations,
context-dependent or otherwise unanalyzable defaults, nested package
declarations, opaque whole-package values, recursive package signatures,
persistent collection storage, publication, and public adapters remain
deferred. This realizes `TOPAL-COMPILER-COLLECTION-PACKAGED-FIELD-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5ap.

## TOPAL-COMP-SCOPE-PACKAGED-FIELD-001 — Exact root Scope package fields

The checked compiler model shall admit the live source-root namespace and an
exact retained root alias as a complete `Scope` field of one- or two-operand
packages. It shall retain the namespace identity, binding-position declaration
snapshot, function overload order, and represented data facts through any
compiler-private source-order binding. A closed default of `root` shall be
admitted. Opaque or computed Scope values, nested or non-root namespaces, and a
live `root` package field formed inside a compiled function shall reject before
LLVM lowering or artifact publication.

The frontend shall evaluate every explicit field initializer once in package
source order and pass source fields in operand/field declaration order. It
shall reuse `TOPAL-COMP-NAMESPACE-BOUNDARY-001`: the private call shall pass one
explicit sealed `i32` Scope observation followed by the exact represented
immutable namespace data values in deterministic existing order. Qualified
function selection shall remain static and direct. LLVM shall own physical
AMD64 placement, and package normalization shall add no allocation or alter
namespace identity, snapshot, or lifetime.

Full O0 DWARF/GDB shall expose the source Scope field and namespace observation,
each material represented data argument, and the ordinary function frame while
compiler-private ordering bindings remain absent. Tests shall cover labeled
reordering with once-only evaluation, positional parity, a closed `root`
default, exact output, function-body live-root artifact rejection, checked
namespace-fact retention, direct matching IR, all interpreter modes, reversible
history, the shared corpus and separate resource baselines, freestanding
ELF/DWARF properties, and GDB Scope/data values and frames.

This shall add no package aggregate, namespace table, dynamic lookup, function
pointer, indirect call, environment or package allocation, `byval`, `sret`,
`inalloca`, `preallocated`, foreign dependency, C/C++ runtime, other-language
standard library, public Scope ABI, or `topal-native/6` revision. Future
compiled-library metadata shall preserve namespace identity and snapshot
position; member visibility and declaration order; complete function overload,
generator, and represented-data schemas; hidden data classifier/order,
lifetime, and effect facts; package operand/field identity and order; default
semantics and dependencies; and versioned target adapters independently of the
private `i32` tag, hidden parameter names, LLVM types, symbols, and physical
placement. Opaque, computed, nested, non-root, external, escaping, result, and
public/library Scope environments remain deferred. This realizes
`TOPAL-COMPILER-SCOPE-PACKAGED-FIELD-001`,
`TOPAL-COMPILER-NAMESPACE-BOUNDARY-001`,
`TOPAL-FUNCTION-PACKAGED-OPERAND-001`, and `TOPAL-TYPE-CALL-001` for compiler
increment 3b2-b5aq.

## TOPAL-COMP-CONTEXT-CAPTURE-001 — Private defining-context capture

The checked compiler model shall admit `@ member` in a root function called
directly from the source entry frame when `member` is an admitted scalar root
binding declared before the function. Resolution shall use only the function's
immutable defining context: later root declarations and same-named caller or
lexical bindings shall not participate. The call shall reuse the already
evaluated root compiler value and shall not replay its initializer.

The frontend shall detect referenced context members and append them in root
declaration order as explicit private capture arguments and parameters. The
capture shall retain its exact checked classifier and static facts. LLVM shall
receive the same exact private `fastcc` prototype at definition and call sites
and own physical x86-64 placement. Full O0 DWARF/GDB shall expose `@ member`, its
source type and value, and the surrounding ordinary source function frame.
Native tests shall cover exact output, lexical shadow isolation, declaration
order, invalid context use, IR, artifact independence, and debugger observation.

This increment shall add no global context storage, lookup table, closure
allocation/runtime, function pointer, indirect call, foreign dependency, C/C++
runtime, other-language standard library, public closure ABI, or
`topal-native/6` revision. Aggregate captures beyond
`TOPAL-COMP-AGGREGATE-ENVIRONMENT-001`, Scope and Function captures,
anonymous/escaping closures, qualified root data not admitted by
`TOPAL-COMP-FUNCTION-ROOT-DATA-001`, and public/library contexts remain rejected.
Exact scalar forwarding is governed by
`TOPAL-COMP-CONTEXT-CAPTURE-FORWARD-001`. This realizes
`TOPAL-COMPILER-CONTEXT-CAPTURE-001` and `TOPAL-CONTEXT-SELECT-001` for compiler
increment 6c1.

## TOPAL-COMP-CONTEXT-CAPTURE-FORWARD-001 — Private defining-context forwarding

For a finite acyclic chain of statically named ordinary root functions reached
from the source entry frame, the checked model shall compute transitive exact
`@ member` selections before instantiating the outer function. Each selected
value shall come from the immutable context snapshot of the function containing
that direct selection, with declaration-position filtering applied there. The
frontend shall append every required supported private machine value to each
intermediate function's hidden capture group in root declaration order and
forward the same already-evaluated value at every direct call edge. Same-named
caller bindings, parameters, and locals shall remain isolated in every frame.

The Linux x86-64 backend shall emit matching exact `fastcc` definitions and
calls and leave physical placement to LLVM. Full O0 DWARF/GDB shall expose all
explicit and forwarded parameters accurately in the active function and every
suspended caller frame. Target-aligned debug-only stack shadows may preserve
call-clobbered values without adding semantic storage. Tests shall cover a
three-frame shared regression, interpreter modes, reversible history, checked
capture order and call arguments, unresolved overload-selection rejection,
exact direct IR, artifact-free failure, freestanding ELF/DWARF, every GDB frame,
the shared corpus, and separate resource baselines.

This shall add no global context storage, namespace/capture/environment table,
initializer replay, lookup, allocation, function pointer, indirect call,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Overload forwarding beyond
`TOPAL-COMP-OVERLOAD-ENVIRONMENT-001`, recursive forwarding beyond
`TOPAL-COMP-RECURSIVE-SCALAR-ENVIRONMENT-001`, local named Function forwarding
beyond `TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001`, anonymous functions,
aggregate environments beyond
`TOPAL-COMP-AGGREGATE-ENVIRONMENT-001`, otherwise unsupported context members,
escape, and public/library environments remain deferred. Future
compiled-library metadata shall preserve canonical
defining-context instance and source-session identity, every selection and call
edge, callee identity/overload, member stable identity, captured declaration
position, visibility/declaration order, classifier/semantic representation,
capture order/lifetime/effects, and a versioned target adapter independently of
private names, LLVM types/symbols, debug shadows, and physical placement. This
realizes `TOPAL-COMPILER-CONTEXT-CAPTURE-FORWARD-001` and
`TOPAL-CONTEXT-SELECT-001` for increment 6c2a.

## TOPAL-COMP-RECURSIVE-SCALAR-ENVIRONMENT-001 — Proof-backed recursive scalar environments

The checked model shall permit exact scalar hidden captures on a direct or
mutual recursive edge only after an existing explicit-measure, Int, Nat, or
mutual recursion proof independently admits that edge. Capture discovery shall
not establish termination. Before closing a cycle, the frontend shall compute
the transitive union of required `@ member` and `root member` values for every
graph member, append them in established declaration order, and use the current
hidden parameters as every recursive call argument. The source entry edge alone
shall supply the immutable defining-context snapshot and live-root call-position
snapshot.

Every cycle member and call shall use the same exact private `fastcc` prototype
and already-reserved symbol, with LLVM owning x86-64 placement. Definitions
shall remain `noinline` without claiming `norecurse`. Full O0 DWARF/GDB shall
expose the explicit parameter and each context/root capture in the active frame
and every suspended direct or mutual frame; aligned debug-only shadows may
retain call-clobbered values without adding semantic state. Tests shall cover
direct, mutual, and explicit-measure checked graphs, transitive captures used by
different cycle members, unproven artifact-free rejection, exact cyclic IR,
interpreter modes, reversible history, freestanding ELF/DWARF, the shared
corpus, resource baselines, and every recursive GDB frame.

This shall add no global root/context storage, environment/cycle table, lookup,
initializer replay, allocation, dispatcher, function pointer, indirect call,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Unproven, incomplete, or mixed-proof cycles;
overload selection beyond `TOPAL-COMP-OVERLOAD-ENVIRONMENT-001`; unsupported
representations; local named Function recursion beyond
`TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001`; anonymous/nested/escaping
recursion; and public/library recursive environments remain deferred. Future
library metadata shall retain
recursion graph/member identity, proof rule/evidence, every ordered call and
capture edge, canonical context/root instance, member identity and declaration
position, classifier/semantic representation, capture order/lifetime/effects,
and a versioned target adapter independently of private symbols, LLVM types,
debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-RECURSIVE-SCALAR-ENVIRONMENT-001` for increments 6b2b2d and
6c2b.

## TOPAL-COMP-AGGREGATE-ENVIRONMENT-001 — Private represented aggregate environments

The checked compiler model shall admit exact Tuple, labeled Record, and nominal
Sum values as hidden defining-context and live-root captures when every
component has an already-admitted private representation and the complete
aggregate contains no Function value. The same admission shall apply at direct
entry calls, through finite acyclic statically named forwarding chains, and on
every direct or mutual recursive edge independently admitted by the existing
termination proofs. Capture discovery shall not establish termination.

The entry edge shall pass each already-evaluated immutable aggregate, and every
forwarding or recursive edge shall rebuild and pass that complete semantic
value unchanged. Tuple positions, Record source field order and labels, and Sum
nominal identity, active alternative, and payload shall remain exact. The Linux
x86-64 backend shall emit matching compiler-private by-value LLVM aggregate
types under `fastcc` without `byval`, `sret`, `inalloca`, or `preallocated`
directives. LLVM shall own physical AMD64 placement and future target adapters.

Full O0 DWARF/GDB shall expose each aggregate by its source capture name and
classifier in active and suspended forwarding or recursive frames. Aligned
debug-only shadows may retain call-clobbered aggregates without semantic
storage. Tests shall cover Tuple, Record, and Sum context/root values; direct,
acyclic, and proven recursive edges; checked-model capture types and cycle
union; exact output and private IR; Function-aggregate artifact-free rejection;
interpreter modes; reversible history; freestanding ELF/DWARF; GDB values in
active and suspended frames; the shared corpus; and separate resource
baselines.

This shall add no global root/context storage, aggregate environment object,
environment/namespace table, lookup, replay, allocation, dispatcher, function
pointer, indirect call, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Function-bearing
aggregates; Scope, Generator, constraint, evidence, static-only, opaque, or
otherwise unsupported representations; overload selection beyond
`TOPAL-COMP-OVERLOAD-ENVIRONMENT-001`; local named Function forwarding beyond
`TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001`; anonymous/escaping functions; and
public/library aggregate environments remain deferred. Future library metadata
shall retain
canonical context/root instance and source session, every selection/call edge,
callee identity/overload, member identity/declaration position, complete
semantic classifier and recursive component structure, Tuple/Record ordering
and labels, Sum identity/alternative/payload, capture order/lifetime/effects,
and a versioned target adapter independently of private capture names, LLVM
aggregate types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-AGGREGATE-ENVIRONMENT-001` for increments 6b2b2e and 6c2c.

## TOPAL-COMP-OVERLOAD-ENVIRONMENT-001 — Exact overload-selected private environments

For an ordinary statically named overloaded call, the checked model shall use
only the source-ordered declaration selected by the ordinary call rules when
selection is known before instantiation from closed Unit, Boolean, Int,
Rational, or String literals, explicit parameter classifiers, exact
Tuple/Record products of those values, or classifier-preserving `+`, `-`, or
`*` over equal admitted classifiers. Capture discovery and the eventual direct
call shall retain the same declaration identity. This shall compose with direct
entry, finite acyclic and cross-overload chains, represented aggregate
environments, and independently proven direct/mutual recursion.

Every overload shall retain its own exact context/root capture vector. An
unselected overload shall neither add nor remove a hidden parameter. Selected
cross-overload and recursive edges shall forward the current exact values in
the established order through matching private `fastcc` prototypes, with LLVM
owning x86-64 placement. Capture discovery shall not establish termination.

When selection could change with retained value facts—including `Int` to
`Nat`, `String` to `Character`, or exact `Rational` narrowing—or depends on a
packaged/defaulted/qualified, locally inferred, higher-order, anonymous,
nested, dynamic, or otherwise unresolved call, the frontend shall reject before
artifact publication whenever any candidate carries an environment. It shall
not union candidate capture sets or invent a provisional overload-call ABI. A
first-class retained overload set admitted by
`TOPAL-COMP-FUNCTION-ENVIRONMENT-BOUNDARY-001` shall instead transport its
complete deduplicated semantic environment while retaining declaration-specific
capture schemas separately, and its selected direct call shall still receive
only the selected declaration's vector. An exact retained named alias admitted
by `TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001` shall use the
same admitted evidence and is not otherwise unresolved here. Tests shall cover
distinct overload capture sets, unselected-capture isolation, closed literal
and explicit-parameter selection, exact aggregate values, acyclic and
cross-overload forwarding, proven recursion, checked capture vectors, exact
output/IR, value-fact-dependent artifact-free rejection, interpreter modes,
reversible history, freestanding ELF/DWARF, selected active/suspended GDB
frames, the shared corpus, and separate resource baselines.

This shall add no global context/root state, overload/environment table,
dispatcher, function pointer, indirect call, lookup, replay, allocation,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Future library metadata shall retain canonical
source-session and context/root identity, call position, source-ordered overload
set and exact selected declaration, selection evidence/conversions, recursion
proof identity, member stable identity/declaration position, complete semantic
classifier/representation, ordered capture schema/lifetime/effects, and a
versioned target adapter independently of private capture names, LLVM
types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-OVERLOAD-ENVIRONMENT-001` for increments 6b2b2f and 6c2d.

## TOPAL-COMP-LOCAL-FUNCTION-ENVIRONMENT-001 — Exact local named Function environments

Within an ordinary root-function invocation, the checked model shall retain an
already-visible named root Function through source-ordered local alias bindings
and shall follow an exact directly applied alias back to its original visible
declaration snapshot while discovering context/root captures. The same scan
shall follow an already-admitted non-escaping ordinary nested Function called
directly or through an exact local alias. Shadowing or rebinding to any other
value shall terminate the retained edge.

An alias shall preserve original function identity, staticness, source-ordered
visible overload declarations, and selection behavior. Overloaded alias calls
shall reuse only the evidence admitted by
`TOPAL-COMP-OVERLOAD-ENVIRONMENT-001` and shall select one exact capture vector.
A nested Function shall retain existing lexical captures, but the model shall
exclude standard `@ member` and `root member` parameters from that lexical
vector and add them exactly once through the environment group. Alias discovery
shall neither prove recursion nor admit unsupported nested declarations,
overload choices, capture representations, or escapes.

The Linux x86-64 backend shall emit matching direct private `fastcc` definitions
and calls for outer, nested, and selected target functions, leaving physical
placement to LLVM and requiring no optimization. Full O0 DWARF/GDB shall expose
each Function alias, selected frame, explicit parameter, and exact source-named
capture in active and suspended frames. Tests shall cover scalar and aggregate
context/root values, multi-binding alias chains, overloaded alias selection,
nested direct and aliased calls, lexical shadow isolation, value-fact-dependent
artifact-free rejection, checked capture vectors, exact output/IR, interpreter
modes, reversible history, freestanding ELF/DWARF, GDB frames, the shared
corpus, and separate resource baselines.

This shall add no closure/environment object, Function dispatcher, function
pointer, indirect call, global context/root state, lookup, replay, allocation,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Exact private Function boundaries carrying these
environments are admitted by
`TOPAL-COMP-FUNCTION-ENVIRONMENT-BOUNDARY-001`. Escaping nested Functions;
recursive/overloaded nested Functions; opaque or dynamically selected aliases;
and public/library local-Function environments remain deferred. Future library metadata shall retain canonical source-session
and context/root identities, lexical invocation scope, alias binding stable
identity/declaration position, retained root Function and visible overload
snapshot or nested declaration path, selected declaration/call edge, selection
evidence/conversions, recursion proof identity, ordered capture
schema/classifiers/representations/lifetimes/effects, and a versioned target
adapter independently of observation tags, private capture names, LLVM
types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-LOCAL-FUNCTION-ENVIRONMENT-001` for increments 6b2b2g and 6c2e.

## TOPAL-COMP-FUNCTION-ENVIRONMENT-BOUNDARY-001 — Exact private Function-environment boundaries

The checked compiler model shall preserve the complete exact environment of a
named root Function value and retained overload set, an anonymous Function
constructed within an ordinary root-function invocation, or an admitted nested
Function across private scalar Function parameters and
results and represented Tuple or labeled Record parameters and results that
contain Function leaves. Each Function leaf shall retain one exact callable
identity and complete semantic capture schema; opaque and dynamically selected
values shall remain `E-COMPILER-UNSUPPORTED`.

The environment transported for a named root overload set shall be the
deduplicated union required by its retained declarations in root declaration
order, with context members before root members. Declaration identities,
selection evidence, and per-declaration capture schemas shall remain separate
from the runtime Function tag. After admitted source-ordered selection, the
backend shall pass only the selected declaration's vector to the direct target.
Value-fact-dependent higher-order selection shall fail before artifact
publication. Anonymous and nested captures shall retain each lexical,
contextual, and root value once; multiple boundaries shall forward the original
immutable values without initializer replay or caller-frame lookup.

The Linux x86-64 backend shall represent private Function results together with
their ordered captures and shall associate Function-containing aggregate result
captures with canonical Tuple-index or Record-label paths. It shall emit
matching private `fastcc` definitions and direct calls for every specialized
boundary and selected target, leaving aggregate classification and physical
placement to LLVM and requiring no optimization. Full O0 DWARF/GDB shall expose
source Function values, exact source-named captures, and selected, anonymous,
and nested frames. Tests shall cover named overload sets, scalar and Record
parameters/results, anonymous and nested values, context/root scalar and
aggregate captures, exact checked vectors, output/IR, value-fact-dependent
artifact-free rejection, interpreter modes, reversible history, freestanding
ELF/DWARF, GDB frames, the shared corpus, and separate resource baselines.

This shall add no global context/root state, closure/environment object,
overload/environment table, runtime dispatcher, function pointer, indirect
call, lookup, replay, allocation, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision. Sum
or unsupported Function-containing representations; escaping anonymous results
or nested results outside `TOPAL-COMP-NESTED-FUNCTION-ESCAPE-001`;
recursive/overloaded nested Functions; fact-dependent, opaque, or
dynamic selection; and public/library Function environments remain deferred.
Future library metadata shall retain canonical source-session, context/root,
lexical-scope, callable, declaration, overload-snapshot, aggregate-path, and
member identities; selection evidence/conversions; recursion-proof identity;
semantic classifiers/representations; ordered per-declaration and transported
capture schemas/lifetimes/effects; and a versioned target adapter independently
of runtime tags, compiler-private names, LLVM types/symbols, debug shadows, and
physical placement. This realizes
`TOPAL-COMPILER-FUNCTION-ENVIRONMENT-BOUNDARY-001` for increments 6b2b2h and
6c2f.

## TOPAL-COMP-RECURSION-INT-001 — Proven direct decreasing Int recursion

The checked compiler model shall reuse the shared structural proof for
`TOPAL-FUNCTION-RECURSION-INT-001` and
`TOPAL-FUNCTION-RECURSION-INT-POSITIVE-STEP-001`. It shall reserve one function
symbol only after that proof succeeds, direct every self-call in the recursive
action to that symbol, and support every independently proven self-call in the
action. A self-call in the base, a zero or otherwise invalid literal step, and
an indirect cycle without an implemented complete-cycle proof shall remain
`E-COMPILER-UNSUPPORTED`.

The recursive function body shall discard initial-call range, Rational, and
String facts for its parameters and check each against only its declared
classifier. LLVM definitions and calls shall use the same exact private
`fastcc` prototype and shall retain `noinline` without claiming `norecurse` or
requiring a tail-call optimization. Recursive Int values shall use the existing
immutable exact representation and Topal-owned Linux allocation/syscall layer,
with no runtime dispatch, C/C++ runtime, other-language standard library, or
`topal-native/6` revision. DWARF/GDB shall retain distinct recursive frames and
the current Int parameter. This requirement realizes
`TOPAL-COMPILER-RECURSION-INT-001` for increment 3b2-b5e1.

## TOPAL-COMP-RECURSION-INT-INCREASING-001 — Proven direct increasing Int recursion

The checked compiler model shall also admit the shared
`TOPAL-FUNCTION-RECURSION-INT-INCREASING-001` proof for a unary `Int` overload
with an inclusive upper-bound base and strict positive literal additions. It
shall accept multiple-unit progress in either proven direction, including safe
overshoot of the inclusive bound, while zero, negative, runtime-selected,
subtracting, base-action, and otherwise unproven increasing edges remain
`E-COMPILER-UNSUPPORTED`.

Increasing recursion shall use the same generalized parameter facts, reserved
overload symbol, exact private `fastcc` prototype, `noinline` and non-`norecurse`
attributes, immutable exact Int representation, and Topal-owned Linux
allocation/syscall layer as decreasing recursion. GDB shall retain consecutive
frames and their increasing parameter values. This adds no runtime dispatch,
C/C++ runtime, other-language standard library, or `topal-native/6` revision
and realizes `TOPAL-COMPILER-RECURSION-INT-INCREASING-001` for increment
3b2-b5e2.

## TOPAL-COMP-RECURSION-NAT-001 — Proven direct Nat recursion

The checked compiler model shall admit the shared
`TOPAL-FUNCTION-RECURSION-NAT-001` and
`TOPAL-FUNCTION-RECURSION-NAT-INCREASING-001` proofs. Decreasing recursion shall
preserve nonnegativity by enforcing the proof's nonnegative inclusive bound and
maximum literal step; increasing recursion shall add a strict positive literal.
Unsafe overshoot and every otherwise unproven direct edge shall remain rejected.

Within a recursive step the model shall forget `Nat` evidence to the unchanged
exact Int carrier for addition or subtraction, then attach `Nat` evidence to
the recursive argument only under the shared range-preservation proof. That
proof-backed `IntToNat` node shall lower as an identity: it shall not call the
dynamic Nat validator, allocate, reinterpret the value as unsigned, or change
its representation. The recursive function shall retain an exact private
`fastcc` prototype, `noinline` without `norecurse`, O0 correctness, distinct
frames, and `Nat` parameter identity in DWARF/GDB. It shall use only the
existing Topal-owned Linux syscall runtime and `topal-native/6` ABI, with no
C/C++ runtime or other-language standard library. This realizes
`TOPAL-COMPILER-RECURSION-NAT-001` for increment 3b2-b5e3.

## TOPAL-COMP-DECREASES-001 — Explicit measured recursion

The checked compiler model shall retain a v0.1 `Decreases` effect bound and
admit its direct recursive edge only when the shared
`TOPAL-FUNCTION-DECREASES-001` proof verifies the complete overload body. The
initial closure shall support one directly named `Int` or `Nat` measure among
multiple scalar parameters, verify the corresponding packaged argument on each
self-call, and reject mismatched measures and non-progressing steps.

Active proof metadata shall record the exact measured parameter index. A
proof-backed Nat evidence conversion shall be available only at that position;
all unmeasured parameters shall retain ordinary checking. The measure shall be
erased before lowering and add no hidden argument, counter, allocation,
validation call, or ABI field. The function shall use one exact private
`fastcc` prototype with `noinline` and no false `norecurse`, preserve every
source parameter in recursive DWARF/GDB frames, and use only the existing
Topal-owned Linux syscall runtime. No C/C++ runtime, other-language standard
library, or `topal-native/6` revision is permitted. This realizes
`TOPAL-COMPILER-FUNCTION-DECREASES-001` for increment 3b2-b5e4.

## TOPAL-COMP-RECURSION-EUCLIDEAN-001 — Proven Euclidean recursion

The checked compiler model shall admit the shared
`TOPAL-FUNCTION-RECURSION-EUCLIDEAN-001` proof for a binary `Int` function
with `Decreases (absolute right)`, a zero-divisor base, and the exact
`(right, left % right)` recursive edge. The compiler shall retain the
nonzero fact established by the zero comparison exclusively in its otherwise
branch, so that this modulo is direct and does not introduce an arithmetic
`Result`. It shall also retain the total nonnegative result fact of `absolute`
when adapting the base to its declared `Nat` result.

The proof and these facts shall be compile-time only: they shall add no hidden
argument, counter, dynamic Nat validator, dynamic modulo check, allocation, or
ABI field. The recursive overload shall retain one exact private `fastcc`
prototype, `noinline` without `norecurse`, and ordinary source parameter
DWARF/GDB frames. It shall use only the existing Topal-owned runtime and no
C/C++ runtime, other-language standard library, or native ABI revision. This
realizes `TOPAL-COMPILER-RECURSION-EUCLIDEAN-001`.

## TOPAL-COMP-RECURSION-OVERLOAD-IDENTITY-001 — Overload-specific recursion identity

The checked compiler model shall use function name, staticness, and the complete
selected input classifier sequence as an active call-graph identity. A call
from one overload to a same-named overload with a different input header shall
be an ordinary acyclic edge and shall not consume or require the active
overload's recursion proof. A later edge returning to an active complete
identity shall remain subject to the applicable proof gate.

Every selected overload shall retain a distinct compiler-private symbol,
checked source signature, and DWARF subprogram even when its scalar LLVM
prototype uses the same carrier types. The acyclic callee shall precede its
caller in generated definitions and appear as a distinct nested GDB frame. No
runtime dispatch, type tag, foreign dependency, C/C++ runtime, other-language
standard library, or `topal-native/6` revision is permitted. This realizes
`TOPAL-COMPILER-RECURSION-OVERLOAD-IDENTITY-001` for increment 3b2-b5e5.

## TOPAL-COMP-RECURSION-INT-MUTUAL-001 — Proven mutual Int recursion

The checked compiler model shall reuse the shared decreasing and increasing
mutual `Int` edge proofs. Before admitting a return to an active overload, it
shall verify an active slice of at least two members in which every proof rule
is identical, every next-member name matches the following active identity,
and the last member targets the first. Isolated candidates, mixed directions,
zero or otherwise invalid steps, and incomplete cycles shall remain
`E-COMPILER-UNSUPPORTED`. Multiple next-member calls shall be checked and
instantiated independently.

Every member shall use its reserved exact private `fastcc` prototype. Generated
definitions shall retain `noinline`, omit the false `norecurse` attribute, and
require no tail-call optimization for O0 correctness. Distinct source members,
parameters, and nested frames shall remain available through DWARF/GDB. The
cycle proof shall be erased before lowering and add no dispatch table, hidden
state, C/C++ runtime, other-language standard library, or `topal-native/6`
revision. This realizes `TOPAL-COMPILER-RECURSION-INT-MUTUAL-001` for increment
3b2-b5e6.

## TOPAL-COMP-RECURSION-NAT-MUTUAL-001 — Proven mutual Nat recursion

The checked compiler model shall reuse the shared decreasing and increasing
mutual `Nat` edge proofs and the complete active-cycle check. All active members
shall have the same direction-specific rule, each next-member name shall match
the following selected overload, and the final target shall close a cycle of at
least two members. Every decreasing edge shall satisfy its own nonnegative bound
and literal-step limit. Unsafe overshoot, mixed directions, invalid steps, and
incomplete cycles shall remain `E-COMPILER-UNSUPPORTED`.

The current active member may restore `Nat` evidence only on the unary argument
to the next member named by its proof. The checked `IntToNat` boundary shall emit
no call to `topal.runtime.int.try.to.nat`; unrelated arithmetic receives no such
authority. Every member shall use its reserved exact private `fastcc` prototype,
retain `noinline`, omit `norecurse`, and expose distinct Nat parameters and
recursive frames through DWARF/GDB. No unsigned carrier, dispatcher, hidden
state, C/C++ runtime, other-language standard library, or `topal-native/6`
revision is permitted. This realizes
`TOPAL-COMPILER-RECURSION-NAT-MUTUAL-001` for increment 3b2-b5e7.

## TOPAL-COMP-RETURN-001 — Direct explicit function return

Within an admitted linear function body, `return expression` shall evaluate and
validate the expression once, preserve every preceding statement in order, and
complete the current invocation without emitting the unreachable tail. It shall
use the same private result representation and DWARF source mapping as an
implicit final result. A return at root shall remain a source diagnostic.

This requirement covers the direct-body case of
`TOPAL-FUNCTION-RETURN-001` and realizes `TOPAL-COMPILER-RETURN-001` for
compiler increment 3b2-a. Indirect, conditional, or cleanup-bearing returns
from nested lexical blocks remain in increment 3b2-b5e8.

## TOPAL-COMP-LEXICAL-RETURN-001 — Cleanup-free lexical return

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from an unconditional lexical block used directly as a
statement, discard initializer, binding initializer, or final expression. It
shall preserve preceding outer and inner evaluation exactly once, validate the
returned expression against the function result classifier rather than an
abandoned binding classifier, and omit both lexical and enclosing unreachable
tails at O0. Except for the whole explicit-return operand admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPERAND-001` and the direct symbolic operand admitted
by `TOPAL-COMP-LEXICAL-RETURN-OPERATOR-001`, and the direct product field
admitted by `TOPAL-COMP-LEXICAL-RETURN-PRODUCT-001`, and the direct named-call
argument admitted by `TOPAL-COMP-LEXICAL-RETURN-CALL-001`, the direct `Some`
payload admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-001`, and the strict unary constructor
payload admitted by `TOPAL-COMP-LEXICAL-RETURN-CONSTRUCTOR-001`, and the
positional Variant payload admitted by
`TOPAL-COMP-LEXICAL-RETURN-VARIANT-001`, and the direct `Character` operand
admitted by `TOPAL-COMP-LEXICAL-RETURN-CHARACTER-001`, and the direct named
constraint operand admitted by `TOPAL-COMP-LEXICAL-RETURN-CONSTRAINT-001`, and
the direct named modular operand admitted by
`TOPAL-COMP-LEXICAL-RETURN-MODULAR-001`, and the direct modular-reduction operand
admitted by `TOPAL-COMP-LEXICAL-RETURN-MODULAR-REDUCE-001`, and the direct unary
List collection source admitted by `TOPAL-COMP-LEXICAL-RETURN-COLLECT-001`, and
the direct unordered collection sources admitted by
`TOPAL-COMP-LEXICAL-RETURN-UNORDERED-COLLECT-001`, and the direct Map collection
source admitted by `TOPAL-COMP-LEXICAL-RETURN-MAP-COLLECT-001`, and the direct
infix Array or String collection sources admitted by
`TOPAL-COMP-LEXICAL-RETURN-INFIX-COLLECT-001`, and the direct complete
Boolean-decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-DECISION-SUBJECT-001`, and the exhaustive
Boolean-decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-EXHAUSTIVE-BOOLEAN-SUBJECT-001`, the ordered
comparison-decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-DECISION-SUBJECT-001`, and the
fallback-complete decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-FALLBACK-DECISION-SUBJECT-001`, and any other
parser-complete decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-COMPLETE-DECISION-SUBJECT-001`, and complete Boolean
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`, and complete
Comparison-value decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`, and complete
ordered comparison decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`, and
final-fallback declared-Enum decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and exhaustive
declared-Enum decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, a return-bearing
block nested in another expression, any other decision action, callback, or
other compound expression shall remain rejected.

The compiler shall retain the block expression and its nested DWARF lexical
scope, then lower its returned value through the enclosing function's existing
private result and single machine return. Every exited scope must be proven to
have no generator-close, resource, destructor, or other cleanup obligation;
otherwise compilation shall fail closed. The implementation shall add no
unwind edge, runtime control-flow value, allocation, foreign dependency,
C/C++ runtime, other-language standard library, public ABI, or `topal-native/6`
revision. Tests shall use one unchanged interpreter/compiler source, verify
skipped tails, direct LLVM/DWARF/GDB behavior and rejection boundaries, and
record separate interpreter, compiler-build, and native-run baselines. This
realizes `TOPAL-FUNCTION-RETURN-001` and
`TOPAL-COMPILER-LEXICAL-RETURN-001` for increment 3b2-b5e8a.

## TOPAL-COMP-LEXICAL-RETURN-OPERAND-001 — Return-expression lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
inner explicit return from a cleanup-free lexical block used as the whole
operand of an outer explicit return. It shall evaluate and validate the inner
returned value once, omit both unreachable tails at O0, and expose one semantic
explicit-return decision rather than completing the outer return a second
time. A block that completes normally remains the ordinary outer return value.

The compiler shall retain the lexical expression and nested DWARF scope while
lowering the inner value through the function's existing private result and
single machine return. Except for the direct symbolic operator operand admitted
by `TOPAL-COMP-LEXICAL-RETURN-OPERATOR-001` and the direct product field
admitted by `TOPAL-COMP-LEXICAL-RETURN-PRODUCT-001`, and the direct named-call
argument admitted by `TOPAL-COMP-LEXICAL-RETURN-CALL-001`, the direct `Some`
payload admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-001`, and the strict unary constructor
payload admitted by `TOPAL-COMP-LEXICAL-RETURN-CONSTRUCTOR-001`, and the
positional Variant payload admitted by
`TOPAL-COMP-LEXICAL-RETURN-VARIANT-001`, and the direct `Character` operand
admitted by `TOPAL-COMP-LEXICAL-RETURN-CHARACTER-001`, and the direct named
constraint operand admitted by `TOPAL-COMP-LEXICAL-RETURN-CONSTRAINT-001`, and
the direct named modular operand admitted by
`TOPAL-COMP-LEXICAL-RETURN-MODULAR-001`, and the direct modular-reduction operand
admitted by `TOPAL-COMP-LEXICAL-RETURN-MODULAR-REDUCE-001`, and the direct unary
List collection source admitted by `TOPAL-COMP-LEXICAL-RETURN-COLLECT-001`, and
the direct unordered collection sources admitted by
`TOPAL-COMP-LEXICAL-RETURN-UNORDERED-COLLECT-001`, and the direct Map collection
source admitted by `TOPAL-COMP-LEXICAL-RETURN-MAP-COLLECT-001`, and the
direct infix Array or String collection sources admitted by
`TOPAL-COMP-LEXICAL-RETURN-INFIX-COLLECT-001`, and the direct complete
Boolean-decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-DECISION-SUBJECT-001`, and the exhaustive
Boolean-decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-EXHAUSTIVE-BOOLEAN-SUBJECT-001`, the ordered
comparison-decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-DECISION-SUBJECT-001`, and the
fallback-complete decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-FALLBACK-DECISION-SUBJECT-001`, and any other
parser-complete decision subject admitted by
`TOPAL-COMP-LEXICAL-RETURN-COMPLETE-DECISION-SUBJECT-001`, and complete Boolean
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`, and complete
Comparison-value decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`, and complete
ordered comparison decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`, and
final-fallback declared-Enum decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and exhaustive
declared-Enum decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, the implementation
shall admit no other embedded, decision-action, callback, generator, or
cleanup-bearing exit. It shall add no runtime control-flow value,
unwind edge, allocation, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share the
interpreter/compiler source, assert exactly one semantic return and skipped
tails, inspect LLVM/DWARF/GDB behavior, and record separate interpreter,
compiler-build, and native-run baselines. This realizes
`TOPAL-FUNCTION-RETURN-001` and
`TOPAL-COMPILER-LEXICAL-RETURN-OPERAND-001` for increment 3b2-b5e8b.

## TOPAL-COMP-LEXICAL-RETURN-OPERATOR-001 — Symbolic-operand lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as a direct left or
right operand of a symbolic operator. A left exit shall omit the operator and
right operand. A right exit shall retain the complete left application prefix
exactly once in source order, abandon its value, and omit the operator. Both
forms shall validate the returned value against the function result classifier
and omit the lexical and function tails at O0.

The compiler shall represent an evaluated left prefix and returned lexical
block as a private exit sequence, emit the prefix in its enclosing debug scope,
retain the block's nested DWARF scope, and use the existing private result and
single machine return. Constructors other than the direct `Some` payload
covered by `TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-001` and the strict unary
constructors covered by `TOPAL-COMP-LEXICAL-RETURN-CONSTRUCTOR-001`, packaged or
nested call arguments, overloaded or indirect calls, decisions, callbacks,
generators, and scopes with cleanup obligations shall remain fail-closed.
The implementation shall add no runtime control-flow value, unwind edge,
allocation, foreign dependency, C/C++ runtime, other-language standard
library, public ABI, or `topal-native/6` revision. Tests shall share the
interpreter/compiler source, verify both operand positions and once-only left
evaluation, omitted operators and tails, LLVM/DWARF/GDB behavior, and separate
resource baselines. This realizes `TOPAL-FUNCTION-RETURN-001` and
`TOPAL-COMPILER-LEXICAL-RETURN-OPERATOR-001` for increment 3b2-b5e8c.

## TOPAL-COMP-LEXICAL-RETURN-PRODUCT-001 — Product-field lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as a direct positional
or labeled product field. It shall evaluate every preceding field exactly once
in source order, abandon those values, and omit product construction, later
fields, the lexical tail, and the function tail at O0. It shall validate the
returned value against the function result classifier rather than the product
or an abandoned binding classifier.

The compiler shall represent the evaluated field prefix and returned lexical
block as a private exit sequence, emit prefix expressions in their enclosing
debug scope, retain the block's nested DWARF scope, and use the existing private
result and single machine return. Only products at an otherwise admitted direct
statement or initializer boundary are covered. Products nested in constructors
or call arguments, decisions, callbacks, generators, and cleanup-bearing scopes
shall remain fail-closed. The implementation shall add no runtime control-flow
value, unwind edge, aggregate allocation, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source, cover positional and labeled
fields, verify once-only prefix evaluation and omitted construction/tails,
inspect LLVM/DWARF/GDB behavior, and record separate resource baselines. This
realizes `TOPAL-FUNCTION-RETURN-001` and
`TOPAL-COMPILER-LEXICAL-RETURN-PRODUCT-001` for increment 3b2-b5e8d.

## TOPAL-COMP-LEXICAL-RETURN-CALL-001 — Named-call argument lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as a direct argument of
an unshadowed named function with exactly one flat declaration. It shall cover
the sole argument of a unary prefix call and either direct argument of a binary
infix call. A left or sole-argument exit shall precede every other argument. A
right exit shall evaluate the complete left application prefix exactly once,
abandon that value, and omit callee selection, invocation, later arguments, and
the enclosing function tail at O0.

The compiler shall validate the returned value against the enclosing function
result classifier, represent an evaluated prefix in the private exit sequence,
retain the block's nested DWARF scope, and use the existing private result and
single machine return. Overloaded, bound, nested, qualified, packaged,
defaulted, or constructor calls; products nested in arguments; decisions;
callbacks; generators; and cleanup-bearing scopes shall remain fail-closed.
The implementation shall add no runtime control-flow value, indirect call,
unwind edge, allocation, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share
the interpreter/compiler source, cover unary, left, and right arguments, verify
once-only prefix evaluation and omitted invocation/tails, inspect
LLVM/DWARF/GDB behavior, and record separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001` and
`TOPAL-COMPILER-LEXICAL-RETURN-CALL-001` for increment 3b2-b5e8e.

## TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-001 — Optional-constructor payload lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct payload of
the built-in unary `Some` constructor. It shall complete the enclosing function
before payload classification, omit Optional construction and the lexical and
function tails at O0, and validate the returned value against the enclosing
function result classifier rather than the Optional payload or abandoned
binding classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Except for the strict unary constructors covered by
`TOPAL-COMP-LEXICAL-RETURN-CONSTRUCTOR-001`, other constructors, products or
other expressions nested in the payload position, decisions, callbacks,
generators, and cleanup-bearing scopes shall remain fail-closed. The
implementation shall add no runtime control-flow value, Optional allocation,
indirect call, unwind edge, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share
the interpreter/compiler source, verify omitted
payload classification, Optional construction, binding, and tails, inspect
LLVM/DWARF/GDB behavior, and record separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001` and
`TOPAL-COMPILER-LEXICAL-RETURN-OPTIONAL-001` for increment 3b2-b5e8f.

## TOPAL-COMP-LEXICAL-RETURN-CONSTRUCTOR-001 — Strict unary-constructor payload lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct operand of
the built-in unary `String`, `Int`, `Nat`, or `Rational` constructor or as the
direct payload of an already-declared payload-bearing Union alternative. It
shall complete the enclosing function before conversion, payload
classification, or constructor selection; omit constructed values, nominal
Union tags, abandoned bindings, and lexical and function tails at O0; and
validate the returned value against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Except for the positional Variant form covered by
`TOPAL-COMP-LEXICAL-RETURN-VARIANT-001` and the direct `Character` form covered
by `TOPAL-COMP-LEXICAL-RETURN-CHARACTER-001`, and the direct named Int-constraint
form covered by `TOPAL-COMP-LEXICAL-RETURN-CONSTRAINT-001`, and the direct named
modular form covered by `TOPAL-COMP-LEXICAL-RETURN-MODULAR-001`, and the direct
modular-reduction operand covered by
`TOPAL-COMP-LEXICAL-RETURN-MODULAR-REDUCE-001`, and the direct unary List
collection source covered by `TOPAL-COMP-LEXICAL-RETURN-COLLECT-001`, and the
direct unordered collection sources covered by
`TOPAL-COMP-LEXICAL-RETURN-UNORDERED-COLLECT-001`, and the direct Map collection
source covered by `TOPAL-COMP-LEXICAL-RETURN-MAP-COLLECT-001`, and the direct
infix Array or String collection sources covered by
`TOPAL-COMP-LEXICAL-RETURN-INFIX-COLLECT-001`, and the direct complete
Boolean-decision subject covered by
`TOPAL-COMP-LEXICAL-RETURN-DECISION-SUBJECT-001`, and the exhaustive
Boolean-decision subject covered by
`TOPAL-COMP-LEXICAL-RETURN-EXHAUSTIVE-BOOLEAN-SUBJECT-001`, the ordered
comparison-decision subject covered by
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-DECISION-SUBJECT-001`, and the
fallback-complete decision subject covered by
`TOPAL-COMP-LEXICAL-RETURN-FALLBACK-DECISION-SUBJECT-001`, and any other
parser-complete decision subject covered by
`TOPAL-COMP-LEXICAL-RETURN-COMPLETE-DECISION-SUBJECT-001`, and complete Boolean
decisions whose every action returns as covered by
`TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`, and complete
Comparison-value decisions whose every action returns as covered by
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`, and complete
ordered comparison decisions whose every action returns as covered by
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`, and
final-fallback declared-Enum decisions whose every action returns as covered by
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and exhaustive
declared-Enum decisions whose every action returns as covered by
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, other
constraint, modular, or collection forms, qualified and other constructor
forms; products or other expressions nested in the operand; other decision
forms; callbacks; generators; and cleanup-bearing scopes shall remain
fail-closed. The
implementation shall add no runtime control-flow value, constructor-specific
allocation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source, cover every admitted
constructor family, verify omitted conversion/construction/binding/tails,
inspect LLVM/DWARF/GDB behavior, and record separate resource baselines. This
realizes
`TOPAL-FUNCTION-RETURN-001` and
`TOPAL-COMPILER-LEXICAL-RETURN-CONSTRUCTOR-001` for increment 3b2-b5e8g.

## TOPAL-COMP-LEXICAL-RETURN-VARIANT-001 — Positional Variant payload lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct payload of
an already-declared positional Variant constructor `Type at index payload` only
when the index names an existing alternative. It shall validate the declared
Variant identity and index first, then complete the enclosing function before
payload classification or construction; omit the Variant tag, payload
aggregate, abandoned binding, and lexical and function tails at O0; and
validate the returned value against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Invalid, undeclared, qualified, nested-payload, decision,
callback, generator, and cleanup-bearing forms shall remain fail-closed under
their existing diagnostics. The implementation shall add no runtime
control-flow value, Variant-specific allocation, indirect call, unwind edge,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Tests shall share the interpreter/compiler source,
verify valid construction identity and index, omitted construction/binding/tails,
invalid-index rejection, LLVM/DWARF/GDB behavior, and separate resource
baselines. This realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-TYPE-VARIANT-001`,
and `TOPAL-COMPILER-LEXICAL-RETURN-VARIANT-001` for increment 3b2-b5e8h.

## TOPAL-COMP-LEXICAL-RETURN-CHARACTER-001 — Character-constraint operand lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct operand of
the built-in `Character` constructor. It shall select the built-in constructor
identity first, then complete the enclosing function before pinned-Unicode
Character constraint validation; omit Character evidence, an abandoned
binding, and lexical and function tails at O0; and validate the returned value
against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Qualified, nested-operand, decision, callback, generator, and
cleanup-bearing forms shall remain fail-closed under their existing diagnostics.
The implementation shall add no runtime control-flow value,
Character-validation routine, allocation, indirect call, unwind edge, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Tests shall share the interpreter/compiler source,
verify omitted validation/evidence/binding/tails, nested-operand rejection,
LLVM/DWARF/GDB behavior, and separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-STRING-CHARACTER-CLASSIFIER-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-CHARACTER-001` for increment 3b2-b5e8i.

## TOPAL-COMP-LEXICAL-RETURN-CONSTRAINT-001 — Named-constraint operand lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct operand of
an already-declared named Int constraint. It shall validate constraint identity,
Int base, and binding declaration order first, then complete the enclosing
function before predicate evaluation or refined evidence construction; omit the
predicate branch, refined evidence, abandoned binding, and lexical and function
tails at O0; and validate the returned value against the enclosing function
result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Forward, unknown, non-Int, dynamically selected, qualified,
nested-operand, decision, callback, generator, and cleanup-bearing forms shall
remain fail-closed under their existing diagnostics. The implementation shall
add no runtime control-flow value, constraint validation, allocation, indirect
call, unwind edge, foreign dependency, C/C++ runtime, other-language standard
library, public ABI, or `topal-native/6` revision. Tests shall share the
interpreter/compiler source, verify identity/base/order guards, omitted
predicate/evidence/binding/tails, rejection boundaries, LLVM/DWARF/GDB behavior,
and separate resource baselines. This realizes `TOPAL-FUNCTION-RETURN-001`,
`TOPAL-TYPE-CONSTRAINT-VALIDATE-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-CONSTRAINT-001` for increment 3b2-b5e8j.

## TOPAL-COMP-LEXICAL-RETURN-MODULAR-001 — Named-modular operand lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct operand of
an already-declared named `ModNat` or `ModInt` type. It shall validate modular
identity and declaration order first, then complete the enclosing function
before Int classification, range validation, dynamic Result creation, or
nominal-value construction; omit comparisons, Result and nominal construction,
the abandoned binding, and lexical and function tails at O0; and validate the
returned value against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Forward, unknown, dynamically selected, qualified,
explicit-reduction forms outside
`TOPAL-COMP-LEXICAL-RETURN-MODULAR-REDUCE-001`, nested-operand, decision,
callback, generator, and cleanup-bearing forms shall remain fail-closed under
their existing diagnostics.
The implementation shall add no runtime control-flow value, modular validation
or reduction, allocation, indirect call, unwind edge, foreign dependency,
C/C++ runtime, other-language standard library, public ABI, or `topal-native/6`
revision. Tests shall share the interpreter/compiler source, verify
identity/order guards, omitted validation/construction/binding/tails, rejection
boundaries, LLVM/DWARF/GDB behavior, and separate resource baselines. This
realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-NUM-MODULAR-CONSTRUCT-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-MODULAR-001` for increment 3b2-b5e8k.

## TOPAL-COMP-LEXICAL-RETURN-MODULAR-REDUCE-001 — Modular-reduction operand lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct left
operand of `operand modulo Name` when `Name` is an already-declared named
`ModNat` or `ModInt` type. It shall validate exact target identity and
declaration order first, then complete the enclosing function before Int
classification or modular reduction; omit the subtract/modulo/add reduction
chain, nominal construction, abandoned binding, and lexical and function tails
at O0; and validate the returned value against the enclosing function result
classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Forward, unknown, dynamically selected, qualified,
nested-operand, decision, callback, generator, and cleanup-bearing forms shall
remain fail-closed under their existing diagnostics. The implementation shall
add no runtime control-flow value, modular validation or reduction, allocation,
indirect call, unwind edge, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share
the interpreter/compiler source, verify target/order guards, omitted reduction,
construction, binding, and tails, rejection boundaries, LLVM/DWARF/GDB
behavior, and separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-NUM-MODULAR-REDUCE-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-MODULAR-REDUCE-001` for increment 3b2-b5e8l.

## TOPAL-COMP-LEXICAL-RETURN-COLLECT-001 — Unary List-collection source lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct source of
the built-in unary `collect source` operation. It shall select the exact
built-in operation first, then complete the enclosing function before
finite-traversal classification, generator consumption, or List materialization;
omit List nodes, consumption actions, the abandoned binding, and lexical and
function tails at O0; and validate the returned value against the enclosing
function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Except for `collect-set` and `collect-bag` covered by
`TOPAL-COMP-LEXICAL-RETURN-UNORDERED-COLLECT-001`, infix Array or String
collection covered by `TOPAL-COMP-LEXICAL-RETURN-INFIX-COLLECT-001`, and the
`collect-map` form covered by
`TOPAL-COMP-LEXICAL-RETURN-MAP-COLLECT-001`, qualified, nested-source, decision,
callback, generator-cleanup, and other cleanup-bearing forms shall remain
fail-closed under their existing diagnostics. The implementation shall add no
runtime control-flow value, collection materialization, allocation, indirect
call, unwind edge, foreign dependency, C/C++ runtime, other-language standard
library, public ABI, or `topal-native/6` revision. Tests shall share the
interpreter/compiler source, verify exact operation selection, omitted
classification/materialization/binding/tails, rejection boundaries,
LLVM/DWARF/GDB behavior, and separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`,
`TOPAL-COLLECTION-COLLECT-LIST-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-COLLECT-001` for increment 3b2-b5e8m.

## TOPAL-COMP-LEXICAL-RETURN-UNORDERED-COLLECT-001 — Unordered-collection source lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct source of
the exact built-in `collect-set source` or `collect-bag source` operation. It
shall select the exact built-in operation first, then complete the enclosing
function before finite-List classification, equality-dependent duplicate
coalescing, multiplicity accumulation, or Set or Bag materialization; omit
unordered collection nodes, comparisons, consumption actions, the abandoned
binding, and lexical and function tails at O0; and validate the returned value
against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Except for `collect-map` covered by
`TOPAL-COMP-LEXICAL-RETURN-MAP-COLLECT-001` and infix Array or String collection
covered by `TOPAL-COMP-LEXICAL-RETURN-INFIX-COLLECT-001`, qualified,
nested-source, decision, callback, cleanup-bearing, and other collection forms
shall remain fail-closed under their existing diagnostics. The implementation
shall add no runtime control-flow value, collection materialization, comparison,
allocation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source, verify exact operation
selection, omitted
classification/coalescing/multiplicity/materialization/binding/tails, rejection
boundaries, LLVM/DWARF/GDB behavior, and separate resource baselines. This
realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-SET-COLLECT-001`,
`TOPAL-BAG-COLLECT-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-UNORDERED-COLLECT-001` for increment 3b2-b5e8n.

## TOPAL-COMP-LEXICAL-RETURN-MAP-COLLECT-001 — Map-collection source lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct source of
the exact built-in `collect-map source resolving policy` operation when
`policy` is `reject`, `keep-first`, or `keep-last`. It shall select the exact
operation, `resolving` clause, and valid collision policy first, then complete
the enclosing function before pair classification, key equality, collision
resolution, or Map materialization; omit Map nodes, comparisons, collision
actions, the abandoned binding, and lexical and function tails at O0; and
validate the returned value against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Except for infix Array or String collection covered by
`TOPAL-COMP-LEXICAL-RETURN-INFIX-COLLECT-001`, invalid policies, qualified,
nested-source, decision, callback, cleanup-bearing, and other collection forms
shall remain fail-closed under their existing diagnostics. The implementation
shall add no runtime control-flow value, collection materialization, comparison,
allocation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source, verify
operation/clause/policy selection, omitted classification/equality/collision/
materialization/binding/tails, rejection boundaries, LLVM/DWARF/GDB behavior,
and separate resource baselines.
This realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-MAP-COLLECT-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-MAP-COLLECT-001` for increment 3b2-b5e8o.

## TOPAL-COMP-LEXICAL-RETURN-INFIX-COLLECT-001 — Infix collection-source lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct left
source of the exact built-in `source collect Array` or `source collect String`
operation. It shall select the exact operation and target first, then complete
the enclosing function before finite-List classification, Array extent
derivation, String-entry validation, or target materialization; omit Array or
String collection results, consumption actions, the abandoned binding, and
lexical and function tails at O0; and validate the returned value against the
enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Unknown or qualified targets, nested-source, decision,
callback, cleanup-bearing, and other collection forms shall remain fail-closed
under their existing diagnostics. The implementation shall add no runtime
control-flow value, collection materialization, allocation, indirect call,
unwind edge, foreign dependency, C/C++ runtime, other-language standard
library, public ABI, or `topal-native/6` revision. Tests shall share the
interpreter/compiler source, verify operation/target selection, omitted
classification/extent-or-entry-validation/materialization/binding/tails,
rejection boundaries, LLVM/DWARF/GDB behavior, and separate resource baselines.
This realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-ARRAY-COLLECT-001`,
`TOPAL-COLLECTION-COLLECT-STRING-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-INFIX-COLLECT-001` for increment 3b2-b5e8p.

## TOPAL-COMP-LEXICAL-RETURN-DECISION-SUBJECT-001 — Boolean-decision subject lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct subject of
a complete Boolean decision consisting of one Boolean-literal rule followed by
an `otherwise` rule. It shall recognize that exact decision shape first, then
complete the enclosing function before Boolean classification, matcher
consideration, action selection, or action evaluation; omit decision branches,
actions, the abandoned decision value, and lexical and function tails at O0;
and validate the returned value against the enclosing function result
classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Other matcher sets, nested subjects, decision-action returns
outside `TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, callbacks,
cleanup-bearing, and other decision forms shall remain fail-closed under their
existing diagnostics. The implementation shall add no runtime
control-flow value, decision branch, allocation, indirect call, unwind edge,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Tests shall share the interpreter/compiler source,
verify exact decision-shape selection, omitted classification/matching/action/
tail work, rejection boundaries, LLVM/DWARF/GDB behavior, and separate resource
baselines. This realizes `TOPAL-FUNCTION-RETURN-001`,
`TOPAL-DECISION-BOOLEAN-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-DECISION-SUBJECT-001` for increment 3b2-b5e8q.

## TOPAL-COMP-LEXICAL-RETURN-EXHAUSTIVE-BOOLEAN-SUBJECT-001 — Exhaustive Boolean-decision subject lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct subject of
a complete Boolean decision consisting of exactly one `false` rule and one
`true` rule, in either source order and without `otherwise`. It shall recognize
that exact two-rule matcher set first, then complete the enclosing function
before Boolean classification, matcher consideration, action selection, or
action evaluation; omit decision branches, actions, the abandoned decision
value, and lexical and function tails at O0; and validate the returned value
against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Duplicate or additional rules, other matcher sets, nested
subjects, decision-action returns outside
`TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, callbacks,
cleanup-bearing, and other decision forms shall remain fail-closed under their
existing diagnostics. The
implementation shall add no runtime control-flow value, decision branch,
allocation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source, verify exact matcher-set
selection in both source orders, omitted classification/matching/action/tail
work, rejection boundaries, LLVM/DWARF/GDB behavior, and separate resource
baselines. This realizes `TOPAL-FUNCTION-RETURN-001`,
`TOPAL-DECISION-BOOLEAN-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-EXHAUSTIVE-BOOLEAN-SUBJECT-001` for increment
3b2-b5e8r.

## TOPAL-COMP-LEXICAL-RETURN-COMPARISON-DECISION-SUBJECT-001 — Comparison-decision subject lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct subject of
a complete ordered comparison decision consisting of one or more comparison
rules followed by a final `otherwise` rule. It shall recognize that exact
matcher sequence first, then complete the enclosing function before
exact-number classification, matcher-operand evaluation, comparison, action
selection, or action evaluation; omit comparison operations, decision branches,
actions, the abandoned decision value, and lexical and function tails at O0;
and validate the returned value against the enclosing function result
classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Empty comparison prefixes, mixed or additional matcher kinds,
a nonfinal or missing `otherwise`, nested subjects, decision-action returns
outside `TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, callbacks,
cleanup-bearing, and other decision forms shall remain fail-closed under their
existing diagnostics. The implementation shall add no runtime
control-flow value, comparison operation, decision branch, allocation,
indirect call, unwind edge, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share
the interpreter/compiler source, verify single and multiple comparison rules,
omitted subject/matcher/action/tail work, rejection boundaries,
LLVM/DWARF/GDB behavior, and separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-COMPARISON-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-COMPARISON-DECISION-SUBJECT-001` for increment
3b2-b5e8s.

## TOPAL-COMP-LEXICAL-RETURN-FALLBACK-DECISION-SUBJECT-001 — Fallback-complete decision subject lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct subject of
any parser-accepted decision whose final rule is `otherwise`. It shall
recognize the final fallback first, then complete the enclosing function before
subject classification, matcher compatibility checking, matcher-operand
evaluation, pattern binding, comparison, action selection, or action
evaluation; omit matcher work, bindings, decision branches, actions, the
abandoned decision value, and lexical and function tails at O0; and validate
the returned value against the enclosing function result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Decision forms without a final fallback except for separately
admitted exhaustive forms, nested subjects, decision-action returns outside
`TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, callbacks,
cleanup-bearing, and other conditional forms shall remain fail-closed under
their existing diagnostics. The implementation shall add no runtime
control-flow value, matcher operation, pattern binding, decision branch,
allocation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source, exercise an otherwise-only
table and heterogeneous Optional/Result/List matcher prefixes, verify omitted
subject/matcher/binding/action/tail work, rejection boundaries,
LLVM/DWARF/GDB behavior, and separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-OPTIONAL-001`,
`TOPAL-DECISION-RESULT-001`, `TOPAL-DECISION-LIST-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-FALLBACK-DECISION-SUBJECT-001` for increment
3b2-b5e8t.

## TOPAL-COMP-LEXICAL-RETURN-COMPLETE-DECISION-SUBJECT-001 — Parser-complete decision subject lexical exit

Inside an admitted ordinary function, the checked model shall propagate an
explicit return from a cleanup-free lexical block used as the direct subject of
any decision table already accepted as complete by the syntax rules. It shall
use construction of the complete decision-table syntax node as prior evidence,
then complete the enclosing function before subject classification,
type-specific exhaustiveness or matcher validation, matcher-operand evaluation,
pattern binding, comparison, action selection, or action evaluation; omit all
matcher, binding, branch, action, abandoned-value, and lexical and function
tail work at O0; and validate the returned value against the enclosing function
result classifier.

The compiler shall retain the returned lexical block as the existing private
function result, preserve its nested DWARF scope, and use the existing single
machine return. Syntactically incomplete decisions, nested subjects,
decision-action returns outside
`TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, callbacks,
cleanup-bearing, and other conditional forms shall remain fail-closed under
their existing diagnostics. The
implementation shall add no runtime control-flow value, matcher or
exhaustiveness operation, pattern binding, decision branch, allocation,
indirect call, unwind edge, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share
the interpreter/compiler source, exercise complete no-fallback Optional,
Result, List, and identifier matcher shapes, verify omitted
subject/matcher/binding/action/tail work, rejection boundaries,
LLVM/DWARF/GDB behavior, and separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-OPTIONAL-001`,
`TOPAL-DECISION-RESULT-001`, `TOPAL-DECISION-LIST-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-COMPLETE-DECISION-SUBJECT-001` for increment
3b2-b5e8u.

## TOPAL-COMP-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001 — Complete Boolean action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from the selected action of a complete
Boolean decision when every action is a direct cleanup-free returning lexical
block. They shall evaluate the Boolean subject once, consider matchers in source
order, evaluate only the selected action, validate its returned value against
the enclosing function result classifier, and omit the selected block tail and
following function tail at O0.

The compiler shall retain the Boolean decision as the function result, retain
each returning lexical block as its branch value, preserve each nested DWARF
scope, emit the ordinary Boolean branch and typed SSA join, and use the existing
single machine return. Decisions with any normally completing action,
non-Boolean decisions outside
`TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, nested action
expressions, callbacks, generators, and cleanup-bearing actions shall remain
fail-closed. The implementation shall add no runtime control-flow value,
allocation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source,
exercise both Boolean alternatives and a final-fallback form, verify exact
selection and skipped tails, retain mixed-path rejection, inspect the LLVM
branch/phi/single-return shape and DWARF/GDB behavior, and record separate
resource baselines. This realizes `TOPAL-FUNCTION-RETURN-001`,
`TOPAL-DECISION-BOOLEAN-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-BOOLEAN-DECISION-ACTIONS-001` for increment
3b2-b5e8v.

## TOPAL-COMP-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001 — Complete Comparison action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from the selected action of a complete
decision over the closed `Comparison` value when every action is a direct
cleanup-free returning lexical block. They shall evaluate the subject once,
consider `Less`, `Equal`, `Greater`, and final-fallback matchers in source order,
evaluate only the selected action, validate its returned value against the
enclosing function result classifier, and omit the selected block tail and
following function tail at O0.

The compiler shall retain the Comparison-value decision as the function result,
retain each returning lexical block as its branch value, preserve each nested
DWARF scope, emit the ordinary three-way switch and typed SSA join, and use the
existing single machine return. Decisions with any normally completing action,
other decision classifiers outside
`TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001`,
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, nested action
expressions, callbacks, generators, and cleanup-bearing actions shall remain
fail-closed. The implementation shall add no runtime control-flow value,
allocation, indirect call, unwind edge,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Tests shall share the interpreter/compiler source,
exercise all three Comparison alternatives and a final-fallback form, verify
exact selection and skipped tails, retain mixed-path rejection, inspect the LLVM
switch/phi/single-return shape and DWARF/GDB behavior, and record separate
resource baselines. This realizes `TOPAL-FUNCTION-RETURN-001`,
`TOPAL-DECISION-ENUM-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-COMPARISON-VALUE-DECISION-ACTIONS-001` for
increment 3b2-b5e8w.

## TOPAL-COMP-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001 — Ordered comparison action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from the selected action of an ordered
comparison decision with a nonempty comparison-rule prefix and final
`otherwise` when every action is a direct cleanup-free returning lexical block.
They shall evaluate the exact numeric subject once, evaluate matcher operands
and consider rules in source order until selection, evaluate only the selected
action, validate its returned value against the enclosing function result
classifier, and omit the selected block tail and following function tail at O0.

The compiler shall retain the ordered comparison decision as the function
result, retain each returning lexical block as its branch value, preserve each
nested DWARF scope, emit the ordinary ordered comparison and branch chain with a
typed SSA join, and use the existing single machine return. Decisions with any
normally completing action, an empty comparison prefix, a nonfinal or missing
fallback, a nonnumeric subject, other decision classifiers outside
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001` and
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, nested action
expressions, callbacks, generators, and cleanup-bearing actions shall remain
fail-closed. The
implementation shall add no runtime control-flow value,
allocation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share the interpreter/compiler source, exercise multiple comparison
rules and the final fallback, verify source-order matching and skipped tails,
retain mixed-path rejection, inspect the LLVM comparison-chain/phi/single-return
shape and DWARF/GDB behavior, and record separate resource baselines. This
realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-COMPARISON-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-ORDERED-COMPARISON-DECISION-ACTIONS-001` for
increment 3b2-b5e8x.

## TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001 — Final-fallback Enum action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from the selected action of a decision
over an already-declared non-Comparison Enum when the decision has a nonempty
prefix of distinct identifier matchers followed by final `otherwise` and every
action is a direct cleanup-free returning lexical block. They shall evaluate
the Enum subject once, consider alternatives in source order, evaluate only the
selected action, validate its returned value against the enclosing function
result classifier, and omit the selected block tail and following function tail
at O0.

The compiler shall retain the Enum decision as the function result, retain each
returning lexical block as its branch value, preserve each nested DWARF scope,
emit the ordinary tag switch and typed SSA join, and use the existing single
machine return. Duplicate or unknown alternatives, an empty prefix, a nonfinal
or missing fallback, an exhaustive no-fallback table outside
`TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001`, and
complete Optional decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001`, and
complete Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001`, and qualified
Error-code Result decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, and complete List
decisions whose every action returns as admitted by
`TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, other decision
classifiers, any normally completing action, nested action expressions,
callbacks, generators, and cleanup-bearing actions shall remain fail-closed.
The implementation shall add no runtime control-flow value, allocation,
indirect call, unwind edge, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share
the interpreter/compiler source, exercise explicit alternatives and fallback,
verify source-order selection and skipped tails, retain mixed-path and unknown
alternative rejection, inspect the LLVM switch/phi/single-return shape and
DWARF/GDB behavior, and record separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-ENUM-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001` for increment
3b2-b5e8y.

## TOPAL-COMP-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001 — Exhaustive Enum action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from the selected action of an
exhaustive decision over an already-declared non-Comparison Enum when every
action is a direct cleanup-free returning lexical block. The decision shall
contain a nonempty set of distinct identifier matchers equal to the Enum's
declared alternative set and no `otherwise`. They shall evaluate the Enum
subject once, consider alternatives in source order, evaluate only the selected
action, validate its returned value against the enclosing function result
classifier, and omit the selected block tail and following function tail at O0.

The compiler shall retain the exhaustive Enum decision as the function result,
retain each returning lexical block as its branch value, preserve each nested
DWARF scope, emit the ordinary tag switch and typed SSA join, and use the
existing single machine return. Missing, foreign, unknown, or duplicate
alternatives, fallback tables outside
`TOPAL-COMP-LEXICAL-RETURN-ENUM-FALLBACK-DECISION-ACTIONS-001`, other decision
classifiers, any normally completing action, nested action expressions,
callbacks, generators, and cleanup-bearing actions shall remain fail-closed.
The implementation shall add no runtime control-flow value, allocation,
indirect call, unwind edge, foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. Tests shall share
the interpreter/compiler source, exercise every declared alternative in
nondeclaration source order, verify once-only selection and skipped tails,
retain incomplete, unknown-alternative, mixed-path, and Comparison-spelling
boundaries, inspect the LLVM switch/phi/single-return shape and DWARF/GDB
behavior, and record separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-ENUM-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-ENUM-EXHAUSTIVE-DECISION-ACTIONS-001` for
increment 3b2-b5e8z.

## TOPAL-COMP-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001 — Complete Optional action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from the selected action of a complete
decision over `Optional T` when every action is a direct cleanup-free returning
lexical block. The admitted matcher shapes are distinct `Some name` and `None`
rules in either order, either explicit alternative followed by final
`otherwise`, and `otherwise` alone. Both execution paths shall evaluate the
subject once, consider rules in source order, bind the present payload only in
the selected explicit `Some name` action, evaluate only that action, validate
its returned value against the enclosing function result classifier, and omit
the selected block tail and following function tail at O0.

The compiler shall retain the Optional decision as the function result, retain
each returning lexical block as its branch value, preserve each nested DWARF
scope and the selected payload binding, emit the ordinary Optional tag query,
two-way branch, conditional payload extraction, and typed SSA join, and use the
existing single machine return. Duplicate or incomplete alternatives, mixed or
additional matcher kinds, nonfinal fallbacks, non-Optional subjects, any
normally completing action, a complete Result decision outside
`TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001` or
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, a complete List
decision outside `TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001`, or other decision
classifiers, nested action expressions, callbacks, generators, and
cleanup-bearing actions shall remain fail-closed. The implementation shall
add no runtime control-flow value, allocation, indirect call, unwind edge,
foreign dependency, C/C++ runtime, other-language standard library, public ABI,
or `topal-native/6` revision. Tests shall share the interpreter/compiler source,
exercise present payload binding, absent matching, both one-alternative fallback
shapes, source-order selection, skipped tails, mixed-path and non-Optional
rejection, exact LLVM branch/phi/single-return behavior, nested DWARF, GDB values
and frames, the complete compiler corpus, and separate resource baselines. This
realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-OPTIONAL-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-OPTIONAL-DECISION-ACTIONS-001` for increment
3b2-b5e8aa.

## TOPAL-COMP-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001 — Exhaustive Result action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from the selected action of an
exhaustive `Result (T, Codes)` decision when its exact `Ok value` and `Error
problem` actions are direct cleanup-free returning lexical blocks. Both source
orders shall be admitted. The interpreter and compiler shall evaluate the
subject once, consider rules in source order, bind the selected success value or
structured Error only inside its action, evaluate only that action, validate the
returned value against the enclosing function result classifier, and omit the
selected block tail and following function tail at O0.

The compiler shall retain the Result decision as the function result, retain
each returning lexical block as its branch value, preserve each nested DWARF
scope and both path-local payload bindings, emit the ordinary Result tag query,
two-way branch, payload extraction, and typed SSA join, and use the existing
single machine return. Qualified Error-code matcher tables outside
`TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001`, duplicate,
missing, mixed, or additional matchers, non-Result subjects, any normally
completing action, nested action expressions, callbacks, generators, and
cleanup-bearing actions shall remain fail-closed. The implementation shall add
no runtime control-flow value, allocation, indirect call, unwind edge, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Tests shall share the interpreter/compiler source,
exercise success and structured-Error bindings plus both matcher orders,
verify once-only source-order selection and skipped tails, retain mixed-path and non-Result
rejection, inspect exact LLVM branch/phi/single-return behavior and nested
DWARF/GDB values and frames, run the complete compiler corpus, and record
separate resource baselines. This realizes `TOPAL-FUNCTION-RETURN-001`,
`TOPAL-DECISION-RESULT-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-RESULT-DECISION-ACTIONS-001` for increment
3b2-b5e8ab.

## TOPAL-COMP-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001 — Qualified Error-code action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from every action of a complete
decision over `Result (T, lang arithmetic ArithmeticErrorCode)`. The table
shall contain exactly one `Ok value` rule and at least one distinct qualified
arithmetic Error-code rule, followed either by a whole-`Error problem` fallback
or, without a fallback, by exact coverage of all four closed arithmetic codes.
Every action shall be a direct cleanup-free returning lexical block.

The interpreter and compiler shall evaluate the subject once, preserve
source-order rule consideration, bind the success value or whole Error only in
a selected binding matcher, evaluate only the selected action, validate its
returned value against the enclosing function result classifier, and omit the
selected block tail and following function tail at O0. Qualified code actions
shall not bind the whole Error. The checked model shall retain ordered nominal
codes, the optional fallback, and normalized branch values. LLVM shall emit the
ordinary Result tag query, path-local payload extraction, one code query and
switch, a fail-closed unreachable default for exact no-fallback coverage, a
typed SSA join, nested action DWARF and selected payload bindings, and the
existing single machine return.

Unknown, duplicate, missing, post-fallback, mixed, or additional matchers;
non-arithmetic or multi-vocabulary code sets; non-Result subjects; normally
completing actions; nested action expressions; callbacks; generators; and
cleanup-bearing forms shall remain fail-closed. The implementation shall add no
runtime control-flow value, allocation, indirect call, unwind edge, foreign
dependency, C/C++ runtime, other-language standard library, public ABI, or
`topal-native/6` revision. Tests shall share one interpreter/compiler source,
exercise success, selected code, whole-Error fallback, and exact four-code
coverage, verify skipped tails plus mixed-path and non-Result rejection, inspect
the exact LLVM switches/joins/single returns and fail-closed default, preserve
DWARF/GDB success and Error values and frames, run the complete compiler corpus,
and record separate resource baselines. This realizes
`TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-RESULT-001`,
`TOPAL-DECISION-ERROR-CODE-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-ERROR-CODE-DECISION-ACTIONS-001` for increment
3b2-b5e8ac.

## TOPAL-COMP-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001 — Complete List action lexical exits

Inside an admitted ordinary function, the interpreter and checked compiler
model shall propagate an explicit return from both actions of a complete List
decision. The table shall contain exactly one `Entry (first, rest)` rule and
one `Empty` rule in either order, the entry names shall be distinct, and both
actions shall be direct cleanup-free returning lexical blocks.

The interpreter and compiler shall evaluate the subject once, preserve
source-order rule consideration, bind the first entry and remaining List only
for the selected Entry action, evaluate only the selected action, validate its
returned value against the enclosing function result classifier, and omit the
selected block tail and following function tail at O0. The checked model shall
retain the List decision, entry bindings, supported exact element facts, and
normalized branch values. LLVM shall emit the ordinary empty test,
path-local head/rest decomposition, two action edges, a typed SSA join, nested
action and binding DWARF, and the existing single machine return.

Duplicate binding names, missing, duplicate, mixed, or additional matchers;
non-List subjects; unsupported List element representations; normally
completing actions; nested action expressions; callbacks; generators; and
cleanup-bearing forms shall remain fail-closed. The implementation shall add no
runtime control-flow value, allocation beyond the subject's existing List
representation, indirect call, unwind edge, foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or `topal-native/6` revision.
Tests shall share one interpreter/compiler source, exercise Entry and Empty
selection plus both matcher orders, verify skipped tails and mixed-path,
non-List, and duplicate-binding rejection, inspect exact LLVM branching,
decomposition, join, and single return, preserve DWARF/GDB bindings and frames,
run the complete compiler corpus, and record separate resource baselines. This
realizes `TOPAL-FUNCTION-RETURN-001`, `TOPAL-DECISION-LIST-001`, and
`TOPAL-COMPILER-LEXICAL-RETURN-LIST-DECISION-ACTIONS-001` for increment
3b2-b5e8ad.

## TOPAL-COMP-BLOCK-001 — Lexical block values

The compiler shall evaluate an admitted lexical block in a fresh checked and
generated-value environment nested inside its enclosing environment. An empty
block shall produce Unit without allocation. A nonempty block shall execute
statements in source order and deliver its final value; its bindings may shadow
outer names and shall not escape. An inner initializer shall resolve names
before introducing its own binding.

Generated instructions and machine-represented immutable locals shall use a
nested DWARF lexical scope so GDB resolves the innermost visible binding. The
compiler shall reject nested declarations and any indirect, conditional, or
cleanup-bearing return-through-block until their declaration, cleanup, and
exit-edge lowerings are admitted.

This requirement covers the cleanup-free block subset of
`TOPAL-EXEC-BLOCK-001` and the block case of `TOPAL-SYN-GRAMMAR-001`. It
realizes `TOPAL-COMPILER-BLOCK-001` for compiler increment 3b2-b1.

## TOPAL-COMP-COMPLETED-001 — Completion evidence

The compiler shall keep Completed distinct from Unit in the checked model,
generated signatures, values, equality, display, and debug information. An
admitted function returning Completed shall have a retained typed result and
call boundary at O0 so a dependent continuation remains ordered after the
call's completion; it shall not be lowered as a Unit-returning `void` call.

The zero-data value shall require no allocation or foreign runtime. Its private
machine carrier shall remain sealed inside the target-qualified Topal ABI, and
DWARF/GDB shall render the source identity `Completed` rather than an unrelated
integer or Unit value.

This requirement covers `TOPAL-EXEC-COMPLETED-001` and realizes
`TOPAL-COMPILER-COMPLETED-001` for compiler increment 3b2-b2.

## TOPAL-COMP-EFFECT-EMPTY-001 — Canonical empty Effect value

The checked compiler model shall classify `Effects ()` as the canonical empty
`Effect` value without scheduling or performing an interaction. `Effect` shall
remain distinct from Unit and `Completed` through classified bindings,
same-classifier equality, decomposed positional products, scalar function
parameters and results, and source display. This scalar rule does not itself
admit Effect Lists or aggregate results; `TOPAL-COMP-TUPLE-RESULT-001`
separately admits a qualified Tuple result containing this value, and
`TOPAL-COMP-LIST-EFFECT-001` admits the first immutable List representation.

The backend shall use a sealed zero-data scalar only in Topal-private signatures,
emit a distinct `Effect` DWARF enumeration for GDB, and require neither
allocation nor an effect-specific runtime function. Canonical display shall use
the existing Topal-owned Linux write boundary. No C/C++ runtime, other-language
standard library, public integer ABI, or `topal-native/6` revision is permitted.
This realizes `TOPAL-COMPILER-EFFECT-EMPTY-001` for compiler increment 7a.

## TOPAL-COMP-FUNCTION-EMPTY-EFFECT-001 — Explicit empty function effect bound

The checked compiler model shall admit the v0.1 post-result
`: Effects ()` upper bound on an otherwise admitted ordinary function. Because
the native subset rejects every source operation with a nonempty inferred
effect, it shall prove the implementation row exactly empty, check containment,
and retain a canonical explicit-empty row on the checked declaration and every
selected function instance. Unsupported nonempty, alternative, or polymorphic
rows shall receive a stable checked diagnostic instead of being erased or
treated as empty. Existing `Decreases` proof annotations shall retain their
separate behavior.

For one exact visible overload carrying the explicit empty bound,
`lang view function` shall produce a static-only typed Function view retaining
root identity, input and result classifiers, staticness, and the declared row.
The view may initialize a binding or be discarded, but it shall not enter the
runtime binding environment. Runtime observation, aggregate or function
passage, root data publication, zero- or multi-overload views, and other
introspection shall remain `E-COMPILER-UNSUPPORTED`.

Code generation shall erase the view and lower the called function exactly as
an inferred-empty direct private function. No view local or effect descriptor
shall enter LLVM IR, DWARF, or the executable; the ordinary function frame and
parameters shall remain fully debuggable. This shall add no reflection runtime,
descriptor registry, dispatch, hidden effect argument, allocation, foreign
runtime, C/C++ standard library, undefined symbol, needed library, relocation,
public/serialized/library effect ABI, or `topal-native/6` revision. It realizes
`TOPAL-COMPILER-FUNCTION-EMPTY-EFFECT-001`,
`TOPAL-FUNCTION-EFFECT-BOUND-001`, `TOPAL-EFFECT-CONTAIN-001`,
`TOPAL-INTRO-STATIC-001`, and `TOPAL-INTRO-VIEW-001` for compiler increment
7a1.

## TOPAL-COMP-LIST-EFFECT-001 — Immutable Effect List foundation

The checked compiler model shall admit `List Effect` where a classifier gives
the contextual element type, construct `Empty` and `Entry (value, remaining)`
with exact homogeneous typing, and retain the List classifier through immutable
bindings and ordinary function parameters and results. Construction shall
evaluate the entry value and remaining List in source order. Canonical output
shall match the shared interpreter's recursive `Entry`/`Empty` spelling.

The Linux x86-64 backend shall represent `Empty` as a null private pointer and
each `Entry` as an immutable, naturally aligned 16-byte node containing the
zero-data Effect carrier and the remaining-node pointer. It shall allocate
nodes only through the existing Topal-owned Linux mapping boundary, retain them
safely for process lifetime, and express private function passage as an LLVM
pointer so LLVM owns physical AMD64 calling-convention lowering. DWARF shall
expose the semantic `List Effect` identity and node shape, and the bundled GDB
renderer shall validate, bound, and render finite chains without recursive
host-stack growth.

This first container slice shall add no List equality, decisions, traversal,
mutation, reclamation contract, other element type, public or serialized node
layout, C/C++ runtime, other-language standard library, foreign allocator, or
`topal-native/6` revision. It realizes `TOPAL-COMPILER-LIST-EFFECT-001` and
`TOPAL-TYPE-LIST-CONSTRUCT-001` for compiler increment 4b3d-a.

## TOPAL-COMP-LIST-EFFECT-CORE-001 — Ordinary canonical-empty Effect Lists

The checked model shall extend the Effect List foundation with private
parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging. Operands shall
evaluate once. Since only `Effects ()` is admitted, equality shall compare
length without performing an effect; unsupported transforms fail before
artifact publication.

Linux x86-64 shall retain null `Empty` and immutable 16-byte i8/pointer nodes.
A conditional finite fragment shall implement equality/count at O0, decisions
shall load the exact sealed carrier, and emptiness shall be a null test. LLVM
owns private AMD64 placement; DWARF/GDB retain exact source identities. Tests
cover all admitted boundaries and observations, interpreter modes/history,
exact IR, artifact rejection, ELF/DWARF, GDB, corpus, and separate baselines.

This shall not define future nonempty effect-row equality or representation,
perform effects, or add runtime tags, generic/public/foreign/library ABI,
foreign allocation, C/C++, another-language library, or an ABI revision.
Future metadata shall carry effect-row identity/evidence, representation,
ownership, lifetime, effects, and target adapters independently of private
details. This realizes `TOPAL-COMPILER-LIST-EFFECT-CORE-001` and the List
construction/decision/equality/count/empty rules for increment 4b3d-t.

## TOPAL-COMP-LIST-COMPARISON-CORE-001 — Ordinary immutable Comparison Lists

The checked model shall admit contextual construction, immutable binding,
private parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging for
`List Comparison`. Entries retain exactly `Less`, `Equal`, or `Greater`, every
operand evaluates once, and unsupported transforms fail before publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte nodes containing the
existing i32 Comparison carrier and remaining pointer. A conditional finite
fragment shall compare exact alternatives and count correctly at O0. LLVM owns
private AMD64 placement; DWARF/GDB retain and validate exact source identities.
Tests cover all admitted boundaries and observations, interpreter modes and
history, exact IR, artifact rejection, ELF/DWARF, GDB, corpus, and baselines.

This adds no runtime tag, generic/public/foreign/library node or enum ABI,
foreign allocator, C/C++ runtime, other-language standard library, or ABI
revision. Future metadata carries the semantic alternative mapping,
representation/ownership, lifetime, effects, and target adapters independently
of private details. This realizes
`TOPAL-COMPILER-LIST-COMPARISON-CORE-001`, List construction, decision,
equality, count, and empty rules for compiler increment 4b3d-u.

## TOPAL-COMP-LIST-ERROR-CODE-CORE-001 — Ordinary arithmetic ErrorCode Lists

The checked model shall admit contextual construction, immutable binding,
private parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging for
`List ErrorCode` containing the four closed qualified arithmetic codes. Every
operand evaluates once; unsupported transforms fail before publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte nodes containing the
existing i32 arithmetic-code carrier and remaining pointer. A conditional
finite fragment shall compare exact qualified identities and count at O0. LLVM
owns private AMD64 placement; DWARF/GDB retain and validate the vocabulary.
Tests cover all four codes, admitted boundaries and observations, interpreter
modes/history, IR, rejection, ELF/DWARF, GDB, corpus, and baselines.

This shall not equate tags across ErrorCode vocabularies or add a runtime tag,
generic/public/foreign/library ABI, foreign allocator, C/C++, another-language
library, or ABI revision. Future metadata carries canonical vocabulary and
alternative identities, representation/ownership, lifetime, effects, and
target adapters independently of private details. This realizes
`TOPAL-COMPILER-LIST-ERROR-CODE-CORE-001`, List construction, decision,
equality, count, and empty rules for compiler increment 4b3d-v.

## TOPAL-COMP-LIST-UNIT-CORE-001 — Ordinary immutable Unit Lists

The checked model shall admit contextual construction, immutable binding,
private parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging for `List Unit`.
Every entry is `()`, operands evaluate once, and unsupported transforms fail
before artifact publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte zero-i8/pointer nodes.
A conditional finite fragment shall compare length and count correctly at O0.
Private Unit results retain void while aggregate fields retain their existing
i8 carrier; LLVM owns AMD64 placement. DWARF/GDB retain exact Unit/List identity.
Tests cover all admitted paths, interpreter modes/history, IR, artifact
rejection, ELF/DWARF, GDB, corpus, and separate baselines.

This shall not turn Unit into completion/effect evidence or add payload state,
runtime tags, generic/public/foreign/library ABI, foreign allocation, C/C++,
another-language library, or an ABI revision. Future metadata carries Unit
identity, representation/ownership, lifetime, effects, and target adapters
independently of private details. This realizes
`TOPAL-COMPILER-LIST-UNIT-CORE-001`, List construction, decision, equality,
count, and empty rules for compiler increment 4b3d-w.

## TOPAL-COMP-LIST-COMPLETED-CORE-001 — Ordinary immutable Completed Lists

The checked model shall admit contextual construction, immutable binding,
private parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging for
`List Completed`. Each entry remains explicit completion evidence, operands
evaluate once, and unsupported transforms fail before artifact publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte validated-zero
i8/pointer nodes. A conditional finite fragment shall compare length and count
correctly at O0. Private parameters/results and aggregate fields retain typed
i8 carriers while LLVM owns AMD64 placement. DWARF/GDB retain exact Completed
and List identities. Tests cover all admitted paths, interpreter modes/history,
IR, rejection, ELF/DWARF, GDB, corpus, and separate baselines.

This shall not conflate Completed with Unit or Effect, discard completion
evidence, or add payload state, runtime tags, generic/public/foreign/library
ABI, foreign allocation, C/C++, another-language library, or an ABI revision.
Future metadata carries completion semantics, representation/ownership,
lifetime, effects, and target adapters independently of private details. This
realizes `TOPAL-COMPILER-LIST-COMPLETED-CORE-001`, List construction, decision,
equality, count, and empty rules for compiler increment 4b3d-x.

## TOPAL-COMP-LIST-TYPE-CORE-001 — Ordinary immutable fundamental Type Lists

The checked model shall admit empty/nonempty construction with all seven
fundamental Type identities, immutable binding, private parameter/result/
package and Tuple/Record passage, structural equality, complete decisions,
count, emptiness, display, and debugging for `List Type`. Operands evaluate
once, exact canonical identity is retained, and unsupported transforms fail
before artifact publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte nodes containing the
existing closed i32 fundamental-Type carrier and remaining pointer. A
conditional finite fragment shall compare identities and count correctly at O0.
Private parameters/results and aggregate fields retain typed i32 carriers while
LLVM owns AMD64 placement. DWARF/GDB retain exact Type/List identities. Tests
cover all identities and admitted paths, interpreter modes/history, IR,
rejection, ELF/DWARF, GDB, corpus, and separate baselines.

This shall not create a host/LLVM descriptor, expand the fundamental identity
set, or add a List runtime tag, generic/public/foreign/library ABI, foreign
allocation, C/C++, another-language library, or an ABI revision. Future
metadata carries canonical identities, representation/ownership/lifetime/
effects, and target adapters independently of private numbers and details. This
realizes `TOPAL-COMPILER-LIST-TYPE-CORE-001`, fundamental Type value/identity/
boundary rules, and List construction, decision, equality, count, and empty
rules for compiler increment 4b3d-y.

## TOPAL-COMP-LIST-ENUM-CORE-001 — Ordinary payload-free nominal Enum Lists

The checked model shall admit empty/nonempty construction, immutable binding,
private parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging for Lists of every
admitted payload-free nominal Enum. Exact declaration identity and ordered
alternatives remain checked, operands evaluate once, cross-enum interchange is
rejected, and unsupported transforms fail before artifact publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte nodes containing the
existing declaration-local i32 enum carrier and remaining pointer. A conditional
common finite fragment shall compare tags only after same-nominal-type checking
and count correctly at O0. Private parameters/results and aggregate fields retain
typed i32 carriers while LLVM owns AMD64 placement. DWARF/GDB retain exact enum,
alternative, and List identities. Tests cover all alternatives, same/different
content and length, nominal mismatch, all admitted paths, interpreter modes/
history, IR, rejection, ELF/DWARF, GDB, corpus, and separate baselines.

This shall not exchange tags across declarations, create a portable foreign
enum, or add a List runtime tag, generic/public/foreign/library ABI, foreign
allocation, C/C++, another-language library, or an ABI revision. Future metadata
carries canonical declaration/alternative identities, representation/ownership/
lifetime/effects, and target adapters independently of private numbers and
details. This realizes `TOPAL-COMPILER-LIST-ENUM-CORE-001`, nominal Enum rules,
and List construction, decision, equality, count, and empty rules for compiler
increment 4b3d-z.

## TOPAL-COMP-LIST-MODULAR-CORE-001 — Ordinary nominal modular Lists

The checked model shall admit empty/nonempty construction, immutable binding,
private parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging for Lists of every
admitted root nominal modular type. Exact declaration identity, signedness,
bounds, and canonical representatives remain checked; operands evaluate once,
cross-type interchange is rejected, and unsupported transforms fail before
artifact publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte nodes containing the
existing canonical arbitrary-precision Int pointer and remaining pointer. A
conditional common finite fragment shall use exact Int comparison only after
same-modular-type checking and count correctly at O0. Private parameters,
results, and Tuple/Record fields retain pointer carriers while LLVM owns AMD64
placement. DWARF/GDB retain exact modular declaration, value, and List
identities. Tests cover bounds, same/different content and length, nominal
mismatch, all admitted paths, compiler-only Record passage, interpreter modes/
history, IR, rejection, ELF/DWARF, GDB, corpus, and separate baselines.

This shall not narrow, copy, truncate, wrap, or re-reduce representatives,
exchange values across declarations, create a portable machine number, or add
a List runtime tag, generic/public/foreign/library ABI, foreign allocation,
C/C++, another-language library, or an ABI revision. Future metadata carries
canonical declaration, signedness, bounds, representation/ownership/lifetime/
effects, and target adapters independently of private details. This realizes
`TOPAL-COMPILER-LIST-MODULAR-CORE-001`, modular type/construction rules, and
List construction, decision, equality, count, and empty rules for compiler
increment 4b3d-aa.

## TOPAL-COMP-LIST-OPTIONAL-INT-CORE-001 — Ordinary Optional Int Lists

The checked model shall admit construction, private parameter/result/package
and Tuple/Record passage, derived equality, complete decisions, count,
emptiness, display, and debugging for `List Optional Int`. Linux x86-64 shall
use null List Empty and immutable 16-byte Optional-pointer/remaining-pointer
nodes; a conditional finite fragment shall delegate exact element equality to
the existing Optional-Int runtime and count correctly at O0. LLVM owns physical
placement, while DWARF/GDB retain both classifiers.

Tests cover `None`, positive/negative `Some`, same/different content and length,
all boundaries, rejection, IR, ELF/DWARF, GDB, corpus, history, and separate
baselines. This adds no flattened Optional, copied Int, generic/public/foreign
ABI, foreign allocation, C/C++, other-language library, or ABI revision. Future
metadata remains independent of private headers and nodes. This realizes
`TOPAL-COMPILER-LIST-OPTIONAL-INT-CORE-001` for increment 4b3d-ab.

## TOPAL-COMP-LIST-OPTIONAL-RATIONAL-CORE-001 — Ordinary Optional Rational Lists

The checked model shall admit construction, private parameter/result/package
and Tuple/Record passage, derived equality, complete decisions, count,
emptiness, display, and debugging for `List Optional Rational`. Linux x86-64
shall use null List Empty and immutable 16-byte Optional-pointer/remaining-
pointer nodes; a conditional finite fragment shall delegate exact element
equality to the existing Optional-Rational runtime and count correctly at O0.
LLVM owns physical placement, while DWARF/GDB retain all classifier layers.

Tests cover `None`, positive/negative `Some`, same/different content and length,
all boundaries, rejection, IR, ELF/DWARF, GDB, corpus, history, and separate
baselines. This adds no flattened Optional, copied Rational, generic/public/
foreign ABI, foreign allocation, C/C++, other-language library, or ABI revision.
Future metadata remains independent of private headers and nodes. This realizes
`TOPAL-COMPILER-LIST-OPTIONAL-RATIONAL-CORE-001` for increment 4b3d-ac.

## TOPAL-COMP-LIST-OPTIONAL-STRING-CORE-001 — Ordinary Optional String Lists

The checked model shall admit construction, private parameter/result/package
and Tuple/Record passage, derived equality, complete decisions, count,
emptiness, display, and debugging for `List Optional String`. Linux x86-64 shall
use null List Empty and immutable 16-byte Optional-pointer/remaining-pointer
nodes; a conditional finite fragment shall delegate exact element equality to
the existing Optional-String runtime and count correctly at O0. LLVM owns
physical placement, while DWARF/GDB retain all classifier layers.

Tests cover `None`, empty/ASCII/non-ASCII `Some`, same/different content and
length, all boundaries, rejection, IR, ELF/DWARF, GDB, corpus, history, and
separate baselines. This adds no flattened Optional, copied String descriptor,
generic/public/foreign ABI, foreign allocation, C/C++, other-language library,
or ABI revision. Future metadata remains independent of private headers and
nodes. This realizes `TOPAL-COMPILER-LIST-OPTIONAL-STRING-CORE-001` for increment
4b3d-ad.

## TOPAL-COMP-LIST-BOOLEAN-001 — Ordinary immutable Boolean Lists

The checked compiler model shall admit contextual `Empty` and `Entry`
construction for `List Boolean`, immutable bindings, ordinary private
parameters and results, package fields, recursively admitted Tuple/Record
fields, structural equality and inequality, complete `Empty`/`Entry` decisions,
entry count, emptiness, canonical display, and debugging. Every constructor and
call operand shall evaluate once in source order. Unsupported Boolean-List
transforms shall remain `E-COMPILER-UNSUPPORTED` before artifact publication.

The Linux x86-64 backend shall represent `Empty` as a null private pointer and
each `Entry` as an immutable naturally aligned 16-byte node with its i1 payload
at offset zero and remaining-node pointer at offset eight. Padding shall carry
no source value. A compiler-selected runtime fragment shall implement finite
nonrecursive structural equality and entry counting; emptiness shall remain a
null test and decisions shall load the exact i1 payload. Correctness at O0 shall
not depend on optimization. Private pointer-bearing definitions, calls,
returns, Tuple/Record/package fields, target-derived DWARF, and the bounded GDB
renderer shall preserve the complete source classifier while LLVM owns physical
AMD64 placement.

Tests shall cover empty and nonempty construction, true and false entries,
same/different structural equality, complete decomposition, count, emptiness,
private parameter/result, package, Tuple, and Record passage, display, all
interpreter modes, reversible history, exact private IR, artifact-free
unsupported-transform rejection, freestanding ELF/DWARF, GDB values/frames,
the shared corpus, and separate interpreter/compiler resource baselines.

This increment shall add no runtime type tag, type-erased generic List, public,
foreign, serialized, or compiled-library node ABI, foreign allocator, C/C++
runtime, other-language standard library, or `topal-native/6` revision.
Projections, insertion, concatenation, reversal, removal, range selection,
traversal, higher-order transforms, final reclamation, and other element types
remain separately governed. Future library metadata shall retain element
classification, representation/ownership/lifetime/effects, and versioned
target-adapter facts independently of node offsets, private helper names, LLVM
types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-LIST-BOOLEAN-001`, `TOPAL-TYPE-LIST-CONSTRUCT-001`,
`TOPAL-DECISION-LIST-001`, `TOPAL-TYPE-LIST-EQUALITY-001`,
`TOPAL-LIST-ENTRY-COUNT-001`, and `TOPAL-LIST-EMPTY-PREDICATE-001` for compiler
increment 4b3d-m.

## TOPAL-COMP-LIST-STRING-CORE-001 — Ordinary immutable String Lists

The checked compiler model shall admit contextual `Empty` and `Entry`
construction for `List String`, immutable bindings, ordinary private parameters
and results, package fields, recursively admitted Tuple/Record fields,
structural equality and inequality, complete `Empty`/`Entry` decisions, entry
count, emptiness, canonical display, and debugging. Every constructor and call
operand shall evaluate once in source order. Unsupported String-List transforms
shall remain `E-COMPILER-UNSUPPORTED` before artifact publication.

The Linux x86-64 backend shall represent `Empty` as a null private pointer and
each `Entry` as an immutable 16-byte node containing the existing String
descriptor pointer and remaining-node pointer. A compiler-selected runtime
fragment shall implement finite nonrecursive structural equality through the
canonical preserved-sequence String comparator and entry counting; emptiness
shall remain a null test and decisions shall load the exact descriptor pointer.
Correctness at O0 shall not depend on optimization. Private pointer-bearing
definitions, calls, returns, Tuple/Record/package fields, target-derived DWARF,
and the bounded GDB renderer shall preserve the complete source classifier and
String delimiters while LLVM owns physical AMD64 placement.

Tests shall cover empty and nonempty construction, distinct Unicode-capable
String entries, same/different structural equality, complete decomposition,
count, emptiness, private parameter/result, package, Tuple, and Record passage,
display, all interpreter modes, reversible history, exact private IR,
artifact-free unsupported-transform rejection, freestanding ELF/DWARF, GDB
values/frames, the shared corpus, and separate interpreter/compiler resource
baselines.

This increment shall add no copied String representation, host text API,
runtime type tag, type-erased generic List, public, foreign, serialized, or
compiled-library node ABI, foreign allocator, C/C++ runtime, other-language
standard library, or `topal-native/6` revision. Projections, insertion,
concatenation, reversal, removal, range selection, traversal, higher-order
transforms, final reclamation, and other element types remain separately
governed. Future library metadata shall retain element classification, String
and node representation/ownership/lifetime/effects, and versioned target-
adapter facts independently of node offsets, private helper names, LLVM
types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-LIST-STRING-CORE-001`, `TOPAL-TYPE-LIST-CONSTRUCT-001`,
`TOPAL-DECISION-LIST-001`, `TOPAL-TYPE-LIST-EQUALITY-001`,
`TOPAL-LIST-ENTRY-COUNT-001`, and `TOPAL-LIST-EMPTY-PREDICATE-001` for compiler
increment 4b3d-n.

## TOPAL-COMP-LIST-CHARACTER-CORE-001 — Ordinary immutable Character Lists

The checked compiler model shall admit contextual `Empty` and `Entry`
construction for `List Character`, immutable bindings, ordinary private
parameters and results, package fields, recursively admitted Tuple/Record
fields, structural equality and inequality, complete `Empty`/`Entry` decisions,
entry count, emptiness, canonical display, and debugging. Every constructor and
call operand shall evaluate once in source order. Stored entries shall retain
their Character constraint evidence and complete preserved scalar sequence.
Unsupported Character-List transforms shall remain `E-COMPILER-UNSUPPORTED`
before artifact publication.

The Linux x86-64 backend shall represent `Empty` as a null private pointer and
each `Entry` as an immutable 16-byte node containing the constrained String
descriptor pointer and remaining-node pointer. The compiler-selected finite
String-List fragment shall implement structural equality through the canonical
preserved-sequence comparator and entry counting; emptiness shall remain a null
test and decisions shall load the exact descriptor pointer. Correctness at O0
shall not depend on optimization. Private pointer-bearing definitions, calls,
returns, Tuple/Record/package fields, target-derived DWARF, and the bounded GDB
renderer shall preserve the complete source classifier, multi-scalar character
contents, and delimiters while LLVM owns physical AMD64 placement.

Tests shall cover empty and nonempty construction, a multi-scalar grapheme and
a ZWJ emoji, same/different structural equality, complete decomposition, count,
emptiness, private parameter/result, package, Tuple, and Record passage,
display, all interpreter modes, reversible history, exact private IR,
artifact-free unsupported-transform rejection, freestanding ELF/DWARF, GDB
values/frames, the shared corpus, and separate interpreter/compiler resource
baselines.

This increment shall add no code-point Character representation, copied String,
implicit normalization, host text API, runtime type tag, type-erased generic
List, public, foreign, serialized, or compiled-library node ABI, foreign
allocator, C/C++ runtime, other-language standard library, or `topal-native/6`
revision. Projections, insertion, concatenation, reversal, removal, range
selection, traversal, higher-order transforms, final reclamation, and other
element types remain separately governed. Future library metadata shall retain
the Character classifier and constraint evidence, representation/ownership,
lifetime, effects, and versioned target-adapter facts independently of node
offsets, private helper names, LLVM types/symbols, debug shadows, and physical
placement. This realizes `TOPAL-COMPILER-LIST-CHARACTER-CORE-001`,
`TOPAL-TYPE-LIST-CONSTRUCT-001`, `TOPAL-DECISION-LIST-001`,
`TOPAL-TYPE-LIST-EQUALITY-001`, `TOPAL-LIST-ENTRY-COUNT-001`, and
`TOPAL-LIST-EMPTY-PREDICATE-001` for compiler increment 4b3d-q.

## TOPAL-COMP-LIST-NAT-CORE-001 — Ordinary immutable Nat Lists

The checked compiler model shall admit contextual `Empty` and `Entry`
construction for `List Nat`, immutable bindings, ordinary private parameters
and results, package fields, recursively admitted Tuple/Record fields,
structural equality and inequality, complete `Empty`/`Entry` decisions, entry
count, emptiness, canonical display, and debugging. Every constructor and call
operand shall evaluate once in source order. Finite entries shall be validated
as nonnegative, `+Infinity` shall remain admitted, and every entry shall retain
Nat evidence. Unsupported Nat-List transforms shall remain
`E-COMPILER-UNSUPPORTED` before artifact publication.

The Linux x86-64 backend shall represent `Empty` as a null private pointer and
each `Entry` as an immutable 16-byte node containing the exact Int-compatible
pointer and remaining-node pointer. The compiler-selected finite Int-List
fragment shall implement structural equality, including positive-infinity
comparison, and entry counting; emptiness shall remain a null test and decisions
shall load the exact numeric pointer. Correctness at O0 shall not depend on
optimization. Private pointer-bearing definitions, calls, returns,
Tuple/Record/package fields, target-derived DWARF, and the bounded GDB renderer
shall preserve the complete source classifier, arbitrary-precision entries,
and `+Infinity` while LLVM owns physical AMD64 placement.

Tests shall cover empty and nonempty construction, zero, a large finite Nat,
`+Infinity`, same/different structural equality, complete decomposition, count,
emptiness, private parameter/result, package, Tuple, and Record passage,
display, all interpreter modes, reversible history, exact private IR,
artifact-free unsupported-transform rejection, freestanding ELF/DWARF, GDB
values/frames, the shared corpus, and separate interpreter/compiler resource
baselines.

This increment shall add no machine-unsigned width, truncation, wrapping,
second numeric representation, runtime type tag, type-erased generic List,
public, foreign, serialized, or compiled-library node ABI, foreign allocator,
C/C++ runtime, other-language standard library, or `topal-native/6` revision.
Projections, insertion, concatenation, reversal, removal, range selection,
traversal, higher-order transforms, final reclamation, and other element types
remain separately governed. Future library metadata shall retain Nat constraint
evidence and infinity capability, representation/ownership, lifetime, effects,
and versioned target-adapter facts independently of node offsets, private helper
names, LLVM types/symbols, debug shadows, and physical placement. This realizes
`TOPAL-COMPILER-LIST-NAT-CORE-001`, `TOPAL-NUM-NAT-001`,
`TOPAL-TYPE-LIST-CONSTRUCT-001`, `TOPAL-DECISION-LIST-001`,
`TOPAL-TYPE-LIST-EQUALITY-001`, `TOPAL-LIST-ENTRY-COUNT-001`, and
`TOPAL-LIST-EMPTY-PREDICATE-001` for compiler increment 4b3d-r.

## TOPAL-COMP-LIST-RATIONAL-CORE-001 — Ordinary immutable Rational Lists

The compiler shall admit contextual construction, immutable binding, private
parameter/result/package and Tuple/Record passage, structural equality,
complete decisions, count, emptiness, display, and debugging for
`List Rational`. Exact reduced fractions and infinities shall be retained;
operands evaluate once and unsupported transforms fail before publication.

Linux x86-64 shall use null `Empty` and immutable 16-byte nodes containing the
existing Rational descriptor and remaining pointer. A conditional finite
fragment shall compare canonically and count correctly at O0. LLVM owns private
AMD64 placement; DWARF/GDB retain exact source types and values. Tests cover all
admitted paths, IR, ELF/DWARF, GDB, history, corpus, rejection, and baselines.

This adds no floating point, host numeric API, runtime tag, public/foreign/
library ABI, foreign allocator, C/C++ runtime, other-language library, or ABI
revision. Future metadata carries Rational/node representation, ownership,
lifetime, effects, infinity capability, and target adapters. This realizes
`TOPAL-COMPILER-LIST-RATIONAL-CORE-001`, List construction, decision, equality,
count, and empty rules for compiler increment 4b3d-s.

## TOPAL-COMP-LIST-INT-CONTAINMENT-001 — Exact Int List containment

The checked compiler model shall extend contextual homogeneous List
construction and private function passage to `List Int` without changing Int
semantics. It shall evaluate the complete List operand before the entry or List
pattern operand exactly once. `contains-entry` shall search for any equal Int;
`contains-sequence` shall search for a consecutive equal pattern; and
`contains-subsequence` shall search for the ordered equal pattern while
permitting gaps. An empty sequence or subsequence pattern shall match every
List. Every input shall remain immutable.

The backend shall retain the private 16-byte node size while using an exact Int
pointer in the first word and the remaining-node pointer in the second word.
Containment shall use allocation-free loops and the existing canonical
arbitrary-precision Int comparator; correctness at O0 shall not depend on LLVM
optimization. The compiler shall include these specialized runtime helpers
only when a checked expression requires them. Canonical display, opaque-pointer
private calls and returns, DWARF, and the bounded GDB renderer shall preserve
every Int value and the `List Int` classifier. LLVM shall continue to own
physical AMD64 pointer placement.

This increment shall add no public, foreign, serialized, or generic List ABI,
no mutation or reclamation contract, no C/C++ runtime, other-language standard
library, foreign allocator, or `topal-native/6` revision. List equality,
decisions, other observations and transformations, and other element types
remain deferred. It realizes `TOPAL-COMPILER-LIST-INT-CONTAINMENT-001`,
`TOPAL-TYPE-LIST-CONSTRUCT-001`, `TOPAL-LIST-CONTAINS-ENTRY-001`,
`TOPAL-LIST-CONTAINS-SEQUENCE-001`, and
`TOPAL-LIST-CONTAINS-SUBSEQUENCE-001` for compiler increment 4b3d-b.

## TOPAL-COMP-LIST-INT-REMOVAL-001 — Immutable Int List removal

The checked compiler model shall accept `remove-first` and `remove-all` only
for the admitted `List Int` specialization and an exact Int operand. It shall
evaluate the complete List before the removal value exactly once, preserve the
List classifier, and leave every input immutable. `remove-first` shall remove
only the earliest equal entry and preserve an unmatched List unchanged;
`remove-all` shall remove every equal entry. Both shall retain the order and
exact arbitrary-precision values of all other entries.

The backend shall implement both operations as finite nonrecursive loops using
the existing canonical Int comparator. It may share the unchanged input and an
untouched suffix. Rebuilt prefixes or filtered results shall contain immutable
logical 16-byte Int-pointer/remaining-pointer nodes allocated only through the
Topal-owned Linux mapping boundary. The compiler shall keep the common layout,
containment, and removal LLVM fragments independently conditional so unrelated
programs do not pay their assembly cost. Behavior at O0 shall not depend on an
optimization pass.

Canonical output, private pointer passage, List-specific DWARF, and bounded GDB
rendering shall remain exact. This increment shall add no public, foreign,
serialized, persistent, or generic List ABI, no foreign allocator, C/C++
runtime, other-language standard library, undefined symbol, needed library,
relocation, reclamation contract, or `topal-native/6` revision. It realizes
`TOPAL-COMPILER-LIST-INT-REMOVAL-001`, `TOPAL-LIST-REMOVE-FIRST-001`, and
`TOPAL-LIST-REMOVE-ALL-001` for compiler increment 4b3d-c.

## TOPAL-COMP-LIST-INT-CORE-001 — Basic immutable Int List operations

The checked compiler model shall admit the existing basic List surface for
`List Int`: explicit `empty List Int`, `one value`, prepend, append, concat,
reverse, entry count, emptiness, structural equality, first, rest, uncons, and
a complete `Empty`/`Entry (first, rest)` decision. Operands shall be evaluated
exactly once in source order. The model shall preserve arbitrary-precision Int
entries, retain exact result classifiers, scope decision bindings only within
the selected Entry action, and reject unsupported element classifiers rather
than applying a type-erased implementation.

The Linux x86-64 backend shall reuse the private immutable 16-byte
Int-pointer/remaining-pointer node. Concatenation shall copy its left operand
into one Topal-owned contiguous allocation and may share the right operand;
append and reverse shall publish only newly initialized immutable nodes.
Counting, emptiness, projections, decisions, and equality shall use finite
nonrecursive control flow. Equality shall call the canonical exact Int
comparator. Behavior at O0 shall not depend on an optimization pass.

`first`, `rest`, and `uncons` shall retain the existing private Optional header
while preserving semantic payload classifiers `Int`, `List Int`, and
`(Int, List Int)`. A present empty tail shall remain distinct from absence.
DWARF and the bundled GDB renderer shall name, validate, and render
`Optional List Int` and `Optional (Int, List Int)` values. The compiler shall
include the core LLVM fragment only for checked expressions that require it.

This increment shall add no public, foreign, serialized, persistent, or
generic List/Optional/pair ABI, foreign allocator, C/C++ runtime,
other-language standard library, undefined symbol, needed library, relocation,
reclamation contract, or `topal-native/6` revision. It realizes
`TOPAL-COMPILER-LIST-INT-CORE-001`, `TOPAL-TYPE-LIST-CONSTRUCT-001`,
`TOPAL-DECISION-LIST-001`, `TOPAL-TYPE-LIST-EQUALITY-001`,
`TOPAL-LIST-PREPEND-001`, `TOPAL-LIST-APPEND-001`,
`TOPAL-LIST-CONCAT-001`, `TOPAL-LIST-ENTRY-COUNT-001`,
`TOPAL-LIST-EMPTY-PREDICATE-001`, `TOPAL-LIST-EMPTY-001`,
`TOPAL-LIST-ONE-001`, `TOPAL-LIST-UNCONS-001`, `TOPAL-LIST-FIRST-001`,
`TOPAL-LIST-REST-001`, and `TOPAL-LIST-REVERSE-001` for compiler increment
4b3d-d.

## TOPAL-COMP-LIST-INT-FUNCTIONS-001 — Contextual Int List functions

The checked compiler model shall accept contextual binding-pattern anonymous
functions for `List Int` map, select, and Int-state fold. It shall infer and
require exact signatures `Int -> Int`, `Int -> Boolean`, and
`(Int, Int) -> Int`, respectively. It shall evaluate the List once, evaluate a
fold initial value once after the List, retain admitted immutable lexical
captures, diagnose arity or result mismatches, and reject anonymous product
patterns and other element/state types.

Generated map and select loops shall invoke the checked body exactly once per
entry in source order. Map shall publish transformed entries in that order;
select shall retain exactly accepted original Int values in that order. Fold
shall pass prior state before current entry, return its initial Int for Empty,
and otherwise return the final exact Int. The source List shall remain
unchanged. Arbitrary-precision operations inside every body shall reuse the
canonical Int runtime.

The Linux x86-64 backend shall specialize each body directly into finite LLVM
control flow. Map and select may allocate and link fresh private 16-byte nodes
through the Topal-owned mapping boundary while those nodes remain inaccessible;
published nodes shall be immutable. Fold shall carry its exact Int pointer in
an LLVM phi. Correctness at O0 shall require no host recursion, Function object,
callback ABI, indirect call, or traversal dispatcher. Existing List/Int DWARF
and the bundled GDB renderer shall expose parameters and result bindings.

This increment shall add no public, foreign, serialized, persistent, or
generic collection/callable ABI, foreign allocator, C/C++ runtime,
other-language standard library, undefined symbol, needed library, relocation,
reclamation contract, or `topal-native/6` revision. Traversal control and
remaining collection algorithms stay deferred. It realizes
`TOPAL-COMPILER-LIST-INT-FUNCTIONS-001`, `TOPAL-COLLECTION-MAP-001`,
`TOPAL-COLLECTION-SELECT-001`, `TOPAL-COLLECTION-FOLD-001`, and
`TOPAL-FUNCTION-ANONYMOUS-001` for compiler increment 4b3d-e.

## TOPAL-COMP-LIST-INT-BOUND-FUNCTIONS-001 — Bound anonymous List functions

The checked compiler model shall allow a binding-pattern anonymous Function to
be bound immutably and later supplied to the admitted `List Int` map, select,
or Int-state fold. The Function binding shall retain its parameter pattern,
body, static context, and defining lexical-capture facts. At each collection
use the compiler shall infer and require `Int -> Int`, `Int -> Boolean`, or
`(Int, Int) -> Int` as appropriate, preserving the definition-time snapshot
rather than resolving shadowing use-site bindings.

The backend shall keep the bound Function's existing private identity tag for
source display and debugging, but specialize the retained body directly into
the finite loop introduced by `TOPAL-COMP-LIST-INT-FUNCTIONS-001`. Execution
shall not inspect the tag or create a Function object, callback ABI, function
pointer, indirect call, closure allocation, or traversal dispatcher. Once-only
operand evaluation, per-entry source order, exact Int behavior, fresh immutable
result publication, empty identities, and O0 correctness shall remain
unchanged.

DWARF and GDB shall expose each bound anonymous Function identity alongside
the resulting List and Int bindings. This increment shall add no public,
foreign, serialized, persistent, or generic callable/collection ABI, foreign
allocator, C/C++ runtime, other-language standard library, undefined symbol,
needed library, relocation, or `topal-native/6` revision. Named, symbolic,
product-pattern, escaping, and dynamically selected collection functions and
other element/result/state classifiers remain deferred. It realizes
`TOPAL-COMPILER-LIST-INT-BOUND-FUNCTIONS-001`,
`TOPAL-COLLECTION-MAP-001`, `TOPAL-COLLECTION-SELECT-001`,
`TOPAL-COLLECTION-FOLD-001`, and `TOPAL-FUNCTION-ANONYMOUS-001` for compiler
increment 4b3d-f.

## TOPAL-COMP-RANGE-SELECTION-001 — Range-selected Lists and Strings

The checked compiler model shall admit `List Int select Range Int` and
`List Int select-index Range Int`, evaluating the operands once in source
order. The backend shall use exact arbitrary-precision entry comparisons for
value selection and exact zero-based positions for index selection, traverse
the finite source once in order, preserve occurrences, and publish only fully
initialized fresh immutable nodes. Empty, disjoint, and inverted ranges shall
produce Empty and the source shall remain unchanged.

For a closed compiler-known String and finite closed compiler-known `Range Int`,
the checked model shall perform index selection with the shared pinned Unicode
user-perceived-Character segmentation and lower the selected semantic result as
an ordinary String. It shall not materialize selection/slice provenance or make
storage sharing observable. Dynamic String range selection shall retain a
stable unsupported diagnostic until the compiler has a freestanding Topal
Unicode segmentation runtime; it shall not depend on a host or foreign Unicode
library merely to broaden this increment.

The Linux x86-64 backend shall conditionally link the private List selection
fragment only when used. That fragment may call the existing Topal allocator,
exact Int conversion/comparison, and Range-membership helpers, but shall add no
foreign allocator, C/C++ runtime, other-language standard library, undefined
symbol, needed library, dynamic relocation, public/serialized/persistent/generic
collection ABI, stabilized private layout, or `topal-native/6` revision. DWARF
and GDB shall retain the applicable List, Int, Range, String, binding, parameter,
and frame views. This realizes `TOPAL-COMPILER-RANGE-SELECTION-001`,
`TOPAL-RANGE-VALUE-SELECTION-001`, and `TOPAL-RANGE-INDEX-SELECTION-001` for
compiler increment 4b3d-g.

## TOPAL-COMP-TRAVERSAL-CONTROL-001 — Short-circuiting Int List fold

The checked compiler model shall admit `Continue Int` and `Finish Int` as
distinct `TraversalControl Int` values. An admitted `List Int` fold with an
Int initial state and an anonymous action may return either an ordinary Int
state or `TraversalControl Int`. Continue shall supply the exact state for the
next reached entry; Finish shall return its exact payload immediately without
executing the action for later entries. The List and initial state shall each
be evaluated once in source order, Empty shall return the initial state, and
ordinary Int-result folds shall remain unchanged. Other payload, element, and
state classifiers and traversal-control function boundaries shall retain a
stable unsupported diagnostic.

The Linux x86-64 backend shall lower each constructor to a private immutable
16-byte allocation containing a 64-bit Continue/Finish tag followed by the
canonical Int pointer. The specialized generated fold loop shall load the tag
and payload and branch directly to its advance or done block. Behavior at O0
shall require no optimization, callback ABI, indirect call, host recursion,
runtime traversal dispatcher, or separately linked traversal helper. DWARF and
the bundled GDB renderer shall identify `TraversalControl Int`, validate its
private storage, and render both constructors.

This increment shall use only the existing Topal-owned Linux mapping and write
boundaries and shall add no foreign allocator, C/C++ runtime, other-language
standard library, undefined symbol, needed library, dynamic relocation,
public/foreign/serialized/persistent/generic layout, or `topal-native/6`
revision. It realizes `TOPAL-COMPILER-TRAVERSAL-CONTROL-001`,
`TOPAL-EXEC-TRAVERSAL-CONTROL-001`, and `TOPAL-COLLECTION-FOLD-001` for compiler
increment 4b3d-h.

## TOPAL-COMP-LIST-INT-PAIR-MAP-001 — Int-pair List product map

The checked compiler model shall admit expected `List (Int, Int)` construction
and map it with a single two-field anonymous product parameter pattern whose
bindings are both exact Int. The anonymous action may be directly contextual
or retained in an immutable binding. Each invocation shall bind fields in
source order and return one Int result. Mapping shall visit every pair exactly
once in List order, preserve every exact arbitrary-precision value, publish a
`List Int`, and leave the source unchanged. Duplicate bindings, wrong product
arity, non-Int fields/results, select/fold use, and pair-List boundaries outside
the later ordinary core increment shall receive stable checked diagnostics.

The Linux x86-64 backend shall store each pair inline as two canonical Int
pointers followed by the remaining-node pointer in one naturally aligned
24-byte private node. Construction shall evaluate the pair and remaining List
before allocating and fully initializing the node. The generated map loop
shall load both fields directly into the specialized anonymous environment and
reuse the existing immutable `List Int` result loop. Canonical output, semantic
DWARF, and the bounded validating GDB renderer shall preserve complete pair
Lists and mapped results at O0.

This increment shall use only the existing Topal Linux mapping and write
boundaries. It shall add no tuple payload allocation, generic/type-erased List
runtime, callback convention, indirect call, foreign allocator, C/C++ runtime,
other-language standard library, undefined symbol, needed library, dynamic
relocation, public/foreign/serialized/persistent/generic List ABI, or
`topal-native/6` revision. It realizes
`TOPAL-COMPILER-LIST-INT-PAIR-MAP-001`, `TOPAL-TYPE-LIST-CONSTRUCT-001`,
`TOPAL-COLLECTION-MAP-001`, and `TOPAL-FUNCTION-ANONYMOUS-001` for compiler
increment 4b3d-i.

## TOPAL-COMP-LIST-INT-PAIR-CORE-001 — Ordinary Int-pair Lists

The checked model shall admit construction, private parameter/result/package
and nested Tuple/Record passage, derived equality, complete decisions, count,
emptiness, display, and debugging for `List (Int, Int)`. Linux x86-64 shall
retain the existing immutable 24-byte two-Int-pointer/remaining-pointer nodes;
a conditional finite fragment shall compare both exact fields in order and
count correctly at O0. LLVM owns physical placement, while DWARF/GDB retain the
recursive List and positional Tuple classifiers.

Tests cover small and arbitrary-precision signed fields, same/different content
and length, all private boundaries, rejection, IR, ELF/DWARF, GDB, corpus,
history, and separate baselines. This adds no Tuple allocation, generic/public/
foreign ABI, foreign allocation, C/C++, other-language library, or ABI revision.
Future metadata remains independent of private nodes and offsets. This realizes
`TOPAL-COMPILER-LIST-INT-PAIR-CORE-001` for increment 4b3d-ae.

## TOPAL-COMP-LIST-RECURSIVE-001 — Exact recursive Int/String Lists

The checked compiler model shall admit contextual `List (Int, String)` and
`List List (Int, String)` construction and retain both exact classifiers. The
outer recursive List shall cross ordinary parameter/result boundaries through
one direct specialization. Its admitted observations shall be `first` with
`Optional (List (Int, String))`, exact `entry-count`, and structural equality
that preserves outer and inner order and compares every exact Int and String.
Construction and observations shall evaluate each source operand once in
source order; `Some Empty` shall remain distinct from `None`. Except for the
later ordinary inner pair-List increment, outer `rest`/`uncons`, deeper nesting,
other shapes, and all unlisted List operations shall receive stable checked
diagnostics.

The Linux x86-64 backend shall use a private 24-byte inner node containing Int,
String, and remaining pointers, and a private 16-byte outer node containing
inner-List and remaining pointers. Empty shall be null at both levels. Nodes
shall be allocated only through the Topal-owned Linux mapping boundary and
shall be immutable after complete initialization. Independently selected,
shape-exact LLVM loops shall implement outer count, first, and equality; the
inner equality loop shall call the canonical exact Int and String comparators.
Behavior at O0 shall require no LLVM optimization, host recursion, generic or
type-erased List runtime, tag, callback, indirect call, or dispatcher.

The outer private function boundary shall use matching LLVM pointer prototypes
so LLVM owns physical AMD64 lowering. Target-layout-derived DWARF and the
bounded validating GDB renderer shall preserve and render both recursive List
types. The executable shall retain no undefined symbol, needed library, or
dynamic relocation and shall use no foreign allocator, C/C++ runtime, or other-
language standard library. This increment shall define no public, foreign,
serialized, persistent, generic, or compiled-library List ABI, stabilize no
private layout, and make no `topal-native/6` revision. It realizes
`TOPAL-COMPILER-LIST-RECURSIVE-001`, `TOPAL-TYPE-LIST-CONSTRUCT-001`,
`TOPAL-TYPE-LIST-RECURSIVE-001`, `TOPAL-TYPE-LIST-EQUALITY-001`,
`TOPAL-LIST-FIRST-001`, and `TOPAL-LIST-ENTRY-COUNT-001` for compiler increment
4b3d-j.

## TOPAL-COMP-LIST-INT-STRING-PAIR-CORE-001 — Ordinary Int/String-pair Lists

The checked model shall admit construction, private parameter/result/package
and nested Tuple/Record passage, derived equality, complete decisions, count,
emptiness, display, and debugging for `List (Int, String)`. Linux x86-64 shall
retain the existing immutable 24-byte Int-pointer/String-pointer/remaining-
pointer nodes. One conditional finite fragment shall compare both exact fields
in order and count correctly at O0, and recursive outer-List equality shall
reuse its inner equality helper. LLVM owns physical placement, while DWARF/GDB
retain the recursive List and positional Tuple classifiers.

Tests cover arbitrary-precision signed Ints, empty and non-ASCII Strings,
same/different fields and length, all private boundaries, rejection, IR,
ELF/DWARF, GDB, corpus, history, and separate baselines. This adds no Tuple
allocation, generic/public/foreign ABI, foreign allocation, C/C++, other-
language library, or ABI revision. Future metadata remains independent of
private nodes and offsets. This realizes
`TOPAL-COMPILER-LIST-INT-STRING-PAIR-CORE-001` for increment 4b3d-af.

## TOPAL-COMP-LIST-STRING-INT-PAIR-CORE-001 — Ordinary String/Int-pair Lists

The checked model shall admit construction, private parameter/result/package
and nested Tuple/Record passage, derived equality, complete decisions, count,
emptiness, display, and debugging for `List (String, Int)`. Linux x86-64 shall
retain the existing immutable 24-byte String-pointer/Int-pointer/remaining-
pointer Map-input nodes. A conditional finite fragment shall compare both exact
fields in source order and count correctly at O0. LLVM owns physical placement,
while DWARF/GDB retain the recursive List and positional Tuple classifiers.

Tests cover empty and non-ASCII Strings, arbitrary-precision signed Ints,
same/different fields and length, all private boundaries, rejection, IR,
ELF/DWARF, GDB, corpus, history, and separate baselines. This adds no Tuple
allocation, generic/public/foreign ABI, Map representation change, foreign
allocation, C/C++, other-language library, or ABI revision. Future metadata
remains independent of private nodes and offsets. This realizes
`TOPAL-COMPILER-LIST-STRING-INT-PAIR-CORE-001` for increment 4b3d-ag.

## TOPAL-COMP-LIST-STRING-PAIR-CORE-001 — Ordinary String-pair Lists

The checked model shall admit construction, private parameter/result/package
and nested Tuple/Record passage, derived equality, complete decisions, count,
emptiness, display, and debugging for `List (String, String)`. Linux x86-64
shall use immutable 24-byte String-pointer/String-pointer/remaining-pointer
nodes. A conditional finite fragment shall compare both exact fields in source
order and count correctly at O0. LLVM owns physical placement, while DWARF/GDB
retain the recursive List and positional Tuple classifiers.

Tests cover empty, non-ASCII, and non-Latin Strings, same/different fields and
length, all private boundaries, rejection, IR, ELF/DWARF, GDB, corpus, history,
and separate baselines. This adds no Tuple allocation, generic/public/foreign
ABI, foreign allocation, C/C++, other-language library, or ABI revision. Future
metadata remains independent of private nodes and offsets. This realizes
`TOPAL-COMPILER-LIST-STRING-PAIR-CORE-001` for increment 4b3d-ah.

## TOPAL-COMP-LIST-SEQUENCE-001 — Closed ordered List sequence operations

The checked compiler shall admit the unchanged
`examples/language/list-sequence-operations.t` regression. Over exact finite
`List Int` values it shall implement single-value and List `insert-at`,
`split-at`, `take`, `drop`, indexed `remove`, range and anonymous-predicate
`remove-indexes`, anonymous-predicate `remove-values`, `zip-exact`,
`zip-shortest`, defaulted `zip-longest`, `unzip`, ordered `foreach`, `entries`,
and List identity collection. It shall also admit contextual `List String`
construction and ordered collection to String. Results, source preservation,
entry order, predicate order, and canonical output shall match the interpreter.

The checked model shall retain element, pair, indexed-entry, Result, and String
classifiers. A closed boundary, index, or index range shall be proven against
the retained exact source count before LLVM; an invalid one shall produce
`E-LIST-BOUNDARY-OUT-OF-RANGE`. Dynamic positions shall remain rejected until
the general evidence-dependent Result boundary is implemented. `zip-exact`
shall check counts in generated code and return the formal `out-of-range`
Result in domain `root.zip-exact(List,List)` when they differ. Predicates and
foreach actions shall bind each visited value or zero-based index exactly once,
in source order, at LLVM O0.

The Linux x86-64 backend shall use private immutable nodes selected from the
complete checked element shape: two pointers for Int and String entries, three
pointers for Int pairs, and the target-laid-out indexed-entry record plus its
remaining pointer. It shall use direct LLVM loops and private non-inlined
helpers for copying prefixes, sharing immutable suffixes, zipping, unzipping,
entry construction, and String concatenation. All allocation and output shall
continue through the Topal-owned Linux syscall runtime. LLVM target data layout
shall determine physical alignment; the backend shall hard-code no public
System V aggregate or call boundary. Correctness shall not depend on an LLVM
optimization pass.

DWARF and the bounded GDB renderer shall expose `List Int`, `List String`,
`List (Int, Int)`, `List (index : Int, value : Int)`, and the collected String.
The executable shall have no undefined symbol, needed library, dynamic
relocation, foreign allocator, C/C++ runtime, or other-language standard
library. This increment shall define no public, foreign, serialized,
persistent, generic, or compiled-library List ABI, stabilize no private node
layout, and make no `topal-native/6` revision. Future library metadata shall
encode the recursive List identity, element and product/record classifiers,
checked count evidence, operation and predicate identities, ordering,
fallibility, allocation effects, ownership, native-representation identity,
and target adapters rather than private node offsets or helper symbols. This
realizes `TOPAL-COMPILER-LIST-SEQUENCE-001`, `TOPAL-LIST-BOUNDARY-CHECK-001`
through `TOPAL-LIST-UNZIP-001`, `TOPAL-COLLECTION-FOREACH-001`,
`TOPAL-COLLECTION-ENTRIES-001`, `TOPAL-COLLECTION-COLLECT-LIST-001`, and
`TOPAL-COLLECTION-COLLECT-STRING-001` for compiler increment 5ay.

## TOPAL-COMP-FUNDAMENTAL-CONTAINERS-001 — Closed fundamental containers

The checked compiler shall admit the unchanged
`examples/language/fundamental-containers.t` regression. From an exact finite
`List Int` it shall construct the exact-extent Array, duplicate-eliminating Set,
and multiplicity-preserving Bag. From an exact finite
`List (String, Int)` it shall construct a Map under an explicit `reject`,
`keep-first`, or `keep-last` collision policy. It shall implement generic
`entry-count` and `empty?`, checked static Array indexing, Set membership, Bag
multiplicity, and Map lookup. Results and canonical output shall match the
interpreter without assigning an ordering guarantee to Set, Bag, or Map.

The checked model shall retain the container kind, element/key/value
classifiers, exact Array extent, and Map collision policy. A closed duplicate
key under `reject` shall produce `E-MAP-KEY-COLLISION` before LLVM. A closed
Array index shall be proven nonnegative and exact before lowering; a dynamic
index, dynamically discovered rejected collision, other classifier shape, or
general function boundary shall remain rejected until the necessary runtime
evidence and representation boundary is implemented.

The Linux x86-64 backend shall represent each container by a private immutable
pointer-backed header. Array may retain the source immutable List. Set, Bag,
and Map collectors may mutate only unpublished freshly allocated nodes while
eliminating duplicates, accumulating multiplicities, or resolving collisions;
they shall publish a completely initialized immutable result. Direct LLVM
helpers shall use the canonical exact Int and String operations and Topal-owned
allocation. Correctness at O0 shall not depend on an optimization pass, host
container, callback, indirect dispatch, foreign allocator, C/C++ runtime, or
another language's standard library.

Target-layout-derived DWARF and the bounded validating GDB renderer shall
expose semantic Array, Set, Bag, and Map types and complete values while keeping
node layout private. The executable shall have no undefined symbol, needed
library, or dynamic relocation. This increment shall define no public, foreign,
serialized, persistent, generic, or compiled-library container ABI, stabilize
no private offsets or helper symbols, and make no `topal-native/6` revision.
Future compiled-library metadata shall encode container kind, element/key/value
classifiers, Array extent, equality and collision policy, count/multiplicity/
lookup/index fallibility, ordering guarantees, allocation effects, ownership,
native-representation identity, and target adapters rather than private
layout. This realizes `TOPAL-COMPILER-FUNDAMENTAL-CONTAINERS-001`,
`TOPAL-ARRAY-COLLECT-001`, `TOPAL-SET-COLLECT-001`,
`TOPAL-BAG-COLLECT-001`, `TOPAL-MAP-COLLECT-001`,
`TOPAL-COLLECTION-ENTRY-COUNT-001`,
`TOPAL-COLLECTION-EMPTY-PREDICATE-001`,
`TOPAL-ARRAY-GET-CHECKED-001`, `TOPAL-MAP-LOOKUP-001`,
`TOPAL-SET-CONTAINS-001`, and `TOPAL-BAG-MULTIPLICITY-001` for compiler
increment 5az.

## TOPAL-COMP-TUPLE-RESULT-001 — Private positional-product results

The checked compiler model shall admit an ordinary or static Tuple result when
every recursively nested leaf has an exact supported private representation.
It shall retain the source field order and identities and reject unsupported
leaves rather than inventing a layout or conversion. Record fields admitted by
`TOPAL-COMP-RECORD-BOUNDARY-001` may occur recursively. Function execution and
all field evaluation shall remain correct
at O0 without semantic heap storage, runtime allocation, or optimization.

The Linux x86-64 backend shall lower each admitted result to a recursively
nested, non-packed LLVM literal struct. Definition and calls shall use the same
exact private `fastcc` prototype, with `insertvalue` and `extractvalue` forming
and observing the SSA value while LLVM performs target-specific physical call
lowering. The representation shall remain module-private and shall not become a
stable compiled-library ABI, C ABI, or other foreign interface.

DWARF shall describe the ordered source Tuple with size, alignment, and offsets
derived from the qualified x86-64 data layout. Because the LLVM 22 x86 backend
does not retain a directly described SSA aggregate as an inspectable O0 local,
named Tuple bindings shall use a target-aligned debug-only stack shadow and
`#dbg_declare`. This shall introduce no semantic aggregate storage, runtime,
allocator, foreign dependency, C/C++ runtime, other-language standard library,
or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-TUPLE-RESULT-001` for compiler increment 3b2-b5f.

## TOPAL-COMP-TUPLE-DECISION-001 — Field-wise Tuple control-flow joins

The checked compiler model shall admit a common recursively composed Tuple
result across Boolean, ordered-comparison, `Comparison`, Enum, Optional, and
Result decisions when every leaf has the private representation admitted by
`TOPAL-COMP-TUPLE-RESULT-001`. It shall require identical complete action types
after existing conversions and shall preserve subject-once evaluation, rule
order, and exactly one selected delayed action at O0.

The backend shall recursively join every decomposed machine leaf with a
correctly typed LLVM `phi`, omitting a machine join only for Unit leaves. It
shall not construct an aggregate `phi`, evaluate an unselected action, or add
semantic aggregate storage, heap allocation, a runtime helper, a foreign
dependency, a C/C++ runtime, another-language standard library, or a
`topal-native/6` revision. Records admitted by
`TOPAL-COMP-RECORD-BOUNDARY-001` may occur recursively; unsupported Tuple leaves
shall remain rejected. This realizes `TOPAL-COMPILER-TUPLE-DECISION-001` for
compiler increment 3b2-b5g.

## TOPAL-COMP-TUPLE-PARAMETER-001 — Private positional-product parameters

The checked compiler model shall admit ordinary and static Tuple parameters
when every recursively nested leaf has the exact private representation
admitted by `TOPAL-COMP-TUPLE-RESULT-001`. It shall evaluate the argument once
and preserve interpreter-compatible call normalization: a unary candidate
matches the complete Tuple, a multi-parameter candidate matches its fields in
declaration order, and otherwise-applicable overloads remain source ordered.
It shall admit recursively nested Record fields covered by
`TOPAL-COMP-RECORD-BOUNDARY-001` and reject other unsupported Tuple leaves.

The Linux x86-64 backend shall pass each Tuple parameter as one recursively
nested, non-packed LLVM literal struct. Caller `insertvalue` construction,
callee `extractvalue` decomposition, definition, and calls shall all use the
same exact private `fastcc` prototype while LLVM performs target-specific
physical call lowering. Named Tuple parameters shall have target-exact DWARF
and remain inspectable in GDB at O0 through a target-aligned debug-only stack
shadow and `#dbg_declare`. A discarded Tuple parameter shall retain its
signature slot but shall have no generated decomposition, source binding, or
DWARF variable. This shall add no semantic aggregate storage, heap allocation,
runtime helper, foreign dependency, C/C++ runtime, other-language standard
library, public aggregate ABI, or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-TUPLE-PARAMETER-001` for compiler increment 3b2-b5h.

## TOPAL-COMP-TYPE-VALUE-001 — Closed fundamental Type values

The checked compiler model shall recognize the seven fundamental Type values
defined by `TOPAL-ABSTRACTION-TYPE-VALUE-001`, preserve the enclosing `Type`
classifier and each exact identity, compare only canonical identities, and
retain the values through bindings, decomposed products, and scalar function
boundaries. Canonical display and DWARF/GDB shall expose the source type names.
User-defined Type values and runtime reflection remain explicitly unsupported.

The backend may lower the closed set to private tags, but shall not expose tag
numbers through a public ABI or use them as serialized library-metadata
identities. Future library metadata shall carry canonical semantic identities
independent of this target representation. No registry, allocation, foreign
type-information runtime, C/C++ runtime, other-language standard library, or
`topal-native/6` revision is permitted. This realizes
`TOPAL-COMPILER-TYPE-VALUE-001` for compiler increment 8a.

## TOPAL-COMP-LAYOUT-POLICY-001 — Closed external-layout policy values

The checked compiler model shall recognize `Little` and `Big` as `Endian`;
`ReadWrite`, `ReadOnly`, `WriteOnly`, and `Reserved` as `Access`;
`MostSignificantFirst` and `LeastSignificantFirst` as `BitOrder`; `Natural` and
`Packed` as `Packing`; `Declared` as `FieldOrder`; `AfterTag` and `Overlay` as
`PayloadPlacement`; and `NoLength` and `NoTerminator` as `LayoutPolicy`. It
shall preserve these seven nominal identities and declaration orders through
immutable bindings, decomposed products, same-type equality, canonical output,
DWARF, and GDB. Cross-family equality shall receive a stable checked type
diagnostic.

The Linux x86-64 backend may reuse its private declaration-ordered `i32` enum
tags. The tags shall remain compiler-selected representation rather than
semantic or serialized identities. This increment shall construct no external
layout, encode or serialize no data, designate no location or address, grant no
access authority, and establish no public, foreign, persistent, or compiled-
library ABI. Future library metadata shall use canonical semantic policy and
value identities independently of these tags. The executable shall require no
layout runtime, allocator, foreign dependency, C/C++ runtime, other-language
standard library, needed library, dynamic relocation, or `topal-native/6`
revision. This realizes `TOPAL-COMPILER-LAYOUT-POLICY-001` and
`TOPAL-LAYOUT-ENDIAN-001`, `TOPAL-LAYOUT-ACCESS-001`,
`TOPAL-LAYOUT-BIT-ORDER-001`, `TOPAL-LAYOUT-PACKING-001`,
`TOPAL-LAYOUT-FIELD-ORDER-001`, `TOPAL-LAYOUT-PAYLOAD-PLACEMENT-001`, and
`TOPAL-LAYOUT-ABSENCE-POLICY-001` for compiler increment 7b1.

## TOPAL-COMP-STATIC-INTROSPECTION-001 — Closed static introspection foundation

The checked compiler model shall admit `lang identity` and `lang view` for the
seven directly named closed fundamental v0.1 Type values. It shall retain an
object-kind-tagged canonical identity and a kind-preserving primitive Type-view
value, respectively. `lang context` shall retain `topal`, the active numeric v0.1
Version, and the exact empty feature set. All three result types shall remain
static-only: their bindings shall stay out of the runtime/root environments and
their use or containment at a runtime boundary shall receive a stable checked
diagnostic. Code generation shall erase them without an instruction, local,
DWARF type, descriptor, or executable metadata entry.

For directly named admitted fundamental Type operands, `lang same-object` and
`lang equivalent-type` shall compare canonical semantic identities during
checking and yield ordinary Boolean constants. Runtime operands and unadmitted
object kinds shall be rejected. `lang version` shall produce the ordinary
numeric Version for the active context with immutable Nat `major`, `minor`,
`patch`, and `build` components and canonical abbreviated display.

The Linux x86-64 backend may materialize this initial Version as a private
frame-local four-pointer header over the existing immutable Nat carrier. LLVM
shall own instruction and stack lowering for the target data layout. DWARF and
the bundled validating GDB renderer shall expose the same four-field Version
and canonical source spelling. The linked executable shall have no load-time
relocation, undefined symbol, needed library, reflection/Version runtime,
foreign runtime, C/C++ standard library, public/foreign/serialized/library
Version ABI, or `topal-native/6` revision. General introspection, other object
kinds and relations, later context changes, static-to-runtime conversion, and
Version operations and function boundaries shall remain unsupported. This
realizes `TOPAL-COMPILER-STATIC-INTROSPECTION-001`,
`TOPAL-INTRO-QUALIFIED-001`, `TOPAL-INTRO-STATIC-001`,
`TOPAL-INTRO-VIEW-001`, `TOPAL-INTRO-CONTEXT-001`, and
`TOPAL-INTRO-RELATION-001` for compiler increment 8a3.

## TOPAL-COMP-CAPABILITY-COMPOSE-001 — Closed static Capability composition

The checked compiler model shall recognize the six v0.1 atomic Capability
values `Equality`, `Ordering`, `Foldable`, `Membership`, `Indexed`, and `Keyed`.
It shall retain canonical alternatives of canonical atomic-promise
conjunctions, fold root-scope `and` as their cross-product, fold `or` as their
alternative union, remove duplicates, and validate the explicit `Capability`
classifier. These values shall be static-only. Root binding chains shall retain the
checked metadata, while non-root bindings, aggregate containment, functions and
other machine boundaries, unknown atoms, application, claims, and other
operators shall receive stable checked diagnostics.

Code generation shall erase every Capability binding and discard before LLVM,
including its source name, type, metadata, and debug entry. An exact
source-entry Capability result may emit only its canonical interpreter-matching
text through the existing Topal syscall writer; no Capability machine value may
be formed. LLVM IR and the executable shall contain no capability/evidence
runtime helper, dispatch, table, tag, descriptor, registry, allocation, or
DWARF Capability type. Native artifact tests shall retain zero undefined
symbols, needed libraries, and load-time relocations.

This increment shall add no foreign runtime, C/C++ runtime, other-language
standard library, public/foreign/serialized/library Capability ABI,
compiled-library metadata format, or `topal-native/6` revision. Future library
metadata shall use separately versioned canonical semantic identities rather
than any target representation. This realizes
`TOPAL-COMPILER-CAPABILITY-COMPOSE-001`,
`TOPAL-CAPABILITY-EVIDENCE-001`, `TOPAL-CAPABILITY-COHERENCE-001`, and
`TOPAL-CAPABILITY-COMPOSE-001` for compiler increment 8a4.

## TOPAL-COMP-FUNCTION-INTERFACE-001 — Closed direct function-interface conformance

For source-root v0.1 interfaces containing only uniquely named ordinary
function shapes over already admitted private native parameter and result
classifiers, the checked compiler shall retain the nominal `root.Name`
identity and canonical operation name/input/result metadata. A following
direct construction shall be validated before function collection and shall
provide exactly one ordinary function declaration for each role, with no
missing, additional, duplicate, or mismatched operation. Successful evidence
shall map each canonical role to its overload-qualified root declaration
identity and its optional explicit empty declared effect bound. An absent bound
shall remain absent rather than being mislabeled as inferred evidence for an
unchecked body.

Only the selected ordinary declarations shall enter LLVM, using the existing
direct module-private `fastcc` calls and LLVM-owned target argument lowering.
Interface shapes and evidence shall produce no instruction, value, namespace,
vtable, function pointer, indirect call, dispatcher, tag, descriptor,
allocation, symbol, relocation, DWARF type, or DWARF variable. DWARF/GDB shall
still expose the implementation subprogram, String parameter, source line,
direct caller frame, and canonical value. Native tests shall cover the shared
interpreter regression, exact model evidence, unknown/missing/additional/
duplicate/mismatched rejection, direct IR, exact output, undefined symbols,
needed libraries, relocations, metadata erasure, DWARF erasure, and GDB.

This increment shall add no foreign runtime, C/C++ runtime, other-language
standard library, public/foreign/serialized interface ABI, native-artifact
export/evidence claim, compiled-library metadata format, or `topal-native/6`
revision. Future compiled libraries shall publish these semantic identities,
shapes, effects, and declaration mappings through a separately versioned and
validated schema rather than reuse `fastcc`, LLVM types, private symbols, or
target layouts. Packaged/dynamic implementations, generators, non-root/message
contexts, v0.2 contracts, and cross-library consumption remain rejected. This
realizes `TOPAL-COMPILER-FUNCTION-INTERFACE-001`,
`TOPAL-INTERFACE-SHAPE-001`, and `TOPAL-INTERFACE-IMPLEMENTATION-001` for
compiler increment 8a5.

## TOPAL-COMP-PATTERN-001 — Positional product and discard inputs

For an admitted ordinary function with multiple scalar parameters, a prefix
application containing one positional product shall validate and pass its
fields as the declared parameter sequence in left-to-right order. Overload
selection shall use the complete flattened sequence without re-evaluating any
field.

A typed `_` parameter shall validate its argument classifier and occupy its
private machine-signature position but introduce no checked source binding,
generated-value binding, or DWARF variable. Other parameters retain their
source argument ordinals in debug information.

This requirement covers the admitted function-input case of
`TOPAL-TYPE-MATCH-001` and realizes `TOPAL-COMPILER-PATTERN-001` for compiler
increment 3b2-b3.

## TOPAL-COMP-OPTIONAL-001 — Optional values and control flow

The compiler shall construct `Some` and explicit or immediately contextual
`None` values for the admitted `Optional Int` and `Optional String` subset,
retain the nominal payload classifier through classified bindings and ordinary
function parameters/results, and preserve the value through a direct return or
machine-scalar decision join. The representation shall be an immutable opaque
pointer with its own validated Optional tag semantics under `topal-native/6`;
it shall not be reclassified as Result or exposed to a foreign aggregate ABI.

An Optional decision shall evaluate its subject once, load and bind a present
payload only in the selected `Some` action, execute only the selected action,
and require `Some` plus `None` coverage or a final `otherwise`. `Optional Int`
shall implement derived equality using canonical arbitrary-precision Int
equality. `Optional String` shall implement derived equality using exact
preserved-sequence String equality.

Construction, display, function passage, decisions, equality, DWARF, and GDB
shall use the same private header and Linux syscall-backed allocator without a
C/C++ runtime, standard library, load-time pointer relocation, or runtime type
lookup. This requirement covers `TOPAL-TYPE-OPTIONAL-CONSTRUCT-001`,
`TOPAL-TYPE-OPTIONAL-CONTEXT-001`, `TOPAL-TYPE-OPTIONAL-BOUNDARY-001`,
`TOPAL-DECISION-OPTIONAL-001`, and the admitted Int- and String-payload cases of
`TOPAL-TYPE-OPTIONAL-EQUALITY-001`. It realizes
`TOPAL-COMPILER-OPTIONAL-001` for compiler increment 3b2-b4.

## TOPAL-COMP-OPTIONAL-RATIONAL-001 — Exact Optional Rational values

The compiler shall extend the existing native Optional construction, contextual
absence, function passage and result, direct return, control-flow join,
decision, display, DWARF, and GDB paths to the admitted `Optional Rational`
payload. It shall preserve the existing opaque Optional header and the existing
canonical Rational payload pointer under `topal-native/6`, without a new public
aggregate, runtime type lookup, C/C++ runtime, standard library, or ABI revision.

Derived equality shall validate both Optional alternatives and call the exact
canonical Rational comparator only when both are `Some`; it shall not load an
absent payload. The equality shall also be available recursively to admitted
same-classifier positional-product equality. This requirement covers the
Rational-payload cases of `TOPAL-TYPE-OPTIONAL-CONSTRUCT-001`,
`TOPAL-TYPE-OPTIONAL-CONTEXT-001`, `TOPAL-TYPE-OPTIONAL-BOUNDARY-001`,
`TOPAL-DECISION-OPTIONAL-001`, and `TOPAL-TYPE-OPTIONAL-EQUALITY-001`. It
realizes `TOPAL-COMPILER-OPTIONAL-RATIONAL-001` for compiler increment
3b2-b4a.

## TOPAL-COMP-TUPLE-EQUALITY-001 — Derived positional-product equality

The compiler shall admit equality and inequality between same-classifier
positional products exactly when every field has an admitted canonical equality
lowering. The admitted recursive field set is Unit, Completed, Boolean, Int,
Nat, Rational, Comparison, ErrorCode, Character, String, payload-free source
Enum, `Optional Int`, `Optional Rational`, `Optional String`, and another
admitted positional product.
Both complete operands shall be evaluated once from left to right before their
corresponding fields are recursively compared, and inequality shall negate the
same all-fields-equal result.

An expression-local product shall remain a compiler aggregate of field values;
comparison shall require no allocation, runtime product header, or foreign
aggregate ABI. Canonical field conversion, general product passage across
machine signatures, and equality for further field classifiers remain outside
this increment and shall be rejected at the checked boundary. This requirement
covers the admitted same-classifier positional-product case of
`TOPAL-TYPE-EQUALITY-001` and realizes
`TOPAL-COMPILER-TUPLE-EQUALITY-001` for compiler increment 3b2-b5a.

## TOPAL-COMP-RECORD-001 — Anonymous record construction and selection

The checked compiler model shall admit anonymous products whose fields are all
labeled as structural Records under `TOPAL-TYPE-PRODUCT-001`. It shall reject a
duplicate label with `E-DUPLICATE-RECORD-FIELD`, evaluate field expressions once
from left to right, retain source order for canonical display, and retain a
canonical label-to-classifier map for static identity. Static field selection
shall return the selected already-evaluated field with its exact classifier and
shall diagnose an absent label with `E-NO-SUCH-RECORD-FIELD` at that label.

Expression-local Records shall lower as decomposed LLVM values without an
allocation, native header, generated record runtime, C/C++ runtime, standard
library, or ABI revision. `TOPAL-COMP-RECORD-BOUNDARY-001` separately admits
private aggregate function passage, control-flow joins, and truthful debug-only
storage. Persistent semantic Record storage remains rejected. This requirement
realizes `TOPAL-COMPILER-RECORD-001` for compiler increment 3b2-b5b.

## TOPAL-COMP-RECORD-BOUNDARY-001 — Order-preserving private Record boundaries

The checked compiler model shall parse and retain closed structural Record
classifiers on ordinary and static parameters and results. It shall compare
classifiers by canonical label-to-type maps, recursively admit Tuple and Record
fields with exact private representations, preserve each value's independent
construction order, evaluate an argument once, and retain source-ordered
candidate selection.

The Linux x86-64 backend shall lower each admitted Record boundary to one
non-packed LLVM literal struct. Values shall appear in canonical label order,
followed by one `i32` canonical-field index per source display position. Caller
`insertvalue`, callee `extractvalue`, results, definitions, and calls shall use
the same exact private `fastcc` type while LLVM performs target-specific
physical call lowering. Every admitted decision family shall join canonical
fields recursively and order indexes individually with LLVM `phi` nodes, with
no aggregate `phi` or eager action execution.

DWARF shall expose semantic named fields at target-derived offsets and account
for the private order suffix in the complete size without inventing source
members. Named Record bindings and parameters shall remain inspectable in GDB
at O0 through a target-aligned debug-only stack shadow and `#dbg_declare` where
needed. This shall add no persistent semantic aggregate storage, heap
allocation, Record runtime helper, foreign dependency, C/C++ runtime,
other-language standard library, public aggregate ABI, or `topal-native/6`
revision. This realizes `TOPAL-COMPILER-RECORD-BOUNDARY-001` for compiler
increment 3b2-b5i.

## TOPAL-COMP-STRUCTURAL-COMPARISON-001 — Derived structural comparison

The checked compiler model shall derive Tuple total ordering recursively when
every corresponding field has admitted ordering. It shall evaluate both
complete operands once from left to right, apply canonical Int/Nat/Rational
conversion per field, and lower lexicographic comparison so later field
comparisons execute only after every preceding field compares Equal. The same
three-way result shall drive `<`, `>`, `<=`, `>=`, and `<=>`.

The compiler shall derive anonymous Record equality and inequality for the same
canonical label set when corresponding label values have admitted equality. It
shall align fields by label independently of construction order and apply
admitted canonical field conversions. Different shapes or unsupported field
pairs shall produce `E-NO-APPLICABLE-OVERLOAD`; conversions hidden in a
non-decomposable aggregate shall remain explicitly unsupported.

LLVM lowering shall reuse decomposed Tuple and Record values, existing exact
comparators, `br`, and `phi`, without aggregate allocation, a structural runtime,
C/C++ runtime, standard library, or native ABI revision. Boolean and Comparison
results shall reuse their existing DWARF/GDB paths. This requirement covers the
admitted structural cases of `TOPAL-TYPE-EQUALITY-001`,
`TOPAL-TYPE-ORDERING-001`, and `TOPAL-NUM-INT-RATIONAL-CONVERT-001`; it realizes
`TOPAL-COMPILER-STRUCTURAL-COMPARISON-001` for increment 3b2-b5c.

## TOPAL-COMP-RECONSTRUCT-001 — Immutable record reconstruction

The checked compiler model shall admit `with` reconstruction of a structural
Record under `TOPAL-TYPE-RECONSTRUCT-001`. It shall evaluate the complete base
once before replacements, then evaluate replacements once from left to right.
Each replacement label shall be unique and present in the base, and its value
shall retain the original field classifier after any admitted exact canonical
conversion. The result shall preserve the base field order and unreplaced
values without changing the original Record.

LLVM lowering shall replace named values in the existing decomposed Record and
shall introduce no allocation, generated reconstruction runtime, public ABI,
C/C++ runtime, or standard-library dependency. Existing scalar DWARF values
projected from the original and reconstructed Records shall remain inspectable;
the compiler shall continue to omit the nonexistent aggregate storage from
DWARF. The compiler shall retain the interpreter diagnostics
`E-RECONSTRUCT-NON-RECORD`, `E-DUPLICATE-RECONSTRUCTION-FIELD`,
`E-NO-SUCH-RECORD-FIELD`, and `E-TYPE-MISMATCH` at the checked boundary. This
requirement realizes `TOPAL-COMPILER-RECONSTRUCT-001` for increment 3b2-b5d.

## TOPAL-COMP-STRING-UTF8-BYTE-COUNT-001 — Prospective UTF-8 byte count

For an admitted plain String, the compiler shall evaluate
`text byte-count Utf8` once, load the preserved UTF-8 byte length from the
immutable native descriptor, and return the equal canonical arbitrary-
precision Int. The operation shall neither use the cached display spelling nor
modify, normalize, encode, or reclassify the String.

The runtime shall convert the complete unsigned target length to normalized
base-2^32 Int limbs without truncation, a fixed source-value width, or a
foreign conversion helper. It shall allocate only through the Linux syscall
platform boundary and introduce no C/C++ runtime or standard-library
dependency. This requirement covers `TOPAL-TYPE-CALL-001` and
`TOPAL-STRING-UTF8-BYTE-COUNT-001`; it realizes
`TOPAL-COMPILER-STRING-UTF8-BYTE-COUNT-001` for compiler increment 4a.

## TOPAL-COMP-STRING-EQUALITY-001 — Exact String equality

The compiler shall evaluate each admitted String equality operand once and
compare the complete preserved Unicode sequence. Its valid UTF-8 native
representation shall implement this by comparing the stored preserved-byte
lengths and then corresponding bytes in order, without inspecting display
spelling, normalizing either operand, consulting locale state, or calling a
foreign String routine.

Derived `Optional String` equality shall validate both Optional alternatives,
compare payloads only when both are `Some`, make two `None` alternatives equal,
and make different alternatives unequal without loading an absent payload.
Inequality shall be the Boolean negation of the same equality result. This
requirement covers the String case of `TOPAL-TYPE-EQUALITY-001` and the admitted
String-payload case of `TOPAL-TYPE-OPTIONAL-EQUALITY-001`; it realizes
`TOPAL-COMPILER-STRING-EQUALITY-001` for compiler increment 4b1.

## TOPAL-COMP-STRING-CONSTRUCTION-001 — String construction and emptiness

The compiler shall construct the unique empty plain String value and compose
adjacent source literal primaries into one preserved sequence as required by
the frontend semantics. Dynamic plain concatenation shall evaluate operands
once from left to right, send target-length overflow through the explicit
platform storage-failure path, allocate exact byte storage through the Linux
syscall platform, and copy both valid UTF-8 sequences in order without
normalization or content changes. The copy intrinsic shall guarantee no
external-function lowering. A zero-length result shall not depend on a
zero-length mapping.

String emptiness shall read the preserved-byte length and return true exactly
for the empty sequence. A dynamic descriptor may omit the literal display cache;
the runtime shall then emit the canonical ordinary or shortest collision-free
tagged spelling directly from preserved bytes. Compiled output and the GDB
renderer shall agree, including values containing quote-and-tag collisions.
These operations shall not use a C/C++ runtime, standard library, foreign
allocator, locale, or Unicode transformation routine.

This requirement covers `TOPAL-TYPE-CALL-001`, `TOPAL-STRING-EMPTY-001`,
`TOPAL-STRING-LITERAL-COMPOSE-001`, `TOPAL-STRING-CONCAT-001`, and
`TOPAL-STRING-EMPTY-PREDICATE-001`; it realizes
`TOPAL-COMPILER-STRING-CONSTRUCTION-001` for compiler increment 4b2.

## TOPAL-COMP-CHARACTER-001 — Retained static Character evidence

For a closed String expression known to the checked model, the compiler shall
use the selected language context's pinned Unicode segmentation to admit the
Character constraint exactly when the preserved sequence has one extended
grapheme cluster. It shall report `E-CHARACTER-CLASSIFIER` with the observed
count for a closed invalid value. Dynamic validation shall remain rejected at
the checked boundary until its explicit Result and freestanding runtime path
are implemented.

Character bindings and ordinary function parameters/results shall retain their
classifier, while explicit or implicit forgetting to String shall emit no
conversion and preserve every scalar. Character equality and derived product
field equality shall call the existing exact String comparator. DWARF shall
expose a distinct Character typedef over the same immutable String descriptor,
and the GDB renderer shall display its preserved sequence. This requirement
covers `TOPAL-TYPE-CONSTRAINT-VALIDATE-001`,
`TOPAL-STRING-CHARACTER-CLASSIFIER-001`,
`TOPAL-STRING-FROM-CHARACTER-001`, and the Character case of
`TOPAL-TYPE-EQUALITY-001`; it realizes `TOPAL-COMPILER-CHARACTER-001` for
compiler increment 4b3a without a C/C++ runtime, standard library, foreign
Unicode implementation, or `topal-native/6` revision.

## TOPAL-COMP-CHARACTER-OBSERVATION-001 — Closed Character observations

For a String whose complete preserved sequence is known to the checked model,
the compiler shall evaluate `character-count` and String `entry-count` with the
selected context's pinned extended-grapheme segmentation and materialize the
equal canonical arbitrary-precision Int. When an exact Int index is also known,
it shall evaluate `character-at` with that same segmentation and materialize an
`Optional Character`: the complete cluster in `Some`, or `None` for a negative
or out-of-range index.

The fold shall be mandatory frontend semantics for this admitted subset at
`-O0`, independent of LLVM optimization. A produced `Optional Character` shall
reuse the existing private Optional header and immutable String-descriptor
payload through ordinary function passage, decisions, display, DWARF, and GDB.
General Optional-Character construction/equality and dynamic String or index
observations remain rejected until reusable constraint evidence and a
Topal-owned freestanding Unicode runtime are implemented.

This requirement covers `TOPAL-STRING-CHARACTER-COUNT-001`,
`TOPAL-STRING-ENTRY-COUNT-001`, `TOPAL-STRING-CHARACTER-AT-001`,
`TOPAL-TYPE-OPTIONAL-BOUNDARY-001`, and `TOPAL-DECISION-OPTIONAL-001`; it
realizes `TOPAL-COMPILER-CHARACTER-OBSERVATION-001` for compiler increment
4b3b without a C/C++ runtime, standard library, host locale or Unicode table,
or `topal-native/6` revision.

## TOPAL-COMP-STRING-CHARACTERS-FOREACH-001 — Closed Character traversal

The checked compiler shall admit a root `foreach` directly over `characters
text` when the complete plain String is known during checking and the action is
capture-free, binds Character, and produces Unit. It shall evaluate the source
String exactly once, use the selected language context's pinned extended-
grapheme segmentation, invoke the action once per complete Character in
preserved order, resume with Unit after each
action, and return Unit without invoking the action for empty input. The source
String shall remain immutable. The statement may bind its Unit result with an
optional exact Unit classifier or leave the result unnamed.

The Linux x86-64 backend shall expand the statically known Character sequence
through existing immutable String descriptors and inline the checked action in
order. This is mandatory O0 source-semantic lowering, not an optimization-pass
result. DWARF/GDB shall preserve the Character action binding, including a
debug-only pointer shadow for an otherwise instruction-free action. The
lowering shall create no semantic traversal collection, Generator object or
token, generic Generator runtime, callback, indirect call, host Unicode or
locale dependency, C/C++ runtime, other-language standard library, needed
library, dynamic relocation, public/library Generator ABI, or
`topal-native/6` revision. Dynamic Strings, function-returned Character
generators outside `TOPAL-COMP-STRING-CHARACTERS-RESULT-001`, other
non-specializable Character generators, and captures remain rejected. Future
library metadata shall carry canonical Generator, pinned-segmentation,
action-evidence, ownership, and target-adapter identities rather than this
specialization. This realizes
`TOPAL-COMPILER-STRING-CHARACTERS-FOREACH-001`,
`TOPAL-STRING-CHARACTERS-COLLECT-001`, and
`TOPAL-STRING-CHARACTERS-FOREACH-001` for compiler increment 4b3d-k.

## TOPAL-COMP-STRING-CHARACTERS-GENERATOR-001 — Named closed traversal

The checked compiler shall admit `characters text` as an exact
`Generator Character Unit Unit` when the complete plain String is known. A root
binding may state that classifier and shall evaluate the source String exactly
once while creating a fresh linear value. The checked model may retain the
pinned ordered Character sequence as compile-session provenance, but
construction shall invoke no action and the generated observation token shall
not serve as continuation state.

Root foreach shall transfer one locally bound value into the existing closed
Character traversal, preserve its action order and Unit result, and mark the
source consumed. Later source use shall report `E-GENERATOR-CONSUMED` rather
than copy or restart the traversal. Unconsumed root bindings shall remain
rejected; the narrow transferred-parameter close is governed by
`TOPAL-COMP-STRING-CHARACTERS-CLOSE-001`. DWARF/GDB shall describe the local
binding as `Generator Character Unit Unit` through a compiler-private token.

The token and compiler-held provenance shall require no Generator object,
continuation-state allocation, generic Generator runtime, callback, indirect
call, host Unicode/locale dependency, C/C++ runtime, other-language standard
library, needed library, dynamic relocation, public/library Generator ABI, or
`topal-native/6` revision. General function result transfer outside
`TOPAL-COMP-STRING-CHARACTERS-RESULT-001`, general parameter use, and external
boundaries remain rejected pending canonical Generator, segmentation,
operation/evidence, ownership, close, and target-adapter metadata. This realizes
`TOPAL-COMPILER-STRING-CHARACTERS-GENERATOR-001`,
`TOPAL-STRING-CHARACTERS-COLLECT-001`,
`TOPAL-STRING-CHARACTERS-FOREACH-001`,
`TOPAL-STRING-CHARACTERS-GENERATOR-001`,
`TOPAL-STRING-CHARACTERS-CLASSIFIER-001`, and
`TOPAL-STRING-CHARACTERS-LINEAR-001` for compiler increment 4b3d-l.

## TOPAL-COMP-STRING-CHARACTERS-COLLECT-001 — Closed String reconstruction

The checked compiler shall admit direct `characters text collect String` when
the complete plain String is known. It shall evaluate `text` exactly once,
retain the selected language context's pinned ordered Character segmentation
as checking evidence, consume the fresh traversal, and return a plain String
with exactly the source's preserved scalar sequence. Empty input shall return
`empty String`.

The Linux x86-64 backend may forward the existing immutable source String
descriptor because this exact unchanged traversal reconstructs that source.
This shall be mandatory O0 semantic lowering, not an LLVM optimization or a
rule for transformed traversals. DWARF/GDB shall expose the result as String.

The lowering shall create no intermediate List or Generator object,
concatenation loop, generic traversal runtime, callback, indirect call, host
Unicode/locale dependency, C/C++ runtime, other-language standard library,
needed library, dynamic relocation, public/library Generator ABI, or
`topal-native/6` revision. Dynamic Strings, transformed traversals, stored
Generator collection, and external boundaries remain rejected pending
generated Topal Unicode support and canonical traversal, operation/evidence,
ownership, and target-adapter metadata. This realizes
`TOPAL-COMPILER-STRING-CHARACTERS-COLLECT-001` and
`TOPAL-STRING-CHARACTERS-COLLECT-001` for compiler increment 4b3d-m.

## TOPAL-COMP-STRING-CHARACTERS-CLOSE-001 — Owned parameter close

The checked compiler shall admit an ordinary called function with exactly one
named `Generator Character Unit Unit` parameter, a Unit result, and a
statement-free Unit body that leaves the parameter untraversed. Passing a
locally bound closed Character generator shall transfer and consume the caller
binding. Function exit shall deliver intrinsic close to that owned built-in
continuation and return Unit without another yield. The checked model shall
retain an explicit close operation.

Because the admitted built-in representation allocates no continuation object
or live state, Linux x86-64 code generation shall lower close to no runtime
action after accepting the compiler-private observation token. The private
function shall use LLVM `fastcc` for the `i32` token rather than hard-coded
System V register placement. DWARF/GDB shall expose the Generator parameter
through debug-only storage when no semantic instruction preserves its location.

The specialization shall add no generic Generator runtime, close dispatcher,
allocation, callback, indirect call, unwind dependency, C/C++ runtime,
other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Return of the parameter, traversal beyond
`TOPAL-COMP-STRING-CHARACTERS-PARAMETER-001`, multiple/additional parameters,
static functions, general close handling, and external boundaries remain
rejected pending canonical Generator classifier, state, ownership,
close-domain/provenance, and target-adapter metadata. This realizes
`TOPAL-COMPILER-STRING-CHARACTERS-CLOSE-001` and
`TOPAL-STRING-CHARACTERS-CLOSE-001`, plus the applicable ownership-transfer
obligations of `TOPAL-STRING-CHARACTERS-GENERATOR-001` and
`TOPAL-STRING-CHARACTERS-PARAMETER-001`, for compiler increment 4b3d-n.

## TOPAL-COMP-STRING-CHARACTERS-PARAMETER-001 — Specialized parameter traversal

The checked compiler shall admit an ordinary called function with exactly one
named `Generator Character Unit Unit` parameter and a Unit result when its
executable body is exactly one foreach over that parameter with a capture-free
Character-to-Unit action. The top-level call argument shall be a locally bound
closed Character generator with retained provenance, and the call shall
transfer and consume the caller binding once.

Each call shall create a private specialization receiving only that argument's
pinned ordered Character sequence in compile-session provenance. The caller
shall evaluate the source String once. The callee shall expand the action once
per Character in order, resume with Unit, exhaust the continuation, and return
Unit without close delivery. Distinct calls shall not share their retained
sequences.

The Linux x86-64 private function shall accept the existing `i32`
observation/ownership token through LLVM `fastcc`, without using it as cursor or
continuation state or hard-coding System V register placement. DWARF/GDB shall
expose the Generator parameter and Character binding.

The specialization shall add no Generator object/runtime, state allocation,
dispatcher, callback, indirect call, host Unicode/locale dependency, C/C++
runtime, other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Dynamic/transformed provenance, general function results outside
`TOPAL-COMP-STRING-CHARACTERS-RESULT-001`, multiple/additional parameters,
nested calls, other bodies, and external boundaries remain rejected pending
canonical Generator, segmentation, action-evidence, ownership, and
target-adapter metadata. This realizes
`TOPAL-COMPILER-STRING-CHARACTERS-PARAMETER-001`,
`TOPAL-STRING-CHARACTERS-FOREACH-001`, and the relevant transfer obligations of
`TOPAL-STRING-CHARACTERS-GENERATOR-001` and
`TOPAL-STRING-CHARACTERS-PARAMETER-001` for compiler increment 4b3d-o.

## TOPAL-COMP-STRING-CHARACTERS-RESULT-001 — Specialized function result

The checked compiler shall admit an ordinary nonrecursive called function with
exactly one named String parameter and result classifier
`Generator Character Unit Unit` when its body has no statements and returns
exactly `characters parameter`. Its top-level call argument shall have a closed
exact String value. Function exit shall transfer the fresh continuation without
close delivery, and the caller shall bind and consume the result exactly once
through an admitted Character traversal.

Every call shall create a distinct private specialization. The compiler shall
retain that argument's pinned ordered Character sequence beside its private
symbol only for checking. The caller shall evaluate the String once; the callee
shall observe its existing immutable descriptor and return the existing private
Generator token; caller traversal shall receive only that call's sequence.

On Linux x86-64, LLVM `fastcc` shall select the private String argument and
`i32` Generator-result placement without hard-coded System V registers.
DWARF/GDB shall expose the String parameter, Generator result classifier/value,
caller Character binding, and call frames.

The specialization shall add no Generator object/runtime, state allocation,
dispatcher, callback, indirect call, host Unicode/locale dependency, C/C++
runtime, other-language standard library, needed library, dynamic relocation,
public/library calling convention or Generator ABI, or `topal-native/6`
revision. Dynamic/transformed arguments, anonymous/static/recursive/nested or
multi-parameter functions, other result bodies, unbound results, general close
handling, and external boundaries remain rejected pending canonical Generator,
segmentation, construction evidence, ownership, close, and target-adapter
metadata. This realizes `TOPAL-COMPILER-STRING-CHARACTERS-RESULT-001`,
`TOPAL-STRING-CHARACTERS-RESULT-001`, and the relevant linear/traversal
obligations of `TOPAL-STRING-CHARACTERS-GENERATOR-001` and
`TOPAL-STRING-CHARACTERS-FOREACH-001` for compiler increment 4b3d-p.

## TOPAL-COMP-UNICODE-FOLD-001 — Closed pinned-Unicode operations

When the checked model knows a String's complete preserved sequence, the
compiler shall evaluate universal `upper`, `lower`, full `case-fold`, NFC
normalization, and NFD normalization through the selected language context's
pinned Unicode implementation. It shall materialize the exact plain String
result without changing the source value. It shall also evaluate closed
`canonically-equals` operands through the same pinned data and materialize the
normative Boolean without normalizing either operand in place.

This frontend evaluation shall be mandatory at `-O0` and independent of LLVM
optimization. Result Strings shall use the existing immutable descriptor and
debug/display paths. Dynamic operands shall remain rejected until a Topal-owned
freestanding Unicode runtime is implemented; the binary shall gain no host
Unicode table, locale service, C/C++ runtime, standard library, or native ABI
revision.

This requirement covers `TOPAL-STRING-UPPER-001`, `TOPAL-STRING-LOWER-001`,
`TOPAL-STRING-CASE-FOLD-001`, `TOPAL-STRING-NORMALIZE-NFC-001`,
`TOPAL-STRING-NORMALIZE-NFD-001`, and
`TOPAL-STRING-CANONICAL-EQUALITY-001`; it realizes
`TOPAL-COMPILER-UNICODE-FOLD-001` for compiler increment 4b3c.

## TOPAL-COMP-RANGE-001 — Finite exact ranges

The compiler shall represent explicitly bounded finite `Range Int` and
`Range Rational` values as immutable opaque handles retaining exact lower and
upper endpoint objects and canonical Boolean inclusivity states. It shall
implement all four range constructors, canonical mixed endpoint conversion,
classification, ordinary function passage and decision joins, both membership
operand orders, same-domain intersection, emptiness, bound and inclusivity
observation, source-form output, and GDB inspection.

Range lowering shall not enumerate members, normalize open endpoints by
arithmetic, expose the private header to a foreign calling convention, require
a C/C++ runtime, or introduce load-time pointer relocations. Unbounded forms
and collection selection remain outside this increment. Exact Int and Rational
infinity endpoints are admitted only under `TOPAL-COMP-INFINITY-001`.

This requirement covers `TOPAL-RANGE-BOUNDS-001`,
`TOPAL-RANGE-MEMBERSHIP-001`, `TOPAL-RANGE-RATIONAL-001`,
`TOPAL-RANGE-CLASSIFIER-001`, `TOPAL-RANGE-INTERSECTION-001`,
`TOPAL-RANGE-EMPTY-001`, and `TOPAL-RANGE-BOUND-001`. It realizes
`TOPAL-COMPILER-RANGE-001` for compiler increment 2d-a.

## TOPAL-COMP-INFINITY-001 — Contextual exact infinities

The checked compiler shall admit immediate root bindings classified as `Int`
with either exact infinity and as `Nat` with positive infinity. It shall retain
the source classifier and direction and admit canonical output, equality,
ordered predicates, three-way comparison, and explicitly bounded `Range Int`
construction, membership, intersection, emptiness, and bound observation. The
same closed root scope shall admit either infinity classified as `Rational`,
the corresponding comparisons and `Range Rational` operations, plus the
canonical embedding of a finite Int comparison value or endpoint. Bare
constants, negative Nat infinity, implicit cross-domain Int/Rational infinity
conversion, and persistent, serialized, public, and compiled-library infinity
boundaries shall remain explicitly unsupported. Specialized executable-private
non-recursive functions shall admit exact Int, Nat, and Rational infinity
parameters/results and captured environments, including recursively
corresponding Tuple and Record fields. Checked specialization shall retain the
domain and direction evidence through each admitted boundary so arithmetic
remains subject to static indeterminate rejection. Recursive infinity entry
shall remain explicitly unsupported until its generalized dynamic arithmetic
contract is implemented.
Closed root-scope negation, absolute value, addition, subtraction, and
multiplication shall admit the statically proved total cases of
`TOPAL-NUM-INFINITY-ARITHMETIC-001`; statically evident indeterminate cases
shall be diagnostics. When one infinity is multiplied by a finite factor whose
zero-ness is dynamic, the existing arithmetic Result ABI shall return code
`indeterminate` with source provenance for zero and the correctly signed
infinity for nonzero. Other dynamic indeterminate Results, division,
remainder, power, and directional-zero arithmetic remain explicitly
unsupported.

The Linux x86-64 backend may lower these values to immutable
executable-private Int sentinels carrying reserved positive- and negative-
infinity tags with zero limbs. A sentinel or validated Rational wrapper may
cross only an LLVM-internal specialized function signature; public and foreign
signatures remain forbidden, so the finite Int representation and
`topal-native/6` function ABI remain unchanged. Runtime unary arithmetic,
addition, subtraction, multiplication, comparison, zero testing, and output
shall branch on the sentinel before finite sign, length, or limb handling.
Dynamic multiplication helpers shall validate the infinity operand before
Result construction, and a violated checked invariant shall fail closed. The
backend shall append those helpers only when the checked program contains this
fallible operation; unrelated O0 programs shall not compile or carry them. The
existing opaque Range pointer representation shall retain the endpoints. All
behavior shall be mandatory at O0 and use only the Topal-owned Linux syscall
runtime, without a
C/C++ runtime, other-language standard library, foreign allocator, undefined
helper, needed library, dynamic relocation, public ABI, or native ABI revision.

A Rational infinity shall use a run-time-constructed private Rational header
whose numerator is the matching Int sentinel and whose denominator is canonical
one. Rational construction, arithmetic normalization, comparison, display, and
debugging shall validate the sentinel/wrapper invariant before finite
greatest-common-divisor or cross-multiplication logic. Construction at run time
shall preserve the no-loader static-PIE relocation invariant; the finite
Rational representation and machine ABI remain unchanged.

DWARF and the bounded validating GDB renderer shall expose truthful `Int`,
`Nat`, `Rational`, `Range Int`, and `Range Rational` source values and reject
malformed sentinel or Rational-wrapper state.
Tests shall use shared interpreter regressions, compare exact output, inspect
checked and LLVM lowering, validate the complete corpus,
freestanding ELF, DWARF and GDB, and record separate interpreter execution plus
compiler build/run resource baselines. Future compiled-library metadata shall
describe language and numeric-domain revisions, infinity direction,
constraints, operations and indeterminate failures, ownership, debug
provenance, and native adapters independently of LLVM types, tags, headers, and
symbols. This realizes `TOPAL-COMPILER-INFINITY-001`,
`TOPAL-NUM-INFINITY-001`, `TOPAL-NUM-INFINITY-ARITHMETIC-001`, the infinity cases of `TOPAL-NUM-NAT-001`,
`TOPAL-NUM-COMPARE-001`, `TOPAL-NUM-THREE-WAY-COMPARE-001`, and the applicable
`TOPAL-RANGE-*` rules for compiler increments 2c-c1 through 2c-c5, 2d-b1, and
2d-b2.

## TOPAL-COMP-DECISION-001 — Comparison decisions

The compiler shall lower ordered comparison-matcher tables over admitted exact
numeric subjects to explicit source-ordered control flow with one subject
evaluation, branch-local matcher operand evaluation, first-match selection, a
required final `otherwise`, and one selected action. It shall also lower
complete decisions over the closed `Comparison` alternatives `Less`, `Equal`,
and `Greater`. Compatible machine-scalar action values shall merge through
typed SSA values.

Mixed Int/Rational matcher operands shall use the same canonical conversion as
ordinary exact comparisons. Lowering shall not evaluate a later matcher or any
unselected action and shall not call a runtime decision dispatcher.

This requirement covers `TOPAL-DECISION-COMPARISON-001`,
`TOPAL-DECISION-OPERAND-EXPRESSION-001`, and the language-defined `Comparison`
case of `TOPAL-DECISION-ENUM-001`. It realizes
`TOPAL-COMPILER-DECISION-001` for compiler increment 2c-a.

## TOPAL-COMP-CONSTRAINT-VALUE-001 — Named constraint observation values

The checked compiler model shall admit root named constraints over supported
primitive bases and retain the name, base classifier, predicate parameter, and
checked Boolean predicate as semantic metadata. A separately named root binding
classified as `Constraint` shall receive its binding identity while retaining
the source constraint's base and predicate. Captures shall be diagnosed as
unsupported rather than silently erased.

LLVM lowering shall carry only a deterministic module-private i32 identity tag,
with matching canonical `<Constraint name>` output and `Constraint` DWARF
enumerators. Native and GDB tests shall cover constructed and classified-copy
identities, checked Boolean result, exact shared-interpreter output, undefined
symbols, needed libraries, relocations, local types, values, and source frame.
The tag shall not dispatch the predicate or become a public ABI/library key.

Constraint application/evidence, capturing predicates, function or
persistent/public aggregate machine boundaries, and public compiled-library
constraint identities remain rejected. This shall add no allocation, constraint
runtime, foreign dependency, C/C++ runtime, other-language standard library, or
`topal-native/6` revision. This realizes `TOPAL-COMPILER-CONSTRAINT-VALUE-001`,
`TOPAL-ABSTRACTION-CONSTRAINT-CLASSIFIER-001`, and the construction-only portion
of `TOPAL-TYPE-CONSTRAINT-001` for compiler increment 8a1.

## TOPAL-COMP-CONSTRAINT-VALIDATE-001 — Int constraint validation

The checked compiler shall apply an admitted named Int constraint to a closed
exact operand by evaluating the retained predicate, diagnosing a known failure,
and giving an accepted unchanged Int value a distinct refined classifier.
Equality, ordering, and arithmetic shall deliberately forget this evidence and
reuse the canonical base operations. Unknown Int operands shall evaluate that
same predicate exactly once in generated code and use the existing Result/Error
representation with `root.Name(Int)`, `out-of-range`, and source provenance.

LLVM lowering shall bind the unchanged operand into a private predicate
environment and use explicit branches for success and failure. The success
payload shall be the original Int pointer. Refined locals shall use a DWARF
typedef over Int and a debug-only stack shadow so GDB preserves both source type
and value at O0. Native tests shall cover static success/rejection, base mismatch,
dynamic success/failure, equality, ordering, arithmetic, exact shared output,
IR paths, freestanding ELF properties, GDB values/types, and frames.

This shall add no duplicate numeric object, predicate dispatcher, constraint
runtime, foreign dependency, C/C++ runtime, other-language standard library,
public evidence ABI, or `topal-native/6` revision. Other bases, captured or
dependent predicates, evidence across function or persistent/public aggregate
machine boundaries, and dynamic constraint identities remain rejected. This
realizes `TOPAL-COMPILER-CONSTRAINT-VALIDATE-001` and
`TOPAL-TYPE-CONSTRAINT-VALIDATE-001` for compiler increment 8a2.

## TOPAL-COMP-CONSTRAINT-FUNDAMENTAL-BASES-001 — Fundamental constraint validation

The checked compiler shall extend `TOPAL-COMP-CONSTRAINT-VALIDATE-001` to
Boolean, Nat, Rational, and String root constraints whose pure predicates use
already-admitted operations. It shall evaluate decidable closed applications
during analysis and shall evaluate an unknown operand exactly once in generated
code. Dynamic validation shall return `Result (Base, lang arithmetic
ArithmeticErrorCode)`, preserving the unchanged operand on success and using
`out-of-range` with exact domain `root.Name(Base)` and source provenance on
failure.

LLVM lowering shall preserve each base representation. Boolean shall be boxed
only for its generic Result payload and loaded back as `i1`; Nat, Rational, and
String shall reuse their established pointer payloads. Refined locals shall
retain nominal DWARF typedefs over the corresponding base and require no LLVM
optimization for correct execution or debugging. Native tests shall cover
closed Boolean/String/Rational success, dynamic Boolean success and failure,
exact interpreter output, checked-model and LLVM representation, freestanding
ELF/DWARF, every interpreter mode, reversible history, the shared corpus, and
separate resource baselines.

This shall add no predicate dispatcher, constraint runtime, foreign dependency,
C/C++ runtime, other-language standard library, public evidence ABI, or
`topal-native/6` revision. Captured or dependent predicates, evidence across
public or persistent aggregate boundaries, and dynamic constraint identities
remain rejected. This realizes
`TOPAL-COMPILER-CONSTRAINT-FUNDAMENTAL-BASES-001` and
`TOPAL-TYPE-CONSTRAINT-VALIDATE-001` for compiler increment 8a2a.

## TOPAL-COMP-NATIVE-SERIALIZATION-001 — Closed canonical native streams

The checked compiler shall admit both version-selected forms of `lang
serialize` and `lang deserialize` for compiler-created, authority-free streams
whose complete value is statically known as literal Unit or Boolean, exact Int,
known String, or one direct Tuple or Record whose fields are those supported
scalar values. It shall derive the bytes
through the shared canonical protocol implementation, using Topal protocol 1.0,
the selected language identity and revision, target little-endian value
encoding, declaration-ordered Record fields, and one finite value event.

Serialization shall still evaluate the source value exactly once at O0. The
Linux x86-64 backend shall retain the canonical expected bytes in immutable
executable storage, copy them into private Topal-owned stream storage, and
construct a Topal-owned private descriptor containing the copy's address and
byte count. The published copy shall thereafter be treated as immutable. Before
`lang deserialize` exposes the retained value, generated code shall validate the
descriptor length and every copied stream byte against the compile-time-validated
canonical bytes. A mismatch shall take the compiler-runtime corruption exit. The
implementation shall not replace this mandatory work with an LLVM optimization
or call a host serialization library.

Dynamic Boolean, Int, and String values, nested or indirect aggregate values, other
returnable classifiers, arbitrary or externally supplied streams, and
serialization across function, persistent, public, or library boundaries
remain rejected with a stable compiler diagnostic. A future compiled-library
interface carrying native serialization shall identify the protocol revision,
language identity and revision, canonical type identities and schemas, field
order, byte-order contract, and authority profile independently of the private
descriptor layout, LLVM type, and native symbol spelling.

Tests shall compile the unchanged interpreter regression, compare exact output,
inspect the checked stream and O0 LLVM, validate the shared corpus and separate
resource baselines, and verify canonical magic, runtime validation, freestanding
ELF, DWARF, GDB, undefined symbols, needed libraries, and relocations. The GDB
renderer shall bound reads and validate stream magic before rendering the byte
count. This shall add no foreign dependency, C/C++ runtime, other-language
standard library, public ABI, or `topal-native/6` revision. This realizes
`TOPAL-COMPILER-NATIVE-SERIALIZATION-001` and `TOPAL-SER-SCOPE-001` through
`TOPAL-SER-DESER-001` for compiler increment 8b1.

## TOPAL-COMP-TASK-DIRECT-001 — Closed direct task transactions

The checked compiler shall admit the unchanged task-declaration-order
regression as compiler increment 7b2. It shall retain the nominal task
classifier and definition identity, queue bound, deterministic immediate-FIFO
scheduler policy, one private Nat state-field schema, lifecycle signatures,
ordinary handler names/kinds/signatures, discarded-context evidence, and a
stable source-ordered transaction identity for every admitted send. The
admitted handlers are one exact Nat initializer, Nat-addition Unit events,
current-Nat requests with an empty error vocabulary, and an optional declared
no-op terminate handler. Other state schemas, handler bodies, observable
MessageContext, streams outside `TOPAL-COMP-TASK-STREAM-001`, overlapping
delivery, queue overflow, and termination delivery remain rejected with stable
diagnostics.

Construction shall evaluate the initial Nat once and allocate a fresh
Topal-owned instance with a distinct nonzero identity, active lifecycle tag,
and private state pointer. Immediate event delivery shall load the current
state, compute arbitrary-precision Nat addition, and commit the replacement
before a following request loads it. Since this closed root scheduler cannot
overlap sends and every admitted context is explicitly discarded, generated
O0 code may erase the unobservable context/transaction carrier and unused queue
storage after the checked model has retained their semantic identities. This is
a compiler semantic lowering and shall not depend on LLVM optimization.

The Linux x86-64 backend shall use only the Topal mmap allocator, exact Int/Nat
runtime, and direct private helpers. The instance layout and helpers shall not
cross function, public, persistent, serialized, foreign, or compiled-library
boundaries. LLVM shall remain responsible for physical target layout; no
System V argument placement shall be encoded in the frontend, and no foreign
dependency, C/C++ runtime, or other-language standard library may be added.

DWARF and the bundled GDB renderer shall expose and safely render the nominal
task type, identity, lifecycle state, and named private Nat state at the request
source frame. Functional evidence shall include checked-model metadata and
rejection tests, ordered O0 LLVM, exact interpreter differential, the complete
shared corpus, freestanding ELF/DWARF/GDB inspection, and separate build/run
resource baselines. A future compiled-library format shall carry versioned task
and definition identities, queue/scheduler policy, state schema, complete
handler/context/transaction signatures, effects, authorities, ownership,
termination, debug provenance, and native adapter requirements independently of
private LLVM types, object layouts, and symbol names. This realizes
`TOPAL-COMPILER-TASK-DIRECT-001`, `TOPAL-TASK-DEFINITION-001`,
`TOPAL-TASK-HANDLER-001`, `TOPAL-TASK-STATE-001`,
`TOPAL-TASK-LIFECYCLE-001`, and `TOPAL-TASK-MESSAGE-001` for increment 7b2.

## TOPAL-COMP-TASK-STREAM-001 — Closed one-yield task stream transaction

The checked compiler shall admit the unchanged task-message-transactions
regression as compiler increment 7b3. In addition to the direct-task metadata,
it shall retain an ordinary stream handler with discarded MessageContext and
Unit payload, Nat yield, Unit resumption, `Result (Unit, ())` final return, the
owning task instance, and one stable source-ordered transaction identity. The
admitted body is exactly one yield of the current private Nat state followed by
Unit. Other directions, bodies, context observation, multiple yields,
post-resumption state access or mutation, effectful traversal actions,
abandonment, close delivery, overlap, and termination interaction remain
rejected with stable diagnostics.

Stream construction shall capture the task capability without loading state.
Its single traversal shall load state at the source yield after the preceding
event commit, perform one inert Unit resumption, commit a successful Unit final
Result, and complete before the following request begins. Since no admitted
code can observe the resume carrier, retain a continuation, or access task
state after resumption, generated O0 code may inline the suspension and erase
those carriers after the checked model records the complete stream directions
and transaction. This semantic lowering shall not depend on LLVM optimization.

The Linux x86-64 backend shall reuse the private task, exact Nat, and Result
runtime representations and add no foreign dependency, C/C++ runtime,
other-language standard library, public ABI, or native ABI revision. Task and
Generator DWARF plus the bundled GDB renderers shall expose the owning task,
private state, affine stream directions, stream binding, and source yield.
Functional evidence shall include checked-model metadata and rejection tests,
ordered O0 LLVM, exact interpreter differential, complete compiler corpus,
freestanding ELF/DWARF/GDB inspection, and separate build/run resource
baselines. Future compiled-library metadata shall carry stream directions,
transaction/suspension identity, state-authority release and reacquisition,
ownership/consumption, close/termination behavior, effects, authorities, debug
provenance, and native adapter requirements independently of private LLVM
types, layouts, and symbols. This realizes
`TOPAL-COMPILER-TASK-STREAM-001`, `TOPAL-TASK-HANDLER-001`, and
`TOPAL-TASK-MESSAGE-001` for increment 7b3.

## TOPAL-COMP-EXTERNAL-LOCATION-001 — Closed checked external location

The checked compiler shall admit the unchanged external-layout-location
regression as compiler increment 7b4. It shall retain target-independent
metadata for the complete five-layout graph, including identities, semantic
classifiers, sizes, encodings, endianness, access, alignment, product fields and
packing, tagged-sum tags and placement, array extent, element layout and stride.
It shall likewise retain the address-range identity, policies, medium, minimum
access size and inclusive bounds; the offset subtype's exact range identity,
alignment and checked value; and the Location subtype, layout and offset.

The checker shall reject missing, extra, duplicate, inconsistent, dynamic, or
unsupported fields; unrepresentable UInt32LE values; invalid bounds, offsets,
fit, alignment, or access; and every non-closed location flow. The admitted
write and read shall be distinct, source ordered, and exactly differential with
the interpreter. General encoders/decoders, fallible hardware access,
uninitialized reads, other layout families, and function, persistent, public,
serialized, or compiled-library location boundaries remain unsupported.

Because the source grants no Linux device mapping or native-adapter authority,
the backend shall not dereference the numeric MMIO address. It shall allocate a
private process-owned Topal Location header through the existing Linux syscall
allocator and preserve range start, offset, initialization state, and the
immutable semantic Nat snapshot. Noinline Topal runtime write/read calls shall
preserve O0 ordering. This explicitly models only the authority-free regression
and does not claim real MMIO integration; that requires a future typed platform
adapter. The executable shall add no C/C++ runtime, other-language standard
library, foreign allocator, undefined symbol, dynamic dependency, public ABI,
or native ABI revision.

DWARF and the bounded validating GDB renderer shall expose the nominal
UInt32LE-backed Nat, nominal ControlLocation, semantic address evidence,
initialization state, stored value, source operations, and frames. Functional
evidence shall cover metadata retention and rejection, ordered O0 LLVM, exact
interpreter differential, freestanding ELF and DWARF/GDB inspection, the full
compiler corpus, and separate build/run resource baselines. Future library
metadata shall carry the complete language/schema/layout/range/offset/location,
ordering, effect, authority, fallibility, ownership, platform-adapter, and debug
contracts independently of LLVM types, layouts, headers, and symbols. This
realizes `TOPAL-COMPILER-EXTERNAL-LOCATION-001`, `TOPAL-LAYOUT-SIZE-001`,
`TOPAL-LAYOUT-CONSTRUCT-001`, `TOPAL-ADDRESS-RANGE-001`,
`TOPAL-LOCATION-CONSTRUCT-001`, `TOPAL-LOCATION-READ-001`, and
`TOPAL-LOCATION-WRITE-001` for increment 7b4.

## TOPAL-COMP-DEBUG-001 — DWARF and GDB

Debug-enabled O0 output shall map generated source functions, parameters,
immutable scalar locals, lexical scopes, and instructions to Topal files and
source locations, emit DWARF 5 through LLVM, retain frame pointers, provide GDB
renderers for private arbitrary-precision Int, Rational, `Range Int`,
`Range Rational`, `Optional Int`, `Optional String`, `Optional List Int`,
`Optional (Int, List Int)`, `Optional Error`,
`Optional SourceLocation`, `SourceLocation`, nominal modular-number objects,
modular-success Result objects, `List Effect`, `List Int`,
`List (String, Int)`, exact-extent `Array Int`, `Set Int`, `Bag Int`, and
`Map (String, Int)` container values, describe source-declared nominal enums,
native `SerializationStream` descriptors,
nominal direct Task instances with identity, lifecycle state, and private Nat
state, affine task-stream Generator directions and bindings,
nominal layout-backed Nat and checked Location headers with address evidence,
initialization state, and stored snapshot,
retained Constraint identities and refined Int bindings with their semantic
names, distinguish
selected overload and static-function frames, and pass automated GDB
breakpoint, value, and backtrace scenarios.

## TOPAL-COMP-ENUM-001 — Payload-free nominal enums

The compiler shall recognize admitted root-scope payload-free
`Name is Enum (A, …)` declarations as distinct from general `Union`, preserve
their declaration-scoped nominal identity, classify their alternatives and
scalar function boundaries, and permit equality only within the same enum type.
Each declaration shall use a declaration-ordered `i32` tag in the sealed private
ABI; the representation shall not be exposed as a portable foreign enum
convention.

Enum display shall emit the selected source label through the Topal platform
writer. Enum decisions shall evaluate their subject once, select only the
first matching alternative action, diagnose missing, foreign, or unknown
alternatives, and merge compatible reachable scalar actions through LLVM
control flow. Generated invalid-tag paths shall fail closed as compiler-runtime
corruption. DWARF shall retain the nominal type and every enumerator so GDB
renders parameters and locals as source alternatives without a language-runtime
dependency.

This requirement covers `TOPAL-TYPE-ENUM-001` and the source-declared enum case
of `TOPAL-DECISION-ENUM-001`. It realizes `TOPAL-COMPILER-ENUM-001` for
compiler increment 3b1; nested enum declarations and general unions remain in
increment 3b2.

## TOPAL-COMP-SUM-001 — Private nominal Union and Variant values

The checked compiler shall collect root-scope `Name is Union` declarations and
`Name is Variant (...)` bindings, retain one nominal identity and the ordered
payload classifier of every alternative, and admit payload types that already
have recursively complete private representations. Payload-free Union
alternatives shall carry Unit without a payload slot. Construction shall
evaluate and classify the selected complete payload exactly once. Complete
decisions shall evaluate their subject once, select by the retained tag, bind a
payload only in its selected action, and diagnose unknown, foreign, duplicate
declaration, or missing alternatives at the checked boundary.

The Linux x86-64 backend shall use one non-packed LLVM literal struct containing
a declaration-ordered `i32` tag followed by one statically typed slot for every
payload-bearing alternative. It shall initialize all machine slots, observe
only the active one, and use the same exact type in private `fastcc`
definitions, calls, and returns. LLVM shall own physical register/stack
classification. Invalid tags shall take the compiler-runtime corruption exit.
Source display shall match the interpreter's labeled or positional alternative
spelling through the Topal writer.

DWARF shall expose the nominal source typedef, an enumerated source-alternative
tag, and correctly laid-out payload members. Named values and aggregate payload
bindings shall use target-aligned debug-only shadows where LLVM 22 cannot retain
an inspectable SSA aggregate. The bundled GDB renderer shall show only the
active alternative and payload. This shall add no semantic heap allocation,
sum runtime helper, foreign dependency, C/C++ runtime, other-language standard
library, public aggregate ABI, or `topal-native/6` revision. Recursive nominal
sums, nested declarations, derived ordering, persistent/public
storage, serialization, introspection, and library metadata remain deferred.
This realizes `TOPAL-COMPILER-SUM-001`, `TOPAL-TYPE-UNION-001`,
`TOPAL-TYPE-VARIANT-001`, and `TOPAL-DECISION-UNION-001` for compiler increment
3b2-b5o.

## TOPAL-COMP-SUM-EQUALITY-001 — Derived nominal Sum equality

The checked compiler model shall admit `=` and `!=` for two values of one exact
nominal Union or positional Variant type exactly when every declared payload
has admitted canonical Equality. Payload-free alternatives shall contribute
Unit. Tuple and Record payloads and fields may recursively contain an admitted
Sum. Function, Range, Result, authority-bearing, and other payloads without
admitted Equality shall reject the complete Sum operation before LLVM lowering
or artifact publication. Structurally identical distinct declarations shall
not share an overload.

Lowering shall compare tags first, return false for different tags without
observing either payload, and use LLVM `switch` to select and recursively
compare only the active payload for equal tags. Payload-free alternatives shall
return true, invalid private tags shall fail closed as unequal, and an `i1`
`phi` shall join the explicit predecessor results at O0. `!=` shall negate the
same equality result. The operation shall reuse the existing exact private
tag-plus-payload aggregate, matching `fastcc` prototypes, nominal DWARF type,
and active-value GDB rendering while LLVM owns AMD64 physical lowering.

Tests shall cover labeled Union and positional Variant values; payload-free,
Int, String, Tuple, Record, and nested Sum alternatives; equal payloads;
same-tag payload inequality; distinct-tag short-circuiting; nominal mismatch;
unsupported-payload rejection before publication; direct `switch`/`phi` IR;
interpreter parity and reversible history; the shared corpus and separate
resource baselines; freestanding ELF/DWARF properties; and full O0 GDB
values/frames. This shall add no whole-storage comparison, inactive-field load,
generic matcher, Sum-equality runtime, allocation, callback, indirect dispatch,
foreign dependency, C/C++ runtime, other-language standard library, public Sum
ABI, or `topal-native/6` revision. Future compiled-library metadata shall encode
nominal identity, ordered alternatives, payload schemas, canonical Equality
evidence, representation identity, and target adapters independently of private
tags, inactive storage, LLVM types, and physical placement. Recursive Sum
declarations, persistent/public storage, publication, and library adapters
remain deferred. This realizes `TOPAL-COMPILER-SUM-EQUALITY-001`,
`TOPAL-TYPE-SUM-EQUALITY-001`, and `TOPAL-TYPE-EQUALITY-001` for compiler
increment 3b2-b5ah.

Under `TK-DEC-262`, the owned numeric publisher and process provider shall realize
`TOPAL-SYSTEMS-NUMERIC-RESULT-RECORD-001` and
`TOPAL-SYSTEMS-PROCESS-IDENTITY-LIBRARY-001` through exact declared Record types,
name-based multiword extraction, recorded canonical slots and validated ordinary
per-value construction-order suffix, bounded copied
facts and independent native ABI evidence. Source and all imported helpers,
adapter work, aggregate transport and native saves shall enter complete unchanged
resource bounds. The owner shall apply both validated scalar outputs only after
full invocation reclamation, preserving existing child-creation checks and commit
order. Independent/combined bindings, exec retention, terminal erasure, reordered
fields, initial/increment/wrap, malformed private facts/results, actual source
frames and before-commit changed-helper rejection shall be qualified. This shall
not qualify escaping source values, persistent allocation or a broader process
model.

Under `TK-DEC-263`, the selected retained identity profile shall realize
`TOPAL-SYSTEMS-RETAINED-NUMERIC-STATE-001` and
`TOPAL-SYSTEMS-RETAINED-PROCESS-IDENTITY-001`. The publisher shall bind the exact
ordinary schema, complete explicit state reserve, checked semantic projection,
private version/owner protocol and full bounds to source/module/adapter/native
provenance. An initialized source call shall borrow the actual published Record
graph rather than box cached state. Preparation shall preserve the old value and
publish no pointers into temporary storage. Cleanup shall precede the exclusive
owner commit; old-version retirement shall follow last borrow. Exec/restoration
shall preserve shared history, and terminal cancellation shall reclaim the store
and every selected binding. Scalar-only interfaces shall retain their contracts.
Native/model/source-frame tests shall cover complete protocol/ranges/order,
repeated alternation, invalid pointers/state, stale publication, standalone and
combined operation, actual source graph survival/retirement and changed-helper
precommit rejection. General persistent types/effects remain unqualified.

Under `TK-DEC-264`, the selected structured identity interface shall implement
`TOPAL-SYSTEMS-RETAINED-STRUCTURED-STATE-001` and
`TOPAL-SYSTEMS-STRUCTURED-PROCESS-IDENTITY-001` and transport
ordinary nested state through the shared function/aggregate ABI and retain the
actual complete source-produced successor. A shared checked layout/projection
description shall cover canonical fields, nested alignment/padding, Boolean
representation, per-value Record order and full bounded Nat nodes; incompatible
or unqualified layouts shall fail closed. Projection and native prepared-graph
validation shall agree on this description. Borrowed input shall use both actual
published numeric nodes; copied state shall retain no temporary or old-bank
reference. Complete persistent/temporary/stack and projection/validation/retirement
bounds shall enter source/module/runtime/native provenance. Earlier scalar and
retained interfaces shall remain independently supported in one semantic slot.
Native/model/physical qualification shall exercise whole aggregate transport,
two-limb boundaries, order/Boolean/padding and malformed graphs/results,
prepare-clean-publish-retire, shared history and complete reclamation. This
qualifies no new core value or effect meaning.

Under `TK-DEC-265`, the qualified volatile-file provider shall bind explicit
dispatch-version evidence under `TOPAL-SYSTEMS-LINUX-DISPATCH-V2-001` and
evidence for `TOPAL-SYSTEMS-VOLATILE-FILE-OWNERSHIP-001`,
`TOPAL-SYSTEMS-VOLATILE-FILE-TRANSFER-001` and
`TOPAL-SYSTEMS-VOLATILE-FILE-PERSONALITY-001`, including
supervisor-only object/page storage and capacity to artifact provenance. Its
native personality shall preserve checked name/flag/mode and user-copy ordering,
descriptor rights, sparse read/write/seek/truncate semantics, native umask and
coherent metadata. Shared contents, allocation and positions shall survive
process restoration; private umask shall follow fork/exec lifetime. Rejection
shall preserve published state, while final description release and terminal
cancellation shall erase all owned pages, metadata and staging. Model/native/
physical cases shall independently qualify allocation exhaustion/reuse, holes,
regrowth, aliases, inheritance, copy faults and complete cleanup. Until those
checks pass this shall remain planned capability, without claiming general
source effects, writable namespace or distribution compatibility.

## TOPAL-COMP-ARTIFACT-001 — Canonical sidecar metadata

Every requested output shall receive a canonical
`topal.native-artifact/1` JSON sidecar containing the complete admitted
target, ABI, compiler, LLVM, optimization, debug, source, interface, dependency,
export, platform, evidence, and provenance fields. The metadata API shall reject
schema, target, revision, ordering, duplicate-identity, and digest errors before
an artifact is consumed.

## TOPAL-COMP-TEST-001 — Shared native regressions

Compiler tests shall compile and execute the unchanged interpreter regression
sources listed by `topalc test --list`, compare output to the interpreter, and
verify freestanding ELF and GDB properties. Resource tooling shall measure
compiler builds and executable runs under identities separate from the
interpreter baseline.

## TOPAL-COMP-SYSTEMS-FILE-OPEN-PLAN-001 — Source-defined open plans

The publisher shall implement `TOPAL-SYSTEMS-FILE-OPEN-PLAN-001`: select the
eight-Boolean/eight-choice pure interface in the unique kernel-library slot,
preserve the frozen three-Boolean interface, prove the complete 1024-byte stack
limit, adapt nominal alternatives by semantic name, bind the selected native
export exactly and reject version confusion. Native consumers shall validate
owned action preconditions before allocating or mutating resources. Qualify
all finite vectors, reversed source order, physical calls and prepublication
wrong-plan refusal. See [design](../../linux-kernel/design/source-file-open-plans.md).

## TOPAL-COMP-SYSTEMS-POSITIONAL-FILE-001 — Explicit-position regular transfers

Implement the systems-only [positional transfer design](../../linux-kernel/design/positional-file-transfers.md)
under `TK-DEC-268`: exact versioned ordinary source operation selection, negative
offset/descriptor/nonseekable/access/copy/full-interval error ordering, independent
positional reads and writes over sparse and immutable backing, Linux append
placement, no shared-position publication, unchanged storage/stack bounds and
complete cleanup. Qualify source versions/orders, actual contents and positions,
capacity/copy failures, unlinked/fork/exec lifetime, active/inactive teardown and
an independent wrong-data/result rejection; retain the existing command corpus.

## TOPAL-COMP-SYSTEMS-NAMED-FILE-001 — Named volatile files

Realize named regular creation, independent reopening, truncating open, unlink and native directory/stat observations under the owned sparse filesystem. Bind selected open plans and versioned dispatch without changing frozen contracts. Keep names, objects, descriptions and descriptors distinct; preserve Linux lookup/admission ordering and complete failure atomicity; prove exact placement/helper bounds and terminal namespace-owner reclamation. Require independent native and pinned-Linux controls, source-policy execution and real shell/file-command evidence.
See [design](../../linux-kernel/design/named-volatile-files.md).

## TOPAL-COMP-SYSTEMS-REGION-SOURCE-001 — Ordinary region source objects

Implement `TOPAL-SYSTEMS-REGION-SOURCE-ENTRY-001`,
`TOPAL-SYSTEMS-REGION-SOURCE-MEMBERS-001`,
`TOPAL-SYSTEMS-REGION-SOURCE-CLOSURE-001` and
`TOPAL-SYSTEMS-REGION-SOURCE-OBJECT-001` using shared ordinary source/module,
function and native lowering. Separate declared export typing from constructing
source authority. Preserve resource-origin effects, empty-effect checks, nonescape
and all checked refusal/identity distinctions. Prove complete source/runtime/
view/stack bounds and inspect actual object/debug/calling evidence. Bind no host
service or writable source global. Standalone object evidence shall remain
distinct from kernel-root/QEMU integration and full reclamation. See
[TK-DEC-270](../../linux-kernel/design/source-kernel-region-functions.md).

## TOPAL-COMP-SYSTEMS-REGION-ROOT-001 — Root region-library publication

Implement `TOPAL-SYSTEMS-REGION-ROOT-BINDING-001`,
`TOPAL-SYSTEMS-REGION-ROOT-CALL-001` and
`TOPAL-SYSTEMS-REGION-ROOT-RECLAIM-001` and
`TOPAL-SYSTEMS-REGION-READONLY-DATA-001`. Bind the exact declared ordinary source
entry, frozen module closure and inspected object into the root's actual region
loan and atomic artifact publication. Qualify dedicated root-context temporary
hooks, disjoint placement, complete bounds, linked code and every allocated
immutable source/runtime input. Qualify complete object data coverage and exact
linked local identity/extent/alignment/bytes, Unit/action namespace separation,
valid empty Unit data and corrected-outer-digest literal rejection without
changing the Unit entry ABI. Resume owner access
only after complete arena, retired-stack and pointer/code-binding reclamation.
Preserve source stores and native callers; test actual helper frames and cleanup
under pinned QEMU. Static owner modeling shall record unknown helper-written
bytes and dynamic byte guards without claiming source execution. See
[TK-DEC-271](../../linux-kernel/design/root-borrowed-region-invocation.md).

## TOPAL-COMP-SYSTEMS-REGION-ACTION-001 — Persistent source actions

Implement `TOPAL-SYSTEMS-REGION-ACTION-SOURCE-001`,
`TOPAL-SYSTEMS-REGION-ACTION-OWNER-001`,
`TOPAL-SYSTEMS-REGION-ACTION-RETURN-001` and
`TOPAL-SYSTEMS-REGION-ACTION-POSITION-001` through shared ordinary source,
module, effect and native lowering. Keep the old Unit context intact. Bind exact
scalar/result transport, unique private namespaces/hooks, complete costs,
controller/actual field ownership and linked code/storage before publication.
Invoke the selected action on real successful ordinary file transfers and omit
the native duplicate update. Reclaim all temporaries before owner resumption;
qualify aliases/append/positional noncalls, active/inactive retirement, negative
code/bounds controls and the full physical cohort. See
[TK-DEC-272](../../linux-kernel/design/persistent-region-actions.md).

## TOPAL-COMP-SYSTEMS-REGION-FRAME-001 — Framed action input qualification

Implement `TOPAL-SYSTEMS-REGION-FRAME-SOURCE-001` and
`TOPAL-SYSTEMS-REGION-FRAME-ABI-001` using ordinary declared-type selection,
module/effect checking, shared numeric algorithms and a separately qualified
target-private input-frame adapter. Bind the exact caller-selected 0–16-Nat
signature and scalar count; preserve full u64 facts, arbitrary-precision source
arithmetic and the old Unit/action entry ABIs. Prove complete input-frame
ownership/disjointness/lifetime, bridge allocation and source/caller stack,
native state, nonescape and cleanup. Reject incompatible counts, frames,
objects, hooks, bounds and caller templates before a live grant. The initial
persistent file-position caller shall still transport exactly effective base
and actual count and preserve source stores, noncalls, terminal cleanup and
Linux behavior. Native and VM qualification shall inspect actual frame words,
ordinary source arguments, independent values/canaries and complete reclamation.
See [TK-DEC-275](../../linux-kernel/design/framed-region-actions.md).

## TOPAL-COMP-SYSTEMS-REGION-INSTANCE-001 — Instance-bound region source calls

Qualify independent framed instances through ordinary declared-type/module/
effect lowering and the existing frame ABI. Derive unique entry/hook and
code/data namespaces from canonical instance identity; bind exact owner/caller
slot, count, source/object/linked bytes, complete bounds and temporary/history
storage. Labels shall not create authority or silently select another caller.
Preserve legacy Unit/action/unscoped-frame representations and reject foreign,
mixed, missing or null instance-only metadata. Root framed calls shall supply
zero facts, retain the actual Boolean, reclaim every temporary and require true
before resuming the real owner. The file-position caller shall retain its two
facts and Linux contract. Validate same-signature object coexistence, wrong
instance/code/control refusal, real independent owners and complete native/VM
cleanup, including root false-after-store and all old contexts. See
[TK-DEC-276](../../linux-kernel/design/instance-scoped-region-actions.md).

## TOPAL-COMP-SYSTEMS-REGION-PAGE-001 — Real source-backed reusable page maps

Select a separately bound `ram-page-pool` instance with the existing two-fact
ordinary region/Boolean frame context and resource limits. Bind the real
filesystem allocation map, source/module/code/data/hooks, contained owner,
independent control/arena/history and complete caller/stack/allocation proofs.
Ordinary source shall choose the slot; native code shall validate the full
single-byte allocation/release delta, actual Boolean, association/payload and
complete reclamation before publication. Preserve Linux recoverable admission
order and explicit native-only/earlier-context compatibility. Independently
execute alternate source placement, invalid/mixed bindings and false/malformed
completion, no-entry/cleanup/reuse and complete affected kernel/BusyBox cohorts.
See [TK-DEC-278](../../linux-kernel/design/source-ram-page-allocation.md).

## TOPAL-COMP-SYSTEMS-REGION-UNSIGNED-001 — Qualified ordinary field encodings

Implement `TOPAL-SYSTEMS-REGION-UNSIGNED-001` and
`TOPAL-SYSTEMS-REGION-UNSIGNED-QUALIFY-001` through existing ordinary source,
module, effect and native pipelines. Bind exact static formats and runtime fact
order, full Nat range semantics, complete checked byte access, shared-owner
effects and all helper costs/code/data. Reject incomplete or changed runtime
evidence and preserve byte-only/earlier callable controls. Execute independently
observed native components before enabling the real file-position application;
retain its arithmetic, admission, owner and cleanup laws. Keep existing source
resource limits and qualify every affected changed-kernel cohort. See
[TK-DEC-279](../../linux-kernel/design/unsigned-region-fields.md).

## TOPAL-COMP-SYSTEMS-INODE-MODE-001 — Ordinary shared metadata service

Realize `TOPAL-SYSTEMS-INODE-MODE-STATE-001`,
`TOPAL-SYSTEMS-INODE-MODE-ABI-001` and
`TOPAL-SYSTEMS-INODE-MODE-ACTION-001` and
`TOPAL-SYSTEMS-LINUX-DISPATCH-V5-001` through existing scoped instance actions.
Qualify ordinary source on actual persistent inode bytes with complete source,
runtime, code/data, caller, storage and cost bindings and fresh history. Preserve
type and untouched fields; keep all Linux argument/credential/mount/clock
admission before mutation, true-only guarded completion and complete temporary
cleanup before owner resumption. Bind new exact layouts without enlarging owner
extents or temporary limits. Independently test all four native adapters, error
ordering, real source/helper effects, read-only/alias/unlinked/reused objects,
mutable directories and both pipe endpoints against byte, pinned Linux, native
and physical oracles. Preserve explicit older dispatch/ABI controls and initial
acceptance scope. See [TK-DEC-280](../../linux-kernel/design/shared-inode-mode-actions.md).

## TOPAL-COMP-SYSTEMS-NAMESPACE-001 — Ordinary namespace mutation service

Implement `TOPAL-SYSTEMS-NAMESPACE-{OWNERSHIP,TRANSACTION,ABI,ACTION}-001`
through separately bound ordinary source, actual persistent metadata and the
existing two-Nat/Boolean instance ABI. Bind input/staging, complete code/data,
owner geometry, runtime, history and costs. Guard exact complete deltas and
immutable input, reclaim all temporaries before resumption and make admitted
failure terminal without rollback. Qualify all five native adapters, retained
dispatch vocabularies, exact new layouts, replacement/alias/capacity/lifetime
laws, malformed bindings and source failures using independent byte/native/
Linux/physical oracles and unchanged utility binaries. Keep existing owner
extents, source resource limits, core meaning and initial acceptance scope.
Bind the V6 inode-mode consumer's complete canonical metadata admission,
four-entry link-count bound, clean peer-controller exclusion and 72-byte
validation stack/return retirement. Charge sequential paths by their maximum
complete depth; retain exact earlier inode invocation guards and certificates.
When ordinary helper specialization exceeds the existing function budget,
validate every original checked body before sharing equivalent instances of
one declaration, erase only lowering-independent integer-range metadata and
revalidate against the unchanged budget. Preserve every call and charge its
complete temporary and view costs independently; retain the exact earlier
representation of already-qualified smaller closures.
Qualify the unique `namespace-library` declaration and its existing controller
dependencies through both the shared semantic model and public compiler
pipeline. Bind and erase private comparison/recovery storage, preserve the
consumed epoch through runtime abort, and recover the caller frame without
trusting aborting callee registers. Preserve the reserved user-address window
when additional supervisor code/storage requires a different placement.
Require V6's existing named-file open-plan policy as well as its namespace and
filesystem controllers; reject missing or boot-only policies before publishing
the new mutable entry-table layout. Preserve older dispatch selection rules.
Bind nested lookup and complete caller/retired-stack costs. Reclaim abandoned
admission helpers before recoverable or no-op returns using only the trusted
captured entry frame; an unverified address must not authorize stack erasure.
See [TK-DEC-281](../../linux-kernel/design/shared-namespace-transactions.md).

## TOPAL-COMP-SYSTEMS-TAIL-PLAN-001 — Checked tail-source plan

Implement `TOPAL-SYSTEMS-TAIL-PLAN-001` as source-only inspection of the shared
checked program. Bind source/dependencies, the exact entry/countdown guard,
every direct tail decrement, invariant optional region input, complete acyclic
helper graph and owner effects. Reject incomplete graphs, hidden/foreign
authority, unsupported forms and unproved recursive edges. Preserve evaluation
order and mark the result as insufficient for native emission. Publication
shall separately satisfy `TOPAL-SYSTEMS-TAIL-REUSE-001`; existing freestanding
profile refusal and source limits remain unchanged. See
[TK-DEC-282](../../linux-kernel/design/repeated-source-tail-traversal.md).

For the tail family, preserve the actual borrowed-owner count in primary and
isolated-module analysis without inferring the older 65536-byte owner cap.
Target-specific native count/resource bounds and actual owner admission remain
separate obligations under `TOPAL-SYSTEMS-TAIL-BOUNDS-001`.

Permit additional terminal rules after the initial literal countdown guard.
Inspect their operands and actions without granting recursive position, retain
the first guard's descent proof, and bound all tested operands and terminal
paths. This does not change ordinary syntax or termination semantics.

## TOPAL-COMP-SYSTEMS-TAIL-BOUNDS-001 — All-step carried storage bounds

Implement `TOPAL-SYSTEMS-TAIL-BOUNDS-001` by rebuilding the source plan and
proving every carried scalar over the complete admitted input domain. Resolve
storage bindings and closed helper results; prove affine measure potentials or
bounded resets without widening away the induction obligation. Reuse reviewed
ordinary numeric/region costs, charge every actual argument/terminal step and
both transfer banks, and keep legacy profiles unchanged. Bind exact source,
graph/runtime identities and actual source-call/loan multiplicities. Reject
missing or oversized proofs. Range/allocation metadata alone shall not grant
native stack, transfer, lifetime or execution qualification. See
[the proof method](../../linux-kernel/design/tail-state-bounds.md).

## TOPAL-COMP-SYSTEMS-TAIL-STEP-001 — Shared lowering of private tail steps

Implement `TOPAL-SYSTEMS-TAIL-STEP-001` under the separate component boundary.
Rebuild source/range evidence, preserve ordinary lowering and ordered argument
evaluation, and expose private terminal/successor transport only. Preserve fresh
logical helper/frame/loan history and current-view checks through explicit
provider-private hooks. Bind readonly roots and the distinct tail-region runtime
without modifying legacy profile contracts. Treat emitted components as
unqualified for kernel publication until complete native evidence exists.
Follow [the return-boundary design](../../linux-kernel/design/tail-step-component.md).

## TOPAL-COMP-SYSTEMS-TAIL-BOUNDARY-001 — Target-owned source stack and recovery

Implement `TOPAL-SYSTEMS-TAIL-BOUNDARY-001` as a distinct private x86-64 provider
component. Preserve live caller state, bind recovery before entering the source
stack, reclaim that stack after return, and recover admitted aborts independently
of source registers. Keep complete temporary/stack bounds and accurate CFI.
Retain pre-entry refusal, persistent effects/history and nonreturning fatal
dispositions. Do not qualify kernel invocation through C test hooks alone.
See [the boundary contract](../../linux-kernel/design/tail-stack-boundary.md).

Provide the distinct between-step controller failure entry under that contract.
Bind the owning caller's actual extents independently of inactive recovery or
possibly inconsistent source-context fields, reclaim both domains and reach
nonreturning fatal handling before any owner resumption. Check source-step and
controller failure paths independently, including preserved stores/history.

## TOPAL-COMP-SYSTEMS-TAIL-SESSION-001 — Source-to-reference session binding

Rebuild the source-tail graph and complete carried/storage analysis before
constructing `TOPAL-SYSTEMS-TAIL-SESSION-001` model constraints. Preserve the
exact helper graph, invariant region, classifiers/ranges, measure/decrements,
step issuance and work/bank layout. Reject missing or unrepresentable facts.
Distinguish reference constraints from actual source execution, native readonly
roots, target layout, code/hooks/context, physical erasure and publication.
See [the session contract](../../linux-kernel/design/tail-session-model.md).

## TOPAL-COMP-SYSTEMS-TAIL-RUNTIME-001 — Freestanding traversal hooks

Implement `TOPAL-SYSTEMS-TAIL-RUNTIME-001` from rebuilt source analysis and exact
provider layout/tables. Bind source/context/history/readonly identities, complete
numeric copies, aligned allocation provenance, scoped helpers and both issuance
budgets. Emit no implicit host-service dependency and retain separate data/stack/
context/owner proofs. Pin fatal history independently of mutable source fields
in the runtime-specific boundary, preserving older component contracts. Compare
actual emitted objects with independent guarded byte/value/history oracles.
See [the hook contract](../../linux-kernel/design/tail-provider-hooks.md).

## TOPAL-COMP-SYSTEMS-TAIL-CHECKPOINT-001 — Native checkpoint controller

Implement `TOPAL-SYSTEMS-TAIL-CHECKPOINT-001` with an exact controller-role target
entry and independently supplied owner history. Run the return body on the same
private stack as completed source steps. Validate complete state/progress/budgets
before retirement, erase all retired domains and retain fresh persistent logical
identity history. Preserve source effects and trusted fatal cleanup. Bind actual
object closure, role-specific stack/CFI/register evidence and independent whole
value/byte/history oracles. Do not infer normal kernel completion/publication
from component tests. See [the checkpoint design](../../linux-kernel/design/tail-native-checkpoint.md).

## TOPAL-COMP-SYSTEMS-TAIL-COMPLETION-001 — Native invocation completion

Implement `TOPAL-SYSTEMS-TAIL-COMPLETION-001` with fixed completion-role lowering,
the existing sequential private stack and an explicitly costed caller-owned
scalar/Unit output frame. Validate complete terminal state and copy/read back the
actual result before target-owned whole-invocation reclamation. Independently
pin actual history/output through running-body and late cleanup failures; erase
partial output, preserve performed stores/history and forbid successful fatal
resumption. Bind complete native object/stack/CFI/register and guarded value/
history/byte evidence. Keep actual kernel admission, context, owning-caller bounds
and publication separate. See [completion design](../../linux-kernel/design/tail-native-completion.md).

## TOPAL-COMP-SYSTEMS-TAIL-ADMISSION-001 — Owned invocation controller

Implement `TOPAL-SYSTEMS-TAIL-ADMISSION-001` from actual rebuilt source/layout
constraints. Admit all complete facts, domains, persistent generation and total
identity budgets before mutation; construct exact source context/banks/views and
run the fixed source/checkpoint/completion roles. Preserve whole refusal state,
performed stores and actual persistent history across reuse and admitted failure.
Keep original history/output independent of mutable context. Bind native object/
import/stack evidence and independent repeated invocation/refusal oracles. Actual
kernel caller ownership/context, complete caller retirement and publication remain
separate. See [admission design](../../linux-kernel/design/tail-owner-admission.md).

## TOPAL-COMP-SYSTEMS-TAIL-KERNEL-001 — Kernel root tail adapter

Implement `TOPAL-SYSTEMS-TAIL-KERNEL-001` with an explicit systems-only interface
and actual typed root owner call. Preserve legacy profiles. Bind CPL/IF/stack,
owned extents, complete caller/inner bounds, independent recovery, Boolean owner
postcondition and normal/fatal physical retirement. Keep canonical publication
refused until complete source/native/caller/boot verification exists; distinguish
exact unpublished VM experiments from that qualification. See the kernel
[root design](../../linux-kernel/design/tail-kernel-root.md).

## TOPAL-COMP-SYSTEMS-TAIL-BINDING-001 — Reconstructed tail publication

Implement `TOPAL-SYSTEMS-TAIL-BINDING-001` through explicit immutable root and
ordinary-source/module inputs, fresh checked lowering and qualified toolchain
reconstruction. Compare every allocated linked contribution against fresh object
bytes with checked local/external relocation resolution, section/symbol identity,
permissions, alignment, actual load projection, bootstrap entry and zero-storage
ownership. Preserve complete kernel
caller, result, resource and retirement requirements. Reject missing, forged,
mixed or unreconstructable bindings before publication/boot packaging; retain
program-only refusal until the complete source-bearing route is qualified.

Trace: [binding design](../../linux-kernel/design/tail-publication-binding.md),
[formal rule](../../spec/systems-profile.md#topal-systems-tail-binding-001--reconstructed-tail-root-publication).

## TOPAL-COMP-SYSTEMS-TAIL-NAT-OWNER-001 — Natural query component

Implement `TOPAL-SYSTEMS-TAIL-NAT-OWNER-001` with a separate source selection and
owner constructor. Reuse the checked ordinary Nat result and existing native
admission/controller/complete retirement without narrowing the result. Preserve
the Boolean owner's exact profile and publication refusals. Bind source/runtime
and native stack/representation evidence; test zero, values wider than a native
word, readonly constants and actual region-derived search facts. No component
result may grant allocator authority or substitute for kernel caller refinement.

## TOPAL-COMP-SYSTEMS-TAIL-HELPER-REUSE-001 — Shared checked helpers

Implement `TOPAL-SYSTEMS-TAIL-HELPER-REUSE-001` through source selection before
native plan construction. Keep the original checked call order and values,
entry/self identity, complete source provenance and every source/native bound.
Qualify the actual ordinary frame metadata policy with an independent complete
state oracle, including fragmented/aligned spans, provenance/physical gaps,
multiple live extents, exhaustion, release/reuse and retained partial writes.
This evidence does not replace actual kernel allocator/context qualification.

## TOPAL-COMP-SYSTEMS-FRAME-POLICY-BINDING-001 — Kernel frame allocator binding

Implement `TOPAL-SYSTEMS-FRAME-POLICY-BINDING-001` with an explicit unique source
slot and complete immutable root/library snapshots. Preserve actual typed owner
creation and whole allocation/release/mapping lifetimes. Require normalized-map,
reservation, identity, physical-zeroing and caller/context/retirement refinement
before publication. Check complete source/native/linked/boot closure and runtime
workload requests. Reject incomplete or program-only publication without changing
legacy profiles. See [kernel binding](../../linux-kernel/design/frame-policy-kernel-binding.md).

Forward actual captured memory requests through a process/context/address-space
and entry-identity checked owning invocation. Check its compiled continuation,
critical state, stack and combined memory/allocator resource bound. Refuse
invalid/busy callers before claiming cleanup ownership. Replacement must pin and
publish new translations, invalidate affected translations, then unpin, erase
and consume the old extent. Keep query/within-page requests allocation-free;
preserve the old heap on ordinary exhaustion and retire the complete heap on
exec/exit. Qualify performed-effect retention and caller retirement on failures,
including partial source writes and failure after replacement publication.
Keep target geometry limits explicit and preserve canonical publication refusal
until the complete native/source/load binding is reconstructed. See
[runtime memory](../../linux-kernel/design/dynamic-frame-memory.md).

The source-bearing publisher and boot adapter must freshly reconstruct the
retained frame root, policy and every other selected source/module input.
Compare the complete native/load binding, derived bounds, original producer
identities, target/entries and unique input/output associations. Measure and
relink the complete image reservation, then verify unchanged geometry. Refuse
missing, mixed, extra, duplicate, null-erased, stale and orphan bindings without
publishing the destination. Retain the other selected owner validators and
program-only refusal. Exercise this public path and rehashed native mutations
in `systems_frame_artifact_tests.rs` as well as the component reconstruction
tests.

## TOPAL-COMP-SYSTEMS-PROCESS-MM-001 — Process memory owner binding

Implement `TOPAL-SYSTEMS-PROCESS-MM-001` through actual per-process frame owners,
not copies of the active global MM token or a fixed heap snapshot. Preserve the
qualified child/pair, descriptor, signal, TLS/extended-state, shared-service and
wait contracts. Bind active/inactive owners to the real relationship, syscall
entry, generation, context, translation storage and compiled caller. Allocate,
zero, copy and pin the complete child heap before publication; preserve inactive
backing through unrelated resize/exec. Exclude heap entries from independent
legacy leaf-page restoration, and use the qualified publisher/invalidation for
every heap switch. Revoke access before unpin/erase/release; reclaim each active,
inactive and prepared extent exactly once. Do not roll back issued identities.
Keep fatal partial-effect retirement distinct from ordinary unavailability.
Qualify complete caller costs, entry/loan exclusion, every actual producer,
native process scenarios, unchanged application regressions and cold public
artifact/boot reconstruction before activating the replacement. Retain imported
descriptor/process ownership across exec; bind actual PID/TID, registration and
handoff during replacement startup independently of its image-stage counter.
Startup observations must not decide ordinary request legality or PID/TID values.
Route both imported-parent exit operations through the same ownership-checked
cancellation and destructor path, including replacement startup. Cancel and
read back an inactive child's wait before its backing and endpoints retire;
retain the existing detached-context, zeroed-storage and shared-service checks.
Model results alone cannot authorize activation. Trace:
[design](../../linux-kernel/design/process-memory-ownership.md),
[rule](../../spec/systems-profile.md#topal-systems-process-mm-001--process-address-space-ownership).

## TOPAL-COMP-SYSTEMS-USER-EXTENT-001 — Owned user-memory validation

Implement `TOPAL-SYSTEMS-USER-EXTENT-001` for the frame-profile process boundary.
Bind the exact active root, entry and stable observation to actual pinned table
and backing owners before dereferencing translations. Check complete runtime
ranges, every level's user/write permissions, entry formats and actual paging
mode. Preserve no-touch empty extents, caller registers/resource retirement,
syscall staging/error order and predecessor roots. Migrate every direct and
shared frame-profile user-buffer caller; replacing one helper or increasing a
constant is insufficient. Keep component/native and canonical publication gates
separate until the complete caller/source/native/load/boot reconstruction is
qualified. Initialize and verify CR0.WP before the new profile's first userspace
entry; preserve all other CR0 bits and keep WP enabled, including during copies.
Retain exact generated transition sites for actual before/after observation.
See [owned extents](../../linux-kernel/design/owned-user-extents.md).

Preserve the shared helper's live input registers and carry/result convention
through an adapter with actual unwind and alignment evidence. Include all outer
return/save/alignment words in the unchanged 4096-byte caller reserve and derive
the inner window accordingly. Both normal completion and nonreturning cleanup
shall retire the adapter's own temporaries without erasing an enclosing frame.
Keep predecessor object/layout equality separate from the new selection.

For stat-family pathname queries, admit complete required input bytes before
their first load and preserve lookup errors before output processing. Admit a
complete output only after successful lookup and independent record-error
decisions, before private staging changes or publication. An absent lookup shall
neither admit nor access its unused output
pointer. Preserve independent selector/flag/lifecycle rules and predecessor
profiles, including when replacing their fixed pathname and destination bounds.
Retain prescribed pathname contents while allowing any admitted readable,
entry-stable storage for those bytes.

For bounded open in the owned selection, admit all required pathname bytes
including the terminator before a load. At a bounded directory read, preserve
the independent capacity and position checks, then admit the actual complete
record output before staging it. EOF paths perform no destination admission or
access. For the bounded profile-file read, first validate the requested numeric
address range without consulting its translations. Preserve predecessor bytes
and verify each migrated path through its native syscall entry.

For the bounded owned shell selection, qualify the complete two-byte root
pathname, 32-byte native signal actions, one-byte header result and eight-byte
poll record with a two-byte writable result field. Keep the operation and
lifecycle checks. Failed admission shall precede output, disposition or phase
changes. A terminal request that returns `ENOTTY` without a transfer shall
perform no argument admission. Qualify through native entries and preserve
the predecessor emitter bytes.

The owned bounded header-poll path shall admit both validated header forms,
allow repeated polls, ignore input `revents`, and retain descriptor position.
Require full readable input and writable result admission before publishing
readiness. The clean form may retain direct reads; a successful read shall
consume pending readiness, while a refused read preserves it. Keep external
terminal probes and all independent operation/lifecycle checks. Qualify
readable read-only input with refused result output, partial inputs, repeated
polls, and successful directory/page-boundary records through native syscalls.
The predecessor encoder shall remain byte-identical.

For the bounded owned command reads, preserve each selected literal and the
serial limit. Derive each copy length from the captured count and the unread
extent. Validate that extent before publishing, retain received serial bytes
over `EFAULT`, erase the consumed serial prefix, and retain no user pointer
across calls. Keep the command cursor and received data separate from transient
exec staging. Qualify short reads, zero counts, retries and exact output through
native entries while preserving the predecessor emitter bytes.

The owned first-image terminal path shall use the initialized descriptor
table after serial delivery, check that no child is retained, and clear the
thread-registration slots without reading or writing their user addresses.
Preserve the zero-status condition and verify retirement through an ordinary
first-image shell exit.
Require the consumed prelude signal slots to be empty after transfer into the
process-owned table. Terminal teardown shall retire that table's current signal
state, including subsequent changes, rather than require the old installation
witnesses to remain live.
