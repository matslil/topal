"""Diagnostic saved-data replay of the corrected reader, without changing inputs."""
import json
from pathlib import Path
import sys

root=Path.cwd();sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from readback_caller_retirement import readback
build=root/'linux-kernel/.cache/x86_64/process-mm-owners-2546325-1794592185978073109'
result=readback(build)
(root/'linux-kernel/.cache/x86_64/caller-retirement-repaired-reader.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({name:result[name] for name in ['passed','sampled_sites','total_sites','outer_adapter_samples',
    'native_results','both_alignments_observed','heap_blobs','heap_blob_bytes']}))
print('saved controls',len(result['controls']),'ordinary cases',result['process_mm']['cases'])
