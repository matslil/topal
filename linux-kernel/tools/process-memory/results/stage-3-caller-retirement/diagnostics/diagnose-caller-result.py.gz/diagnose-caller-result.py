"""Inspect only the recorded caller result convention; no guest execution."""
from collections import Counter
import hashlib
import json
from pathlib import Path

root=Path.cwd();build=root/'linux-kernel/.cache/x86_64/process-mm-owners-2546325-1794592185978073109'
value=json.loads((build/'process-mm-users/observations.json').read_bytes())
data=value['caller_retirement'];unusual=[];counts=Counter();geometry=Counter()
for row in data['records']:
    done=row['gateway_return'];returned=row['return'];status=returned['result']
    counts[status]+=1;geometry[row['sp']-row['gateway_entry']['sp']]+=1
    assert status==done['result'] and bool(returned['flags']&1)==bool(status)
    if status not in [0,1]:
        unusual.append(dict(offset=row['site']['offset'],target=row['site']['target'],
            arguments=row['arguments'],gateway_result=done['result'],helper_result=status,
            carry=returned['flags']&1,labels=row['site']['nearest_labels']))
result=dict(native_passed=value['passed'],caller_complete=data['complete'],records=len(data['records']),
    native_results=dict(counts),outer_adapter_counts=dict(geometry),non_boolean_statuses=unusual,
    scope='Actual native records and exact carry/result equality only; not an independent admission predicate or lifetime proof')
(root/'linux-kernel/.cache/x86_64/caller-retirement-result-diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
