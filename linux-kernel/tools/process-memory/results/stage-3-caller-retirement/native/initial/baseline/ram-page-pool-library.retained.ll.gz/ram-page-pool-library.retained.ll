; ModuleID = 'kernel-region'
source_filename = "ram-page-pool.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.OptionalStorage = type { i64, ptr }
%topal.IntStorage = type { i64, i64, [0 x i32] }
%topal.KernelRegionControl = type { ptr, i64, i64, i64, ptr, i64, i64, i64 }
%topal.KernelRegionView = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }

@llvm.used = appending global [1 x ptr] [ptr @topal.region-instance.ram-page-pool.memset], section "llvm.metadata"
@topal.region-instance.ram-page-pool.runtime.int.zero = internal constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@topal.region-instance.ram-page-pool.literal.int.0 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.1 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.2 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.3 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.4 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.5 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.6 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.7 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.8 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.9 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.10 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.11 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.12 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.13 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.14 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.15 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.16 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.ram-page-pool.literal.int.17 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 6] }, align 8
@topal.region-instance.ram-page-pool.literal.int.18 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 5] }, align 8
@topal.region-instance.ram-page-pool.literal.int.19 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.ram-page-pool.literal.int.20 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.region-instance.ram-page-pool.literal.int.21 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.ram-page-pool.literal.int.22 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.23 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.24 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.25 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.26 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.27 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.ram-page-pool.literal.int.28 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.ram-page-pool.literal.int.29 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.ram-page-pool.literal.int.30 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8

; Function Attrs: noimplicitfloat noinline noredzone nounwind optnone
define internal ptr @topal.region-instance.ram-page-pool.memset(ptr %destination, i32 %value, i64 %length) #0 {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill

fill:                                             ; preds = %fill, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill

complete:                                         ; preds = %fill, %entry
  ret ptr %destination
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.runtime.optional.some(ptr %payload) #1 {
entry:
  %optional = call ptr @topal.region-instance.ram-page-pool.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.runtime.optional.none() #1 {
entry:
  %optional = call ptr @topal.region-instance.ram-page-pool.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %optional) #1 {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid

checked:                                          ; preds = %entry
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some

invalid:                                          ; preds = %entry
  call void @topal.region-instance.ram-page-pool.platform.exit(i64 70)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %optional) #1 {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.runtime.int.allocate(i64 %length, i64 %negative) #1 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.region-instance.ram-page-pool.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.region-instance.ram-page-pool.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.runtime.int.from.u64(i64 %source) #1 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.region-instance.ram-page-pool.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.region-instance.ram-page-pool.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.region-instance.ram-page-pool.runtime.int.compare.absolute(ptr %left, ptr %right) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer

check.longer:                                     ; preds = %entry
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty

check.empty:                                      ; preds = %check.longer
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs

limbs:                                            ; preds = %limbs.equal, %check.empty
  %position = phi i64 [ %left.length, %check.empty ], [ %index, %limbs.equal ]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater

check.limb.greater:                               ; preds = %limbs
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal

limbs.equal:                                      ; preds = %check.limb.greater
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal

less:                                             ; preds = %limbs, %entry
  ret i32 -1

equal:                                            ; preds = %limbs.equal, %check.empty
  ret i32 0

greater:                                          ; preds = %check.limb.greater, %check.longer
  ret i32 1
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity

left.positive:                                    ; preds = %entry
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result

check.left.negative.infinity:                     ; preds = %entry
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity

left.negative:                                    ; preds = %check.left.negative.infinity
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result

check.right.positive.infinity:                    ; preds = %check.left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity

check.right.negative.infinity:                    ; preds = %check.right.positive.infinity
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite

less:                                             ; preds = %check.right.positive.infinity
  ret i32 -1

greater:                                          ; preds = %check.right.negative.infinity
  ret i32 1

finite:                                           ; preds = %check.right.negative.infinity
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute

signed.result:                                    ; preds = %finite
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result

absolute:                                         ; preds = %finite
  %magnitude = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

declare ptr @topal_kernel_region_frame_ram_page_pool_allocate_v1(i64)

; Function Attrs: noreturn
declare void @topal_kernel_region_frame_ram_page_pool_abort_v1() #2

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.platform.allocate(i64 %length) #1 {
entry:
  %pointer = call ptr @topal_kernel_region_frame_ram_page_pool_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.region-instance.ram-page-pool.platform.exit(i64 %status) #3 {
entry:
  call void @topal_kernel_region_frame_ram_page_pool_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.region-instance.ram-page-pool.primitive.abort() #3 {
entry:
  call void @topal_kernel_region_frame_ram_page_pool_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.primitive.guard(ptr %view) #1 {
entry:
  %address = ptrtoint ptr %view to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %valid.pointer = and i1 %nonnull, %aligned
  br i1 %valid.pointer, label %view.fields, label %invalid

view.fields:                                      ; preds = %entry
  %control = load ptr, ptr %view, align 8
  %control.address = ptrtoint ptr %control to i64
  %control.nonnull = icmp ne i64 %control.address, 0
  %control.alignment = and i64 %control.address, 7
  %control.aligned = icmp eq i64 %control.alignment, 0
  %control.valid = and i1 %control.nonnull, %control.aligned
  br i1 %control.valid, label %control.fields, label %invalid

control.fields:                                   ; preds = %view.fields
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %view.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %view.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %view.epoch.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 4
  %view.owner.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 5
  %view.code.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 6
  %view.zero.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 7
  %offset = load i64, ptr %offset.pointer, align 8
  %view.count = load i64, ptr %view.count.pointer, align 8
  %view.rights = load i64, ptr %view.rights.pointer, align 8
  %view.epoch = load i64, ptr %view.epoch.pointer, align 8
  %view.owner = load i64, ptr %view.owner.pointer, align 8
  %view.code = load ptr, ptr %view.code.pointer, align 8
  %view.zero = load i64, ptr %view.zero.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_ram_page_pool_apply_v1
  %view.code.valid = icmp eq ptr %view.code, %code
  %owner.valid = icmp ne i64 %owner, 0
  %view.owner.valid = icmp eq i64 %view.owner, %owner
  %epoch.valid = icmp ne i64 %epoch, 0
  %view.epoch.valid = icmp eq i64 %view.epoch, %epoch
  %active.valid = icmp eq i64 %active, 1
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %view.rights.valid = icmp ule i64 %view.rights, %rights
  %zero.valid = icmp eq i64 %view.zero, 0
  %offset.valid = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %view.count.valid = icmp ule i64 %view.count, %remaining
  %base.address = ptrtoint ptr %base to i64
  %base.nonnull = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %issued.positive = icmp uge i64 %issued, 1
  %issued.bounded = icmp ule i64 %issued, 256
  %issued.valid = and i1 %issued.positive, %issued.bounded
  %a = and i1 %code.valid, %view.code.valid
  %b = and i1 %owner.valid, %view.owner.valid
  %c = and i1 %epoch.valid, %view.epoch.valid
  %d = and i1 %active.valid, %count.valid
  %e = and i1 %rights.valid, %view.rights.valid
  %f = and i1 %zero.valid, %offset.valid
  %g = and i1 %view.count.valid, %base.nonnull
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %ef = and i1 %e, %f
  %g.end = and i1 %g, %end.valid
  %abcd = and i1 %ab, %cd
  %efgh = and i1 %ef, %g.end
  %all.fields = and i1 %abcd, %efgh
  %valid = and i1 %all.fields, %issued.valid
  br i1 %valid, label %success, label %invalid

success:                                          ; preds = %control.fields
  %bytes = getelementptr i8, ptr %base, i64 %offset
  ret ptr %bytes

invalid:                                          ; preds = %control.fields, %view.fields, %entry
  call void @topal.region-instance.ram-page-pool.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal { i1, i64 } @topal.region-instance.ram-page-pool.primitive.index(ptr %number) #1 {
entry:
  %sign = load i64, ptr %number, align 8
  %nonnegative = icmp eq i64 %sign, 0
  br i1 %nonnegative, label %number.length, label %invalid

number.length:                                    ; preds = %entry
  %length.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %zero.result, label %bounded

zero.result:                                      ; preds = %number.length
  ret { i1, i64 } { i1 true, i64 0 }

bounded:                                          ; preds = %number.length
  %fits = icmp ule i64 %length, 2
  br i1 %fits, label %low, label %refuse

low:                                              ; preds = %bounded
  %low.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 0
  %low.word = load i32, ptr %low.pointer, align 4
  %low.value = zext i32 %low.word to i64
  %single = icmp eq i64 %length, 1
  br i1 %single, label %single.result, label %high

single.result:                                    ; preds = %low
  %one = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %low.value, 1
  ret { i1, i64 } %one

high:                                             ; preds = %low
  %high.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 1
  %high.word = load i32, ptr %high.pointer, align 4
  %high.value = zext i32 %high.word to i64
  %shifted = shl i64 %high.value, 32
  %value = or i64 %shifted, %low.value
  %two = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %value, 1
  ret { i1, i64 } %two

refuse:                                           ; preds = %bounded
  ret { i1, i64 } zeroinitializer

invalid:                                          ; preds = %entry
  call void @topal.region-instance.ram-page-pool.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.primitive.count(ptr %view) #1 {
entry:
  %bytes = call ptr @topal.region-instance.ram-page-pool.primitive.guard(ptr %view)
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %number = call ptr @topal.region-instance.ram-page-pool.runtime.int.from.u64(i64 %count)
  ret ptr %number
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %view, ptr %index) #1 {
entry:
  %bytes = call ptr @topal.region-instance.ram-page-pool.primitive.guard(ptr %view)
  %decoded = call { i1, i64 } @topal.region-instance.ram-page-pool.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %valid = and i1 %fits, %contained
  br i1 %valid, label %read, label %refuse

read:                                             ; preds = %entry
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = load i8, ptr %pointer, align 1
  %value = zext i8 %byte to i64
  %number = call ptr @topal.region-instance.ram-page-pool.runtime.int.from.u64(i64 %value)
  %some = call ptr @topal.region-instance.ram-page-pool.runtime.optional.some(ptr %number)
  ret ptr %some

refuse:                                           ; preds = %entry
  %none = call ptr @topal.region-instance.ram-page-pool.runtime.optional.none()
  ret ptr %none
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %view, ptr %index, ptr %number) #1 {
entry:
  %bytes = call ptr @topal.region-instance.ram-page-pool.primitive.guard(ptr %view)
  %decoded.index = call { i1, i64 } @topal.region-instance.ram-page-pool.primitive.index(ptr %index)
  %decoded.value = call { i1, i64 } @topal.region-instance.ram-page-pool.primitive.index(ptr %number)
  %index.fits = extractvalue { i1, i64 } %decoded.index, 0
  %offset = extractvalue { i1, i64 } %decoded.index, 1
  %value.fits = extractvalue { i1, i64 } %decoded.value, 0
  %value = extractvalue { i1, i64 } %decoded.value, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %writable = icmp eq i64 %rights, 1
  %byte.valid = icmp ule i64 %value, 255
  %both.fit = and i1 %index.fits, %value.fits
  %access = and i1 %contained, %writable
  %range = and i1 %both.fit, %byte.valid
  %valid = and i1 %access, %range
  br i1 %valid, label %write, label %refuse

write:                                            ; preds = %entry
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = trunc i64 %value to i8
  store i8 %byte, ptr %pointer, align 1
  ret i1 true

refuse:                                           ; preds = %entry
  ret i1 false
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.0(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !6 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !21, !DIExpression(), !22)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !23, !DIExpression(), !24)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !25, !DIExpression(), !26)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.0), !dbg !27
  %v4 = icmp eq i32 %v3, 0, !dbg !27
  %v5 = icmp eq i1 %v4, true, !dbg !27
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !27

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.1), !dbg !28
  br label %decision.merge.2, !dbg !28

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !29

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !27
  ret i1 %v7, !dbg !27
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.1(ptr %arg0, ptr %arg1) #1 !dbg !30 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !33, !DIExpression(), !34)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !35, !DIExpression(), !36)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !37
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !37
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !37

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !38
    #dbg_value(ptr %v4, !39, !DIExpression(), !38)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.0(ptr %arg0, ptr %arg1, ptr %v4), !dbg !40
  br label %optional.decision.merge.2, !dbg !40

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !41

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !37
  ret i1 %v6, !dbg !37
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.2(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !42 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !43, !DIExpression(), !44)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !45, !DIExpression(), !46)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !47, !DIExpression(), !48)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.2), !dbg !49
  %v4 = icmp eq i32 %v3, 0, !dbg !49
  %v5 = icmp eq i1 %v4, true, !dbg !49
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !49

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.3), !dbg !50
  br label %decision.merge.2, !dbg !50

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !51

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !49
  ret i1 %v7, !dbg !49
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.3(ptr %arg0, ptr %arg1) #1 !dbg !52 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !53, !DIExpression(), !54)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !55, !DIExpression(), !56)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !57
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !57
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !57

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !58
    #dbg_value(ptr %v4, !59, !DIExpression(), !58)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.2(ptr %arg0, ptr %arg1, ptr %v4), !dbg !60
  br label %optional.decision.merge.2, !dbg !60

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !61

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !57
  ret i1 %v6, !dbg !57
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.4(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !62 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !63, !DIExpression(), !64)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !65, !DIExpression(), !66)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !67, !DIExpression(), !68)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.4), !dbg !69
  %v4 = icmp eq i32 %v3, 0, !dbg !69
  %v5 = icmp eq i1 %v4, true, !dbg !69
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !69

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.5), !dbg !70
  br label %decision.merge.2, !dbg !70

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !71

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !69
  ret i1 %v7, !dbg !69
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.5(ptr %arg0, ptr %arg1) #1 !dbg !72 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !73, !DIExpression(), !74)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !75, !DIExpression(), !76)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !77
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !77
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !77

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !78
    #dbg_value(ptr %v4, !79, !DIExpression(), !78)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.4(ptr %arg0, ptr %arg1, ptr %v4), !dbg !80
  br label %optional.decision.merge.2, !dbg !80

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !81

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !77
  ret i1 %v6, !dbg !77
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.6(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !82 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !83, !DIExpression(), !84)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !85, !DIExpression(), !86)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !87, !DIExpression(), !88)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.6), !dbg !89
  %v4 = icmp eq i32 %v3, 0, !dbg !89
  %v5 = icmp eq i1 %v4, true, !dbg !89
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !89

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.7), !dbg !90
  br label %decision.merge.2, !dbg !90

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !91

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !89
  ret i1 %v7, !dbg !89
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.7(ptr %arg0, ptr %arg1) #1 !dbg !92 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !93, !DIExpression(), !94)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !95, !DIExpression(), !96)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !97
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !97
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !97

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !98
    #dbg_value(ptr %v4, !99, !DIExpression(), !98)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.6(ptr %arg0, ptr %arg1, ptr %v4), !dbg !100
  br label %optional.decision.merge.2, !dbg !100

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !101

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !97
  ret i1 %v6, !dbg !97
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.8(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !102 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !103, !DIExpression(), !104)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !105, !DIExpression(), !106)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !107, !DIExpression(), !108)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.8), !dbg !109
  %v4 = icmp eq i32 %v3, 0, !dbg !109
  %v5 = icmp eq i1 %v4, true, !dbg !109
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !109

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.9), !dbg !110
  br label %decision.merge.2, !dbg !110

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !111

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !109
  ret i1 %v7, !dbg !109
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.9(ptr %arg0, ptr %arg1) #1 !dbg !112 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !113, !DIExpression(), !114)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !115, !DIExpression(), !116)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !117
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !117
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !117

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !118
    #dbg_value(ptr %v4, !119, !DIExpression(), !118)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.8(ptr %arg0, ptr %arg1, ptr %v4), !dbg !120
  br label %optional.decision.merge.2, !dbg !120

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !121

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !117
  ret i1 %v6, !dbg !117
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.10(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !122 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !123, !DIExpression(), !124)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !125, !DIExpression(), !126)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !127, !DIExpression(), !128)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.10), !dbg !129
  %v4 = icmp eq i32 %v3, 0, !dbg !129
  %v5 = icmp eq i1 %v4, true, !dbg !129
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !129

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.11), !dbg !130
  br label %decision.merge.2, !dbg !130

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !131

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !129
  ret i1 %v7, !dbg !129
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.11(ptr %arg0, ptr %arg1) #1 !dbg !132 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !133, !DIExpression(), !134)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !135, !DIExpression(), !136)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !137
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !137
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !137

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !138
    #dbg_value(ptr %v4, !139, !DIExpression(), !138)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.10(ptr %arg0, ptr %arg1, ptr %v4), !dbg !140
  br label %optional.decision.merge.2, !dbg !140

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !141

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !137
  ret i1 %v6, !dbg !137
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.12(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !142 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !143, !DIExpression(), !144)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !145, !DIExpression(), !146)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !147, !DIExpression(), !148)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.12), !dbg !149
  %v4 = icmp eq i32 %v3, 0, !dbg !149
  %v5 = icmp eq i1 %v4, true, !dbg !149
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !149

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.13), !dbg !150
  br label %decision.merge.2, !dbg !150

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !151

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !149
  ret i1 %v7, !dbg !149
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.13(ptr %arg0, ptr %arg1) #1 !dbg !152 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !153, !DIExpression(), !154)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !155, !DIExpression(), !156)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !157
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !157
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !157

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !158
    #dbg_value(ptr %v4, !159, !DIExpression(), !158)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.12(ptr %arg0, ptr %arg1, ptr %v4), !dbg !160
  br label %optional.decision.merge.2, !dbg !160

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !161

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !157
  ret i1 %v6, !dbg !157
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.14(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !162 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !163, !DIExpression(), !164)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !165, !DIExpression(), !166)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !167, !DIExpression(), !168)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.14), !dbg !169
  %v4 = icmp eq i32 %v3, 0, !dbg !169
  %v5 = icmp eq i1 %v4, true, !dbg !169
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !169

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.15), !dbg !170
  br label %decision.merge.2, !dbg !170

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !171

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !169
  ret i1 %v7, !dbg !169
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.15(ptr %arg0, ptr %arg1) #1 !dbg !172 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !173, !DIExpression(), !174)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !175, !DIExpression(), !176)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !177
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !177
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !177

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !178
    #dbg_value(ptr %v4, !179, !DIExpression(), !178)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.14(ptr %arg0, ptr %arg1, ptr %v4), !dbg !180
  br label %optional.decision.merge.2, !dbg !180

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !181

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !177
  ret i1 %v6, !dbg !177
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d7.16(ptr %arg0) #1 !dbg !182 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !185, !DIExpression(), !186)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.15(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.16), !dbg !187
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !187

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !188

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !189

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v2 = phi i1 [ true, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !187
  ret i1 %v2, !dbg !187
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d6.17(ptr %arg0) #1 !dbg !190 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !191, !DIExpression(), !192)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.13(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.17), !dbg !193
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !193

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !194

decision.false.1:                                 ; preds = %entry
  %v2 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d7.16(ptr %arg0), !dbg !195
  br label %decision.merge.2, !dbg !195

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi i1 [ true, %decision.true.0 ], [ %v2, %decision.false.1 ], !dbg !193
  ret i1 %v3, !dbg !193
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d5.18(ptr %arg0) #1 !dbg !196 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !197, !DIExpression(), !198)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.11(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.18), !dbg !199
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !199

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !200

decision.false.1:                                 ; preds = %entry
  %v2 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d6.17(ptr %arg0), !dbg !201
  br label %decision.merge.2, !dbg !201

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi i1 [ true, %decision.true.0 ], [ %v2, %decision.false.1 ], !dbg !199
  ret i1 %v3, !dbg !199
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d4.19(ptr %arg0) #1 !dbg !202 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !203, !DIExpression(), !204)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.9(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.19), !dbg !205
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !205

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !206

decision.false.1:                                 ; preds = %entry
  %v2 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d5.18(ptr %arg0), !dbg !207
  br label %decision.merge.2, !dbg !207

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi i1 [ true, %decision.true.0 ], [ %v2, %decision.false.1 ], !dbg !205
  ret i1 %v3, !dbg !205
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d3.20(ptr %arg0) #1 !dbg !208 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !209, !DIExpression(), !210)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.7(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.20), !dbg !211
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !211

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !212

decision.false.1:                                 ; preds = %entry
  %v2 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d4.19(ptr %arg0), !dbg !213
  br label %decision.merge.2, !dbg !213

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi i1 [ true, %decision.true.0 ], [ %v2, %decision.false.1 ], !dbg !211
  ret i1 %v3, !dbg !211
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d2.21(ptr %arg0) #1 !dbg !214 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !215, !DIExpression(), !216)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.5(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.21), !dbg !217
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !217

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !218

decision.false.1:                                 ; preds = %entry
  %v2 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d3.20(ptr %arg0), !dbg !219
  br label %decision.merge.2, !dbg !219

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi i1 [ true, %decision.true.0 ], [ %v2, %decision.false.1 ], !dbg !217
  ret i1 %v3, !dbg !217
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d1.22(ptr %arg0) #1 !dbg !220 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !221, !DIExpression(), !222)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.3(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.22), !dbg !223
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !223

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !224

decision.false.1:                                 ; preds = %entry
  %v2 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d2.21(ptr %arg0), !dbg !225
  br label %decision.merge.2, !dbg !225

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi i1 [ true, %decision.true.0 ], [ %v2, %decision.false.1 ], !dbg !223
  ret i1 %v3, !dbg !223
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve.23(ptr %arg0) #1 !dbg !226 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !227, !DIExpression(), !228)
  %v1 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.1(ptr %arg0, ptr @topal.region-instance.ram-page-pool.literal.int.23), !dbg !229
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !229

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !230

decision.false.1:                                 ; preds = %entry
  %v2 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d1.22(ptr %arg0), !dbg !231
  br label %decision.merge.2, !dbg !231

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi i1 [ true, %decision.true.0 ], [ %v2, %decision.false.1 ], !dbg !229
  ret i1 %v3, !dbg !229
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.allocate.24(ptr %arg0, ptr %arg1) #1 !dbg !232 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !233, !DIExpression(), !234)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !235, !DIExpression(), !236)
  %v2 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.24), !dbg !237
  %v3 = icmp eq i32 %v2, 0, !dbg !237
  %v4 = icmp eq i1 %v3, true, !dbg !237
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !237

decision.true.0:                                  ; preds = %entry
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve.23(ptr %arg0), !dbg !238
  br label %decision.merge.2, !dbg !238

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !239

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v6 = phi i1 [ %v5, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !237
  ret i1 %v6, !dbg !237
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease_2dif_2doccupied.25(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !240 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !241, !DIExpression(), !242)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !243, !DIExpression(), !244)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !245, !DIExpression(), !246)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.ram-page-pool.literal.int.25), !dbg !247
  %v4 = icmp eq i32 %v3, 0, !dbg !247
  %v5 = icmp eq i1 %v4, true, !dbg !247
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !247

decision.true.0:                                  ; preds = %entry
  %v6 = call i1 @topal.region-instance.ram-page-pool.primitive.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.26), !dbg !248
  br label %decision.merge.2, !dbg !248

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !249

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !247
  ret i1 %v7, !dbg !247
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease_2dslot.26(ptr %arg0, ptr %arg1) #1 !dbg !250 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !251, !DIExpression(), !252)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !253, !DIExpression(), !254)
  %v2 = call ptr @topal.region-instance.ram-page-pool.primitive.load(ptr %arg0, ptr %arg1), !dbg !255
  %v3 = call i1 @topal.region-instance.ram-page-pool.runtime.optional.is.some(ptr %v2), !dbg !255
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !255

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.ram-page-pool.runtime.optional.payload(ptr %v2), !dbg !256
    #dbg_value(ptr %v4, !257, !DIExpression(), !256)
  %v5 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease_2dif_2doccupied.25(ptr %arg0, ptr %arg1, ptr %v4), !dbg !258
  br label %optional.decision.merge.2, !dbg !258

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !259

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi i1 [ %v5, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !255
  ret i1 %v6, !dbg !255
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease.27(ptr %arg0, ptr %arg1) #1 !dbg !260 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !261, !DIExpression(), !262)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !263, !DIExpression(), !264)
  %v2 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.27), !dbg !265
  %v3 = icmp slt i32 %v2, 0, !dbg !265
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !265

decision.true.0:                                  ; preds = %entry
  %v4 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease_2dslot.26(ptr %arg0, ptr %arg1), !dbg !266
  br label %decision.merge.2, !dbg !266

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !267

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !265
  ret i1 %v5, !dbg !265
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.release_2dor_2drefuse.28(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !268 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !269, !DIExpression(), !270)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !271, !DIExpression(), !272)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !273, !DIExpression(), !274)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.28), !dbg !275
  %v4 = icmp eq i32 %v3, 0, !dbg !275
  %v5 = icmp eq i1 %v4, true, !dbg !275
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !275

decision.true.0:                                  ; preds = %entry
  %v6 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease.27(ptr %arg0, ptr %arg2), !dbg !276
  br label %decision.merge.2, !dbg !276

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !277

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !275
  ret i1 %v7, !dbg !275
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.dispatch.29(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !278 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !279, !DIExpression(), !280)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !281, !DIExpression(), !282)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !283, !DIExpression(), !284)
  %v3 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.ram-page-pool.literal.int.29), !dbg !285
  %v4 = icmp eq i32 %v3, 0, !dbg !285
  %v5 = icmp eq i1 %v4, true, !dbg !285
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !285

decision.true.0:                                  ; preds = %entry
  %v6 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.allocate.24(ptr %arg0, ptr %arg2), !dbg !286
  br label %decision.merge.2, !dbg !286

decision.false.1:                                 ; preds = %entry
  %v7 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.release_2dor_2drefuse.28(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !287
  br label %decision.merge.2, !dbg !287

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v6, %decision.true.0 ], [ %v7, %decision.false.1 ], !dbg !285
  ret i1 %v8, !dbg !285
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.apply.30(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !288 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !289, !DIExpression(), !290)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !291, !DIExpression(), !292)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !293, !DIExpression(), !294)
  %v3 = call ptr @topal.region-instance.ram-page-pool.primitive.count(ptr %arg0), !dbg !295
    #dbg_value(ptr %v3, !296, !DIExpression(), !297)
  %v4 = call i32 @topal.region-instance.ram-page-pool.runtime.int.compare(ptr %v3, ptr @topal.region-instance.ram-page-pool.literal.int.30), !dbg !298
  %v5 = icmp eq i32 %v4, 0, !dbg !298
  %v6 = icmp eq i1 %v5, true, !dbg !298
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !298

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.dispatch.29(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !299
  br label %decision.merge.2, !dbg !299

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !300

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !298
  ret i1 %v8, !dbg !298
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define i64 @topal_kernel_region_frame_ram_page_pool_apply_v1(ptr %control, i64 %expected.owner, i64 %next.epoch, ptr %frame.words, i64 %frame.word.count) #1 {
entry:
  %frame.arity.valid = icmp eq i64 %frame.word.count, 2
  br i1 %frame.arity.valid, label %frame.control, label %invalid

frame.control:                                    ; preds = %entry
  %address = ptrtoint ptr %control to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %control.end = add i64 %address, 64
  %control.extent.valid = icmp uge i64 %control.end, %address
  %pointer.valid = and i1 %nonnull, %aligned
  %control.valid = and i1 %pointer.valid, %control.extent.valid
  br i1 %control.valid, label %fields, label %invalid

fields:                                           ; preds = %frame.control
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_ram_page_pool_apply_v1
  %owner.nonzero = icmp ne i64 %owner, 0
  %owner.matches = icmp eq i64 %owner, %expected.owner
  %owner.valid = and i1 %owner.nonzero, %owner.matches
  %epoch.bounded = icmp ne i64 %epoch, -1
  %successor = add i64 %epoch, 1
  %epoch.matches = icmp eq i64 %successor, %next.epoch
  %epoch.valid = and i1 %epoch.bounded, %epoch.matches
  %active.valid = icmp eq i64 %active, 0
  %issued.valid = icmp eq i64 %issued, 0
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %base.address = ptrtoint ptr %base to i64
  %base.valid = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %below.control = icmp ule i64 %end, %address
  %above.control = icmp uge i64 %base.address, %control.end
  %disjoint = or i1 %below.control, %above.control
  %a = and i1 %code.valid, %owner.valid
  %b = and i1 %epoch.valid, %active.valid
  %c = and i1 %issued.valid, %count.valid
  %d = and i1 %rights.valid, %base.valid
  %e = and i1 %end.valid, %disjoint
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %abcd = and i1 %ab, %cd
  %valid = and i1 %abcd, %e
  br i1 %valid, label %frame.bounds, label %invalid

frame.bounds:                                     ; preds = %fields
  %frame.address = ptrtoint ptr %frame.words to i64
  %frame.nonnull = icmp ne i64 %frame.address, 0
  %frame.alignment = and i64 %frame.address, 7
  %frame.aligned = icmp eq i64 %frame.alignment, 0
  %frame.end = add i64 %frame.address, 16
  %frame.extent.valid = icmp uge i64 %frame.end, %frame.address
  %frame.below.control = icmp ule i64 %frame.end, %address
  %frame.above.control = icmp uge i64 %frame.address, %control.end
  %frame.control.disjoint = or i1 %frame.below.control, %frame.above.control
  %frame.below.owner = icmp ule i64 %frame.end, %base.address
  %frame.above.owner = icmp uge i64 %frame.address, %end
  %frame.owner.disjoint = or i1 %frame.below.owner, %frame.above.owner
  %frame.pointer.valid = and i1 %frame.nonnull, %frame.aligned
  %frame.storage.valid = and i1 %frame.extent.valid, %frame.control.disjoint
  %frame.nonoverlapping = and i1 %frame.storage.valid, %frame.owner.disjoint
  %frame.valid = and i1 %frame.pointer.valid, %frame.nonoverlapping
  br i1 %frame.valid, label %prepare, label %invalid

prepare:                                          ; preds = %frame.bounds
  store i64 %next.epoch, ptr %epoch.pointer, align 8
  store i64 1, ptr %active.pointer, align 8
  store i64 1, ptr %issued.pointer, align 8
  %view = call ptr @topal.region-instance.ram-page-pool.platform.allocate(i64 64)
  %v0 = insertvalue %topal.KernelRegionView zeroinitializer, ptr %control, 0
  %v1 = insertvalue %topal.KernelRegionView %v0, i64 %count, 2
  %v2 = insertvalue %topal.KernelRegionView %v1, i64 %rights, 3
  %v3 = insertvalue %topal.KernelRegionView %v2, i64 %next.epoch, 4
  %v4 = insertvalue %topal.KernelRegionView %v3, i64 %owner, 5
  %v5 = insertvalue %topal.KernelRegionView %v4, ptr @topal_kernel_region_frame_ram_page_pool_apply_v1, 6
  store %topal.KernelRegionView %v5, ptr %view, align 8
  %frame.word.pointer.0 = getelementptr i64, ptr %frame.words, i64 0
  %frame.word.0 = load i64, ptr %frame.word.pointer.0, align 8
  %frame.value.0 = call ptr @topal.region-instance.ram-page-pool.runtime.int.from.u64(i64 %frame.word.0)
  %frame.word.pointer.1 = getelementptr i64, ptr %frame.words, i64 1
  %frame.word.1 = load i64, ptr %frame.word.pointer.1, align 8
  %frame.value.1 = call ptr @topal.region-instance.ram-page-pool.runtime.int.from.u64(i64 %frame.word.1)
  %accepted = call fastcc i1 @topal.region-instance.ram-page-pool.topal.fn.apply.30(ptr %view, ptr %frame.value.0, ptr %frame.value.1)
  %final.view = call ptr @topal.region-instance.ram-page-pool.primitive.guard(ptr %view)
  store ptr null, ptr %control, align 8
  store i64 0, ptr %owner.pointer, align 8
  store i64 0, ptr %active.pointer, align 8
  store ptr null, ptr %base.pointer, align 8
  store i64 0, ptr %count.pointer, align 8
  store i64 0, ptr %rights.pointer, align 8
  store i64 0, ptr %issued.pointer, align 8
  %result = zext i1 %accepted to i64
  ret i64 %result

invalid:                                          ; preds = %frame.bounds, %fields, %frame.control, %entry
  call void @topal.region-instance.ram-page-pool.primitive.abort()
  unreachable
}

attributes #0 = { noimplicitfloat noinline noredzone nounwind optnone "disable-tail-calls"="true" }
attributes #1 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #2 = { noreturn }
attributes #3 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "ram-page-pool.t", directory: "/home/mats/git/topal/linux-kernel/kernel/memory")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.0", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DIFile(filename: "page-slots.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !11, !14, !14}
!10 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!11 = !DIDerivedType(tag: DW_TAG_typedef, name: "KernelByteRegion", file: !1, baseType: !12)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64, align: 64)
!13 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalKernelRegionBorrow", flags: DIFlagFwdDecl)
!14 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !15)
!15 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !17)
!17 = !{!18, !20}
!18 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !19, size: 64, align: 64)
!19 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !19, size: 64, align: 64, offset: 64)
!21 = !DILocalVariable(name: "pool", arg: 1, scope: !6, file: !7, line: 3, type: !11)
!22 = !DILocation(line: 3, column: 25, scope: !6)
!23 = !DILocalVariable(name: "slot", arg: 2, scope: !6, file: !7, line: 3, type: !14)
!24 = !DILocation(line: 3, column: 50, scope: !6)
!25 = !DILocalVariable(name: "occupied", arg: 3, scope: !6, file: !7, line: 3, type: !14)
!26 = !DILocation(line: 3, column: 62, scope: !6)
!27 = !DILocation(line: 4, column: 3, scope: !6)
!28 = !DILocation(line: 5, column: 15, scope: !6)
!29 = !DILocation(line: 6, column: 16, scope: !6)
!30 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.1", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!31 = !DISubroutineType(types: !32)
!32 = !{!10, !11, !14}
!33 = !DILocalVariable(name: "pool", arg: 1, scope: !30, file: !7, line: 8, type: !11)
!34 = !DILocation(line: 8, column: 21, scope: !30)
!35 = !DILocalVariable(name: "slot", arg: 2, scope: !30, file: !7, line: 8, type: !14)
!36 = !DILocation(line: 8, column: 46, scope: !30)
!37 = !DILocation(line: 9, column: 3, scope: !30)
!38 = !DILocation(line: 10, column: 10, scope: !30)
!39 = !DILocalVariable(name: "occupied", scope: !30, file: !7, line: 10, type: !14)
!40 = !DILocation(line: 10, column: 24, scope: !30)
!41 = !DILocation(line: 11, column: 15, scope: !30)
!42 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.2", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!43 = !DILocalVariable(name: "pool", arg: 1, scope: !42, file: !7, line: 3, type: !11)
!44 = !DILocation(line: 3, column: 25, scope: !42)
!45 = !DILocalVariable(name: "slot", arg: 2, scope: !42, file: !7, line: 3, type: !14)
!46 = !DILocation(line: 3, column: 50, scope: !42)
!47 = !DILocalVariable(name: "occupied", arg: 3, scope: !42, file: !7, line: 3, type: !14)
!48 = !DILocation(line: 3, column: 62, scope: !42)
!49 = !DILocation(line: 4, column: 3, scope: !42)
!50 = !DILocation(line: 5, column: 15, scope: !42)
!51 = !DILocation(line: 6, column: 16, scope: !42)
!52 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.3", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!53 = !DILocalVariable(name: "pool", arg: 1, scope: !52, file: !7, line: 8, type: !11)
!54 = !DILocation(line: 8, column: 21, scope: !52)
!55 = !DILocalVariable(name: "slot", arg: 2, scope: !52, file: !7, line: 8, type: !14)
!56 = !DILocation(line: 8, column: 46, scope: !52)
!57 = !DILocation(line: 9, column: 3, scope: !52)
!58 = !DILocation(line: 10, column: 10, scope: !52)
!59 = !DILocalVariable(name: "occupied", scope: !52, file: !7, line: 10, type: !14)
!60 = !DILocation(line: 10, column: 24, scope: !52)
!61 = !DILocation(line: 11, column: 15, scope: !52)
!62 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.4", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!63 = !DILocalVariable(name: "pool", arg: 1, scope: !62, file: !7, line: 3, type: !11)
!64 = !DILocation(line: 3, column: 25, scope: !62)
!65 = !DILocalVariable(name: "slot", arg: 2, scope: !62, file: !7, line: 3, type: !14)
!66 = !DILocation(line: 3, column: 50, scope: !62)
!67 = !DILocalVariable(name: "occupied", arg: 3, scope: !62, file: !7, line: 3, type: !14)
!68 = !DILocation(line: 3, column: 62, scope: !62)
!69 = !DILocation(line: 4, column: 3, scope: !62)
!70 = !DILocation(line: 5, column: 15, scope: !62)
!71 = !DILocation(line: 6, column: 16, scope: !62)
!72 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.5", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!73 = !DILocalVariable(name: "pool", arg: 1, scope: !72, file: !7, line: 8, type: !11)
!74 = !DILocation(line: 8, column: 21, scope: !72)
!75 = !DILocalVariable(name: "slot", arg: 2, scope: !72, file: !7, line: 8, type: !14)
!76 = !DILocation(line: 8, column: 46, scope: !72)
!77 = !DILocation(line: 9, column: 3, scope: !72)
!78 = !DILocation(line: 10, column: 10, scope: !72)
!79 = !DILocalVariable(name: "occupied", scope: !72, file: !7, line: 10, type: !14)
!80 = !DILocation(line: 10, column: 24, scope: !72)
!81 = !DILocation(line: 11, column: 15, scope: !72)
!82 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.6", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!83 = !DILocalVariable(name: "pool", arg: 1, scope: !82, file: !7, line: 3, type: !11)
!84 = !DILocation(line: 3, column: 25, scope: !82)
!85 = !DILocalVariable(name: "slot", arg: 2, scope: !82, file: !7, line: 3, type: !14)
!86 = !DILocation(line: 3, column: 50, scope: !82)
!87 = !DILocalVariable(name: "occupied", arg: 3, scope: !82, file: !7, line: 3, type: !14)
!88 = !DILocation(line: 3, column: 62, scope: !82)
!89 = !DILocation(line: 4, column: 3, scope: !82)
!90 = !DILocation(line: 5, column: 15, scope: !82)
!91 = !DILocation(line: 6, column: 16, scope: !82)
!92 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.7", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!93 = !DILocalVariable(name: "pool", arg: 1, scope: !92, file: !7, line: 8, type: !11)
!94 = !DILocation(line: 8, column: 21, scope: !92)
!95 = !DILocalVariable(name: "slot", arg: 2, scope: !92, file: !7, line: 8, type: !14)
!96 = !DILocation(line: 8, column: 46, scope: !92)
!97 = !DILocation(line: 9, column: 3, scope: !92)
!98 = !DILocation(line: 10, column: 10, scope: !92)
!99 = !DILocalVariable(name: "occupied", scope: !92, file: !7, line: 10, type: !14)
!100 = !DILocation(line: 10, column: 24, scope: !92)
!101 = !DILocation(line: 11, column: 15, scope: !92)
!102 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.8", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!103 = !DILocalVariable(name: "pool", arg: 1, scope: !102, file: !7, line: 3, type: !11)
!104 = !DILocation(line: 3, column: 25, scope: !102)
!105 = !DILocalVariable(name: "slot", arg: 2, scope: !102, file: !7, line: 3, type: !14)
!106 = !DILocation(line: 3, column: 50, scope: !102)
!107 = !DILocalVariable(name: "occupied", arg: 3, scope: !102, file: !7, line: 3, type: !14)
!108 = !DILocation(line: 3, column: 62, scope: !102)
!109 = !DILocation(line: 4, column: 3, scope: !102)
!110 = !DILocation(line: 5, column: 15, scope: !102)
!111 = !DILocation(line: 6, column: 16, scope: !102)
!112 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.9", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!113 = !DILocalVariable(name: "pool", arg: 1, scope: !112, file: !7, line: 8, type: !11)
!114 = !DILocation(line: 8, column: 21, scope: !112)
!115 = !DILocalVariable(name: "slot", arg: 2, scope: !112, file: !7, line: 8, type: !14)
!116 = !DILocation(line: 8, column: 46, scope: !112)
!117 = !DILocation(line: 9, column: 3, scope: !112)
!118 = !DILocation(line: 10, column: 10, scope: !112)
!119 = !DILocalVariable(name: "occupied", scope: !112, file: !7, line: 10, type: !14)
!120 = !DILocation(line: 10, column: 24, scope: !112)
!121 = !DILocation(line: 11, column: 15, scope: !112)
!122 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.10", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!123 = !DILocalVariable(name: "pool", arg: 1, scope: !122, file: !7, line: 3, type: !11)
!124 = !DILocation(line: 3, column: 25, scope: !122)
!125 = !DILocalVariable(name: "slot", arg: 2, scope: !122, file: !7, line: 3, type: !14)
!126 = !DILocation(line: 3, column: 50, scope: !122)
!127 = !DILocalVariable(name: "occupied", arg: 3, scope: !122, file: !7, line: 3, type: !14)
!128 = !DILocation(line: 3, column: 62, scope: !122)
!129 = !DILocation(line: 4, column: 3, scope: !122)
!130 = !DILocation(line: 5, column: 15, scope: !122)
!131 = !DILocation(line: 6, column: 16, scope: !122)
!132 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.11", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!133 = !DILocalVariable(name: "pool", arg: 1, scope: !132, file: !7, line: 8, type: !11)
!134 = !DILocation(line: 8, column: 21, scope: !132)
!135 = !DILocalVariable(name: "slot", arg: 2, scope: !132, file: !7, line: 8, type: !14)
!136 = !DILocation(line: 8, column: 46, scope: !132)
!137 = !DILocation(line: 9, column: 3, scope: !132)
!138 = !DILocation(line: 10, column: 10, scope: !132)
!139 = !DILocalVariable(name: "occupied", scope: !132, file: !7, line: 10, type: !14)
!140 = !DILocation(line: 10, column: 24, scope: !132)
!141 = !DILocation(line: 11, column: 15, scope: !132)
!142 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.12", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!143 = !DILocalVariable(name: "pool", arg: 1, scope: !142, file: !7, line: 3, type: !11)
!144 = !DILocation(line: 3, column: 25, scope: !142)
!145 = !DILocalVariable(name: "slot", arg: 2, scope: !142, file: !7, line: 3, type: !14)
!146 = !DILocation(line: 3, column: 50, scope: !142)
!147 = !DILocalVariable(name: "occupied", arg: 3, scope: !142, file: !7, line: 3, type: !14)
!148 = !DILocation(line: 3, column: 62, scope: !142)
!149 = !DILocation(line: 4, column: 3, scope: !142)
!150 = !DILocation(line: 5, column: 15, scope: !142)
!151 = !DILocation(line: 6, column: 16, scope: !142)
!152 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.13", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!153 = !DILocalVariable(name: "pool", arg: 1, scope: !152, file: !7, line: 8, type: !11)
!154 = !DILocation(line: 8, column: 21, scope: !152)
!155 = !DILocalVariable(name: "slot", arg: 2, scope: !152, file: !7, line: 8, type: !14)
!156 = !DILocation(line: 8, column: 46, scope: !152)
!157 = !DILocation(line: 9, column: 3, scope: !152)
!158 = !DILocation(line: 10, column: 10, scope: !152)
!159 = !DILocalVariable(name: "occupied", scope: !152, file: !7, line: 10, type: !14)
!160 = !DILocation(line: 10, column: 24, scope: !152)
!161 = !DILocation(line: 11, column: 15, scope: !152)
!162 = distinct !DISubprogram(name: "support.page-slots.reserve-if-free", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2dif_2dfree.14", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!163 = !DILocalVariable(name: "pool", arg: 1, scope: !162, file: !7, line: 3, type: !11)
!164 = !DILocation(line: 3, column: 25, scope: !162)
!165 = !DILocalVariable(name: "slot", arg: 2, scope: !162, file: !7, line: 3, type: !14)
!166 = !DILocation(line: 3, column: 50, scope: !162)
!167 = !DILocalVariable(name: "occupied", arg: 3, scope: !162, file: !7, line: 3, type: !14)
!168 = !DILocation(line: 3, column: 62, scope: !162)
!169 = !DILocation(line: 4, column: 3, scope: !162)
!170 = !DILocation(line: 5, column: 15, scope: !162)
!171 = !DILocation(line: 6, column: 16, scope: !162)
!172 = distinct !DISubprogram(name: "support.page-slots.try-reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2etry_2dreserve.15", scope: !7, file: !7, line: 8, type: !31, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!173 = !DILocalVariable(name: "pool", arg: 1, scope: !172, file: !7, line: 8, type: !11)
!174 = !DILocation(line: 8, column: 21, scope: !172)
!175 = !DILocalVariable(name: "slot", arg: 2, scope: !172, file: !7, line: 8, type: !14)
!176 = !DILocation(line: 8, column: 46, scope: !172)
!177 = !DILocation(line: 9, column: 3, scope: !172)
!178 = !DILocation(line: 10, column: 10, scope: !172)
!179 = !DILocalVariable(name: "occupied", scope: !172, file: !7, line: 10, type: !14)
!180 = !DILocation(line: 10, column: 24, scope: !172)
!181 = !DILocation(line: 11, column: 15, scope: !172)
!182 = distinct !DISubprogram(name: "support.page-slots.reserve-7", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d7.16", scope: !7, file: !7, line: 13, type: !183, scopeLine: 13, spFlags: DISPFlagDefinition, unit: !0)
!183 = !DISubroutineType(types: !184)
!184 = !{!10, !11}
!185 = !DILocalVariable(name: "pool", arg: 1, scope: !182, file: !7, line: 13, type: !11)
!186 = !DILocation(line: 13, column: 18, scope: !182)
!187 = !DILocation(line: 14, column: 3, scope: !182)
!188 = !DILocation(line: 15, column: 15, scope: !182)
!189 = !DILocation(line: 16, column: 16, scope: !182)
!190 = distinct !DISubprogram(name: "support.page-slots.reserve-6", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d6.17", scope: !7, file: !7, line: 18, type: !183, scopeLine: 18, spFlags: DISPFlagDefinition, unit: !0)
!191 = !DILocalVariable(name: "pool", arg: 1, scope: !190, file: !7, line: 18, type: !11)
!192 = !DILocation(line: 18, column: 18, scope: !190)
!193 = !DILocation(line: 19, column: 3, scope: !190)
!194 = !DILocation(line: 20, column: 15, scope: !190)
!195 = !DILocation(line: 21, column: 16, scope: !190)
!196 = distinct !DISubprogram(name: "support.page-slots.reserve-5", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d5.18", scope: !7, file: !7, line: 23, type: !183, scopeLine: 23, spFlags: DISPFlagDefinition, unit: !0)
!197 = !DILocalVariable(name: "pool", arg: 1, scope: !196, file: !7, line: 23, type: !11)
!198 = !DILocation(line: 23, column: 18, scope: !196)
!199 = !DILocation(line: 24, column: 3, scope: !196)
!200 = !DILocation(line: 25, column: 15, scope: !196)
!201 = !DILocation(line: 26, column: 16, scope: !196)
!202 = distinct !DISubprogram(name: "support.page-slots.reserve-4", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d4.19", scope: !7, file: !7, line: 28, type: !183, scopeLine: 28, spFlags: DISPFlagDefinition, unit: !0)
!203 = !DILocalVariable(name: "pool", arg: 1, scope: !202, file: !7, line: 28, type: !11)
!204 = !DILocation(line: 28, column: 18, scope: !202)
!205 = !DILocation(line: 29, column: 3, scope: !202)
!206 = !DILocation(line: 30, column: 15, scope: !202)
!207 = !DILocation(line: 31, column: 16, scope: !202)
!208 = distinct !DISubprogram(name: "support.page-slots.reserve-3", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d3.20", scope: !7, file: !7, line: 33, type: !183, scopeLine: 33, spFlags: DISPFlagDefinition, unit: !0)
!209 = !DILocalVariable(name: "pool", arg: 1, scope: !208, file: !7, line: 33, type: !11)
!210 = !DILocation(line: 33, column: 18, scope: !208)
!211 = !DILocation(line: 34, column: 3, scope: !208)
!212 = !DILocation(line: 35, column: 15, scope: !208)
!213 = !DILocation(line: 36, column: 16, scope: !208)
!214 = distinct !DISubprogram(name: "support.page-slots.reserve-2", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d2.21", scope: !7, file: !7, line: 38, type: !183, scopeLine: 38, spFlags: DISPFlagDefinition, unit: !0)
!215 = !DILocalVariable(name: "pool", arg: 1, scope: !214, file: !7, line: 38, type: !11)
!216 = !DILocation(line: 38, column: 18, scope: !214)
!217 = !DILocation(line: 39, column: 3, scope: !214)
!218 = !DILocation(line: 40, column: 15, scope: !214)
!219 = !DILocation(line: 41, column: 16, scope: !214)
!220 = distinct !DISubprogram(name: "support.page-slots.reserve-1", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve_2d1.22", scope: !7, file: !7, line: 43, type: !183, scopeLine: 43, spFlags: DISPFlagDefinition, unit: !0)
!221 = !DILocalVariable(name: "pool", arg: 1, scope: !220, file: !7, line: 43, type: !11)
!222 = !DILocation(line: 43, column: 18, scope: !220)
!223 = !DILocation(line: 44, column: 3, scope: !220)
!224 = !DILocation(line: 45, column: 15, scope: !220)
!225 = !DILocation(line: 46, column: 16, scope: !220)
!226 = distinct !DISubprogram(name: "support.page-slots.reserve", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2ereserve.23", scope: !7, file: !7, line: 48, type: !183, scopeLine: 48, spFlags: DISPFlagDefinition, unit: !0)
!227 = !DILocalVariable(name: "pool", arg: 1, scope: !226, file: !7, line: 48, type: !11)
!228 = !DILocation(line: 48, column: 20, scope: !226)
!229 = !DILocation(line: 49, column: 3, scope: !226)
!230 = !DILocation(line: 50, column: 15, scope: !226)
!231 = !DILocation(line: 51, column: 16, scope: !226)
!232 = distinct !DISubprogram(name: "allocate", linkageName: "topal.region-instance.ram-page-pool.topal.fn.allocate.24", scope: !1, file: !1, line: 6, type: !31, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !0)
!233 = !DILocalVariable(name: "pool", arg: 1, scope: !232, file: !1, line: 6, type: !11)
!234 = !DILocation(line: 6, column: 18, scope: !232)
!235 = !DILocalVariable(name: "slot", arg: 2, scope: !232, file: !1, line: 6, type: !14)
!236 = !DILocation(line: 6, column: 43, scope: !232)
!237 = !DILocation(line: 7, column: 3, scope: !232)
!238 = !DILocation(line: 8, column: 15, scope: !232)
!239 = !DILocation(line: 9, column: 16, scope: !232)
!240 = distinct !DISubprogram(name: "support.page-slots.release-if-occupied", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease_2dif_2doccupied.25", scope: !7, file: !7, line: 53, type: !8, scopeLine: 53, spFlags: DISPFlagDefinition, unit: !0)
!241 = !DILocalVariable(name: "pool", arg: 1, scope: !240, file: !7, line: 53, type: !11)
!242 = !DILocation(line: 53, column: 29, scope: !240)
!243 = !DILocalVariable(name: "slot", arg: 2, scope: !240, file: !7, line: 53, type: !14)
!244 = !DILocation(line: 53, column: 54, scope: !240)
!245 = !DILocalVariable(name: "occupied", arg: 3, scope: !240, file: !7, line: 53, type: !14)
!246 = !DILocation(line: 53, column: 66, scope: !240)
!247 = !DILocation(line: 54, column: 3, scope: !240)
!248 = !DILocation(line: 55, column: 15, scope: !240)
!249 = !DILocation(line: 56, column: 16, scope: !240)
!250 = distinct !DISubprogram(name: "support.page-slots.release-slot", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease_2dslot.26", scope: !7, file: !7, line: 58, type: !31, scopeLine: 58, spFlags: DISPFlagDefinition, unit: !0)
!251 = !DILocalVariable(name: "pool", arg: 1, scope: !250, file: !7, line: 58, type: !11)
!252 = !DILocation(line: 58, column: 22, scope: !250)
!253 = !DILocalVariable(name: "slot", arg: 2, scope: !250, file: !7, line: 58, type: !14)
!254 = !DILocation(line: 58, column: 47, scope: !250)
!255 = !DILocation(line: 59, column: 3, scope: !250)
!256 = !DILocation(line: 60, column: 10, scope: !250)
!257 = !DILocalVariable(name: "occupied", scope: !250, file: !7, line: 60, type: !14)
!258 = !DILocation(line: 60, column: 24, scope: !250)
!259 = !DILocation(line: 61, column: 15, scope: !250)
!260 = distinct !DISubprogram(name: "support.page-slots.release", linkageName: "topal.region-instance.ram-page-pool.topal.fn.support_2epage_2dslots_2erelease.27", scope: !7, file: !7, line: 63, type: !31, scopeLine: 63, spFlags: DISPFlagDefinition, unit: !0)
!261 = !DILocalVariable(name: "pool", arg: 1, scope: !260, file: !7, line: 63, type: !11)
!262 = !DILocation(line: 63, column: 21, scope: !260)
!263 = !DILocalVariable(name: "slot", arg: 2, scope: !260, file: !7, line: 63, type: !14)
!264 = !DILocation(line: 63, column: 46, scope: !260)
!265 = !DILocation(line: 64, column: 3, scope: !260)
!266 = !DILocation(line: 65, column: 15, scope: !260)
!267 = !DILocation(line: 66, column: 16, scope: !260)
!268 = distinct !DISubprogram(name: "release-or-refuse", linkageName: "topal.region-instance.ram-page-pool.topal.fn.release_2dor_2drefuse.28", scope: !1, file: !1, line: 11, type: !8, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !0)
!269 = !DILocalVariable(name: "pool", arg: 1, scope: !268, file: !1, line: 11, type: !11)
!270 = !DILocation(line: 11, column: 27, scope: !268)
!271 = !DILocalVariable(name: "operation", arg: 2, scope: !268, file: !1, line: 11, type: !14)
!272 = !DILocation(line: 11, column: 52, scope: !268)
!273 = !DILocalVariable(name: "slot", arg: 3, scope: !268, file: !1, line: 11, type: !14)
!274 = !DILocation(line: 11, column: 69, scope: !268)
!275 = !DILocation(line: 12, column: 3, scope: !268)
!276 = !DILocation(line: 13, column: 15, scope: !268)
!277 = !DILocation(line: 14, column: 16, scope: !268)
!278 = distinct !DISubprogram(name: "dispatch", linkageName: "topal.region-instance.ram-page-pool.topal.fn.dispatch.29", scope: !1, file: !1, line: 16, type: !8, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !0)
!279 = !DILocalVariable(name: "pool", arg: 1, scope: !278, file: !1, line: 16, type: !11)
!280 = !DILocation(line: 16, column: 18, scope: !278)
!281 = !DILocalVariable(name: "operation", arg: 2, scope: !278, file: !1, line: 16, type: !14)
!282 = !DILocation(line: 16, column: 43, scope: !278)
!283 = !DILocalVariable(name: "slot", arg: 3, scope: !278, file: !1, line: 16, type: !14)
!284 = !DILocation(line: 16, column: 60, scope: !278)
!285 = !DILocation(line: 17, column: 3, scope: !278)
!286 = !DILocation(line: 18, column: 15, scope: !278)
!287 = !DILocation(line: 19, column: 16, scope: !278)
!288 = distinct !DISubprogram(name: "apply", linkageName: "topal.region-instance.ram-page-pool.topal.fn.apply.30", scope: !1, file: !1, line: 21, type: !8, scopeLine: 21, spFlags: DISPFlagDefinition, unit: !0)
!289 = !DILocalVariable(name: "pool", arg: 1, scope: !288, file: !1, line: 21, type: !11)
!290 = !DILocation(line: 21, column: 19, scope: !288)
!291 = !DILocalVariable(name: "operation", arg: 2, scope: !288, file: !1, line: 21, type: !14)
!292 = !DILocation(line: 21, column: 44, scope: !288)
!293 = !DILocalVariable(name: "slot", arg: 3, scope: !288, file: !1, line: 21, type: !14)
!294 = !DILocation(line: 21, column: 61, scope: !288)
!295 = !DILocation(line: 22, column: 13, scope: !288)
!296 = !DILocalVariable(name: "extent", scope: !288, file: !1, line: 22, type: !14)
!297 = !DILocation(line: 22, column: 3, scope: !288)
!298 = !DILocation(line: 23, column: 3, scope: !288)
!299 = !DILocation(line: 24, column: 15, scope: !288)
!300 = !DILocation(line: 25, column: 16, scope: !288)
