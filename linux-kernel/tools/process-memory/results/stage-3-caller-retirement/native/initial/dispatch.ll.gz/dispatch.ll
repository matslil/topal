target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"
; Actual bootstrap gateway dispatch; these are private provider calls.
declare ptr @topal_x86_frame_allocator_create_v1(ptr)
declare i1 @topal_frame_allocator_allocate_v1(ptr,i64,i64,ptr)
declare i1 @topal_frame_allocator_release_v1(ptr,ptr)
declare i1 @topal_frame_allocator_pin_v1(ptr,ptr,i1)
declare i1 @topal_frame_allocator_resolve_v1(ptr,ptr,ptr)
@topal_x86_frame_context_v1 = external global [16 x i64]
define internal i64 @topal_frame_kernel_boot_dispatch_v1(i64 %op,i64 %a,i64 %b,ptr %token,ptr %facts) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  switch i64 %op,label %bad [i64 0,label %create
    i64 1,label %allocate
    i64 2,label %release
    i64 3,label %pin
    i64 4,label %resolve]
create:
  %boot = inttoptr i64 %a to ptr
  %ctx = call ptr @topal_x86_frame_allocator_create_v1(ptr %boot)
  %created = ptrtoint ptr %ctx to i64
  ret i64 %created
allocate:
  %allocated = call i1 @topal_frame_allocator_allocate_v1(ptr @topal_x86_frame_context_v1,i64 %a,i64 %b,ptr %token)
  %allocation = zext i1 %allocated to i64
  ret i64 %allocation
release:
  %released = call i1 @topal_frame_allocator_release_v1(ptr @topal_x86_frame_context_v1,ptr %token)
  %releaseResult = zext i1 %released to i64
  ret i64 %releaseResult
pin:
  %valid = icmp ule i64 %a,1
  br i1 %valid,label %changePin,label %bad
changePin:
  %acquire = icmp eq i64 %a,1
  %pinned = call i1 @topal_frame_allocator_pin_v1(ptr @topal_x86_frame_context_v1,ptr %token,i1 %acquire)
  %pinResult = zext i1 %pinned to i64
  ret i64 %pinResult
resolve:
  %resolved = call i1 @topal_frame_allocator_resolve_v1(ptr @topal_x86_frame_context_v1,ptr %token,ptr %facts)
  %resolution = zext i1 %resolved to i64
  ret i64 %resolution
bad:
  ret i64 0
}

; Private translation/ABI realization. Physical selection remains ordinary Topal.
@topal_x86_frame_mm_tokens_v1 = global [6 x i64] zeroinitializer, align 8
@topal_x86_frame_mm_state_v1 = global [4 x i64] zeroinitializer, align 8
@topal_x86_frame_mm_epoch_v1 = global [2 x i64] zeroinitializer, align 8
@topal_x86_frame_details_v1 = external global [4 x i64]
@topal_bootstrap_storage = external global [0 x i8]
declare i1 @topal_frame_kernel_admit_v1(ptr,i64,i64,i64)
declare void @topal_frame_kernel_fatal_v1(ptr) noreturn

define internal i64 @m.word(ptr %p,i64 %n) nounwind noinline noredzone {
  %at = getelementptr i64,ptr %p,i64 %n
  %v = load volatile i64,ptr %at,align 8
  ret i64 %v
}
define internal void @m.put(ptr %p,i64 %n,i64 %v) nounwind noinline noredzone {
  %at = getelementptr i64,ptr %p,i64 %n
  store volatile i64 %v,ptr %at,align 8
  ret void
}
define internal void @m.require(i1 %ok) nounwind noinline noredzone {
  br i1 %ok,label %end,label %bad
bad:
  store volatile i64 3,ptr @topal_x86_frame_mm_state_v1,align 8
  call void @topal_frame_kernel_fatal_v1(ptr @topal_x86_frame_context_v1)
  unreachable
end:
  ret void
}
define internal ptr @m.context() nounwind noinline noredzone {
  %p = getelementptr i8,ptr @topal_bootstrap_storage,i64 512
  ret ptr %p
}
define internal void @m.clean_facts() nounwind noinline noredzone {
  call void @m.put(ptr @topal_x86_frame_details_v1,i64 0,i64 0)
  call void @m.put(ptr @topal_x86_frame_details_v1,i64 1,i64 0)
  call void @m.put(ptr @topal_x86_frame_details_v1,i64 2,i64 0)
  call void @m.put(ptr @topal_x86_frame_details_v1,i64 3,i64 0)
  ret void
}
define internal i64 @m.resolve(ptr %token,i64 %count,i64 %pins) nounwind noinline noredzone {
  %ok = call i1 @topal_frame_allocator_resolve_v1(ptr @topal_x86_frame_context_v1,ptr %token,ptr @topal_x86_frame_details_v1)
  call void @m.require(i1 %ok)
  %frame = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 0)
  %length = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 1)
  %alignment = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 2)
  %provenance = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 3)
  %same = icmp eq i64 %count,%length
  %one = icmp eq i64 %alignment,1
  %tag = icmp ne i64 %provenance,0
  %a = and i1 %same,%one
  %valid = and i1 %a,%tag
  call void @m.require(i1 %valid)
  %index = call i64 @m.word(ptr %token,i64 2)
  %registryWord = call i64 @m.word(ptr @topal_x86_frame_context_v1,i64 6)
  %registry = inttoptr i64 %registryWord to ptr
  %offset = mul i64 %index,8
  %record = getelementptr i64,ptr %registry,i64 %offset
  %actual = call i64 @m.word(ptr %record,i64 6)
  %pinned = icmp eq i64 %pins,%actual
  call void @m.require(i1 %pinned)
  call void @m.clean_facts()
  %base = shl i64 %frame,12
  ret i64 %base
}
define internal ptr @m.pte(i64 %index) nounwind noinline noredzone {
  %ctx = call ptr @m.context()
  %low = icmp ult i64 %index,9
  br i1 %low,label %first,label %second
first:
  %loWord = call i64 @m.word(ptr %ctx,i64 14)
  %lo = inttoptr i64 %loWord to ptr
  %loIndex = add i64 %index,503
  %a = getelementptr i64,ptr %lo,i64 %loIndex
  ret ptr %a
second:
  %root = call i64 @m.word(ptr %ctx,i64 3)
  %highWord = add i64 %root,16384
  %hi = inttoptr i64 %highWord to ptr
  %hiIndex = sub i64 %index,9
  %b = getelementptr i64,ptr %hi,i64 %hiIndex
  ret ptr %b
}
define internal void @m.hierarchy() nounwind noinline noredzone {
  %ctx = call ptr @m.context()
  %rootWord = call i64 @m.word(ptr %ctx,i64 3)
  %lowWord = call i64 @m.word(ptr %ctx,i64 14)
  %root = inttoptr i64 %rootWord to ptr
  %pml4 = call i64 @m.word(ptr %root,i64 0)
  %pdpt = call i64 @m.word(ptr %root,i64 512)
  %low = call i64 @m.word(ptr %root,i64 1026)
  %high = call i64 @m.word(ptr %root,i64 1027)
  %p = add i64 %rootWord,4096
  %d = add i64 %rootWord,8192
  %h = add i64 %rootWord,16384
  %pe = or i64 %p,7
  %de = or i64 %d,7
  %le = or i64 %lowWord,7
  %he = or i64 %h,7
  %pm = and i64 %pml4,-97
  %dm = and i64 %pdpt,-97
  %lm = and i64 %low,-97
  %hm = and i64 %high,-97
  %pOk = icmp eq i64 %pm,%pe
  %dOk = icmp eq i64 %dm,%de
  %lOk = icmp eq i64 %lm,%le
  %hOk = icmp eq i64 %hm,%he
  %a = and i1 %pOk,%dOk
  %b = and i1 %lOk,%hOk
  %ok = and i1 %a,%b
  call void @m.require(i1 %ok)
  ret void
}
define internal void @m.validate(i64 %count,i64 %base) nounwind noinline noredzone {
entry:
  call void @m.hierarchy()
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %inside = icmp ult i64 %i,519
  br i1 %inside,label %body,label %end
body:
  %pte = call ptr @m.pte(i64 %i)
  %entryWord = load volatile i64,ptr %pte,align 8
  %normalized = and i64 %entryWord,-97
  %used = icmp ult i64 %i,%count
  %delta = shl i64 %i,12
  %physical = add i64 %base,%delta
  %leaf = or i64 %physical,-9223372036854775801
  %expected = select i1 %used,i64 %leaf,i64 0
  %same = icmp eq i64 %normalized,%expected
  call void @m.require(i1 %same)
  %next = add i64 %i,1
  br label %loop
end:
  ret void
}
define internal void @m.copy(i64 %from,i64 %to,i64 %count) nounwind noinline noredzone {
entry:
  %words = shl i64 %count,9
  %src = inttoptr i64 %from to ptr
  %dst = inttoptr i64 %to to ptr
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%words
  br i1 %more,label %body,label %end
body:
  %s = getelementptr i64,ptr %src,i64 %i
  %d = getelementptr i64,ptr %dst,i64 %i
  %v = load volatile i64,ptr %s,align 8
  store volatile i64 %v,ptr %d,align 8
  %next = add i64 %i,1
  br label %loop
end:
  ret void
}
define internal void @m.erase(i64 %base,i64 %count) nounwind noinline noredzone {
entry:
  %p = inttoptr i64 %base to ptr
  %words = shl i64 %count,9
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%words
  br i1 %more,label %body,label %end
body:
  %at = getelementptr i64,ptr %p,i64 %i
  store volatile i64 0,ptr %at,align 8
  %next = add i64 %i,1
  br label %loop
end:
  ret void
}
define internal void @m.publish(i64 %oldCount,i64 %newCount,i64 %base) nounwind noinline noredzone {
entry:
  %growing = icmp ugt i64 %newCount,%oldCount
  %count = select i1 %growing,i64 %newCount,i64 %oldCount
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%count
  br i1 %more,label %body,label %invalidate
body:
  %pte = call ptr @m.pte(i64 %i)
  %used = icmp ult i64 %i,%newCount
  %offset = shl i64 %i,12
  %physical = add i64 %base,%offset
  %leaf = or i64 %physical,-9223372036854775801
  %v = select i1 %used,i64 %leaf,i64 0
  store volatile i64 %v,ptr %pte,align 8
  %next = add i64 %i,1
  br label %loop
invalidate:
  fence seq_cst
  br label %tlb
tlb:
  %j = phi i64 [0,%invalidate],[%after,%flush]
  %pending = icmp ult i64 %j,%count
  br i1 %pending,label %flush,label %end
flush:
  %delta = shl i64 %j,12
  %va = add i64 %delta,6254592
  %address = inttoptr i64 %va to ptr
  call void asm sideeffect "invlpg ($0)", "r,~{memory},~{dirflag},~{fpsr},~{flags}"(ptr %address)
  %after = add i64 %j,1
  br label %tlb
end:
  fence seq_cst
  ret void
}
define i64 @topal_frame_memory_request_v1(i64 %operation,i64 %request) nounwind noinline noredzone {
entry:
  %admitted = call i1 @topal_frame_kernel_admit_v1(ptr @topal_x86_frame_context_v1,i64 0,i64 0,i64 0)
  call void @m.require(i1 %admitted)
  %f0 = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 0)
  %f1 = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 1)
  %f2 = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 2)
  %f3 = call i64 @m.word(ptr @topal_x86_frame_details_v1,i64 3)
  %f01 = or i64 %f0,%f1
  %f23 = or i64 %f2,%f3
  %facts = or i64 %f01,%f23
  %clean = icmp eq i64 %facts,0
  call void @m.require(i1 %clean)
  %ctx = call ptr @m.context()
  %candidate = getelementptr i64,ptr @topal_x86_frame_mm_tokens_v1,i64 3
  %state = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 0)
  %virgin = icmp eq i64 %state,0
  br i1 %virgin,label %initialize,label %ready
initialize:
  %v1 = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 1)
  %v2 = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %v3 = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 3)
  %v12 = or i64 %v1,%v2
  %v123 = or i64 %v12,%v3
  %fresh = icmp eq i64 %v123,0
  call void @m.require(i1 %fresh)
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 0,i64 1)
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 1,i64 6254592)
  call void @p.initial_parent()
  br label %ready
ready:
  %live = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 0)
  %valid = icmp eq i64 %live,1
  call void @m.require(i1 %valid)
  %oldBreak = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 1)
  %oldCount = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %oldBase = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 3)
  %bounded = icmp ule i64 %oldCount,519
  call void @m.require(i1 %bounded)
  %oldLow = icmp uge i64 %oldBreak,6254592
  %oldHigh = icmp ule i64 %oldBreak,8380416
  %oldRange = and i1 %oldLow,%oldHigh
  call void @m.require(i1 %oldRange)
  %oldDifference = sub i64 %oldBreak,6254592
  %oldRounded = add i64 %oldDifference,4095
  %expectedOldCount = lshr i64 %oldRounded,12
  %coherent = icmp eq i64 %oldCount,%expectedOldCount
  call void @m.require(i1 %coherent)
  %p0 = call i64 @m.word(ptr %candidate,i64 0)
  %p1 = call i64 @m.word(ptr %candidate,i64 1)
  %p2 = call i64 @m.word(ptr %candidate,i64 2)
  %p01 = or i64 %p0,%p1
  %p012 = or i64 %p01,%p2
  %emptyCandidate = icmp eq i64 %p012,0
  call void @m.require(i1 %emptyCandidate)
  %empty = icmp eq i64 %oldCount,0
  br i1 %empty,label %no_old,label %old
no_old:
  %c0 = call i64 @m.word(ptr @topal_x86_frame_mm_tokens_v1,i64 0)
  %c1 = call i64 @m.word(ptr @topal_x86_frame_mm_tokens_v1,i64 1)
  %c2 = call i64 @m.word(ptr @topal_x86_frame_mm_tokens_v1,i64 2)
  %c01 = or i64 %c0,%c1
  %c012 = or i64 %c01,%c2
  %all = or i64 %c012,%oldBase
  %absent = icmp eq i64 %all,0
  call void @m.require(i1 %absent)
  br label %validated
old:
  %resolved = call i64 @m.resolve(ptr @topal_x86_frame_mm_tokens_v1,i64 %oldCount,i64 1)
  %same = icmp eq i64 %resolved,%oldBase
  call void @m.require(i1 %same)
  br label %validated
validated:
  %retainedBase = call i64 @m.word(ptr %ctx,i64 15)
  %sameBase = icmp eq i64 %retainedBase,%oldBase
  call void @m.require(i1 %sameBase)
  call void @m.validate(i64 %oldCount,i64 %oldBase)
  call void @p.memory_entry(i64 %operation)
  %brk = icmp eq i64 %operation,5
  %query = icmp eq i64 %request,0
  %read = and i1 %brk,%query
  br i1 %read,label %unchanged,label %range
range:
  %lower = icmp uge i64 %request,6254592
  %upper = icmp ule i64 %request,8380416
  %inside = and i1 %lower,%upper
  %destroy = xor i1 %brk,true
  %allowed = or i1 %inside,%destroy
  br i1 %allowed,label %sizing,label %unchanged
sizing:
  %newBreak = select i1 %brk,i64 %request,i64 6254592
  %difference = sub i64 %newBreak,6254592
  %rounded = add i64 %difference,4095
  %newCount = lshr i64 %rounded,12
  %sameCount = icmp eq i64 %newCount,%oldCount
  br i1 %sameCount,label %commit,label %replace
replace:
  %none = icmp eq i64 %newCount,0
  br i1 %none,label %publish,label %allocate
allocate:
  %budget = call i1 @topal_frame_kernel_admit_v1(ptr @topal_x86_frame_context_v1,i64 1,i64 %newCount,i64 1)
  call void @m.require(i1 %budget)
  %nextId = call i64 @m.word(ptr @topal_x86_frame_context_v1,i64 2)
  %notzero = icmp ne i64 %nextId,0
  %notmax = icmp ne i64 %nextId,-1
  %idOk = and i1 %notzero,%notmax
  call void @m.require(i1 %idOk)
  %allocated = call i1 @topal_frame_allocator_allocate_v1(ptr @topal_x86_frame_context_v1,i64 %newCount,i64 1,ptr %candidate)
  br i1 %allocated,label %prepare,label %unchanged
prepare:
  %physical = call i64 @m.resolve(ptr %candidate,i64 %newCount,i64 0)
  %smaller = icmp ult i64 %newCount,%oldCount
  %kept = select i1 %smaller,i64 %newCount,i64 %oldCount
  call void @m.copy(i64 %oldBase,i64 %physical,i64 %kept)
  %pinned = call i1 @topal_frame_allocator_pin_v1(ptr @topal_x86_frame_context_v1,ptr %candidate,i1 true)
  call void @m.require(i1 %pinned)
  br label %publish
publish:
  %newBase = phi i64 [0,%replace],[%physical,%prepare]
  call void @m.publish(i64 %oldCount,i64 %newCount,i64 %newBase)
  br i1 %empty,label %transfer,label %release
release:
  %unpinned = call i1 @topal_frame_allocator_pin_v1(ptr @topal_x86_frame_context_v1,ptr @topal_x86_frame_mm_tokens_v1,i1 false)
  call void @m.require(i1 %unpinned)
  call void @m.erase(i64 %oldBase,i64 %oldCount)
  %released = call i1 @topal_frame_allocator_release_v1(ptr @topal_x86_frame_context_v1,ptr @topal_x86_frame_mm_tokens_v1)
  call void @m.require(i1 %released)
  br label %transfer
transfer:
  %t0 = call i64 @m.word(ptr %candidate,i64 0)
  %t1 = call i64 @m.word(ptr %candidate,i64 1)
  %t2 = call i64 @m.word(ptr %candidate,i64 2)
  call void @m.put(ptr @topal_x86_frame_mm_tokens_v1,i64 0,i64 %t0)
  call void @m.put(ptr @topal_x86_frame_mm_tokens_v1,i64 1,i64 %t1)
  call void @m.put(ptr @topal_x86_frame_mm_tokens_v1,i64 2,i64 %t2)
  call void @m.put(ptr %candidate,i64 0,i64 0)
  call void @m.put(ptr %candidate,i64 1,i64 0)
  call void @m.put(ptr %candidate,i64 2,i64 0)
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 2,i64 %newCount)
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 3,i64 %newBase)
  call void @m.put(ptr %ctx,i64 15,i64 %newBase)
  br label %commit
commit:
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 1,i64 %newBreak)
  br i1 %brk,label %return_break,label %retire
retire:
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 0,i64 0)
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 1,i64 0)
  ret i64 1
return_break:
  ret i64 %newBreak
unchanged:
  ret i64 %oldBreak
}

define i64 @topal_frame_kernel_dispatch_v1(i64 %op,i64 %a,i64 %b,ptr %token,ptr %facts) nounwind noinline noredzone {
entry:
  %pLow = icmp uge i64 %op,9
  %pHigh = icmp ule i64 %op,13
  %pKnown = and i1 %pLow,%pHigh
  br i1 %pKnown,label %process,label %oldEntry
process:
  %pNoB = icmp eq i64 %b,0
  %pNoToken = icmp eq ptr %token,null
  %pNoFacts = icmp eq ptr %facts,null
  %pA = and i1 %pNoB,%pNoToken
  %pOk = and i1 %pA,%pNoFacts
  call void @m.require(i1 %pOk)
  %pResult = call i64 @p.request(i64 %op,i64 %a)
  ret i64 %pResult
oldEntry:
  %user_extent = icmp eq i64 %op,8
  br i1 %user_extent,label %extent,label %previous
extent:
  %direction = ptrtoint ptr %token to i64
  %known_direction = icmp ule i64 %direction,1
  %no_facts = icmp eq ptr %facts,null
  %format = and i1 %known_direction,%no_facts
  call void @m.require(i1 %format)
  %checked = call i64 @topal_x86_owned_user_extent_v1(i64 %a,i64 %b,i64 %direction)
  ret i64 %checked
previous:
  %mm = icmp uge i64 %op,5
  br i1 %mm,label %memory,label %boot
memory:
  %known = icmp ule i64 %op,7
  %zero = icmp eq i64 %b,0
  %noToken = icmp eq ptr %token,null
  %noFacts = icmp eq ptr %facts,null
  %a0 = and i1 %known,%zero
  %b0 = and i1 %noToken,%noFacts
  %ok = and i1 %a0,%b0
  call void @m.require(i1 %ok)
  %result = call i64 @topal_frame_memory_request_v1(i64 %op,i64 %a)
  call void @p.memory_return(i64 %op)
  ret i64 %result
boot:
  %normal = call i64 @topal_frame_kernel_boot_dispatch_v1(i64 %op,i64 %a,i64 %b,ptr %token,ptr %facts)
  ret i64 %normal
}

declare i64 @topal_x86_owned_user_extent_v1(i64,i64,i64)
; TK-DEC-284 unpublished preparation primitive. Actual owning brk invocation.
; Receipt: live, break, count, base, root, context, syscall epoch.
@topal_x86_process_mm_prepared_token_v1 = global [3 x i64] zeroinitializer, align 8
@topal_x86_process_mm_prepared_state_v1 = global [7 x i64] zeroinitializer, align 8
@topal_x86_frame_gateway_recovery_v1 = external global [6 x i64]

define internal void @pm.require(i1 %ok) nounwind noinline noredzone {
  br i1 %ok,label %end,label %bad
bad:
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 0,i64 3)
  call void @m.require(i1 false)
  unreachable
end:
  ret void
}
define internal void @pm.zero(ptr %p,i64 %count) nounwind noinline noredzone {
entry:
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%count
  br i1 %more,label %body,label %end
body:
  %v = call i64 @m.word(ptr %p,i64 %i)
  %zero = icmp eq i64 %v,0
  call void @pm.require(i1 %zero)
  %next = add i64 %i,1
  br label %loop
end:
  ret void
}
define internal void @pm.equal(i64 %from,i64 %to,i64 %count) nounwind noinline noredzone {
entry:
  %words = shl i64 %count,9
  %a = inttoptr i64 %from to ptr
  %b = inttoptr i64 %to to ptr
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%words
  br i1 %more,label %body,label %end
body:
  %av = call i64 @m.word(ptr %a,i64 %i)
  %bv = call i64 @m.word(ptr %b,i64 %i)
  %same = icmp eq i64 %av,%bv
  call void @pm.require(i1 %same)
  %next = add i64 %i,1
  br label %loop
end:
  ret void
}
define internal void @pm.at_prepared() nounwind noinline noredzone {
  %v = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 0)
  ret void
}
define internal void @pm.at_released() nounwind noinline noredzone {
  %v = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 0)
  ret void
}
define internal void @pm.at_erased(i64 %base,i64 %count) nounwind noinline noredzone {
  %nonempty = icmp ugt i64 %count,0
  call void @pm.require(i1 %nonempty)
  %p = inttoptr i64 %base to ptr
  %v = call i64 @m.word(ptr %p,i64 0)
  %zero = icmp eq i64 %v,0
  call void @pm.require(i1 %zero)
  ret void
}
define internal void @pm.at_unavailable() nounwind noinline noredzone {
  %v = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 0)
  ret void
}
define internal void @pm.entry() nounwind noinline noredzone {
  %admitted = call i1 @topal_frame_kernel_admit_v1(ptr @topal_x86_frame_context_v1,i64 0,i64 0,i64 0)
  call void @pm.require(i1 %admitted)
  %op = call i64 @m.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 2)
  %brk = icmp eq i64 %op,9
  call void @pm.require(i1 %brk)
  call void @pm.zero(ptr @topal_x86_frame_details_v1,i64 4)
  %live = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 0)
  %one = icmp eq i64 %live,1
  call void @pm.require(i1 %one)
  ret void
}
define internal i1 @pm.prepare() nounwind noinline noredzone {
entry:
  call void @pm.entry()
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_state_v1,i64 7)
  %ctx = call ptr @m.context()
  %oldBreak = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 1)
  %count = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %oldBase = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 3)
  %bounded = icmp ule i64 %count,519
  call void @pm.require(i1 %bounded)
  call void @m.validate(i64 %count,i64 %oldBase)
  %empty = icmp eq i64 %count,0
  br i1 %empty,label %commit,label %allocate
allocate:
  %actual = call i64 @m.resolve(ptr @topal_x86_frame_mm_tokens_v1,i64 %count,i64 1)
  %same = icmp eq i64 %actual,%oldBase
  call void @pm.require(i1 %same)
  %budget = call i1 @topal_frame_kernel_admit_v1(ptr @topal_x86_frame_context_v1,i64 1,i64 %count,i64 1)
  call void @pm.require(i1 %budget)
  %allocated = call i1 @topal_frame_allocator_allocate_v1(ptr @topal_x86_frame_context_v1,i64 %count,i64 1,ptr @topal_x86_process_mm_prepared_token_v1)
  br i1 %allocated,label %copy,label %unavailable
copy:
  %newBase = call i64 @m.resolve(ptr @topal_x86_process_mm_prepared_token_v1,i64 %count,i64 0)
  %bytes = shl i64 %count,12
  %oldEnd = add i64 %oldBase,%bytes
  %newEnd = add i64 %newBase,%bytes
  %before = icmp ule i64 %newEnd,%oldBase
  %after = icmp ule i64 %oldEnd,%newBase
  %disjoint = or i1 %before,%after
  call void @pm.require(i1 %disjoint)
  %newPointer = inttoptr i64 %newBase to ptr
  %newWords = shl i64 %count,9
  call void @pm.zero(ptr %newPointer,i64 %newWords)
  call void @m.copy(i64 %oldBase,i64 %newBase,i64 %count)
  call void @pm.equal(i64 %oldBase,i64 %newBase,i64 %count)
  %pinned = call i1 @topal_frame_allocator_pin_v1(ptr @topal_x86_frame_context_v1,ptr @topal_x86_process_mm_prepared_token_v1,i1 true)
  call void @pm.require(i1 %pinned)
  %resolved = call i64 @m.resolve(ptr @topal_x86_process_mm_prepared_token_v1,i64 %count,i64 1)
  %sameNew = icmp eq i64 %resolved,%newBase
  call void @pm.require(i1 %sameNew)
  br label %commit
commit:
  %base = phi i64 [0,%entry],[%newBase,%copy]
  %root = call i64 @m.word(ptr %ctx,i64 3)
  %ctxWord = ptrtoint ptr %ctx to i64
  %epoch = call i64 @m.word(ptr @topal_x86_frame_mm_epoch_v1,i64 0)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 1,i64 %oldBreak)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 2,i64 %count)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 3,i64 %base)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 4,i64 %root)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 5,i64 %ctxWord)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 6,i64 %epoch)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 0,i64 1)
  call void @pm.at_prepared()
  ret i1 true
unavailable:
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_state_v1,i64 7)
  call void @pm.at_unavailable()
  ret i1 false
}
define internal void @pm.cancel(i1 %prepared) nounwind noinline noredzone {
entry:
  call void @pm.entry()
  br i1 %prepared,label %validate,label %empty
empty:
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_state_v1,i64 7)
  call void @pm.at_released()
  ret void
validate:
  %ctx = call ptr @m.context()
  %live = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 0)
  %one = icmp eq i64 %live,1
  call void @pm.require(i1 %one)
  %root = call i64 @m.word(ptr %ctx,i64 3)
  %ctxWord = ptrtoint ptr %ctx to i64
  %epoch = call i64 @m.word(ptr @topal_x86_frame_mm_epoch_v1,i64 0)
  %savedRoot = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 4)
  %savedCtx = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 5)
  %savedEpoch = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 6)
  %sameRoot = icmp eq i64 %savedRoot,%root
  %sameCtx = icmp eq i64 %savedCtx,%ctxWord
  %sameEpoch = icmp eq i64 %savedEpoch,%epoch
  %a = and i1 %sameRoot,%sameCtx
  %all = and i1 %a,%sameEpoch
  call void @pm.require(i1 %all)
  %count = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 2)
  %base = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 3)
  %oldBreak = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 1)
  %oldCount = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %oldBase = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 3)
  %savedBreak = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 1)
  %sameCount = icmp eq i64 %count,%oldCount
  %sameBreak = icmp eq i64 %savedBreak,%oldBreak
  %unchanged = and i1 %sameCount,%sameBreak
  call void @pm.require(i1 %unchanged)
  call void @m.validate(i64 %oldCount,i64 %oldBase)
  %none = icmp eq i64 %count,0
  br i1 %none,label %clear,label %release
release:
  %resolved = call i64 @m.resolve(ptr @topal_x86_process_mm_prepared_token_v1,i64 %count,i64 1)
  %same = icmp eq i64 %resolved,%base
  call void @pm.require(i1 %same)
  call void @pm.equal(i64 %oldBase,i64 %base,i64 %count)
  %unpinned = call i1 @topal_frame_allocator_pin_v1(ptr @topal_x86_frame_context_v1,ptr @topal_x86_process_mm_prepared_token_v1,i1 false)
  call void @pm.require(i1 %unpinned)
  call void @m.erase(i64 %base,i64 %count)
  %pointer = inttoptr i64 %base to ptr
  %words = shl i64 %count,9
  call void @pm.zero(ptr %pointer,i64 %words)
  call void @pm.at_erased(i64 %base,i64 %count)
  %released = call i1 @topal_frame_allocator_release_v1(ptr @topal_x86_frame_context_v1,ptr @topal_x86_process_mm_prepared_token_v1)
  call void @pm.require(i1 %released)
  br label %clear
clear:
  br i1 %none,label %empty_token,label %clear_state
empty_token:
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  %zeroBase = icmp eq i64 %base,0
  call void @pm.require(i1 %zeroBase)
  br label %clear_state
clear_state:
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 0,i64 0)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 1,i64 0)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 2,i64 0)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 3,i64 0)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 4,i64 0)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 5,i64 0)
  call void @m.put(ptr @topal_x86_process_mm_prepared_state_v1,i64 6,i64 0)
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_state_v1,i64 7)
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @pm.at_released()
  ret void
}
; TK-DEC-284 / TOPAL-SYSTEMS-PROCESS-MM-001 private serialized MM owners.
; IDs: active PID/MM/generation, inactive PID/MM/generation, next MM identity.
; Tokens remain actual allocator handles; these scalar IDs grant no authority.
@topal_x86_process_mm_ids_v1 = global [7 x i64] zeroinitializer, align 8
@topal_x86_process_mm_inactive_token_v1 = global [3 x i64] zeroinitializer, align 8
@topal_x86_process_mm_inactive_state_v1 = global [4 x i64] zeroinitializer, align 8
@topal_x86_process_mm_prepared_owner_v1 = global [3 x i64] zeroinitializer, align 8
@topal_x86_process_mm_transition_v1 = global [3 x i64] zeroinitializer, align 8

define internal i64 @p.id(i64 %n) nounwind noinline noredzone {
  %v = call i64 @m.word(ptr @topal_x86_process_mm_ids_v1,i64 %n)
  ret i64 %v
}
define internal void @p.set_id(i64 %n,i64 %v) nounwind noinline noredzone {
  call void @m.put(ptr @topal_x86_process_mm_ids_v1,i64 %n,i64 %v)
  ret void
}
define internal void @p.copy(ptr %from,ptr %to,i64 %count) nounwind noinline noredzone {
entry:
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%count
  br i1 %more,label %body,label %end
body:
  %v = call i64 @m.word(ptr %from,i64 %i)
  call void @m.put(ptr %to,i64 %i,i64 %v)
  %actual = call i64 @m.word(ptr %to,i64 %i)
  %same = icmp eq i64 %v,%actual
  call void @pm.require(i1 %same)
  %next = add i64 %i,1
  br label %loop
end:
  ret void
}
define internal void @p.clear(ptr %to,i64 %count) nounwind noinline noredzone {
entry:
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%count
  br i1 %more,label %body,label %end
body:
  call void @m.put(ptr %to,i64 %i,i64 0)
  %next = add i64 %i,1
  br label %loop
end:
  call void @pm.zero(ptr %to,i64 %count)
  ret void
}
define internal ptr @p.table_storage() nounwind noinline noredzone {
  %ctx = call ptr @m.context()
  %word = call i64 @m.word(ptr %ctx,i64 116)
  %mask = and i64 %word,4095
  %aligned = icmp eq i64 %mask,0
  %nonzero = icmp ne i64 %word,0
  %end = add i64 %word,311296
  %nowrap = icmp uge i64 %end,%word
  %bounded = icmp ule i64 %end,1073741824
  %below = icmp ule i64 %end,4194304
  %above = icmp uge i64 %word,8388608
  %supervisor = or i1 %below,%above
  %a = and i1 %aligned,%nonzero
  %b = and i1 %nowrap,%bounded
  %ab = and i1 %a,%b
  %ok = and i1 %ab,%supervisor
  call void @pm.require(i1 %ok)
  %table = inttoptr i64 %word to ptr
  ret ptr %table
}
define internal ptr @p.table() nounwind noinline noredzone {
  %table = call ptr @p.table_storage()
  %live = call i64 @m.word(ptr %table,i64 0)
  %one = icmp eq i64 %live,1
  call void @pm.require(i1 %one)
  ret ptr %table
}
define internal void @p.bank(ptr %state,ptr %token) nounwind noinline noredzone {
entry:
  %live = call i64 @m.word(ptr %state,i64 0)
  %brk = call i64 @m.word(ptr %state,i64 1)
  %count = call i64 @m.word(ptr %state,i64 2)
  %base = call i64 @m.word(ptr %state,i64 3)
  %one = icmp eq i64 %live,1
  %low = icmp uge i64 %brk,6254592
  %high = icmp ule i64 %brk,8380416
  %bounded = icmp ule i64 %count,519
  %difference = sub i64 %brk,6254592
  %rounded = add i64 %difference,4095
  %expected = lshr i64 %rounded,12
  %same = icmp eq i64 %expected,%count
  %a = and i1 %one,%low
  %b = and i1 %high,%bounded
  %ab = and i1 %a,%b
  %ok = and i1 %ab,%same
  call void @pm.require(i1 %ok)
  %empty = icmp eq i64 %count,0
  br i1 %empty,label %zero,label %resolve
zero:
  call void @pm.zero(ptr %token,i64 3)
  %noBase = icmp eq i64 %base,0
  call void @pm.require(i1 %noBase)
  ret void
resolve:
  %actual = call i64 @m.resolve(ptr %token,i64 %count,i64 1)
  %equal = icmp eq i64 %actual,%base
  call void @pm.require(i1 %equal)
  ret void
}
define internal void @p.prime(i64 %op) nounwind noinline noredzone {
entry:
  %live = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 0)
  %empty = icmp eq i64 %live,0
  br i1 %empty,label %initialize,label %end
initialize:
  call void @pm.zero(ptr @topal_x86_frame_mm_state_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_frame_mm_tokens_v1,i64 6)
  call void @m.validate(i64 0,i64 0)
  %switch = icmp eq i64 %op,11
  br i1 %switch,label %saved,label %current
saved:
  %table = call ptr @p.table()
  %old = call i64 @m.word(ptr %table,i64 1071)
  br label %check
current:
  %ctx = call ptr @m.context()
  %active = call i64 @m.word(ptr %ctx,i64 15)
  br label %check
check:
  %heap = phi i64 [%old,%saved],[%active,%current]
  %none = icmp eq i64 %heap,0
  call void @pm.require(i1 %none)
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 0,i64 1)
  call void @m.put(ptr @topal_x86_frame_mm_state_v1,i64 1,i64 6254592)
  br label %end
end:
  ret void
}
define internal void @p.initialize_ids(i64 %op) nounwind noinline noredzone {
entry:
  %pid = call i64 @p.id(i64 0)
  %fresh = icmp eq i64 %pid,0
  br i1 %fresh,label %initialize,label %end
initialize:
  %switch = icmp eq i64 %op,11
  %exit = icmp eq i64 %op,12
  %needsOwner = or i1 %switch,%exit
  %allowed = xor i1 %needsOwner,true
  call void @pm.require(i1 %allowed)
  call void @pm.zero(ptr @topal_x86_process_mm_ids_v1,i64 7)
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_state_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_token_v1,i64 3)
  %table = call ptr @p.table()
  %actual = call i64 @m.word(ptr %table,i64 7)
  %parent = icmp eq i64 %actual,1
  call void @pm.require(i1 %parent)
  call void @p.set_id(i64 0,i64 1)
  call void @p.set_id(i64 1,i64 1)
  call void @p.set_id(i64 6,i64 2)
  br label %end
end:
  ret void
}
define internal void @p.initial_parent() nounwind noinline noredzone {
entry:
  %pid = call i64 @p.id(i64 0)
  %fresh = icmp eq i64 %pid,0
  br i1 %fresh,label %initialize,label %end
initialize:
  ; The checked initial-process constructor owns PID one. This runs at its
  ; first empty-heap initialization, before descriptor import and before fork.
  ; Exec already retains a bound owner and therefore takes the unchanged arm.
  call void @pm.zero(ptr @topal_x86_process_mm_ids_v1,i64 7)
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_state_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_token_v1,i64 3)
  call void @p.set_id(i64 0,i64 1)
  call void @p.set_id(i64 1,i64 1)
  call void @p.set_id(i64 6,i64 2)
  br label %end
end:
  ret void
}
define internal void @p.inactive() nounwind noinline noredzone {
entry:
  %pid = call i64 @p.id(i64 3)
  %none = icmp eq i64 %pid,0
  br i1 %none,label %empty,label %live
empty:
  %ids = getelementptr i64,ptr @topal_x86_process_mm_ids_v1,i64 3
  call void @pm.zero(ptr %ids,i64 3)
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_state_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_token_v1,i64 3)
  ret void
live:
  %activePid = call i64 @p.id(i64 0)
  %different = icmp ne i64 %pid,%activePid
  %id = call i64 @p.id(i64 4)
  %activeId = call i64 @p.id(i64 1)
  %next = call i64 @p.id(i64 6)
  %nonzero = icmp ne i64 %id,0
  %issued = icmp ult i64 %id,%next
  %distinct = icmp ne i64 %id,%activeId
  %a = and i1 %different,%nonzero
  %b = and i1 %issued,%distinct
  %ok = and i1 %a,%b
  call void @pm.require(i1 %ok)
  call void @p.bank(ptr @topal_x86_process_mm_inactive_state_v1,ptr @topal_x86_process_mm_inactive_token_v1)
  call void @p.disjoint(ptr @topal_x86_frame_mm_state_v1,ptr @topal_x86_frame_mm_tokens_v1,ptr @topal_x86_process_mm_inactive_state_v1,ptr @topal_x86_process_mm_inactive_token_v1)
  ret void
}
define internal void @p.disjoint(ptr %a,ptr %at,ptr %b,ptr %bt) nounwind noinline noredzone {
entry:
  %ac = call i64 @m.word(ptr %a,i64 2)
  %bc = call i64 @m.word(ptr %b,i64 2)
  %ae = icmp eq i64 %ac,0
  %be = icmp eq i64 %bc,0
  %empty = or i1 %ae,%be
  br i1 %empty,label %end,label %check
check:
  %ab = call i64 @m.word(ptr %a,i64 3)
  %bb = call i64 @m.word(ptr %b,i64 3)
  %abytes = shl i64 %ac,12
  %bbytes = shl i64 %bc,12
  %aend = add i64 %ab,%abytes
  %bend = add i64 %bb,%bbytes
  %before = icmp ule i64 %aend,%bb
  %after = icmp ule i64 %bend,%ab
  %separate = or i1 %before,%after
  %aid = call i64 @m.word(ptr %at,i64 1)
  %bid = call i64 @m.word(ptr %bt,i64 1)
  %distinct = icmp ne i64 %aid,%bid
  %ok = and i1 %separate,%distinct
  call void @pm.require(i1 %ok)
  br label %end
end:
  ret void
}
define internal void @p.bind(i1 %switch) nounwind noinline noredzone {
  call void @p.bank(ptr @topal_x86_frame_mm_state_v1,ptr @topal_x86_frame_mm_tokens_v1)
  %candidate = getelementptr i64,ptr @topal_x86_frame_mm_tokens_v1,i64 3
  call void @pm.zero(ptr %candidate,i64 3)
  call void @p.inactive()
  %table = call ptr @p.table()
  %pid = call i64 @p.id(i64 0)
  %inactivePid = call i64 @p.id(i64 3)
  %id = call i64 @p.id(i64 1)
  %next = call i64 @p.id(i64 6)
  %nonzero = icmp ne i64 %id,0
  %issued = icmp ult i64 %id,%next
  %idOk = and i1 %nonzero,%issued
  call void @pm.require(i1 %idOk)
  %actualPid = call i64 @m.word(ptr %table,i64 7)
  %expectedPid = select i1 %switch,i64 %inactivePid,i64 %pid
  %samePid = icmp eq i64 %actualPid,%expectedPid
  call void @pm.require(i1 %samePid)
  %ctx = call ptr @m.context()
  %base = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 3)
  %count = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %inactiveBase = call i64 @m.word(ptr @topal_x86_process_mm_inactive_state_v1,i64 3)
  %heap = call i64 @m.word(ptr %ctx,i64 15)
  %expectedHeap = select i1 %switch,i64 %inactiveBase,i64 %base
  %sameHeap = icmp eq i64 %heap,%expectedHeap
  call void @pm.require(i1 %sameHeap)
  call void @m.validate(i64 %count,i64 %base)
  ret void
}
define internal i64 @p.issue() nounwind noinline noredzone {
  %next = call i64 @p.id(i64 6)
  %nonzero = icmp ne i64 %next,0
  %room = icmp ne i64 %next,-1
  %ok = and i1 %nonzero,%room
  call void @pm.require(i1 %ok)
  %after = add i64 %next,1
  call void @p.set_id(i64 6,i64 %after)
  ret i64 %next
}
define internal void @p.prepared_empty() nounwind noinline noredzone {
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_state_v1,i64 7)
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @pm.zero(ptr @topal_x86_process_mm_prepared_owner_v1,i64 3)
  ret void
}
define internal void @p.receipt() nounwind noinline noredzone {
  call void @p.bank(ptr @topal_x86_process_mm_prepared_state_v1,ptr @topal_x86_process_mm_prepared_token_v1)
  %ctx = call ptr @m.context()
  %root = call i64 @m.word(ptr %ctx,i64 3)
  %ctxWord = ptrtoint ptr %ctx to i64
  %epoch = call i64 @m.word(ptr @topal_x86_frame_mm_epoch_v1,i64 0)
  %r = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 4)
  %c = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 5)
  %e = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 6)
  %sameR = icmp eq i64 %r,%root
  %sameC = icmp eq i64 %c,%ctxWord
  %sameE = icmp eq i64 %e,%epoch
  %a = and i1 %sameR,%sameC
  %ok = and i1 %a,%sameE
  call void @pm.require(i1 %ok)
  %pid = call i64 @p.id(i64 0)
  %id = call i64 @p.id(i64 1)
  %generation = call i64 @p.id(i64 2)
  %pPid = call i64 @m.word(ptr @topal_x86_process_mm_prepared_owner_v1,i64 0)
  %pId = call i64 @m.word(ptr @topal_x86_process_mm_prepared_owner_v1,i64 1)
  %pGeneration = call i64 @m.word(ptr @topal_x86_process_mm_prepared_owner_v1,i64 2)
  %sameP = icmp eq i64 %pid,%pPid
  %sameI = icmp eq i64 %id,%pId
  %sameG = icmp eq i64 %generation,%pGeneration
  %b = and i1 %sameP,%sameI
  %bound = and i1 %b,%sameG
  call void @pm.require(i1 %bound)
  ret void
}
define internal void @p.retire(ptr %state,ptr %token) nounwind noinline noredzone {
entry:
  call void @p.bank(ptr %state,ptr %token)
  %count = call i64 @m.word(ptr %state,i64 2)
  %base = call i64 @m.word(ptr %state,i64 3)
  %empty = icmp eq i64 %count,0
  br i1 %empty,label %clear,label %release
release:
  %unpinned = call i1 @topal_frame_allocator_pin_v1(ptr @topal_x86_frame_context_v1,ptr %token,i1 false)
  call void @pm.require(i1 %unpinned)
  call void @m.erase(i64 %base,i64 %count)
  %pointer = inttoptr i64 %base to ptr
  %words = shl i64 %count,9
  call void @pm.zero(ptr %pointer,i64 %words)
  %released = call i1 @topal_frame_allocator_release_v1(ptr @topal_x86_frame_context_v1,ptr %token)
  call void @pm.require(i1 %released)
  br label %clear
clear:
  call void @pm.zero(ptr %token,i64 3)
  call void @p.clear(ptr %state,i64 4)
  ret void
}
define internal i64 @p.prepare() nounwind noinline noredzone {
entry:
  %pid = call i64 @p.id(i64 0)
  %inactive = call i64 @p.id(i64 3)
  %parent = icmp eq i64 %pid,1
  %alone = icmp eq i64 %inactive,0
  %allowed = and i1 %parent,%alone
  call void @pm.require(i1 %allowed)
  call void @p.prepared_empty()
  %ok = call i1 @pm.prepare()
  br i1 %ok,label %remember,label %end
remember:
  call void @p.copy(ptr @topal_x86_process_mm_ids_v1,ptr @topal_x86_process_mm_prepared_owner_v1,i64 3)
  br label %end
end:
  %result = zext i1 %ok to i64
  ret i64 %result
}
define internal i64 @p.commit(i64 %child) nounwind noinline noredzone {
  call void @p.receipt()
  call void @p.disjoint(ptr @topal_x86_frame_mm_state_v1,ptr @topal_x86_frame_mm_tokens_v1,ptr @topal_x86_process_mm_prepared_state_v1,ptr @topal_x86_process_mm_prepared_token_v1)
  %table = call ptr @p.table()
  %pid = call i64 @p.id(i64 0)
  %parent = icmp eq i64 %pid,1
  call void @pm.require(i1 %parent)
  %inactivePid = call i64 @p.id(i64 3)
  %alone = icmp eq i64 %inactivePid,0
  call void @pm.require(i1 %alone)
  %header = call i64 @m.word(ptr %table,i64 1024)
  %unused = icmp eq i64 %header,0
  call void @pm.require(i1 %unused)
  %pending = call i64 @m.word(ptr %table,i64 1026)
  %same = icmp eq i64 %pending,%child
  %minimum = icmp uge i64 %child,2
  %maximum = icmp ule i64 %child,2147483647
  %range = and i1 %minimum,%maximum
  %valid = and i1 %same,%range
  call void @pm.require(i1 %valid)
  %oldCount = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %oldBase = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 3)
  %newCount = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 2)
  %newBase = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 3)
  %oldBreak = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 1)
  %newBreak = call i64 @m.word(ptr @topal_x86_process_mm_prepared_state_v1,i64 1)
  %sameCount = icmp eq i64 %oldCount,%newCount
  %sameBreak = icmp eq i64 %oldBreak,%newBreak
  %equal = and i1 %sameCount,%sameBreak
  call void @pm.require(i1 %equal)
  call void @pm.equal(i64 %oldBase,i64 %newBase,i64 %oldCount)
  %id = call i64 @p.issue()
  %generation = call i64 @p.id(i64 2)
  call void @m.put(ptr @topal_x86_process_mm_transition_v1,i64 0,i64 %child)
  call void @m.put(ptr @topal_x86_process_mm_transition_v1,i64 1,i64 %id)
  call void @m.put(ptr @topal_x86_process_mm_transition_v1,i64 2,i64 %generation)
  call void @m.publish(i64 %oldCount,i64 %newCount,i64 %newBase)
  %inactiveIds = getelementptr i64,ptr @topal_x86_process_mm_ids_v1,i64 3
  call void @p.copy(ptr @topal_x86_frame_mm_tokens_v1,ptr @topal_x86_process_mm_inactive_token_v1,i64 3)
  call void @p.copy(ptr @topal_x86_frame_mm_state_v1,ptr @topal_x86_process_mm_inactive_state_v1,i64 4)
  call void @p.copy(ptr @topal_x86_process_mm_ids_v1,ptr %inactiveIds,i64 3)
  call void @p.copy(ptr @topal_x86_process_mm_prepared_token_v1,ptr @topal_x86_frame_mm_tokens_v1,i64 3)
  call void @p.copy(ptr @topal_x86_process_mm_prepared_state_v1,ptr @topal_x86_frame_mm_state_v1,i64 4)
  call void @p.copy(ptr @topal_x86_process_mm_transition_v1,ptr @topal_x86_process_mm_ids_v1,i64 3)
  %ctx = call ptr @m.context()
  call void @m.put(ptr %ctx,i64 15,i64 %newBase)
  call void @p.clear(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @p.clear(ptr @topal_x86_process_mm_prepared_state_v1,i64 7)
  call void @p.clear(ptr @topal_x86_process_mm_prepared_owner_v1,i64 3)
  call void @p.clear(ptr @topal_x86_process_mm_transition_v1,i64 3)
  ret i64 1
}
define internal i64 @p.switch() nounwind noinline noredzone {
  call void @p.prepared_empty()
  %inactive = call i64 @p.id(i64 3)
  %live = icmp ne i64 %inactive,0
  call void @pm.require(i1 %live)
  %table = call ptr @p.table()
  %oldPid = call i64 @m.word(ptr %table,i64 1543)
  %sourcePid = call i64 @p.id(i64 0)
  %sameSource = icmp eq i64 %oldPid,%sourcePid
  call void @pm.require(i1 %sameSource)
  %oldCount = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %newCount = call i64 @m.word(ptr @topal_x86_process_mm_inactive_state_v1,i64 2)
  %newBase = call i64 @m.word(ptr @topal_x86_process_mm_inactive_state_v1,i64 3)
  call void @m.publish(i64 %oldCount,i64 %newCount,i64 %newBase)
  %inactiveIds = getelementptr i64,ptr @topal_x86_process_mm_ids_v1,i64 3
  call void @p.copy(ptr @topal_x86_frame_mm_tokens_v1,ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @p.copy(ptr @topal_x86_process_mm_inactive_token_v1,ptr @topal_x86_frame_mm_tokens_v1,i64 3)
  call void @p.copy(ptr @topal_x86_process_mm_prepared_token_v1,ptr @topal_x86_process_mm_inactive_token_v1,i64 3)
  call void @p.copy(ptr @topal_x86_frame_mm_state_v1,ptr @topal_x86_process_mm_prepared_state_v1,i64 4)
  call void @p.copy(ptr @topal_x86_process_mm_inactive_state_v1,ptr @topal_x86_frame_mm_state_v1,i64 4)
  call void @p.copy(ptr @topal_x86_process_mm_prepared_state_v1,ptr @topal_x86_process_mm_inactive_state_v1,i64 4)
  call void @p.copy(ptr @topal_x86_process_mm_ids_v1,ptr @topal_x86_process_mm_transition_v1,i64 3)
  call void @p.copy(ptr %inactiveIds,ptr @topal_x86_process_mm_ids_v1,i64 3)
  call void @p.copy(ptr @topal_x86_process_mm_transition_v1,ptr %inactiveIds,i64 3)
  call void @p.clear(ptr @topal_x86_process_mm_prepared_token_v1,i64 3)
  call void @p.clear(ptr @topal_x86_process_mm_prepared_state_v1,i64 7)
  call void @p.clear(ptr @topal_x86_process_mm_transition_v1,i64 3)
  ret i64 1
}
define internal i64 @p.child_exit() nounwind noinline noredzone {
  call void @p.prepared_empty()
  %pid = call i64 @p.id(i64 0)
  %parent = call i64 @p.id(i64 3)
  %child = icmp uge i64 %pid,2
  %one = icmp eq i64 %parent,1
  %ok = and i1 %child,%one
  call void @pm.require(i1 %ok)
  %table = call ptr @p.table()
  %savedPid = call i64 @m.word(ptr %table,i64 1543)
  %matches = icmp eq i64 %savedPid,1
  call void @pm.require(i1 %matches)
  %oldCount = call i64 @m.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %newCount = call i64 @m.word(ptr @topal_x86_process_mm_inactive_state_v1,i64 2)
  %newBase = call i64 @m.word(ptr @topal_x86_process_mm_inactive_state_v1,i64 3)
  call void @m.publish(i64 %oldCount,i64 %newCount,i64 %newBase)
  call void @p.retire(ptr @topal_x86_frame_mm_state_v1,ptr @topal_x86_frame_mm_tokens_v1)
  %inactiveIds = getelementptr i64,ptr @topal_x86_process_mm_ids_v1,i64 3
  call void @p.copy(ptr @topal_x86_process_mm_inactive_token_v1,ptr @topal_x86_frame_mm_tokens_v1,i64 3)
  call void @p.copy(ptr @topal_x86_process_mm_inactive_state_v1,ptr @topal_x86_frame_mm_state_v1,i64 4)
  call void @p.copy(ptr %inactiveIds,ptr @topal_x86_process_mm_ids_v1,i64 3)
  %ctx = call ptr @m.context()
  call void @m.put(ptr %ctx,i64 15,i64 %newBase)
  call void @p.clear(ptr @topal_x86_process_mm_inactive_token_v1,i64 3)
  call void @p.clear(ptr @topal_x86_process_mm_inactive_state_v1,i64 4)
  call void @p.clear(ptr %inactiveIds,i64 3)
  ret i64 1
}
define internal i64 @p.cancel_inactive() nounwind noinline noredzone {
entry:
  call void @p.prepared_empty()
  %pid = call i64 @p.id(i64 0)
  %parent = icmp eq i64 %pid,1
  call void @pm.require(i1 %parent)
  %inactive = call i64 @p.id(i64 3)
  %none = icmp eq i64 %inactive,0
  br i1 %none,label %end,label %cancel
cancel:
  %table = call ptr @p.table()
  %header = call i64 @m.word(ptr %table,i64 1024)
  %pending = call i64 @m.word(ptr %table,i64 1026)
  %live = icmp eq i64 %header,1
  %same = icmp eq i64 %pending,%inactive
  %valid = and i1 %live,%same
  call void @pm.require(i1 %valid)
  call void @p.retire(ptr @topal_x86_process_mm_inactive_state_v1,ptr @topal_x86_process_mm_inactive_token_v1)
  %ids = getelementptr i64,ptr @topal_x86_process_mm_ids_v1,i64 3
  call void @p.clear(ptr %ids,i64 3)
  br label %end
end:
  ret i64 1
}
define internal i64 @p.request(i64 %op,i64 %argument) nounwind noinline noredzone {
entry:
  %admitted = call i1 @topal_frame_kernel_admit_v1(ptr @topal_x86_frame_context_v1,i64 0,i64 0,i64 0)
  call void @pm.require(i1 %admitted)
  call void @pm.zero(ptr @topal_x86_frame_details_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_process_mm_transition_v1,i64 3)
  %commit = icmp eq i64 %op,10
  %noArgument = icmp eq i64 %argument,0
  %format = or i1 %commit,%noArgument
  call void @pm.require(i1 %format)
  call void @p.prime(i64 %op)
  call void @p.initialize_ids(i64 %op)
  %switch = icmp eq i64 %op,11
  call void @p.bind(i1 %switch)
  switch i64 %op,label %bad [i64 9,label %prepare
    i64 10,label %create i64 11,label %handoff i64 12,label %exit i64 13,label %cancel]
prepare:
  %p = call i64 @p.prepare()
  ret i64 %p
create:
  %c = call i64 @p.commit(i64 %argument)
  ret i64 %c
handoff:
  %h = call i64 @p.switch()
  ret i64 %h
exit:
  %e = call i64 @p.child_exit()
  ret i64 %e
cancel:
  %r = call i64 @p.cancel_inactive()
  ret i64 %r
bad:
  call void @pm.require(i1 false)
  unreachable
}
define internal void @p.memory_entry(i64 %op) nounwind noinline noredzone {
entry:
  %pid = call i64 @p.id(i64 0)
  %unbound = icmp eq i64 %pid,0
  %cleanup = icmp eq i64 %op,6
  %skip = or i1 %unbound,%cleanup
  br i1 %skip,label %end,label %check
check:
  call void @pm.zero(ptr @topal_x86_process_mm_transition_v1,i64 3)
  call void @p.prepared_empty()
  ; The ordinary MM request has already bound its exact active context/base,
  ; complete heap and allocator handle. Descriptor initialization is a distinct
  ; lifetime: exec retains it even while the new image's phase counter is zero.
  call void @p.bank(ptr @topal_x86_frame_mm_state_v1,ptr @topal_x86_frame_mm_tokens_v1)
  call void @p.inactive()
  %table = call ptr @p.table_storage()
  %state = call i64 @m.word(ptr %table,i64 0)
  %known = icmp ule i64 %state,1
  call void @pm.require(i1 %known)
  %ready = icmp eq i64 %state,1
  br i1 %ready,label %descriptor,label %end
descriptor:
  call void @p.bind(i1 false)
  br label %end
end:
  ret void
}
define internal void @p.memory_return(i64 %op) nounwind noinline noredzone {
entry:
  %exec = icmp eq i64 %op,7
  %cleanup = icmp eq i64 %op,6
  br i1 %cleanup,label %retired,label %check
check:
  %pid = call i64 @p.id(i64 0)
  %bound = icmp ne i64 %pid,0
  %advance = and i1 %exec,%bound
  br i1 %advance,label %generation,label %end
generation:
  call void @pm.zero(ptr @topal_x86_frame_mm_state_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_frame_mm_tokens_v1,i64 6)
  %old = call i64 @p.id(i64 2)
  %room = icmp ne i64 %old,-1
  call void @pm.require(i1 %room)
  %id = call i64 @p.issue()
  %nextGeneration = add i64 %old,1
  call void @p.set_id(i64 1,i64 %id)
  call void @p.set_id(i64 2,i64 %nextGeneration)
  br label %end
retired:
  call void @pm.zero(ptr @topal_x86_frame_mm_state_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_frame_mm_tokens_v1,i64 6)
  call void @p.prepared_empty()
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_state_v1,i64 4)
  call void @pm.zero(ptr @topal_x86_process_mm_inactive_token_v1,i64 3)
  call void @pm.zero(ptr @topal_x86_process_mm_transition_v1,i64 3)
  call void @p.clear(ptr @topal_x86_process_mm_ids_v1,i64 7)
  br label %end
end:
  ret void
}
