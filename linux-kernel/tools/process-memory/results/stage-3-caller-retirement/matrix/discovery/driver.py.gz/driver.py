"""Source-frozen ordinary MM VM and observation-only qualification.

The earlier full compiler run is reused only after exact relevant source checks.
No production source, C application, compiler semantics or old reuse guard changes.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import hashes,watched,VALIDATIONS


def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def compiler_reference(paths):
    reference=root/'linux-kernel/tools/process-memory/results/stage-3-prelude-stat'
    raw=(root/(str(reference.relative_to(root))+'-review.json')).read_bytes()
    review=json.loads(raw);qualified=review['qualification']
    assert review['passed'] and qualified['passed'] and qualified['exit_code']==0
    assert qualified['source_hashes_before']==qualified['source_hashes_after']
    assert set(qualified['validation'])==set(VALIDATIONS)
    assert all(row['status']=='complete' and row['exit_code']==0 for row in qualified['validation'].values())
    manifest=(reference/'manifest.json').read_bytes()
    assert fact(manifest)==review['archive_manifest']
    assert fact(manifest)['sha256']=='560238583f342343cf601fe648dcb1a0e9ecf6d764f72fb95f63620ee16d495d'
    name='matrix/validation/compiler-units.stdout.log.gz';packed=(reference/name).read_bytes()
    assert fact(packed)==json.loads(manifest)[name]
    compiler_log=gzip.decompress(packed)
    assert b'test result: ok. 383 passed; 0 failed; 25 ignored; 0 measured; 0 filtered out' in compiler_log
    assert qualified['validation']['compiler-units']['argv']==[
        'rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1']
    commit='b754f06a159075a66c01ed509eab42a78b7cc6fd'
    protected=['src','docs','se','spec','scripts','Cargo.toml','Cargo.lock','AGENTS.md',
        'linux-kernel/kernel','linux-kernel/design']
    changed=subprocess.check_output(['rtk','proxy','git','diff','--name-only',commit,'--']+protected,cwd=root)
    assert not changed.strip(),changed.decode()
    before=qualified['source_hashes_before']
    relevant={name:sha for name,sha in before.items() if name.startswith('src/topal-compiler/')
        or name.endswith('.c') or name in ['Cargo.toml','Cargo.lock','AGENTS.md','scripts/run_bounded.py']}
    actual={name for name in paths if name.startswith('src/topal-compiler/')
        or name.endswith('.c') or name in ['Cargo.toml','Cargo.lock','AGENTS.md','scripts/run_bounded.py']}
    assert actual==set(relevant) and hashes(relevant)==relevant
    return dict(commit=commit,review=fact(raw),manifest=fact(manifest),compiler_log=fact(compiler_log),
        unchanged_relevant_inputs=len(relevant),compiler_passed=383,compiler_ignored=25,
        original_resource_accounting_complete=False,
        scope='Earlier actual full compiler command and its recorded exit0, not rerun. Compiler/dependency/authority/kernel/C sources are unchanged; this increment adds only observation/readback/model code. Original driver recovery and incomplete exact original cgroup accounting remain explicit in the retained reference.')


parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('name',nargs='?',default='caller-retirement-stage')
args=parser.parse_args();assert re.fullmatch(r'caller-retirement-stage(?:-[0-9]+)?',args.name)
output=cache/args.name;output.mkdir(exist_ok=False)
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
def resources():return {name:(directory/name).read_text().strip() for name in
    ['memory.max','memory.swap.max','memory.peak','memory.events']}
paths=watched();assert 'topal-as-dsl.md' not in paths
before=hashes(paths);reference=compiler_reference(paths)
script=Path(__file__).read_bytes();(output/'driver.py').write_bytes(script)
report=dict(passed=False,compiler_reference=reference,source_hashes_before=before,
    validation={},cohorts=[],group=group,resource_samples=[resources()],
    scope='One fresh complete ordinary process/MM VM with first-per-site read-only normal-return samples; fresh workspace/models/ABI/format/ceiling checks. Earlier unchanged full383compiler qualification is identified, not rerun. No every path, continuous lifetime, fatal/exception or public/initial Linux qualification.')
start=time.monotonic();log=(output/'driver.log').open('w',buffering=1)
def announce(*values):print(*values,file=log,flush=True)
def progress():
    report['resource_samples'].append(resources())
    (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
temporary=cache/'caller-retirement-validation-tmp';temporary.mkdir(exist_ok=True)
environment=dict(os.environ,RUST_MIN_STACK='16777216',PYTHONDONTWRITEBYTECODE='1',
    TMPDIR=str(temporary),RUST_TEST_THREADS='2')
for name in ['TOPAL_TEST_PROCESS_MM_PUBLICATION','TOPAL_TEST_PROCESS_MM_PREPARATION',
             'TOPAL_TEST_PROCESS_MM_CALLER_RETIREMENT']:environment.pop(name,None)
report['environment']={name:environment[name] for name in ['RUST_MIN_STACK','TMPDIR','RUST_TEST_THREADS','PYTHONDONTWRITEBYTECODE']}
failure=0;progress()
try:
    native=dict(environment,TOPAL_TEST_PROCESS_MM_CALLER_RETIREMENT='1')
    command=['rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1',
        'systems_frame_target::root_tests::process_mm_fork_handoff_and_exit_preserve_independent_heap_owners',
        '--','--ignored','--exact','--test-threads=1','--nocapture']
    began=time.monotonic();announce('ordinary native started')
    with (output/'native.log').open('w') as stream:
        completed=subprocess.run(command,cwd=root,env=native,stdout=stream,stderr=subprocess.STDOUT)
    text=(output/'native.log').read_text()
    builds=[Path(path.strip()).resolve() for path in re.findall(r'actual frame source root: ([^\n]+)',text)]
    row=dict(label='ordinary-caller-retirement',argv=command,exit_code=completed.returncode,
        elapsed_seconds=time.monotonic()-began,environment={'TOPAL_TEST_PROCESS_MM_CALLER_RETIREMENT':'1'},
        builds=[path.relative_to(root).as_posix() for path in builds]);report['cohorts'].append(row);progress()
    announce('ordinary native',completed.returncode)
    failure=completed.returncode
    if failure:raise RuntimeError('native command failed; see retained native.log')
    assert len(builds)==1 and builds[0].is_relative_to(cache)
    build=builds[0];assert fact((build/'kernel.elf').read_bytes())['sha256']=='b8212e5e9aca715d8db0d863cbc9655ed989c3884b938b57055c3e22e04d0a7c'
    command=['rtk','proxy','python3','-B','linux-kernel/tools/process-memory/readback_caller_retirement.py',str(build)]
    with (output/'readback.stdout.log').open('w') as out,(output/'readback.stderr.log').open('w') as err:
        completed=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err)
    row['readback']=dict(argv=command,exit_code=completed.returncode);progress()
    announce('ordinary readback',completed.returncode);failure=completed.returncode
    if failure:raise RuntimeError('saved caller reader failed; see retained readback.stderr.log')
    result=json.loads((build/'process-mm-users/caller-retirement-readback.json').read_bytes())
    report['caller_summary']={name:result[name] for name in
        ['sampled_sites','total_sites','outer_adapter_samples','both_alignments_observed','missing_alignments']}
    for name,arguments in VALIDATIONS.items():
        if name=='compiler-units':continue
        command=['rtk','proxy']+arguments;began=time.monotonic()
        report['validation'][name]=dict(argv=command,status='running');progress();announce(name,'started')
        with (output/(name+'.stdout.log')).open('w') as out,(output/(name+'.stderr.log')).open('w') as err:
            completed=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err)
        report['validation'][name].update(status='complete',exit_code=completed.returncode,
            elapsed_seconds=time.monotonic()-began);progress();announce(name,completed.returncode)
        failure=completed.returncode
        if failure:raise RuntimeError('qualification failed: '+name)
except BaseException:
    report['failure']=traceback.format_exc();announce(report['failure']);failure=failure or 1
finally:
    after=hashes(paths);same=before==after and paths==watched()
    same_driver=Path(__file__).read_bytes()==script
    report.update(passed=not failure and len(report['validation'])==6 and same and same_driver,
        exit_code=failure,source_hashes_after=after,source_changes_during_run=not same,
        driver_unchanged=same_driver,elapsed_seconds=time.monotonic()-start,resources=resources())
    (output/'run.json').write_text(json.dumps(report,indent=2)+'\n')
    announce('finished',report['passed'],'elapsed',report['elapsed_seconds'])
    log.close()
raise SystemExit(failure or int(not report['passed']))
