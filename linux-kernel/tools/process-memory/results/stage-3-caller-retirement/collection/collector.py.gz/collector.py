"""Freeze both attempts and replay the corrected and original failed readers."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
matrix=cache/'caller-retirement-stage-3';first_matrix=cache/'caller-retirement-stage'
middle_matrix=cache/'caller-retirement-stage-2'
archive=root/'linux-kernel/tools/process-memory/results/stage-3-caller-retirement'
replay=cache/'caller-retirement-frozen-replay'
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
began=time.monotonic()
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
run=json.loads((matrix/'run.json').read_bytes());failed=json.loads((first_matrix/'run.json').read_bytes())
discovery=json.loads((middle_matrix/'run.json').read_bytes())
assert run['passed'] and run['exit_code']==0 and len(run['validation'])==6
assert run['source_hashes_before']==run['source_hashes_after'] and not run['source_changes_during_run']
assert run['driver_unchanged'] and all(row['status']=='complete' and row['exit_code']==0 for row in run['validation'].values())
assert not failed['passed'] and failed['exit_code']==1 and not failed['source_changes_during_run']
assert failed['cohorts'][0]['exit_code']==0 and failed['cohorts'][0]['readback']['exit_code']==1
assert 'ValueError: caller admission/result carry' in (first_matrix/'readback.stderr.log').read_text()
assert not discovery['passed'] and discovery['exit_code']==1 and not discovery['source_changes_during_run']
assert discovery['cohorts'][0]['exit_code']==discovery['cohorts'][0]['readback']['exit_code']==0
assert discovery['validation']['process-memory-models']['exit_code']==1
assert "ImportError: 'test_model' module incorrectly imported" in (middle_matrix/'process-memory-models.stderr.log').read_text()
assert len(run['cohorts'])==len(failed['cohorts'])==len(discovery['cohorts'])==1
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from readback_caller_retirement import readback
from process_native import require
archive.mkdir(exist_ok=False);manifest={}
def save(name,raw):
    target=archive/name;assert target.resolve().is_relative_to(archive)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);manifest[name]=fact(raw)
def packed(name,raw):save(name+'.gz',gzip.compress(raw,mtime=0))
report=dict(passed=True,schema='topal-process-mm-caller-retirement-v1',sources={},
    historical_sources={'initial':{},'discovery':{}},cohorts={},compiler_reference=run['compiler_reference'],
    scope='Three actual ordinary MM VMs: initial native success with a retained reader-vocabulary failure, subsequent native/reader success with a retained test-discovery import failure, and a fresh complete corrected qualification. Frozen replay is saved-data/source/model work, not another VM or compiler build. Every argument/path, continuous lifetime, fatal/exception and production/initial Linux acceptance remain open.')
for name,sha in run['source_hashes_before'].items():
    raw=(root/name).read_bytes();assert fact(raw)['sha256']==sha
    report['sources'][name]=fact(raw);packed('inputs/'+name,raw)
    for label,old,folder in [('initial',failed,first_matrix),('discovery',discovery,middle_matrix)]:
        if old['source_hashes_before'][name]!=sha:
            previous=(folder/'failure-inputs'/name).read_bytes()
            assert fact(previous)['sha256']==old['source_hashes_before'][name]
            report['historical_sources'][label][name]=fact(previous)
            packed('historical-inputs/'+label+'/'+name,previous)
assert set(report['historical_sources']['initial'])=={'linux-kernel/tools/process-memory/'+name for name in
    ['caller_retirement.py','readback_caller_retirement.py','test_caller_retirement.py']}
assert set(report['historical_sources']['discovery'])=={'linux-kernel/tools/process-memory/test_caller_retirement.py'}
for label,folder in [('initial',first_matrix),('discovery',middle_matrix),('qualified',matrix)]:
    for path in folder.rglob('*'):
        if path.is_file():packed('matrix/'+label+'/'+path.relative_to(folder).as_posix(),path.read_bytes())
for label,qualification in [('initial',failed),('discovery',discovery),('qualified',run)]:
    build=root/qualification['cohorts'][0]['builds'][0]
    summary=readback(build)
    if label!='initial':
        actual=json.loads((build/'process-mm-users/caller-retirement-readback.json').read_bytes())
        assert json.loads(json.dumps(summary))==actual
    opt=json.loads((build/'root-target-verify.command.json').read_bytes())['argv'][0]
    modules={}
    for role in ['source','runtime','owner','controller','target','dispatch','extent']:
        command=['rtk','proxy',opt,'-passes=verify','-disable-output',str(build/(role+'.ll'))]
        result=subprocess.run(command,capture_output=True);assert result.returncode==0,result.stderr
        modules[role]=dict(passed=True,input=fact((build/(role+'.ll')).read_bytes()),argv=command)
    files={}
    for path in build.rglob('*'):
        if path.is_file():
            name=path.relative_to(build).as_posix();raw=path.read_bytes();files[name]=fact(raw)
            packed('native/'+label+'/'+name,raw)
    meanings=dict(initial='Corrected saved-data replay; initial recorded original reader remains failed',
        discovery='Native and corrected reader passed; original full model discovery remains failed',
        qualified='Fresh native, corrected-reader and all six surrounding checks passed')
    report['cohorts'][label]=dict(summary=summary,llvm=modules,files=files,reader_scope=meanings[label])
reference=root/'linux-kernel/tools/process-memory/results/stage-3-prelude-stat'
for name in ['manifest.json','report.json']:
    save('compiler-reference/'+name,(reference/name).read_bytes())
save('compiler-reference/review.json',(root/(str(reference.relative_to(root))+'-review.json')).read_bytes())
for name in ['compiler-units.stdout.log','compiler-units.stderr.log']:
    save('compiler-reference/'+name+'.gz',(reference/'matrix/validation'/(name+'.gz')).read_bytes())
for name in ['diagnose-caller-result.py','caller-retirement-result-diagnosis.json',
             'replay-repaired-caller-reader.py','caller-retirement-repaired-reader.json']:
    packed('diagnostics/'+name,(cache/name).read_bytes())
packed('collection/collector.py',Path(__file__).read_bytes())
save('report.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print('collected',len(manifest),'files',flush=True)
replay.mkdir(exist_ok=False)
def restore(target,name,expected):
    assert target.resolve().is_relative_to(replay)
    raw=gzip.decompress((archive/(name+'.gz')).read_bytes());assert fact(raw)==expected
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
for label in ['qualified','initial','discovery']:
    task=replay/label
    for name,expected in report['sources'].items():restore(task/name,'inputs/'+name,expected)
    if label!='qualified':
        for name,expected in report['historical_sources'][label].items():
            restore(task/name,'historical-inputs/'+label+'/'+name,expected)
    build=task/'linux-kernel/.cache/x86_64/caller-retirement-replay'
    for name,expected in report['cohorts'][label]['files'].items():restore(build/name,'native/'+label+'/'+name,expected)
    command=['rtk','proxy','python3','-B','linux-kernel/tools/process-memory/readback_caller_retirement.py',str(build)]
    result=subprocess.run(command,cwd=task,capture_output=True,text=True)
    (replay/(label+'.stdout.log')).write_text(result.stdout);(replay/(label+'.stderr.log')).write_text(result.stderr)
    if label!='initial':
        assert result.returncode==0,result.stderr[-4000:]
        assert json.loads(result.stdout)==json.loads(json.dumps(report['cohorts'][label]['summary']))
        tests=subprocess.run(['rtk','proxy','python3','-B','-m','unittest','discover','-s',
            'linux-kernel/tools/process-memory','-p','test_*.py'],cwd=task,capture_output=True,text=True)
        (replay/(label+'-models.stdout.log')).write_text(tests.stdout)
        (replay/(label+'-models.stderr.log')).write_text(tests.stderr)
        if label=='qualified':
            assert tests.returncode==0 and 'Ran 80 tests in ' in tests.stderr and tests.stderr.rstrip().endswith('OK'),tests.stderr
            print('qualified frozen reader and 80 models passed',flush=True)
        else:
            assert tests.returncode!=0 and "ImportError: 'test_model' module incorrectly imported" in tests.stderr
            print('intermediate test-discovery failure reproduced',flush=True)
    else:
        assert result.returncode!=0 and 'ValueError: caller admission/result carry' in result.stderr
        print('original failed reader reproduced its retained refusal',flush=True)
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
record=dict(passed=True,archive_manifest=fact((archive/'manifest.json').read_bytes()),
    qualified_reader_passed=True,original_reader_failure_reproduced=True,
    discovery_failure_reproduced=True,models=80,
    elapsed_seconds=time.monotonic()-began,resources=resources,
    scope='Closed source/native archive and frozen saved-data/source/model replay: qualified reader/full80models pass, original reader refusal and intermediate discovery failure reproduced. No VM or compiler rebuild in collection/replay.')
(replay/'replayed.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,entries=len(manifest),sources=len(report['sources']),
    elapsed_seconds=record['elapsed_seconds'])),flush=True)
