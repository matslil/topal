"""Preserve an interrupted driver and finish only its five unrun checks.

The original two native/readback pairs, workspace check and full compiler suite
completed. This recovery does not reconstruct missing original cgroup counters.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
matrix=cache/'process-mm-prelude-stat-matrix';recovery=matrix/'recovery'
original=(matrix/'progress.json').read_bytes();report=json.loads(original)
assert not (matrix/'run.json').exists()
assert set(report['validation'])=={'workspace-check','compiler-units'}
assert all(row['status']=='complete' and row['exit_code']==0 for row in report['validation'].values())
assert len(report['cohorts'])==2
assert all(row['exit_code']==row['readback']['exit_code']==0 for row in report['cohorts'])
text=(matrix/'validation/compiler-units.stdout.log').read_text()
assert re.search(r'test result: ok\. 383 passed; 0 failed; 25 ignored; 0 measured; 0 filtered out',text)
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import watched,hashes,VALIDATIONS
paths=watched();assert set(paths)==set(report['source_hashes_before'])
assert hashes(paths)==report['source_hashes_before']
assert all(hashlib.sha256((cache/name).read_bytes()).hexdigest()==sha for name,sha in report['tools'].items())
recovery.mkdir(exist_ok=False);(recovery/'original-progress.json').write_bytes(original)
(recovery/'recovery.py').write_bytes(Path(__file__).read_bytes())
journal_command=['rtk','proxy','journalctl','--user','--user-unit=topal-bounded-2521033-70983b1f.scope',
    '--since','2026-11-13 08:45:00 UTC','--no-pager','--utc','-n','15']
journal=subprocess.run(journal_command,capture_output=True,text=True);assert journal.returncode==0
(recovery/'original-scope-journal.log').write_text(journal.stdout)
assert "detected unhandled Python exception in 'linux-kernel/.cache/x86_64/run-prelude-stat-stage.py'" in journal.stdout
assert '1.9G memory peak' in journal.stdout
(recovery/'journal-command.json').write_text(json.dumps(dict(argv=journal_command,exit_code=0),indent=2)+'\n')
report['recovery']=dict(original_scope='topal-bounded-2521033-70983b1f.scope',
    exact_notice="detected unhandled Python exception in 'linux-kernel/.cache/x86_64/run-prelude-stat-stage.py'",
    exception_cause='not established; no original traceback or driver exit code retained',
    completed_before_interruption=['two native/readback pairs','workspace-check','compiler-units:383passed25ignored,exit0'],
    original_cgroup_accounting=dict(complete=False,memory_peak_rounded='1.9G',memory_max=None,memory_events=None,
        no_swap_entry_assertion=True,
        scope='Rounded journal peak and frozen bounded/no-swap entry guard only. Exact original counters and limit are unavailable; no zero-event claim for the original batch.'),
    original_journal_sha256=hashlib.sha256(journal.stdout.encode()).hexdigest(),
    original_progress_sha256=hashlib.sha256(original).hexdigest(),
    scope='Preserve the interrupted driver; finish five unrun checks with unchanged original native/compiler sources. No repeat VM or full compiler execution.')
environment=dict(os.environ,TMPDIR=str(cache/'prelude-stat-validation-tmp'),RUST_TEST_THREADS='2')
start=time.monotonic();failure=0
for name,arguments in VALIDATIONS.items():
    if name in report['validation']:continue
    command=['rtk','proxy']+arguments;began=time.monotonic()
    out=matrix/'validation'/(name+'.stdout.log');err=matrix/'validation'/(name+'.stderr.log')
    assert not out.exists() and not err.exists()
    report['validation'][name]=dict(argv=command,status='running',executed_in='supplementary-recovery')
    (recovery/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,'started',flush=True)
    with out.open('w') as stdout,err.open('w') as stderr:
        result=subprocess.run(command,cwd=root,env=environment,stdout=stdout,stderr=stderr)
    report['validation'][name].update(status='complete',exit_code=result.returncode,elapsed_seconds=time.monotonic()-began)
    (recovery/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,result.returncode,flush=True);failure=result.returncode
    if failure:print(err.read_text()[-4000:],flush=True);break
after=hashes(paths);same_tools=all(hashlib.sha256((cache/name).read_bytes()).hexdigest()==sha for name,sha in report['tools'].items())
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
report.update(schema='topal-process-mm-prelude-stat-recovered-qualification-v1',
    passed=not failure and len(report['validation'])==7 and after==report['source_hashes_before'] and same_tools,
    exit_code=failure,source_hashes_after=after,source_changes_during_run=after!=report['source_hashes_before'],
    tools_unchanged=same_tools,elapsed_seconds=time.monotonic()-start,resources=resources,group=group,
    resources_scope='Five supplementary checks only; exact original native/full-compiler cgroup accounting unavailable',
    elapsed_scope='Five supplementary checks only; original compiler command elapsed_seconds is retained separately',
    scope='Two original successful native/readback pairs, original successful workspace/full383compiler command and five supplementary checks, with730unchanged original sources. Driver interruption and partial original resource accounting are explicit. No new native execution or full compiler rerun in recovery.')
assert resources['memory.swap.max']=='0' and all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
(matrix/'run.json').write_text(json.dumps(report,indent=2)+'\n')
assert (matrix/'progress.json').read_bytes()==original
print(json.dumps(dict(passed=report['passed'],validation=len(report['validation']),
    sources=len(after),elapsed_seconds=report['elapsed_seconds'],resources=resources,
    original_accounting_complete=False)),flush=True)
raise SystemExit(failure or int(not report['passed']))
