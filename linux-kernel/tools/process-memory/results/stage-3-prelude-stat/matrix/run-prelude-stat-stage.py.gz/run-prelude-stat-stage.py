"""Source-frozen two-VM and full compiler qualification under run_bounded."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import watched, hashes, VALIDATIONS
output=cache/'process-mm-prelude-stat-matrix';output.mkdir(exist_ok=False)
temporary=cache/'prelude-stat-validation-tmp';temporary.mkdir(exist_ok=True)
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
paths=watched();assert 'topal-as-dsl.md' not in paths
before=hashes(paths);start=time.monotonic()
tools={name:(cache/name).read_bytes() for name in ['run-prelude-stat-stage.py','collect-prelude-stat-stage.py']}
for name,raw in tools.items():(output/name).write_bytes(raw)
environment=dict(os.environ,TMPDIR=str(temporary),RUST_TEST_THREADS='2')
environment.pop('TOPAL_TEST_PROCESS_MM_PUBLICATION',None)
environment.pop('TOPAL_TEST_PROCESS_MM_PREPARATION',None)
report=dict(passed=False,source_hashes_before=before,cohorts=[],validation={},
    environment={k:environment[k] for k in ['TMPDIR','RUST_TEST_THREADS']},
    tools={k:hashlib.sha256(v).hexdigest() for k,v in tools.items()},
    scope='Two fresh targeted VMs: selected missing-stat prefix and full ordinary MM regression; separate fresh full compiler/workspace/models/ABI/format/ceiling validation. Prefix is not full application/VM completion.')
def progress():(output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
progress();failure=0
for label,test in [('prelude-stat','process_mm_prelude_missing_stat_executes_owned_read_and_retires_caller'),
                   ('ordinary','process_mm_fork_handoff_and_exit_preserve_independent_heap_owners')]:
    folder=output/label;folder.mkdir();began=time.monotonic()
    command=['rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1',
        'systems_frame_target::root_tests::'+test,'--','--ignored','--exact','--test-threads=1','--nocapture']
    with (folder/'native.log').open('w') as stream:
        result=subprocess.run(command,cwd=root,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    text=(folder/'native.log').read_text();builds=[Path(p.strip()).resolve() for p in re.findall(r'actual frame source root: ([^\n]+)',text)]
    row=dict(label=label,argv=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-began,
        builds=[p.relative_to(root).as_posix() for p in builds]);report['cohorts'].append(row);progress()
    print(label,'native',result.returncode,flush=True);failure=result.returncode
    if failure:print(text[-8000:],flush=True);break
    assert len(builds)==1 and builds[0].is_relative_to(cache)
    build=builds[0]
    assert hashlib.sha256((build/'kernel.elf').read_bytes()).hexdigest()=='b8212e5e9aca715d8db0d863cbc9655ed989c3884b938b57055c3e22e04d0a7c'
    if label=='prelude-stat':
        command=['rtk','proxy','python3','linux-kernel/tools/process-memory/readback_prelude_stat.py',str(build)]
    else:
        command=['rtk','proxy','python3','linux-kernel/tools/process-memory/readback_process.py',
            str(build/'process-mm-users/observations.json'),str(build/'process-mm-users/readback.json')]
    result=subprocess.run(command,cwd=root,env=environment,capture_output=True,text=True)
    (folder/'readback.stdout.log').write_text(result.stdout);(folder/'readback.stderr.log').write_text(result.stderr)
    row['readback']=dict(argv=command,exit_code=result.returncode);progress()
    print(label,'readback',result.returncode,flush=True);failure=result.returncode
    if failure:print(result.stderr[-8000:],flush=True);break
if not failure:
    folder=output/'validation';folder.mkdir()
    for name,arguments in VALIDATIONS.items():
        command=['rtk','proxy']+arguments;began=time.monotonic()
        report['validation'][name]=dict(argv=command,status='running');progress()
        print(name,'started',flush=True)
        with (folder/(name+'.stdout.log')).open('w') as out,(folder/(name+'.stderr.log')).open('w') as err:
            result=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err)
        report['validation'][name].update(status='complete',exit_code=result.returncode,elapsed_seconds=time.monotonic()-began);progress()
        print(name,result.returncode,flush=True);failure=result.returncode
        if failure:print((folder/(name+'.stderr.log')).read_text()[-8000:],flush=True);break
after=hashes(paths)
same_tools=all((cache/name).read_bytes()==raw for name,raw in tools.items())
report.update(passed=not failure and len(report['cohorts'])==2 and len(report['validation'])==7 and before==after and same_tools,
    exit_code=failure,source_hashes_after=after,source_changes_during_run=before!=after,tools_unchanged=same_tools,
    elapsed_seconds=time.monotonic()-start,resources={name:(directory/name).read_text().strip() for name in
        ['memory.max','memory.swap.max','memory.peak','memory.events']},group=group)
(output/'run.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['source_hashes_before','source_hashes_after','cohorts']}),flush=True)
raise SystemExit(failure or int(not report['passed']))
