"""Preserve complete targeted native builds and replay frozen saved readers."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
matrix=cache/'process-mm-prelude-stat-matrix'
archive=root/'linux-kernel/tools/process-memory/results/stage-3-prelude-stat'
replay=cache/'prelude-stat-frozen-replay'
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
began=time.monotonic()
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
run=json.loads((matrix/'run.json').read_bytes())
assert run['passed'] and run['exit_code']==0 and run['tools_unchanged']
assert run['source_hashes_before']==run['source_hashes_after']
assert len(run['cohorts'])==2 and len(run['validation'])==7
assert all(row['exit_code']==row['readback']['exit_code']==0 for row in run['cohorts'])
assert all(row['status']=='complete' and row['exit_code']==0 for row in run['validation'].values())
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from readback_prelude_stat import readback as prelude
from readback_process import readback as ordinary
archive.mkdir(exist_ok=False);manifest={}
def save(name,raw):
    path=archive/name;assert path.resolve().is_relative_to(archive)
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);manifest[name]=fact(raw)
def packed(name,raw):save(name+'.gz',gzip.compress(raw,mtime=0))
report=dict(passed=True,schema='topal-process-mm-prelude-stat-v1',sources={},cohorts={},
    scope='One fresh selected pre-import syscall prefix and one fresh complete ordinary MM VM. Full compiler validation is separately logged. Frozen replay executes saved readers, not VMs or compiler rebuilds; general caller/lifetime/public/fullLinux qualification remains open.')
for name,sha in run['source_hashes_before'].items():
    raw=(root/name).read_bytes();assert fact(raw)['sha256']==sha
    report['sources'][name]=fact(raw);packed('inputs/'+name,raw)
for path in matrix.rglob('*'):
    if path.is_file():packed('matrix/'+path.relative_to(matrix).as_posix(),path.read_bytes())
for row in run['cohorts']:
    label=row['label'];build=root/row['builds'][0]
    if label=='prelude-stat':
        summary=prelude(build);actual=json.loads((build/'process-mm-prelude-stat/readback.json').read_bytes())
    else:
        summary=ordinary(json.loads((build/'process-mm-users/observations.json').read_bytes()))
        actual=json.loads((build/'process-mm-users/readback.json').read_bytes())
        # The standalone reader adds the observation byte identity.
        actual.pop('observations')
    summary=json.loads(json.dumps(summary));assert summary==actual
    opt=json.loads((build/'root-target-verify.command.json').read_bytes())['argv'][0]
    modules={}
    for role in ['source','runtime','owner','controller','target','dispatch','extent']:
        command=['rtk','proxy',opt,'-passes=verify','-disable-output',str(build/(role+'.ll'))]
        result=subprocess.run(command,capture_output=True);assert result.returncode==0,result.stderr
        modules[role]=dict(passed=True,input=fact((build/(role+'.ll')).read_bytes()),argv=command)
    files={}
    for path in build.rglob('*'):
        if path.is_file():
            name=path.relative_to(build).as_posix();raw=path.read_bytes();files[name]=fact(raw);packed('native/'+label+'/'+name,raw)
    report['cohorts'][label]=dict(summary=summary,llvm=modules,files=files)
save('report.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print('collected',len(manifest),'files',flush=True)
# Restore source/build bytes beneath a fresh task root before invoking readers.
replay.mkdir(exist_ok=False)
def restore(target,name,expected):
    assert target.resolve().is_relative_to(replay)
    raw=gzip.decompress((archive/(name+'.gz')).read_bytes());assert fact(raw)==expected
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
for name,expected in report['sources'].items():restore(replay/name,'inputs/'+name,expected)
results={}
for label,case in report['cohorts'].items():
    build=replay/'linux-kernel/.cache/x86_64/prelude-stat-replay'/label
    for name,expected in case['files'].items():restore(build/name,'native/'+label+'/'+name,expected)
    if label=='prelude-stat':
        command=['rtk','proxy','python3','linux-kernel/tools/process-memory/readback_prelude_stat.py',str(build)]
    else:
        # Leave the restored original output unchanged: compare an in-memory
        # call to the frozen reader against its archived normalized summary.
        program='import json,sys; sys.path.insert(0,"linux-kernel/tools/process-memory"); from readback_process import readback; print(json.dumps(readback(json.load(open(sys.argv[1])))))'
        command=['rtk','proxy','python3','-c',program,str(build/'process-mm-users/observations.json')]
    result=subprocess.run(command,cwd=replay,capture_output=True,text=True)
    (replay/(label+'.stdout.log')).write_text(result.stdout);(replay/(label+'.stderr.log')).write_text(result.stderr)
    assert result.returncode==0,result.stderr[-4000:]
    results[label]=json.loads(result.stdout);assert results[label]==case['summary']
    print(label,'frozen reader passed',flush=True)
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
record=dict(passed=True,cohorts=results,elapsed_seconds=time.monotonic()-began,
    archive_manifest=fact((archive/'manifest.json').read_bytes()),resources=resources,
    scope='Complete selected source/native archives and frozen saved-data readers; no VM or compiler rebuild in this follow-up')
(replay/'replayed.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,archive_entries=len(manifest),sources=len(report['sources']),elapsed_seconds=record['elapsed_seconds'])),flush=True)
