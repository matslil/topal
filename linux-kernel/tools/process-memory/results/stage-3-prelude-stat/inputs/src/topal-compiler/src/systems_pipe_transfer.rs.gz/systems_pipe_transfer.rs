//! Checked circular byte transfers; wait publication occurs before any byte copy.
use super::super::R::_Bp as Bp;
use super::*;

fn resolve(e: &mut E<'_>, kind: i32) -> Result<(), CompileError> {
    e.gs(0x8b, Di, 312);
    e.0.call("fd-lookup");
    e.0.jump_if(0x82, "fd-ebadf");
    e.load(A, R14, 0);
    e.cmp(A, kind);
    e.0.jump_if(0x85, "fd-ebadf");
    e.0.call("pipe-object-lookup");
    e.mov(R13, R10);
    Ok(())
}
fn range(e: &mut E<'_>) {
    e.gs(0x8b, R8, 320);
    e.gs(0x8b, R9, 328);
    e.0.call("fd-native-range");
    e.0.jump_if(0x82, "pipe-efault");
}

fn transfer_count(e: &mut E<'_>) {
    // TOPAL-SYSTEMS-USER-EXTENT-001: the byte loops execute before testing
    // their remaining count. Re-establish the trusted nonempty ring quantum
    // after clock/description lookup and clipping, immediately before lending
    // application memory. Broken internal state is not an ordinary EFAULT.
    if !e.0.owned_user_extents {
        return;
    }
    e.cmp(R9, 0);
    e.0.jump_if(0x84, "fatal");
    e.cmp(R9, 4096);
    e.0.jump_if(0x87, "fatal");
}

pub(super) fn emit(code: &mut X86FunctionEncoder) -> Result<(), CompileError> {
    let mut e = E(code);
    e.0.bind("pipe-read")?;
    e.0.call("pipe-object-lookup");
    e.mov(R13, R10);
    range(&mut e);
    e.cmp(R9, 0);
    e.0.jump_if(0x84, "pipe-transfer-zero");
    e.load(A, R13, 40);
    e.cmp(A, 0);
    e.0.jump_if(0x85, "pipe-read-ready");
    e.load(A, R13, 24);
    e.cmp(A, 0);
    e.0.jump_if(0x84, "pipe-transfer-zero");
    e.load(A, R14, 16);
    e.arith(4, A, 0x800);
    e.cmp(A, 0);
    e.0.jump_if(0x85, "pipe-eagain");
    e.imm(R8, 0);
    e.imm(R9, 2);
    e.0.jump("pipe-block");
    e.0.bind("pipe-read-ready")?;
    e.0.call("realtime-observe");
    e.0.jump_if(0x82, "pipe-eio");
    e.mov(Bp, R15);
    resolve(&mut e, 5)?;
    e.gs(0x8b, R8, 320);
    e.gs(0x8b, R9, 328);
    e.load(A, R13, 40);
    e.rr(0x39, R9, A);
    e.0.jump_if(0x86, "pipe-read-count-ready");
    e.mov(R9, A);
    e.0.bind("pipe-read-count-ready")?;
    transfer_count(&mut e);
    e.0.call("runtime-writable-extent");
    e.0.jump_if(0x82, "pipe-efault");
    buffer(&mut e, R13);
    e.load(R15, R13, 32);
    e.mov(Di, R8);
    e.mov(C, R9);
    e.0.bind("pipe-read-byte")?;
    e.mov(Si, R11);
    e.rr(0x01, Si, R15);
    e.0.bytes(&[0x8a, 0x06, 0x88, 0x07, 0x38, 0x07]);
    e.0.jump_if(0x85, "fatal");
    e.0.bytes(&[0xc6, 0x06, 0, 0x80, 0x3e, 0]);
    e.0.jump_if(0x85, "fatal");
    e.add(Di, 1);
    e.add(R15, 1);
    e.arith(4, R15, 4095);
    e.add(C, -1);
    e.cmp(C, 0);
    e.0.jump_if(0x85, "pipe-read-byte");
    e.store(R13, 32, R15);
    e.load(A, R13, 40);
    e.rr(0x29, A, R9);
    e.store(R13, 40, A);
    e.store(R13, 72, Bp);
    e.0.call("pipe-notify");
    e.mov(A, R9);
    emit_static_process_sysret(e.0);

    e.0.bind("pipe-write")?;
    e.0.call("pipe-object-lookup");
    e.mov(R13, R10);
    range(&mut e);
    e.cmp(R9, 0);
    e.0.jump_if(0x84, "pipe-transfer-zero");
    e.load(A, R13, 16);
    e.cmp(A, 0);
    e.0.jump_if(0x84, "pipe-write-no-reader");
    e.imm(A, 4096);
    e.load(R11, R13, 40);
    e.rr(0x29, A, R11);
    e.cmp(R9, 4096);
    e.0.jump_if(0x87, "pipe-write-large");
    e.rr(0x39, A, R9);
    e.0.jump_if(0x83, "pipe-write-ready");
    e.0.jump("pipe-write-wait");
    e.0.bind("pipe-write-large")?;
    e.cmp(A, 0);
    e.0.jump_if(0x85, "pipe-write-ready");
    e.0.bind("pipe-write-wait")?;
    e.load(A, R14, 16);
    e.arith(4, A, 0x800);
    e.cmp(A, 0);
    e.0.jump_if(0x85, "pipe-eagain");
    e.imm(R8, 1);
    e.imm(R9, 3);
    e.0.jump("pipe-block");
    e.0.bind("pipe-write-no-reader")?;
    e.load(A, R12, 1792 + 12 * 32);
    e.cmp(A, 1);
    e.0.jump_if(0x85, "pipe-enosys");
    e.0.jump("pipe-epipe");
    e.0.bind("pipe-write-ready")?;
    e.0.call("realtime-observe");
    e.0.jump_if(0x82, "pipe-eio");
    e.mov(Bp, R15);
    resolve(&mut e, 6)?;
    e.gs(0x8b, R8, 320);
    e.gs(0x8b, R9, 328);
    e.imm(A, 4096);
    e.load(R11, R13, 40);
    e.rr(0x29, A, R11);
    e.rr(0x39, R9, A);
    e.0.jump_if(0x86, "pipe-write-count-ready");
    e.mov(R9, A);
    e.0.bind("pipe-write-count-ready")?;
    transfer_count(&mut e);
    e.0.call("runtime-readable-extent");
    e.0.jump_if(0x82, "pipe-efault");
    buffer(&mut e, R13);
    e.load(R15, R13, 32);
    e.load(A, R13, 40);
    e.rr(0x01, R15, A);
    e.arith(4, R15, 4095);
    e.mov(Si, R8);
    e.mov(C, R9);
    e.0.bind("pipe-write-byte")?;
    e.mov(Di, R11);
    e.rr(0x01, Di, R15);
    e.0.bytes(&[0x8a, 0x06, 0x88, 0x07, 0x38, 0x07]);
    e.0.jump_if(0x85, "fatal");
    e.add(Si, 1);
    e.add(R15, 1);
    e.arith(4, R15, 4095);
    e.add(C, -1);
    e.cmp(C, 0);
    e.0.jump_if(0x85, "pipe-write-byte");
    e.load(A, R13, 40);
    e.rr(0x01, A, R9);
    e.store(R13, 40, A);
    e.store(R13, 80, Bp);
    e.store(R13, 88, Bp);
    e.0.call("pipe-notify");
    e.mov(A, R9);
    emit_static_process_sysret(e.0);
    e.0.bind("pipe-transfer-zero")?;
    e.imm(A, 0);
    emit_static_process_sysret(e.0);
    Ok(())
}
