set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-ready-termination-2453355-1794499115558907749/kernel.elf"
target remote 127.0.0.1:43063
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-ready-termination-2453355-1794499115558907749/process-mm-users/observations.json'
component={'allocation_profile': None, 'base': 5701632, 'cancellation': None, 'command_source_sha256': 'cac5afad81808c0123175a2de8b1e799c70579f9a5ef81445bb3a66433f9e3ef', 'conservative_user_stack_bytes': 1264, 'entry': 5709568, 'exec_source_sha256': None, 'file_source_sha256': '757a45600b38e0746659781ba6e14aa5a90ec9d378cf364fd555299890ef92fa', 'geometry_profile': None, 'image_entry': 5709744, 'image_sha256': 'c81407eafab223badd49739ce613949a29294ca054513313d48fcd7c1624d5c9', 'linked_sha256': '70eb0502bb17481c21792a2316b30a00fa793273736c11e34d32e83ed1d2f441', 'metadata_source_sha256': None, 'mode': 'process-mm-relationship', 'pipe_source_sha256': None, 'poll_source_sha256': None, 'process_mm_allocation_source_sha256': None, 'process_mm_cancel_source_sha256': None, 'process_mm_exec_source_sha256': None, 'process_mm_geometry_source_sha256': None, 'process_mm_relationship_source_sha256': '2aeeec05f089d4805bbeea6cf094b98f3ca76def03d244c76098375237fd3796', 'process_mm_source_sha256': None, 'relationship_profile': {'early': True, 'identity_storage_bytes': 4096, 'process_storage_bytes': 311296, 'status': 709, 'syscall': 60, 'zombie': False}, 'scope': 'source-built ordinary syscall component in a freshly generated first-party ABI witness; not an arbitrary-program loader or production qualification', 'serial_source_sha256': None, 'shell_source_sha256': '574462c620fb4e2db01bc4140e98377f52d4add8eddc3e4a9fa0428d2a3d8db4', 'signal_source_sha256': None, 'source_sha256': '49758cc99552709eb1fe062b26dbcb189ae93ead0755139a56f0dd532017ca6c', 'stack_frame_costs': {'command-cases': 104, 'file-cases': 400, 'process-mm-relationship-cases': 96, 'shell-cases': 168, 'source-cases': 496, 'startup-cases': 168}, 'startup': 5702592, 'startup_call': 5709680, 'startup_source_sha256': '2c5171f997c27d084883f6dce969747c191ab41649864e5c1d73f2367bb574aa', 'stat_source_sha256': None, 'storage_source_sha256': None, 'syscall': 5709632, 'syscall4': 5709648, 'text_bytes': 8338}
kernel_spans=[[2097152, 2097720], [8388608, 44974080], [44974080, 44999368], [45003472, 46281165], [46285264, 46288896], [46289376, 46289384]]
native_halt=45803143
model={}
exec('"""TOPAL-SYSTEMS-PROCESS-MM-001 saved process/MM boundary checks.\n\nRecords describe observations; they cannot construct native ownership or prove\ncontinuous exclusion, every invalidation instruction or public qualification.\n"""\nPAGE = 4096\nSTART = 0x5F7000\n\n\ndef require(ok, reason):\n    if not ok:\n        raise ValueError(reason)\n\n\ndef owner(row, token, allocator, data=True):\n    require(row[\'token\'] == token, \'token binding\')\n    if token == [0, 0, 0]:\n        require(row[\'record\'] == row[\'cells\'] == [] and row[\'bytes\'] == \'\', \'empty allocation\')\n        return None\n    issuer, identity, index = token\n    require(issuer == allocator[1] == 1 and 0 < identity < allocator[2] and 0 <= index < allocator[3], \'live issuance\')\n    r, cells = row[\'record\'], row[\'cells\']\n    require(len(r) == 8 and r[:2] == token[:2] and r[7] == 1 and r[5] > 0, \'live record\')\n    count = r[3]\n    require(0 < count <= allocator[3] and r[4] > 0 and r[4] & (r[4] - 1) == 0\n            and 0 <= r[2] < r[2] + count <= allocator[3], \'allocation geometry\')\n    require(len(cells) == count * 3 and cells[0::3] == [identity] * count and cells[1::3] == [r[5]] * count, \'owned cells\')\n    first = cells[2]\n    require(first % r[4] == 0, \'allocation alignment\')\n    require(cells[2::3] == list(range(first, first + count)) and 0 <= first < first + count <= 1 << 18, \'physical frames\')\n    raw = bytes.fromhex(row[\'bytes\'])\n    require(len(raw) == (count * PAGE if data else 0), \'whole allocation bytes\')\n    return dict(token=token, span=[first * PAGE, (first + count) * PAGE], count=count,\n                pins=r[6], data=raw, record=r, cells=cells)\n\n\ndef bank(value, state, token, allocator):\n    allocated = owner(value, token, allocator)\n    require(len(state) in [4, 7], \'state width\')\n    if state == [0] * len(state):\n        require(allocated is None, \'owner without state\')\n        return None\n    require(state[0] == 1 and START <= state[1] <= START + 519 * PAGE, \'MM state\')\n    require((state[1] - START + PAGE - 1) // PAGE == state[2] and 0 <= state[2] <= 519, \'byte break\')\n    if not state[2]:\n        require(state[3] == 0 and allocated is None, \'zero-page heap\')\n    else:\n        require(allocated is not None and allocated[\'count\'] == state[2]\n                and allocated[\'span\'][0] == state[3] and allocated[\'pins\'] == 1\n                and allocated[\'record\'][4] == 1, \'heap backing/pin\')\n    return allocated\n\n\ndef mappings(value, count, base):\n    ctx, tables = value[\'context\'], value[\'tables\']\n    root, low = ctx[\'root\'], ctx[\'low\']\n    require(set(tables) == {str(a) for a in [root, root + PAGE, root + 2 * PAGE, root + 3 * PAGE, root + 4 * PAGE, low]}, \'table set\')\n    require(all(len(words) == 512 for words in tables.values()), \'complete tables\')\n    for table, index, target in [(root, 0, root + PAGE), (root + PAGE, 0, root + 2 * PAGE),\n                                 (root + 2 * PAGE, 2, low), (root + 2 * PAGE, 3, root + 4 * PAGE)]:\n        require(tables[str(table)][index] & ~0x60 == target | 7, \'hierarchy\')\n    for i in range(519):\n        table, index = (low, 503 + i) if i < 9 else (root + 4 * PAGE, i - 9)\n        expected = ((base + i * PAGE) | (1 << 63) | 7) if i < count else 0\n        require(tables[str(table)][index] & ~0x60 == expected, \'selected heap translations\')\n\n\ndef snapshot(value, stable=True):\n    allocator = value[\'allocator\']\n    require(len(allocator) == 16 and allocator[:2] == [1, 1] and 0 < allocator[3] <= 262144, \'allocator\')\n    require(value[\'details\'] == [0] * 4, \'resolve scratch\')\n    active = bank(value[\'active\'], value[\'state\'], value[\'tokens\'][:3], allocator)\n    inactive = bank(value[\'inactive\'], value[\'inactive_state\'], value[\'inactive\'][\'token\'], allocator)\n    prepared = bank(value[\'prepared\'], value[\'prepared_state\'], value[\'prepared\'][\'token\'], allocator)\n    candidate = owner(value[\'candidate\'], value[\'tokens\'][3:], allocator)\n    ids = value[\'ids\']\n    require(len(ids) == 7, \'MM identities\')\n    if ids[0] == 0:\n        require(ids == [0] * 7 and inactive is None and prepared is None, \'unbound identities\')\n    else:\n        require(0 < ids[0] <= 2147483647 and 0 < ids[1] < ids[6], \'active MM identity\')\n        if ids[3]:\n            require(0 < ids[3] <= 2147483647 and ids[3] != ids[0] and 1 in [ids[0], ids[3]], \'pair PIDs\')\n            require(0 < ids[4] < ids[6] and ids[4] != ids[1] and value[\'inactive_state\'][0] == 1, \'inactive MM identity\')\n        else:\n            require(ids[3:6] == [0] * 3 and value[\'inactive_state\'] == [0] * 4, \'empty inactive owner\')\n    owned = [o for o in [active, inactive, prepared, candidate] if o is not None]\n    for row in value[\'root_owners\']:\n        owned.append(owner(row, row[\'token\'], allocator, False))\n    require(any(o[\'span\'][0] == value[\'context\'][\'root\'] and o[\'count\'] == 5 and o[\'pins\'] == 1\n                for o in owned if o is not None), \'owned hierarchy\')\n    require(any(o[\'span\'][0] == value[\'context\'][\'low\'] and o[\'count\'] == 1 and o[\'pins\'] == 1\n                for o in owned if o is not None), \'owned low table\')\n    spans = list(value[\'kernel_spans\'])\n    identities = []\n    for allocation in owned:\n        a, b = allocation[\'span\']\n        require(all(b <= x or y <= a for x, y in spans), \'backing overlap\')\n        require(allocation[\'token\'][1] not in identities, \'aliased handle\')\n        identities.append(allocation[\'token\'][1])\n        spans.append([a, b])\n    if stable:\n        require(candidate is None and value[\'transition\'] == [0] * 3, \'incomplete transfer\')\n        mappings(value, value[\'state\'][2], value[\'state\'][3])\n    return dict(active=active, inactive=inactive, prepared=prepared, candidate=candidate)\n\n\ndef same_bank(a, b, name):\n    require(a[name] == b[name] and a[name + \'_state\'] == b[name + \'_state\'], \'changed retained \' + name)\n\n\ndef firmware_frames(evidence):\n    """All complete RAM pages, excluding every reservation/non-RAM overlap."""\n    ram=[];forbidden=list(evidence[\'reservations\'])\n    for base,length,kind in evidence[\'e820\']:\n        require(0<=base<base+length<=1<<64 and length>0 and kind>0, \'firmware interval\')\n        if kind==1:\n            require(base+length<=1<<30, \'firmware supported RAM domain\')\n            ram.append((base,base+length))\n        else:forbidden.append((base,base+length))\n    require(len(evidence[\'reservations\'])==2 and all(0<=a<b<=1<<30 for a,b in evidence[\'reservations\']), \'firmware reservations\')\n    frames=set()\n    for a,b in ram:\n        for frame in range((a+PAGE-1)//PAGE,b//PAGE):\n            if all((frame+1)*PAGE<=x or y<=frame*PAGE for x,y in forbidden):frames.add(frame)\n    return sorted(frames)\n\n\ndef physical_catalog(value):\n    """Independent whole-catalog/registry readback for the small-RAM cohort."""\n    allocator=value[\'allocator\'];n=allocator[3]\n    require(\'catalog\' in value and \'registry\' in value, \'missing complete physical catalog\')\n    cells,registry=value[\'catalog\'],value[\'registry\']\n    require(len(cells)==3*n and len(registry)==8*n, \'complete physical catalog/registry\')\n    physical=cells[2::3]\n    require(physical==sorted(set(physical)) and all(0<=p<1<<18 for p in physical), \'catalog physical identity\')\n    require(all(p>0 for p in cells[1::3]), \'catalog provenance\')\n    records={};free_records=0\n    for index in range(n):\n        r=registry[index*8:(index+1)*8]\n        if r==[0]*8:\n            free_records+=1;continue\n        require(r[0]==allocator[1]==1 and 0<r[1]<allocator[2] and r[7]==1, \'catalog live record\')\n        require(r[1] not in records and 0<=r[2]<r[2]+r[3]<=n and r[3]>0\n                and r[4]>0 and r[4]&(r[4]-1)==0 and r[5]>0, \'catalog record geometry\')\n        part=cells[r[2]*3:(r[2]+r[3])*3]\n        require(part[0::3]==[r[1]]*r[3] and part[1::3]==[r[5]]*r[3], \'catalog owned span\')\n        require(part[2]%r[4]==0 and part[2::3]==list(range(part[2],part[2]+r[3])), \'catalog contiguous record\')\n        records[r[1]]=(index,r)\n    for index in range(n):\n        identity=cells[index*3]\n        if identity:\n            require(identity in records, \'catalog cell lacks record\')\n            r=records[identity][1]\n            require(r[2]<=index<r[2]+r[3], \'catalog cell outside record\')\n    for owner in [value[k] for k in [\'active\',\'inactive\',\'prepared\',\'candidate\']]+value[\'root_owners\']:\n        if owner[\'token\']!=[0]*3:\n            _,identity,index=owner[\'token\'];r=owner[\'record\']\n            require(records.get(identity)==(index,r) and owner[\'cells\']==cells[r[2]*3:(r[2]+r[3])*3], \'catalog owner binding\')\n    free=largest=run=0;previous=None\n    for i in range(n):\n        identity,provenance,frame=cells[i*3:i*3+3]\n        if identity==0:\n            free+=1\n            run=run+1 if previous is not None and previous==(provenance,frame-1) else 1\n            largest=max(largest,run);previous=(provenance,frame)\n        else:\n            run=0;previous=None\n    return dict(frames=n,free=free,largest_run=largest,free_records=free_records)\n\n\ndef preparation_refusal(row):\n    before,after=row[\'before\'],row[\'after\']\n    require(row[\'operation\']==9 and row[\'result\']==0 and row[\'request\']==0, \'physical refusal result\')\n    require(before[\'ids\'][0]==before[\'context\'][\'pid\']==1 and before[\'ids\'][3:6]==[0]*3\n            and before[\'context\'][\'relationship\']==0, \'physical refusal source\')\n    require(before[\'state\'][2]>0, \'physical refusal nonempty request\')\n    for value in [before,after]:\n        require(value[\'prepared_state\']==[0]*7 and value[\'prepared_owner\']==[0]*3\n                and value[\'prepared\'][\'token\']==[0]*3, \'refusal retained preparation\')\n    for key in [\'allocator\',\'ids\',\'state\',\'active\',\'inactive\',\'inactive_state\',\'catalog\',\'registry\',\'tables\',\'identity_store\']:\n        require(before[key]==after[key], \'refusal changed \'+key)\n    catalog=physical_catalog(before);physical_catalog(after)\n    require(catalog[\'free_records\']>0 and before[\'allocator\'][2]<(1<<64)-1, \'refusal is not registry/identity exhaustion\')\n    require(catalog[\'largest_run\']<before[\'state\'][2], \'physical refusal has an eligible run\')\n    return catalog\n\n\ndef resize_refusal(row):\n    before,after=row[\'before\'],row[\'after\'];request=row[\'request\']\n    require(START<request<=START+519*PAGE and row[\'result\']==before[\'state\'][1], \'raw resize refusal\')\n    count=(request-START+PAGE-1)//PAGE\n    require(count!=before[\'state\'][2], \'resize refusal geometry\')\n    for key in [\'allocator\',\'ids\',\'state\',\'active\',\'inactive\',\'inactive_state\',\'catalog\',\'registry\',\'tables\',\'identity_store\']:\n        require(before[key]==after[key], \'resize refusal changed \'+key)\n    catalog=physical_catalog(before);physical_catalog(after)\n    require(catalog[\'free_records\']>0 and before[\'allocator\'][2]<(1<<64)-1, \'resize refusal metadata exhaustion\')\n    require(catalog[\'largest_run\']<count, \'resize refusal has eligible run\')\n    return catalog\n\n\ndef event(row):\n    before, after = row[\'before\'], row[\'after\']\n    first, last = snapshot(before), snapshot(after)\n    op, request = row[\'operation\'], row[\'request\']\n    for value in [before, after]:\n        require(value[\'cs\'] & 3 == 0 and value[\'flags\'] & 0x600 == 0, \'kernel critical state\')\n        require(value[\'cr0\'] & 0x80010001 == 0x80010001 and value[\'cr4\'] & 0x20, \'paging/write protection\')\n        require(value[\'cr4\'] & ((1 << 7) | (1 << 12) | (1 << 17)) == 0, \'selected paging mode\')\n        if op == 6:\n            require(value[\'context\'][\'state\'] == 2 and value[\'cr3\'] == value[\'context\'][\'bootstrap\'], \'detached cleanup root\')\n        else:\n            require(value[\'context\'][\'state\'] == 1 and value[\'cr3\'] == value[\'context\'][\'root\']\n                    and value[\'gs_base\'] == value[\'context\'][\'self\'] == value[\'context\'][\'address\'], \'actual live root/context\')\n    require(before[\'epoch\'] == after[\'epoch\'] and before[\'epoch\'][0] > 0, \'entry changed\')\n    numbers = {5: [12], 6: [60, 231], 7: [59], 9: [56, 57], 10: [56, 57],\n               11: [0, 1, 19, 20, 24, 61], 12: [60, 231], 13: [60, 231]}\n    require(op in numbers and before[\'epoch\'][1] in numbers[op], \'syscall identity\')\n    require(before[\'context\'][\'root\'] == after[\'context\'][\'root\'] and before[\'cr3\'] == after[\'cr3\'], \'root changed\')\n    require(before[\'tokens\'][3:] == after[\'tokens\'][3:] == [0] * 3, \'resize candidate retained\')\n    require(before[\'root_owners\'] == after[\'root_owners\'], \'root owners changed\')\n    if op == 9:\n        require(row[\'result\'] in [0,1] and request == 0 and before[\'ids\'][0] == 1, \'creation preparation\')\n        require(before[\'state\'] == after[\'state\'] and before[\'active\'] == after[\'active\'] and before[\'ids\'] == after[\'ids\'], \'changed source during preparation\')\n        if row[\'result\']==0:\n            preparation_refusal(row)\n        else:\n            require(after[\'prepared_state\'][:3] == before[\'state\'][:3], \'prepared byte geometry\')\n            require(after[\'prepared_state\'][4:] == [before[\'context\'][\'root\'], before[\'context\'][\'address\'], before[\'epoch\'][0]], \'prepared entry receipt\')\n            require(after[\'prepared_owner\'] == before[\'ids\'][:3], \'prepared source owner\')\n            if first[\'active\']:\n                require(last[\'prepared\'][\'data\'] == first[\'active\'][\'data\'], \'incomplete fork copy\')\n            require(after[\'allocator\'][2] == before[\'allocator\'][2] + int(before[\'state\'][2] > 0), \'preparation issuance\')\n    elif op == 10:\n        require(row[\'result\'] == 1 and request >= 2 and before[\'prepared_owner\'] == before[\'ids\'][:3], \'creation commit\')\n        require(after[\'active\'] == before[\'prepared\'] and after[\'state\'] == before[\'prepared_state\'][:4], \'child adoption\')\n        require(after[\'inactive\'] == before[\'active\'] and after[\'inactive_state\'] == before[\'state\'], \'parent retention\')\n        require(after[\'ids\'] == [request, before[\'ids\'][6], before[\'ids\'][2]] + before[\'ids\'][:3] + [before[\'ids\'][6] + 1], \'child MM identity\')\n    elif op == 11:\n        require(row[\'result\'] == 1 and request == 0, \'handoff result\')\n        require(after[\'active\'] == before[\'inactive\'] and after[\'state\'] == before[\'inactive_state\'], \'target handoff\')\n        require(after[\'inactive\'] == before[\'active\'] and after[\'inactive_state\'] == before[\'state\'], \'source handoff\')\n        require(after[\'ids\'] == before[\'ids\'][3:6] + before[\'ids\'][:3] + before[\'ids\'][6:], \'handoff identities\')\n    elif op == 12:\n        require(row[\'result\'] == 1 and before[\'ids\'][0] >= 2 and before[\'ids\'][3] == 1, \'child exit\')\n        require(after[\'active\'] == before[\'inactive\'] and after[\'state\'] == before[\'inactive_state\'], \'parent restoration\')\n        require(after[\'ids\'] == before[\'ids\'][3:6] + [0] * 3 + before[\'ids\'][6:], \'retired child MM identity\')\n    elif op == 13:\n        require(row[\'result\'] == 1 and before[\'ids\'][0] == 1, \'outer cancellation\')\n        require(after[\'active\'] == before[\'active\'] and after[\'state\'] == before[\'state\'], \'active cancellation effect\')\n        require(after[\'ids\'] == before[\'ids\'][:3] + [0] * 3 + before[\'ids\'][6:], \'inactive cancellation identity\')\n    elif op == 5:\n        same_bank(before, after, \'inactive\')\n        count = before[\'state\'][2]\n        wanted = (request - START + PAGE - 1) // PAGE if START <= request <= START + 519 * PAGE else count\n        if request == 0 or wanted == count:\n            require(after[\'allocator\'][2] == before[\'allocator\'][2] and after[\'active\'] == before[\'active\'], \'query/within-page allocation\')\n        elif START<request<=START+519*PAGE and row[\'result\']==before[\'state\'][1]:\n            resize_refusal(row)\n    elif op == 7:\n        same_bank(before, after, \'inactive\')\n        require(after[\'state\'] == [0] * 4 and after[\'tokens\'] == [0] * 6, \'exec heap retirement\')\n        require(after[\'ids\'] == [before[\'ids\'][0], before[\'ids\'][6], before[\'ids\'][2] + 1] + before[\'ids\'][3:6] + [before[\'ids\'][6] + 1], \'exec MM generation\')\n    elif op == 6:\n        require(after[\'state\'] == [0] * 4 and after[\'tokens\'] == [0] * 6 and after[\'ids\'] == [0] * 7, \'outer retirement\')\n    else:\n        require(False, \'unknown MM operation\')\n    if op != 9:\n        require(after[\'prepared_state\'] == [0] * 7 and after[\'prepared_owner\'] == [0] * 3 and after[\'prepared\'][\'token\'] == [0] * 3, \'prepared owner retained\')\n    retained = [after[name][\'token\'] for name in [\'active\', \'inactive\', \'prepared\', \'candidate\']]\n    expected = {tuple(before[name][\'token\']): before[name] for name in\n                [\'active\', \'inactive\', \'prepared\', \'candidate\']\n                if before[name][\'token\'] != [0] * 3 and before[name][\'token\'] not in retained}\n    actual = [tuple(retired[\'token\']) for retired in row[\'retired\']]\n    require(len(actual) == len(set(actual)) and set(actual) == set(expected), \'complete retirement set\')\n    for retired in row[\'retired\']:\n        original = expected[tuple(retired[\'token\'])]\n        count = original[\'record\'][3]\n        require(retired[\'count\'] == count and len(bytes.fromhex(retired[\'bytes\'])) == count * PAGE\n                and len(retired[\'cells\']) == count * 3, \'complete retirement geometry\')\n        require(retired[\'record\'] == [0] * 8 and not any(bytes.fromhex(retired[\'bytes\'])), \'retired backing not consumed/zero\')\n        require(retired[\'cells\'][0::3] == [0] * retired[\'count\'], \'retired cells still owned\')\n        require(retired[\'cells\'][2::3] == original[\'cells\'][2::3], \'retired physical cell identity\')\n    return dict(passed=True, operation=op, active_pid=after[\'ids\'][0],\n                active_pages=after[\'state\'][2], inactive_pages=after[\'inactive_state\'][2])\n',model)

import gdb,hashlib,json,struct,traceback
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
def address(name):return int(gdb.parse_and_eval("(unsigned long long)&'"+name+"'"))
def memory(p,n):return bytes(gdb.selected_inferior().read_memory(p,n)) if n else b''
def words(p,n):return list(struct.unpack('<'+'Q'*n,memory(p,n*8)))
def word(p):return words(p,1)[0]
context=address('topal_bootstrap_storage')+512
observed=dict(passed=False,cases=[],events=[],child_exec_entries=[],replacement_entries=[],terminal=[],refusals=[],child_departures=[])
child_exec=component['mode']=='process-mm-exec'
cancel_config=component.get('cancellation')
allocation_config=component.get('allocation_profile')
geometry_config=component.get('geometry_profile')
relationship_config=component.get('relationship_profile')
observed['cancellation']=cancel_config
observed['allocation_profile']=allocation_config
observed['geometry_profile']=geometry_config
observed['relationship_profile']=relationship_config
pending=case=None
refusal_attempt=None
returns={}
callee=['rbx','rbp','r12','r13','r14','r15']

def allocation(pointer,data=True):
    token=words(pointer,3)
    if token==[0]*3:return dict(token=token,record=[],cells=[],bytes='')
    allocator=words(address('topal_x86_frame_context_v1'),16)
    assert token[0]==1 and 0<token[1]<allocator[2] and token[2]<allocator[3]
    record=words(allocator[6]+token[2]*64,8)
    assert record[:2]==token[:2] and record[7]==1 and 0<record[3]<=allocator[3]
    assert 0<=record[2]<record[2]+record[3]<=allocator[3]
    cells=words(allocator[4]+128+record[2]*24,record[3]*3)
    return dict(token=token,record=record,cells=cells,
        bytes=memory(cells[2]*4096,record[3]*4096).hex() if data else '')

def capture():
    root,low,table=word(context+24),word(context+112),word(context+928)
    tokens=address('topal_x86_frame_mm_tokens_v1')
    root_tokens=address('topal_x86_frame_root_tokens_v1')
    allocator=words(address('topal_x86_frame_context_v1'),16)
    result=dict(allocator=allocator,
        ids=words(address('topal_x86_process_mm_ids_v1'),7),
        state=words(address('topal_x86_frame_mm_state_v1'),4),tokens=words(tokens,6),
        inactive_state=words(address('topal_x86_process_mm_inactive_state_v1'),4),
        prepared_state=words(address('topal_x86_process_mm_prepared_state_v1'),7),
        prepared_owner=words(address('topal_x86_process_mm_prepared_owner_v1'),3),
        transition=words(address('topal_x86_process_mm_transition_v1'),3),
        active=allocation(tokens),candidate=allocation(tokens+24),
        inactive=allocation(address('topal_x86_process_mm_inactive_token_v1')),
        prepared=allocation(address('topal_x86_process_mm_prepared_token_v1')),
        root_owners=[allocation(root_tokens+i*24,False) for i in range(token_bytes//24) if words(root_tokens+i*24,3)!=[0]*3],
        details=words(address('topal_x86_frame_details_v1'),4),
        epoch=words(address('topal_x86_frame_mm_epoch_v1'),2),
        context=dict(address=context,state=word(context),root=root,low=low,heap=word(context+120),
            self=word(context+256),bootstrap=word(context+16),user_arg=word(context+312),phase=word(context+104),
            tls=word(context+128),registered_tid=word(context+152),robust=word(context+160),
            table=table,pid=word(table+56),child=word(table+0x2010),relationship=word(table+0x2000),
            policy_store=word(context+1000),
            saved_pid=word(table+0x3038),saved_heap=word(table+0x2178)),
        inactive_wait=[word(table+0x2060),word(table+0x2078)],
        tables={str(a):words(a,512) for a in [root,root+4096,root+8192,root+12288,root+16384,low]},
        kernel_spans=kernel_spans,cr3=reg('cr3'),cr0=reg('cr0'),cr4=reg('cr4'),cs=reg('cs'),flags=reg('eflags'),gs_base=reg('gs_base'),fs_base=reg('fs_base'),
        thread=list(gdb.selected_thread().ptid))
    if allocation_config is not None:
        assert 0<allocator[3]<=4096, 'observer catalog bound for the small-RAM cohort'
        result.update(catalog=words(allocator[4]+128,allocator[3]*3),
                      registry=words(allocator[6],allocator[3]*8))
    identity_config=allocation_config or geometry_config or relationship_config
    if identity_config is not None:
        policy=result['context']['policy_store']
        result['identity_store']=memory(policy,identity_config['identity_storage_bytes']).hex() if policy else ''
    return result

def save():
    observed['pending']=pending
    observed['active_case']=case
    observed['refusal_pending']=refusal_attempt
    with open(observation_path,'w') as f:json.dump(observed,f)

class Checked(gdb.Breakpoint):
    def stop(self):
        try:return self.observe()
        except Exception:
            traceback.print_exc()
            observed['failure']=traceback.format_exc()
            save()
            return True

class Gateway(Checked):
    def __init__(self,symbol,enter):
        self.enter=enter
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        global pending
        if self.enter:
            op=reg('rdi')
            if allocation_config is not None and op==0:
                assert 'firmware' not in observed and reg('cs')&3==0
                boot=reg('rsi');assert 0<boot<=0xfff000
                n=memory(boot+488,1)[0];assert 0<n<=128
                resource=int.from_bytes(memory(boot+536,4),'little')
                size=int.from_bytes(memory(boot+540,4),'little')
                observed['firmware']=dict(boot=boot,
                    e820=[words(boot+720+20*i,2)+[int.from_bytes(memory(boot+736+20*i,4),'little')] for i in range(n)],
                    raw_map=memory(boot+720,n*20).hex(),
                    reservations=[[0,address('topal_x86_kernel_reservation_end_v1')],[resource,resource+size]])
                save()
            if op not in [5,6,7,9,10,11,12,13]:return False
            assert pending is None
            pending=dict(operation=op,request=reg('rsi'),before=capture(),sp=reg('rsp'),
                callee={r:reg(r) for r in callee},retired=[])
            model['snapshot'](pending['before'])
        elif pending is not None:
            row=pending
            assert reg('rsp')==row['sp'] and {r:reg(r) for r in callee}==row['callee']
            assert all(reg(r)==0 for r in ['rcx','rdx','rsi','rdi','r8','r9','r10','r11'])
            after=capture()
            retained=[after[k]['token'] for k in ['active','inactive','prepared','candidate']]
            for bank in ['active','inactive','prepared','candidate']:
                old=row['before'][bank]
                if old['token']!=[0]*3 and old['token'] not in retained:
                    a=after['allocator'];r=old['record'];count=r[3]
                    row['retired'].append(dict(token=old['token'],count=count,
                        record=words(a[6]+old['token'][2]*64,8),cells=words(a[4]+128+r[2]*24,count*3),
                        bytes=memory(old['cells'][2]*4096,count*4096).hex()))
            row.update(after=after,result=reg('rax'))
            row['comparison']=model['event'](row)
            observed['events'].append(row)
            pending=None
            save()
        return False

class CaseReturned(Checked):
    def observe(self):
        global case
        self.enabled=False
        assert case is not None and pending is None and reg('cs')&3==3
        assert cancel_config is allocation_config is geometry_config is relationship_config is None, ('terminal case unexpectedly returned',reg('rax'))
        if reg('rax')!=0:
            value=capture()
            raise AssertionError(('source case failed',reg('rax'),value['context'],value['ids']))
        assert reg('rsp')==case['sp']+8 and {r:reg(r) for r in callee}==case['callee']
        after=capture();model['snapshot'](after)
        case['returned']=dict(result=reg('rax'),sp=reg('rsp'),callee={r:reg(r) for r in callee},cs=reg('cs'))
        assert after['ids'][:3]==case['before']['ids'][:3] and after['ids'][3:6]==[0]*3
        assert after['ids'][6]==case['before']['ids'][6]+(2 if child_exec else 1)
        assert after['state'][1:3]==case['before']['state'][1:3]
        assert hashlib.sha256(bytes.fromhex(after['active']['bytes'])).hexdigest()==case['prefix']
        case['after']=after
        observed['cases'].append(case);case=None
        print('PROCESS_MM_CASE_PASS',len(observed['cases']),flush=True)
        save()
        return False

class CaseEntered(Checked):
    def observe(self):
        global case
        assert case is None and pending is None and reg('cs')&3==3
        before=capture();model['snapshot'](before)
        if allocation_config is not None:
            firmware=observed['firmware']
            assert memory(firmware['boot']+720,len(firmware['e820'])*20).hex()==firmware['raw_map']
            assert before['catalog'][2::3]==model['firmware_frames'](firmware)
        assert before['ids'][0]==1 and before['state'][1:3]==[0x619000,34]
        case=dict(before=before,sp=reg('rsp'),callee={r:reg(r) for r in callee},
            prefix=hashlib.sha256(bytes.fromhex(before['active']['bytes'])).hexdigest())
        site=word(reg('rsp'))
        if site not in returns:returns[site]=CaseReturned('*'+hex(site),internal=True)
        returns[site].enabled=True
        return False

class ImageEntered(Checked):
    def observe(self):
        assert reg('cs')&3==3 and pending is None
        value=capture()
        if ((cancel_config is not None and cancel_config['early']) or (relationship_config is not None and relationship_config['early']) or allocation_config is not None or geometry_config is not None) and value['ids'][0]==1:
            assert value['ids'][2]==1 and value['context']['phase']==0 and value['state']==[0]*4
            assert value['fs_base']==value['context']['tls']==0
            observed['replacement_entries'].append(dict(snapshot=value,initial_sp=reg('rsp')))
            save()
        if value['ids'][0]<2:return False
        assert child_exec and case is not None
        model['snapshot'](value)
        assert value['state']==[0]*4 and value['tokens']==[0]*6
        assert value['fs_base']==value['context']['tls']==0
        assert value['context']['registered_tid']==value['context']['robust']==0
        assert value['ids'][3:6]==case['before']['ids'][:3]
        assert value['ids'][2]==case['before']['ids'][2]+1
        assert value['inactive_state'][2]==67
        last=observed['events'][-1]
        assert last['operation']==7 and last['before']['ids'][0]==value['ids'][0]
        assert last['after']['ids']==value['ids']
        assert last['before']['inactive']==last['after']['inactive']==value['inactive']
        assert word(reg('rsp'))==2
        observed['child_exec_entries'].append(dict(snapshot=value,initial_sp=reg('rsp')))
        save()
        return False

class RefusalReturned(Checked):
    def observe(self):
        global refusal_attempt
        self.enabled=False
        assert refusal_attempt is not None and pending is None and reg('cs')&3==3
        assert reg('rax')==(1<<64)-12
        assert reg('rsp')==refusal_attempt['sp']+8
        assert {r:reg(r) for r in callee}==refusal_attempt['callee']
        assert reg('rip')==refusal_attempt['return_pc']
        after=capture();model['snapshot'](after)
        raw=memory(after['context']['table'],allocation_config['process_storage_bytes']).hex()
        before=refusal_attempt['before']
        for key in ['allocator','ids','state','active','inactive','inactive_state','tables','catalog','registry','identity_store']:
            assert after[key]==before[key], ('fork refusal changed',key)
        assert raw==refusal_attempt['storage']
        assert after['epoch']==[before['epoch'][0]+1,57]
        refusal_attempt.update(after=after,after_storage=raw,result=reg('rax'),returned_sp=reg('rsp'),
            returned_pc=reg('rip'),returned_callee={r:reg(r) for r in callee})
        observed['refusals'].append(refusal_attempt);refusal_attempt=None
        save()
        return False

class UserFork(Checked):
    def observe(self):
        global refusal_attempt
        if reg('rdi')!=57:return False
        before=capture()
        if before['state'][2]!=519:return False
        assert allocation_config is not None and refusal_attempt is None and observed['refusals']==[]
        assert reg('cs')&3==3 and before['ids'][0]==1
        model['snapshot'](before)
        refusal_attempt=dict(before=before,sp=reg('rsp'),callee={r:reg(r) for r in callee},return_pc=word(reg('rsp')),
            storage=memory(before['context']['table'],allocation_config['process_storage_bytes']).hex())
        RefusalReturned('*'+hex(word(reg('rsp'))),internal=True)
        save()
        return False

class AllocationTerminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert allocation_config is not None and pending is refusal_attempt is None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids']==[1,2,1,0,0,0,5]
        assert value['epoch'][1]==231 and value['context']['user_arg']==0
        assert value['state']==[1,0x5f7000,0,0] and value['active']['token']==[0]*3
        raw=memory(value['context']['table'],allocation_config['process_storage_bytes'])
        assert len(observed['terminal'])==int(self.retired)
        if self.retired:assert raw==bytes(len(raw))
        else:assert value['context']['pid']==1 and value['context']['relationship']==0
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class Terminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert cancel_config is not None and pending is None and case is not None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids'][0]==1
        assert value['epoch'][1]==cancel_config['syscall']
        assert value['context']['user_arg']==cancel_config['status']
        assert value['state'][2]==35
        raw=memory(value['context']['table'],cancel_config['process_storage_bytes'])
        if self.retired:
            assert value['ids'][3:6]==[0]*3 and value['inactive_state']==[0]*4
            assert raw==bytes(len(raw)) and value['inactive_wait']==[0,0]
            assert len(observed['terminal'])==1
            assert value['active']==observed['terminal'][0]['snapshot']['active']
        else:
            assert observed['terminal']==[]
            assert value['ids'][3]>=2 and value['inactive_state'][2]==101
            assert value['inactive_wait'][0]==(3 if cancel_config.get('writer',False) else 2) and value['inactive_wait'][1]>0
            assert value['context']['phase']==(1 if cancel_config['early'] else 32)
            child=bytes.fromhex(value['inactive']['bytes'])
            assert [child[i] for i in [34*4096+128,66*4096+64,101*4096-1]]==[0xc1,0xc2,0xc7]
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class GeometryTerminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert geometry_config is not None and pending is None and case is not None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids']==[1,2,1,0,0,0,4]
        assert value['epoch'][1]==231 and value['context']['user_arg']==0
        assert value['state'][:3]==[1,0x5f7000+518*4096-7,518]
        raw=memory(value['context']['table'],geometry_config['process_storage_bytes'])
        assert len(observed['terminal'])==int(self.retired)
        if self.retired:assert raw==bytes(len(raw))
        else:assert value['context']['pid']==1 and value['context']['relationship']==0
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class ChildDeparture(Checked):
    def observe(self):
        assert relationship_config is not None
        number=60 if relationship_config['zombie'] else 24
        if reg('rdi')!=number:return False
        value=capture()
        if value['ids'][0]==1:return False
        assert value['ids'][0]==2 and reg('cs')&3==3 and pending is None
        assert observed['child_departures']==[]
        model['snapshot'](value)
        raw=memory(value['context']['table'],relationship_config['process_storage_bytes'])
        observed['child_departures'].append(dict(snapshot=value,syscall=reg('rdi'),argument=reg('rsi'),storage=raw.hex()))
        save()
        return False

class RelationshipTerminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert relationship_config is not None and pending is None and case is not None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids'][0]==1 and value['state'][2]==35
        assert value['epoch'][1]==relationship_config['syscall'] and value['context']['user_arg']==relationship_config['status']
        assert value['inactive_wait']==[0,0] and value['context']['phase']==(1 if relationship_config['early'] else 32)
        raw=memory(value['context']['table'],relationship_config['process_storage_bytes'])
        assert len(observed['terminal'])==int(self.retired)
        if self.retired:
            assert raw==bytes(len(raw)) and value['ids'][3:6]==[0]*3
        else:
            assert value['context']['pid']==1 and value['context']['relationship']==(2 if relationship_config['zombie'] else 1)
            if relationship_config['zombie']:assert value['ids'][3:6]==[0]*3 and value['inactive_state']==[0]*4
            else:assert value['ids'][3]==2 and value['inactive_state'][2]==101
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class Halt(Checked):
    def observe(self):
        value=capture()
        observed['halt']=dict(snapshot=value,registers={r:reg(r) for r in
            ['rax','rcx','rdx','rsi','rdi','r8','r9','r10','r11','r12','r13','r14','r15','rsp','rip']},
            stack=words(reg('rsp'),16),context_words=words(context,120))
        raise AssertionError(('provider invariant halt',value['context'],value['ids']))

class Complete(Checked):
    def observe(self):
        assert pending is None
        ops=[r['operation'] for r in observed['events']]
        # Four new large-heap cases plus the unchanged four child/clone cases
        # in the surrounding full ABI witness all use actual MM owners.
        if relationship_config is not None:
            zombie=relationship_config['zombie']
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,7,9,10,11,12,13]]==[1,int(relationship_config['early']),1,1,int(not zombie),int(zombie),1]
            assert len(observed['child_departures'])==1
            assert len(observed['replacement_entries'])==int(relationship_config['early'])
            identity=memory(case['before']['context']['policy_store'],relationship_config['identity_storage_bytes'])
            assert identity==bytes(len(identity))
            observed['final_identity_store']=identity.hex()
        elif geometry_config is not None:
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,7,9,10,11,12,13]]==[1,1,1,1,4,1,1]
            prep=[r for r in observed['events'] if r['operation']==9]
            assert [(r['before']['state'][2],r['result'],r['before']['epoch'][1]) for r in prep]==[(519,1,geometry_config['syscall'])]
            assert len(observed['replacement_entries'])==1 and observed['refusals']==[]
            identity=memory(case['before']['context']['policy_store'],geometry_config['identity_storage_bytes'])
            assert identity==bytes(len(identity))
            observed['final_identity_store']=identity.hex()
        elif allocation_config is not None:
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,7,9,10,11,12,13]]==[1,1,3,2,0,2,1]
            prep=[r for r in observed['events'] if r['operation']==9]
            assert [(r['before']['state'][2],r['result']) for r in prep]==[(519,0),(1,1),(0,1)]
            assert len(observed['replacement_entries'])==len(observed['refusals'])==1
            assert refusal_attempt is None
            identity=memory(case['before']['context']['policy_store'],allocation_config['identity_storage_bytes'])
            assert identity==bytes(len(identity))
            observed['final_identity_store']=identity.hex()
        elif cancel_config is not None:
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,9,10,11,12,13]]==[1,1,1,1,0,1]
            assert ops.count(7)==int(cancel_config['early'])
            assert len(observed['replacement_entries'])==int(cancel_config['early'])
        else:
            assert case is None and len(observed['cases'])==4
            assert [r['before']['ids'][2] for r in observed['cases']]==[0,1,2,3]
            assert [ops.count(n) for n in [9,10,11,12]]==[8,8,8,8]
            preparations=[r['before']['state'][2] for r in observed['events'] if r['operation']==9]
            assert sorted(preparations)==[34]*4+[67]*4
            assert ops.count(7)==(7 if child_exec else 3)
            assert len(observed['child_exec_entries'])==(4 if child_exec else 0)
        assert words(address('topal_x86_frame_mm_tokens_v1'),6)==[0]*6
        assert words(address('topal_x86_frame_mm_state_v1'),4)==[0]*4
        observed['final']={}
        for suffix,count in [('ids',7),('inactive_token',3),('inactive_state',4),('prepared_token',3),
                             ('prepared_state',7),('prepared_owner',3),('transition',3)]:
            actual=words(address('topal_x86_process_mm_'+suffix+'_v1'),count)
            assert actual==[0]*count
            observed['final'][suffix]=actual
        observed['passed']=True
        save()
        return True

try:
    Gateway('topal_x86_frame_gateway_v1',True)
    Gateway('topal_x86_frame_gateway_return_reclaimed_v1',False)
    CaseEntered('*'+hex(component['entry']),internal=True)
    if child_exec or allocation_config is not None or geometry_config is not None or (cancel_config is not None and cancel_config['early']) or (relationship_config is not None and relationship_config['early']):
        ImageEntered('*'+hex(component['image_entry']),internal=True)
    if cancel_config is not None:
        Terminal('topal_x86_process_mm_parent_exit_v1',False)
        Terminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    if allocation_config is not None:
        UserFork('*'+hex(component['syscall']),internal=True)
        AllocationTerminal('topal_x86_process_mm_parent_exit_v1',False)
        AllocationTerminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    if geometry_config is not None:
        GeometryTerminal('topal_x86_process_mm_parent_exit_v1',False)
        GeometryTerminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    if relationship_config is not None:
        ChildDeparture('*'+hex(component['syscall']),internal=True)
        RelationshipTerminal('topal_x86_process_mm_parent_exit_v1',False)
        RelationshipTerminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    Halt('*'+hex(native_halt),internal=True)
    Complete('*topal_x86_systems_fatal',internal=True)
    gdb.execute('continue')
    assert observed['passed']
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:
    traceback.print_exc()
    save()
    gdb.execute('quit 1')

end
