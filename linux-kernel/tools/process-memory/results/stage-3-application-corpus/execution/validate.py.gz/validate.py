"""Validate the completed native corpus under the next exclusive bounded run."""
import ast
import json
from pathlib import Path
import subprocess
import time

root=Path.cwd()
build=root/'linux-kernel/.cache/x86_64/process-mm-applications-2466445-1794506962968504890'
batch=json.loads((build/'process-mm-applications/observations.json').read_text())
assert batch['passed'] and batch['complete_corpus'] and len(batch['workloads'])==51
for name in ['readback_applications.py','archive_applications.py','replay_applications.py']:
    path=root/'linux-kernel/tools/process-memory'/name
    tree=ast.parse(path.read_text(),filename=str(path))
    compile(tree,str(path),'exec')
    for node in ast.walk(tree):
        if isinstance(node,ast.Assign) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str):
            if any(isinstance(target,ast.Name) and target.id=='script' for target in node.targets):
                compile(node.value.value,str(path)+':frozen-script','exec')
commands=[
    ('workspace-check',['cargo','check','--workspace','--all-targets','--locked','-j1']),
    ('user-memory-models',['python3','-m','unittest','discover','-s','linux-kernel/tools/user-memory','-p','test_*.py']),
    ('process-memory-models',['python3','-m','unittest','discover','-s','linux-kernel/tools/process-memory','-p','test_*.py']),
    ('default-ABI-fixture',['cargo','test','-p','topal-compiler','--lib','default_abi_fixture_preserves_committed_generator_bytes']),
    ('format',['cargo','fmt','--all','--','--check']),
    ('Rust-file-ceiling',['python3','scripts/check_rust_file_sizes.py']),
]
report={}
for name,command in commands:
    start=time.monotonic();args=['rtk','proxy']+command
    result=subprocess.run(args,capture_output=True,text=True)
    (build/(name+'.stdout.log')).write_text(result.stdout)
    (build/(name+'.stderr.log')).write_text(result.stderr)
    row=dict(argv=args,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
    (build/(name+'.command.json')).write_text(json.dumps(row,indent=2)+'\n')
    report[name]=row;(build/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:
        print(result.stdout[-4000:]+result.stderr[-4000:])
        raise SystemExit(result.returncode)
opt=Path('/home/mats/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/opt')
verification={}
import hashlib
for role in ['source','runtime','owner','controller','target','dispatch','extent']:
    command=[str(opt),'-passes=verify','-disable-output',str(build/(role+'.ll'))]
    result=subprocess.run(['rtk','proxy']+command,capture_output=True,text=True)
    (build/(role+'-explicit-verify.command.json')).write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
    (build/(role+'-explicit-verify.stdout.log')).write_text(result.stdout)
    (build/(role+'-explicit-verify.stderr.log')).write_text(result.stderr)
    if result.returncode:raise RuntimeError(result.stderr)
    verification[role]=dict(passed=True,sha256=hashlib.sha256((build/(role+'.ll')).read_bytes()).hexdigest())
(build/'llvm-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
for name in batch['selected']:
    command=['rtk','proxy','python3','linux-kernel/tools/process-memory/readback_applications.py',str(build),name]
    result=subprocess.run(command,capture_output=True,text=True)
    native=build/'process-mm-applications'/name
    (native/'readback.command.json').write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
    (native/'readback.stdout.log').write_text(result.stdout)
    (native/'readback.stderr.log').write_text(result.stderr)
    print(name,result.returncode,result.stdout.strip(),flush=True)
    if result.returncode:
        print(result.stderr[-6000:],flush=True)
        raise SystemExit(result.returncode)
