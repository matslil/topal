"""Collect only after native execution, validation and final reports are ready."""
import json
from pathlib import Path
import subprocess
import sys

folder=Path(__file__).resolve().parent
build='linux-kernel/.cache/x86_64/process-mm-applications-2466445-1794506962968504890'
args=['python3','linux-kernel/tools/process-memory/archive_applications.py',build,
      '--reference','linux-kernel/.cache/x86_64/process-mm-preparation-2424572-1794483877447939717',
      '--prior','linux-kernel/tools/process-memory/results/stage-3-interface-regressions',
      '--run','linux-kernel/.cache/x86_64/process-mm-applications-corpus',
      '--driver','linux-kernel/.cache/x86_64/process-mm-applications-initial/run.py',
      '--history','linux-kernel/.cache/x86_64/process-mm-applications-initial',
      '--history','linux-kernel/.cache/x86_64/process-mm-applications-smoke',
      '--history','linux-kernel/.cache/x86_64/process-mm-applications-2465998-1794506337011380818',
      '--output','linux-kernel/tools/process-memory/results/stage-3-application-corpus']
result=subprocess.run(['rtk','proxy']+args,capture_output=True,text=True)
(folder/'collection.command.json').write_text(json.dumps(dict(argv=args,exit_code=result.returncode),indent=2)+'\n')
(folder/'collection.stdout.log').write_text(result.stdout)
(folder/'collection.stderr.log').write_text(result.stderr)
print(result.stdout+result.stderr,end='')
sys.exit(result.returncode)
