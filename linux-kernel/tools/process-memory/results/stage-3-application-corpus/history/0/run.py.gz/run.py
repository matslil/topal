"""Retain the actual selected native test command, output and cgroup sample."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();folder=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
if len(sys.argv)>1:folder.mkdir(parents=True,exist_ok=False)
paths=set()
for base,pattern in [('src/topal-compiler/src','**/*.rs'),('src/topal-compiler/src','**/*.ll'),
                     ('linux-kernel/kernel','**/*.t'),('linux-kernel/labs/qemu/x86_64','*.py'),
                     ('linux-kernel/tools/user-memory','*.py')]:
    paths.update(p.relative_to(root).as_posix() for p in (root/base).glob(pattern) if p.is_file())
paths.add('linux-kernel/tools/process-memory/process_native.py')
def hashes():return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(paths)}
before=hashes()
command=['rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1',
         'systems_frame_target::root_tests::process_mm_preserves_pinned_busybox_workloads',
         '--','--ignored','--exact','--test-threads=1','--nocapture']
request=dict(argv=command,environment={name:os.environ.get(name) for name in
    ['TOPAL_PINNED_STATIC_USER_IMAGE','TOPAL_TEST_PROCESS_MM_WORKLOADS']},source_hashes_before=before)
(folder/'request.json').write_text(json.dumps(request,indent=2)+'\n')
start=time.monotonic()
with (folder/'test.log').open('w') as stream:
    result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
after=hashes()
record=dict(request,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
    source_hashes_after=after,source_changes_during_run=before!=after,group=group,resources=resources,
    scope='Actual selected native test and last live cgroup sample; no unseen final-instant or source-lifetime claim')
(folder/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['source_hashes_before','source_hashes_after','argv','environment']}),flush=True)
if result.returncode:print((folder/'test.log').read_text()[-12000:],flush=True)
sys.exit(result.returncode or (2 if before!=after else 0))
