"""Freeze selected ordinary-interface caller observations and qualification."""
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import hashes,watched,VALIDATIONS
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
# Preserve the exact preceding guarded full-compiler reference implementation.
reference_source=(cache/'run-caller-retirement-stage.py').read_text()
tree=ast.parse(reference_source)
function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='compiler_reference')
reference_function=ast.get_source_segment(reference_source,function)
exec(compile(reference_function,'<previous-compiler-reference>','exec'))
name=sys.argv[1] if len(sys.argv)>1 else 'interface-callers-stage'
assert re.fullmatch(r'interface-callers-stage(?:-[0-9]+)?',name)
output=cache/name;output.mkdir(exist_ok=False)
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
def resources():return {name:(directory/name).read_text().strip() for name in
    ['memory.max','memory.swap.max','memory.peak','memory.events']}
paths=watched();assert 'topal-as-dsl.md' not in paths
before=hashes(paths);reference=compiler_reference(paths)
script=Path(__file__).read_bytes();(output/'driver.py').write_bytes(script)
(output/'compiler-reference-function.py').write_text(reference_function+'\n')
report=dict(passed=False,compiler_reference=reference,source_hashes_before=before,
    validation={},cohorts=[],group=group,resource_samples=[resources()],
    scope='Four existing source-built ordinary interfaces (poll,pipes,storage,serial), unchanged kernel/workloads. First normal return per actual helper plus every existing selected interface/MM assertion. Six checks fresh; earlier unchanged383compiler suite referenced, not rerun. All-path/lifetime/fatal/production/fullLinux gates remain.')
start=time.monotonic();log=(output/'driver.log').open('w',buffering=1)
def announce(*values):print(*values,file=log,flush=True)
def progress():
    report['resource_samples'].append(resources())
    (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
temporary=cache/'interface-callers-validation-tmp';temporary.mkdir(exist_ok=True)
environment=dict(os.environ,RUST_MIN_STACK='16777216',PYTHONDONTWRITEBYTECODE='1',
    TMPDIR=str(temporary),RUST_TEST_THREADS='2')
for key in list(environment):
    if key.startswith('TOPAL_TEST_'):environment.pop(key)
native=dict(environment,TOPAL_TEST_PROCESS_MM_CALLER_RETIREMENT='1',
    TOPAL_TEST_PROCESS_MM_INTERFACES='poll,pipes,storage,serial')
failure=0;progress()
try:
    command=['rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1',
        'systems_frame_target::root_tests::process_mm_preserves_source_built_application_interfaces',
        '--','--ignored','--exact','--test-threads=1','--nocapture']
    began=time.monotonic();announce('four ordinary interfaces started')
    with (output/'native.log').open('w') as stream:
        completed=subprocess.run(command,cwd=root,env=native,stdout=stream,stderr=subprocess.STDOUT)
    text=(output/'native.log').read_text()
    builds=[Path(path.strip()).resolve() for path in re.findall(r'actual frame source root: ([^\n]+)',text)]
    native_row=dict(argv=command,exit_code=completed.returncode,elapsed_seconds=time.monotonic()-began,
        environment={key:native[key] for key in ['TOPAL_TEST_PROCESS_MM_CALLER_RETIREMENT','TOPAL_TEST_PROCESS_MM_INTERFACES']},
        builds=[path.relative_to(root).as_posix() for path in builds])
    report['native']=native_row;progress();announce('native',completed.returncode)
    failure=completed.returncode
    if failure:raise RuntimeError('native interface command failed; original log retained')
    assert len(builds)==4 and all(path.is_relative_to(cache) for path in builds)
    for mode,build in zip(['poll','pipes','storage','serial'],builds):
        assert json.loads((build/'source-component.json').read_bytes())['mode']==mode
        assert fact((build/'kernel.elf').read_bytes())['sha256']=='b8212e5e9aca715d8db0d863cbc9655ed989c3884b938b57055c3e22e04d0a7c'
        command=['rtk','proxy','python3','-B','linux-kernel/tools/process-memory/readback_interface_callers.py',str(build)]
        with (output/(mode+'-readback.stdout.log')).open('w') as out,(output/(mode+'-readback.stderr.log')).open('w') as err:
            completed=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err)
        report['cohorts'].append(dict(mode=mode,build=build.relative_to(root).as_posix(),
            readback=dict(argv=command,exit_code=completed.returncode)))
        progress();announce(mode,'readback',completed.returncode);failure=completed.returncode
        if failure:raise RuntimeError('interface caller saved reader failed: '+mode)
    for name,arguments in VALIDATIONS.items():
        if name=='compiler-units':continue
        command=['rtk','proxy']+arguments;began=time.monotonic()
        report['validation'][name]=dict(argv=command,status='running');progress();announce(name,'started')
        with (output/(name+'.stdout.log')).open('w') as out,(output/(name+'.stderr.log')).open('w') as err:
            completed=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err)
        report['validation'][name].update(status='complete',exit_code=completed.returncode,
            elapsed_seconds=time.monotonic()-began);progress();announce(name,completed.returncode)
        failure=completed.returncode
        if failure:raise RuntimeError('qualification failed: '+name)
except BaseException:
    report['failure']=traceback.format_exc();announce(report['failure']);failure=failure or 1
finally:
    after=hashes(paths);same=before==after and paths==watched()
    same_driver=Path(__file__).read_bytes()==script
    report.update(passed=not failure and len(report['validation'])==6 and len(report['cohorts'])==4 and same and same_driver,
        exit_code=failure,source_hashes_after=after,source_changes_during_run=not same,
        driver_unchanged=same_driver,elapsed_seconds=time.monotonic()-start,resources=resources())
    (output/'run.json').write_text(json.dumps(report,indent=2)+'\n')
    announce('finished',report['passed'],'elapsed',report['elapsed_seconds']);log.close()
raise SystemExit(failure or int(not report['passed']))
