def compiler_reference(paths):
    reference=root/'linux-kernel/tools/process-memory/results/stage-3-prelude-stat'
    raw=(root/(str(reference.relative_to(root))+'-review.json')).read_bytes()
    review=json.loads(raw);qualified=review['qualification']
    assert review['passed'] and qualified['passed'] and qualified['exit_code']==0
    assert qualified['source_hashes_before']==qualified['source_hashes_after']
    assert set(qualified['validation'])==set(VALIDATIONS)
    assert all(row['status']=='complete' and row['exit_code']==0 for row in qualified['validation'].values())
    manifest=(reference/'manifest.json').read_bytes()
    assert fact(manifest)==review['archive_manifest']
    assert fact(manifest)['sha256']=='560238583f342343cf601fe648dcb1a0e9ecf6d764f72fb95f63620ee16d495d'
    name='matrix/validation/compiler-units.stdout.log.gz';packed=(reference/name).read_bytes()
    assert fact(packed)==json.loads(manifest)[name]
    compiler_log=gzip.decompress(packed)
    assert b'test result: ok. 383 passed; 0 failed; 25 ignored; 0 measured; 0 filtered out' in compiler_log
    assert qualified['validation']['compiler-units']['argv']==[
        'rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1']
    commit='b754f06a159075a66c01ed509eab42a78b7cc6fd'
    protected=['src','docs','se','spec','scripts','Cargo.toml','Cargo.lock','AGENTS.md',
        'linux-kernel/kernel','linux-kernel/design']
    changed=subprocess.check_output(['rtk','proxy','git','diff','--name-only',commit,'--']+protected,cwd=root)
    assert not changed.strip(),changed.decode()
    before=qualified['source_hashes_before']
    relevant={name:sha for name,sha in before.items() if name.startswith('src/topal-compiler/')
        or name.endswith('.c') or name in ['Cargo.toml','Cargo.lock','AGENTS.md','scripts/run_bounded.py']}
    actual={name for name in paths if name.startswith('src/topal-compiler/')
        or name.endswith('.c') or name in ['Cargo.toml','Cargo.lock','AGENTS.md','scripts/run_bounded.py']}
    assert actual==set(relevant) and hashes(relevant)==relevant
    return dict(commit=commit,review=fact(raw),manifest=fact(manifest),compiler_log=fact(compiler_log),
        unchanged_relevant_inputs=len(relevant),compiler_passed=383,compiler_ignored=25,
        original_resource_accounting_complete=False,
        scope='Earlier actual full compiler command and its recorded exit0, not rerun. Compiler/dependency/authority/kernel/C sources are unchanged; this increment adds only observation/readback/model code. Original driver recovery and incomplete exact original cgroup accounting remain explicit in the retained reference.')
