"""Replay the four successful VMs after the new reader's null-field repair."""
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import hashes,watched,VALIDATIONS
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
source=(cache/'run-caller-retirement-stage.py').read_text()
node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='compiler_reference')
exec(compile(ast.get_source_segment(source,node),'<guarded-compiler-reference>','exec'))
original_dir=cache/'interface-callers-stage'
original=json.loads((original_dir/'run.json').read_bytes())
assert not original['passed'] and original['native']['exit_code']==0 and len(original['native']['builds'])==4
assert original['source_hashes_before']==original['source_hashes_after'] and original['driver_unchanged']
assert "FileNotFoundError:" in (original_dir/'poll-readback.stderr.log').read_text()
assert "/pipe-cases.c'" in (original_dir/'poll-readback.stderr.log').read_text()
paths=watched();before=hashes(paths);reference=compiler_reference(paths)
assert reference==original['compiler_reference'] and set(before)==set(original['source_hashes_after'])
changed={name for name in before if before[name]!=original['source_hashes_after'][name]}
assert changed=={'linux-kernel/tools/process-memory/readback_interface_callers.py'}
for name in changed:
    assert fact((original_dir/'failure-inputs'/name).read_bytes())['sha256']==original['source_hashes_after'][name]
output=cache/'interface-callers-recovery';output.mkdir(exist_ok=False)
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
def resources():return {name:(directory/name).read_text().strip() for name in
    ['memory.max','memory.swap.max','memory.peak','memory.events']}
script=Path(__file__).read_bytes();(output/'driver.py').write_bytes(script)
report=dict(passed=False,schema='topal-interface-callers-recovered-reader-v1',
    compiler_reference=reference,source_hashes_before=before,validation={},cohorts=[],
    native=original['native'],native_source_hashes=original['source_hashes_after'],
    native_resources=original['resources'],original_qualification=fact((original_dir/'run.json').read_bytes()),
    repaired_sources=sorted(changed),group=group,resource_samples=[resources()],
    scope='Four earlier actual complete source-frozen VMs passed. The new saved reader failed on a null optional source-hash field. Only that reader changed. Corrected saved-data replay and six checks run now; no VM or full compiler rerun. Original failed qualification and source version remain failed/retained; resource scopes are separate.')
log=(output/'driver.log').open('w',buffering=1);start=time.monotonic();failure=0
def progress():
    report['resource_samples'].append(resources())
    (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
environment=dict(os.environ,RUST_MIN_STACK='16777216',PYTHONDONTWRITEBYTECODE='1',
    TMPDIR=str(cache/'interface-callers-validation-tmp'),RUST_TEST_THREADS='2')
for name in list(environment):
    if name.startswith('TOPAL_TEST_'):environment.pop(name)
progress()
try:
    for mode,path in zip(['poll','pipes','storage','serial'],original['native']['builds']):
        build=root/path;command=['rtk','proxy','python3','-B',
            'linux-kernel/tools/process-memory/readback_interface_callers.py',str(build)]
        with (output/(mode+'-readback.stdout.log')).open('w') as out,(output/(mode+'-readback.stderr.log')).open('w') as err:
            result=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err)
        report['cohorts'].append(dict(mode=mode,build=path,readback=dict(argv=command,exit_code=result.returncode)))
        print(mode,'saved reader',result.returncode,file=log);progress();failure=result.returncode
        if failure:raise RuntimeError('corrected reader failed: '+mode)
    for name,arguments in VALIDATIONS.items():
        if name=='compiler-units':continue
        command=['rtk','proxy']+arguments;began=time.monotonic()
        report['validation'][name]=dict(argv=command,status='running');progress()
        with (output/(name+'.stdout.log')).open('w') as out,(output/(name+'.stderr.log')).open('w') as err:
            result=subprocess.run(command,cwd=root,env=environment,stdout=out,stderr=err)
        report['validation'][name].update(status='complete',exit_code=result.returncode,
            elapsed_seconds=time.monotonic()-began)
        print(name,result.returncode,file=log);progress();failure=result.returncode
        if failure:raise RuntimeError('supplementary check failed: '+name)
except BaseException:
    report['failure']=traceback.format_exc();print(report['failure'],file=log);failure=failure or 1
finally:
    after=hashes(paths);same=before==after and paths==watched();same_driver=script==Path(__file__).read_bytes()
    report.update(passed=not failure and len(report['validation'])==6 and len(report['cohorts'])==4 and same and same_driver,
        exit_code=failure,source_hashes_after=after,source_changes_during_run=not same,
        driver_unchanged=same_driver,elapsed_seconds=time.monotonic()-start,resources=resources())
    (output/'run.json').write_text(json.dumps(report,indent=2)+'\n')
    print('finished',report['passed'],file=log);log.close()
print(json.dumps(dict(passed=report['passed'],elapsed_seconds=report['elapsed_seconds'])))
raise SystemExit(failure or int(not report['passed']))
