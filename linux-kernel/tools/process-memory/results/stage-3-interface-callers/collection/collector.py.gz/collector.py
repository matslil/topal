"""Freeze selected interface caller evidence and replay from isolated inputs."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
matrix=cache/'interface-callers-recovery';initial_matrix=cache/'interface-callers-stage'
archive=root/'linux-kernel/tools/process-memory/results/stage-3-interface-callers'
replay=cache/'interface-callers-frozen-replay'
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
began=time.monotonic()
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
run=json.loads((matrix/'run.json').read_bytes())
initial=json.loads((initial_matrix/'run.json').read_bytes())
assert not initial['passed'] and initial['native']['exit_code']==0
assert run['original_qualification']==fact((initial_matrix/'run.json').read_bytes())
assert run['passed'] and run['exit_code']==0 and len(run['validation'])==6
assert run['source_hashes_before']==run['source_hashes_after'] and not run['source_changes_during_run']
assert run['driver_unchanged'] and all(row['status']=='complete' and row['exit_code']==0 for row in run['validation'].values())
assert run['native']['exit_code']==0 and len(run['cohorts'])==4
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from readback_interface_callers import readback
archive.mkdir(exist_ok=False);manifest={}
def save(name,raw):
    target=archive/name;assert target.resolve().is_relative_to(archive)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);manifest[name]=fact(raw)
def packed(name,raw):save(name+'.gz',gzip.compress(raw,mtime=0))
report=dict(passed=True,schema='topal-process-mm-interface-callers-v1',sources={},historical_sources={},cohorts={},
    compiler_reference=run['compiler_reference'],
    scope='Four actual selected complete ordinary interface VMs with first normal-return samples. Frozen saved-data/source/model replay executes no VM or compiler rebuild. Every-path, continuous/private-loan, fatal/exception and production/fullLinux gates remain.')
for name,sha in run['source_hashes_before'].items():
    raw=(root/name).read_bytes();assert fact(raw)['sha256']==sha
    report['sources'][name]=fact(raw);packed('inputs/'+name,raw)
    if initial['source_hashes_after'][name]!=sha:
        old=(initial_matrix/'failure-inputs'/name).read_bytes()
        assert fact(old)['sha256']==initial['source_hashes_after'][name]
        report['historical_sources'][name]=fact(old);packed('historical-inputs/'+name,old)
assert set(report['historical_sources'])=={'linux-kernel/tools/process-memory/readback_interface_callers.py'}
for path in matrix.rglob('*'):
    if path.is_file():packed('matrix/'+path.relative_to(matrix).as_posix(),path.read_bytes())
for path in initial_matrix.rglob('*'):
    if path.is_file():packed('history/'+path.relative_to(initial_matrix).as_posix(),path.read_bytes())
for row in run['cohorts']:
    assert row['readback']['exit_code']==0
    mode=row['mode'];build=root/row['build'];summary=json.loads(json.dumps(readback(build)))
    assert summary==json.loads((build/'interface-callers-readback.json').read_bytes())
    opt=json.loads((build/'root-target-verify.command.json').read_bytes())['argv'][0]
    modules={}
    for role in ['source','runtime','owner','controller','target','dispatch','extent']:
        command=['rtk','proxy',opt,'-passes=verify','-disable-output',str(build/(role+'.ll'))]
        result=subprocess.run(command,capture_output=True);assert result.returncode==0,result.stderr
        modules[role]=dict(passed=True,input=fact((build/(role+'.ll')).read_bytes()),argv=command)
    files={}
    for path in build.rglob('*'):
        if path.is_file():
            name=path.relative_to(build).as_posix();raw=path.read_bytes();files[name]=fact(raw)
            packed('native/'+mode+'/'+name,raw)
    report['cohorts'][mode]=dict(summary=summary,llvm=modules,files=files)
    print('collected native',mode,flush=True)
for stage in ['stage-3-caller-retirement','stage-3-prelude-stat','stage-3-interface-regressions']:
    previous=root/'linux-kernel/tools/process-memory/results'/stage
    for name in ['manifest.json','report.json']:
        save('references/'+stage+'/'+name,(previous/name).read_bytes())
    if stage!='stage-3-interface-regressions':
        save('references/'+stage+'/review.json',(previous.parent/(stage+'-review.json')).read_bytes())
    if stage=='stage-3-prelude-stat':
        for name in ['compiler-units.stdout.log','compiler-units.stderr.log']:
            save('references/'+stage+'/'+name+'.gz',(previous/'matrix/validation'/(name+'.gz')).read_bytes())
packed('collection/collector.py',Path(__file__).read_bytes())
save('report.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
replay.mkdir(exist_ok=False)
def restore(target,name,expected):
    assert target.resolve().is_relative_to(replay)
    raw=gzip.decompress((archive/(name+'.gz')).read_bytes());assert fact(raw)==expected
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
for name,expected in report['sources'].items():restore(replay/name,'inputs/'+name,expected)
for mode,case in report['cohorts'].items():
    build=replay/'linux-kernel/.cache/x86_64'/mode
    for name,expected in case['files'].items():restore(build/name,'native/'+mode+'/'+name,expected)
    command=['rtk','proxy','python3','-B','linux-kernel/tools/process-memory/readback_interface_callers.py',str(build)]
    result=subprocess.run(command,cwd=replay,capture_output=True,text=True)
    (replay/(mode+'.stdout.log')).write_text(result.stdout);(replay/(mode+'.stderr.log')).write_text(result.stderr)
    assert result.returncode==0,result.stderr[-4000:]
    assert json.loads(result.stdout)==case['summary']
    print('frozen reader passed',mode,flush=True)
tests=subprocess.run(['rtk','proxy','python3','-B','-m','unittest','discover','-s',
    'linux-kernel/tools/process-memory','-p','test_*.py'],cwd=replay,capture_output=True,text=True)
(replay/'models.stdout.log').write_text(tests.stdout);(replay/'models.stderr.log').write_text(tests.stderr)
assert tests.returncode==0 and 'Ran 82 tests in ' in tests.stderr and tests.stderr.rstrip().endswith('OK'),tests.stderr
initial_root=replay/'initial-reader'
for name,expected in report['sources'].items():restore(initial_root/name,'inputs/'+name,expected)
for name,expected in report['historical_sources'].items():restore(initial_root/name,'historical-inputs/'+name,expected)
initial_build=initial_root/'linux-kernel/.cache/x86_64/poll'
for name,expected in report['cohorts']['poll']['files'].items():restore(initial_build/name,'native/poll/'+name,expected)
failed=subprocess.run(['rtk','proxy','python3','-B','linux-kernel/tools/process-memory/readback_interface_callers.py',str(initial_build)],
    cwd=initial_root,capture_output=True,text=True)
(replay/'initial-reader.stdout.log').write_text(failed.stdout)
(replay/'initial-reader.stderr.log').write_text(failed.stderr)
assert failed.returncode!=0 and 'FileNotFoundError:' in failed.stderr and "/pipe-cases.c'" in failed.stderr
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
record=dict(passed=True,archive_manifest=fact((archive/'manifest.json').read_bytes()),
    cohorts={mode:case['summary'] for mode,case in report['cohorts'].items()},models=82,
    original_reader_failure_reproduced=True,
    elapsed_seconds=time.monotonic()-began,resources=resources,
    scope='Four frozen saved-data readers and82models; no VM/compiler execution during collection/replay.')
(replay/'replayed.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,entries=len(manifest),sources=len(report['sources']),
    elapsed_seconds=record['elapsed_seconds'])),flush=True)
