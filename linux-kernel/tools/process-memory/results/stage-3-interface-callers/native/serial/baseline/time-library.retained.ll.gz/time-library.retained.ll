; ModuleID = '/home/mats/git/topal/src/topal-compiler/../../linux-kernel/.cache/x86_64/process-mm-interface-regression-2549665-1794595403586793869/.topal-systems-artifact-2549665-3/work/time-library.bc'
source_filename = "relative-sleep-deadline.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.OptionalStorage = type { i64, ptr }
%topal.IntStorage = type { i64, i64, [0 x i32] }
%topal.IntDivmod = type { ptr, ptr }
%topal.ContainerSequenceHeader = type { i64, ptr }

@llvm.used = appending global [1 x ptr] [ptr @memset], section "llvm.metadata"
@topal.runtime.int.zero = private constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@topal.runtime.int.one = private constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@.topal.int.0 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.1 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.2 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 2147483647] }, align 8
@.topal.int.3 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1000000000] }, align 8
@.topal.int.4 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 633437444, i32 2] }, align 8
@.topal.int.5 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 2147483647] }, align 8
@.topal.int.6 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 10] }, align 8
@.topal.int.7 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 9] }, align 8
@.topal.int.8 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 10] }, align 8
@.topal.int.9 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -858993459, i32 214748364] }, align 8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #0

; Function Attrs: noimplicitfloat noinline noredzone nounwind optnone
define internal ptr @memset(ptr %destination, i32 %value, i64 %length) #1 {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill

fill:                                             ; preds = %fill, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill

complete:                                         ; preds = %fill, %entry
  ret ptr %destination
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.optional.some(ptr %payload) #2 {
entry:
  %optional = call ptr @topal.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.optional.none() #2 {
entry:
  %optional = call ptr @topal.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.runtime.optional.is.some(ptr %optional) #2 {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid

checked:                                          ; preds = %entry
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some

invalid:                                          ; preds = %entry
  call void @topal.platform.exit(i64 70)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.optional.payload(ptr %optional) #2 {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.allocate(i64 %length, i64 %negative) #2 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.from.u64(i64 %source) #2 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.runtime.int.limb.or.zero(ptr %value, i64 %index) #2 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero

load:                                             ; preds = %entry
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended

zero:                                             ; preds = %entry
  ret i64 0
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.normalize(ptr %value) #2 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim

trim:                                             ; preds = %leading.zero, %entry
  %candidate = phi i64 [ %length, %entry ], [ %next, %leading.zero ]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done

leading.zero:                                     ; preds = %trim
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim

zero:                                             ; preds = %leading.zero, %entry
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value

done:                                             ; preds = %trim
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.copy.with.sign(ptr %value, i64 %negative) #2 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate

zero:                                             ; preds = %entry
  ret ptr @topal.runtime.int.zero

allocate:                                         ; preds = %entry
  %copy = call ptr @topal.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %allocate
  %index = phi i64 [ 0, %allocate ], [ %next, %loop ]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  ret ptr %copy
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.absolute(ptr %value) #2 {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite

infinite:                                         ; preds = %entry
  ret ptr @topal.runtime.int.positive.infinity

finite:                                           ; preds = %entry
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy

same:                                             ; preds = %finite
  ret ptr %value

copy:                                             ; preds = %finite
  %result = call ptr @topal.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.runtime.int.compare.absolute(ptr %left, ptr %right) #2 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer

check.longer:                                     ; preds = %entry
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty

check.empty:                                      ; preds = %check.longer
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs

limbs:                                            ; preds = %limbs.equal, %check.empty
  %position = phi i64 [ %left.length, %check.empty ], [ %index, %limbs.equal ]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater

check.limb.greater:                               ; preds = %limbs
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal

limbs.equal:                                      ; preds = %check.limb.greater
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal

less:                                             ; preds = %limbs, %entry
  ret i32 -1

equal:                                            ; preds = %limbs.equal, %check.empty
  ret i32 0

greater:                                          ; preds = %check.limb.greater, %check.longer
  ret i32 1
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.runtime.int.compare(ptr %left, ptr %right) #2 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity

left.positive:                                    ; preds = %entry
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result

check.left.negative.infinity:                     ; preds = %entry
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity

left.negative:                                    ; preds = %check.left.negative.infinity
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result

check.right.positive.infinity:                    ; preds = %check.left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity

check.right.negative.infinity:                    ; preds = %check.right.positive.infinity
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite

less:                                             ; preds = %check.right.positive.infinity
  ret i32 -1

greater:                                          ; preds = %check.right.negative.infinity
  ret i32 1

finite:                                           ; preds = %check.right.negative.infinity
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute

signed.result:                                    ; preds = %finite
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result

absolute:                                         ; preds = %finite
  %magnitude = call i32 @topal.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) #2 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %left.limb = call i64 @topal.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish

finish:                                           ; preds = %loop, %entry
  %final.carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry

store.carry:                                      ; preds = %finish
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result

without.carry:                                    ; preds = %finish
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) #2 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %borrow = phi i64 [ 0, %entry ], [ %next.borrow, %loop ]
  %left = call i64 @topal.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  %normalized = call ptr @topal.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.add(ptr %left, ptr %right) #2 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity

validate.left.infinity:                           ; preds = %entry
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity

indeterminate.infinity:                           ; preds = %validate.left.infinity
  call void @topal.platform.exit(i64 70)
  unreachable

return.left.infinity:                             ; preds = %validate.left.infinity
  ret ptr %left

check.right.infinity:                             ; preds = %entry
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite

return.right.infinity:                            ; preds = %check.right.infinity
  ret ptr %right

finite:                                           ; preds = %check.right.infinity
  %left.zero = call i1 @topal.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right

return.right:                                     ; preds = %finite
  ret ptr %right

check.right:                                      ; preds = %finite
  %right.zero = call i1 @topal.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero

return.left:                                      ; preds = %check.right
  ret ptr %left

nonzero:                                          ; preds = %check.right
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference

sum:                                              ; preds = %nonzero
  %sum.value = call ptr @topal.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value

difference:                                       ; preds = %nonzero
  %ordering = call i32 @topal.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger

zero:                                             ; preds = %difference
  ret ptr @topal.runtime.int.zero

select.larger:                                    ; preds = %difference
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference

left.difference:                                  ; preds = %select.larger
  %left.value = call ptr @topal.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value

right.difference:                                 ; preds = %select.larger
  %right.value = call ptr @topal.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.multiply(ptr %left, ptr %right) #2 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite

infinite:                                         ; preds = %entry
  %left.zero = call i1 @topal.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity

indeterminate.infinity:                           ; preds = %infinite
  call void @topal.platform.exit(i64 70)
  unreachable

select.infinity:                                  ; preds = %infinite
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.runtime.int.negative.infinity, ptr @topal.runtime.int.positive.infinity
  ret ptr %infinity

finite:                                           ; preds = %entry
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length

zero:                                             ; preds = %finite
  ret ptr @topal.runtime.int.zero

check.length:                                     ; preds = %finite
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate

failure:                                          ; preds = %check.length
  call void @topal.platform.exit(i64 71)
  unreachable

allocate:                                         ; preds = %check.length
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear

clear:                                            ; preds = %clear, %allocate
  %clear.index = phi i64 [ 0, %allocate ], [ %clear.next, %clear ]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry

outer.entry:                                      ; preds = %clear
  br label %outer

outer:                                            ; preds = %outer.done, %outer.entry
  %left.index = phi i64 [ 0, %outer.entry ], [ %left.next, %outer.done ]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner

inner:                                            ; preds = %inner, %outer
  %right.index = phi i64 [ 0, %outer ], [ %right.next, %inner ]
  %carry = phi i64 [ 0, %outer ], [ %next.carry, %inner ]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done

outer.done:                                       ; preds = %inner
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done

done:                                             ; preds = %outer.done
  %normalized = call ptr @topal.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.runtime.int.is.zero(ptr %value) #2 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.divmod.pair(ptr %quotient, ptr %remainder) #2 {
entry:
  %pair = call ptr @topal.platform.allocate(i64 16)
  %quotient.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %remainder.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  store ptr %quotient, ptr %quotient.pointer, align 8
  store ptr %remainder, ptr %remainder.pointer, align 8
  ret ptr %pair
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.divmod.quotient(ptr %pair) #2 {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.divmod.remainder(ptr %pair) #2 {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.runtime.int.bit.length(ptr %value) #2 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check

zero:                                             ; preds = %entry
  ret i64 0

check:                                            ; preds = %entry
  %valid = icmp ule i64 %length, 576460752303423487
  br i1 %valid, label %calculate, label %failure

failure:                                          ; preds = %check
  call void @topal.platform.exit(i64 71)
  unreachable

calculate:                                        ; preds = %check
  %last = sub i64 %length, 1
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %last
  %limb = load i32, ptr %pointer, align 4
  %leading = call i32 @llvm.ctlz.i32(i32 %limb, i1 false)
  %top.bits.raw = sub i32 32, %leading
  %top.bits = zext i32 %top.bits.raw to i64
  %lower.bits = mul i64 %last, 32
  %bits = add i64 %lower.bits, %top.bits
  ret i64 %bits
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.runtime.int.bit.at(ptr %value, i64 %index) #2 {
entry:
  %limb.index = lshr i64 %index, 5
  %offset.raw = and i64 %index, 31
  %offset = trunc i64 %offset.raw to i32
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %limb.index
  %limb = load i32, ptr %pointer, align 4
  %shifted = lshr i32 %limb, %offset
  %bit.raw = and i32 %shifted, 1
  %bit = icmp ne i32 %bit.raw, 0
  ret i1 %bit
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.divmod.absolute(ptr %dividend, ptr %divisor) #2 {
entry:
  %divisor.zero = call i1 @topal.runtime.int.is.zero(ptr %divisor)
  br i1 %divisor.zero, label %failure, label %check.dividend

failure:                                          ; preds = %entry
  call void @topal.platform.exit(i64 65)
  unreachable

check.dividend:                                   ; preds = %entry
  %dividend.zero = call i1 @topal.runtime.int.is.zero(ptr %dividend)
  br i1 %dividend.zero, label %zero, label %prepare

zero:                                             ; preds = %check.dividend
  %zero.pair = call ptr @topal.runtime.int.divmod.pair(ptr @topal.runtime.int.zero, ptr @topal.runtime.int.zero)
  ret ptr %zero.pair

prepare:                                          ; preds = %check.dividend
  %bits = call i64 @topal.runtime.int.bit.length(ptr %dividend)
  br label %loop

loop:                                             ; preds = %merge, %prepare
  %position = phi i64 [ %bits, %prepare ], [ %next.position, %merge ]
  %quotient = phi ptr [ @topal.runtime.int.zero, %prepare ], [ %next.quotient, %merge ]
  %remainder = phi ptr [ @topal.runtime.int.zero, %prepare ], [ %next.remainder, %merge ]
  %bit.index = sub i64 %position, 1
  %bit = call i1 @topal.runtime.int.bit.at(ptr %dividend, i64 %bit.index)
  %quotient.twice = call ptr @topal.runtime.int.add(ptr %quotient, ptr %quotient)
  %remainder.twice = call ptr @topal.runtime.int.add(ptr %remainder, ptr %remainder)
  br i1 %bit, label %append.bit, label %compare

append.bit:                                       ; preds = %loop
  %remainder.with.bit = call ptr @topal.runtime.int.add(ptr %remainder.twice, ptr @topal.runtime.int.one)
  br label %compare

compare:                                          ; preds = %append.bit, %loop
  %candidate = phi ptr [ %remainder.twice, %loop ], [ %remainder.with.bit, %append.bit ]
  %ordering = call i32 @topal.runtime.int.compare.absolute(ptr %candidate, ptr %divisor)
  %subtract = icmp sge i32 %ordering, 0
  br i1 %subtract, label %subtract.divisor, label %retain

subtract.divisor:                                 ; preds = %compare
  %reduced = call ptr @topal.runtime.int.subtract.absolute(ptr %candidate, ptr %divisor, i64 0)
  %incremented = call ptr @topal.runtime.int.add(ptr %quotient.twice, ptr @topal.runtime.int.one)
  br label %merge

retain:                                           ; preds = %compare
  br label %merge

merge:                                            ; preds = %retain, %subtract.divisor
  %next.quotient = phi ptr [ %incremented, %subtract.divisor ], [ %quotient.twice, %retain ]
  %next.remainder = phi ptr [ %reduced, %subtract.divisor ], [ %candidate, %retain ]
  %next.position = sub i64 %position, 1
  %more = icmp ne i64 %next.position, 0
  br i1 %more, label %loop, label %done

done:                                             ; preds = %merge
  %pair = call ptr @topal.runtime.int.divmod.pair(ptr %next.quotient, ptr %next.remainder)
  ret ptr %pair
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.int.quotient.modulo(ptr %left, ptr %right) #2 {
entry:
  %right.zero = call i1 @topal.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %divide

failure:                                          ; preds = %entry
  call void @topal.platform.exit(i64 65)
  unreachable

divide:                                           ; preds = %entry
  %left.absolute = call ptr @topal.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.runtime.int.absolute(ptr %right)
  %unsigned = call ptr @topal.runtime.int.divmod.absolute(ptr %left.absolute, ptr %right.absolute)
  %quotient.absolute = call ptr @topal.runtime.int.divmod.quotient(ptr %unsigned)
  %remainder.absolute = call ptr @topal.runtime.int.divmod.remainder(ptr %unsigned)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.negative = icmp ne i64 %left.sign, 0
  %remainder.zero = call i1 @topal.runtime.int.is.zero(ptr %remainder.absolute)
  %remainder.present = xor i1 %remainder.zero, true
  %needs.adjustment = and i1 %left.negative, %remainder.present
  %quotient.sign = xor i64 %left.sign, %right.sign
  br i1 %needs.adjustment, label %adjust, label %direct

direct:                                           ; preds = %divide
  %direct.quotient = call ptr @topal.runtime.int.copy.with.sign(ptr %quotient.absolute, i64 %quotient.sign)
  %direct.pair = call ptr @topal.runtime.int.divmod.pair(ptr %direct.quotient, ptr %remainder.absolute)
  ret ptr %direct.pair

adjust:                                           ; preds = %divide
  %larger.quotient = call ptr @topal.runtime.int.add(ptr %quotient.absolute, ptr @topal.runtime.int.one)
  %adjusted.quotient = call ptr @topal.runtime.int.copy.with.sign(ptr %larger.quotient, i64 %quotient.sign)
  %adjusted.remainder = call ptr @topal.runtime.int.subtract.absolute(ptr %right.absolute, ptr %remainder.absolute, i64 0)
  %adjusted.pair = call ptr @topal.runtime.int.divmod.pair(ptr %adjusted.quotient, ptr %adjusted.remainder)
  ret ptr %adjusted.pair
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.runtime.container.list.count(ptr %list) #2 {
entry:
  br label %loop

loop:                                             ; preds = %advance, %entry
  %current = phi ptr [ %list, %entry ], [ %next, %advance ]
  %count = phi i64 [ 0, %entry ], [ %count.next, %advance ]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance

advance:                                          ; preds = %loop
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop

done:                                             ; preds = %loop
  ret i64 %count
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.container.array.int.collect(ptr %list) #2 {
entry:
  %count = call i64 @topal.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.runtime.container.array.int.at(ptr %array, i64 %index) #2 {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent

find:                                             ; preds = %entry
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop

loop:                                             ; preds = %advance, %find
  %current = phi ptr [ %entries, %find ], [ %next, %advance ]
  %position = phi i64 [ 0, %find ], [ %position.next, %advance ]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance

advance:                                          ; preds = %loop
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop

present:                                          ; preds = %loop
  %value = load ptr, ptr %current, align 8
  %some = call ptr @topal.runtime.optional.some(ptr %value)
  ret ptr %some

absent:                                           ; preds = %entry
  %none = call ptr @topal.runtime.optional.none()
  ret ptr %none
}

declare ptr @topal_kernel_numeric_allocate_v1(i64)

; Function Attrs: noreturn
declare void @topal_kernel_numeric_abort_v1() #3

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.platform.allocate(i64 %length) #2 {
entry:
  %pointer = call ptr @topal_kernel_numeric_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.platform.exit(i64 %status) #4 {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2einterval_2dseconds.0(ptr %arg0) #2 !dbg !6 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !24, !DIExpression(), !25)
  %v1 = call ptr @topal.runtime.container.array.int.at(ptr %arg0, i64 0), !dbg !26
  %v2 = call i1 @topal.runtime.optional.is.some(ptr %v1), !dbg !26
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !26

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.runtime.optional.payload(ptr %v1), !dbg !27
    #dbg_value(ptr %v3, !28, !DIExpression(), !27)
  br label %optional.decision.merge.2, !dbg !29

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !30

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.0, %optional.decision.none.1 ], !dbg !26
  ret ptr %v4, !dbg !26
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2einterval_2dnanoseconds.1(ptr %arg0) #2 !dbg !31 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !32, !DIExpression(), !33)
  %v1 = call ptr @topal.runtime.container.array.int.at(ptr %arg0, i64 1), !dbg !34
  %v2 = call i1 @topal.runtime.optional.is.some(ptr %v1), !dbg !34
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !34

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.runtime.optional.payload(ptr %v1), !dbg !35
    #dbg_value(ptr %v3, !36, !DIExpression(), !35)
  br label %optional.decision.merge.2, !dbg !37

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !38

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.1, %optional.decision.none.1 ], !dbg !34
  ret ptr %v4, !dbg !34
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2eduration_2dfrom_2dparts.2(ptr %arg0) #2 !dbg !39 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !40, !DIExpression(), !41)
  %v1 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2einterval_2dseconds.0(ptr %arg0), !dbg !42
    #dbg_value(ptr %v1, !43, !DIExpression(), !44)
  %v2 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2einterval_2dnanoseconds.1(ptr %arg0), !dbg !45
    #dbg_value(ptr %v2, !46, !DIExpression(), !47)
    #dbg_value(ptr @.topal.int.2, !48, !DIExpression(), !49)
    #dbg_value(ptr @.topal.int.3, !50, !DIExpression(), !51)
  %v3 = call i32 @topal.runtime.int.compare(ptr %v1, ptr @.topal.int.4), !dbg !52
  %v4 = icmp sge i32 %v3, 0, !dbg !52
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !52

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !53

decision.false.1:                                 ; preds = %entry
  %v5 = call ptr @topal.runtime.int.multiply(ptr %v1, ptr @.topal.int.3), !dbg !54
  %v6 = call ptr @topal.runtime.int.add(ptr %v5, ptr %v2), !dbg !54
  br label %decision.merge.2, !dbg !54

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi ptr [ @.topal.int.2, %decision.true.0 ], [ %v6, %decision.false.1 ], !dbg !52
  ret ptr %v7, !dbg !52
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2eduration_2dnanoseconds.3({ ptr, ptr, i32, i32 } %arg0) #2 !dbg !55 {
entry:
  %v0 = extractvalue { ptr, ptr, i32, i32 } %arg0, 0, !dbg !63
  %v1 = extractvalue { ptr, ptr, i32, i32 } %arg0, 1, !dbg !63
  %v2 = extractvalue { ptr, ptr, i32, i32 } %arg0, 2, !dbg !63
  %v3 = extractvalue { ptr, ptr, i32, i32 } %arg0, 3, !dbg !63
  %v4 = alloca { ptr, ptr, i32, i32 }, align 8
  store { ptr, ptr, i32, i32 } %arg0, ptr %v4, align 8
    #dbg_declare(ptr %v4, !64, !DIExpression(), !63)
    #dbg_value(ptr %v1, !65, !DIExpression(), !66)
    #dbg_value(ptr %v0, !67, !DIExpression(), !68)
    #dbg_value(ptr %v1, !69, !DIExpression(), !70)
    #dbg_value(ptr %v0, !71, !DIExpression(), !72)
  %v5 = call ptr @topal.platform.allocate(i64 16), !dbg !73
  store ptr %v0, ptr %v5, align 8, !dbg !73
  %v6 = getelementptr i8, ptr %v5, i64 8, !dbg !73
  store ptr null, ptr %v6, align 8, !dbg !73
  %v7 = call ptr @topal.platform.allocate(i64 16), !dbg !74
  store ptr %v1, ptr %v7, align 8, !dbg !74
  %v8 = getelementptr i8, ptr %v7, i64 8, !dbg !74
  store ptr %v5, ptr %v8, align 8, !dbg !74
    #dbg_value(ptr %v7, !75, !DIExpression(), !82)
  %v9 = call ptr @topal.runtime.container.array.int.collect(ptr %v7), !dbg !83
  %v10 = alloca ptr, align 8, !dbg !84
  store ptr %v9, ptr %v10, align 8, !dbg !84
    #dbg_declare(ptr %v10, !85, !DIExpression(), !84)
  %v11 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2eduration_2dfrom_2dparts.2(ptr %v9), !dbg !86
  ret ptr %v11, !dbg !86
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2esaturate.4(ptr %arg0) #2 !dbg !87 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !90, !DIExpression(), !91)
    #dbg_value(ptr @.topal.int.5, !92, !DIExpression(), !93)
  %v1 = call i32 @topal.runtime.int.compare(ptr %arg0, ptr @.topal.int.5), !dbg !94
  %v2 = icmp sgt i32 %v1, 0, !dbg !94
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !94

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !95

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !96

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v3 = phi ptr [ @.topal.int.5, %decision.true.0 ], [ %arg0, %decision.false.1 ], !dbg !94
  ret ptr %v3, !dbg !94
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2efirst_2dquotient.5(ptr %arg0, ptr %arg1) #2 !dbg !97 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !100, !DIExpression(), !101)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !102, !DIExpression(), !103)
  ret ptr %arg0, !dbg !104
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2erounded.6(ptr %arg0) #2 !dbg !105 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !106, !DIExpression(), !107)
    #dbg_value(ptr @.topal.int.6, !108, !DIExpression(), !109)
    #dbg_value(ptr @.topal.int.7, !110, !DIExpression(), !111)
  %v1 = call ptr @topal.runtime.int.add(ptr %arg0, ptr @.topal.int.7), !dbg !112
  %v2 = call ptr @topal.runtime.int.quotient.modulo(ptr %v1, ptr @.topal.int.6), !dbg !112
  %v3 = call ptr @topal.runtime.int.divmod.quotient(ptr %v2), !dbg !112
  %v4 = call ptr @topal.runtime.int.divmod.remainder(ptr %v2), !dbg !112
  %v5 = call ptr @topal.runtime.int.add(ptr %arg0, ptr @.topal.int.7), !dbg !112
  %v6 = call ptr @topal.runtime.int.quotient.modulo(ptr %v5, ptr @.topal.int.6), !dbg !112
  %v7 = call ptr @topal.runtime.int.divmod.quotient(ptr %v6), !dbg !112
  %v8 = call ptr @topal.runtime.int.divmod.remainder(ptr %v6), !dbg !112
  %v9 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2efirst_2dquotient.5(ptr %v3, ptr %v8), !dbg !113
  ret ptr %v9, !dbg !113
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2eordinary_2ddeadline.7({ { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0) #2 !dbg !114 {
entry:
  %v0 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 0, !dbg !126
  %v1 = extractvalue { ptr, i1, i32, i32 } %v0, 0, !dbg !126
  %v2 = extractvalue { ptr, i1, i32, i32 } %v0, 1, !dbg !126
  %v3 = extractvalue { ptr, i1, i32, i32 } %v0, 2, !dbg !126
  %v4 = extractvalue { ptr, i1, i32, i32 } %v0, 3, !dbg !126
  %v5 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 1, !dbg !126
  %v6 = extractvalue { ptr, ptr, i32, i32 } %v5, 0, !dbg !126
  %v7 = extractvalue { ptr, ptr, i32, i32 } %v5, 1, !dbg !126
  %v8 = extractvalue { ptr, ptr, i32, i32 } %v5, 2, !dbg !126
  %v9 = extractvalue { ptr, ptr, i32, i32 } %v5, 3, !dbg !126
  %v10 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 2, !dbg !126
  %v11 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 3, !dbg !126
  %v12 = alloca { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 }, align 8
  store { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, ptr %v12, align 8
    #dbg_declare(ptr %v12, !127, !DIExpression(), !126)
  %v13 = insertvalue { ptr, ptr, i32, i32 } poison, ptr %v6, 0, !dbg !128
  %v14 = insertvalue { ptr, ptr, i32, i32 } %v13, ptr %v7, 1, !dbg !128
  %v15 = insertvalue { ptr, ptr, i32, i32 } %v14, i32 %v8, 2, !dbg !128
  %v16 = insertvalue { ptr, ptr, i32, i32 } %v15, i32 %v9, 3, !dbg !128
  %v17 = alloca { ptr, ptr, i32, i32 }, align 8, !dbg !128
  store { ptr, ptr, i32, i32 } %v16, ptr %v17, align 8, !dbg !128
    #dbg_declare(ptr %v17, !129, !DIExpression(), !128)
  %v18 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v1, 0, !dbg !130
  %v19 = insertvalue { ptr, i1, i32, i32 } %v18, i1 %v2, 1, !dbg !130
  %v20 = insertvalue { ptr, i1, i32, i32 } %v19, i32 %v3, 2, !dbg !130
  %v21 = insertvalue { ptr, i1, i32, i32 } %v20, i32 %v4, 3, !dbg !130
  %v22 = alloca { ptr, i1, i32, i32 }, align 8, !dbg !130
  store { ptr, i1, i32, i32 } %v21, ptr %v22, align 8, !dbg !130
    #dbg_declare(ptr %v22, !131, !DIExpression(), !130)
    #dbg_value(ptr %v1, !132, !DIExpression(), !133)
    #dbg_value(ptr @.topal.int.8, !134, !DIExpression(), !135)
  %v23 = insertvalue { ptr, ptr, i32, i32 } poison, ptr %v6, 0, !dbg !136
  %v24 = insertvalue { ptr, ptr, i32, i32 } %v23, ptr %v7, 1, !dbg !136
  %v25 = insertvalue { ptr, ptr, i32, i32 } %v24, i32 %v8, 2, !dbg !136
  %v26 = insertvalue { ptr, ptr, i32, i32 } %v25, i32 %v9, 3, !dbg !136
  %v27 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2eduration_2dnanoseconds.3({ ptr, ptr, i32, i32 } %v26), !dbg !136
    #dbg_value(ptr %v27, !137, !DIExpression(), !138)
  %v28 = insertvalue { ptr, ptr, i32, i32 } poison, ptr %v27, 0, !dbg !139
  %v29 = insertvalue { ptr, ptr, i32, i32 } %v28, ptr %v1, 1, !dbg !139
  %v30 = insertvalue { ptr, ptr, i32, i32 } %v29, i32 0, 2, !dbg !139
  %v31 = insertvalue { ptr, ptr, i32, i32 } %v30, i32 1, 3, !dbg !139
  %v32 = alloca { ptr, ptr, i32, i32 }, align 8, !dbg !139
  store { ptr, ptr, i32, i32 } %v31, ptr %v32, align 8, !dbg !139
    #dbg_declare(ptr %v32, !140, !DIExpression(), !139)
  %v33 = call ptr @topal.runtime.int.multiply(ptr %v1, ptr @.topal.int.8), !dbg !145
  %v34 = call ptr @topal.runtime.int.add(ptr %v33, ptr %v27), !dbg !145
    #dbg_value(ptr %v34, !146, !DIExpression(), !147)
  %v35 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2esaturate.4(ptr %v34), !dbg !148
  %v36 = insertvalue { ptr, ptr, i32, i32 } poison, ptr %v35, 0, !dbg !149
  %v37 = insertvalue { ptr, ptr, i32, i32 } %v36, ptr %v1, 1, !dbg !149
  %v38 = insertvalue { ptr, ptr, i32, i32 } %v37, i32 0, 2, !dbg !149
  %v39 = insertvalue { ptr, ptr, i32, i32 } %v38, i32 1, 3, !dbg !149
  %v40 = alloca { ptr, ptr, i32, i32 }, align 8, !dbg !149
  store { ptr, ptr, i32, i32 } %v39, ptr %v40, align 8, !dbg !149
    #dbg_declare(ptr %v40, !150, !DIExpression(), !149)
    #dbg_value(ptr %v35, !151, !DIExpression(), !152)
  %v41 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2erounded.6(ptr %v35), !dbg !153
  ret ptr %v41, !dbg !153
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.support_2eclock_2esleep_2ddeadline.8({ { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0) #2 !dbg !154 {
entry:
  %v0 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 0, !dbg !155
  %v1 = extractvalue { ptr, i1, i32, i32 } %v0, 0, !dbg !155
  %v2 = extractvalue { ptr, i1, i32, i32 } %v0, 1, !dbg !155
  %v3 = extractvalue { ptr, i1, i32, i32 } %v0, 2, !dbg !155
  %v4 = extractvalue { ptr, i1, i32, i32 } %v0, 3, !dbg !155
  %v5 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 1, !dbg !155
  %v6 = extractvalue { ptr, ptr, i32, i32 } %v5, 0, !dbg !155
  %v7 = extractvalue { ptr, ptr, i32, i32 } %v5, 1, !dbg !155
  %v8 = extractvalue { ptr, ptr, i32, i32 } %v5, 2, !dbg !155
  %v9 = extractvalue { ptr, ptr, i32, i32 } %v5, 3, !dbg !155
  %v10 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 2, !dbg !155
  %v11 = extractvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, 3, !dbg !155
  %v12 = alloca { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 }, align 8
  store { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %arg0, ptr %v12, align 8
    #dbg_declare(ptr %v12, !156, !DIExpression(), !155)
  %v13 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v1, 0, !dbg !157
  %v14 = insertvalue { ptr, i1, i32, i32 } %v13, i1 %v2, 1, !dbg !157
  %v15 = insertvalue { ptr, i1, i32, i32 } %v14, i32 %v3, 2, !dbg !157
  %v16 = insertvalue { ptr, i1, i32, i32 } %v15, i32 %v4, 3, !dbg !157
  %v17 = alloca { ptr, i1, i32, i32 }, align 8, !dbg !157
  store { ptr, i1, i32, i32 } %v16, ptr %v17, align 8, !dbg !157
    #dbg_declare(ptr %v17, !158, !DIExpression(), !157)
    #dbg_value(i1 %v2, !159, !DIExpression(), !160)
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !161

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !162

decision.false.1:                                 ; preds = %entry
  %v18 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v1, 0, !dbg !163
  %v19 = insertvalue { ptr, i1, i32, i32 } %v18, i1 %v2, 1, !dbg !163
  %v20 = insertvalue { ptr, i1, i32, i32 } %v19, i32 %v3, 2, !dbg !163
  %v21 = insertvalue { ptr, i1, i32, i32 } %v20, i32 %v4, 3, !dbg !163
  %v22 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } poison, { ptr, i1, i32, i32 } %v21, 0, !dbg !163
  %v23 = insertvalue { ptr, ptr, i32, i32 } poison, ptr %v6, 0, !dbg !163
  %v24 = insertvalue { ptr, ptr, i32, i32 } %v23, ptr %v7, 1, !dbg !163
  %v25 = insertvalue { ptr, ptr, i32, i32 } %v24, i32 %v8, 2, !dbg !163
  %v26 = insertvalue { ptr, ptr, i32, i32 } %v25, i32 %v9, 3, !dbg !163
  %v27 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v22, { ptr, ptr, i32, i32 } %v26, 1, !dbg !163
  %v28 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v27, i32 %v10, 2, !dbg !163
  %v29 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v28, i32 %v11, 3, !dbg !163
  %v30 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2eordinary_2ddeadline.7({ { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v29), !dbg !163
  br label %decision.merge.2, !dbg !163

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v31 = phi ptr [ @.topal.int.9, %decision.true.0 ], [ %v30, %decision.false.1 ], !dbg !161
  ret ptr %v31, !dbg !161
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.numeric.topal.fn.sleep_2ddeadline.9(ptr %arg0, ptr %arg1, ptr %arg2, i1 %arg3) #2 !dbg !164 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !167, !DIExpression(), !168)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !169, !DIExpression(), !170)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !171, !DIExpression(), !172)
  %v3 = alloca i1, align 1
  store i1 %arg3, ptr %v3, align 1
    #dbg_declare(ptr %v3, !173, !DIExpression(), !174)
  %v4 = insertvalue { ptr, i1, i32, i32 } poison, ptr %arg2, 0, !dbg !175
  %v5 = insertvalue { ptr, i1, i32, i32 } %v4, i1 %arg3, 1, !dbg !175
  %v6 = insertvalue { ptr, i1, i32, i32 } %v5, i32 0, 2, !dbg !175
  %v7 = insertvalue { ptr, i1, i32, i32 } %v6, i32 1, 3, !dbg !175
  %v8 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } poison, { ptr, i1, i32, i32 } %v7, 0, !dbg !175
  %v9 = insertvalue { ptr, ptr, i32, i32 } poison, ptr %arg1, 0, !dbg !175
  %v10 = insertvalue { ptr, ptr, i32, i32 } %v9, ptr %arg0, 1, !dbg !175
  %v11 = insertvalue { ptr, ptr, i32, i32 } %v10, i32 1, 2, !dbg !175
  %v12 = insertvalue { ptr, ptr, i32, i32 } %v11, i32 0, 3, !dbg !175
  %v13 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v8, { ptr, ptr, i32, i32 } %v12, 1, !dbg !175
  %v14 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v13, i32 1, 2, !dbg !175
  %v15 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v14, i32 0, 3, !dbg !175
  %v16 = alloca { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 }, align 8, !dbg !175
  store { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v15, ptr %v16, align 8, !dbg !175
    #dbg_declare(ptr %v16, !176, !DIExpression(), !175)
  %v17 = insertvalue { ptr, i1, i32, i32 } poison, ptr %arg2, 0, !dbg !177
  %v18 = insertvalue { ptr, i1, i32, i32 } %v17, i1 %arg3, 1, !dbg !177
  %v19 = insertvalue { ptr, i1, i32, i32 } %v18, i32 0, 2, !dbg !177
  %v20 = insertvalue { ptr, i1, i32, i32 } %v19, i32 1, 3, !dbg !177
  %v21 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } poison, { ptr, i1, i32, i32 } %v20, 0, !dbg !177
  %v22 = insertvalue { ptr, ptr, i32, i32 } poison, ptr %arg1, 0, !dbg !177
  %v23 = insertvalue { ptr, ptr, i32, i32 } %v22, ptr %arg0, 1, !dbg !177
  %v24 = insertvalue { ptr, ptr, i32, i32 } %v23, i32 1, 2, !dbg !177
  %v25 = insertvalue { ptr, ptr, i32, i32 } %v24, i32 0, 3, !dbg !177
  %v26 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v21, { ptr, ptr, i32, i32 } %v25, 1, !dbg !177
  %v27 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v26, i32 1, 2, !dbg !177
  %v28 = insertvalue { { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v27, i32 0, 3, !dbg !177
  %v29 = call fastcc ptr @topal.numeric.topal.fn.support_2eclock_2esleep_2ddeadline.8({ { ptr, i1, i32, i32 }, { ptr, ptr, i32, i32 }, i32, i32 } %v28), !dbg !177
  ret ptr %v29, !dbg !177
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define i64 @topal_kernel_sleep_deadline_policy_v1(i64 %seconds, i64 %nanoseconds, i64 %ticks, i64 %wrapped) #2 {
entry:
  %seconds.valid = icmp ule i64 %seconds, 9223372036854775807
  %nanos.valid = icmp ult i64 %nanoseconds, 1000000000
  %wrapped.valid = icmp ule i64 %wrapped, 1
  %valid.interval = and i1 %seconds.valid, %nanos.valid
  %valid = and i1 %valid.interval, %wrapped.valid
  br i1 %valid, label %invoke, label %invalid

invoke:                                           ; preds = %entry
  %s = call ptr @topal.runtime.int.from.u64(i64 %seconds)
  %n = call ptr @topal.runtime.int.from.u64(i64 %nanoseconds)
  %t = call ptr @topal.runtime.int.from.u64(i64 %ticks)
  %w = trunc i64 %wrapped to i1
  %result = call fastcc ptr @topal.numeric.topal.fn.sleep_2ddeadline.9(ptr %s, ptr %n, ptr %t, i1 %w)
  %sign.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  %sign = load i64, ptr %sign.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %nonnegative = icmp eq i64 %sign, 0
  %bounded.length = icmp ule i64 %length, 2
  %valid.result = and i1 %nonnegative, %bounded.length
  br i1 %valid.result, label %extract, label %invalid

extract:                                          ; preds = %invoke
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %return.zero, label %low

return.zero:                                      ; preds = %extract
  ret i64 0

low:                                              ; preds = %extract
  %low.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 0
  %low.word = load i32, ptr %low.pointer, align 4
  %low.value = zext i32 %low.word to i64
  %single = icmp eq i64 %length, 1
  br i1 %single, label %check, label %high

high:                                             ; preds = %low
  %high.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 1
  %high.word = load i32, ptr %high.pointer, align 4
  %high.value = zext i32 %high.word to i64
  %shifted = shl i64 %high.value, 32
  %combined = or i64 %low.value, %shifted
  br label %check

check:                                            ; preds = %high, %low
  %value = phi i64 [ %low.value, %low ], [ %combined, %high ]
  %in.range = icmp ule i64 %value, 922337203685477581
  br i1 %in.range, label %return, label %invalid

return:                                           ; preds = %check
  ret i64 %value

invalid:                                          ; preds = %check, %invoke, %entry
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { noimplicitfloat noinline noredzone nounwind optnone "disable-tail-calls"="true" }
attributes #2 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #3 = { noreturn }
attributes #4 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "relative-sleep-deadline.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "support.clock.interval-seconds", linkageName: "topal.numeric.topal.fn.support_2eclock_2einterval_2dseconds.0", scope: !7, file: !7, line: 11, type: !8, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DIFile(filename: "clock.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !17}
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !1, baseType: !11)
!11 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !12, size: 64, align: 64)
!12 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !13)
!13 = !{!14, !16}
!14 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !15, size: 64, align: 64)
!15 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !15, size: 64, align: 64, offset: 64)
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "Array 2 Int", file: !1, baseType: !18)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!19 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalContainer.Array 2 Int", file: !1, size: 128, align: 64, elements: !20)
!20 = !{!21, !22}
!21 = !DIDerivedType(tag: DW_TAG_member, name: "entry_count", file: !1, baseType: !15, size: 64, align: 64)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "entries", file: !1, baseType: !23, size: 64, align: 64, offset: 64)
!23 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64, align: 64)
!24 = !DILocalVariable(name: "parts", arg: 1, scope: !6, file: !7, line: 11, type: !17)
!25 = !DILocation(line: 11, column: 25, scope: !6)
!26 = !DILocation(line: 12, column: 3, scope: !6)
!27 = !DILocation(line: 13, column: 10, scope: !6)
!28 = !DILocalVariable(name: "value", scope: !6, file: !7, line: 13, type: !10)
!29 = !DILocation(line: 13, column: 21, scope: !6)
!30 = !DILocation(line: 14, column: 15, scope: !6)
!31 = distinct !DISubprogram(name: "support.clock.interval-nanoseconds", linkageName: "topal.numeric.topal.fn.support_2eclock_2einterval_2dnanoseconds.1", scope: !7, file: !7, line: 16, type: !8, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !0)
!32 = !DILocalVariable(name: "parts", arg: 1, scope: !31, file: !7, line: 16, type: !17)
!33 = !DILocation(line: 16, column: 29, scope: !31)
!34 = !DILocation(line: 17, column: 3, scope: !31)
!35 = !DILocation(line: 18, column: 10, scope: !31)
!36 = !DILocalVariable(name: "value", scope: !31, file: !7, line: 18, type: !10)
!37 = !DILocation(line: 18, column: 21, scope: !31)
!38 = !DILocation(line: 19, column: 15, scope: !31)
!39 = distinct !DISubprogram(name: "support.clock.duration-from-parts", linkageName: "topal.numeric.topal.fn.support_2eclock_2eduration_2dfrom_2dparts.2", scope: !7, file: !7, line: 21, type: !8, scopeLine: 21, spFlags: DISPFlagDefinition, unit: !0)
!40 = !DILocalVariable(name: "parts", arg: 1, scope: !39, file: !7, line: 21, type: !17)
!41 = !DILocation(line: 21, column: 28, scope: !39)
!42 = !DILocation(line: 22, column: 14, scope: !39)
!43 = !DILocalVariable(name: "seconds", scope: !39, file: !7, line: 22, type: !10)
!44 = !DILocation(line: 22, column: 3, scope: !39)
!45 = !DILocation(line: 23, column: 18, scope: !39)
!46 = !DILocalVariable(name: "nanoseconds", scope: !39, file: !7, line: 23, type: !10)
!47 = !DILocation(line: 23, column: 3, scope: !39)
!48 = !DILocalVariable(name: "maximum", scope: !39, file: !7, line: 24, type: !10)
!49 = !DILocation(line: 24, column: 3, scope: !39)
!50 = !DILocalVariable(name: "billion", scope: !39, file: !7, line: 25, type: !10)
!51 = !DILocation(line: 25, column: 3, scope: !39)
!52 = !DILocation(line: 26, column: 3, scope: !39)
!53 = !DILocation(line: 27, column: 15, scope: !39)
!54 = !DILocation(line: 28, column: 16, scope: !39)
!55 = distinct !DISubprogram(name: "support.clock.duration-nanoseconds", linkageName: "topal.numeric.topal.fn.support_2eclock_2eduration_2dnanoseconds.3", scope: !7, file: !7, line: 30, type: !56, scopeLine: 30, spFlags: DISPFlagDefinition, unit: !0)
!56 = !DISubroutineType(types: !57)
!57 = !{!10, !58}
!58 = !DICompositeType(tag: DW_TAG_structure_type, name: "(nanoseconds : Nat, seconds : Nat)", file: !1, size: 192, align: 64, elements: !59)
!59 = !{!60, !62}
!60 = !DIDerivedType(tag: DW_TAG_member, name: "nanoseconds", file: !1, baseType: !61, size: 64, align: 64)
!61 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !11)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "seconds", file: !1, baseType: !61, size: 64, align: 64, offset: 64)
!63 = !DILocation(line: 30, column: 29, scope: !55)
!64 = !DILocalVariable(name: "interval", arg: 1, scope: !55, file: !7, line: 30, type: !58)
!65 = !DILocalVariable(name: "seconds", scope: !55, file: !7, line: 31, type: !61)
!66 = !DILocation(line: 31, column: 3, scope: !55)
!67 = !DILocalVariable(name: "nanoseconds", scope: !55, file: !7, line: 32, type: !61)
!68 = !DILocation(line: 32, column: 3, scope: !55)
!69 = !DILocalVariable(name: "seconds-value", scope: !55, file: !7, line: 33, type: !10)
!70 = !DILocation(line: 33, column: 3, scope: !55)
!71 = !DILocalVariable(name: "nanoseconds-value", scope: !55, file: !7, line: 34, type: !10)
!72 = !DILocation(line: 34, column: 3, scope: !55)
!73 = !DILocation(line: 35, column: 47, scope: !55)
!74 = !DILocation(line: 35, column: 25, scope: !55)
!75 = !DILocalVariable(name: "entries", scope: !55, file: !7, line: 35, type: !76)
!76 = !DIDerivedType(tag: DW_TAG_typedef, name: "List Int", file: !1, baseType: !77)
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !78, size: 64, align: 64)
!78 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalList.Int", file: !1, size: 128, align: 64, elements: !79)
!79 = !{!80, !81}
!80 = !DIDerivedType(tag: DW_TAG_member, name: "value", file: !1, baseType: !10, size: 64, align: 64)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "remaining", file: !1, baseType: !23, size: 64, align: 64, offset: 64)
!82 = !DILocation(line: 35, column: 3, scope: !55)
!83 = !DILocation(line: 36, column: 29, scope: !55)
!84 = !DILocation(line: 36, column: 3, scope: !55)
!85 = !DILocalVariable(name: "parts", scope: !55, file: !7, line: 36, type: !17)
!86 = !DILocation(line: 37, column: 3, scope: !55)
!87 = distinct !DISubprogram(name: "support.clock.saturate", linkageName: "topal.numeric.topal.fn.support_2eclock_2esaturate.4", scope: !7, file: !7, line: 39, type: !88, scopeLine: 39, spFlags: DISPFlagDefinition, unit: !0)
!88 = !DISubroutineType(types: !89)
!89 = !{!10, !10}
!90 = !DILocalVariable(name: "nanoseconds", arg: 1, scope: !87, file: !7, line: 39, type: !10)
!91 = !DILocation(line: 39, column: 17, scope: !87)
!92 = !DILocalVariable(name: "maximum", scope: !87, file: !7, line: 40, type: !10)
!93 = !DILocation(line: 40, column: 3, scope: !87)
!94 = !DILocation(line: 41, column: 3, scope: !87)
!95 = !DILocation(line: 42, column: 15, scope: !87)
!96 = !DILocation(line: 43, column: 16, scope: !87)
!97 = distinct !DISubprogram(name: "support.clock.first-quotient", linkageName: "topal.numeric.topal.fn.support_2eclock_2efirst_2dquotient.5", scope: !7, file: !7, line: 3, type: !98, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!98 = !DISubroutineType(types: !99)
!99 = !{!10, !10, !10}
!100 = !DILocalVariable(name: "quotient", arg: 1, scope: !97, file: !7, line: 3, type: !10)
!101 = !DILocation(line: 3, column: 23, scope: !97)
!102 = !DILocalVariable(name: "remainder", arg: 2, scope: !97, file: !7, line: 3, type: !10)
!103 = !DILocation(line: 3, column: 39, scope: !97)
!104 = !DILocation(line: 4, column: 3, scope: !97)
!105 = distinct !DISubprogram(name: "support.clock.rounded", linkageName: "topal.numeric.topal.fn.support_2eclock_2erounded.6", scope: !7, file: !7, line: 6, type: !88, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !0)
!106 = !DILocalVariable(name: "target", arg: 1, scope: !105, file: !7, line: 6, type: !10)
!107 = !DILocation(line: 6, column: 20, scope: !105)
!108 = !DILocalVariable(name: "ten", scope: !105, file: !7, line: 7, type: !10)
!109 = !DILocation(line: 7, column: 3, scope: !105)
!110 = !DILocalVariable(name: "nine", scope: !105, file: !7, line: 8, type: !10)
!111 = !DILocation(line: 8, column: 3, scope: !105)
!112 = !DILocation(line: 9, column: 20, scope: !105)
!113 = !DILocation(line: 9, column: 3, scope: !105)
!114 = distinct !DISubprogram(name: "support.clock.ordinary-deadline", linkageName: "topal.numeric.topal.fn.support_2eclock_2eordinary_2ddeadline.7", scope: !7, file: !7, line: 45, type: !115, scopeLine: 45, spFlags: DISPFlagDefinition, unit: !0)
!115 = !DISubroutineType(types: !116)
!116 = !{!10, !117}
!117 = !DICompositeType(tag: DW_TAG_structure_type, name: "(clock : (ticks : Nat, wrapped : Boolean), interval : (nanoseconds : Nat, seconds : Nat))", file: !1, size: 448, align: 64, elements: !118)
!118 = !{!119, !125}
!119 = !DIDerivedType(tag: DW_TAG_member, name: "clock", file: !1, baseType: !120, size: 192, align: 64)
!120 = !DICompositeType(tag: DW_TAG_structure_type, name: "(ticks : Nat, wrapped : Boolean)", file: !1, size: 192, align: 64, elements: !121)
!121 = !{!122, !123}
!122 = !DIDerivedType(tag: DW_TAG_member, name: "ticks", file: !1, baseType: !61, size: 64, align: 64)
!123 = !DIDerivedType(tag: DW_TAG_member, name: "wrapped", file: !1, baseType: !124, size: 8, align: 8, offset: 64)
!124 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!125 = !DIDerivedType(tag: DW_TAG_member, name: "interval", file: !1, baseType: !58, size: 192, align: 64, offset: 192)
!126 = !DILocation(line: 45, column: 26, scope: !114)
!127 = !DILocalVariable(name: "request", arg: 1, scope: !114, file: !7, line: 45, type: !117)
!128 = !DILocation(line: 46, column: 3, scope: !114)
!129 = !DILocalVariable(name: "interval", scope: !114, file: !7, line: 46, type: !58)
!130 = !DILocation(line: 47, column: 3, scope: !114)
!131 = !DILocalVariable(name: "clock", scope: !114, file: !7, line: 47, type: !120)
!132 = !DILocalVariable(name: "ticks", scope: !114, file: !7, line: 48, type: !61)
!133 = !DILocation(line: 48, column: 3, scope: !114)
!134 = !DILocalVariable(name: "ten", scope: !114, file: !7, line: 49, type: !61)
!135 = !DILocation(line: 49, column: 3, scope: !114)
!136 = !DILocation(line: 50, column: 15, scope: !114)
!137 = !DILocalVariable(name: "duration", scope: !114, file: !7, line: 50, type: !10)
!138 = !DILocation(line: 50, column: 3, scope: !114)
!139 = !DILocation(line: 51, column: 3, scope: !114)
!140 = !DILocalVariable(name: "state", scope: !114, file: !7, line: 51, type: !141)
!141 = !DICompositeType(tag: DW_TAG_structure_type, name: "(nanoseconds : Int, ticks : Nat)", file: !1, size: 192, align: 64, elements: !142)
!142 = !{!143, !144}
!143 = !DIDerivedType(tag: DW_TAG_member, name: "nanoseconds", file: !1, baseType: !10, size: 64, align: 64)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "ticks", file: !1, baseType: !61, size: 64, align: 64, offset: 64)
!145 = !DILocation(line: 52, column: 16, scope: !114)
!146 = !DILocalVariable(name: "requested", scope: !114, file: !7, line: 52, type: !10)
!147 = !DILocation(line: 52, column: 3, scope: !114)
!148 = !DILocation(line: 53, column: 44, scope: !114)
!149 = !DILocation(line: 53, column: 3, scope: !114)
!150 = !DILocalVariable(name: "normalized", scope: !114, file: !7, line: 53, type: !141)
!151 = !DILocalVariable(name: "target", scope: !114, file: !7, line: 54, type: !10)
!152 = !DILocation(line: 54, column: 3, scope: !114)
!153 = !DILocation(line: 55, column: 3, scope: !114)
!154 = distinct !DISubprogram(name: "support.clock.sleep-deadline", linkageName: "topal.numeric.topal.fn.support_2eclock_2esleep_2ddeadline.8", scope: !7, file: !7, line: 57, type: !115, scopeLine: 57, spFlags: DISPFlagDefinition, unit: !0)
!155 = !DILocation(line: 57, column: 27, scope: !154)
!156 = !DILocalVariable(name: "request", arg: 1, scope: !154, file: !7, line: 57, type: !117)
!157 = !DILocation(line: 58, column: 3, scope: !154)
!158 = !DILocalVariable(name: "clock", scope: !154, file: !7, line: 58, type: !120)
!159 = !DILocalVariable(name: "wrapped", scope: !154, file: !7, line: 59, type: !124)
!160 = !DILocation(line: 59, column: 3, scope: !154)
!161 = !DILocation(line: 60, column: 3, scope: !154)
!162 = !DILocation(line: 61, column: 15, scope: !154)
!163 = !DILocation(line: 62, column: 16, scope: !154)
!164 = distinct !DISubprogram(name: "sleep-deadline", linkageName: "topal.numeric.topal.fn.sleep_2ddeadline.9", scope: !1, file: !1, line: 5, type: !165, scopeLine: 5, spFlags: DISPFlagDefinition, unit: !0)
!165 = !DISubroutineType(types: !166)
!166 = !{!10, !61, !61, !61, !124}
!167 = !DILocalVariable(name: "seconds", arg: 1, scope: !164, file: !1, line: 5, type: !61)
!168 = !DILocation(line: 5, column: 28, scope: !164)
!169 = !DILocalVariable(name: "nanoseconds", arg: 2, scope: !164, file: !1, line: 5, type: !61)
!170 = !DILocation(line: 5, column: 43, scope: !164)
!171 = !DILocalVariable(name: "ticks", arg: 3, scope: !164, file: !1, line: 5, type: !61)
!172 = !DILocation(line: 5, column: 62, scope: !164)
!173 = !DILocalVariable(name: "wrapped", arg: 4, scope: !164, file: !1, line: 5, type: !124)
!174 = !DILocation(line: 5, column: 75, scope: !164)
!175 = !DILocation(line: 6, column: 3, scope: !164)
!176 = !DILocalVariable(name: "request", scope: !164, file: !1, line: 6, type: !117)
!177 = !DILocation(line: 10, column: 3, scope: !164)
