import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path.cwd()
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from readback_cancel import readback as cancel_readback
from readback_exec import readback as exec_readback
from readback_allocation import readback as allocation_readback
opt=root.parent.parent/'.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/opt'
opt=Path('/home/mats/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/opt')
for name in sys.argv[1:]:
    build=(root/name).resolve();verification={}
    for role in ['source','runtime','owner','controller','target','dispatch','extent']:
        command=[str(opt),'-passes=verify','-disable-output',str(build/(role+'.ll'))]
        result=subprocess.run(['rtk','proxy']+command,capture_output=True,text=True)
        (build/(role+'-explicit-verify.command.json')).write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
        (build/(role+'-explicit-verify.stdout.log')).write_text(result.stdout)
        (build/(role+'-explicit-verify.stderr.log')).write_text(result.stderr)
        if result.returncode:raise RuntimeError(result.stderr)
        verification[role]=dict(passed=True,sha256=hashlib.sha256((build/(role+'.ll')).read_bytes()).hexdigest())
    (build/'llvm-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    value=json.loads((build/'process-mm-users/observations.json').read_text())
    component=json.loads((build/'source-component.json').read_text())
    reader={'process-mm-cancel':cancel_readback,'process-mm-exec':exec_readback,'process-mm-allocation':allocation_readback}[component['mode']]
    report=reader(value)
    (build/'readback.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(build.name,report.get('case'),report['retired_extents'],report['erased_released_bytes'],flush=True)
