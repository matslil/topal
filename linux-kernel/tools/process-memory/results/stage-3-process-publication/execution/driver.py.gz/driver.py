"""Run the remaining existing MM cohorts with publication observation enabled."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root=Path.cwd();folder=root/'linux-kernel/.cache/x86_64/process-mm-publication-matrix-retry-1'
basic=root/'linux-kernel/.cache/x86_64/process-mm-publication-retry-2/run.json'
basic_build=root/'linux-kernel/.cache/x86_64/process-mm-owners-2474369-1794517655724048367'
basic_result=json.loads(basic.read_text())
assert basic_result['exit_code']==0 and not basic_result['source_changes_during_run']
assert json.loads((basic_build/'process-mm-users/publication-readback.json').read_text())['passed']
assert os.environ.get('TOPAL_TEST_PROCESS_MM_PUBLICATION')=='1'
folder.mkdir(parents=True,exist_ok=False)
paths=set()
for base,patterns in [('src/topal-compiler/src',['**/*.rs','**/*.ll']),
    ('linux-kernel/kernel',['**/*.t']),('linux-kernel/labs/qemu/x86_64',['*.py','*.c']),
    ('linux-kernel/tools/user-memory',['*.py']),('linux-kernel/tools/process-memory',['*.py'])]:
    for pattern in patterns:paths.update(p.relative_to(root).as_posix() for p in (root/base).glob(pattern) if p.is_file())
def hashes():return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(paths)}
before=hashes();start=time.monotonic()
report=dict(passed=False,source_hashes_before=before,
    environment=dict(TOPAL_TEST_PROCESS_MM_PUBLICATION=os.environ.get('TOPAL_TEST_PROCESS_MM_PUBLICATION')),
    cohorts=[])
(folder/'request.json').write_text(json.dumps(report,indent=2)+'\n')
cohorts=[
    ('owners','process_mm_fork_handoff_and_exit_preserve_independent_heap_owners',1),
    ('child-exec','process_mm_child_exec_preserves_inactive_parent_and_fresh_child_heap',1),
    ('allocation','process_mm_allocation_refusal_preserves_owner_and_pid_history',1),
    ('geometry','process_mm_maximum_fork_and_clone_copy_survive_empty_and_one_page_handoff',2),
    ('reader-cancel','process_mm_parent_exit_cancels_blocked_child_and_all_resources',4),
    ('writer-cancel','process_mm_parent_exit_cancels_blocked_writer_and_dirty_fifo',4),
    ('relationships','process_mm_parent_exit_retires_ready_and_zombie_relationships',8),
]
failure=0
for label,test,count in cohorts:
    target=folder/label;target.mkdir()
    command=['rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1',
        'systems_frame_target::root_tests::'+test,'--','--ignored','--exact','--test-threads=1','--nocapture']
    case_start=time.monotonic()
    with (target/'test.log').open('w') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
    row=dict(label=label,argv=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-case_start,builds=[])
    text=(target/'test.log').read_text()
    builds=[Path(name.strip()).resolve() for name in re.findall(r'actual frame source root: ([^\n]+)',text)]
    row['builds']=[str(build.relative_to(root)) for build in builds]
    report['cohorts'].append(row)
    (target/'command.json').write_text(json.dumps(row,indent=2)+'\n')
    (folder/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
    print(label,'native',result.returncode,'builds',len(builds),flush=True)
    if result.returncode:
        print(text[-12000:],flush=True);failure=result.returncode;break
    assert len(builds)==count and all(build.is_relative_to(root/'linux-kernel/.cache/x86_64') for build in builds)
    for i,build in enumerate(builds):
        assert hashlib.sha256((build/'kernel.elf').read_bytes()).hexdigest()=='b8212e5e9aca715d8db0d863cbc9655ed989c3884b938b57055c3e22e04d0a7c'
        command=['rtk','proxy','python3','linux-kernel/tools/process-memory/readback_publication.py',str(build)]
        result=subprocess.run(command,capture_output=True,text=True)
        (target/f'readback-{i}.stdout.log').write_text(result.stdout)
        (target/f'readback-{i}.stderr.log').write_text(result.stderr)
        (target/f'readback-{i}.command.json').write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
        print(label,'readback',i,result.returncode,result.stdout.strip(),flush=True)
        if result.returncode:
            print(result.stderr[-8000:],flush=True);failure=result.returncode;break
    if failure:break
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
after=hashes()
report.update(passed=not failure and len(report['cohorts'])==len(cohorts),exit_code=failure,
    elapsed_seconds=time.monotonic()-start,source_hashes_after=after,source_changes_during_run=before!=after,
    group=group,resources=resources,
    scope='Actual seven selected native tests and per-build record checks; resource sample is cumulative for this complete bounded matrix, not independent per-VM peaks or an unseen final instant')
(folder/'run.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key not in ['source_hashes_before','source_hashes_after','cohorts']}),flush=True)
sys.exit(failure or (2 if before!=after else 0))
