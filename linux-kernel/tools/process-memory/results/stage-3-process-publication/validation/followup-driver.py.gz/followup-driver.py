"""Run dependent validation, collection and frozen replay after the matrix.

The outer run_bounded wrapper serializes this job behind the native matrix.
Any unsuccessful matrix or dependent command stops this pipeline. This script
does not commit, publish or declare initial Step 4 complete.
"""
import json
import hashlib
from pathlib import Path
import subprocess
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
matrix=cache/'process-mm-publication-matrix-retry-1'
run=json.loads((matrix/'run.json').read_text())
assert run['passed'] and run['exit_code']==0 and not run['source_changes_during_run']
validation=cache/'process-mm-publication-final-validation-2'
archive=root/'linux-kernel/tools/process-memory/results/stage-3-process-publication'
replay=cache/'process-mm-publication-frozen-replay-final'
pipeline=cache/'process-mm-publication-final-pipeline-2'
pipeline.mkdir(parents=True,exist_ok=False)
started=time.monotonic()
driver_source=Path(__file__).read_bytes()
(pipeline/'driver.py').write_bytes(driver_source)
commands={
    'validation':['rtk','proxy','python3',str(cache/'validate-publication-stage.py'),str(matrix),str(validation)],
    'archive':['rtk','proxy','python3','linux-kernel/tools/process-memory/archive_publication.py',
        '--matrix',str(matrix),'--driver',str(cache/'process-mm-publication-matrix-retry-1.py'),
        '--prior','linux-kernel/tools/process-memory/results/stage-3-application-corpus',
        '--validation',str(validation),'--output',str(archive),
        '--history',str(cache/'process-mm-publication-initial'),
        '--history',str(cache/'process-mm-publication-retry-1'),
        '--history',str(cache/'process-mm-publication-retry-2'),
        '--history',str(cache/'process-mm-publication-matrix')],
    'replay':['rtk','proxy','python3','linux-kernel/tools/process-memory/replay_publication.py',str(archive),str(replay)],
}
rows={}
for name,command in commands.items():
    start=time.monotonic()
    with (pipeline/(name+'.stdout.log')).open('w') as out,(pipeline/(name+'.stderr.log')).open('w') as err:
        result=subprocess.run(command,stdout=out,stderr=err)
    rows[name]=dict(argv=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
    (pipeline/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:
        print((pipeline/(name+'.stderr.log')).read_text()[-5000:],flush=True)
        raise SystemExit(result.returncode)
    if name=='validation':
        # The collector retains this exact follow-up source with validation
        # logs. This does not alter any repository source or native input.
        (validation/'followup-driver.py').write_bytes(driver_source)
assert json.loads((replay/'replayed.json').read_text())['passed']
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
assert int(resources['memory.swap.max'])==0
assert 0<int(resources['memory.peak'])<=int(resources['memory.max'])
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
(pipeline/'completed.json').write_text(json.dumps(dict(passed=True,commands=rows,
    elapsed_seconds=time.monotonic()-started,group=group,resources=resources,
    driver_sha256=hashlib.sha256(driver_source).hexdigest(),
    scope='Completed matrix follow-up validation/archive/frozen replay with cumulative bounded-job resource sample; source/diff review, evidence commit and final PR update remain'))+'\n')
print('Publication stage prepared for source/diff review and PR update',flush=True)
