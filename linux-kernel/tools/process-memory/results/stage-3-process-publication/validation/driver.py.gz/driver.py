"""Capture fresh checks after the complete publication matrix succeeds."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from archive_publication import selected_inputs
matrix=root/sys.argv[1];output=root/sys.argv[2]
execution=json.loads((matrix/'run.json').read_text())
assert execution['passed'] and execution['exit_code']==0
output.mkdir(parents=True,exist_ok=False)
(output/'driver.py').write_bytes(Path(__file__).read_bytes())
paths=selected_inputs(execution['source_hashes_before'])
def hashes():return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in paths}
before=hashes();start=time.monotonic()
commands={
    'workspace-check':['rtk','proxy','cargo','check','--workspace','--all-targets','--locked','-j1'],
    'user-memory-models':['rtk','proxy','python3','-m','unittest','discover','-s','linux-kernel/tools/user-memory','-p','test_*.py'],
    'process-memory-models':['rtk','proxy','python3','-m','unittest','discover','-s','linux-kernel/tools/process-memory','-p','test_*.py'],
    'default-ABI-fixture':['rtk','proxy','cargo','test','-p','topal-compiler','--lib','--locked','-j1','default_abi_fixture_preserves_committed_generator_bytes'],
    'format':['rtk','proxy','cargo','fmt','--all','--','--check'],
    'Rust-file-ceiling':['rtk','proxy','python3','scripts/check_rust_file_sizes.py'],
}
validation={}
for name,command in commands.items():
    began=time.monotonic();result=subprocess.run(command,capture_output=True,text=True)
    row=dict(argv=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-began)
    validation[name]=row
    (output/(name+'.command.json')).write_text(json.dumps(row,indent=2)+'\n')
    (output/(name+'.stdout.log')).write_text(result.stdout)
    (output/(name+'.stderr.log')).write_text(result.stderr)
    (output/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==0,result.stderr[-4000:]
for path in (root/'linux-kernel/tools/process-memory').glob('*.py'):
    compile(ast.parse(path.read_text()),str(path),'exec')
sys.path.insert(0,str(root/'linux-kernel/labs/qemu/x86_64'))
from process_mm_process_inspect import PROGRAM
from process_mm_publication_observer import augment
compile(augment(PROGRAM),'process-MM-publication-GDB','exec')
for cohort in execution['cohorts']:
    for name in cohort['builds']:
        build=root/name
        opt=json.loads((build/'root-target-verify.command.json').read_text())['argv'][0]
        verified={}
        for role in ['source','runtime','owner','controller','target','dispatch','extent']:
            command=['rtk','proxy',opt,'-passes=verify','-disable-output',str(build/(role+'.ll'))]
            result=subprocess.run(command,capture_output=True,text=True)
            (build/(role+'-publication-verify.command.json')).write_text(json.dumps(dict(argv=command,exit_code=result.returncode))+'\n')
            (build/(role+'-publication-verify.stdout.log')).write_text(result.stdout)
            (build/(role+'-publication-verify.stderr.log')).write_text(result.stderr)
            assert result.returncode==0,result.stderr
            verified[role]=dict(passed=True,sha256=hashlib.sha256((build/(role+'.ll')).read_bytes()).hexdigest())
        (build/'llvm-verification.json').write_text(json.dumps(verified,indent=2)+'\n')
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
after=hashes()
record=dict(passed=before==after,source_hashes_before=before,source_hashes_after=after,
    elapsed_seconds=time.monotonic()-start,group=group,resources=resources,
    scope='Fresh six validation commands, generated observer syntax and seven LLVM modules for each of 21 native builds; no additional VM execution')
(output/'source-stability.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['passed']
print('Fresh publication-stage validation passed',flush=True)
