set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-parent-cancel-2479322-1794521994701828266/kernel.elf"
target remote 127.0.0.1:53411
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-parent-cancel-2479322-1794521994701828266/process-mm-users/observations.json'
component={'allocation_profile': None, 'base': 5701632, 'cancellation': {'early': True, 'process_storage_bytes': 311296, 'status': 769, 'syscall': 231, 'writer': False}, 'command_source_sha256': 'cac5afad81808c0123175a2de8b1e799c70579f9a5ef81445bb3a66433f9e3ef', 'conservative_user_stack_bytes': 1264, 'entry': 5709488, 'exec_source_sha256': None, 'file_source_sha256': '757a45600b38e0746659781ba6e14aa5a90ec9d378cf364fd555299890ef92fa', 'geometry_profile': None, 'image_entry': 5709664, 'image_sha256': '737023628e47c18ea265b46f6d9c0b6851907b2ccf82a191b6393ab4d1f7aa9e', 'linked_sha256': 'dfcc2973f9b4390609dffd7c4f0850ec66a4aa6e35375c8d1b33fe566031006c', 'metadata_source_sha256': None, 'mode': 'process-mm-cancel', 'pipe_source_sha256': None, 'poll_source_sha256': None, 'process_mm_allocation_source_sha256': None, 'process_mm_cancel_source_sha256': '27e33148a69193a4a24a68f265aba9ebfb59f360d5ade425dd2469412d804658', 'process_mm_exec_source_sha256': None, 'process_mm_geometry_source_sha256': None, 'process_mm_relationship_source_sha256': None, 'process_mm_source_sha256': None, 'relationship_profile': None, 'scope': 'source-built ordinary syscall component in a freshly generated first-party ABI witness; not an arbitrary-program loader or production qualification', 'serial_source_sha256': None, 'shell_source_sha256': '574462c620fb4e2db01bc4140e98377f52d4add8eddc3e4a9fa0428d2a3d8db4', 'signal_source_sha256': None, 'source_sha256': '49758cc99552709eb1fe062b26dbcb189ae93ead0755139a56f0dd532017ca6c', 'stack_frame_costs': {'command-cases': 104, 'file-cases': 400, 'process-mm-cancel-cases': 96, 'shell-cases': 168, 'source-cases': 496, 'startup-cases': 168}, 'startup': 5702592, 'startup_call': 5709600, 'startup_source_sha256': '2c5171f997c27d084883f6dce969747c191ab41649864e5c1d73f2367bb574aa', 'stat_source_sha256': None, 'storage_source_sha256': None, 'syscall': 5709552, 'syscall4': 5709568, 'text_bytes': 8236}
kernel_spans=[[2097152, 2097720], [8388608, 44974080], [44974080, 44999368], [45003472, 46281165], [46285264, 46288896], [46289376, 46289384]]
native_halt=45803143
publication_profile={'passed': True, 'kernel_sha256': 'b8212e5e9aca715d8db0d863cbc9655ed989c3884b938b57055c3e22e04d0a7c', 'function_sha256': '019d80d15a88e149c052d72b8d1d40897361bb0593e0b0f8c23a63262f7ceb53', 'function': {'name': 'm.publish', 'info': 2, 'section': 3, 'value': 45160448, 'size': 149}, 'source_sha256': 'cd788d52b2a66f15f80b1a8b6d668d0501f50daed73f5e0151e21d953f5713be', 'dispatch_ir_sha256': 'd8bd7f3e6b20076920d99986e37255b8af05db34a077c7c7768f04a116c206f2', 'erase_entry': 45160400, 'root_switch_sites': {'before': 45700908, 'after': 45700911}, 'root_switch_instruction_sha256': 'd44393334707d9497003080541c12ec4e4bcfdaf11416ce7b8cec718e1764fcb', 'inspector_sha256': '53a25b8a1cca3710ebb0b1a07a8b546d7280dbd8a82ab23e0992eb2f997d267f', 'sites': {'entry': 45160448, 'stored': 45160545, 'invalidated': 45160563, 'returning': 45160596}, 'sites_meaning': {'stored': 'After the first locked publication barrier and before any INVLPG iteration', 'invalidated': 'Immediately after INVLPG and before index/address increments', 'returning': 'After the second locked barrier and complete epilogue, before RET'}, 'scope': 'Exact current 149-byte publisher layout, linked PTE-helper call and source/compiled IR binding; not arbitrary-code decoding, continuous CPU state, AP/DMA/async or complete compiler correctness', 'pin_entry': 45151648, 'release_entry': 45151200}
model={}
exec('"""TOPAL-SYSTEMS-PROCESS-MM-001 saved process/MM boundary checks.\n\nRecords describe observations; they cannot construct native ownership or prove\ncontinuous exclusion, every invalidation instruction or public qualification.\n"""\nPAGE = 4096\nSTART = 0x5F7000\n\n\ndef require(ok, reason):\n    if not ok:\n        raise ValueError(reason)\n\n\ndef owner(row, token, allocator, data=True):\n    require(row[\'token\'] == token, \'token binding\')\n    if token == [0, 0, 0]:\n        require(row[\'record\'] == row[\'cells\'] == [] and row[\'bytes\'] == \'\', \'empty allocation\')\n        return None\n    issuer, identity, index = token\n    require(issuer == allocator[1] == 1 and 0 < identity < allocator[2] and 0 <= index < allocator[3], \'live issuance\')\n    r, cells = row[\'record\'], row[\'cells\']\n    require(len(r) == 8 and r[:2] == token[:2] and r[7] == 1 and r[5] > 0, \'live record\')\n    count = r[3]\n    require(0 < count <= allocator[3] and r[4] > 0 and r[4] & (r[4] - 1) == 0\n            and 0 <= r[2] < r[2] + count <= allocator[3], \'allocation geometry\')\n    require(len(cells) == count * 3 and cells[0::3] == [identity] * count and cells[1::3] == [r[5]] * count, \'owned cells\')\n    first = cells[2]\n    require(first % r[4] == 0, \'allocation alignment\')\n    require(cells[2::3] == list(range(first, first + count)) and 0 <= first < first + count <= 1 << 18, \'physical frames\')\n    raw = bytes.fromhex(row[\'bytes\'])\n    require(len(raw) == (count * PAGE if data else 0), \'whole allocation bytes\')\n    return dict(token=token, span=[first * PAGE, (first + count) * PAGE], count=count,\n                pins=r[6], data=raw, record=r, cells=cells)\n\n\ndef bank(value, state, token, allocator):\n    allocated = owner(value, token, allocator)\n    require(len(state) in [4, 7], \'state width\')\n    if state == [0] * len(state):\n        require(allocated is None, \'owner without state\')\n        return None\n    require(state[0] == 1 and START <= state[1] <= START + 519 * PAGE, \'MM state\')\n    require((state[1] - START + PAGE - 1) // PAGE == state[2] and 0 <= state[2] <= 519, \'byte break\')\n    if not state[2]:\n        require(state[3] == 0 and allocated is None, \'zero-page heap\')\n    else:\n        require(allocated is not None and allocated[\'count\'] == state[2]\n                and allocated[\'span\'][0] == state[3] and allocated[\'pins\'] == 1\n                and allocated[\'record\'][4] == 1, \'heap backing/pin\')\n    return allocated\n\n\ndef mappings(value, count, base):\n    ctx, tables = value[\'context\'], value[\'tables\']\n    root, low = ctx[\'root\'], ctx[\'low\']\n    require(set(tables) == {str(a) for a in [root, root + PAGE, root + 2 * PAGE, root + 3 * PAGE, root + 4 * PAGE, low]}, \'table set\')\n    require(all(len(words) == 512 for words in tables.values()), \'complete tables\')\n    for table, index, target in [(root, 0, root + PAGE), (root + PAGE, 0, root + 2 * PAGE),\n                                 (root + 2 * PAGE, 2, low), (root + 2 * PAGE, 3, root + 4 * PAGE)]:\n        require(tables[str(table)][index] & ~0x60 == target | 7, \'hierarchy\')\n    for i in range(519):\n        table, index = (low, 503 + i) if i < 9 else (root + 4 * PAGE, i - 9)\n        expected = ((base + i * PAGE) | (1 << 63) | 7) if i < count else 0\n        require(tables[str(table)][index] & ~0x60 == expected, \'selected heap translations\')\n\n\ndef snapshot(value, stable=True):\n    allocator = value[\'allocator\']\n    require(len(allocator) == 16 and allocator[:2] == [1, 1] and 0 < allocator[3] <= 262144, \'allocator\')\n    require(value[\'details\'] == [0] * 4, \'resolve scratch\')\n    active = bank(value[\'active\'], value[\'state\'], value[\'tokens\'][:3], allocator)\n    inactive = bank(value[\'inactive\'], value[\'inactive_state\'], value[\'inactive\'][\'token\'], allocator)\n    prepared = bank(value[\'prepared\'], value[\'prepared_state\'], value[\'prepared\'][\'token\'], allocator)\n    candidate = owner(value[\'candidate\'], value[\'tokens\'][3:], allocator)\n    ids = value[\'ids\']\n    require(len(ids) == 7, \'MM identities\')\n    if ids[0] == 0:\n        require(ids == [0] * 7 and inactive is None and prepared is None, \'unbound identities\')\n    else:\n        require(0 < ids[0] <= 2147483647 and 0 < ids[1] < ids[6], \'active MM identity\')\n        if ids[3]:\n            require(0 < ids[3] <= 2147483647 and ids[3] != ids[0] and 1 in [ids[0], ids[3]], \'pair PIDs\')\n            require(0 < ids[4] < ids[6] and ids[4] != ids[1] and value[\'inactive_state\'][0] == 1, \'inactive MM identity\')\n        else:\n            require(ids[3:6] == [0] * 3 and value[\'inactive_state\'] == [0] * 4, \'empty inactive owner\')\n    owned = [o for o in [active, inactive, prepared, candidate] if o is not None]\n    for row in value[\'root_owners\']:\n        owned.append(owner(row, row[\'token\'], allocator, False))\n    require(any(o[\'span\'][0] == value[\'context\'][\'root\'] and o[\'count\'] == 5 and o[\'pins\'] == 1\n                for o in owned if o is not None), \'owned hierarchy\')\n    require(any(o[\'span\'][0] == value[\'context\'][\'low\'] and o[\'count\'] == 1 and o[\'pins\'] == 1\n                for o in owned if o is not None), \'owned low table\')\n    spans = list(value[\'kernel_spans\'])\n    identities = []\n    for allocation in owned:\n        a, b = allocation[\'span\']\n        require(all(b <= x or y <= a for x, y in spans), \'backing overlap\')\n        require(allocation[\'token\'][1] not in identities, \'aliased handle\')\n        identities.append(allocation[\'token\'][1])\n        spans.append([a, b])\n    if stable:\n        require(candidate is None and value[\'transition\'] == [0] * 3, \'incomplete transfer\')\n        mappings(value, value[\'state\'][2], value[\'state\'][3])\n    return dict(active=active, inactive=inactive, prepared=prepared, candidate=candidate)\n\n\ndef same_bank(a, b, name):\n    require(a[name] == b[name] and a[name + \'_state\'] == b[name + \'_state\'], \'changed retained \' + name)\n\n\ndef firmware_frames(evidence):\n    """All complete RAM pages, excluding every reservation/non-RAM overlap."""\n    ram=[];forbidden=list(evidence[\'reservations\'])\n    for base,length,kind in evidence[\'e820\']:\n        require(0<=base<base+length<=1<<64 and length>0 and kind>0, \'firmware interval\')\n        if kind==1:\n            require(base+length<=1<<30, \'firmware supported RAM domain\')\n            ram.append((base,base+length))\n        else:forbidden.append((base,base+length))\n    require(len(evidence[\'reservations\'])==2 and all(0<=a<b<=1<<30 for a,b in evidence[\'reservations\']), \'firmware reservations\')\n    frames=set()\n    for a,b in ram:\n        for frame in range((a+PAGE-1)//PAGE,b//PAGE):\n            if all((frame+1)*PAGE<=x or y<=frame*PAGE for x,y in forbidden):frames.add(frame)\n    return sorted(frames)\n\n\ndef physical_catalog(value):\n    """Independent whole-catalog/registry readback for the small-RAM cohort."""\n    allocator=value[\'allocator\'];n=allocator[3]\n    require(\'catalog\' in value and \'registry\' in value, \'missing complete physical catalog\')\n    cells,registry=value[\'catalog\'],value[\'registry\']\n    require(len(cells)==3*n and len(registry)==8*n, \'complete physical catalog/registry\')\n    physical=cells[2::3]\n    require(physical==sorted(set(physical)) and all(0<=p<1<<18 for p in physical), \'catalog physical identity\')\n    require(all(p>0 for p in cells[1::3]), \'catalog provenance\')\n    records={};free_records=0\n    for index in range(n):\n        r=registry[index*8:(index+1)*8]\n        if r==[0]*8:\n            free_records+=1;continue\n        require(r[0]==allocator[1]==1 and 0<r[1]<allocator[2] and r[7]==1, \'catalog live record\')\n        require(r[1] not in records and 0<=r[2]<r[2]+r[3]<=n and r[3]>0\n                and r[4]>0 and r[4]&(r[4]-1)==0 and r[5]>0, \'catalog record geometry\')\n        part=cells[r[2]*3:(r[2]+r[3])*3]\n        require(part[0::3]==[r[1]]*r[3] and part[1::3]==[r[5]]*r[3], \'catalog owned span\')\n        require(part[2]%r[4]==0 and part[2::3]==list(range(part[2],part[2]+r[3])), \'catalog contiguous record\')\n        records[r[1]]=(index,r)\n    for index in range(n):\n        identity=cells[index*3]\n        if identity:\n            require(identity in records, \'catalog cell lacks record\')\n            r=records[identity][1]\n            require(r[2]<=index<r[2]+r[3], \'catalog cell outside record\')\n    for owner in [value[k] for k in [\'active\',\'inactive\',\'prepared\',\'candidate\']]+value[\'root_owners\']:\n        if owner[\'token\']!=[0]*3:\n            _,identity,index=owner[\'token\'];r=owner[\'record\']\n            require(records.get(identity)==(index,r) and owner[\'cells\']==cells[r[2]*3:(r[2]+r[3])*3], \'catalog owner binding\')\n    free=largest=run=0;previous=None\n    for i in range(n):\n        identity,provenance,frame=cells[i*3:i*3+3]\n        if identity==0:\n            free+=1\n            run=run+1 if previous is not None and previous==(provenance,frame-1) else 1\n            largest=max(largest,run);previous=(provenance,frame)\n        else:\n            run=0;previous=None\n    return dict(frames=n,free=free,largest_run=largest,free_records=free_records)\n\n\ndef preparation_refusal(row):\n    before,after=row[\'before\'],row[\'after\']\n    require(row[\'operation\']==9 and row[\'result\']==0 and row[\'request\']==0, \'physical refusal result\')\n    require(before[\'ids\'][0]==before[\'context\'][\'pid\']==1 and before[\'ids\'][3:6]==[0]*3\n            and before[\'context\'][\'relationship\']==0, \'physical refusal source\')\n    require(before[\'state\'][2]>0, \'physical refusal nonempty request\')\n    for value in [before,after]:\n        require(value[\'prepared_state\']==[0]*7 and value[\'prepared_owner\']==[0]*3\n                and value[\'prepared\'][\'token\']==[0]*3, \'refusal retained preparation\')\n    for key in [\'allocator\',\'ids\',\'state\',\'active\',\'inactive\',\'inactive_state\',\'catalog\',\'registry\',\'tables\',\'identity_store\']:\n        require(before[key]==after[key], \'refusal changed \'+key)\n    catalog=physical_catalog(before);physical_catalog(after)\n    require(catalog[\'free_records\']>0 and before[\'allocator\'][2]<(1<<64)-1, \'refusal is not registry/identity exhaustion\')\n    require(catalog[\'largest_run\']<before[\'state\'][2], \'physical refusal has an eligible run\')\n    return catalog\n\n\ndef resize_refusal(row):\n    before,after=row[\'before\'],row[\'after\'];request=row[\'request\']\n    require(START<request<=START+519*PAGE and row[\'result\']==before[\'state\'][1], \'raw resize refusal\')\n    count=(request-START+PAGE-1)//PAGE\n    require(count!=before[\'state\'][2], \'resize refusal geometry\')\n    for key in [\'allocator\',\'ids\',\'state\',\'active\',\'inactive\',\'inactive_state\',\'catalog\',\'registry\',\'tables\',\'identity_store\']:\n        require(before[key]==after[key], \'resize refusal changed \'+key)\n    catalog=physical_catalog(before);physical_catalog(after)\n    require(catalog[\'free_records\']>0 and before[\'allocator\'][2]<(1<<64)-1, \'resize refusal metadata exhaustion\')\n    require(catalog[\'largest_run\']<count, \'resize refusal has eligible run\')\n    return catalog\n\n\ndef event(row):\n    before, after = row[\'before\'], row[\'after\']\n    first, last = snapshot(before), snapshot(after)\n    op, request = row[\'operation\'], row[\'request\']\n    for value in [before, after]:\n        require(value[\'cs\'] & 3 == 0 and value[\'flags\'] & 0x600 == 0, \'kernel critical state\')\n        require(value[\'cr0\'] & 0x80010001 == 0x80010001 and value[\'cr4\'] & 0x20, \'paging/write protection\')\n        require(value[\'cr4\'] & ((1 << 7) | (1 << 12) | (1 << 17)) == 0, \'selected paging mode\')\n        if op == 6:\n            require(value[\'context\'][\'state\'] == 2 and value[\'cr3\'] == value[\'context\'][\'bootstrap\'], \'detached cleanup root\')\n        else:\n            require(value[\'context\'][\'state\'] == 1 and value[\'cr3\'] == value[\'context\'][\'root\']\n                    and value[\'gs_base\'] == value[\'context\'][\'self\'] == value[\'context\'][\'address\'], \'actual live root/context\')\n    require(before[\'epoch\'] == after[\'epoch\'] and before[\'epoch\'][0] > 0, \'entry changed\')\n    numbers = {5: [12], 6: [60, 231], 7: [59], 9: [56, 57], 10: [56, 57],\n               11: [0, 1, 19, 20, 24, 61], 12: [60, 231], 13: [60, 231]}\n    require(op in numbers and before[\'epoch\'][1] in numbers[op], \'syscall identity\')\n    require(before[\'context\'][\'root\'] == after[\'context\'][\'root\'] and before[\'cr3\'] == after[\'cr3\'], \'root changed\')\n    require(before[\'tokens\'][3:] == after[\'tokens\'][3:] == [0] * 3, \'resize candidate retained\')\n    require(before[\'root_owners\'] == after[\'root_owners\'], \'root owners changed\')\n    if op == 9:\n        require(row[\'result\'] in [0,1] and request == 0 and before[\'ids\'][0] == 1, \'creation preparation\')\n        require(before[\'state\'] == after[\'state\'] and before[\'active\'] == after[\'active\'] and before[\'ids\'] == after[\'ids\'], \'changed source during preparation\')\n        if row[\'result\']==0:\n            preparation_refusal(row)\n        else:\n            require(after[\'prepared_state\'][:3] == before[\'state\'][:3], \'prepared byte geometry\')\n            require(after[\'prepared_state\'][4:] == [before[\'context\'][\'root\'], before[\'context\'][\'address\'], before[\'epoch\'][0]], \'prepared entry receipt\')\n            require(after[\'prepared_owner\'] == before[\'ids\'][:3], \'prepared source owner\')\n            if first[\'active\']:\n                require(last[\'prepared\'][\'data\'] == first[\'active\'][\'data\'], \'incomplete fork copy\')\n            require(after[\'allocator\'][2] == before[\'allocator\'][2] + int(before[\'state\'][2] > 0), \'preparation issuance\')\n    elif op == 10:\n        require(row[\'result\'] == 1 and request >= 2 and before[\'prepared_owner\'] == before[\'ids\'][:3], \'creation commit\')\n        require(after[\'active\'] == before[\'prepared\'] and after[\'state\'] == before[\'prepared_state\'][:4], \'child adoption\')\n        require(after[\'inactive\'] == before[\'active\'] and after[\'inactive_state\'] == before[\'state\'], \'parent retention\')\n        require(after[\'ids\'] == [request, before[\'ids\'][6], before[\'ids\'][2]] + before[\'ids\'][:3] + [before[\'ids\'][6] + 1], \'child MM identity\')\n    elif op == 11:\n        require(row[\'result\'] == 1 and request == 0, \'handoff result\')\n        require(after[\'active\'] == before[\'inactive\'] and after[\'state\'] == before[\'inactive_state\'], \'target handoff\')\n        require(after[\'inactive\'] == before[\'active\'] and after[\'inactive_state\'] == before[\'state\'], \'source handoff\')\n        require(after[\'ids\'] == before[\'ids\'][3:6] + before[\'ids\'][:3] + before[\'ids\'][6:], \'handoff identities\')\n    elif op == 12:\n        require(row[\'result\'] == 1 and before[\'ids\'][0] >= 2 and before[\'ids\'][3] == 1, \'child exit\')\n        require(after[\'active\'] == before[\'inactive\'] and after[\'state\'] == before[\'inactive_state\'], \'parent restoration\')\n        require(after[\'ids\'] == before[\'ids\'][3:6] + [0] * 3 + before[\'ids\'][6:], \'retired child MM identity\')\n    elif op == 13:\n        require(row[\'result\'] == 1 and before[\'ids\'][0] == 1, \'outer cancellation\')\n        require(after[\'active\'] == before[\'active\'] and after[\'state\'] == before[\'state\'], \'active cancellation effect\')\n        require(after[\'ids\'] == before[\'ids\'][:3] + [0] * 3 + before[\'ids\'][6:], \'inactive cancellation identity\')\n    elif op == 5:\n        same_bank(before, after, \'inactive\')\n        count = before[\'state\'][2]\n        wanted = (request - START + PAGE - 1) // PAGE if START <= request <= START + 519 * PAGE else count\n        if request == 0 or wanted == count:\n            require(after[\'allocator\'][2] == before[\'allocator\'][2] and after[\'active\'] == before[\'active\'], \'query/within-page allocation\')\n        elif START<request<=START+519*PAGE and row[\'result\']==before[\'state\'][1]:\n            resize_refusal(row)\n    elif op == 7:\n        same_bank(before, after, \'inactive\')\n        require(after[\'state\'] == [0] * 4 and after[\'tokens\'] == [0] * 6, \'exec heap retirement\')\n        require(after[\'ids\'] == [before[\'ids\'][0], before[\'ids\'][6], before[\'ids\'][2] + 1] + before[\'ids\'][3:6] + [before[\'ids\'][6] + 1], \'exec MM generation\')\n    elif op == 6:\n        require(after[\'state\'] == [0] * 4 and after[\'tokens\'] == [0] * 6 and after[\'ids\'] == [0] * 7, \'outer retirement\')\n    else:\n        require(False, \'unknown MM operation\')\n    if op != 9:\n        require(after[\'prepared_state\'] == [0] * 7 and after[\'prepared_owner\'] == [0] * 3 and after[\'prepared\'][\'token\'] == [0] * 3, \'prepared owner retained\')\n    retained = [after[name][\'token\'] for name in [\'active\', \'inactive\', \'prepared\', \'candidate\']]\n    expected = {tuple(before[name][\'token\']): before[name] for name in\n                [\'active\', \'inactive\', \'prepared\', \'candidate\']\n                if before[name][\'token\'] != [0] * 3 and before[name][\'token\'] not in retained}\n    actual = [tuple(retired[\'token\']) for retired in row[\'retired\']]\n    require(len(actual) == len(set(actual)) and set(actual) == set(expected), \'complete retirement set\')\n    for retired in row[\'retired\']:\n        original = expected[tuple(retired[\'token\'])]\n        count = original[\'record\'][3]\n        require(retired[\'count\'] == count and len(bytes.fromhex(retired[\'bytes\'])) == count * PAGE\n                and len(retired[\'cells\']) == count * 3, \'complete retirement geometry\')\n        require(retired[\'record\'] == [0] * 8 and not any(bytes.fromhex(retired[\'bytes\'])), \'retired backing not consumed/zero\')\n        require(retired[\'cells\'][0::3] == [0] * retired[\'count\'], \'retired cells still owned\')\n        require(retired[\'cells\'][2::3] == original[\'cells\'][2::3], \'retired physical cell identity\')\n    return dict(passed=True, operation=op, active_pid=after[\'ids\'][0],\n                active_pages=after[\'state\'][2], inactive_pages=after[\'inactive_state\'][2])\n',model)

import gdb,hashlib,json,struct,traceback
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
def address(name):return int(gdb.parse_and_eval("(unsigned long long)&'"+name+"'"))
def memory(p,n):return bytes(gdb.selected_inferior().read_memory(p,n)) if n else b''
def words(p,n):return list(struct.unpack('<'+'Q'*n,memory(p,n*8)))
def word(p):return words(p,1)[0]
context=address('topal_bootstrap_storage')+512
observed=dict(passed=False,cases=[],events=[],child_exec_entries=[],replacement_entries=[],terminal=[],refusals=[],child_departures=[])
child_exec=component['mode']=='process-mm-exec'
cancel_config=component.get('cancellation')
allocation_config=component.get('allocation_profile')
geometry_config=component.get('geometry_profile')
relationship_config=component.get('relationship_profile')
observed['cancellation']=cancel_config
observed['allocation_profile']=allocation_config
observed['geometry_profile']=geometry_config
observed['relationship_profile']=relationship_config
pending=case=None
refusal_attempt=None
returns={}
callee=['rbx','rbp','r12','r13','r14','r15']

def allocation(pointer,data=True):
    token=words(pointer,3)
    if token==[0]*3:return dict(token=token,record=[],cells=[],bytes='')
    allocator=words(address('topal_x86_frame_context_v1'),16)
    assert token[0]==1 and 0<token[1]<allocator[2] and token[2]<allocator[3]
    record=words(allocator[6]+token[2]*64,8)
    assert record[:2]==token[:2] and record[7]==1 and 0<record[3]<=allocator[3]
    assert 0<=record[2]<record[2]+record[3]<=allocator[3]
    cells=words(allocator[4]+128+record[2]*24,record[3]*3)
    return dict(token=token,record=record,cells=cells,
        bytes=memory(cells[2]*4096,record[3]*4096).hex() if data else '')

def capture():
    root,low,table=word(context+24),word(context+112),word(context+928)
    tokens=address('topal_x86_frame_mm_tokens_v1')
    root_tokens=address('topal_x86_frame_root_tokens_v1')
    allocator=words(address('topal_x86_frame_context_v1'),16)
    result=dict(allocator=allocator,
        ids=words(address('topal_x86_process_mm_ids_v1'),7),
        state=words(address('topal_x86_frame_mm_state_v1'),4),tokens=words(tokens,6),
        inactive_state=words(address('topal_x86_process_mm_inactive_state_v1'),4),
        prepared_state=words(address('topal_x86_process_mm_prepared_state_v1'),7),
        prepared_owner=words(address('topal_x86_process_mm_prepared_owner_v1'),3),
        transition=words(address('topal_x86_process_mm_transition_v1'),3),
        active=allocation(tokens),candidate=allocation(tokens+24),
        inactive=allocation(address('topal_x86_process_mm_inactive_token_v1')),
        prepared=allocation(address('topal_x86_process_mm_prepared_token_v1')),
        root_owners=[allocation(root_tokens+i*24,False) for i in range(token_bytes//24) if words(root_tokens+i*24,3)!=[0]*3],
        details=words(address('topal_x86_frame_details_v1'),4),
        epoch=words(address('topal_x86_frame_mm_epoch_v1'),2),
        context=dict(address=context,state=word(context),root=root,low=low,heap=word(context+120),
            self=word(context+256),bootstrap=word(context+16),user_arg=word(context+312),phase=word(context+104),
            tls=word(context+128),registered_tid=word(context+152),robust=word(context+160),
            table=table,pid=word(table+56),child=word(table+0x2010),relationship=word(table+0x2000),
            policy_store=word(context+1000),
            saved_pid=word(table+0x3038),saved_heap=word(table+0x2178)),
        inactive_wait=[word(table+0x2060),word(table+0x2078)],
        tables={str(a):words(a,512) for a in [root,root+4096,root+8192,root+12288,root+16384,low]},
        kernel_spans=kernel_spans,cr3=reg('cr3'),cr0=reg('cr0'),cr4=reg('cr4'),cs=reg('cs'),flags=reg('eflags'),gs_base=reg('gs_base'),fs_base=reg('fs_base'),
        thread=list(gdb.selected_thread().ptid))
    if allocation_config is not None:
        assert 0<allocator[3]<=4096, 'observer catalog bound for the small-RAM cohort'
        result.update(catalog=words(allocator[4]+128,allocator[3]*3),
                      registry=words(allocator[6],allocator[3]*8))
    identity_config=allocation_config or geometry_config or relationship_config
    if identity_config is not None:
        policy=result['context']['policy_store']
        result['identity_store']=memory(policy,identity_config['identity_storage_bytes']).hex() if policy else ''
    return result

def save():
    observed['pending']=pending
    observed['active_case']=case
    observed['refusal_pending']=refusal_attempt
    with open(observation_path,'w') as f:json.dump(observed,f)

class Checked(gdb.Breakpoint):
    def stop(self):
        try:return self.observe()
        except Exception:
            traceback.print_exc()
            observed['failure']=traceback.format_exc()
            save()
            return True

class Gateway(Checked):
    def __init__(self,symbol,enter):
        self.enter=enter
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        global pending
        if self.enter:
            op=reg('rdi')
            if allocation_config is not None and op==0:
                assert 'firmware' not in observed and reg('cs')&3==0
                boot=reg('rsi');assert 0<boot<=0xfff000
                n=memory(boot+488,1)[0];assert 0<n<=128
                resource=int.from_bytes(memory(boot+536,4),'little')
                size=int.from_bytes(memory(boot+540,4),'little')
                observed['firmware']=dict(boot=boot,
                    e820=[words(boot+720+20*i,2)+[int.from_bytes(memory(boot+736+20*i,4),'little')] for i in range(n)],
                    raw_map=memory(boot+720,n*20).hex(),
                    reservations=[[0,address('topal_x86_kernel_reservation_end_v1')],[resource,resource+size]])
                save()
            if op not in [5,6,7,9,10,11,12,13]:return False
            assert pending is None
            pending=dict(operation=op,request=reg('rsi'),before=capture(),sp=reg('rsp'),
                callee={r:reg(r) for r in callee},retired=[])
            model['snapshot'](pending['before'])
        elif pending is not None:
            row=pending
            assert reg('rsp')==row['sp'] and {r:reg(r) for r in callee}==row['callee']
            assert all(reg(r)==0 for r in ['rcx','rdx','rsi','rdi','r8','r9','r10','r11'])
            after=capture()
            retained=[after[k]['token'] for k in ['active','inactive','prepared','candidate']]
            for bank in ['active','inactive','prepared','candidate']:
                old=row['before'][bank]
                if old['token']!=[0]*3 and old['token'] not in retained:
                    a=after['allocator'];r=old['record'];count=r[3]
                    row['retired'].append(dict(token=old['token'],count=count,
                        record=words(a[6]+old['token'][2]*64,8),cells=words(a[4]+128+r[2]*24,count*3),
                        bytes=memory(old['cells'][2]*4096,count*4096).hex()))
            row.update(after=after,result=reg('rax'))
            row['comparison']=model['event'](row)
            observed['events'].append(row)
            pending=None
            save()
        return False

class CaseReturned(Checked):
    def observe(self):
        global case
        self.enabled=False
        assert case is not None and pending is None and reg('cs')&3==3
        assert cancel_config is allocation_config is geometry_config is relationship_config is None, ('terminal case unexpectedly returned',reg('rax'))
        if reg('rax')!=0:
            value=capture()
            raise AssertionError(('source case failed',reg('rax'),value['context'],value['ids']))
        assert reg('rsp')==case['sp']+8 and {r:reg(r) for r in callee}==case['callee']
        after=capture();model['snapshot'](after)
        case['returned']=dict(result=reg('rax'),sp=reg('rsp'),callee={r:reg(r) for r in callee},cs=reg('cs'))
        assert after['ids'][:3]==case['before']['ids'][:3] and after['ids'][3:6]==[0]*3
        assert after['ids'][6]==case['before']['ids'][6]+(2 if child_exec else 1)
        assert after['state'][1:3]==case['before']['state'][1:3]
        assert hashlib.sha256(bytes.fromhex(after['active']['bytes'])).hexdigest()==case['prefix']
        case['after']=after
        observed['cases'].append(case);case=None
        print('PROCESS_MM_CASE_PASS',len(observed['cases']),flush=True)
        save()
        return False

class CaseEntered(Checked):
    def observe(self):
        global case
        assert case is None and pending is None and reg('cs')&3==3
        before=capture();model['snapshot'](before)
        if allocation_config is not None:
            firmware=observed['firmware']
            assert memory(firmware['boot']+720,len(firmware['e820'])*20).hex()==firmware['raw_map']
            assert before['catalog'][2::3]==model['firmware_frames'](firmware)
        assert before['ids'][0]==1 and before['state'][1:3]==[0x619000,34]
        case=dict(before=before,sp=reg('rsp'),callee={r:reg(r) for r in callee},
            prefix=hashlib.sha256(bytes.fromhex(before['active']['bytes'])).hexdigest())
        site=word(reg('rsp'))
        if site not in returns:returns[site]=CaseReturned('*'+hex(site),internal=True)
        returns[site].enabled=True
        return False

class ImageEntered(Checked):
    def observe(self):
        assert reg('cs')&3==3 and pending is None
        value=capture()
        if ((cancel_config is not None and cancel_config['early']) or (relationship_config is not None and relationship_config['early']) or allocation_config is not None or geometry_config is not None) and value['ids'][0]==1:
            assert value['ids'][2]==1 and value['context']['phase']==0 and value['state']==[0]*4
            assert value['fs_base']==value['context']['tls']==0
            observed['replacement_entries'].append(dict(snapshot=value,initial_sp=reg('rsp')))
            save()
        if value['ids'][0]<2:return False
        assert child_exec and case is not None
        model['snapshot'](value)
        assert value['state']==[0]*4 and value['tokens']==[0]*6
        assert value['fs_base']==value['context']['tls']==0
        assert value['context']['registered_tid']==value['context']['robust']==0
        assert value['ids'][3:6]==case['before']['ids'][:3]
        assert value['ids'][2]==case['before']['ids'][2]+1
        assert value['inactive_state'][2]==67
        last=observed['events'][-1]
        assert last['operation']==7 and last['before']['ids'][0]==value['ids'][0]
        assert last['after']['ids']==value['ids']
        assert last['before']['inactive']==last['after']['inactive']==value['inactive']
        assert word(reg('rsp'))==2
        observed['child_exec_entries'].append(dict(snapshot=value,initial_sp=reg('rsp')))
        save()
        return False

class RefusalReturned(Checked):
    def observe(self):
        global refusal_attempt
        self.enabled=False
        assert refusal_attempt is not None and pending is None and reg('cs')&3==3
        assert reg('rax')==(1<<64)-12
        assert reg('rsp')==refusal_attempt['sp']+8
        assert {r:reg(r) for r in callee}==refusal_attempt['callee']
        assert reg('rip')==refusal_attempt['return_pc']
        after=capture();model['snapshot'](after)
        raw=memory(after['context']['table'],allocation_config['process_storage_bytes']).hex()
        before=refusal_attempt['before']
        for key in ['allocator','ids','state','active','inactive','inactive_state','tables','catalog','registry','identity_store']:
            assert after[key]==before[key], ('fork refusal changed',key)
        assert raw==refusal_attempt['storage']
        assert after['epoch']==[before['epoch'][0]+1,57]
        refusal_attempt.update(after=after,after_storage=raw,result=reg('rax'),returned_sp=reg('rsp'),
            returned_pc=reg('rip'),returned_callee={r:reg(r) for r in callee})
        observed['refusals'].append(refusal_attempt);refusal_attempt=None
        save()
        return False

class UserFork(Checked):
    def observe(self):
        global refusal_attempt
        if reg('rdi')!=57:return False
        before=capture()
        if before['state'][2]!=519:return False
        assert allocation_config is not None and refusal_attempt is None and observed['refusals']==[]
        assert reg('cs')&3==3 and before['ids'][0]==1
        model['snapshot'](before)
        refusal_attempt=dict(before=before,sp=reg('rsp'),callee={r:reg(r) for r in callee},return_pc=word(reg('rsp')),
            storage=memory(before['context']['table'],allocation_config['process_storage_bytes']).hex())
        RefusalReturned('*'+hex(word(reg('rsp'))),internal=True)
        save()
        return False

class AllocationTerminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert allocation_config is not None and pending is refusal_attempt is None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids']==[1,2,1,0,0,0,5]
        assert value['epoch'][1]==231 and value['context']['user_arg']==0
        assert value['state']==[1,0x5f7000,0,0] and value['active']['token']==[0]*3
        raw=memory(value['context']['table'],allocation_config['process_storage_bytes'])
        assert len(observed['terminal'])==int(self.retired)
        if self.retired:assert raw==bytes(len(raw))
        else:assert value['context']['pid']==1 and value['context']['relationship']==0
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class Terminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert cancel_config is not None and pending is None and case is not None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids'][0]==1
        assert value['epoch'][1]==cancel_config['syscall']
        assert value['context']['user_arg']==cancel_config['status']
        assert value['state'][2]==35
        raw=memory(value['context']['table'],cancel_config['process_storage_bytes'])
        if self.retired:
            assert value['ids'][3:6]==[0]*3 and value['inactive_state']==[0]*4
            assert raw==bytes(len(raw)) and value['inactive_wait']==[0,0]
            assert len(observed['terminal'])==1
            assert value['active']==observed['terminal'][0]['snapshot']['active']
        else:
            assert observed['terminal']==[]
            assert value['ids'][3]>=2 and value['inactive_state'][2]==101
            assert value['inactive_wait'][0]==(3 if cancel_config.get('writer',False) else 2) and value['inactive_wait'][1]>0
            assert value['context']['phase']==(1 if cancel_config['early'] else 32)
            child=bytes.fromhex(value['inactive']['bytes'])
            assert [child[i] for i in [34*4096+128,66*4096+64,101*4096-1]]==[0xc1,0xc2,0xc7]
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class GeometryTerminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert geometry_config is not None and pending is None and case is not None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids']==[1,2,1,0,0,0,4]
        assert value['epoch'][1]==231 and value['context']['user_arg']==0
        assert value['state'][:3]==[1,0x5f7000+518*4096-7,518]
        raw=memory(value['context']['table'],geometry_config['process_storage_bytes'])
        assert len(observed['terminal'])==int(self.retired)
        if self.retired:assert raw==bytes(len(raw))
        else:assert value['context']['pid']==1 and value['context']['relationship']==0
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class ChildDeparture(Checked):
    def observe(self):
        assert relationship_config is not None
        number=60 if relationship_config['zombie'] else 24
        if reg('rdi')!=number:return False
        value=capture()
        if value['ids'][0]==1:return False
        assert value['ids'][0]==2 and reg('cs')&3==3 and pending is None
        assert observed['child_departures']==[]
        model['snapshot'](value)
        raw=memory(value['context']['table'],relationship_config['process_storage_bytes'])
        observed['child_departures'].append(dict(snapshot=value,syscall=reg('rdi'),argument=reg('rsi'),storage=raw.hex()))
        save()
        return False

class RelationshipTerminal(Checked):
    def __init__(self,symbol,retired):
        self.retired=retired
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        assert relationship_config is not None and pending is None and case is not None
        value=capture();model['snapshot'](value)
        assert reg('cs')&3==0 and value['ids'][0]==1 and value['state'][2]==35
        assert value['epoch'][1]==relationship_config['syscall'] and value['context']['user_arg']==relationship_config['status']
        assert value['inactive_wait']==[0,0] and value['context']['phase']==(1 if relationship_config['early'] else 32)
        raw=memory(value['context']['table'],relationship_config['process_storage_bytes'])
        assert len(observed['terminal'])==int(self.retired)
        if self.retired:
            assert raw==bytes(len(raw)) and value['ids'][3:6]==[0]*3
        else:
            assert value['context']['pid']==1 and value['context']['relationship']==(2 if relationship_config['zombie'] else 1)
            if relationship_config['zombie']:assert value['ids'][3:6]==[0]*3 and value['inactive_state']==[0]*4
            else:assert value['ids'][3]==2 and value['inactive_state'][2]==101
        observed['terminal'].append(dict(retired=self.retired,snapshot=value,storage=raw.hex()))
        save()
        return False

class Halt(Checked):
    def observe(self):
        value=capture()
        observed['halt']=dict(snapshot=value,registers={r:reg(r) for r in
            ['rax','rcx','rdx','rsi','rdi','r8','r9','r10','r11','r12','r13','r14','r15','rsp','rip']},
            stack=words(reg('rsp'),16),context_words=words(context,120))
        raise AssertionError(('provider invariant halt',value['context'],value['ids']))

class Complete(Checked):
    def observe(self):
        assert pending is None
        ops=[r['operation'] for r in observed['events']]
        # Four new large-heap cases plus the unchanged four child/clone cases
        # in the surrounding full ABI witness all use actual MM owners.
        if relationship_config is not None:
            zombie=relationship_config['zombie']
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,7,9,10,11,12,13]]==[1,int(relationship_config['early']),1,1,int(not zombie),int(zombie),1]
            assert len(observed['child_departures'])==1
            assert len(observed['replacement_entries'])==int(relationship_config['early'])
            identity=memory(case['before']['context']['policy_store'],relationship_config['identity_storage_bytes'])
            assert identity==bytes(len(identity))
            observed['final_identity_store']=identity.hex()
        elif geometry_config is not None:
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,7,9,10,11,12,13]]==[1,1,1,1,4,1,1]
            prep=[r for r in observed['events'] if r['operation']==9]
            assert [(r['before']['state'][2],r['result'],r['before']['epoch'][1]) for r in prep]==[(519,1,geometry_config['syscall'])]
            assert len(observed['replacement_entries'])==1 and observed['refusals']==[]
            identity=memory(case['before']['context']['policy_store'],geometry_config['identity_storage_bytes'])
            assert identity==bytes(len(identity))
            observed['final_identity_store']=identity.hex()
        elif allocation_config is not None:
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,7,9,10,11,12,13]]==[1,1,3,2,0,2,1]
            prep=[r for r in observed['events'] if r['operation']==9]
            assert [(r['before']['state'][2],r['result']) for r in prep]==[(519,0),(1,1),(0,1)]
            assert len(observed['replacement_entries'])==len(observed['refusals'])==1
            assert refusal_attempt is None
            identity=memory(case['before']['context']['policy_store'],allocation_config['identity_storage_bytes'])
            assert identity==bytes(len(identity))
            observed['final_identity_store']=identity.hex()
        elif cancel_config is not None:
            assert case is not None and observed['cases']==[] and len(observed['terminal'])==2
            assert [ops.count(n) for n in [6,9,10,11,12,13]]==[1,1,1,1,0,1]
            assert ops.count(7)==int(cancel_config['early'])
            assert len(observed['replacement_entries'])==int(cancel_config['early'])
        else:
            assert case is None and len(observed['cases'])==4
            assert [r['before']['ids'][2] for r in observed['cases']]==[0,1,2,3]
            assert [ops.count(n) for n in [9,10,11,12]]==[8,8,8,8]
            preparations=[r['before']['state'][2] for r in observed['events'] if r['operation']==9]
            assert sorted(preparations)==[34]*4+[67]*4
            assert ops.count(7)==(7 if child_exec else 3)
            assert len(observed['child_exec_entries'])==(4 if child_exec else 0)
        assert words(address('topal_x86_frame_mm_tokens_v1'),6)==[0]*6
        assert words(address('topal_x86_frame_mm_state_v1'),4)==[0]*4
        observed['final']={}
        for suffix,count in [('ids',7),('inactive_token',3),('inactive_state',4),('prepared_token',3),
                             ('prepared_state',7),('prepared_owner',3),('transition',3)]:
            actual=words(address('topal_x86_process_mm_'+suffix+'_v1'),count)
            assert actual==[0]*count
            observed['final'][suffix]=actual
        observed['passed']=True
        save()
        return True

publication_tables={}
exec('"""Saved-data checks for the actual local heap publication/invalidation order.\n\nTOPAL-SYSTEMS-USER-EXTENT-001. Numeric records describe observations; they do not\ncreate mapping authority, inspect a TLB or establish AP/DMA/async exclusion.\n"""\nPAGE=4096\nHEAP=0x5f7000\nLEAF=(1<<63)|7\n\n\ndef controls(snapshot):\n    assert snapshot[\'cr0\']&0x80010001==0x80010001\n    assert snapshot[\'cr4\']&0x20 and snapshot[\'cr4\']&((1<<7)|(1<<12)|(1<<17))==0\n    assert snapshot[\'cs\']&3==0 and snapshot[\'flags\']&0x600==0\n    return tuple(snapshot[k] for k in [\'cr0\',\'cr3\',\'cr4\',\'cs\'])\n\n\ndef check_switch(record):\n    before,after=record[\'before\'],record[\'after\']\n    first,last=controls(before),controls(after)\n    ctx=before[\'context\']\n    assert ctx==after[\'context\'] and ctx[\'state\']==1\n    assert before[\'thread\']==after[\'thread\']\n    assert all(0<ctx[k]<1<<30 and ctx[k]%PAGE==0 for k in [\'root\',\'bootstrap\'])\n    assert ctx[\'root\']!=ctx[\'bootstrap\']\n    assert first[1]==ctx[\'root\'] and last[1]==ctx[\'bootstrap\']\n    assert first[0]==last[0] and first[2:]==last[2:]\n    return dict(passed=True,target_root=ctx[\'root\'],bootstrap_root=ctx[\'bootstrap\'],\n        scope=\'Observed local CR3 replacement with PCID/global paging disabled; no other CPU or continuous-mode proof\')\n\n\ndef mode(snapshot,detachment=None):\n    current=controls(snapshot)\n    ctx=snapshot[\'context\']\n    assert ctx[\'root\']%PAGE==0\n    if snapshot[\'cr3\']==ctx[\'root\']:\n        assert ctx[\'state\']==1 and detachment is None\n    else:\n        assert detachment is not None,\'detached root requires its observed flushing handoff\'\n        check_switch(detachment)\n        after=detachment[\'after\']\n        assert ctx[\'state\']==2 and snapshot[\'cr3\']==ctx[\'bootstrap\']\n        assert {k:v for k,v in ctx.items() if k!=\'state\'}=={k:v for k,v in after[\'context\'].items() if k!=\'state\'}\n        assert current==controls(after) and snapshot[\'thread\']==after[\'thread\']\n    return current\n\n\ndef slot(snapshot,index):\n    assert 0<=index<519\n    ctx=snapshot[\'context\']\n    return (str(ctx[\'low\']),503+index) if index<9 else (str(ctx[\'root\']+16384),index-9)\n\n\ndef published(before,after,old,new,base,detachment=None):\n    assert 0<=old<=519 and 0<=new<=519 and old!=new\n    assert before[\'state\'][2]==old\n    assert base%PAGE==0 and (base>0 if new else base==0)\n    assert 0<=base<=base+new*PAGE<=1<<30\n    if detachment is not None:assert old>0 and new==0,\'detached publication must revoke the whole heap\'\n    assert mode(before,detachment)==mode(after,detachment)\n    assert before[\'thread\']==after[\'thread\'] and before[\'context\']==after[\'context\']\n    assert before[\'state\']==after[\'state\'] and before[\'tokens\']==after[\'tokens\']\n    root=before[\'context\'][\'root\']\n    expected={str(t) for t in [root,root+PAGE,root+2*PAGE,root+3*PAGE,root+4*PAGE,before[\'context\'][\'low\']]}\n    assert set(before[\'tables\'])==set(after[\'tables\'])==expected\n    selected={slot(before,i):((base+i*PAGE)|LEAF if i<new else 0) for i in range(max(old,new))}\n    for table,words in before[\'tables\'].items():\n        actual=after[\'tables\'][table]\n        assert len(words)==len(actual)==512\n        for index,(a,b) in enumerate(zip(words,actual)):\n            assert type(a) is int and type(b) is int and 0<=a<1<<64 and 0<=b<1<<64\n            if (table,index) in selected:\n                assert b&~0x60==selected[(table,index)],\'published heap leaf differs\'\n            else:\n                assert a&~0x60==b&~0x60 and (a|b)==b,\'unrelated translation changed\'\n    for i in range(519):\n        table,index=slot(before,i)\n        old_expected=((before[\'state\'][3]+i*PAGE)|LEAF) if i<old else 0\n        assert before[\'tables\'][table][index]&~0x60==old_expected,\'old heap leaf differs\'\n    return max(old,new)\n\n\ndef check(record):\n    old,new,base=record[\'old_count\'],record[\'new_count\'],record[\'new_base\']\n    detachment=record.get(\'detachment\')\n    if detachment is not None:assert record[\'operation\']==6\n    count=published(record[\'before\'],record[\'stored\'],old,new,base,detachment)\n    assert record[\'published_before_invalidations\'],\'missing publication barrier observation\'\n    assert len(record[\'invalidations\'])==count,\'incomplete invalidation interval\'\n    for index,event in enumerate(record[\'invalidations\']):\n        assert event[\'index\']==index and event[\'address\']==HEAP+index*PAGE,\'wrong invalidation page/order\'\n        assert event[\'thread\']==record[\'before\'][\'thread\'],\'local invalidation changed CPU\'\n    assert record[\'after\'][\'tables\']==record[\'stored\'][\'tables\'],\'translations changed during invalidation\'\n    assert mode(record[\'after\'],detachment)==mode(record[\'before\'],detachment)\n    assert record[\'after\'][\'thread\']==record[\'before\'][\'thread\']\n    assert record[\'after\'][\'context\']==record[\'before\'][\'context\']\n    assert record[\'after\'][\'state\']==record[\'before\'][\'state\']\n    assert record[\'after\'][\'tokens\']==record[\'before\'][\'tokens\']\n    assert record[\'return_stack\']==record[\'entry_stack\'] and record[\'return_address\']==record[\'entry_return_address\']\n    assert record[\'final_barrier_observed\'],\'missing final publication barrier\'\n    return dict(passed=True,pages_invalidated=count,\n        scope=\'Recorded active heap publication or whole detached cleanup bound to its observed flushing CR3 handoff, plus current-context post-INVLPG boundaries and final barrier. Not TLB introspection, continuous mode, AP/DMA/async or general stable ownership qualification\')\n',publication_tables)
publication_model=dict(owner=model['owner'],require=model['require'])
publication_model.update({key:publication_tables[key] for key in ['HEAP','LEAF','PAGE','mode','slot']})
exec('"""Saved process-MM publication checks, including equal-size owner changes.\n\nTOPAL-SYSTEMS-PROCESS-MM-001. Records do not create ownership, inspect hardware\nTLBs or prove unobserved mapping writers, continuous mode or AP/DMA exclusion.\n"""\nfrom pathlib import Path\nimport sys\n\nif \'owner\' not in globals():\n    from process_native import owner, require\nif \'slot\' not in globals():\n    sys.path.insert(0,str(Path(__file__).resolve().parents[3]/\'linux-kernel/tools/user-memory\'))\n    from translation_publication import HEAP, LEAF, PAGE, mode, slot\n\n\ndef bank(snapshot,name,state_name):\n    state=snapshot[state_name]\n    allocation=owner(snapshot[name],snapshot[name][\'token\'],snapshot[\'allocator\'],False)\n    require(len(state) in [4,7], \'publication bank width\')\n    if state==[0]*len(state):\n        require(allocation is None, \'publication owner without bank\')\n        return None\n    require(state[0]==1 and HEAP<=state[1]<=HEAP+519*PAGE\n            and state[2]==(state[1]-HEAP+PAGE-1)//PAGE, \'publication byte break\')\n    if state[2]:\n        require(allocation is not None and allocation[\'count\']==state[2]\n                and allocation[\'span\'][0]==state[3] and allocation[\'pins\']==1\n                and allocation[\'record\'][4]==1, \'publication bank backing/pin\')\n    else:require(allocation is None and state[3]==0, \'empty publication bank\')\n    return allocation\n\n\ndef owners(snapshot):\n    allocator=snapshot[\'allocator\']\n    require(len(allocator)==16 and allocator[:2]==[1,1], \'publication allocator identity\')\n    values={name:bank(snapshot,name,state) for name,state in [\n        (\'active\',\'state\'),(\'inactive\',\'inactive_state\'),(\'prepared\',\'prepared_state\')]}\n    values[\'candidate\']=owner(snapshot[\'candidate\'],snapshot[\'tokens\'][3:],allocator,False)\n    require(snapshot[\'tokens\'][:3]==snapshot[\'active\'][\'token\'], \'publication active token\')\n    roots=[owner(row,row[\'token\'],allocator,False) for row in snapshot[\'root_owners\']]\n    require(all(row is not None for row in roots), \'publication retained root allocation\')\n    require(any(row[\'span\'][0]==snapshot[\'context\'][\'root\'] and row[\'count\']==5 and row[\'pins\']==1 for row in roots)\n            and any(row[\'span\'][0]==snapshot[\'context\'][\'low\'] and row[\'count\']==1 and row[\'pins\']==1 for row in roots),\n            \'publication owned translation storage\')\n    spans=list(snapshot[\'kernel_spans\']);identities=set()\n    for allocation in list(values.values())+roots:\n        if allocation is None:continue\n        a,b=allocation[\'span\'];identity=tuple(allocation[\'token\'][:2])\n        require(identity not in identities and all(b<=x or y<=a for x,y in spans),\n                \'publication backing alias\')\n        spans.append([a,b]);identities.add(identity)\n    return values\n\n\ndef target(record,values):\n    before=record[\'before\'];operation=record[\'operation\']\n    ids=before[\'ids\']\n    require(len(ids)==7 and ids[0]>0 and 0<ids[1]<ids[6], \'publication active MM identity\')\n    if operation==5:return values[\'candidate\']\n    if operation in [6,7]:return None\n    if operation==10:\n        state=before[\'prepared_state\']\n        require(state[0]==1 and before[\'prepared_owner\']==ids[:3]\n                and state[4:]==[before[\'context\'][\'root\'],before[\'context\'][\'address\'],before[\'epoch\'][0]],\n                \'publication prepared receipt\')\n        require(ids[0]==1 and ids[3:6]==[0]*3 and 2<=before[\'transition\'][0]<=2147483647\n                and before[\'transition\'][1]!=ids[1] and 0<before[\'transition\'][1]+1==ids[6]\n                and before[\'transition\'][2]==ids[2], \'publication creation identity\')\n        return values[\'prepared\']\n    require(operation in [11,12], \'operation cannot publish process heap\')\n    require(ids[3]>0 and ids[3]!=ids[0] and 0<ids[4]<ids[6] and ids[4]!=ids[1]\n            and before[\'inactive_state\'][0]==1, \'publication inactive MM identity\')\n    if operation==12:require(ids[0]>=2 and ids[3]==1, \'publication child-to-parent return\')\n    return values[\'inactive\']\n\n\ndef check(record):\n    before,stored,after=[record[key] for key in [\'before\',\'stored\',\'after\']]\n    old,new,base=[record[key] for key in [\'old_count\',\'new_count\',\'new_base\']]\n    detached=record.get(\'detachment\')\n    require(0<=old<=519 and 0<=new<=519 and old==before[\'state\'][2], \'publication page geometry\')\n    require(detached is None or record[\'operation\']==6, \'publication detached operation\')\n    require(mode(before,detached)==mode(stored,detached)==mode(after,detached), \'publication processor mode\')\n    require(set(before)==set(stored)==set(after), \'publication snapshot closure\')\n    for key in before:\n        if key not in [\'tables\',\'flags\']:\n            require(before[key]==stored[key]==after[key], \'publication changed \'+key)\n    values=owners(before);selected=target(record,values)\n    require(base%PAGE==0 and 0<=base<=base+new*PAGE<=1<<30, \'publication physical geometry\')\n    if selected is None:require(new==base==0, \'publication without target owner\')\n    else:require(selected[\'pins\']==1 and selected[\'count\']==new and selected[\'span\'][0]==base,\n                 \'publication target extent\')\n    if detached is not None:require(old>0 and new==0, \'detached whole-heap publication\')\n    root=before[\'context\'][\'root\']\n    tables={str(t) for t in [root,root+PAGE,root+2*PAGE,root+3*PAGE,root+4*PAGE,before[\'context\'][\'low\']]}\n    require(set(before[\'tables\'])==set(stored[\'tables\'])==set(after[\'tables\'])==tables,\n            \'publication complete translation graph\')\n    changed={slot(before,i):((base+i*PAGE)|LEAF if i<new else 0) for i in range(max(old,new))}\n    for table,words in before[\'tables\'].items():\n        actual=stored[\'tables\'][table]\n        require(len(words)==len(actual)==512, \'publication complete table\')\n        for index,(a,b) in enumerate(zip(words,actual)):\n            require(type(a) is int and type(b) is int and 0<=a<1<<64 and 0<=b<1<<64,\n                    \'publication table word\')\n            if (table,index) in changed:require(b&~0x60==changed[(table,index)], \'publication selected leaf\')\n            else:require(a&~0x60==b&~0x60 and (a|b)==b, \'publication unrelated translation\')\n    for i in range(519):\n        table,index=slot(before,i)\n        expected=((before[\'state\'][3]+i*PAGE)|LEAF) if i<old else 0\n        require(before[\'tables\'][table][index]&~0x60==expected, \'publication old owner mappings\')\n    count=max(old,new)\n    require(record[\'published_before_invalidations\'] and record[\'final_barrier_observed\'],\n            \'publication barrier observations\')\n    require(len(record[\'invalidations\'])==count, \'publication complete invalidation interval\')\n    for index,event in enumerate(record[\'invalidations\']):\n        require(event[\'index\']==index and event[\'address\']==HEAP+index*PAGE\n                and event[\'thread\']==before[\'thread\'], \'publication invalidation order/CPU\')\n    require(after[\'tables\']==stored[\'tables\'], \'publication translation changed during invalidation\')\n    require(record[\'return_stack\']==record[\'entry_stack\']\n            and record[\'return_address\']==record[\'entry_return_address\'], \'publication return identity\')\n    return dict(passed=True,pages_invalidated=count,operation=record[\'operation\'],\n        source_token=before[\'active\'][\'token\'],target_token=selected[\'token\'] if selected is not None else [0]*3,\n        scope=\'Saved selected process publication and local invalidation boundaries; not TLB introspection, continuous lifetime, all mapping writers, AP/DMA/async exclusion or public activation\')\n\n\ndef retirement(record,publications):\n    """Check one observed heap unpin/erase/release against recorded local flushes."""\n    import hashlib\n    before=record[\'before\'];values=owners(before)\n    operation,role=record[\'operation\'],record[\'bank\']\n    require((operation==13 and role==\'inactive\' and before[\'ids\'][0]==1)\n            or (operation in [5,6,7,12] and role==\'active\'), \'retirement process role\')\n    allocation=values[role]\n    require(allocation is not None and record[\'owner\']==before[role], \'retirement original owner\')\n    token=allocation[\'token\'];index=record[\'publication_index\']\n    require(0<=index<len(publications), \'retirement missing completed publication\')\n    results=[check(row) for row in publications]\n    require(results[index][\'source_token\']==token\n            and all(row[\'target_token\']!=token for row in results[index:]), \'retirement source remains unmapped\')\n    if operation!=13:require(index==len(publications)-1\n            and publications[index][\'operation\']==operation, \'retirement current publication\')\n    last=publications[-1]\n    require(mode(before,record.get(\'detachment\'))==mode(last[\'after\'],last.get(\'detachment\'))\n            and before[\'thread\']==last[\'after\'][\'thread\'], \'retirement publication CPU/mode\')\n    require(all(before[\'context\'][key]==last[\'after\'][\'context\'][key]\n                for key in [\'address\',\'root\',\'low\',\'bootstrap\']), \'retirement publication context\')\n    require(set(before[\'tables\'])==set(last[\'after\'][\'tables\']), \'retirement complete tables\')\n    for table,words in last[\'after\'][\'tables\'].items():\n        current=before[\'tables\'][table]\n        require(len(current)==len(words)==512 and all(a&~0x60==b&~0x60 and a|b==b for a,b in zip(words,current)),\n                \'retirement mapping changed after publication\')\n    a,b=allocation[\'span\']\n    for i in range(519):\n        table,position=slot(before,i);pte=before[\'tables\'][table][position]\n        if pte&1:require(not a<=(pte&0x000ffffffffff000)<b, \'retirement still mapped heap\')\n    require(record[\'unpin_succeeded\'] is True, \'retirement unpin result\')\n    unpinned=record[\'unpinned\']\n    expected=allocation[\'record\'][:]\n    expected[6]=0\n    require(unpinned[\'record\']==expected and unpinned[\'token\']==token\n            and unpinned[\'cells\']==allocation[\'cells\'] and unpinned[\'bytes\']==\'\', \'retirement unpin effect\')\n    erased=record[\'erase\'];release=record[\'release\']\n    require(erased==dict(base=a,count=allocation[\'count\']), \'retirement erase arguments\')\n    size=allocation[\'count\']*PAGE;zero=hashlib.sha256(bytes(size)).hexdigest()\n    require(release==dict(base=a,count=allocation[\'count\'],erased_bytes=size,erased_sha256=zero),\n            \'retirement complete erasure before release\')\n    after=record[\'released\']\n    cells=[value for i in range(allocation[\'count\']) for value in [0,allocation[\'cells\'][i*3+1],allocation[\'cells\'][i*3+2]]]\n    require(record[\'release_succeeded\'] is True and after[\'token\']==[0]*3\n            and after[\'record\']==[0]*8 and after[\'cells\']==cells\n            and after[\'erased_sha256\']==zero, \'retirement consumed owner/free cells\')\n    return dict(passed=True,erased_bytes=size,token=token,publication_index=index,\n        scope=\'Saved local publication before heap unpin, complete erasure before release and consumed record; no continuous exclusion, other mapping writers, AP/DMA/async or fatal-path qualification\')\n',publication_model)
publication_trace={}
exec('"""Parse saved QEMU TCG CPU states immediately following the publisher INVLPG.\n\nThese are execution-log observations, not a TLB dump or general CPU exclusion.\n"""\nimport re\n\n\ndef parse(raw,site):\n    # With default chaining, QEMU\'s exec logger also emits link diagnostics,\n    # including on a CPU with no states inside the address filter.\n    text=\'\'.join(line for line in raw.decode(\'ascii\').splitlines(keepends=True)\n        if not re.fullmatch(r\'Linking TBs 0x[0-9a-f]+ index [01] -> 0x[0-9a-f]+\\n?\',line))\n    starts=list(re.finditer(r\'^Trace ([0-9]+): (0x[0-9a-f]+) \\[([0-9a-f]+)/([0-9a-f]+)/[^\\]]+\\][^\\n]*\\n\',text,re.M))\n    assert not starts or not text[:starts[0].start()].strip(),\'unexpected trace prefix\'\n    result=[]\n    for i,header in enumerate(starts):\n        cpu,tb,_,pc=header.groups()\n        pc=int(pc,16)\n        assert pc==site,\'unexpected CPU trace PC\'\n        block=text[header.end():starts[i+1].start() if i+1<len(starts) else len(text)]\n        def value(name):\n            values=re.findall(r\'\\b\'+name+r\'\\s*=([0-9a-fA-F]+)\',block)\n            assert len(values)==1,(\'missing or duplicate CPU state\',name)\n            return int(values[0],16)\n        assert value(\'RIP\')==site and value(\'CS\')&3==0\n        stopped=re.findall(r\'^Stopped execution of TB chain before (0x[0-9a-f]+) \\[([0-9a-f]+)\\][^\\n]*$\',block,re.M)\n        assert len(stopped)==sum(line.startswith(\'Stopped execution\') for line in block.splitlines())\n        assert len(stopped)<=1 and all(pointer==tb and int(address,16)==site for pointer,address in stopped)\n        result.append(dict(cpu=int(cpu),index=value(\'RCX\'),address=value(\'RAX\'),\n            cr0=value(\'CR0\'),cr3=value(\'CR3\'),cr4=value(\'CR4\'),efer=value(\'EFER\'),flags=value(\'RFL\'),cancelled=bool(stopped)))\n    assert not text or starts,\'unparsed nonempty CPU trace\'\n    return result\n\n\ndef completed(events):\n    """Keep explicit cancelled attempts separate and require their exact retry.\n\n    A CPU dump precedes its execution block. QEMU explicitly reports a block\n    stopped before execution; it can then log the same post-INVLPG PC again.\n    No unmarked duplicate, different retry or terminal cancellation is removed.\n    """\n    pending=None\n    states=[]\n    cancelled=[]\n    for event in events:\n        key={k:v for k,v in event.items() if k!=\'cancelled\'}\n        if pending is not None:assert key==pending,\'cancelled block lacks matching retry\'\n        if event[\'cancelled\']:\n            pending=key\n            cancelled.append(event)\n        else:\n            states.append(event)\n            pending=None\n    assert pending is None,\'terminal cancelled block has no retry\'\n    return states,cancelled\n',publication_trace)

def complete_save():
    import os
    observed.update(pending=pending,active_case=case,refusal_pending=refusal_attempt)
    with open(observation_path+'.tmp','w') as stream:
        stream.write(json.dumps(observed,separators=(',',':')))
    os.replace(observation_path+'.tmp',observation_path)

def save():
    # Every in-memory record and every native assertion is retained. Avoid
    # repeatedly encoding the complete growing history on ordinary queries.
    if observed.get('passed') or observed.get('failure') or len(observed['events'])%64==0:
        complete_save()

from pathlib import Path
publication_active=None
publication_retiring=None
publication_switch=None
publication_returns={}
publication_gateway_return=None
publication_data=dict(passed=False,profile=publication_profile,records=[],root_switches=[])
observed['process_publication']=publication_data

def publication_allocation(token,allocator):
    if token==[0]*3:return dict(token=token,record=[],cells=[],bytes='')
    assert token[0]==1 and 0<token[1]<allocator[2] and token[2]<allocator[3]
    record=words(allocator[6]+token[2]*64,8)
    assert record[:2]==token[:2] and record[7]==1 and 0<record[3]<=allocator[3]
    assert 0<=record[2]<record[2]+record[3]<=allocator[3]
    cells=words(allocator[4]+128+record[2]*24,record[3]*3)
    return dict(token=token,record=record,cells=cells,bytes='')

def publication_capture():
    # Read each shared metadata block once at this debugger stop. These are
    # fresh reads on every capture, never cached owner/pin/table observations.
    header=words(context,16);root,low=header[3],header[14]
    token=address('topal_x86_frame_mm_tokens_v1')
    roots=address('topal_x86_frame_root_tokens_v1')
    allocator=words(address('topal_x86_frame_context_v1'),16)
    tokens=words(token,6);root_tokens=words(roots,token_bytes//8)
    return dict(allocator=allocator,
        context=dict(address=context,state=header[0],root=root,low=low,
                     bootstrap=header[2],heap=header[15]),
        state=words(address('topal_x86_frame_mm_state_v1'),4),tokens=tokens,
        ids=words(address('topal_x86_process_mm_ids_v1'),7),epoch=words(address('topal_x86_frame_mm_epoch_v1'),2),
        inactive_state=words(address('topal_x86_process_mm_inactive_state_v1'),4),
        prepared_state=words(address('topal_x86_process_mm_prepared_state_v1'),7),
        prepared_owner=words(address('topal_x86_process_mm_prepared_owner_v1'),3),
        transition=words(address('topal_x86_process_mm_transition_v1'),3),
        active=publication_allocation(tokens[:3],allocator),candidate=publication_allocation(tokens[3:],allocator),
        inactive=publication_allocation(words(address('topal_x86_process_mm_inactive_token_v1'),3),allocator),
        prepared=publication_allocation(words(address('topal_x86_process_mm_prepared_token_v1'),3),allocator),
        root_owners=[publication_allocation(root_tokens[i:i+3],allocator)
            for i in range(0,len(root_tokens),3) if root_tokens[i:i+3]!=[0]*3],
        tables={str(at):words(at,512) for at in [root,root+4096,root+8192,root+12288,root+16384,low]},
        kernel_spans=kernel_spans,thread=list(gdb.selected_thread().ptid),
        cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'),cs=reg('cs'),flags=reg('eflags'))

class PublicationChecked(Checked):
    def stop(self):
        try:return self.observe()
        except Exception:
            traceback.print_exc()
            observed['passed']=False
            publication_data.update(failure=traceback.format_exc(),active=publication_active,
                retiring=publication_retiring,switch=publication_switch)
            observed['failure']=traceback.format_exc()
            save()
            return True

class PublicationBoundary(PublicationChecked):
    def __init__(self,kind,site):
        self.kind=kind
        super().__init__('*'+hex(site),internal=True)
    def observe(self):
        global publication_active
        assert pending is not None and publication_retiring is None
        if self.kind=='entry':
            assert publication_active is None
            operation=pending['operation']
            assert operation in [5,6,7,10,11,12]
            detached=publication_data['root_switches'][-1] if operation==6 and publication_data['root_switches'] else None
            assert (operation==6)==(detached is not None)
            publication_active=dict(operation=operation,old_count=reg('rdi'),new_count=reg('rsi'),new_base=reg('rdx'),
                before=publication_capture(),detachment=detached,entry_stack=reg('rsp'),entry_return_address=word(reg('rsp')),
                request_sp=pending['sp'],invalidations=[],published_before_invalidations=False,final_barrier_observed=False,
                trace_before={path.name:path.stat().st_size for path in Path(observation_path).parent.glob('cpu-*.log')})
        elif self.kind=='stored':
            assert publication_active is not None and not publication_active['published_before_invalidations']
            publication_active.update(stored=publication_capture(),published_before_invalidations=True)
        else:
            assert self.kind=='returning' and publication_active is not None
            row=publication_active
            row.update(after=publication_capture(),return_stack=reg('rsp'),return_address=word(reg('rsp')),
                final_barrier_observed=True,trace_slices=[],cancelled_post_states=[])
            for path in sorted(Path(observation_path).parent.glob('cpu-*.log')):
                start=row['trace_before'].get(path.name,0);raw=path.read_bytes()[start:]
                events=publication_trace['parse'](raw,publication_profile['sites']['invalidated'])
                row['trace_slices'].append(dict(file=path.name,start=start,size=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
                for event in events:
                    assert event['cpu']+1==row['before']['thread'][1] and row['before']['thread'][0]==1
                    assert (event['cr0'],event['cr3'],event['cr4'])==tuple(row['before'][key] for key in ['cr0','cr3','cr4'])
                    assert event['efer']&0xd00==0xd00 and event['flags']&0x600==0
                states,cancelled=publication_trace['completed'](events)
                row['invalidations'].extend(dict(event,thread=row['before']['thread']) for event in states)
                row['cancelled_post_states'].extend(cancelled)
            row['comparison']=publication_model['check'](row)
            pending['publication_indices'].append(len(publication_data['records']))
            publication_data['records'].append(row)
            publication_active=None
        return False

class PublicationRootSwitch(PublicationChecked):
    def __init__(self,kind,site):
        self.kind=kind
        super().__init__('*'+hex(site),internal=True)
    def observe(self):
        global publication_switch
        assert pending is publication_active is publication_retiring is None
        if self.kind=='before':
            assert publication_switch is None
            before=publication_capture()
            assert reg('rax')==before['context']['bootstrap']
            publication_switch=dict(before=before,before_site=reg('rip'),source_register=reg('rax'))
        else:
            assert self.kind=='after' and publication_switch is not None
            row=publication_switch;row.update(after=publication_capture(),after_site=reg('rip'))
            row['comparison']=publication_tables['check_switch'](row)
            publication_data['root_switches'].append(row);publication_switch=None
        return False

def publication_return(kind,site):
    key=(kind,site)
    if key not in publication_returns:publication_returns[key]=PublicationReturn(kind,site)
    point=publication_returns[key];assert not point.enabled
    point.enabled=True

class PublicationUnpin(PublicationChecked):
    def observe(self):
        global publication_retiring
        pointers={address('topal_x86_frame_mm_tokens_v1'):'active',
            address('topal_x86_process_mm_inactive_token_v1'):'inactive'}
        pointer=reg('rsi')
        if reg('rdx')&1 or pointer not in pointers:return False
        assert pending is not None and publication_active is publication_retiring is None
        assert reg('rdi')==address('topal_x86_frame_context_v1')
        before=publication_capture();role=pointers[pointer];owned=before[role]
        token=owned['token'];assert token!=[0]*3 and owned['record'][6:]==[1,1]
        indices=[i for i,row in enumerate(publication_data['records']) if row['comparison']['source_token']==token]
        assert indices
        publication_retiring=dict(operation=pending['operation'],bank=role,before=before,owner=owned,
            token_pointer=pointer,publication_index=indices[-1],detachment=(publication_data['root_switches'][-1]
            if pending['operation']==6 else None),unpin_succeeded=False,erase=None,release=None,
            release_succeeded=False,publication_count=len(publication_data['records']),
            unpin_stack=reg('rsp'),unpin_return=word(reg('rsp')))
        publication_return('unpin',word(reg('rsp')))
        return False

class PublicationErase(PublicationChecked):
    def observe(self):
        if publication_retiring is None:return False
        row=publication_retiring
        assert row['unpin_succeeded'] and row['erase'] is row['release'] is None
        assert publication_active is None and len(publication_data['records'])==row['publication_count']
        row['erase']=dict(base=reg('rdi'),count=reg('rsi'))
        assert row['erase']==dict(base=row['owner']['cells'][2]*4096,count=row['owner']['record'][3])
        return False

class PublicationRelease(PublicationChecked):
    def observe(self):
        if publication_retiring is None:return False
        row=publication_retiring
        assert row['unpin_succeeded'] and row['erase'] is not None and row['release'] is None
        assert publication_active is None and len(publication_data['records'])==row['publication_count']
        assert reg('rdi')==address('topal_x86_frame_context_v1') and reg('rsi')==row['token_pointer']
        base,count=row['erase']['base'],row['erase']['count'];raw=memory(base,count*4096)
        assert raw==bytes(len(raw))
        row['release']=dict(base=base,count=count,erased_bytes=len(raw),erased_sha256=hashlib.sha256(raw).hexdigest())
        row.update(release_stack=reg('rsp'),release_return=word(reg('rsp')))
        publication_return('release',word(reg('rsp')))
        return False

class PublicationReturn(PublicationChecked):
    def __init__(self,kind,site):
        self.kind=kind
        super().__init__('*'+hex(site),internal=True);self.enabled=False
    def observe(self):
        global publication_retiring
        self.enabled=False;row=publication_retiring
        assert row is not None and reg('rax')&1
        assert reg('rsp')==row[self.kind+'_stack']+8 and reg('rip')==row[self.kind+'_return']
        assert publication_active is None and len(publication_data['records'])==row['publication_count']
        if self.kind=='unpin':
            row.update(unpin_succeeded=True,unpinned=allocation(row['token_pointer'],False))
        else:
            assert self.kind=='release' and row['release'] is not None
            old=row['owner'];allocator=words(address('topal_x86_frame_context_v1'),16)
            row.update(release_succeeded=True,released=dict(token=words(row['token_pointer'],3),
                record=words(allocator[6]+old['token'][2]*64,8),
                cells=words(allocator[4]+128+old['record'][2]*24,old['record'][3]*3),
                erased_sha256=hashlib.sha256(memory(row['erase']['base'],row['erase']['count']*4096)).hexdigest()))
            row['comparison']=publication_model['retirement'](row,publication_data['records'])
            pending['publication_retirements'].append(row);publication_retiring=None
        return False

class Gateway(Gateway):
    def __init__(self,symbol,enter):
        global publication_gateway_return
        super().__init__(symbol,enter)
        if not enter:
            assert publication_gateway_return is None
            publication_gateway_return=self;self.enabled=False
    def observe(self):
        count=len(observed['events']);result=super().observe()
        assert publication_gateway_return is not None
        if self.enter:publication_gateway_return.enabled=pending is not None
        else:self.enabled=False
        if self.enter and pending is not None:
            assert publication_active is publication_retiring is None
            pending.update(publication_indices=[],publication_retirements=[])
        elif not self.enter and len(observed['events'])>count:
            row=observed['events'][-1]
            assert publication_active is publication_retiring is None
            assert {tuple(r['token']) for r in row['retired']}=={
                tuple(r['owner']['token']) for r in row['publication_retirements']}
            operation=row['operation'];old=row['before']['state'][2];new=row['after']['state'][2]
            expected=1 if operation in [10,11,12] else int(old!=new) if operation==5 else int(old>0) if operation in [6,7] else 0
            assert len(row['publication_indices'])==expected
        return result

class Complete(Complete):
    def observe(self):
        assert publication_active is publication_retiring is publication_switch is None
        assert publication_gateway_return is not None and not publication_gateway_return.enabled
        assert all(not point.enabled for point in publication_returns.values())
        assert publication_data['records'] and publication_data['root_switches']
        publication_data['passed']=True
        return super().observe()

def install_process_publication():
    for kind,site in publication_profile['sites'].items():
        if kind!='invalidated':PublicationBoundary(kind,site)
    for kind,site in publication_profile['root_switch_sites'].items():PublicationRootSwitch(kind,site)
    PublicationUnpin('*'+hex(publication_profile['pin_entry']),internal=True)
    PublicationErase('*'+hex(publication_profile['erase_entry']),internal=True)
    PublicationRelease('*'+hex(publication_profile['release_entry']),internal=True)

try:
    install_process_publication()
    Gateway('topal_x86_frame_gateway_v1',True)
    Gateway('topal_x86_frame_gateway_return_reclaimed_v1',False)
    CaseEntered('*'+hex(component['entry']),internal=True)
    if child_exec or allocation_config is not None or geometry_config is not None or (cancel_config is not None and cancel_config['early']) or (relationship_config is not None and relationship_config['early']):
        ImageEntered('*'+hex(component['image_entry']),internal=True)
    if cancel_config is not None:
        Terminal('topal_x86_process_mm_parent_exit_v1',False)
        Terminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    if allocation_config is not None:
        UserFork('*'+hex(component['syscall']),internal=True)
        AllocationTerminal('topal_x86_process_mm_parent_exit_v1',False)
        AllocationTerminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    if geometry_config is not None:
        GeometryTerminal('topal_x86_process_mm_parent_exit_v1',False)
        GeometryTerminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    if relationship_config is not None:
        ChildDeparture('*'+hex(component['syscall']),internal=True)
        RelationshipTerminal('topal_x86_process_mm_parent_exit_v1',False)
        RelationshipTerminal('topal_x86_process_mm_parent_resources_retired_v1',True)
    Halt('*'+hex(native_halt),internal=True)
    Complete('*topal_x86_systems_fatal',internal=True)
    gdb.execute('continue')
    assert observed['passed']
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:
    traceback.print_exc()
    save()
    gdb.execute('quit 1')

end
