target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"
; Bootstrap-only target implementation, not a source address constructor.
; The 1GiB bound is the existing bootstrap identity mapping, not pool policy.
; All complete normalized allocatable frames must fit, or creation fails.
; Capacities cover that architectural window; actual N is derived from E820.
@topal_x86_frame_context_v1 = global [16 x i64] zeroinitializer, align 64
@topal_x86_frame_table_v1 = global [6291584 x i8] zeroinitializer, align 64
@topal_x86_frame_snapshot_v1 = global [6291584 x i8] zeroinitializer, align 64
@topal_x86_frame_registry_v1 = global [16777216 x i8] zeroinitializer, align 64
@topal_x86_frame_tokens_v1 = global [6291456 x i8] zeroinitializer, align 64
@topal_x86_frame_history_v1 = global [5 x i64] zeroinitializer, align 16
@topal_x86_frame_private_v1 = global [65536 x i8] zeroinitializer, align 16
@topal_x86_frame_stack_v1 = global [4096 x i8] zeroinitializer, align 16
@topal_x86_frame_facts_v1 = global [3 x i64] zeroinitializer, align 16
@topal_x86_frame_output_v1 = global [7 x i64] zeroinitializer, align 16
@topal_x86_frame_details_v1 = global [4 x i64] zeroinitializer, align 16
@topal_x86_frame_handoff_v1 = global [5 x i64] zeroinitializer, align 16
; Linker/packager must bind the actual complete allocated image end, including
; this backing. No hand-written floor may stand in for that binding.
@topal_x86_kernel_reservation_end_v1 = external global i8
@topal_frame_allocator_active_v1 = external global ptr
@topal_x86_tail_boundary_active_v1 = external global ptr

define internal i64 @t.word(ptr %p,i64 %i) nounwind alwaysinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %a = getelementptr i64,ptr %p,i64 %i
  %v = load i64,ptr %a,align 8
  ret i64 %v
}
define internal void @t.put(ptr %p,i64 %i,i64 %v) nounwind alwaysinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %a = getelementptr i64,ptr %p,i64 %i
  store i64 %v,ptr %a,align 8
  ret void
}
define internal i64 @t.load64(ptr %p,i64 %offset) nounwind alwaysinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %a = getelementptr i8,ptr %p,i64 %offset
  %v = load i64,ptr %a,align 1
  ret i64 %v
}
define internal i64 @t.load32(ptr %p,i64 %offset) nounwind alwaysinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %a = getelementptr i8,ptr %p,i64 %offset
  %v = load i32,ptr %a,align 1
  %w = zext i32 %v to i64
  ret i64 %w
}
define internal void @t.zero(ptr %p,i64 %bytes) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %more = icmp ult i64 %i,%bytes
  br i1 %more,label %body,label %end
body:
  %a = getelementptr i8,ptr %p,i64 %i
  store volatile i8 0,ptr %a,align 1
  %next = add i64 %i,1
  br label %loop
end:
  ret void
}
; Private ordinary-RAM predicate. Caller holds the complete stable buffer.
; Wide loads cover only complete eight-byte chunks; tails retain byte loads.
; No result or memory contents are cached across calls.
define internal i1 @t.clean(ptr %p,i64 %bytes) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %words
words:
  %i = phi i64 [0,%entry],[%word_next,%word]
  %remaining = sub i64 %bytes,%i
  %wide = icmp uge i64 %remaining,8
  br i1 %wide,label %word,label %tail
word:
  %word_at = getelementptr i8,ptr %p,i64 %i
  %word_value = load volatile i64,ptr %word_at,align 1
  %word_zero = icmp eq i64 %word_value,0
  %word_next = add i64 %i,8
  br i1 %word_zero,label %words,label %bad
tail:
  %j = phi i64 [%i,%words],[%byte_next,%byte]
  %more = icmp ult i64 %j,%bytes
  br i1 %more,label %byte,label %end
byte:
  %byte_at = getelementptr i8,ptr %p,i64 %j
  %byte_value = load volatile i8,ptr %byte_at,align 1
  %byte_zero = icmp eq i8 %byte_value,0
  %byte_next = add i64 %j,1
  br i1 %byte_zero,label %tail,label %bad
end:
  ret i1 true
bad:
  ret i1 false
}
; Architecture-private register observations. The source language has no asm.
; This admission establishes bootstrap hardware geometry only, not the later
; typed owning gateway, syscall stack leases or complete caller retirement.
define internal i1 @t.bootstrap() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %cs = call i16 asm sideeffect "movw %cs, $0", "=r,~{dirflag},~{fpsr},~{flags}"()
  %flags = call i64 asm sideeffect "pushfq; popq $0", "=r,~{dirflag},~{fpsr},~{flags},~{memory}"()
  %sp = call i64 asm sideeffect "movq %rsp, $0", "=r,~{dirflag},~{fpsr},~{flags}"()
  %ring = and i16 %cs,3
  %kernel = icmp eq i16 %ring,0
  %if = and i64 %flags,512
  %disabled = icmp eq i64 %if,0
  %low = icmp uge i64 %sp,1081344
  %high = icmp ult i64 %sp,1572864
  %a = and i1 %kernel,%disabled
  %b = and i1 %low,%high
  %ok = and i1 %a,%b
  %lease = call i1 @g.lease()
  %owned = and i1 %ok,%lease
  ret i1 %owned
}

; Return the next *raw* boundary, including both reservations. Classifying and
; aligning each interval before merging reproduces the normalized-page rule:
; an unaligned raw boundary cannot be erased by premature RAM coalescing.
define internal i64 @t.next(ptr %boot,i64 %entries,i64 %cursor,i64 %reserved,i64 %resource,i64 %resourceEnd) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %r = icmp ugt i64 %reserved,%cursor
  %first = select i1 %r,i64 %reserved,i64 -1
  %s = icmp ugt i64 %resource,%cursor
  %less = icmp ult i64 %resource,%first
  %take = and i1 %s,%less
  %second = select i1 %take,i64 %resource,i64 %first
  %e = icmp ugt i64 %resourceEnd,%cursor
  %el = icmp ult i64 %resourceEnd,%second
  %et = and i1 %e,%el
  %initial = select i1 %et,i64 %resourceEnd,i64 %second
  br label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%body]
  %minimum = phi i64 [%initial,%entry],[%chosenEnd,%body]
  %more = icmp ult i64 %i,%entries
  br i1 %more,label %body,label %end
body:
  %offset = mul i64 %i,20
  %at = add i64 %offset,720
  %base = call i64 @t.load64(ptr %boot,i64 %at)
  %la = add i64 %at,8
  %length = call i64 @t.load64(ptr %boot,i64 %la)
  %limit = add i64 %base,%length
  %above = icmp ugt i64 %base,%cursor
  %below = icmp ult i64 %base,%minimum
  %choose = and i1 %above,%below
  %chosenBase = select i1 %choose,i64 %base,i64 %minimum
  %endAbove = icmp ugt i64 %limit,%cursor
  %endBelow = icmp ult i64 %limit,%chosenBase
  %chooseEnd = and i1 %endAbove,%endBelow
  %chosenEnd = select i1 %chooseEnd,i64 %limit,i64 %chosenBase
  %next = add i64 %i,1
  br label %loop
end:
  ret i64 %minimum
}
define internal i1 @t.allocatable(ptr %boot,i64 %entries,i64 %start,i64 %end,i64 %reserved,i64 %resource,i64 %resourceEnd) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %kernel = icmp ult i64 %start,%reserved
  %left = icmp ult i64 %start,%resourceEnd
  %right = icmp ugt i64 %end,%resource
  %overlap = and i1 %left,%right
  %blocked = or i1 %kernel,%overlap
  br i1 %blocked,label %bad,label %loop
loop:
  %i = phi i64 [0,%entry],[%next,%advance]
  %found = phi i1 [false,%entry],[%now,%advance]
  %more = icmp ult i64 %i,%entries
  br i1 %more,label %body,label %endloop
body:
  %offset = mul i64 %i,20
  %at = add i64 %offset,720
  %base = call i64 @t.load64(ptr %boot,i64 %at)
  %la = add i64 %at,8
  %length = call i64 @t.load64(ptr %boot,i64 %la)
  %limit = add i64 %base,%length
  %before = icmp ule i64 %base,%start
  %after = icmp uge i64 %limit,%end
  %covers = and i1 %before,%after
  %ta = add i64 %at,16
  %type = call i64 @t.load32(ptr %boot,i64 %ta)
  %ram = icmp eq i64 %type,1
  %notram = xor i1 %ram,true
  %reservedClaim = and i1 %covers,%notram
  br i1 %reservedClaim,label %bad,label %advance
advance:
  %now = or i1 %found,%covers
  %next = add i64 %i,1
  br label %loop
endloop:
  ret i1 %found
bad:
  ret i1 false
}

; Complete constructor. BSS belongs to the linked-image reservation; the
; complete table/registry/token backing cannot become allocatable memory.
define ptr @topal_x86_frame_allocator_create_v1(ptr %boot) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %hardware = call i1 @t.bootstrap()
  br i1 %hardware,label %once,label %refuse
once:
  %state = call i64 @t.word(ptr @topal_x86_frame_context_v1,i64 0)
  %fresh = icmp eq i64 %state,0
  br i1 %fresh,label %geometry,label %refuse
geometry:
  %address = ptrtoint ptr %boot to i64
  %nonzero = icmp ne i64 %address,0
  %inside = icmp ule i64 %address,16773120
  %end = ptrtoint ptr @topal_x86_kernel_reservation_end_v1 to i64
  %aboveBootstrap = icmp uge i64 %end,16777216
  %mapped = icmp ule i64 %end,1073741824
  %a = and i1 %nonzero,%inside
  %b = and i1 %aboveBootstrap,%mapped
  %valid = and i1 %a,%b
  br i1 %valid,label %handoff,label %failed
handoff:
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 0,i64 2)
  %setup = call i64 @t.load64(ptr %boot,i64 592)
  %extImage = call i64 @t.load32(ptr %boot,i64 192)
  %extSize = call i64 @t.load32(ptr %boot,i64 196)
  %resource = call i64 @t.load32(ptr %boot,i64 536)
  %resourceSize = call i64 @t.load32(ptr %boot,i64 540)
  %resourceEnd = add i64 %resource,%resourceSize
  %resNonzero = icmp ne i64 %resourceSize,0
  %resAfter = icmp uge i64 %resource,%end
  %resMapped = icmp ule i64 %resourceEnd,1073741824
  %noExtra = or i64 %setup,%extImage
  %noExt = or i64 %noExtra,%extSize
  %plain = icmp eq i64 %noExt,0
  %c = and i1 %resNonzero,%resAfter
  %d = and i1 %resMapped,%plain
  %handoffValid = and i1 %c,%d
  br i1 %handoffValid,label %count,label %failed
count:
  %cp = getelementptr i8,ptr %boot,i64 488
  %cv = load i8,ptr %cp,align 1
  %entries = zext i8 %cv to i64
  %has = icmp ne i64 %entries,0
  %bounded = icmp ule i64 %entries,128
  %table = and i1 %has,%bounded
  br i1 %table,label %validate,label %failed
validate:
  %i = phi i64 [0,%count],[%nextEntry,%entryNext]
  %more = icmp ult i64 %i,%entries
  br i1 %more,label %entryCheck,label %normalize
entryCheck:
  %offset = mul i64 %i,20
  %at = add i64 %offset,720
  %base = call i64 @t.load64(ptr %boot,i64 %at)
  %la = add i64 %at,8
  %length = call i64 @t.load64(ptr %boot,i64 %la)
  %limit = add i64 %base,%length
  %nonempty = icmp ne i64 %length,0
  %nowrap = icmp ugt i64 %limit,%base
  %proper = and i1 %nonempty,%nowrap
  %ta = add i64 %at,16
  %type = call i64 @t.load32(ptr %boot,i64 %ta)
  %ram = icmp eq i64 %type,1
  %outside = icmp ugt i64 %limit,1073741824
  %unsupported = and i1 %ram,%outside
  %supported = xor i1 %unsupported,true
  %entryValid = and i1 %proper,%supported
  br i1 %entryValid,label %entryNext,label %failed
entryNext:
  %nextEntry = add i64 %i,1
  br label %validate
normalize:
  br label %interval
interval:
  %cursor = phi i64 [0,%normalize],[%boundary,%advance]
  %n = phi i64 [0,%normalize],[%newN,%advance]
  %boundary = call i64 @t.next(ptr %boot,i64 %entries,i64 %cursor,i64 %end,i64 %resource,i64 %resourceEnd)
  %last = icmp eq i64 %boundary,-1
  br i1 %last,label %complete,label %classify
classify:
  %alloc = call i1 @t.allocatable(ptr %boot,i64 %entries,i64 %cursor,i64 %boundary,i64 %end,i64 %resource,i64 %resourceEnd)
  br i1 %alloc,label %align,label %skip
align:
  %rounded = add i64 %cursor,4095
  %overflow = icmp ult i64 %rounded,%cursor
  br i1 %overflow,label %failed,label %qualified
qualified:
  %lo = and i64 %rounded,-4096
  %hi = and i64 %boundary,-4096
  %whole = icmp ult i64 %lo,%hi
  br i1 %whole,label %window,label %skip
window:
  %fits = icmp ule i64 %hi,1073741824
  br i1 %fits,label %cells,label %failed
cells:
  %physical = lshr i64 %lo,12
  %stop = lshr i64 %hi,12
  br label %cellloop
cellloop:
  %frame = phi i64 [%physical,%cells],[%nextFrame,%write]
  %used = phi i64 [%n,%cells],[%nextN,%write]
  %remaining = icmp ult i64 %frame,%stop
  br i1 %remaining,label %capacity,label %added
capacity:
  %space = icmp ult i64 %used,262144
  br i1 %space,label %write,label %failed
write:
  %bytes = mul i64 %used,24
  %cellOffset = add i64 %bytes,128
  %cell = getelementptr i8,ptr @topal_x86_frame_table_v1,i64 %cellOffset
  call void @t.put(ptr %cell,i64 0,i64 0)
  ; All E820 type-1 claims have identical source-kind/provider provenance.
  call void @t.put(ptr %cell,i64 1,i64 1)
  call void @t.put(ptr %cell,i64 2,i64 %frame)
  %nextFrame = add i64 %frame,1
  %nextN = add i64 %used,1
  br label %cellloop
added:
  br label %advance
skip:
  br label %advance
advance:
  %newN = phi i64 [%used,%added],[%n,%skip]
  br label %interval
complete:
  %any = icmp ne i64 %n,0
  br i1 %any,label %publish,label %failed
publish:
  %registryBytes = mul i64 %n,64
  %tokenBytes = mul i64 %n,24
  call void @t.zero(ptr @topal_x86_frame_registry_v1,i64 %registryBytes)
  call void @t.zero(ptr @topal_x86_frame_tokens_v1,i64 %tokenBytes)
  call void @t.zero(ptr @topal_x86_frame_history_v1,i64 40)
  call void @t.zero(ptr @topal_x86_frame_private_v1,i64 65536)
  call void @t.zero(ptr @topal_x86_frame_stack_v1,i64 4096)
  call void @t.zero(ptr @topal_x86_frame_facts_v1,i64 24)
  call void @t.zero(ptr @topal_x86_frame_output_v1,i64 56)
  call void @t.zero(ptr @topal_x86_frame_details_v1,i64 32)
  call void @t.put(ptr @topal_x86_frame_table_v1,i64 0,i64 %n)
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 1,i64 1)
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 2,i64 1)
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 3,i64 %n)
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 4,i64 ptrtoint (ptr @topal_x86_frame_table_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 5,i64 ptrtoint (ptr @topal_x86_frame_snapshot_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 6,i64 ptrtoint (ptr @topal_x86_frame_registry_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 7,i64 ptrtoint (ptr @topal_x86_frame_history_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 8,i64 ptrtoint (ptr @topal_x86_frame_private_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 9,i64 ptrtoint (ptr @topal_x86_frame_stack_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 10,i64 ptrtoint (ptr @topal_x86_frame_facts_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 11,i64 ptrtoint (ptr @topal_x86_frame_output_v1 to i64))
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 12,i64 4096)
  call void @t.put(ptr @topal_x86_frame_handoff_v1,i64 0,i64 %address)
  call void @t.put(ptr @topal_x86_frame_handoff_v1,i64 1,i64 %end)
  call void @t.put(ptr @topal_x86_frame_handoff_v1,i64 2,i64 %resource)
  call void @t.put(ptr @topal_x86_frame_handoff_v1,i64 3,i64 %resourceEnd)
  call void @t.put(ptr @topal_x86_frame_handoff_v1,i64 4,i64 %n)
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 0,i64 1)
  ret ptr @topal_x86_frame_context_v1
failed:
  call void @t.put(ptr @topal_x86_frame_context_v1,i64 0,i64 3)
  ret ptr null
refuse:
  ret ptr null
}

define i1 @topal_frame_kernel_admit_v1(ptr %ctx,i64 %operation,i64 %count,i64 %alignment) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %owned = icmp eq ptr %ctx,@topal_x86_frame_context_v1
  br i1 %owned,label %hardware,label %bad
hardware:
  %actual = call i1 @t.bootstrap()
  br i1 %actual,label %state,label %bad
state:
  %s = call i64 @t.word(ptr %ctx,i64 0)
  %issuer = call i64 @t.word(ptr %ctx,i64 1)
  %id = call i64 @t.word(ptr %ctx,i64 2)
  %n = call i64 @t.word(ptr %ctx,i64 3)
  %originalN = call i64 @t.word(ptr @topal_x86_frame_handoff_v1,i64 4)
  %live = icmp eq i64 %s,1
  %sameIssuer = icmp eq i64 %issuer,1
  %identity = icmp ne i64 %id,0
  %has = icmp ne i64 %n,0
  %capacity = icmp ule i64 %n,262144
  %sameN = icmp eq i64 %n,%originalN
  %a = and i1 %live,%sameIssuer
  %b = and i1 %identity,%has
  %c = and i1 %capacity,%sameN
  %ab = and i1 %a,%b
  %valid = and i1 %ab,%c
  br i1 %valid,label %pointers,label %bad
pointers:
  %p4 = call i64 @t.word(ptr %ctx,i64 4)
  %p5 = call i64 @t.word(ptr %ctx,i64 5)
  %p6 = call i64 @t.word(ptr %ctx,i64 6)
  %p7 = call i64 @t.word(ptr %ctx,i64 7)
  %p8 = call i64 @t.word(ptr %ctx,i64 8)
  %p9 = call i64 @t.word(ptr %ctx,i64 9)
  %p10 = call i64 @t.word(ptr %ctx,i64 10)
  %p11 = call i64 @t.word(ptr %ctx,i64 11)
  %p12 = call i64 @t.word(ptr %ctx,i64 12)
  %v4 = icmp eq i64 %p4,ptrtoint (ptr @topal_x86_frame_table_v1 to i64)
  %v5 = icmp eq i64 %p5,ptrtoint (ptr @topal_x86_frame_snapshot_v1 to i64)
  %v6 = icmp eq i64 %p6,ptrtoint (ptr @topal_x86_frame_registry_v1 to i64)
  %v7 = icmp eq i64 %p7,ptrtoint (ptr @topal_x86_frame_history_v1 to i64)
  %v8 = icmp eq i64 %p8,ptrtoint (ptr @topal_x86_frame_private_v1 to i64)
  %v9 = icmp eq i64 %p9,ptrtoint (ptr @topal_x86_frame_stack_v1 to i64)
  %v10 = icmp eq i64 %p10,ptrtoint (ptr @topal_x86_frame_facts_v1 to i64)
  %v11 = icmp eq i64 %p11,ptrtoint (ptr @topal_x86_frame_output_v1 to i64)
  %v12 = icmp eq i64 %p12,4096
  %v45 = and i1 %v4,%v5
  %v67 = and i1 %v6,%v7
  %v89 = and i1 %v8,%v9
  %v1011 = and i1 %v10,%v11
  %v4567 = and i1 %v45,%v67
  %v891011 = and i1 %v89,%v1011
  %allPointers = and i1 %v4567,%v891011
  %geometry = and i1 %allPointers,%v12
  br i1 %geometry,label %domains,label %bad
domains:
  %tableN = call i64 @t.word(ptr @topal_x86_frame_table_v1,i64 0)
  %sameTable = icmp eq i64 %tableN,%n
  %active = call i64 @t.word(ptr @topal_x86_frame_history_v1,i64 3)
  %poison = call i64 @t.word(ptr @topal_x86_frame_history_v1,i64 4)
  %busy = or i64 %active,%poison
  %idle = icmp eq i64 %busy,0
  %pin = load ptr,ptr @topal_frame_allocator_active_v1,align 8
  %sourcePin = load ptr,ptr @topal_x86_tail_boundary_active_v1,align 8
  %notPinned = icmp eq ptr %pin,null
  %notSourcePinned = icmp eq ptr %sourcePin,null
  %private = call i1 @t.clean(ptr @topal_x86_frame_private_v1,i64 65528)
  %stack = call i1 @t.clean(ptr @topal_x86_frame_stack_v1,i64 4096)
  %facts = call i1 @t.clean(ptr @topal_x86_frame_facts_v1,i64 24)
  %output = call i1 @t.clean(ptr @topal_x86_frame_output_v1,i64 56)
  %q0 = and i1 %sameTable,%idle
  %q1 = and i1 %notPinned,%notSourcePinned
  %q2 = and i1 %private,%stack
  %q3 = and i1 %facts,%output
  %q01 = and i1 %q0,%q1
  %q23 = and i1 %q2,%q3
  %clean = and i1 %q01,%q23
  br i1 %clean,label %operationCheck,label %bad
operationCheck:
  %known = icmp ule i64 %operation,2
  %query = icmp eq i64 %operation,0
  br i1 %known,label %request,label %bad
request:
  br i1 %query,label %end,label %budget
budget:
  %positive = icmp ne i64 %count,0
  %alignmentNonzero = icmp ne i64 %alignment,0
  %minus = sub i64 %alignment,1
  %mask = and i64 %alignment,%minus
  %power = icmp eq i64 %mask,0
  %frames = call i64 @t.word(ptr @topal_x86_frame_history_v1,i64 0)
  %loans = call i64 @t.word(ptr @topal_x86_frame_history_v1,i64 1)
  %generation = call i64 @t.word(ptr @topal_x86_frame_history_v1,i64 2)
  ; The generator checks these products using reconstructed source costs and
  ; maximum architectural N. Include the terminal step and virgin identity 2.
  %double = mul i64 %n,2
  %work = add i64 %double,4
  %frameCost = mul i64 %work,53
  %loanCost = mul i64 %work,38
  %frameBudget = add i64 %frameCost,2
  %loanBudget = add i64 %loanCost,2
  %frameLimit = sub i64 -1,%frameBudget
  %loanLimit = sub i64 -1,%loanBudget
  %frameRoom = icmp ule i64 %frames,%frameLimit
  %loanRoom = icmp ule i64 %loans,%loanLimit
  %generationRoom = icmp ne i64 %generation,-1
  %noFrames = icmp eq i64 %frames,0
  %noLoans = icmp eq i64 %loans,0
  %noGeneration = icmp eq i64 %generation,0
  %noIds = and i1 %noFrames,%noLoans
  %virgin = and i1 %noIds,%noGeneration
  %validFrames = icmp uge i64 %frames,2
  %validLoans = icmp uge i64 %loans,2
  %validGeneration = icmp ne i64 %generation,0
  %validIds = and i1 %validFrames,%validLoans
  %old = and i1 %validIds,%validGeneration
  %validHistory = or i1 %virgin,%old
  %r0 = and i1 %positive,%alignmentNonzero
  %r1 = and i1 %power,%frameRoom
  %r2 = and i1 %loanRoom,%generationRoom
  %r01 = and i1 %r0,%r1
  %safeBudget = and i1 %r01,%r2
  %admitted = and i1 %safeBudget,%validHistory
  ret i1 %admitted
end:
  ret i1 true
bad:
  ret i1 false
}

define internal i1 @r.pool_token_domain(ptr %ctx,ptr %token,i1 %write) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %owned = icmp eq ptr %ctx,@topal_x86_frame_context_v1
  br i1 %owned,label %domain,label %bad
domain:
  %n = call i64 @t.word(ptr %ctx,i64 3)
  %size = mul i64 %n,24
  %p = ptrtoint ptr %token to i64
  %base = ptrtoint ptr @topal_x86_frame_tokens_v1 to i64
  %offset = sub i64 %p,%base
  %lower = icmp uge i64 %p,%base
  %upper = icmp ult i64 %offset,%size
  %rem = urem i64 %offset,24
  %aligned = icmp eq i64 %rem,0
  %capacity = icmp ule i64 %n,262144
  %a = and i1 %lower,%upper
  %b = and i1 %aligned,%capacity
  %valid = and i1 %a,%b
  ret i1 %valid
bad:
  ret i1 false
}
define i1 @topal_frame_kernel_facts_domain_v1(ptr %ctx,ptr %facts,i64 %bytes) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %owned = icmp eq ptr %ctx,@topal_x86_frame_context_v1
  %domain = icmp eq ptr %facts,@topal_x86_frame_details_v1
  %size = icmp eq i64 %bytes,32
  %a = and i1 %owned,%domain
  %valid = and i1 %a,%size
  ret i1 %valid
}

define i1 @topal_frame_kernel_zero_v1(ptr %ctx,i64 %physical,i64 %count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %owned = icmp eq ptr %ctx,@topal_x86_frame_context_v1
  br i1 %owned,label %hardware,label %bad
hardware:
  %boot = call i1 @t.bootstrap()
  br i1 %boot,label %check,label %bad
check:
  %state = call i64 @t.word(ptr %ctx,i64 0)
  %n = call i64 @t.word(ptr %ctx,i64 3)
  %id = call i64 @t.word(ptr %ctx,i64 2)
  %start = call i64 @t.word(ptr %ctx,i64 13)
  %pendingCount = call i64 @t.word(ptr %ctx,i64 14)
  %pendingId = call i64 @t.word(ptr %ctx,i64 15)
  %active = load ptr,ptr @topal_frame_allocator_active_v1,align 8
  %busy = icmp eq i64 %state,2
  %pinned = icmp eq ptr %active,%ctx
  %sameCount = icmp eq i64 %count,%pendingCount
  %sameId = icmp eq i64 %id,%pendingId
  %positive = icmp ne i64 %count,0
  %inside = icmp ult i64 %start,%n
  %capacity = icmp ule i64 %n,262144
  %left = sub i64 %n,%start
  %fits = icmp ule i64 %count,%left
  %physicalEnd = add i64 %physical,%count
  %nowrap = icmp ugt i64 %physicalEnd,%physical
  %mapped = icmp ule i64 %physicalEnd,262144
  %a = and i1 %busy,%pinned
  %b = and i1 %sameCount,%sameId
  %c = and i1 %positive,%inside
  %d = and i1 %capacity,%fits
  %e = and i1 %nowrap,%mapped
  %ab = and i1 %a,%b
  %cd = and i1 %c,%d
  %abcd = and i1 %ab,%cd
  %valid = and i1 %abcd,%e
  br i1 %valid,label %reservations,label %bad
reservations:
  %address = shl i64 %physical,12
  %limit = shl i64 %physicalEnd,12
  %imageEnd = call i64 @t.word(ptr @topal_x86_frame_handoff_v1,i64 1)
  %resource = call i64 @t.word(ptr @topal_x86_frame_handoff_v1,i64 2)
  %resourceEnd = call i64 @t.word(ptr @topal_x86_frame_handoff_v1,i64 3)
  %above = icmp uge i64 %address,%imageEnd
  %before = icmp ule i64 %limit,%resource
  %after = icmp uge i64 %address,%resourceEnd
  %disjoint = or i1 %before,%after
  %safe = and i1 %above,%disjoint
  br i1 %safe,label %loop,label %bad
loop:
  %i = phi i64 [0,%reservations],[%next,%advance]
  %more = icmp ult i64 %i,%count
  br i1 %more,label %cell,label %zero
cell:
  %index = add i64 %start,%i
  %offset = mul i64 %index,24
  %body = add i64 %offset,128
  %ptr = getelementptr i8,ptr @topal_x86_frame_table_v1,i64 %body
  %cellId = call i64 @t.word(ptr %ptr,i64 0)
  %tag = call i64 @t.word(ptr %ptr,i64 1)
  %frame = call i64 @t.word(ptr %ptr,i64 2)
  %expected = add i64 %physical,%i
  %identity = icmp eq i64 %cellId,%id
  %provenance = icmp eq i64 %tag,1
  %contiguous = icmp eq i64 %frame,%expected
  %f = and i1 %identity,%provenance
  %ok = and i1 %f,%contiguous
  br i1 %ok,label %advance,label %bad
advance:
  %next = add i64 %i,1
  br label %loop
zero:
  %ptrPhysical = inttoptr i64 %address to ptr
  %bytes = shl i64 %count,12
  call void @t.zero(ptr %ptrPhysical,i64 %bytes)
  ret i1 true
bad:
  ret i1 false
}

; Nonreturning component failure. This retires the actual source domains but
; deliberately grants NO owning-caller retirement/publication certificate.
; A qualified gateway must retire its complete stack and recovery state too.
define void @topal_frame_kernel_fatal_v1(ptr %ctx) nounwind noinline noreturn noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  store volatile i64 3,ptr @topal_x86_frame_mm_state_v1,align 8
  %owned = icmp eq ptr %ctx,@topal_x86_frame_context_v1
  br i1 %owned,label %retire,label %halt
retire:
  call void @t.put(ptr %ctx,i64 0,i64 3)
  call void @t.put(ptr @topal_x86_frame_history_v1,i64 3,i64 0)
  call void @t.put(ptr @topal_x86_frame_history_v1,i64 4,i64 1)
  call void @t.zero(ptr @topal_x86_frame_private_v1,i64 65528)
  call void @t.zero(ptr @topal_x86_frame_stack_v1,i64 4096)
  call void @t.zero(ptr @topal_x86_frame_facts_v1,i64 24)
  call void @t.zero(ptr @topal_x86_frame_output_v1,i64 56)
  call void @t.zero(ptr @topal_x86_frame_details_v1,i64 32)
  store ptr null,ptr @topal_frame_allocator_active_v1,align 8
  store ptr null,ptr @topal_x86_tail_boundary_active_v1,align 8
  br label %halt
halt:
  call void @topal_x86_frame_target_halt_v1()
  unreachable
}
define void @topal_x86_frame_target_halt_v1() nounwind noinline noreturn noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %halt
halt:
  call void @topal_x86_frame_gateway_abort_v1()
  unreachable
}
; Private current invocation lease. Only the owning machine gateway writes it.
declare void @topal_x86_frame_gateway_abort_v1() noreturn
@topal_x86_frame_gateway_recovery_v1 = external global [6 x i64]
define internal i1 @g.lease() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %live = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 1)
  %saved = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 0)
  %pin = icmp eq i64 %live,1
  %low = icmp uge i64 %saved,1085456
  %high = icmp ule i64 %saved,1572808
  %mask = and i64 %saved,15
  %alignment = icmp eq i64 %mask,8
  %sp = call i64 asm sideeffect "movq %rsp, $0", "=r,~{dirflag},~{fpsr},~{flags}"()
  %bottom = sub i64 %saved,3952
  %above = icmp uge i64 %sp,%bottom
  %below = icmp ule i64 %sp,%saved
  %a = and i1 %pin,%low
  %b = and i1 %high,%alignment
  %c = and i1 %above,%below
  %ab = and i1 %a,%b
  %owned = and i1 %ab,%c
  %memoryContext = call i1 @g.memory_context()
  %combined = and i1 %owned,%memoryContext
  ret i1 %combined
}

@topal_x86_frame_root_tokens_v1 = external global [336 x i8]
; The root compiler allocates one private slot per affine IR definition. These
; are value storage, not registry capacity or an application allocation quota.
define internal i1 @mm.previous_token_domain(ptr %ctx,ptr %token,i1 %write) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %pool = call i1 @r.pool_token_domain(ptr %ctx,ptr %token,i1 %write)
  %owned = icmp eq ptr %ctx,@topal_x86_frame_context_v1
  %p = ptrtoint ptr %token to i64
  %start = ptrtoint ptr @topal_x86_frame_root_tokens_v1 to i64
  %end = add i64 %start,336
  %nowrap = icmp ugt i64 %end,%start
  %offset = sub i64 %p,%start
  %lower = icmp uge i64 %p,%start
  %upper = icmp ult i64 %offset,336
  %remainder = urem i64 %offset,24
  %aligned = icmp eq i64 %remainder,0
  %a = and i1 %owned,%nowrap
  %b = and i1 %lower,%upper
  %ab = and i1 %a,%b
  %root = and i1 %ab,%aligned
  %valid = or i1 %pool,%root
  ret i1 %valid
}
@topal_bootstrap_storage = external global [0 x i8]
@topal_x86_frame_mm_tokens_v1 = external global [6 x i64]
@topal_x86_frame_mm_state_v1 = external global [4 x i64]
@topal_x86_frame_mm_epoch_v1 = external global [2 x i64]
@topal_x86_frame_mm_brk_return_v1 = external global i8
@topal_x86_frame_mm_exec_return_v1 = external global i8
@topal_x86_frame_mm_cleanup_return_v1 = external global i8

define internal i1 @g.memory_context() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %op = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 2)
  %ctx = getelementptr i8,ptr @topal_bootstrap_storage,i64 512
  %state = call i64 @t.word(ptr %ctx,i64 0)
  %saved = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 0)
  %identity = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 5)
  %user_extent = icmp eq i64 %op,8
  br i1 %user_extent,label %user_observation,label %original_context
user_observation:
  %user_owned = call i1 @u.syscall_context(i64 %saved,i64 %identity)
  ret i1 %user_owned
original_context:
  %boot = icmp ult i64 %op,5
  br i1 %boot,label %bootstrap,label %memory
bootstrap:
  %notUser = icmp ne i64 %state,1
  %noIdentity = icmp eq i64 %identity,0
  %normal = and i1 %notUser,%noIdentity
  ret i1 %normal
memory:
  %oldKnown = icmp ule i64 %op,7
  %processLow = icmp uge i64 %op,9
  %processHigh = icmp ule i64 %op,13
  %process = and i1 %processLow,%processHigh
  %known = or i1 %oldKnown,%process
  %cleanup = icmp eq i64 %op,6
  %liveState = select i1 %cleanup,i64 2,i64 1
  %live = icmp eq i64 %state,%liveState
  %stack = call i64 @t.word(ptr %ctx,i64 1)
  %expected = add i64 %saved,64
  %sameStack = icmp eq i64 %stack,%expected
  %offset = select i1 %cleanup,i64 2,i64 3
  %root = call i64 @t.word(ptr %ctx,i64 %offset)
  %cr3 = call i64 asm sideeffect "movq %cr3, $0", "=r,~{dirflag},~{fpsr},~{flags}"()
  %sameRoot = icmp eq i64 %root,%cr3
  %msr = select i1 %cleanup,i32 -1073741566,i32 -1073741567
  %halves = call {i32,i32} asm sideeffect "rdmsr", "={ax},={dx},{cx},~{dirflag},~{fpsr},~{flags}"(i32 %msr)
  %lo32 = extractvalue {i32,i32} %halves,0
  %hi32 = extractvalue {i32,i32} %halves,1
  %lo = zext i32 %lo32 to i64
  %hi = zext i32 %hi32 to i64
  %upper = shl i64 %hi,32
  %gs = or i64 %lo,%upper
  %contextWord = ptrtoint ptr %ctx to i64
  %sameGs = icmp eq i64 %gs,%contextWord
  %epoch = call i64 @t.word(ptr @topal_x86_frame_mm_epoch_v1,i64 0)
  %number = call i64 @t.word(ptr @topal_x86_frame_mm_epoch_v1,i64 1)
  %sameEpoch = icmp eq i64 %epoch,%identity
  %nonzero = icmp ne i64 %epoch,0
  %brk = icmp eq i64 %op,5
  %request = select i1 %brk,i64 12,i64 59
  %requestOk = icmp eq i64 %number,%request
  %exit = icmp eq i64 %number,60
  %exitGroup = icmp eq i64 %number,231
  %exitOk = or i1 %exit,%exitGroup
  %oldAbi = select i1 %cleanup,i1 %exitOk,i1 %requestOk
  %processAbi = call i1 @p.abi(i64 %op,i64 %number)
  %abi = select i1 %process,i1 %processAbi,i1 %oldAbi
  %brkReturn = ptrtoint ptr @topal_x86_frame_mm_brk_return_v1 to i64
  %execReturn = ptrtoint ptr @topal_x86_frame_mm_exec_return_v1 to i64
  %cleanupReturn = ptrtoint ptr @topal_x86_frame_mm_cleanup_return_v1 to i64
  %syscallReturn = select i1 %brk,i64 %brkReturn,i64 %execReturn
  %oldReturn = select i1 %cleanup,i64 %cleanupReturn,i64 %syscallReturn
  %processReturn = call i64 @p.return_site(i64 %op)
  %returnSite = select i1 %process,i64 %processReturn,i64 %oldReturn
  %wordAt = add i64 %saved,48
  %returnAt = inttoptr i64 %wordAt to ptr
  %actual = load volatile i64,ptr %returnAt,align 8
  %sameSite = icmp eq i64 %actual,%returnSite
  %a = and i1 %known,%live
  %b = and i1 %sameStack,%sameRoot
  %c = and i1 %sameGs,%sameEpoch
  %d = and i1 %nonzero,%abi
  %ab = and i1 %a,%b
  %cd = and i1 %c,%d
  %abcd = and i1 %ab,%cd
  %valid = and i1 %abcd,%sameSite
  ret i1 %valid
}

define i1 @topal_frame_kernel_token_domain_v1(ptr %ctx,ptr %token,i1 %write) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %old = call i1 @mm.previous_token_domain(ptr %ctx,ptr %token,i1 %write)
  %owned = icmp eq ptr %ctx,@topal_x86_frame_context_v1
  %p = ptrtoint ptr %token to i64
  %base = ptrtoint ptr @topal_x86_frame_mm_tokens_v1 to i64
  %second = add i64 %base,24
  %first = icmp eq i64 %p,%base
  %next = icmp eq i64 %p,%second
  %either = or i1 %first,%next
  %prepared = icmp eq ptr %token,@topal_x86_process_mm_prepared_token_v1
  %inactive = icmp eq ptr %token,@topal_x86_process_mm_inactive_token_v1
  %extra = or i1 %prepared,%inactive
  %mmEither = or i1 %either,%extra
  %mm = and i1 %owned,%mmEither
  %ok = or i1 %old,%mm
  ret i1 %ok
}
; Private actual-root target. This component alone grants no publication route.
@topal_x86_user_extent_return_v1 = external global i8

define internal void @u.require(i1 %ok) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  br i1 %ok,label %end,label %bad
bad:
  call void @topal_x86_user_extent_fatal_v1()
  unreachable
end:
  ret void
}
define internal i64 @u.msr(i32 %number) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %halves = call {i32,i32} asm sideeffect "rdmsr", "={ax},={dx},{cx},~{dirflag},~{fpsr},~{flags}"(i32 %number)
  %a = extractvalue {i32,i32} %halves,0
  %b = extractvalue {i32,i32} %halves,1
  %lo = zext i32 %a to i64
  %hi = zext i32 %b to i64
  %shift = shl i64 %hi,32
  %word = or i64 %lo,%shift
  ret i64 %word
}

; Called by g.lease for operation 8; must not recurse into g.lease itself.
; The exact emitted site and live captured entry establish caller identity;
; stack geometry alone cannot create the lease. Complete outer caller costs
; remain a separate proof before all-caller integration.
define internal i1 @u.syscall_context(i64 %saved,i64 %identity) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ctx = getelementptr i8,ptr @topal_bootstrap_storage,i64 512
  %state = call i64 @t.word(ptr %ctx,i64 0)
  %self = call i64 @t.word(ptr %ctx,i64 32)
  %stack = call i64 @t.word(ptr %ctx,i64 1)
  %root = call i64 @t.word(ptr %ctx,i64 3)
  %epoch = call i64 @t.word(ptr @topal_x86_frame_mm_epoch_v1,i64 0)
  %gs = call i64 @u.msr(i32 -1073741567)
  %cr3 = call i64 asm sideeffect "movq %cr3, $0", "=r,~{dirflag},~{fpsr},~{flags}"()
  %live = icmp eq i64 %state,1
  %ctx_word = ptrtoint ptr %ctx to i64
  %self_ok = icmp eq i64 %self,%ctx_word
  %gs_ok = icmp eq i64 %gs,%ctx_word
  %root_ok = icmp eq i64 %root,%cr3
  %epoch_ok = icmp eq i64 %epoch,%identity
  %nonzero = icmp ne i64 %identity,0
  %caller = add i64 %saved,64
  %nowrap = icmp ugt i64 %caller,%saved
  %inside = icmp ule i64 %caller,%stack
  %top_owned = icmp ule i64 %stack,1572864
  %top_low = icmp uge i64 %stack,1085456
  %saved_low = icmp uge i64 %saved,1085456
  %saved_high = icmp ule i64 %saved,1572808
  %align_bits = and i64 %saved,15
  %aligned = icmp eq i64 %align_bits,8
  %a = and i1 %live,%self_ok
  %b = and i1 %gs_ok,%root_ok
  %c = and i1 %epoch_ok,%nonzero
  %d = and i1 %nowrap,%inside
  %e = and i1 %top_owned,%top_low
  %f = and i1 %saved_low,%saved_high
  %ab = and i1 %a,%b
  %cd = and i1 %c,%d
  %ef = and i1 %e,%f
  %abcd = and i1 %ab,%cd
  %rest = and i1 %ef,%aligned
  %safe = and i1 %abcd,%rest
  br i1 %safe,label %site,label %refuse
site:
  call void asm sideeffect "lfence", "~{memory},~{dirflag},~{fpsr},~{flags}"()
  %return_word = add i64 %saved,48
  %return_at = inttoptr i64 %return_word to ptr
  %actual_site = load volatile i64,ptr %return_at,align 8
  %site_ok = icmp eq i64 %actual_site,ptrtoint (ptr @topal_x86_user_extent_return_v1 to i64)
  ret i1 %site_ok
refuse:
  ret i1 false
}
define internal void @u.check(i64 %identity) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %admit = call i1 @topal_frame_kernel_admit_v1(ptr @topal_x86_frame_context_v1,i64 0,i64 0,i64 0)
  call void @u.require(i1 %admit)
  %op = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 2)
  %entry = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 5)
  %known = icmp eq i64 %op,8
  %same = icmp eq i64 %entry,%identity
  %nonzero = icmp ne i64 %identity,0
  %a = and i1 %known,%same
  %ok = and i1 %a,%nonzero
  call void @u.require(i1 %ok)
  ret void
}

; Read-only whole-token/registry/cell validation. No resolve fact staging and no
; source call. The source/controller protocol preserves normalized physical and
; provenance columns; all token pointers below are private compiled bindings.
define internal i64 @u.owner(ptr %token,i64 %count,i64 %pins) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %n = call i64 @t.word(ptr @topal_x86_frame_context_v1,i64 3)
  %issuer = call i64 @t.word(ptr %token,i64 0)
  %id = call i64 @t.word(ptr %token,i64 1)
  %slot = call i64 @t.word(ptr %token,i64 2)
  %next = call i64 @t.word(ptr @topal_x86_frame_context_v1,i64 2)
  %issuer_ok = icmp eq i64 %issuer,1
  %id_nonzero = icmp ne i64 %id,0
  %id_issued = icmp ult i64 %id,%next
  %inside = icmp ult i64 %slot,%n
  %positive = icmp ne i64 %count,0
  %a = and i1 %issuer_ok,%id_nonzero
  %b = and i1 %id_issued,%inside
  %ab = and i1 %a,%b
  %valid = and i1 %ab,%positive
  call void @u.require(i1 %valid)
  call void asm sideeffect "lfence", "~{memory},~{dirflag},~{fpsr},~{flags}"()
  %offset = mul i64 %slot,64
  %record = getelementptr i8,ptr @topal_x86_frame_registry_v1,i64 %offset
  %r0 = call i64 @t.word(ptr %record,i64 0)
  %r1 = call i64 @t.word(ptr %record,i64 1)
  %start = call i64 @t.word(ptr %record,i64 2)
  %r3 = call i64 @t.word(ptr %record,i64 3)
  %r4 = call i64 @t.word(ptr %record,i64 4)
  %provenance = call i64 @t.word(ptr %record,i64 5)
  %r6 = call i64 @t.word(ptr %record,i64 6)
  %r7 = call i64 @t.word(ptr %record,i64 7)
  %end = add i64 %start,%count
  %end_wrap = icmp ugt i64 %end,%start
  %end_inside = icmp ule i64 %end,%n
  %same_issuer = icmp eq i64 %r0,%issuer
  %same_id = icmp eq i64 %r1,%id
  %same_count = icmp eq i64 %r3,%count
  %alignment = icmp eq i64 %r4,1
  %tag = icmp ne i64 %provenance,0
  %pinned = icmp eq i64 %r6,%pins
  %live = icmp eq i64 %r7,1
  %c = and i1 %end_wrap,%end_inside
  %d = and i1 %same_issuer,%same_id
  %e = and i1 %same_count,%alignment
  %f = and i1 %tag,%pinned
  %cd = and i1 %c,%d
  %ef = and i1 %e,%f
  %cdef = and i1 %cd,%ef
  %registry_valid = and i1 %cdef,%live
  call void @u.require(i1 %registry_valid)
  call void asm sideeffect "lfence", "~{memory},~{dirflag},~{fpsr},~{flags}"()
  %cell_offset = mul i64 %start,24
  %first_offset = add i64 %cell_offset,128
  %first = getelementptr i8,ptr @topal_x86_frame_table_v1,i64 %first_offset
  %frame = call i64 @t.word(ptr %first,i64 2)
  %last_frame = add i64 %frame,%count
  %frame_wrap = icmp ugt i64 %last_frame,%frame
  %accessible = icmp ule i64 %last_frame,262144
  %physical_valid = and i1 %frame_wrap,%accessible
  call void @u.require(i1 %physical_valid)
  br label %cells
cells:
  %i = phi i64 [0,%entry],[%after,%cell]
  %more = icmp ult i64 %i,%count
  br i1 %more,label %cell,label %done
cell:
  %delta = mul i64 %i,24
  %at = getelementptr i8,ptr %first,i64 %delta
  %actual_id = call i64 @t.word(ptr %at,i64 0)
  %actual_tag = call i64 @t.word(ptr %at,i64 1)
  %actual_frame = call i64 @t.word(ptr %at,i64 2)
  %expected_frame = add i64 %frame,%i
  %id_ok = icmp eq i64 %actual_id,%id
  %tag_ok = icmp eq i64 %actual_tag,%provenance
  %frame_ok = icmp eq i64 %actual_frame,%expected_frame
  %both = and i1 %id_ok,%tag_ok
  %cell_valid = and i1 %both,%frame_ok
  call void @u.require(i1 %cell_valid)
  %after = add i64 %i,1
  br label %cells
done:
  %base = shl i64 %frame,12
  ret i64 %base
}

define internal i64 @u.static_owner(i64 %role) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  switch i64 %role,label %bad [i64 0,label %hierarchy i64 1,label %low i64 2,label %image i64 3,label %stack]
hierarchy:
  %h = getelementptr i8,ptr @topal_x86_frame_root_tokens_v1,i64 168
  %hv = call i64 @u.owner(ptr %h,i64 5,i64 1)
  ret i64 %hv
low:
  %l = getelementptr i8,ptr @topal_x86_frame_root_tokens_v1,i64 144
  %lv = call i64 @u.owner(ptr %l,i64 1,i64 1)
  ret i64 %lv
image:
  %m = getelementptr i8,ptr @topal_x86_frame_root_tokens_v1,i64 120
  %mv = call i64 @u.owner(ptr %m,i64 503,i64 1)
  ret i64 %mv
stack:
  %s = getelementptr i8,ptr @topal_x86_frame_root_tokens_v1,i64 192
  %sv = call i64 @u.owner(ptr %s,i64 2,i64 2)
  ret i64 %sv
bad:
  call void @topal_x86_user_extent_fatal_v1()
  unreachable
}

define i64 @topal_x86_user_extent_begin_v1() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %identity = call i64 @t.word(ptr @topal_x86_frame_gateway_recovery_v1,i64 5)
  call void @u.check(i64 %identity)
  %cr0 = call i64 asm sideeffect "movq %cr0, $0", "=r,~{dirflag},~{fpsr},~{flags}"()
  %cr4 = call i64 asm sideeffect "movq %cr4, $0", "=r,~{dirflag},~{fpsr},~{flags}"()
  %efer = call i64 @u.msr(i32 -1073741696)
  %apic = call i64 @u.msr(i32 27)
  %required_cr0 = and i64 %cr0,2147549185
  %cr0_ok = icmp eq i64 %required_cr0,2147549185
  ; LA57, PCID, SMAP, PKE, CET and PKS need distinct qualification.
  %extra_modes = and i64 %cr4,31592448
  %cr4_ok = icmp eq i64 %extra_modes,0
  %required_efer = and i64 %efer,3328
  %efer_ok = icmp eq i64 %required_efer,3328
  %bsp_bit = and i64 %apic,256
  %bsp = icmp ne i64 %bsp_bit,0
  %a = and i1 %cr0_ok,%cr4_ok
  %b = and i1 %efer_ok,%bsp
  %mode = and i1 %a,%b
  %result = select i1 %mode,i64 %identity,i64 0
  ret i64 %result
}
define i64 @topal_x86_user_extent_root_v1(i64 %identity) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  call void @u.check(i64 %identity)
  %owned = call i64 @u.static_owner(i64 0)
  %ctx = getelementptr i8,ptr @topal_bootstrap_storage,i64 512
  %actual = call i64 @t.word(ptr %ctx,i64 3)
  %same = icmp eq i64 %owned,%actual
  call void @u.require(i1 %same)
  ret i64 %owned
}
define ptr @topal_x86_user_extent_table_v1(i64 %identity,i64 %root,i64 %physical,i64 %level) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %current = call i64 @topal_x86_user_extent_root_v1(i64 %identity)
  %same = icmp eq i64 %root,%current
  call void @u.require(i1 %same)
  %low = call i64 @u.static_owner(i64 1)
  %l4 = icmp eq i64 %level,4
  %p4 = icmp eq i64 %physical,%root
  %a = and i1 %l4,%p4
  %p3word = add i64 %root,4096
  %l3 = icmp eq i64 %level,3
  %p3 = icmp eq i64 %physical,%p3word
  %b = and i1 %l3,%p3
  %p2word = add i64 %root,8192
  %p2other = add i64 %root,12288
  %l2 = icmp eq i64 %level,2
  %p2a = icmp eq i64 %physical,%p2word
  %p2b = icmp eq i64 %physical,%p2other
  %p2 = or i1 %p2a,%p2b
  %c = and i1 %l2,%p2
  %high = add i64 %root,16384
  %l1 = icmp eq i64 %level,1
  %p1a = icmp eq i64 %physical,%low
  %p1b = icmp eq i64 %physical,%high
  %p1 = or i1 %p1a,%p1b
  %d = and i1 %l1,%p1
  %ab = or i1 %a,%b
  %cd = or i1 %c,%d
  %valid = or i1 %ab,%cd
  %pointer = inttoptr i64 %physical to ptr
  %result = select i1 %valid,ptr %pointer,ptr null
  ret ptr %result
}

; A runtime heap allocation is distinct from every statically bound root
; allocation, including retained translation storage. Issued identities are
; monotonic within the single validated allocator issuer. Historical root slots
; can only cause rejection; they cannot supply backing authority.
define internal i64 @u.heap_owner(i64 %count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %base = call i64 @u.owner(ptr @topal_x86_frame_mm_tokens_v1,i64 %count,i64 1)
  %identity = call i64 @t.word(ptr @topal_x86_frame_mm_tokens_v1,i64 1)
  br label %slots
slots:
  %i = phi i64 [0,%entry],[%next,%slot]
  %more = icmp ult i64 %i,14
  br i1 %more,label %slot,label %done
slot:
  %offset = mul i64 %i,24
  %token = getelementptr i8,ptr @topal_x86_frame_root_tokens_v1,i64 %offset
  %root_identity = call i64 @t.word(ptr %token,i64 1)
  %distinct = icmp ne i64 %identity,%root_identity
  call void @u.require(i1 %distinct)
  %next = add i64 %i,1
  br label %slots
done:
  ret i64 %base
}

define i64 @topal_x86_user_extent_backing_v1(i64 %identity,i64 %root,i64 %virtual,i64 %physical,i64 %write) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %current = call i64 @topal_x86_user_extent_root_v1(i64 %identity)
  %same = icmp eq i64 %root,%current
  call void @u.require(i1 %same)
  %image_low = icmp uge i64 %virtual,4194304
  %image_high = icmp ult i64 %virtual,6254592
  %image = and i1 %image_low,%image_high
  br i1 %image,label %image_owner,label %stack_range
image_owner:
  %image_base = call i64 @u.static_owner(i64 2)
  %image_offset = sub i64 %virtual,4194304
  %image_expected = add i64 %image_base,%image_offset
  %image_same = icmp eq i64 %physical,%image_expected
  call void @u.require(i1 %image_same)
  %ctx = getelementptr i8,ptr @topal_bootstrap_storage,i64 512
  %phase_at = getelementptr i8,ptr %ctx,i64 104
  %phase = load volatile i8,ptr %phase_at,align 1
  %relro = icmp uge i8 %phase,9
  %write_start = select i1 %relro,i64 6213632,i64 6180864
  %image_writable = icmp uge i64 %virtual,%write_start
  %output = icmp eq i64 %write,1
  %readonly = xor i1 %image_writable,true
  %denied = and i1 %output,%readonly
  %image_result = select i1 %denied,i64 1,i64 0
  ret i64 %image_result
stack_range:
  %stack_low = icmp uge i64 %virtual,8380416
  %stack_high = icmp ult i64 %virtual,8388608
  %stack = and i1 %stack_low,%stack_high
  br i1 %stack,label %stack_owner,label %heap
stack_owner:
  %stack_base = call i64 @u.static_owner(i64 3)
  %stack_offset = sub i64 %virtual,8380416
  %stack_expected = add i64 %stack_base,%stack_offset
  %stack_same = icmp eq i64 %physical,%stack_expected
  call void @u.require(i1 %stack_same)
  ret i64 0
heap:
  %state = call i64 @t.word(ptr @topal_x86_frame_mm_state_v1,i64 0)
  %count = call i64 @t.word(ptr @topal_x86_frame_mm_state_v1,i64 2)
  %base = call i64 @t.word(ptr @topal_x86_frame_mm_state_v1,i64 3)
  %live = icmp eq i64 %state,1
  %positive = icmp ne i64 %count,0
  %bounded = icmp ule i64 %count,519
  %size = shl i64 %count,12
  %end = add i64 %size,6254592
  %heap_low = icmp uge i64 %virtual,6254592
  %heap_high = icmp ult i64 %virtual,%end
  %a = and i1 %live,%positive
  %b = and i1 %bounded,%heap_low
  %ab = and i1 %a,%b
  %valid = and i1 %ab,%heap_high
  call void @u.require(i1 %valid)
  %heap_base = call i64 @u.heap_owner(i64 %count)
  %heap_offset = sub i64 %virtual,6254592
  %heap_expected = add i64 %heap_base,%heap_offset
  %heap_same = icmp eq i64 %physical,%heap_expected
  %base_same = icmp eq i64 %base,%heap_base
  %ok = and i1 %heap_same,%base_same
  call void @u.require(i1 %ok)
  ret i64 0
}
; Validation closes here; actual entry/table/backing owners must remain held
; through the caller's copy. A future target must not drop its mapping lock here.
define void @topal_x86_user_extent_end_v1(i64 %identity,i64 %root) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  %actual = call i64 @topal_x86_user_extent_root_v1(i64 %identity)
  %same = icmp eq i64 %actual,%root
  call void @u.require(i1 %same)
  ret void
}
define void @topal_x86_user_extent_fatal_v1() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
  call void @topal_frame_kernel_fatal_v1(ptr @topal_x86_frame_context_v1)
  unreachable
}

@topal_x86_process_mm_prepared_token_v1 = external global [3 x i64]
; TK-DEC-284 private process caller identities. Hardware observations remain
; in the existing g.memory_context and owning gateway; no source entry is added.
@topal_x86_process_mm_inactive_token_v1 = external global [3 x i64]
@topal_x86_process_mm_prepare_return_v1 = external global i8
@topal_x86_process_mm_commit_return_v1 = external global i8
@topal_x86_process_mm_switch_return_v1 = external global i8
@topal_x86_process_mm_child_exit_return_v1 = external global i8
@topal_x86_process_mm_cancel_return_v1 = external global i8

define internal i1 @p.abi(i64 %op,i64 %number) nounwind noinline noredzone {
entry:
  switch i64 %op,label %bad [i64 9,label %creation
    i64 10,label %creation i64 11,label %switch i64 12,label %exit i64 13,label %exit]
creation:
  %fork = icmp eq i64 %number,57
  %clone = icmp eq i64 %number,56
  %create = or i1 %fork,%clone
  ret i1 %create
switch:
  %read = icmp eq i64 %number,0
  %write = icmp eq i64 %number,1
  %readv = icmp eq i64 %number,19
  %writev = icmp eq i64 %number,20
  %yield = icmp eq i64 %number,24
  %wait = icmp eq i64 %number,61
  %a = or i1 %read,%write
  %b = or i1 %readv,%writev
  %c = or i1 %yield,%wait
  %ab = or i1 %a,%b
  %ok = or i1 %ab,%c
  ret i1 %ok
exit:
  %one = icmp eq i64 %number,60
  %group = icmp eq i64 %number,231
  %leave = or i1 %one,%group
  ret i1 %leave
bad:
  ret i1 false
}
define internal i64 @p.return_site(i64 %op) nounwind noinline noredzone {
entry:
  switch i64 %op,label %bad [i64 9,label %prepare
    i64 10,label %commit i64 11,label %switch i64 12,label %exit i64 13,label %cancel]
prepare:
  ret i64 ptrtoint (ptr @topal_x86_process_mm_prepare_return_v1 to i64)
commit:
  ret i64 ptrtoint (ptr @topal_x86_process_mm_commit_return_v1 to i64)
switch:
  ret i64 ptrtoint (ptr @topal_x86_process_mm_switch_return_v1 to i64)
exit:
  ret i64 ptrtoint (ptr @topal_x86_process_mm_child_exit_return_v1 to i64)
cancel:
  ret i64 ptrtoint (ptr @topal_x86_process_mm_cancel_return_v1 to i64)
bad:
  ret i64 0
}
