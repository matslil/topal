"""Small streaming identity audit; no model replay, VM or kernel rebuild."""
import hashlib
import json
from pathlib import Path
import re

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
names=['process-mm-publication-initial','process-mm-publication-retry-1',
       'process-mm-publication-retry-2','process-mm-publication-matrix']
def sha(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        while block:=stream.read(1024*1024):value.update(block)
    return value.hexdigest()
rows=[]
for name in names:
    folder=cache/name;run=json.loads((folder/'run.json').read_text())
    assert not run['source_changes_during_run']
    assert run['source_hashes_before']==run['source_hashes_after']
    saved=folder/'history-inputs'
    manifest=json.loads((saved/'manifest.json').read_text())
    hashes=manifest.get('source_hashes',manifest)
    for path,fact in hashes.items():
        expected=fact['sha256'] if isinstance(fact,dict) else fact
        target=(saved/path).resolve();assert target.is_relative_to(saved)
        assert sha(target)==expected,path
        if path in run['source_hashes_before']:assert run['source_hashes_before'][path]==expected,path
    resources=run['resources']
    assert resources['memory.swap.max']=='0'
    assert 0<int(resources['memory.peak'])<=int(resources['memory.max'])
    assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
    if 'cohorts' in run:
        builds=[root/path for cohort in run['cohorts'] for path in cohort['builds']]
    else:
        builds=[Path(path.strip()).resolve() for path in re.findall(r'actual frame source root: ([^\n]+)',(folder/'test.log').read_text())]
    assert builds
    scripts=[]
    model=saved/'linux-kernel/tools/process-memory/publication.py'
    text=model.read_text()
    for build in builds:
        build=build.resolve();assert build.is_relative_to(cache)
        kernel=sha(build/'kernel.elf')
        assert kernel=='b8212e5e9aca715d8db0d863cbc9655ed989c3884b938b57055c3e22e04d0a7c'
        script=build/'process-mm-users/inspect.gdb'
        assert ('exec('+repr(text)+',publication_model)') in script.read_text(),str(script)
        scripts.append(dict(build=build.relative_to(root).as_posix(),kernel_sha256=kernel,
            inspector_sha256=sha(script),embedded_publication_model_sha256=sha(model)))
    rows.append(dict(name=name,exit_code=run['exit_code'],source_inputs=len(hashes),
        reconstructed=manifest.get('reconstructed',[]),
        outside_native_watch=sorted(set(hashes)-set(run['source_hashes_before'])),scripts=scripts))
assert [row['exit_code'] for row in rows]==[101,0,0,1]
report=dict(passed=True,attempts=rows,
    scope='Streaming source/kernel/script identity and recorded resource audit only; no saved-record model replay, current-observer qualification, VM execution or historical rebuild')
target=cache/'process-mm-publication-matrix/history-metadata.json'
target.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(passed=True,attempts=len(rows),native_builds=sum(len(row['scripts']) for row in rows),
    source_inputs=[row['source_inputs'] for row in rows],report=target.relative_to(root).as_posix())))
