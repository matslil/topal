"""Preserve an original metadata manifest and expose its SHA-only projection.

No source bytes, native records, historical result, or current matrix inputs
are changed. The original per-file metadata and original manifest bytes remain.
"""
import hashlib
import json
from pathlib import Path

folder=Path('linux-kernel/.cache/x86_64/process-mm-publication-retry-1/history-inputs')
manifest=folder/'manifest.json';original=folder/'manifest-original.json'
raw=manifest.read_bytes();value=json.loads(raw)
assert 'source_hashes' not in value and not original.exists()
assert all(isinstance(fact,dict) and set(fact)=={'sha256','native_watched_input'} for fact in value.values())
hashes={name:fact['sha256'] for name,fact in value.items()}
for name,sha in hashes.items():
    path=(folder/name).resolve();assert path.is_relative_to(folder.resolve())
    assert hashlib.sha256(path.read_bytes()).hexdigest()==sha,name
original.write_bytes(raw)
projected=dict(value,source_hashes=hashes,
    normalization=dict(original_manifest='manifest-original.json',original_sha256=hashlib.sha256(raw).hexdigest(),
        scope='Added a SHA-only projection of the original per-file records for collector compatibility. Original manifest bytes and all original per-file metadata remain preserved; no source/native bytes or historical execution result changed.'))
manifest.write_text(json.dumps(projected,indent=2)+'\n')
print(json.dumps(dict(passed=True,source_inputs=len(hashes),original_sha256=hashlib.sha256(raw).hexdigest(),
    scope=projected['normalization']['scope'])))
