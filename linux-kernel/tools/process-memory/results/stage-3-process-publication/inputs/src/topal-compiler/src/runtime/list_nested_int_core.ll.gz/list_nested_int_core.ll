; Exact core operations for List (List Int). Outer nodes contain the inner List
; pointer followed by the remaining outer List pointer.

define internal i64 @topal.runtime.list.nested.int.count.raw(ptr %list) nounwind noinline {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop
done:
  ret i64 %count
}

define internal ptr @topal.runtime.list.nested.int.entry.count(ptr %list) nounwind noinline {
entry:
  %count = call i64 @topal.runtime.list.nested.int.count.raw(ptr %list)
  %value = call ptr @topal.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal ptr @topal.runtime.list.nested.int.first(ptr %list) nounwind noinline {
entry:
  %empty = icmp eq ptr %list, null
  br i1 %empty, label %none, label %some
some:
  %value = load ptr, ptr %list, align 8
  %present = call ptr @topal.runtime.optional.some(ptr %value)
  ret ptr %present
none:
  %absent = call ptr @topal.runtime.optional.none()
  ret ptr %absent
}

define internal i1 @topal.runtime.list.nested.int.equal(ptr %left, ptr %right) nounwind noinline {
entry:
  br label %loop
loop:
  %left.current = phi ptr [%left, %entry], [%left.next, %advance]
  %right.current = phi ptr [%right, %entry], [%right.next, %advance]
  %left.empty = icmp eq ptr %left.current, null
  %right.empty = icmp eq ptr %right.current, null
  %either.empty = or i1 %left.empty, %right.empty
  br i1 %either.empty, label %finish, label %compare
compare:
  %left.value = load ptr, ptr %left.current, align 8
  %right.value = load ptr, ptr %right.current, align 8
  %equal = call i1 @topal.runtime.list.int.equal(ptr %left.value, ptr %right.value)
  br i1 %equal, label %advance, label %different
advance:
  %left.next.pointer = getelementptr i8, ptr %left.current, i64 8
  %right.next.pointer = getelementptr i8, ptr %right.current, i64 8
  %left.next = load ptr, ptr %left.next.pointer, align 8
  %right.next = load ptr, ptr %right.next.pointer, align 8
  br label %loop
finish:
  %both.empty = and i1 %left.empty, %right.empty
  ret i1 %both.empty
different:
  ret i1 false
}

define internal ptr @topal.runtime.list.nested.int.insert.everywhere(ptr %list, ptr %value) nounwind noinline {
entry:
  %count = call i64 @topal.runtime.list.int.count.raw(ptr %list)
  %result.count = add i64 %count, 1
  %allocation.length = shl i64 %result.count, 4
  %result = call ptr @topal.platform.allocate(i64 %allocation.length)
  %singleton = call ptr @topal.platform.allocate(i64 16)
  store ptr %value, ptr %singleton, align 8
  %singleton.next = getelementptr i8, ptr %singleton, i64 8
  store ptr null, ptr %singleton.next, align 8
  br label %loop
loop:
  %boundary = phi i64 [0, %entry], [%boundary.next, %advance]
  %inserted = call ptr @topal.runtime.list.int.insert.at(ptr %list, i64 %boundary, ptr %singleton)
  %offset = shl i64 %boundary, 4
  %node = getelementptr i8, ptr %result, i64 %offset
  store ptr %inserted, ptr %node, align 8
  %node.next.pointer = getelementptr i8, ptr %node, i64 8
  %boundary.next = add i64 %boundary, 1
  %complete = icmp eq i64 %boundary.next, %result.count
  %following = getelementptr i8, ptr %node, i64 16
  %next = select i1 %complete, ptr null, ptr %following
  store ptr %next, ptr %node.next.pointer, align 8
  br i1 %complete, label %done, label %advance
advance:
  br label %loop
done:
  ret ptr %result
}
