set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-owners-2429178-1794488720472082309/kernel.elf"
target remote 127.0.0.1:56265
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-owners-2429178-1794488720472082309/process-mm-users-phase/observations.json'
component={'base': 5701632, 'command_source_sha256': 'cac5afad81808c0123175a2de8b1e799c70579f9a5ef81445bb3a66433f9e3ef', 'conservative_user_stack_bytes': 1208, 'entry': 5708656, 'exec_source_sha256': None, 'file_source_sha256': '757a45600b38e0746659781ba6e14aa5a90ec9d378cf364fd555299890ef92fa', 'image_sha256': '1c8232ecb5b4de138dd75cb1bcc150256c65f581a411144378ab78f753cdf18f', 'linked_sha256': 'ab1c52bc4fb98ec79d1abff81e80d4f6d7834283b2df82f18b9215498c789669', 'metadata_source_sha256': None, 'mode': 'process-mm', 'pipe_source_sha256': None, 'poll_source_sha256': None, 'process_mm_source_sha256': '135d000a5ba6ce5d0f2a28b01a23a955e30f88796a8bfa5d9fda0ce8e6116acf', 'scope': 'source-built ordinary syscall component in a freshly generated first-party ABI witness; not an arbitrary-program loader or production qualification', 'serial_source_sha256': None, 'shell_source_sha256': '574462c620fb4e2db01bc4140e98377f52d4add8eddc3e4a9fa0428d2a3d8db4', 'signal_source_sha256': None, 'source_sha256': '49758cc99552709eb1fe062b26dbcb189ae93ead0755139a56f0dd532017ca6c', 'stack_frame_costs': {'command-cases': 104, 'file-cases': 400, 'process-mm-cases': 56, 'shell-cases': 168, 'source-cases': 496, 'startup-cases': 168}, 'startup': 5702592, 'startup_call': 5710064, 'startup_source_sha256': '2c5171f997c27d084883f6dce969747c191ab41649864e5c1d73f2367bb574aa', 'stat_source_sha256': None, 'storage_source_sha256': None, 'syscall': 5710016, 'syscall4': 5710032, 'text_bytes': 8576}
kernel_spans=[[2097152, 2097720], [8388608, 44974080], [44974080, 44999368], [45003472, 46279325], [46283424, 46284800], [46287536, 46287544]]
native_halt=45803255
model={}
exec('"""TOPAL-SYSTEMS-PROCESS-MM-001 saved process/MM boundary checks.\n\nRecords describe observations; they cannot construct native ownership or prove\ncontinuous exclusion, every invalidation instruction or public qualification.\n"""\nPAGE = 4096\nSTART = 0x5F7000\n\n\ndef require(ok, reason):\n    if not ok:\n        raise ValueError(reason)\n\n\ndef owner(row, token, allocator, data=True):\n    require(row[\'token\'] == token, \'token binding\')\n    if token == [0, 0, 0]:\n        require(row[\'record\'] == row[\'cells\'] == [] and row[\'bytes\'] == \'\', \'empty allocation\')\n        return None\n    issuer, identity, index = token\n    require(issuer == allocator[1] == 1 and 0 < identity < allocator[2] and 0 <= index < allocator[3], \'live issuance\')\n    r, cells = row[\'record\'], row[\'cells\']\n    require(len(r) == 8 and r[:2] == token[:2] and r[7] == 1 and r[5] > 0, \'live record\')\n    count = r[3]\n    require(0 < count <= allocator[3] and r[4] > 0 and r[4] & (r[4] - 1) == 0\n            and 0 <= r[2] < r[2] + count <= allocator[3], \'allocation geometry\')\n    require(len(cells) == count * 3 and cells[0::3] == [identity] * count and cells[1::3] == [r[5]] * count, \'owned cells\')\n    first = cells[2]\n    require(first % r[4] == 0, \'allocation alignment\')\n    require(cells[2::3] == list(range(first, first + count)) and 0 <= first < first + count <= 1 << 18, \'physical frames\')\n    raw = bytes.fromhex(row[\'bytes\'])\n    require(len(raw) == (count * PAGE if data else 0), \'whole allocation bytes\')\n    return dict(token=token, span=[first * PAGE, (first + count) * PAGE], count=count,\n                pins=r[6], data=raw, record=r, cells=cells)\n\n\ndef bank(value, state, token, allocator):\n    allocated = owner(value, token, allocator)\n    require(len(state) in [4, 7], \'state width\')\n    if state == [0] * len(state):\n        require(allocated is None, \'owner without state\')\n        return None\n    require(state[0] == 1 and START <= state[1] <= START + 519 * PAGE, \'MM state\')\n    require((state[1] - START + PAGE - 1) // PAGE == state[2] and 0 <= state[2] <= 519, \'byte break\')\n    if not state[2]:\n        require(state[3] == 0 and allocated is None, \'zero-page heap\')\n    else:\n        require(allocated is not None and allocated[\'count\'] == state[2]\n                and allocated[\'span\'][0] == state[3] and allocated[\'pins\'] == 1\n                and allocated[\'record\'][4] == 1, \'heap backing/pin\')\n    return allocated\n\n\ndef mappings(value, count, base):\n    ctx, tables = value[\'context\'], value[\'tables\']\n    root, low = ctx[\'root\'], ctx[\'low\']\n    require(set(tables) == {str(a) for a in [root, root + PAGE, root + 2 * PAGE, root + 3 * PAGE, root + 4 * PAGE, low]}, \'table set\')\n    require(all(len(words) == 512 for words in tables.values()), \'complete tables\')\n    for table, index, target in [(root, 0, root + PAGE), (root + PAGE, 0, root + 2 * PAGE),\n                                 (root + 2 * PAGE, 2, low), (root + 2 * PAGE, 3, root + 4 * PAGE)]:\n        require(tables[str(table)][index] & ~0x60 == target | 7, \'hierarchy\')\n    for i in range(519):\n        table, index = (low, 503 + i) if i < 9 else (root + 4 * PAGE, i - 9)\n        expected = ((base + i * PAGE) | (1 << 63) | 7) if i < count else 0\n        require(tables[str(table)][index] & ~0x60 == expected, \'selected heap translations\')\n\n\ndef snapshot(value, stable=True):\n    allocator = value[\'allocator\']\n    require(len(allocator) == 16 and allocator[:2] == [1, 1] and 0 < allocator[3] <= 262144, \'allocator\')\n    require(value[\'details\'] == [0] * 4, \'resolve scratch\')\n    active = bank(value[\'active\'], value[\'state\'], value[\'tokens\'][:3], allocator)\n    inactive = bank(value[\'inactive\'], value[\'inactive_state\'], value[\'inactive\'][\'token\'], allocator)\n    prepared = bank(value[\'prepared\'], value[\'prepared_state\'], value[\'prepared\'][\'token\'], allocator)\n    candidate = owner(value[\'candidate\'], value[\'tokens\'][3:], allocator)\n    ids = value[\'ids\']\n    require(len(ids) == 7, \'MM identities\')\n    if ids[0] == 0:\n        require(ids == [0] * 7 and inactive is None and prepared is None, \'unbound identities\')\n    else:\n        require(0 < ids[0] <= 2147483647 and 0 < ids[1] < ids[6], \'active MM identity\')\n        if ids[3]:\n            require(0 < ids[3] <= 2147483647 and ids[3] != ids[0] and 1 in [ids[0], ids[3]], \'pair PIDs\')\n            require(0 < ids[4] < ids[6] and ids[4] != ids[1] and value[\'inactive_state\'][0] == 1, \'inactive MM identity\')\n        else:\n            require(ids[3:6] == [0] * 3 and value[\'inactive_state\'] == [0] * 4, \'empty inactive owner\')\n    owned = [o for o in [active, inactive, prepared, candidate] if o is not None]\n    for row in value[\'root_owners\']:\n        owned.append(owner(row, row[\'token\'], allocator, False))\n    require(any(o[\'span\'][0] == value[\'context\'][\'root\'] and o[\'count\'] == 5 and o[\'pins\'] == 1\n                for o in owned if o is not None), \'owned hierarchy\')\n    require(any(o[\'span\'][0] == value[\'context\'][\'low\'] and o[\'count\'] == 1 and o[\'pins\'] == 1\n                for o in owned if o is not None), \'owned low table\')\n    spans = list(value[\'kernel_spans\'])\n    identities = []\n    for allocation in owned:\n        a, b = allocation[\'span\']\n        require(all(b <= x or y <= a for x, y in spans), \'backing overlap\')\n        require(allocation[\'token\'][1] not in identities, \'aliased handle\')\n        identities.append(allocation[\'token\'][1])\n        spans.append([a, b])\n    if stable:\n        require(candidate is None and value[\'transition\'] == [0] * 3, \'incomplete transfer\')\n        mappings(value, value[\'state\'][2], value[\'state\'][3])\n    return dict(active=active, inactive=inactive, prepared=prepared, candidate=candidate)\n\n\ndef same_bank(a, b, name):\n    require(a[name] == b[name] and a[name + \'_state\'] == b[name + \'_state\'], \'changed retained \' + name)\n\n\ndef event(row):\n    before, after = row[\'before\'], row[\'after\']\n    first, last = snapshot(before), snapshot(after)\n    op, request = row[\'operation\'], row[\'request\']\n    for value in [before, after]:\n        require(value[\'cs\'] & 3 == 0 and value[\'flags\'] & 0x600 == 0, \'kernel critical state\')\n        require(value[\'cr0\'] & 0x80010001 == 0x80010001 and value[\'cr4\'] & 0x20, \'paging/write protection\')\n        require(value[\'cr4\'] & ((1 << 7) | (1 << 12) | (1 << 17)) == 0, \'selected paging mode\')\n        if op == 6:\n            require(value[\'context\'][\'state\'] == 2 and value[\'cr3\'] == value[\'context\'][\'bootstrap\'], \'detached cleanup root\')\n        else:\n            require(value[\'context\'][\'state\'] == 1 and value[\'cr3\'] == value[\'context\'][\'root\']\n                    and value[\'gs_base\'] == value[\'context\'][\'self\'] == value[\'context\'][\'address\'], \'actual live root/context\')\n    require(before[\'epoch\'] == after[\'epoch\'] and before[\'epoch\'][0] > 0, \'entry changed\')\n    require(before[\'context\'][\'root\'] == after[\'context\'][\'root\'] and before[\'cr3\'] == after[\'cr3\'], \'root changed\')\n    require(before[\'tokens\'][3:] == after[\'tokens\'][3:] == [0] * 3, \'resize candidate retained\')\n    require(before[\'root_owners\'] == after[\'root_owners\'], \'root owners changed\')\n    if op == 9:\n        require(row[\'result\'] == 1 and request == 0 and before[\'ids\'][0] == 1, \'creation preparation\')\n        require(before[\'state\'] == after[\'state\'] and before[\'active\'] == after[\'active\'] and before[\'ids\'] == after[\'ids\'], \'changed source during preparation\')\n        require(after[\'prepared_state\'][:3] == before[\'state\'][:3], \'prepared byte geometry\')\n        require(after[\'prepared_state\'][4:] == [before[\'context\'][\'root\'], before[\'context\'][\'address\'], before[\'epoch\'][0]], \'prepared entry receipt\')\n        require(after[\'prepared_owner\'] == before[\'ids\'][:3], \'prepared source owner\')\n        if first[\'active\']:\n            require(last[\'prepared\'][\'data\'] == first[\'active\'][\'data\'], \'incomplete fork copy\')\n        require(after[\'allocator\'][2] == before[\'allocator\'][2] + int(before[\'state\'][2] > 0), \'preparation issuance\')\n    elif op == 10:\n        require(row[\'result\'] == 1 and request >= 2 and before[\'prepared_owner\'] == before[\'ids\'][:3], \'creation commit\')\n        require(after[\'active\'] == before[\'prepared\'] and after[\'state\'] == before[\'prepared_state\'][:4], \'child adoption\')\n        require(after[\'inactive\'] == before[\'active\'] and after[\'inactive_state\'] == before[\'state\'], \'parent retention\')\n        require(after[\'ids\'] == [request, before[\'ids\'][6], before[\'ids\'][2]] + before[\'ids\'][:3] + [before[\'ids\'][6] + 1], \'child MM identity\')\n    elif op == 11:\n        require(row[\'result\'] == 1 and request == 0, \'handoff result\')\n        require(after[\'active\'] == before[\'inactive\'] and after[\'state\'] == before[\'inactive_state\'], \'target handoff\')\n        require(after[\'inactive\'] == before[\'active\'] and after[\'inactive_state\'] == before[\'state\'], \'source handoff\')\n        require(after[\'ids\'] == before[\'ids\'][3:6] + before[\'ids\'][:3] + before[\'ids\'][6:], \'handoff identities\')\n    elif op == 12:\n        require(row[\'result\'] == 1 and before[\'ids\'][0] >= 2 and before[\'ids\'][3] == 1, \'child exit\')\n        require(after[\'active\'] == before[\'inactive\'] and after[\'state\'] == before[\'inactive_state\'], \'parent restoration\')\n        require(after[\'ids\'] == before[\'ids\'][3:6] + [0] * 3 + before[\'ids\'][6:], \'retired child MM identity\')\n    elif op == 13:\n        require(row[\'result\'] == 1 and before[\'ids\'][0] == 1, \'outer cancellation\')\n        require(after[\'active\'] == before[\'active\'] and after[\'state\'] == before[\'state\'], \'active cancellation effect\')\n        require(after[\'ids\'] == before[\'ids\'][:3] + [0] * 3 + before[\'ids\'][6:], \'inactive cancellation identity\')\n    elif op == 5:\n        same_bank(before, after, \'inactive\')\n        count = before[\'state\'][2]\n        wanted = (request - START + PAGE - 1) // PAGE if START <= request <= START + 519 * PAGE else count\n        if request == 0 or wanted == count:\n            require(after[\'allocator\'][2] == before[\'allocator\'][2] and after[\'active\'] == before[\'active\'], \'query/within-page allocation\')\n    elif op == 7:\n        same_bank(before, after, \'inactive\')\n        require(after[\'state\'] == [0] * 4 and after[\'tokens\'] == [0] * 6, \'exec heap retirement\')\n        require(after[\'ids\'] == [before[\'ids\'][0], before[\'ids\'][6], before[\'ids\'][2] + 1] + before[\'ids\'][3:6] + [before[\'ids\'][6] + 1], \'exec MM generation\')\n    elif op == 6:\n        require(after[\'state\'] == [0] * 4 and after[\'tokens\'] == [0] * 6 and after[\'ids\'] == [0] * 7, \'outer retirement\')\n    else:\n        require(False, \'unknown MM operation\')\n    if op != 9:\n        require(after[\'prepared_state\'] == [0] * 7 and after[\'prepared_owner\'] == [0] * 3 and after[\'prepared\'][\'token\'] == [0] * 3, \'prepared owner retained\')\n    for retired in row[\'retired\']:\n        require(retired[\'record\'] == [0] * 8 and not any(bytes.fromhex(retired[\'bytes\'])), \'retired backing not consumed/zero\')\n        require(retired[\'cells\'][0::3] == [0] * retired[\'count\'], \'retired cells still owned\')\n    return dict(passed=True, operation=op, active_pid=after[\'ids\'][0],\n                active_pages=after[\'state\'][2], inactive_pages=after[\'inactive_state\'][2])\n',model)

import gdb,hashlib,json,struct,traceback
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
def address(name):return int(gdb.parse_and_eval("(unsigned long long)&'"+name+"'"))
def memory(p,n):return bytes(gdb.selected_inferior().read_memory(p,n)) if n else b''
def words(p,n):return list(struct.unpack('<'+'Q'*n,memory(p,n*8)))
def word(p):return words(p,1)[0]
context=address('topal_bootstrap_storage')+512
observed=dict(passed=False,cases=[],events=[])
pending=case=None
returns={}
callee=['rbx','rbp','r12','r13','r14','r15']

def allocation(pointer,data=True):
    token=words(pointer,3)
    if token==[0]*3:return dict(token=token,record=[],cells=[],bytes='')
    allocator=words(address('topal_x86_frame_context_v1'),16)
    assert token[0]==1 and 0<token[1]<allocator[2] and token[2]<allocator[3]
    record=words(allocator[6]+token[2]*64,8)
    assert record[:2]==token[:2] and record[7]==1 and 0<record[3]<=allocator[3]
    assert 0<=record[2]<record[2]+record[3]<=allocator[3]
    cells=words(allocator[4]+128+record[2]*24,record[3]*3)
    return dict(token=token,record=record,cells=cells,
        bytes=memory(cells[2]*4096,record[3]*4096).hex() if data else '')

def capture():
    root,low,table=word(context+24),word(context+112),word(context+928)
    tokens=address('topal_x86_frame_mm_tokens_v1')
    root_tokens=address('topal_x86_frame_root_tokens_v1')
    return dict(allocator=words(address('topal_x86_frame_context_v1'),16),
        ids=words(address('topal_x86_process_mm_ids_v1'),7),
        state=words(address('topal_x86_frame_mm_state_v1'),4),tokens=words(tokens,6),
        inactive_state=words(address('topal_x86_process_mm_inactive_state_v1'),4),
        prepared_state=words(address('topal_x86_process_mm_prepared_state_v1'),7),
        prepared_owner=words(address('topal_x86_process_mm_prepared_owner_v1'),3),
        transition=words(address('topal_x86_process_mm_transition_v1'),3),
        active=allocation(tokens),candidate=allocation(tokens+24),
        inactive=allocation(address('topal_x86_process_mm_inactive_token_v1')),
        prepared=allocation(address('topal_x86_process_mm_prepared_token_v1')),
        root_owners=[allocation(root_tokens+i*24,False) for i in range(token_bytes//24) if words(root_tokens+i*24,3)!=[0]*3],
        details=words(address('topal_x86_frame_details_v1'),4),
        epoch=words(address('topal_x86_frame_mm_epoch_v1'),2),
        context=dict(address=context,state=word(context),root=root,low=low,heap=word(context+120),
            self=word(context+256),bootstrap=word(context+16),user_arg=word(context+312),phase=word(context+104),
            table=table,pid=word(table+56),child=word(table+0x2010),relationship=word(table+0x2000),
            saved_pid=word(table+0x3038),saved_heap=word(table+0x2178)),
        tables={str(a):words(a,512) for a in [root,root+4096,root+8192,root+12288,root+16384,low]},
        kernel_spans=kernel_spans,cr3=reg('cr3'),cr0=reg('cr0'),cr4=reg('cr4'),cs=reg('cs'),flags=reg('eflags'),gs_base=reg('gs_base'),
        thread=list(gdb.selected_thread().ptid))

def save():
    observed['pending']=pending
    observed['active_case']=case
    with open(observation_path,'w') as f:json.dump(observed,f)

class Checked(gdb.Breakpoint):
    def stop(self):
        try:return self.observe()
        except Exception:
            traceback.print_exc()
            observed['failure']=traceback.format_exc()
            save()
            return True

class Gateway(Checked):
    def __init__(self,symbol,enter):
        self.enter=enter
        super().__init__("*'"+symbol+"'",internal=True)
    def observe(self):
        global pending
        if self.enter:
            op=reg('rdi')
            if op not in [5,6,7,9,10,11,12,13]:return False
            assert pending is None
            pending=dict(operation=op,request=reg('rsi'),before=capture(),sp=reg('rsp'),
                callee={r:reg(r) for r in callee},retired=[])
            model['snapshot'](pending['before'])
        elif pending is not None:
            row=pending
            assert reg('rsp')==row['sp'] and {r:reg(r) for r in callee}==row['callee']
            assert all(reg(r)==0 for r in ['rcx','rdx','rsi','rdi','r8','r9','r10','r11'])
            after=capture()
            retained=[after[k]['token'] for k in ['active','inactive','prepared','candidate']]
            for bank in ['active','inactive','prepared','candidate']:
                old=row['before'][bank]
                if old['token']!=[0]*3 and old['token'] not in retained:
                    a=after['allocator'];r=old['record'];count=r[3]
                    row['retired'].append(dict(token=old['token'],count=count,
                        record=words(a[6]+old['token'][2]*64,8),cells=words(a[4]+128+r[2]*24,count*3),
                        bytes=memory(old['cells'][2]*4096,count*4096).hex()))
            row.update(after=after,result=reg('rax'))
            row['comparison']=model['event'](row)
            observed['events'].append(row)
            pending=None
            save()
        return False

class CaseReturned(Checked):
    def observe(self):
        global case
        self.enabled=False
        assert case is not None and pending is None and reg('cs')&3==3
        if reg('rax')!=0:
            value=capture()
            raise AssertionError(('source case failed',reg('rax'),value['context'],value['ids']))
        assert reg('rsp')==case['sp']+8 and {r:reg(r) for r in callee}==case['callee']
        after=capture();model['snapshot'](after)
        assert after['ids'][:3]==case['before']['ids'][:3] and after['ids'][3:6]==[0]*3
        assert after['ids'][6]==case['before']['ids'][6]+1
        assert after['state'][1:3]==case['before']['state'][1:3]
        assert hashlib.sha256(bytes.fromhex(after['active']['bytes'])).hexdigest()==case['prefix']
        case['after']=after
        observed['cases'].append(case);case=None
        print('PROCESS_MM_CASE_PASS',len(observed['cases']),flush=True)
        save()
        return False

class CaseEntered(Checked):
    def observe(self):
        global case
        assert case is None and pending is None and reg('cs')&3==3
        before=capture();model['snapshot'](before)
        assert before['ids'][0]==1 and before['state'][1:3]==[0x619000,34]
        case=dict(before=before,sp=reg('rsp'),callee={r:reg(r) for r in callee},
            prefix=hashlib.sha256(bytes.fromhex(before['active']['bytes'])).hexdigest())
        site=word(reg('rsp'))
        if site not in returns:returns[site]=CaseReturned('*'+hex(site),internal=True)
        returns[site].enabled=True
        return False

class Halt(Checked):
    def observe(self):
        raise AssertionError(('provider invariant halt',capture()))

class Complete(Checked):
    def observe(self):
        assert case is pending is None and len(observed['cases'])==4
        assert [r['before']['ids'][2] for r in observed['cases']]==[0,1,2,3]
        ops=[r['operation'] for r in observed['events']]
        assert [ops.count(n) for n in [9,10,11,12]]==[4,4,8,4]
        assert words(address('topal_x86_frame_mm_tokens_v1'),6)==[0]*6
        assert words(address('topal_x86_frame_mm_state_v1'),4)==[0]*4
        for suffix,count in [('ids',7),('inactive_token',3),('inactive_state',4),('prepared_token',3),
                             ('prepared_state',7),('prepared_owner',3),('transition',3)]:
            assert words(address('topal_x86_process_mm_'+suffix+'_v1'),count)==[0]*count
        observed['passed']=True
        save()
        return True

try:
    Gateway('topal_x86_frame_gateway_v1',True)
    Gateway('topal_x86_frame_gateway_return_reclaimed_v1',False)
    CaseEntered('*'+hex(component['entry']),internal=True)
    Halt('*'+hex(native_halt),internal=True)
    Complete('*topal_x86_systems_fatal',internal=True)
    gdb.execute('continue')
    assert observed['passed']
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:
    traceback.print_exc()
    save()
    gdb.execute('quit 1')

end
