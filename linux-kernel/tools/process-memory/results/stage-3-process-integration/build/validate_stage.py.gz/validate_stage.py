import json
from pathlib import Path
import subprocess
import time

build=Path(__file__).resolve().parent
commands=[
    ('user-memory-models',['python3','-m','unittest','discover','-s','linux-kernel/tools/user-memory','-p','test_*.py']),
    ('process-memory-models',['python3','-m','unittest','discover','-s','linux-kernel/tools/process-memory','-p','test_*.py']),
    ('default-ABI-fixture',['cargo','test','-p','topal-compiler','--lib','default_abi_fixture_preserves_committed_generator_bytes']),
    ('format',['cargo','fmt','--all','--','--check']),
    ('Rust-file-ceiling',['python3','scripts/check_rust_file_sizes.py']),
]
report={}
for name,command in commands:
    start=time.monotonic()
    args=['rtk','proxy']+command
    result=subprocess.run(args,capture_output=True,text=True)
    (build/(name+'.stdout.log')).write_text(result.stdout)
    (build/(name+'.stderr.log')).write_text(result.stderr)
    row=dict(argv=args,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
    (build/(name+'.command.json')).write_text(json.dumps(row,indent=2)+'\n')
    report[name]=row
    (build/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:
        print(result.stdout[-4000:]+result.stderr[-4000:])
        raise SystemExit(result.returncode)
