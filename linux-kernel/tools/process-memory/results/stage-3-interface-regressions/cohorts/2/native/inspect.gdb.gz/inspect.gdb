set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-interface-regression-2458890-1794502403283077751/kernel.elf"
target remote 127.0.0.1:57509
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/process-mm-interface-regression-2458890-1794502403283077751/source-user-extents/observations.json'
component={'allocation_profile': None, 'base': 5701632, 'cancellation': None, 'command_source_sha256': 'cac5afad81808c0123175a2de8b1e799c70579f9a5ef81445bb3a66433f9e3ef', 'conservative_user_stack_bytes': 1496, 'entry': 5708672, 'exec_source_sha256': None, 'file_source_sha256': '757a45600b38e0746659781ba6e14aa5a90ec9d378cf364fd555299890ef92fa', 'geometry_profile': None, 'image_entry': None, 'image_sha256': '09b725dc3ab2d71b070806e98d4f77dfbf2d873edf2f9e044e52c6324995c057', 'linked_sha256': '476706cd911104af98cadcd174353f50d929f32dcd5233155dffcbad123c6537', 'metadata_source_sha256': None, 'mode': 'signals', 'pipe_source_sha256': None, 'poll_source_sha256': None, 'process_mm_allocation_source_sha256': None, 'process_mm_cancel_source_sha256': None, 'process_mm_exec_source_sha256': None, 'process_mm_geometry_source_sha256': None, 'process_mm_relationship_source_sha256': None, 'process_mm_source_sha256': None, 'relationship_profile': None, 'scope': 'source-built ordinary syscall component in a freshly generated first-party ABI witness; not an arbitrary-program loader or production qualification', 'serial_source_sha256': None, 'shell_source_sha256': '574462c620fb4e2db01bc4140e98377f52d4add8eddc3e4a9fa0428d2a3d8db4', 'signal_source_sha256': '72d650525751faebd14e997ab1e681d3e44fe5fa340f36cc3932ff37bfb95efd', 'source_sha256': '49758cc99552709eb1fe062b26dbcb189ae93ead0755139a56f0dd532017ca6c', 'stack_frame_costs': {'command-cases': 104, 'file-cases': 400, 'shell-cases': 168, 'signal-cases': 344, 'source-cases': 496, 'startup-cases': 168}, 'startup': 5702592, 'startup_call': 5711552, 'startup_source_sha256': '2c5171f997c27d084883f6dce969747c191ab41649864e5c1d73f2367bb574aa', 'stat_source_sha256': None, 'storage_source_sha256': None, 'syscall': 5711504, 'syscall4': 5711520, 'text_bytes': 10144}
process_regression_profile={'process_memory': True, 'scope': 'Existing ordinary source-built syscall fixtures on the experimental process-MM kernel; no public activation', 'kernel_spans': [[2097152, 2097720], [8388608, 44974080], [44974080, 44999368], [45003472, 46281165], [46285264, 46288896], [46289376, 46289384]], 'kernel_sha256': 'b8212e5e9aca715d8db0d863cbc9655ed989c3884b938b57055c3e22e04d0a7c'}
process_regression_boundary_program='model={}\nexec(\'"""TOPAL-SYSTEMS-PROCESS-MM-001 saved process/MM boundary checks.\\n\\nRecords describe observations; they cannot construct native ownership or prove\\ncontinuous exclusion, every invalidation instruction or public qualification.\\n"""\\nPAGE = 4096\\nSTART = 0x5F7000\\n\\n\\ndef require(ok, reason):\\n    if not ok:\\n        raise ValueError(reason)\\n\\n\\ndef owner(row, token, allocator, data=True):\\n    require(row[\\\'token\\\'] == token, \\\'token binding\\\')\\n    if token == [0, 0, 0]:\\n        require(row[\\\'record\\\'] == row[\\\'cells\\\'] == [] and row[\\\'bytes\\\'] == \\\'\\\', \\\'empty allocation\\\')\\n        return None\\n    issuer, identity, index = token\\n    require(issuer == allocator[1] == 1 and 0 < identity < allocator[2] and 0 <= index < allocator[3], \\\'live issuance\\\')\\n    r, cells = row[\\\'record\\\'], row[\\\'cells\\\']\\n    require(len(r) == 8 and r[:2] == token[:2] and r[7] == 1 and r[5] > 0, \\\'live record\\\')\\n    count = r[3]\\n    require(0 < count <= allocator[3] and r[4] > 0 and r[4] & (r[4] - 1) == 0\\n            and 0 <= r[2] < r[2] + count <= allocator[3], \\\'allocation geometry\\\')\\n    require(len(cells) == count * 3 and cells[0::3] == [identity] * count and cells[1::3] == [r[5]] * count, \\\'owned cells\\\')\\n    first = cells[2]\\n    require(first % r[4] == 0, \\\'allocation alignment\\\')\\n    require(cells[2::3] == list(range(first, first + count)) and 0 <= first < first + count <= 1 << 18, \\\'physical frames\\\')\\n    raw = bytes.fromhex(row[\\\'bytes\\\'])\\n    require(len(raw) == (count * PAGE if data else 0), \\\'whole allocation bytes\\\')\\n    return dict(token=token, span=[first * PAGE, (first + count) * PAGE], count=count,\\n                pins=r[6], data=raw, record=r, cells=cells)\\n\\n\\ndef bank(value, state, token, allocator):\\n    allocated = owner(value, token, allocator)\\n    require(len(state) in [4, 7], \\\'state width\\\')\\n    if state == [0] * len(state):\\n        require(allocated is None, \\\'owner without state\\\')\\n        return None\\n    require(state[0] == 1 and START <= state[1] <= START + 519 * PAGE, \\\'MM state\\\')\\n    require((state[1] - START + PAGE - 1) // PAGE == state[2] and 0 <= state[2] <= 519, \\\'byte break\\\')\\n    if not state[2]:\\n        require(state[3] == 0 and allocated is None, \\\'zero-page heap\\\')\\n    else:\\n        require(allocated is not None and allocated[\\\'count\\\'] == state[2]\\n                and allocated[\\\'span\\\'][0] == state[3] and allocated[\\\'pins\\\'] == 1\\n                and allocated[\\\'record\\\'][4] == 1, \\\'heap backing/pin\\\')\\n    return allocated\\n\\n\\ndef mappings(value, count, base):\\n    ctx, tables = value[\\\'context\\\'], value[\\\'tables\\\']\\n    root, low = ctx[\\\'root\\\'], ctx[\\\'low\\\']\\n    require(set(tables) == {str(a) for a in [root, root + PAGE, root + 2 * PAGE, root + 3 * PAGE, root + 4 * PAGE, low]}, \\\'table set\\\')\\n    require(all(len(words) == 512 for words in tables.values()), \\\'complete tables\\\')\\n    for table, index, target in [(root, 0, root + PAGE), (root + PAGE, 0, root + 2 * PAGE),\\n                                 (root + 2 * PAGE, 2, low), (root + 2 * PAGE, 3, root + 4 * PAGE)]:\\n        require(tables[str(table)][index] & ~0x60 == target | 7, \\\'hierarchy\\\')\\n    for i in range(519):\\n        table, index = (low, 503 + i) if i < 9 else (root + 4 * PAGE, i - 9)\\n        expected = ((base + i * PAGE) | (1 << 63) | 7) if i < count else 0\\n        require(tables[str(table)][index] & ~0x60 == expected, \\\'selected heap translations\\\')\\n\\n\\ndef snapshot(value, stable=True):\\n    allocator = value[\\\'allocator\\\']\\n    require(len(allocator) == 16 and allocator[:2] == [1, 1] and 0 < allocator[3] <= 262144, \\\'allocator\\\')\\n    require(value[\\\'details\\\'] == [0] * 4, \\\'resolve scratch\\\')\\n    active = bank(value[\\\'active\\\'], value[\\\'state\\\'], value[\\\'tokens\\\'][:3], allocator)\\n    inactive = bank(value[\\\'inactive\\\'], value[\\\'inactive_state\\\'], value[\\\'inactive\\\'][\\\'token\\\'], allocator)\\n    prepared = bank(value[\\\'prepared\\\'], value[\\\'prepared_state\\\'], value[\\\'prepared\\\'][\\\'token\\\'], allocator)\\n    candidate = owner(value[\\\'candidate\\\'], value[\\\'tokens\\\'][3:], allocator)\\n    ids = value[\\\'ids\\\']\\n    require(len(ids) == 7, \\\'MM identities\\\')\\n    if ids[0] == 0:\\n        require(ids == [0] * 7 and inactive is None and prepared is None, \\\'unbound identities\\\')\\n    else:\\n        require(0 < ids[0] <= 2147483647 and 0 < ids[1] < ids[6], \\\'active MM identity\\\')\\n        if ids[3]:\\n            require(0 < ids[3] <= 2147483647 and ids[3] != ids[0] and 1 in [ids[0], ids[3]], \\\'pair PIDs\\\')\\n            require(0 < ids[4] < ids[6] and ids[4] != ids[1] and value[\\\'inactive_state\\\'][0] == 1, \\\'inactive MM identity\\\')\\n        else:\\n            require(ids[3:6] == [0] * 3 and value[\\\'inactive_state\\\'] == [0] * 4, \\\'empty inactive owner\\\')\\n    owned = [o for o in [active, inactive, prepared, candidate] if o is not None]\\n    for row in value[\\\'root_owners\\\']:\\n        owned.append(owner(row, row[\\\'token\\\'], allocator, False))\\n    require(any(o[\\\'span\\\'][0] == value[\\\'context\\\'][\\\'root\\\'] and o[\\\'count\\\'] == 5 and o[\\\'pins\\\'] == 1\\n                for o in owned if o is not None), \\\'owned hierarchy\\\')\\n    require(any(o[\\\'span\\\'][0] == value[\\\'context\\\'][\\\'low\\\'] and o[\\\'count\\\'] == 1 and o[\\\'pins\\\'] == 1\\n                for o in owned if o is not None), \\\'owned low table\\\')\\n    spans = list(value[\\\'kernel_spans\\\'])\\n    identities = []\\n    for allocation in owned:\\n        a, b = allocation[\\\'span\\\']\\n        require(all(b <= x or y <= a for x, y in spans), \\\'backing overlap\\\')\\n        require(allocation[\\\'token\\\'][1] not in identities, \\\'aliased handle\\\')\\n        identities.append(allocation[\\\'token\\\'][1])\\n        spans.append([a, b])\\n    if stable:\\n        require(candidate is None and value[\\\'transition\\\'] == [0] * 3, \\\'incomplete transfer\\\')\\n        mappings(value, value[\\\'state\\\'][2], value[\\\'state\\\'][3])\\n    return dict(active=active, inactive=inactive, prepared=prepared, candidate=candidate)\\n\\n\\ndef same_bank(a, b, name):\\n    require(a[name] == b[name] and a[name + \\\'_state\\\'] == b[name + \\\'_state\\\'], \\\'changed retained \\\' + name)\\n\\n\\ndef firmware_frames(evidence):\\n    """All complete RAM pages, excluding every reservation/non-RAM overlap."""\\n    ram=[];forbidden=list(evidence[\\\'reservations\\\'])\\n    for base,length,kind in evidence[\\\'e820\\\']:\\n        require(0<=base<base+length<=1<<64 and length>0 and kind>0, \\\'firmware interval\\\')\\n        if kind==1:\\n            require(base+length<=1<<30, \\\'firmware supported RAM domain\\\')\\n            ram.append((base,base+length))\\n        else:forbidden.append((base,base+length))\\n    require(len(evidence[\\\'reservations\\\'])==2 and all(0<=a<b<=1<<30 for a,b in evidence[\\\'reservations\\\']), \\\'firmware reservations\\\')\\n    frames=set()\\n    for a,b in ram:\\n        for frame in range((a+PAGE-1)//PAGE,b//PAGE):\\n            if all((frame+1)*PAGE<=x or y<=frame*PAGE for x,y in forbidden):frames.add(frame)\\n    return sorted(frames)\\n\\n\\ndef physical_catalog(value):\\n    """Independent whole-catalog/registry readback for the small-RAM cohort."""\\n    allocator=value[\\\'allocator\\\'];n=allocator[3]\\n    require(\\\'catalog\\\' in value and \\\'registry\\\' in value, \\\'missing complete physical catalog\\\')\\n    cells,registry=value[\\\'catalog\\\'],value[\\\'registry\\\']\\n    require(len(cells)==3*n and len(registry)==8*n, \\\'complete physical catalog/registry\\\')\\n    physical=cells[2::3]\\n    require(physical==sorted(set(physical)) and all(0<=p<1<<18 for p in physical), \\\'catalog physical identity\\\')\\n    require(all(p>0 for p in cells[1::3]), \\\'catalog provenance\\\')\\n    records={};free_records=0\\n    for index in range(n):\\n        r=registry[index*8:(index+1)*8]\\n        if r==[0]*8:\\n            free_records+=1;continue\\n        require(r[0]==allocator[1]==1 and 0<r[1]<allocator[2] and r[7]==1, \\\'catalog live record\\\')\\n        require(r[1] not in records and 0<=r[2]<r[2]+r[3]<=n and r[3]>0\\n                and r[4]>0 and r[4]&(r[4]-1)==0 and r[5]>0, \\\'catalog record geometry\\\')\\n        part=cells[r[2]*3:(r[2]+r[3])*3]\\n        require(part[0::3]==[r[1]]*r[3] and part[1::3]==[r[5]]*r[3], \\\'catalog owned span\\\')\\n        require(part[2]%r[4]==0 and part[2::3]==list(range(part[2],part[2]+r[3])), \\\'catalog contiguous record\\\')\\n        records[r[1]]=(index,r)\\n    for index in range(n):\\n        identity=cells[index*3]\\n        if identity:\\n            require(identity in records, \\\'catalog cell lacks record\\\')\\n            r=records[identity][1]\\n            require(r[2]<=index<r[2]+r[3], \\\'catalog cell outside record\\\')\\n    for owner in [value[k] for k in [\\\'active\\\',\\\'inactive\\\',\\\'prepared\\\',\\\'candidate\\\']]+value[\\\'root_owners\\\']:\\n        if owner[\\\'token\\\']!=[0]*3:\\n            _,identity,index=owner[\\\'token\\\'];r=owner[\\\'record\\\']\\n            require(records.get(identity)==(index,r) and owner[\\\'cells\\\']==cells[r[2]*3:(r[2]+r[3])*3], \\\'catalog owner binding\\\')\\n    free=largest=run=0;previous=None\\n    for i in range(n):\\n        identity,provenance,frame=cells[i*3:i*3+3]\\n        if identity==0:\\n            free+=1\\n            run=run+1 if previous is not None and previous==(provenance,frame-1) else 1\\n            largest=max(largest,run);previous=(provenance,frame)\\n        else:\\n            run=0;previous=None\\n    return dict(frames=n,free=free,largest_run=largest,free_records=free_records)\\n\\n\\ndef preparation_refusal(row):\\n    before,after=row[\\\'before\\\'],row[\\\'after\\\']\\n    require(row[\\\'operation\\\']==9 and row[\\\'result\\\']==0 and row[\\\'request\\\']==0, \\\'physical refusal result\\\')\\n    require(before[\\\'ids\\\'][0]==before[\\\'context\\\'][\\\'pid\\\']==1 and before[\\\'ids\\\'][3:6]==[0]*3\\n            and before[\\\'context\\\'][\\\'relationship\\\']==0, \\\'physical refusal source\\\')\\n    require(before[\\\'state\\\'][2]>0, \\\'physical refusal nonempty request\\\')\\n    for value in [before,after]:\\n        require(value[\\\'prepared_state\\\']==[0]*7 and value[\\\'prepared_owner\\\']==[0]*3\\n                and value[\\\'prepared\\\'][\\\'token\\\']==[0]*3, \\\'refusal retained preparation\\\')\\n    for key in [\\\'allocator\\\',\\\'ids\\\',\\\'state\\\',\\\'active\\\',\\\'inactive\\\',\\\'inactive_state\\\',\\\'catalog\\\',\\\'registry\\\',\\\'tables\\\',\\\'identity_store\\\']:\\n        require(before[key]==after[key], \\\'refusal changed \\\'+key)\\n    catalog=physical_catalog(before);physical_catalog(after)\\n    require(catalog[\\\'free_records\\\']>0 and before[\\\'allocator\\\'][2]<(1<<64)-1, \\\'refusal is not registry/identity exhaustion\\\')\\n    require(catalog[\\\'largest_run\\\']<before[\\\'state\\\'][2], \\\'physical refusal has an eligible run\\\')\\n    return catalog\\n\\n\\ndef resize_refusal(row):\\n    before,after=row[\\\'before\\\'],row[\\\'after\\\'];request=row[\\\'request\\\']\\n    require(START<request<=START+519*PAGE and row[\\\'result\\\']==before[\\\'state\\\'][1], \\\'raw resize refusal\\\')\\n    count=(request-START+PAGE-1)//PAGE\\n    require(count!=before[\\\'state\\\'][2], \\\'resize refusal geometry\\\')\\n    for key in [\\\'allocator\\\',\\\'ids\\\',\\\'state\\\',\\\'active\\\',\\\'inactive\\\',\\\'inactive_state\\\',\\\'catalog\\\',\\\'registry\\\',\\\'tables\\\',\\\'identity_store\\\']:\\n        require(before[key]==after[key], \\\'resize refusal changed \\\'+key)\\n    catalog=physical_catalog(before);physical_catalog(after)\\n    require(catalog[\\\'free_records\\\']>0 and before[\\\'allocator\\\'][2]<(1<<64)-1, \\\'resize refusal metadata exhaustion\\\')\\n    require(catalog[\\\'largest_run\\\']<count, \\\'resize refusal has eligible run\\\')\\n    return catalog\\n\\n\\ndef event(row):\\n    before, after = row[\\\'before\\\'], row[\\\'after\\\']\\n    first, last = snapshot(before), snapshot(after)\\n    op, request = row[\\\'operation\\\'], row[\\\'request\\\']\\n    for value in [before, after]:\\n        require(value[\\\'cs\\\'] & 3 == 0 and value[\\\'flags\\\'] & 0x600 == 0, \\\'kernel critical state\\\')\\n        require(value[\\\'cr0\\\'] & 0x80010001 == 0x80010001 and value[\\\'cr4\\\'] & 0x20, \\\'paging/write protection\\\')\\n        require(value[\\\'cr4\\\'] & ((1 << 7) | (1 << 12) | (1 << 17)) == 0, \\\'selected paging mode\\\')\\n        if op == 6:\\n            require(value[\\\'context\\\'][\\\'state\\\'] == 2 and value[\\\'cr3\\\'] == value[\\\'context\\\'][\\\'bootstrap\\\'], \\\'detached cleanup root\\\')\\n        else:\\n            require(value[\\\'context\\\'][\\\'state\\\'] == 1 and value[\\\'cr3\\\'] == value[\\\'context\\\'][\\\'root\\\']\\n                    and value[\\\'gs_base\\\'] == value[\\\'context\\\'][\\\'self\\\'] == value[\\\'context\\\'][\\\'address\\\'], \\\'actual live root/context\\\')\\n    require(before[\\\'epoch\\\'] == after[\\\'epoch\\\'] and before[\\\'epoch\\\'][0] > 0, \\\'entry changed\\\')\\n    numbers = {5: [12], 6: [60, 231], 7: [59], 9: [56, 57], 10: [56, 57],\\n               11: [0, 1, 19, 20, 24, 61], 12: [60, 231], 13: [60, 231]}\\n    require(op in numbers and before[\\\'epoch\\\'][1] in numbers[op], \\\'syscall identity\\\')\\n    require(before[\\\'context\\\'][\\\'root\\\'] == after[\\\'context\\\'][\\\'root\\\'] and before[\\\'cr3\\\'] == after[\\\'cr3\\\'], \\\'root changed\\\')\\n    require(before[\\\'tokens\\\'][3:] == after[\\\'tokens\\\'][3:] == [0] * 3, \\\'resize candidate retained\\\')\\n    require(before[\\\'root_owners\\\'] == after[\\\'root_owners\\\'], \\\'root owners changed\\\')\\n    if op == 9:\\n        require(row[\\\'result\\\'] in [0,1] and request == 0 and before[\\\'ids\\\'][0] == 1, \\\'creation preparation\\\')\\n        require(before[\\\'state\\\'] == after[\\\'state\\\'] and before[\\\'active\\\'] == after[\\\'active\\\'] and before[\\\'ids\\\'] == after[\\\'ids\\\'], \\\'changed source during preparation\\\')\\n        if row[\\\'result\\\']==0:\\n            preparation_refusal(row)\\n        else:\\n            require(after[\\\'prepared_state\\\'][:3] == before[\\\'state\\\'][:3], \\\'prepared byte geometry\\\')\\n            require(after[\\\'prepared_state\\\'][4:] == [before[\\\'context\\\'][\\\'root\\\'], before[\\\'context\\\'][\\\'address\\\'], before[\\\'epoch\\\'][0]], \\\'prepared entry receipt\\\')\\n            require(after[\\\'prepared_owner\\\'] == before[\\\'ids\\\'][:3], \\\'prepared source owner\\\')\\n            if first[\\\'active\\\']:\\n                require(last[\\\'prepared\\\'][\\\'data\\\'] == first[\\\'active\\\'][\\\'data\\\'], \\\'incomplete fork copy\\\')\\n            require(after[\\\'allocator\\\'][2] == before[\\\'allocator\\\'][2] + int(before[\\\'state\\\'][2] > 0), \\\'preparation issuance\\\')\\n    elif op == 10:\\n        require(row[\\\'result\\\'] == 1 and request >= 2 and before[\\\'prepared_owner\\\'] == before[\\\'ids\\\'][:3], \\\'creation commit\\\')\\n        require(after[\\\'active\\\'] == before[\\\'prepared\\\'] and after[\\\'state\\\'] == before[\\\'prepared_state\\\'][:4], \\\'child adoption\\\')\\n        require(after[\\\'inactive\\\'] == before[\\\'active\\\'] and after[\\\'inactive_state\\\'] == before[\\\'state\\\'], \\\'parent retention\\\')\\n        require(after[\\\'ids\\\'] == [request, before[\\\'ids\\\'][6], before[\\\'ids\\\'][2]] + before[\\\'ids\\\'][:3] + [before[\\\'ids\\\'][6] + 1], \\\'child MM identity\\\')\\n    elif op == 11:\\n        require(row[\\\'result\\\'] == 1 and request == 0, \\\'handoff result\\\')\\n        require(after[\\\'active\\\'] == before[\\\'inactive\\\'] and after[\\\'state\\\'] == before[\\\'inactive_state\\\'], \\\'target handoff\\\')\\n        require(after[\\\'inactive\\\'] == before[\\\'active\\\'] and after[\\\'inactive_state\\\'] == before[\\\'state\\\'], \\\'source handoff\\\')\\n        require(after[\\\'ids\\\'] == before[\\\'ids\\\'][3:6] + before[\\\'ids\\\'][:3] + before[\\\'ids\\\'][6:], \\\'handoff identities\\\')\\n    elif op == 12:\\n        require(row[\\\'result\\\'] == 1 and before[\\\'ids\\\'][0] >= 2 and before[\\\'ids\\\'][3] == 1, \\\'child exit\\\')\\n        require(after[\\\'active\\\'] == before[\\\'inactive\\\'] and after[\\\'state\\\'] == before[\\\'inactive_state\\\'], \\\'parent restoration\\\')\\n        require(after[\\\'ids\\\'] == before[\\\'ids\\\'][3:6] + [0] * 3 + before[\\\'ids\\\'][6:], \\\'retired child MM identity\\\')\\n    elif op == 13:\\n        require(row[\\\'result\\\'] == 1 and before[\\\'ids\\\'][0] == 1, \\\'outer cancellation\\\')\\n        require(after[\\\'active\\\'] == before[\\\'active\\\'] and after[\\\'state\\\'] == before[\\\'state\\\'], \\\'active cancellation effect\\\')\\n        require(after[\\\'ids\\\'] == before[\\\'ids\\\'][:3] + [0] * 3 + before[\\\'ids\\\'][6:], \\\'inactive cancellation identity\\\')\\n    elif op == 5:\\n        same_bank(before, after, \\\'inactive\\\')\\n        count = before[\\\'state\\\'][2]\\n        wanted = (request - START + PAGE - 1) // PAGE if START <= request <= START + 519 * PAGE else count\\n        if request == 0 or wanted == count:\\n            require(after[\\\'allocator\\\'][2] == before[\\\'allocator\\\'][2] and after[\\\'active\\\'] == before[\\\'active\\\'], \\\'query/within-page allocation\\\')\\n        elif START<request<=START+519*PAGE and row[\\\'result\\\']==before[\\\'state\\\'][1]:\\n            resize_refusal(row)\\n    elif op == 7:\\n        same_bank(before, after, \\\'inactive\\\')\\n        require(after[\\\'state\\\'] == [0] * 4 and after[\\\'tokens\\\'] == [0] * 6, \\\'exec heap retirement\\\')\\n        require(after[\\\'ids\\\'] == [before[\\\'ids\\\'][0], before[\\\'ids\\\'][6], before[\\\'ids\\\'][2] + 1] + before[\\\'ids\\\'][3:6] + [before[\\\'ids\\\'][6] + 1], \\\'exec MM generation\\\')\\n    elif op == 6:\\n        require(after[\\\'state\\\'] == [0] * 4 and after[\\\'tokens\\\'] == [0] * 6 and after[\\\'ids\\\'] == [0] * 7, \\\'outer retirement\\\')\\n    else:\\n        require(False, \\\'unknown MM operation\\\')\\n    if op != 9:\\n        require(after[\\\'prepared_state\\\'] == [0] * 7 and after[\\\'prepared_owner\\\'] == [0] * 3 and after[\\\'prepared\\\'][\\\'token\\\'] == [0] * 3, \\\'prepared owner retained\\\')\\n    retained = [after[name][\\\'token\\\'] for name in [\\\'active\\\', \\\'inactive\\\', \\\'prepared\\\', \\\'candidate\\\']]\\n    expected = {tuple(before[name][\\\'token\\\']): before[name] for name in\\n                [\\\'active\\\', \\\'inactive\\\', \\\'prepared\\\', \\\'candidate\\\']\\n                if before[name][\\\'token\\\'] != [0] * 3 and before[name][\\\'token\\\'] not in retained}\\n    actual = [tuple(retired[\\\'token\\\']) for retired in row[\\\'retired\\\']]\\n    require(len(actual) == len(set(actual)) and set(actual) == set(expected), \\\'complete retirement set\\\')\\n    for retired in row[\\\'retired\\\']:\\n        original = expected[tuple(retired[\\\'token\\\'])]\\n        count = original[\\\'record\\\'][3]\\n        require(retired[\\\'count\\\'] == count and len(bytes.fromhex(retired[\\\'bytes\\\'])) == count * PAGE\\n                and len(retired[\\\'cells\\\']) == count * 3, \\\'complete retirement geometry\\\')\\n        require(retired[\\\'record\\\'] == [0] * 8 and not any(bytes.fromhex(retired[\\\'bytes\\\'])), \\\'retired backing not consumed/zero\\\')\\n        require(retired[\\\'cells\\\'][0::3] == [0] * retired[\\\'count\\\'], \\\'retired cells still owned\\\')\\n        require(retired[\\\'cells\\\'][2::3] == original[\\\'cells\\\'][2::3], \\\'retired physical cell identity\\\')\\n    return dict(passed=True, operation=op, active_pid=after[\\\'ids\\\'][0],\\n                active_pages=after[\\\'state\\\'][2], inactive_pages=after[\\\'inactive_state\\\'][2])\\n\',model)\n\nimport gdb,hashlib,json,struct,traceback\ndef reg(name):return int(gdb.parse_and_eval(\'$\'+name))&((1<<64)-1)\ndef address(name):return int(gdb.parse_and_eval("(unsigned long long)&\'"+name+"\'"))\ndef memory(p,n):return bytes(gdb.selected_inferior().read_memory(p,n)) if n else b\'\'\ndef words(p,n):return list(struct.unpack(\'<\'+\'Q\'*n,memory(p,n*8)))\ndef word(p):return words(p,1)[0]\ncontext=address(\'topal_bootstrap_storage\')+512\nobserved=dict(passed=False,cases=[],events=[],child_exec_entries=[],replacement_entries=[],terminal=[],refusals=[],child_departures=[])\nchild_exec=component[\'mode\']==\'process-mm-exec\'\ncancel_config=component.get(\'cancellation\')\nallocation_config=component.get(\'allocation_profile\')\ngeometry_config=component.get(\'geometry_profile\')\nrelationship_config=component.get(\'relationship_profile\')\nobserved[\'cancellation\']=cancel_config\nobserved[\'allocation_profile\']=allocation_config\nobserved[\'geometry_profile\']=geometry_config\nobserved[\'relationship_profile\']=relationship_config\npending=case=None\nrefusal_attempt=None\nreturns={}\ncallee=[\'rbx\',\'rbp\',\'r12\',\'r13\',\'r14\',\'r15\']\n\ndef allocation(pointer,data=True):\n    token=words(pointer,3)\n    if token==[0]*3:return dict(token=token,record=[],cells=[],bytes=\'\')\n    allocator=words(address(\'topal_x86_frame_context_v1\'),16)\n    assert token[0]==1 and 0<token[1]<allocator[2] and token[2]<allocator[3]\n    record=words(allocator[6]+token[2]*64,8)\n    assert record[:2]==token[:2] and record[7]==1 and 0<record[3]<=allocator[3]\n    assert 0<=record[2]<record[2]+record[3]<=allocator[3]\n    cells=words(allocator[4]+128+record[2]*24,record[3]*3)\n    return dict(token=token,record=record,cells=cells,\n        bytes=memory(cells[2]*4096,record[3]*4096).hex() if data else \'\')\n\ndef capture():\n    root,low,table=word(context+24),word(context+112),word(context+928)\n    tokens=address(\'topal_x86_frame_mm_tokens_v1\')\n    root_tokens=address(\'topal_x86_frame_root_tokens_v1\')\n    allocator=words(address(\'topal_x86_frame_context_v1\'),16)\n    result=dict(allocator=allocator,\n        ids=words(address(\'topal_x86_process_mm_ids_v1\'),7),\n        state=words(address(\'topal_x86_frame_mm_state_v1\'),4),tokens=words(tokens,6),\n        inactive_state=words(address(\'topal_x86_process_mm_inactive_state_v1\'),4),\n        prepared_state=words(address(\'topal_x86_process_mm_prepared_state_v1\'),7),\n        prepared_owner=words(address(\'topal_x86_process_mm_prepared_owner_v1\'),3),\n        transition=words(address(\'topal_x86_process_mm_transition_v1\'),3),\n        active=allocation(tokens),candidate=allocation(tokens+24),\n        inactive=allocation(address(\'topal_x86_process_mm_inactive_token_v1\')),\n        prepared=allocation(address(\'topal_x86_process_mm_prepared_token_v1\')),\n        root_owners=[allocation(root_tokens+i*24,False) for i in range(token_bytes//24) if words(root_tokens+i*24,3)!=[0]*3],\n        details=words(address(\'topal_x86_frame_details_v1\'),4),\n        epoch=words(address(\'topal_x86_frame_mm_epoch_v1\'),2),\n        context=dict(address=context,state=word(context),root=root,low=low,heap=word(context+120),\n            self=word(context+256),bootstrap=word(context+16),user_arg=word(context+312),phase=word(context+104),\n            tls=word(context+128),registered_tid=word(context+152),robust=word(context+160),\n            table=table,pid=word(table+56),child=word(table+0x2010),relationship=word(table+0x2000),\n            policy_store=word(context+1000),\n            saved_pid=word(table+0x3038),saved_heap=word(table+0x2178)),\n        inactive_wait=[word(table+0x2060),word(table+0x2078)],\n        tables={str(a):words(a,512) for a in [root,root+4096,root+8192,root+12288,root+16384,low]},\n        kernel_spans=kernel_spans,cr3=reg(\'cr3\'),cr0=reg(\'cr0\'),cr4=reg(\'cr4\'),cs=reg(\'cs\'),flags=reg(\'eflags\'),gs_base=reg(\'gs_base\'),fs_base=reg(\'fs_base\'),\n        thread=list(gdb.selected_thread().ptid))\n    if allocation_config is not None:\n        assert 0<allocator[3]<=4096, \'observer catalog bound for the small-RAM cohort\'\n        result.update(catalog=words(allocator[4]+128,allocator[3]*3),\n                      registry=words(allocator[6],allocator[3]*8))\n    identity_config=allocation_config or geometry_config or relationship_config\n    if identity_config is not None:\n        policy=result[\'context\'][\'policy_store\']\n        result[\'identity_store\']=memory(policy,identity_config[\'identity_storage_bytes\']).hex() if policy else \'\'\n    return result\n\ndef save():\n    observed[\'pending\']=pending\n    observed[\'active_case\']=case\n    observed[\'refusal_pending\']=refusal_attempt\n    with open(observation_path,\'w\') as f:json.dump(observed,f)\n\nclass Checked(gdb.Breakpoint):\n    def stop(self):\n        try:return self.observe()\n        except Exception:\n            traceback.print_exc()\n            observed[\'failure\']=traceback.format_exc()\n            save()\n            return True\n\nclass Gateway(Checked):\n    def __init__(self,symbol,enter):\n        self.enter=enter\n        super().__init__("*\'"+symbol+"\'",internal=True)\n    def observe(self):\n        global pending\n        if self.enter:\n            op=reg(\'rdi\')\n            if allocation_config is not None and op==0:\n                assert \'firmware\' not in observed and reg(\'cs\')&3==0\n                boot=reg(\'rsi\');assert 0<boot<=0xfff000\n                n=memory(boot+488,1)[0];assert 0<n<=128\n                resource=int.from_bytes(memory(boot+536,4),\'little\')\n                size=int.from_bytes(memory(boot+540,4),\'little\')\n                observed[\'firmware\']=dict(boot=boot,\n                    e820=[words(boot+720+20*i,2)+[int.from_bytes(memory(boot+736+20*i,4),\'little\')] for i in range(n)],\n                    raw_map=memory(boot+720,n*20).hex(),\n                    reservations=[[0,address(\'topal_x86_kernel_reservation_end_v1\')],[resource,resource+size]])\n                save()\n            if op not in [5,6,7,9,10,11,12,13]:return False\n            assert pending is None\n            pending=dict(operation=op,request=reg(\'rsi\'),before=capture(),sp=reg(\'rsp\'),\n                callee={r:reg(r) for r in callee},retired=[])\n            model[\'snapshot\'](pending[\'before\'])\n        elif pending is not None:\n            row=pending\n            assert reg(\'rsp\')==row[\'sp\'] and {r:reg(r) for r in callee}==row[\'callee\']\n            assert all(reg(r)==0 for r in [\'rcx\',\'rdx\',\'rsi\',\'rdi\',\'r8\',\'r9\',\'r10\',\'r11\'])\n            after=capture()\n            retained=[after[k][\'token\'] for k in [\'active\',\'inactive\',\'prepared\',\'candidate\']]\n            for bank in [\'active\',\'inactive\',\'prepared\',\'candidate\']:\n                old=row[\'before\'][bank]\n                if old[\'token\']!=[0]*3 and old[\'token\'] not in retained:\n                    a=after[\'allocator\'];r=old[\'record\'];count=r[3]\n                    row[\'retired\'].append(dict(token=old[\'token\'],count=count,\n                        record=words(a[6]+old[\'token\'][2]*64,8),cells=words(a[4]+128+r[2]*24,count*3),\n                        bytes=memory(old[\'cells\'][2]*4096,count*4096).hex()))\n            row.update(after=after,result=reg(\'rax\'))\n            row[\'comparison\']=model[\'event\'](row)\n            observed[\'events\'].append(row)\n            pending=None\n            save()\n        return False\n\n'
process_preparation_profile=None
process_preparation_model_source='"""Saved native preparation records; no authority, native producer or TLB proof."""\nPAGE = 4096\nSTART = 0x5F7000\n\n\ndef require(condition, reason):\n    if not condition:\n        raise ValueError(reason)\n\n\ndef allocation(snapshot, value, count, pins, spans, capture_bytes=True):\n    token, record, cells = value[\'token\'], value[\'record\'], value[\'cells\']\n    if not count:\n        require(token == [0, 0, 0] and record == cells == [] and value[\'bytes\'] == \'\', \'empty owner\')\n        return None\n    issuer, identity, index = token\n    allocator = snapshot[\'allocator\']\n    require(issuer == allocator[1] == 1 and 0 < identity < allocator[2] and 0 <= index < allocator[3], \'token\')\n    require(len(record) == 8 and record[:2] == token[:2] and record[3:5] == [count, 1], \'record\')\n    require(record[5] > 0 and record[6:] == [pins, 1], \'pin/lifetime\')\n    require(0 <= record[2] < record[2] + count <= allocator[3], \'cell domain\')\n    require(len(cells) == count * 3 and cells[0::3] == [identity] * count, \'cell ownership\')\n    require(cells[1::3] == [record[5]] * count, \'cell provenance\')\n    first = cells[2]\n    require(cells[2::3] == list(range(first, first + count)) and 0 <= first < first + count <= 1 << 18, \'physical extent\')\n    span = [first * PAGE, (first + count) * PAGE]\n    require(all(span[1] <= a or b <= span[0] for a, b in spans), \'reserved/static overlap\')\n    raw = bytes.fromhex(value[\'bytes\'])\n    require(len(raw) == (count * PAGE if capture_bytes else 0), \'whole bytes\')\n    return dict(span=span, identity=identity, token=token, record=record, cells=cells, bytes=raw)\n\n\ndef snapshot(value):\n    allocator = value[\'allocator\']\n    require(len(allocator) == 16 and allocator[:2] == [1, 1] and 0 < allocator[3] <= 262144, \'allocator\')\n    state = value[\'state\']\n    require(len(state) == 4 and state[0] == 1 and 0 <= state[2] <= 519, \'active state\')\n    require(START <= state[1] <= START + 519 * PAGE and\n            (state[1] - START + PAGE - 1) // PAGE == state[2], \'actual break geometry\')\n    require(value[\'tokens\'][3:] == [0, 0, 0] and value[\'tokens\'][:3] == value[\'active\'][\'token\'], \'active token bank\')\n    require(value[\'epoch\'][0] > 0 and value[\'epoch\'][1] == 12 and value[\'recovery\'][1:3] == [1, 5], \'entry identity/operation\')\n    require(value[\'recovery\'][5] == value[\'epoch\'][0], \'captured epoch\')\n    ctx = value[\'context\']\n    require(ctx[\'state\'] == 1 and ctx[\'address\'] == ctx[\'self\'] == value[\'gs_base\'], \'current context\')\n    require(ctx[\'root\'] == value[\'cr3\'] and ctx[\'heap\'] == state[3], \'actual root/heap\')\n    require(value[\'cs\'] & 3 == 0 and value[\'flags\'] & 0x600 == 0, \'privileged critical state\')\n    require(value[\'cr0\'] & 0x80010001 == 0x80010001 and value[\'cr4\'] & (1 << 5), \'paging/write protection\')\n    require(value[\'cr4\'] & ((1 << 7) | (1 << 12) | (1 << 17)) == 0, \'selected paging mode\')\n    spans = list(value[\'reserved_spans\'])\n    require(len(value[\'static_owners\']) == 4, \'static owner roles\')\n    static = []\n    for owned, (count, pins) in zip(value[\'static_owners\'], [(5, 1), (1, 1), (503, 1), (2, 2)]):\n        owner = allocation(value, owned, count, pins, spans, False)\n        static.append(owner)\n        spans.append(owner[\'span\'])\n    active = allocation(value, value[\'active\'], state[2], 1, spans)\n    require((active[\'span\'][0] if active else 0) == state[3], \'active backing\')\n    tables = value[\'tables\']\n    root, low = ctx[\'root\'], ctx[\'low\']\n    require(root == static[0][\'span\'][0] and low == static[1][\'span\'][0], \'table ownership\')\n    require(set(tables) == {str(a) for a in [root, root + PAGE, root + 2 * PAGE,\n                                           root + 3 * PAGE, root + 4 * PAGE, low]}, \'complete selected tables\')\n    require(all(len(words) == 512 for words in tables.values()), \'table words\')\n    expected = [(root, 0, root + PAGE), (root + PAGE, 0, root + 2 * PAGE),\n                (root + 2 * PAGE, 2, low), (root + 2 * PAGE, 3, root + 4 * PAGE)]\n    for table, index, target in expected:\n        require(tables[str(table)][index] & ~0x60 == target | 7, \'heap hierarchy\')\n    for i in range(519):\n        table, index = (low, 503 + i) if i < 9 else (root + 4 * PAGE, i - 9)\n        wanted = ((state[3] + i * PAGE) | (1 << 63) | 7) if i < state[2] else 0\n        require(tables[str(table)][index] & ~0x60 == wanted, \'unchanged active heap mapping\')\n    require(value[\'details\'] == [0] * 4, \'retired resolve facts\')\n    return active\n\n\ndef check(row):\n    before, ready, after = (row[k] for k in [\'before\', \'ready\', \'after\'])\n    original = snapshot(before)\n    for current in [ready, after]:\n        snapshot(current)\n        for key in [\'state\', \'tokens\', \'epoch\', \'recovery\', \'context\', \'context_bytes\', \'reserved_spans\',\n                    \'active\', \'static_owners\', \'cr0\', \'cr3\', \'cr4\', \'gs_base\', \'cs\']:\n            require(current[key] == before[key], \'changed active owner/context: \' + key)\n        for table, words in before[\'tables\'].items():\n            for old, new in zip(words, current[\'tables\'][table]):\n                require(old & ~0x60 == new & ~0x60 and old | new == new, \'unrelated descriptor change\')\n    require(before[\'prepared_state\'] == after[\'prepared_state\'] == [0] * 7, \'receipt retirement\')\n    require(before[\'prepared\'][\'token\'] == after[\'prepared\'][\'token\'] == [0] * 3, \'prepared token retirement\')\n    count = before[\'state\'][2]\n    require(ready[\'prepared_state\'][:3] == [1, before[\'state\'][1], count], \'prepared geometry\')\n    require(ready[\'prepared_state\'][4:] == [before[\'cr3\'], before[\'context\'][\'address\'], before[\'epoch\'][0]], \'prepared entry binding\')\n    spans = before[\'reserved_spans\'] + [[o[\'cells\'][2] * PAGE, (o[\'cells\'][2] + o[\'record\'][3]) * PAGE]\n                                        for o in before[\'static_owners\']]\n    candidate = allocation(ready, ready[\'prepared\'], count, 1, spans)\n    expected_issued = before[\'allocator\'][2] + int(count > 0)\n    for current in [ready, after]:\n        require(current[\'allocator\'] == before[\'allocator\'][:2] + [expected_issued] + before[\'allocator\'][3:], \'allocator issuance/state\')\n    require(ready[\'prepared_state\'][3] == (candidate[\'span\'][0] if candidate else 0), \'prepared physical alias\')\n    if count:\n        require(candidate[\'identity\'] == before[\'allocator\'][2] and candidate[\'identity\'] != original[\'identity\'], \'distinct issued extent\')\n        a, b = candidate[\'span\'], original[\'span\']\n        require(a[1] <= b[0] or b[1] <= a[0], \'parent/prepared alias\')\n        require(candidate[\'bytes\'] == original[\'bytes\'], \'complete copied heap\')\n        erased = row[\'erased\']\n        require(erased[\'base\'] == a[0] and erased[\'count\'] == count, \'erasure owner\')\n        require(erased[\'token\'] == candidate[\'token\'] and erased[\'record\'][:6] == candidate[\'record\'][:6], \'erasure identity\')\n        require(erased[\'record\'][6:] == [0, 1] and bytes.fromhex(erased[\'bytes\']) == bytes(count * PAGE), \'unpin/physical erasure before release\')\n        require(after[\'released_record\'] == [0] * 8, \'consumed registry owner\')\n        cells = after[\'released_cells\']\n        require(cells[0::3] == [0] * count and cells[1::3] == candidate[\'cells\'][1::3]\n                and cells[2::3] == candidate[\'cells\'][2::3], \'released cell ownership/provenance\')\n    else:\n        require(row[\'erased\'] is None and after[\'released_record\'] == after[\'released_cells\'] == [], \'empty preparation\')\n    return dict(passed=True, pages=count, copied_bytes=count * PAGE, released_bytes=count * PAGE,\n                scope=\'Observed preparation/cancellation within an actual brk gateway; no process switch, complete mapping-alias, asynchronous or production proof\')\n'
owner_profile=None
image_publication_profile=None
image_publication_model_source='"""Saved-data checks of selected image-leaf publication and local invalidation.\n\nTOPAL-SYSTEMS-USER-EXTENT-001. Records cannot create ownership or qualify\nunobserved entries, CPUs, DMA, faults, asynchronous behavior or stable lifetime.\n"""\nPAGE=4096\nBASE=0x5e5000\nNX=1<<63\n\n\ndef owners(snapshot,bindings,kernel_spans,kind):\n    ctx=snapshot[\'context\']\n    assert kind in [\'relro\',\'exec\']\n    generation=snapshot[\'image_generation\']\n    assert ctx[\'state\']==1 and generation in [0,1]\n    if kind==\'relro\':assert ctx[\'phase\']==8\n    elif generation==0:assert ctx[\'phase\']==32\n    else:assert 11<=ctx[\'phase\']<=15\n    assert snapshot[\'epoch\'][0]>0 and snapshot[\'epoch\'][1]==(10 if kind==\'relro\' else 59)\n    assert ctx[\'address\']==ctx[\'self\']==snapshot[\'gs_base\']\n    assert snapshot[\'cr0\']&0x80010001==0x80010001 and snapshot[\'cs\']&3==0\n    assert snapshot[\'cr4\']&0x20 and snapshot[\'cr4\']&((1<<7)|(1<<12)|(1<<17)|31592448)==0\n    assert snapshot[\'flags\']&0x600==0\n    allocator=snapshot[\'allocator\']\n    assert len(allocator)==16 and allocator[:2]==[1,1] and 0<allocator[3]<=262144\n    tokens=snapshot[\'root_tokens\']\n    roles=bindings[\'roles\']\n    assert len(tokens)*8==bindings[\'token_bytes\'] and len(tokens)%3==0\n    assert [(r[\'count\'],r[\'pins\']) for r in roles]==[(5,1),(1,1),(503,1),(2,2)]\n    assert len({r[\'slot\'] for r in roles})==len(snapshot[\'roles\'])==4\n    extents=[]\n    ids=[]\n    def allocation(row,token,count,pins):\n        issuer,identity,index=token\n        assert issuer==1 and 0<identity<allocator[2] and 0<=index<allocator[3]\n        record,cells=row[\'record\'],row[\'cells\']\n        assert len(record)==8 and record[:2]==token[:2]\n        assert record[3:5]==[count,1] and record[5]>0 and record[6:]==[pins,1]\n        assert 0<=record[2]<record[2]+count<=allocator[3]\n        assert len(cells)==count*3 and cells[0::3]==[identity]*count and cells[1::3]==[record[5]]*count\n        first=cells[2]\n        assert 0<first<first+count<=1<<18 and cells[2::3]==list(range(first,first+count))\n        span=[first*PAGE,(first+count)*PAGE]\n        assert all(span[1]<=a or b<=span[0] for a,b in kernel_spans+extents)\n        assert identity not in ids\n        extents.append(span)\n        ids.append(identity)\n        return span[0]\n    bases=[]\n    for row,role in zip(snapshot[\'roles\'],roles):\n        slot=role[\'slot\']\n        assert 0<=slot<len(tokens)//3\n        bases.append(allocation(row,tokens[slot*3:slot*3+3],role[\'count\'],role[\'pins\']))\n    mm=snapshot[\'state\']\n    assert len(mm)==4 and mm[0]==1 and 0<mm[2]<=519 and mm[1]==0x5f7000+mm[2]*PAGE\n    assert len(snapshot[\'heap_tokens\'])==6 and snapshot[\'heap_tokens\'][3:]==[0,0,0]\n    heap=allocation(snapshot[\'heap\'],snapshot[\'heap_tokens\'][:3],mm[2],1)\n    assert heap==mm[3] and snapshot[\'heap_tokens\'][1] not in tokens[1::3]\n    root,low,image,stack=bases\n    assert ctx[\'root\']==snapshot[\'cr3\']==root and ctx[\'low\']==low and ctx[\'stack_page\']==stack+PAGE\n    assert set(snapshot[\'tables\'])=={str(p) for p in [root,root+PAGE,root+2*PAGE,root+3*PAGE,root+4*PAGE,low]}\n    assert all(len(words)==512 and all(type(w) is int and 0<=w<1<<64 for w in words) for words in snapshot[\'tables\'].values())\n    # Bind the effective ancestor path for the complete changed image interval.\n    for table,index,next_table in [(root,0,root+PAGE),(root+PAGE,0,root+2*PAGE),(root+2*PAGE,2,low)]:\n        assert snapshot[\'tables\'][str(table)][index]&~0x60==next_table|7\n    return image\n\n\ndef published(record,bindings,kernel_spans):\n    before,after=record[\'before\'],record[\'stored\']\n    kind=record[\'kind\']\n    image=owners(before,bindings,kernel_spans,kind)\n    assert owners(after,bindings,kernel_spans,kind)==image\n    assert {k:v for k,v in before.items() if k not in [\'tables\',\'flags\']}=={k:v for k,v in after.items() if k not in [\'tables\',\'flags\']}\n    low=str(before[\'context\'][\'low\'])\n    count=8 if kind==\'relro\' else 18\n    selected=set(range(485,485+count))\n    for table,words in before[\'tables\'].items():\n        for index,(old,new) in enumerate(zip(words,after[\'tables\'][table])):\n            if table==low and index in selected:\n                page=index-485\n                physical=image+(BASE-0x400000)+page*PAGE\n                old_flags=7 if kind==\'relro\' or page>=8 else 5\n                new_flags=5 if kind==\'relro\' else 7\n                assert old&~0x60==physical|NX|old_flags,\'old image leaf differs\'\n                assert new&~0x60==physical|NX|new_flags,\'published image leaf differs\'\n            else:assert old&~0x60==new&~0x60 and old|new==new,\'unrelated translation changed\'\n    assert record[\'publication_barrier_observed\']\n    return count\n\n\ndef check(record,bindings,kernel_spans):\n    count=published(record,bindings,kernel_spans)\n    before,after=record[\'before\'],record[\'after\']\n    assert owners(after,bindings,kernel_spans,record[\'kind\'])==owners(before,bindings,kernel_spans,record[\'kind\'])\n    assert {k:v for k,v in after.items() if k!=\'flags\'}=={k:v for k,v in record[\'stored\'].items() if k!=\'flags\'}\n    assert record[\'thread_before\']==record[\'thread_stored\']==record[\'thread_after\']\n    assert len(record[\'invalidations\'])==count,\'incomplete image invalidation interval\'\n    for index,event in enumerate(record[\'invalidations\']):\n        assert event[\'index\']==count-index and event[\'address\']==BASE+index*PAGE,\'wrong image invalidation address/order\'\n        assert before[\'cr0\']==event[\'cr0\'] and before[\'cr3\']==event[\'cr3\'] and before[\'cr4\']==event[\'cr4\']\n        assert event[\'cpu\']+1==record[\'thread_before\'][1] and record[\'thread_before\'][0]==1\n        assert event[\'flags\']&0x600==0 and event[\'efer\']&0xd00==0xd00\n    assert record[\'final_barrier_observed\']==(record[\'kind\']==\'relro\')\n    return dict(passed=True,pages_invalidated=count,\n        scope=\'Selected actual image-owner boundaries, complete local leaf edits and ordered post-INVLPG states before reuse/readback. Exec has a publication barrier and no claimed extra final MFENCE. Not continuous mode, AP/DMA/asynchronous exclusion, arbitrary mapping editors or stable lifetime qualification\')\n'
interval_profile=None
translation_profile=None
translation_model_source='"""Saved-data checks for the actual local heap publication/invalidation order.\n\nTOPAL-SYSTEMS-USER-EXTENT-001. Numeric records describe observations; they do not\ncreate mapping authority, inspect a TLB or establish AP/DMA/async exclusion.\n"""\nPAGE=4096\nHEAP=0x5f7000\nLEAF=(1<<63)|7\n\n\ndef controls(snapshot):\n    assert snapshot[\'cr0\']&0x80010001==0x80010001\n    assert snapshot[\'cr4\']&0x20 and snapshot[\'cr4\']&((1<<7)|(1<<12)|(1<<17))==0\n    assert snapshot[\'cs\']&3==0 and snapshot[\'flags\']&0x600==0\n    return tuple(snapshot[k] for k in [\'cr0\',\'cr3\',\'cr4\',\'cs\'])\n\n\ndef check_switch(record):\n    before,after=record[\'before\'],record[\'after\']\n    first,last=controls(before),controls(after)\n    ctx=before[\'context\']\n    assert ctx==after[\'context\'] and ctx[\'state\']==1\n    assert before[\'thread\']==after[\'thread\']\n    assert all(0<ctx[k]<1<<30 and ctx[k]%PAGE==0 for k in [\'root\',\'bootstrap\'])\n    assert ctx[\'root\']!=ctx[\'bootstrap\']\n    assert first[1]==ctx[\'root\'] and last[1]==ctx[\'bootstrap\']\n    assert first[0]==last[0] and first[2:]==last[2:]\n    return dict(passed=True,target_root=ctx[\'root\'],bootstrap_root=ctx[\'bootstrap\'],\n        scope=\'Observed local CR3 replacement with PCID/global paging disabled; no other CPU or continuous-mode proof\')\n\n\ndef mode(snapshot,detachment=None):\n    current=controls(snapshot)\n    ctx=snapshot[\'context\']\n    assert ctx[\'root\']%PAGE==0\n    if snapshot[\'cr3\']==ctx[\'root\']:\n        assert ctx[\'state\']==1 and detachment is None\n    else:\n        assert detachment is not None,\'detached root requires its observed flushing handoff\'\n        check_switch(detachment)\n        after=detachment[\'after\']\n        assert ctx[\'state\']==2 and snapshot[\'cr3\']==ctx[\'bootstrap\']\n        assert {k:v for k,v in ctx.items() if k!=\'state\'}=={k:v for k,v in after[\'context\'].items() if k!=\'state\'}\n        assert current==controls(after) and snapshot[\'thread\']==after[\'thread\']\n    return current\n\n\ndef slot(snapshot,index):\n    assert 0<=index<519\n    ctx=snapshot[\'context\']\n    return (str(ctx[\'low\']),503+index) if index<9 else (str(ctx[\'root\']+16384),index-9)\n\n\ndef published(before,after,old,new,base,detachment=None):\n    assert 0<=old<=519 and 0<=new<=519 and old!=new\n    assert before[\'state\'][2]==old\n    assert base%PAGE==0 and (base>0 if new else base==0)\n    assert 0<=base<=base+new*PAGE<=1<<30\n    if detachment is not None:assert old>0 and new==0,\'detached publication must revoke the whole heap\'\n    assert mode(before,detachment)==mode(after,detachment)\n    assert before[\'thread\']==after[\'thread\'] and before[\'context\']==after[\'context\']\n    assert before[\'state\']==after[\'state\'] and before[\'tokens\']==after[\'tokens\']\n    root=before[\'context\'][\'root\']\n    expected={str(t) for t in [root,root+PAGE,root+2*PAGE,root+3*PAGE,root+4*PAGE,before[\'context\'][\'low\']]}\n    assert set(before[\'tables\'])==set(after[\'tables\'])==expected\n    selected={slot(before,i):((base+i*PAGE)|LEAF if i<new else 0) for i in range(max(old,new))}\n    for table,words in before[\'tables\'].items():\n        actual=after[\'tables\'][table]\n        assert len(words)==len(actual)==512\n        for index,(a,b) in enumerate(zip(words,actual)):\n            assert type(a) is int and type(b) is int and 0<=a<1<<64 and 0<=b<1<<64\n            if (table,index) in selected:\n                assert b&~0x60==selected[(table,index)],\'published heap leaf differs\'\n            else:\n                assert a&~0x60==b&~0x60 and (a|b)==b,\'unrelated translation changed\'\n    for i in range(519):\n        table,index=slot(before,i)\n        old_expected=((before[\'state\'][3]+i*PAGE)|LEAF) if i<old else 0\n        assert before[\'tables\'][table][index]&~0x60==old_expected,\'old heap leaf differs\'\n    return max(old,new)\n\n\ndef check(record):\n    old,new,base=record[\'old_count\'],record[\'new_count\'],record[\'new_base\']\n    detachment=record.get(\'detachment\')\n    if detachment is not None:assert record[\'operation\']==6\n    count=published(record[\'before\'],record[\'stored\'],old,new,base,detachment)\n    assert record[\'published_before_invalidations\'],\'missing publication barrier observation\'\n    assert len(record[\'invalidations\'])==count,\'incomplete invalidation interval\'\n    for index,event in enumerate(record[\'invalidations\']):\n        assert event[\'index\']==index and event[\'address\']==HEAP+index*PAGE,\'wrong invalidation page/order\'\n        assert event[\'thread\']==record[\'before\'][\'thread\'],\'local invalidation changed CPU\'\n    assert record[\'after\'][\'tables\']==record[\'stored\'][\'tables\'],\'translations changed during invalidation\'\n    assert mode(record[\'after\'],detachment)==mode(record[\'before\'],detachment)\n    assert record[\'after\'][\'thread\']==record[\'before\'][\'thread\']\n    assert record[\'after\'][\'context\']==record[\'before\'][\'context\']\n    assert record[\'after\'][\'state\']==record[\'before\'][\'state\']\n    assert record[\'after\'][\'tokens\']==record[\'before\'][\'tokens\']\n    assert record[\'return_stack\']==record[\'entry_stack\'] and record[\'return_address\']==record[\'entry_return_address\']\n    assert record[\'final_barrier_observed\'],\'missing final publication barrier\'\n    return dict(passed=True,pages_invalidated=count,\n        scope=\'Recorded active heap publication or whole detached cleanup bound to its observed flushing CR3 handoff, plus current-context post-INVLPG boundaries and final barrier. Not TLB introspection, continuous mode, AP/DMA/async or general stable ownership qualification\')\n'
translation_trace_model_source='"""Parse saved QEMU TCG CPU states immediately following the publisher INVLPG.\n\nThese are execution-log observations, not a TLB dump or general CPU exclusion.\n"""\nimport re\n\n\ndef parse(raw,site):\n    # With default chaining, QEMU\'s exec logger also emits link diagnostics,\n    # including on a CPU with no states inside the address filter.\n    text=\'\'.join(line for line in raw.decode(\'ascii\').splitlines(keepends=True)\n        if not re.fullmatch(r\'Linking TBs 0x[0-9a-f]+ index [01] -> 0x[0-9a-f]+\\n?\',line))\n    starts=list(re.finditer(r\'^Trace ([0-9]+): (0x[0-9a-f]+) \\[([0-9a-f]+)/([0-9a-f]+)/[^\\]]+\\][^\\n]*\\n\',text,re.M))\n    assert not starts or not text[:starts[0].start()].strip(),\'unexpected trace prefix\'\n    result=[]\n    for i,header in enumerate(starts):\n        cpu,tb,_,pc=header.groups()\n        pc=int(pc,16)\n        assert pc==site,\'unexpected CPU trace PC\'\n        block=text[header.end():starts[i+1].start() if i+1<len(starts) else len(text)]\n        def value(name):\n            values=re.findall(r\'\\b\'+name+r\'\\s*=([0-9a-fA-F]+)\',block)\n            assert len(values)==1,(\'missing or duplicate CPU state\',name)\n            return int(values[0],16)\n        assert value(\'RIP\')==site and value(\'CS\')&3==0\n        stopped=re.findall(r\'^Stopped execution of TB chain before (0x[0-9a-f]+) \\[([0-9a-f]+)\\][^\\n]*$\',block,re.M)\n        assert len(stopped)==sum(line.startswith(\'Stopped execution\') for line in block.splitlines())\n        assert len(stopped)<=1 and all(pointer==tb and int(address,16)==site for pointer,address in stopped)\n        result.append(dict(cpu=int(cpu),index=value(\'RCX\'),address=value(\'RAX\'),\n            cr0=value(\'CR0\'),cr3=value(\'CR3\'),cr4=value(\'CR4\'),efer=value(\'EFER\'),flags=value(\'RFL\'),cancelled=bool(stopped)))\n    assert not text or starts,\'unparsed nonempty CPU trace\'\n    return result\n\n\ndef completed(events):\n    """Keep explicit cancelled attempts separate and require their exact retry.\n\n    A CPU dump precedes its execution block. QEMU explicitly reports a block\n    stopped before execution; it can then log the same post-INVLPG PC again.\n    No unmarked duplicate, different retry or terminal cancellation is removed.\n    """\n    pending=None\n    states=[]\n    cancelled=[]\n    for event in events:\n        key={k:v for k,v in event.items() if k!=\'cancelled\'}\n        if pending is not None:assert key==pending,\'cancelled block lacks matching retry\'\n        if event[\'cancelled\']:\n            pending=key\n            cancelled.append(event)\n        else:\n            states.append(event)\n            pending=None\n    assert pending is None,\'terminal cancelled block has no retry\'\n    return states,cancelled\n'
interval_model_sha256='19cb7e8f13e08588c7b5290ab7f07928baed7e885fd0ad30be56c5a6853600f3'
immutable_head='7f454c4602010103000000000000000002003e000100000080654a00000000004000000000000000000000000000000000000000400038000b000000000000000100000004000000000000000000000000004000000000000000400000000000e006000000000000e0060000000000000010000000000000010000000500000000100000000000000010400000000000001040000000000085b218000000000085b21800000000000010000000000000010000000400000000d018000000000000d058000000000000d0580000000000407005000000000040700500000000000010000000000000010000000600000060461e000000000060565e0000000000'
serial_sites=None
serial_patterns=[('544f50414c5f534f555243455f53455249414c5f410a', '5561626364656667'), ('544f50414c5f534f555243455f53455249414c5f420a', '3132333435363738')]
extent_inventory=None
native_sites={'halt': 45803143, 'exits': [45697814, 45699463]}

import gdb
import hashlib
import json
import struct
import traceback

def reg(name): return int(gdb.parse_and_eval('$'+name)) & ((1<<64)-1)
def address(name): return int(gdb.parse_and_eval('(unsigned long long)&'+name))
def memory(pointer, size): return bytes(gdb.selected_inferior().read_memory(pointer, size)) if size else b''
def words(pointer, count): return list(struct.unpack('<'+'Q'*count, memory(pointer, count*8)))
def word(pointer): return words(pointer, 1)[0]
def signed(value): return value if value < (1<<63) else value-(1<<64)
def state(): return words(address('topal_x86_frame_mm_state_v1'), 4)
def prefix(pages): return hashlib.sha256(memory(0x5f7000, pages*4096)).hexdigest()
def credentials_pointer():
    return word(context+920)+96 if memory(context+896,1)[0] == 1 else 0x7fff18
def file_controls():
    return (memory(context+472,152)+memory(context+736,160)).hex()

context = address('topal_bootstrap_storage') + 512
current = pending = startup_current = bridge_current = None
component_returns = {}
syscall_returns = {}
observed = dict(passed=False, executions=[], startup_executions=[], file_executions=[], shell_executions=[], command_executions=[], poll_executions=[], bridge_returns=[])
callee = ['rbx', 'rbp', 'r12', 'r13', 'r14', 'r15']

class Checked(gdb.Breakpoint):
    def stop(self):
        try:
            return self.observe()
        except Exception:
            traceback.print_exc()
            observed['observer_failure'] = traceback.format_exc()
            observed['active_startup'] = startup_current
            observed['active_bridge'] = bridge_current
            if translation_profile is not None:
                observed['active_translation_publication']=translation_active
                observed['active_translation_request']=translation_request
                observed['pending_translation_root_switch']=translation_root_switch_pending
            if image_publication_profile is not None:
                observed['active_image_publication']=image_publication_active
            if process_preparation_profile is not None:
                observed['active_process_preparation']=process_preparation_active
            with open(observation_path, 'w') as handle:
                json.dump(observed, handle, indent=2)
            return True

class SourceReturned(Checked):
    def observe(self):
        global current
        self.enabled = False
        assert current and pending is None and reg('cs') & 3 == 3
        assert reg('rax') == 0, ('source case failed', reg('rax'), current)
        assert reg('rsp') == current['stack']+8
        assert {name:reg(name) for name in callee} == current['callee']
        after = state()
        assert after[1:3] == current['before'][1:3], (after, current['before'])
        assert prefix(after[2]) == current['prefix_before']
        assert word(context+904) == current['snapshot']
        assert hashlib.sha256(memory(current['snapshot']+0x9e00,512)).hexdigest() == current['command_before']
        process_regression_case_returned()
        if component.get('mode') == 'exec':
            return exec_returned(current,after)
        if component.get('mode') == 'signals':
            return signal_returned(current,after)
        if component.get('mode') == 'pipes':
            return pipe_returned(current,after)
        if component.get('mode') == 'storage':
            return storage_returned(current,after)
        if component.get('mode') == 'metadata':
            interval_case_completed()
            return metadata_returned(current,after)
        if component.get('mode') == 'serial':
            return serial_returned(current,after)
        if component.get('mode') == 'stat':
            return stat_returned(current,after)
        calls = current['calls']
        expected_numbers = [12,12,63,63,63,63,63,63,63,1,1,1,1]
        original = current['before'][1]
        expected_results = [original,0x63a000,0,0]+[-14]*5+[0,-9,-22,-14]
        if component.get('mode') == 'transfers':
            expected_numbers += [1,1,1,79]
            expected_results += [-14,24,24,len(current['cwd_expected'])//2]
            assert [row['args'] for row in calls[13:17]] == [
                [1,0x639fff,2],[1,0x5ffff8,24],[1,0x638ff8,24],[0x638fff,5,0]]
            assert word(word(context+928)+40) == current['cwd_before']
            assert calls[16]['output_hex'] == current['cwd_expected']
        assert [row['number'] for row in calls] == expected_numbers+[12], calls
        expected_results += [original]
        assert [row['result'] for row in calls] == expected_results, calls
        assert [row['args'][0] for row in calls[2:9]] == [
            0x5ffff8,0x638ff8,0x639fff,0x63a000,(1<<64)-1,0x400000,0x800000]
        assert calls[0]['args'][0] == 0 and calls[1]['args'][0] == 0x63a000
        assert [row['args'] for row in calls[9:13]] == [
            [1,(1<<64)-1,0],[0,(1<<64)-1,0],
            [1,(1<<64)-1,257],[1,(1<<64)-1,1]]
        assert calls[-1]['args'][0] == original
        current['after'] = after
        observed['executions'].append(current)
        print('SOURCE_USER_CASES_PASS', len(observed['executions']), len(calls), flush=True)
        current = None
        return False

class SourceEntered(Checked):
    def observe(self):
        global current
        assert current is None and pending is None
        assert reg('cs') & 3 == 3 and reg('cr0') & (1<<16)
        stack = reg('rsp')
        assert 0x7fe000 <= stack < 0x800000 and stack % 16 == 8
        return_site = word(stack)
        assert 0x4e0000 <= return_site < 0x4e8000
        before = state()
        assert before[1] == 0x5f7000+before[2]*4096
        snapshot = word(context+904)
        assert snapshot
        current = dict(stack=stack, before=before, prefix_before=prefix(before[2]),
                       callee={name:reg(name) for name in callee}, calls=[],
                       snapshot=snapshot,
                       command_before=hashlib.sha256(memory(snapshot+0x9e00,512)).hexdigest())
        if component.get('mode') == 'transfers':
            current['cwd_before'] = word(word(context+928)+40)
            current['cwd_expected'] = {3:b'/\0',4:b'/bin\0',6:b'/tmp\0'}[current['cwd_before']].hex()
        if component.get('mode') == 'signals':
            current['table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
        if component.get('mode') == 'pipes':
            current['pipe_table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
            current['_pipe_initial'] = memory(word(context+928)+PIPE_BASE,PIPE_BYTES).hex()
        if component.get('mode') == 'storage':
            current['storage_table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
            current['_storage_initial'] = memory(word(context+928)+STORAGE_BASE,STORAGE_BYTES).hex()
        if component.get('mode') == 'metadata':
            metadata_begin(current)
        if component.get('mode') == 'serial':
            current['serial_table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
            current['serial_received']=[]
            current['serial_markers']=0
        if component.get('mode') == 'stat':
            current['stat_table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
        process_regression_case_entered()
        if return_site not in component_returns:
            component_returns[return_site] = SourceReturned('*'+hex(return_site), internal=True)
        component_returns[return_site].enabled = True
        return False

class SyscallReturned(Checked):
    def observe(self):
        global pending
        self.enabled = False
        assert (current or startup_current) and pending and reg('cs') & 3 == 3
        pending['result'] = signed(reg('rax'))
        pending['phase_after'] = memory(context+104,1)[0]
        copy_source_syscall_returned(pending)
        staged_source_syscall_returned(pending)
        pipe_fixed_syscall_returned(pending)
        pipe_loop_syscall_returned(pending)
        interval_syscall_returned(pending)
        if current and component.get('mode') == 'transfers' and pending['number'] == 79:
            expected = bytes.fromhex(current['cwd_expected'])
            assert pending['result'] == len(expected), pending
            pending['output_hex'] = memory(pending['args'][0],len(expected)).hex()
            assert pending['output_hex'] == current['cwd_expected'], pending
        if current and component.get('mode') == 'exec' and pending['number'] == 59:
            observe_exec_result(pending)
        if current and component.get('mode') == 'signals' and pending['number'] in [13,14]:
            observe_signal_result(pending)
        if current and component.get('mode') == 'pipes' and pending['number'] != 12:
            pipe_result(pending)
        if current and component.get('mode') == 'storage' and pending['number'] != 12:
            storage_result(pending)
        if current and component.get('mode') == 'metadata' and pending['number'] != 12:
            metadata_result(pending)
        if current and component.get('mode') == 'serial' and pending['number'] != 12:
            serial_result(pending)
        if current and component.get('mode') == 'stat' and pending['number'] in [5,262]:
            stat_result(pending)
        if startup_current and startup_current.get('kind') == 'poll':
            observe_poll_result(pending)
        if startup_current and startup_current.get('kind') in ['shell','command']:
            observe_shell_result(pending)
        if startup_current and startup_current.get('kind') == 'file':
            n = pending['number']
            result = pending['result']
            if (n in [5,262] and result == 0) or (n == 217 and result > 0):
                pointer = pending['args'][2 if n == 262 else 1]
                pending['output_hex'] = memory(pointer,result if n == 217 else 144).hex()
        if pending['result'] in [-14,-22] or pending['number'] == 12:
            assert pending['phase_after'] == pending['phase_before'], pending
        if startup_current and startup_current.get('kind') == 'file' and pending['result'] == -14:
            assert file_controls() == pending['controls_before'], pending
        (current or startup_current)['calls'].append(pending)
        pending = None
        return False

class SyscallEntered(Checked):
    def __init__(self, specification, count):
        super().__init__(specification, internal=True)
        self.count = count

    def observe(self):
        global pending
        assert (current or startup_current) and pending is None and reg('cs') & 3 == 3
        pending = dict(number=reg('rdi'),
                       args=[reg(name) for name in ['rsi','rdx','rcx','r8'][:self.count]],
                       phase_before=memory(context+104,1)[0])
        copy_source_syscall_entered(pending)
        staged_source_syscall_entered(pending)
        pipe_fixed_syscall_entered(pending)
        pipe_loop_syscall_entered(pending)
        interval_syscall_entered(pending)
        if current and component.get('mode') == 'exec' and pending['number'] == 59:
            observe_exec_request(pending)
        if current and component.get('mode') == 'signals' and pending['number'] in [13,14]:
            observe_signal_request(pending)
        if current and component.get('mode') == 'pipes' and pending['number'] != 12:
            pipe_request(pending)
        if current and component.get('mode') == 'storage' and pending['number'] != 12:
            storage_request(pending)
        if current and component.get('mode') == 'metadata' and pending['number'] != 12:
            metadata_request(pending)
        if current and component.get('mode') == 'serial' and pending['number'] != 12:
            serial_request(pending)
        if current and component.get('mode') == 'stat' and pending['number'] in [5,262]:
            stat_request(pending)
        if startup_current and startup_current.get('kind') == 'poll':
            observe_poll_request(pending)
        if startup_current and startup_current.get('kind') in ['shell','command']:
            observe_shell_request(pending)
        if startup_current and startup_current.get('kind') == 'file':
            pending['controls_before'] = file_controls()
            if pending['number'] in [257,262] and pending['args'][1] == 0x637ff8:
                data = memory(0x637ff8,64)
                pending['pathname_hex'] = data[:data.index(0)+1].hex()
        return_site = word(reg('rsp'))
        assert component['base'] <= return_site < component['base']+component['text_bytes']
        if return_site not in syscall_returns:
            syscall_returns[return_site] = SyscallReturned('*'+hex(return_site), internal=True)
        syscall_returns[return_site].enabled = True
        return False

class StartupReturned(Checked):
    def observe(self):
        global startup_current
        self.enabled = False
        row = startup_current
        if row and row.get('kind') == 'poll':
            return poll_returned(row)
        if row and row.get('kind') in ['shell','command']:
            return shell_returned(row)
        if row and row.get('kind') == 'file':
            return file_returned(row)
        assert row and current is None and pending is None
        assert reg('cs') & 3 == 3 and reg('rsp') == row['stack']+8
        assert {name:reg(name) for name in callee} == row['callee']
        assert credentials_pointer() == row['credentials_pointer']
        assert words(row['credentials_pointer'],8) == row['credentials']
        n = row['number']
        expected = -2 if n == 262 else (8 if n == 318 else 0)
        assert signed(reg('rax')) == expected, ('startup source failed', signed(reg('rax')), row)
        after = state()
        assert after[1:3] == row['before'][1:3]
        assert prefix(after[2]) == row['prefix_before']
        calls = row['calls']
        assert calls[0]['number'] == calls[1]['number'] == calls[-1]['number'] == 12
        assert calls[0]['args'][0] == 0 and calls[1]['args'][0] == 0x63a000
        assert [calls[i]['result'] for i in [0,1,-1]] == [row['before'][1],0x63a000,row['before'][1]]
        assert calls[-1]['args'][0] == row['before'][1]
        assert all(call['number'] == n for call in calls[2:-1])
        if n == 262:
            assert [call['result'] for call in calls[2:-1]] == [-14]*4+[-2]
            assert [call['args'][1] for call in calls[2:-1]] == [
                0x63a000,(1<<64)-1,0x800000,0x639fff,0x638ff8]
            assert calls[-2]['args'][2] == (1<<64)-1
            assert memory(row['destination'],144).hex() == row['output_before']
        else:
            errors = calls[2:-2]
            if n == 318:
                assert [call['result'] for call in errors[:3]] == [0,-22,-22]
                assert [call['args'][:3] for call in errors[:3]] == [
                    [(1<<64)-1,0,1],[(1<<64)-1,8,8],[(1<<64)-1,17,1]]
                errors = errors[3:]
            assert [call['result'] for call in errors] == [-14]*5
            index = 3 if n == 302 else (1 if n == 157 else 0)
            assert [call['args'][index] for call in errors] == [
                0x63a000,(1<<64)-1,0x400000,0x800000,0x639fff]
            assert calls[-2]['args'][index] == (0x5ffff8 if n == 302 else 0x638ff8)
            assert calls[-2]['result'] == expected
            output = memory(row['destination'],8 if n == 318 else 16)
            if n == 302: assert output == struct.pack('<QQ',0x800000,(1<<64)-1)
            if n == 157: assert output == b'busybox'+bytes(9)
            row['output_after'] = output.hex()
        row['after'] = after
        row['phase_after'] = memory(context+104,1)[0]
        expected_phase = {302:6,318:6,157:10,262:12}[n]
        # Exec retains an active descriptor/namespace owner. Its general
        # pathname service runs before the sealed startup fallback and does
        # not advance that fallback's phase.
        if n == 262 and row['table_active']:
            expected_phase = row['phase_before']
        assert row['phase_after'] == expected_phase, row
        observed['startup_executions'].append(row)
        print('SOURCE_STARTUP_CASES_PASS', len(observed['startup_executions']), n, len(calls), flush=True)
        startup_current = None
        return False

class StartupEntered(Checked):
    def observe(self):
        global startup_current
        assert current is startup_current is pending is None
        assert reg('cs') & 3 == 3 and reg('cr0') & (1<<16)
        stack = reg('rsp')
        assert 0x7fe000 <= stack < 0x800000 and stack % 16 == 8
        return_site = word(stack)
        assert component['base'] <= return_site < component['base']+component['text_bytes']
        args = [reg(name) for name in ['rsi','rdx','rcx','r8']]
        n = reg('rdi')
        if component.get('mode') == 'poll':
            return poll_entered(n,args,stack,return_site)
        if (n == 0 and (args[0] == 0 or args[2] == 1)) or n in [1,13,16,63,79,80]:
            return shell_entered(n,args,stack,return_site)
        if n in [5,257,217,0] or (n == 262 and args[1] != 0x4a6900):
            return file_entered(n,args,stack,return_site)
        assert n in [302,318,157,262]
        destination = args[{302:3,318:0,157:1,262:2}[n]]
        before = state()
        startup_current = dict(number=n,args=args,stack=stack,before=before,
            prefix_before=prefix(before[2]),callee={name:reg(name) for name in callee},
            calls=[],destination=destination,
            output_before=memory(destination,144 if n == 262 else (8 if n == 318 else 16)).hex(),
            phase_before=memory(context+104,1)[0],
            table_active=word(word(context+928)) == 1,
            credentials_pointer=credentials_pointer(),credentials=words(credentials_pointer(),8))
        assert startup_current['credentials'] == [11,0,12,0,13,0,14,0]
        assert startup_current['phase_before'] == ({302:5,318:6,157:9,262:11}[n])
        if return_site not in component_returns:
            component_returns[return_site] = StartupReturned('*'+hex(return_site), internal=True)
        component_returns[return_site].enabled = True
        return False

class BridgeReturned(Checked):
    def observe(self):
        global bridge_current
        self.enabled = False
        row = bridge_current
        assert row and current is startup_current is pending is None
        assert reg('rsp') == row['stack']+8 and reg('cs') & 3 == 3
        assert {name:reg(name) for name in row['registers']} == row['registers']
        assert credentials_pointer() == row['credentials_pointer']
        assert words(row['credentials_pointer'],8) == [11,0,12,0,13,0,14,0]
        observed['bridge_returns'].append(row)
        bridge_current = None
        return False

class BridgeEntered(Checked):
    def observe(self):
        global bridge_current
        assert current is startup_current is pending is bridge_current is None
        stack = reg('rsp')
        site = word(stack)
        assert 0x4a6100 <= site < 0x4b0000
        bridge_current = dict(stack=stack,return_site=site,credentials_pointer=credentials_pointer(),
            registers={name:reg(name) for name in callee+['rdi','rsi','rdx','r10','r8','r9']})
        if site not in component_returns:
            component_returns[site] = BridgeReturned('*'+hex(site), internal=True)
        component_returns[site].enabled = True
        return False

def file_entered(n,args,stack,return_site):
    global startup_current
    assert word(word(context+928)) == 0, 'bounded file fixture must precede table activation'
    before = state()
    assert before[1:3] == [0x619000,34]
    destination = args[2] if n == 262 else args[1]
    size = 0 if n == 257 else (512 if n == 217 else (128 if n == 0 else 144))
    path = None
    if n in [257,262]:
        data = memory(args[1],64)
        path = data[:data.index(0)+1].hex()
    startup_current = dict(kind='file',number=n,args=args,stack=stack,before=before,
        prefix_before=prefix(before[2]),callee={name:reg(name) for name in callee},calls=[],
        destination=destination,output_before=memory(destination,size).hex(),
        output_size=size,path=path,credentials_pointer=credentials_pointer(),
        credentials=words(credentials_pointer(),8),phase_before=memory(context+104,1)[0],
        controls_before=file_controls())
    assert startup_current['credentials'] == [11,0,12,0,13,0,14,0]
    if return_site not in component_returns:
        component_returns[return_site] = StartupReturned('*'+hex(return_site), internal=True)
    component_returns[return_site].enabled = True
    return False

def file_returned(row):
    global startup_current
    assert current is None and pending is None and reg('cs') & 3 == 3
    assert reg('rsp') == row['stack']+8
    assert {name:reg(name) for name in callee} == row['callee']
    assert credentials_pointer() == row['credentials_pointer']
    assert words(row['credentials_pointer'],8) == row['credentials']
    after = state()
    assert after[1:3] == row['before'][1:3]
    assert prefix(after[2]) == row['prefix_before']
    n = row['number']
    calls = row['calls']
    assert calls[0]['number'] == calls[1]['number'] == calls[-1]['number'] == 12
    assert [calls[i]['args'][0] for i in [0,1,-1]] == [0,0x63a000,0x619000]
    assert [calls[i]['result'] for i in [0,1,-1]] == [0x619000,0x63a000,0x619000]
    actions = calls[2:-1]
    assert all(c['number'] == n for c in actions)
    path = bytes.fromhex(row['path']) if row['path'] else None
    if n in [257,262]:
        assert [c['args'][1] for c in actions[:4]] == [0x63a000,(1<<64)-1,0x800000,0x639fff]
        assert [c['result'] for c in actions[:4]] == [-14]*4
        actions = actions[4:]
        assert all(c['args'][1] == 0x637ff8 and c['pathname_hex'] == row['path'] for c in actions)
    if n == 257:
        expected = -2 if path == b'/dev/tty\0' else 3
        assert len(actions) == 1 and actions[0]['result'] == expected
    elif n == 0:
        expected = 0
        assert [c['args'][1] for c in actions] == [(1<<64)-1,(1<<47)-4096-127,0x63a000]
        assert [c['result'] for c in actions] == [-14,-14,0]
    elif n == 262 and path == b'/var/spool/mail/root\0':
        expected = -2
        assert len(actions) == 1 and actions[0]['result'] == -2 and actions[0]['args'][2] == 0x63a000
    elif n == 217 and len(actions) == 1:
        expected = 0
        assert actions[0]['args'][1] == 0x63a000 and actions[0]['result'] == 0
    else:
        expected = actions[-1]['result']
        assert expected in ([72,80] if n == 217 else [0])
        index = 2 if n == 262 else 1
        assert [c['args'][index] for c in actions[:-1]] == [0x63a000,(1<<64)-1,0x400000,0x800000,0x639fff]
        assert [c['result'] for c in actions[:-1]] == [-14]*5
        actual = 0x639fb0 if n == 217 else (0x5ffff8 if n == 5 and row['args'][0] == 1 else 0x638ff8)
        assert actions[-1]['args'][index] == actual
        size = expected if n == 217 else 144
        assert memory(row['destination'],size).hex() == actions[-1]['output_hex']
        before = bytes.fromhex(row['output_before'])
        assert memory(row['destination']+size,len(before)-size) == before[size:]
        row['output_after'] = memory(row['destination'],size).hex()
    assert signed(reg('rax')) == expected, ('file source failed',signed(reg('rax')),row)
    if 'output_after' not in row:
        assert memory(row['destination'],row['output_size']).hex() == row['output_before']
    row['after'] = after
    row['phase_after'] = memory(context+104,1)[0]
    observed['file_executions'].append(row)
    print('SOURCE_FILE_CASES_PASS',len(observed['file_executions']),n,len(calls),flush=True)
    startup_current = None
    return False


def protected_controls():
    return (memory(context+152,104)+memory(context+416,8)).hex()+file_controls()
def command_state():
    snapshot = word(context+904)
    assert snapshot
    return memory(snapshot+0x9e00,512).hex()
def masked_prefix(pages,pointer,size):
    data = bytearray(memory(0x5f7000,pages*4096))
    left,right=max(pointer,0x5f7000),min(pointer+size,0x5f7000+len(data))
    if right>left: data[left-0x5f7000:right-0x5f7000] = bytes(right-left)
    return hashlib.sha256(data).hexdigest()
def shell_shape(n,args):
    a,b,c,d=args
    if n==16: return False,0,c
    input = n in [1,80] or (n==13 and b!=0)
    size = 390 if n==63 else (32 if n==13 else (2 if n in [79,80] else c))
    pointer = (b if b else c) if n==13 else (a if n in [63,79,80] else b)
    return input,size,pointer

def shell_entered(n,args,stack,return_site):
    global startup_current
    command = n==0 and args[0]==0
    input,size,pointer = (False,args[2],args[1]) if command else shell_shape(n,args)
    before = state()
    assert before[1:3]==[0x619000,34]
    write_pointer,write_size = (0,0) if input else (pointer,size)
    startup_current = dict(kind='command' if command else 'shell',number=n,args=args,
        stack=stack,before=before,callee={name:reg(name) for name in callee},calls=[],
        input=bool(input),size=size,pointer=pointer,
        original_bytes=memory(pointer,size if size else 1).hex(),
        write_pointer=write_pointer,write_size=write_size,
        prefix_before=masked_prefix(before[2],write_pointer,write_size),
        credentials_pointer=credentials_pointer(),credentials=words(credentials_pointer(),8),
        phase_before=memory(context+104,1)[0],queue_before=command_state())
    assert startup_current['credentials']==[11,0,12,0,13,0,14,0]
    if return_site not in component_returns:
        component_returns[return_site]=StartupReturned('*'+hex(return_site),internal=True)
    component_returns[return_site].enabled=True
    return False

def observe_shell_request(call):
    call['protected_before']=protected_controls()
    call['queue_before']=command_state()
    row=startup_current
    if row['kind']=='shell' and row['input'] and call['number']==row['number']:
        index=1 if call['number'] in [1,13] else 0
        pointer=call['args'][index]
        if pointer in [0x638ff8,0x638fff] or component['base']<=pointer<component['base']+component['text_bytes']:
            call['input_hex']=memory(pointer,row['size']).hex()

def observe_shell_result(call):
    row=startup_current
    call['queue_after']=command_state()
    if call['result']==-14:
        assert protected_controls()==call['protected_before'],call
    if row['kind']=='shell' and not row['input'] and call['number']==row['number'] and call['result']>=0:
        n=call['number']
        if n!=16:
            index=2 if n==13 else (0 if n in [63,79] else 1)
            call['output_hex']=memory(call['args'][index],row['size']).hex()

def shell_returned(row):
    global startup_current
    assert current is None and pending is None and reg('cs')&3==3
    assert reg('rsp')==row['stack']+8
    assert {name:reg(name) for name in callee}==row['callee']
    assert credentials_pointer()==row['credentials_pointer']
    assert words(row['credentials_pointer'],8)==row['credentials']
    after=state()
    assert after[1:3]==row['before'][1:3]
    assert masked_prefix(after[2],row['write_pointer'],row['write_size'])==row['prefix_before']
    calls=row['calls']
    assert [calls[i]['number'] for i in [0,1,-1]]==[12,12,12]
    assert [calls[i]['args'][0] for i in [0,1,-1]]==[0,0x63a000,0x619000]
    assert [calls[i]['result'] for i in [0,1,-1]]==[0x619000,0x63a000,0x619000]
    if row['kind']=='command':
        command_returned(row)
    else:
        n,args,size,input=row['number'],row['args'],row['size'],row['input']
        actions=calls[2:-1]
        assert all(call['number']==n for call in actions)
        if n==16:
            expected=-25
            assert len(actions)==1 and actions[0]['args'][2]==(1<<64)-1
            assert memory(row['pointer'],1).hex()==row['original_bytes']
        else:
            index=1 if n in [1,13,0] and (n!=13 or input) else (2 if n==13 else 0)
            bad=[0x63a000,(1<<64)-1,0x800000,0x63b000 if size==1 else 0x639fff]
            if not input: bad.append(0x400000)
            assert [call['args'][index] for call in actions[:-1]]==bad
            assert [call['result'] for call in actions[:-1]]==[-14]*len(bad)
            expected=size if n in [0,1,79] else 0
            good=actions[-1]
            assert good['result']==expected
            if input:
                assert good['input_hex']==row['original_bytes']
                if n==13: assert component['base']<=good['args'][index]<component['base']+component['text_bytes']
                assert memory(row['pointer'],size).hex()==row['original_bytes']
            else:
                assert memory(row['pointer'],size).hex()==good['output_hex']
            row['output_after']=memory(row['pointer'],size).hex()
        assert signed(reg('rax'))==expected,('shell case failed',signed(reg('rax')),row)
        observed['shell_executions'].append(row)
        print('SOURCE_SHELL_CASES_PASS',len(observed['shell_executions']),n,len(calls),flush=True)
    row['after']=after
    row['phase_after']=memory(context+104,1)[0]
    startup_current=None
    return False

def command_returned(row):
    actions=row['calls'][2:-1]
    assert [call['number'] for call in actions]==[0]*10
    count=row['args'][2]
    assert [call['args'][1] for call in actions]==[
        (1<<64)-1,0x63a000,(1<<64)-1,0x400000,0x800000,0x639fff,
        0x638ff8,(1<<64)-1,0x639fff,0x638ff9]
    assert [call['args'][2] for call in actions]==[0]+[count]*5+[1,0,count,count]
    assert [call['result'] for call in actions[:9]]==[0]+[-14]*5+[1,0,-14]
    rest=actions[-1]['result']
    assert rest>0 and signed(reg('rax'))==rest+1
    assert all(call['phase_after']==call['phase_before'] for call in actions[:-1])
    assert actions[0]['queue_before']==actions[0]['queue_after']
    assert actions[1]['queue_after']==actions[2]['queue_after']==actions[3]['queue_after']==actions[4]['queue_after']==actions[5]['queue_after']
    assert actions[6]['queue_after']==actions[7]['queue_after']==actions[8]['queue_after']
    serial=count==23
    def queue(call):
        data=bytes.fromhex(call['queue_after'])
        return data[:256],struct.unpack_from('<QQQ',data,256)
    if serial:
        queued=queue(actions[1]); short=queue(actions[6]); complete=queue(actions[-1])
        assert queued[1][1]==23 and short[1][1]==22 and complete[1][1]==0
        assert short[0][:22]==queued[0][1:23] and short[0][22:]==bytes(234)
        assert complete[0]==bytes(256)
    else:
        assert queue(actions[1])[1][0]==0 and queue(actions[6])[1][0]==1
        assert queue(actions[-1])[1][0]==0
    before=bytes.fromhex(row['original_bytes'])
    total=rest+1
    assert memory(row['pointer']+total,len(before)-total)==before[total:]
    row['delivered_hex']=memory(row['pointer'],total).hex()
    observed['command_executions'].append(row)
    print('SOURCE_COMMAND_CASES_PASS',len(observed['command_executions']),total,len(row['calls']),flush=True)



def exec_protected():
    table = word(context+928)
    assert word(table) == 1
    return dict(table_sha256=hashlib.sha256(memory(table,8192)).hexdigest(),
        registrations=memory(context+152,104).hex(),
        shell=memory(context+416,8).hex(),files=memory(context+736,160).hex(),
        command=memory(word(context+904)+0x9e00,512).hex(),
        snapshot=word(context+904),auxiliary=word(context+920))

def observe_exec_request(call):
    call['protected_before'] = exec_protected()
    assert memory(word(context+904)+0x9800,0x600) == bytes(0x600)
    name,argv,envp = call['args']
    def candidate(address,size):
        # Read only the candidate's actual mapped portion, including code data.
        if component['base'] <= address < component['base']+component['text_bytes']:
            return memory(address,min(size,component['base']+component['text_bytes']-address))
        if 0x5f7000 <= address < 0x63a000:
            return memory(address,min(size,0x63a000-address))
        return b''
    call['pathname_prefix_hex'] = candidate(name,256).hex()
    call['argv_prefix_hex'] = candidate(argv,72).hex()
    call['environment_prefix_hex'] = candidate(envp,136).hex()

def observe_exec_result(call):
    assert call['result'] in [-14,-2,-36,-22,-7],call
    assert exec_protected() == call['protected_before'],call
    assert memory(word(context+904)+0x9800,0x600) == bytes(0x600)
    call['private_staging_zero'] = True
    call['protected_state_unchanged'] = True

def exec_returned(row,after):
    global current
    calls = row['calls']
    assert [c['number'] for c in calls] == [12,12]+[59]*29+[12]
    assert [calls[i]['args'][0] for i in [0,1,-1]] == [0,0x63a000,0x619000]
    assert [calls[i]['result'] for i in [0,1,-1]] == [0x619000,0x63a000,0x619000]
    actions=calls[2:-1]
    expected = [-14]*5+[-2,-36]+[-14]*10+[-22,-7,-7]+[-14]*6+[-7]*3
    assert len(expected)==29
    assert [c['result'] for c in actions] == expected
    assert all(c['private_staging_zero'] and c['protected_state_unchanged'] for c in actions)
    assert [c['args'][0] for c in actions[:5]] == [0,0x63a000,(1<<64)-1,0x800000,0x639fff]
    assert [c['args'][1] for c in actions[7:12]] == [0,0x63a000,(1<<64)-4,0x800000,0x639ffc]
    assert actions[12]['args'][1] == 0x5ffffc
    assert actions[13]['args'][:2] == [0x638ff8,0x637ffc]
    assert component['base'] <= actions[14]['args'][1] < component['base']+component['text_bytes']
    assert actions[16]['args'][1] == 0x639ff0
    assert actions[23]['args'][2] == 0x639ffc
    assert actions[25]['args'][2] == 0x639ff0
    row['after'] = after
    observed['executions'].append(row)
    print('SOURCE_EXEC_CASES_PASS',len(observed['executions']),len(actions),flush=True)
    current = None
    return False



def signal_read(pointer,size):
    if component['base'] <= pointer < component['base']+component['text_bytes']:
        return memory(pointer,min(size,component['base']+component['text_bytes']-pointer))
    if 0x5f7000 <= pointer < 0x63a000:
        return memory(pointer,min(size,0x63a000-pointer))
    if pointer == 0x400000:
        return memory(pointer,size)
    return b''

def signal_writable(pointer,size):
    return 0x5f7000 <= pointer and pointer+size <= 0x63a000

def signal_context():
    return (memory(context+152,104)+memory(context+416,8)+memory(context+736,160)+
            memory(word(context+904)+0x9e00,512)).hex()

def signal_state(table):
    return dict(blocked=struct.unpack_from('<Q',table,32)[0],
        action10=list(struct.unpack_from('<4Q',table,1792+9*32)))

def observe_signal_request(call):
    table=memory(word(context+928),8192)
    assert word(word(context+928)) == 1
    assert table[1408:1664] == bytes(256)
    call['_table_before'] = table.hex()
    call['state_before'] = signal_state(table)
    call['context_before'] = signal_context()
    size=32 if call['number']==13 else 8
    _,new,old,_=call['args']
    call['input_hex'] = signal_read(new,size).hex() if new else ''
    call['old_output_prefix_before'] = signal_read(old,size).hex() if old else ''

def observe_signal_result(call):
    table=bytearray.fromhex(call.pop('_table_before'))
    number=call['number']
    selector,new,old,sigsetsize=call['args']
    size=32 if number==13 else 8
    input_bytes=bytes.fromhex(call['input_hex'])
    expected=0
    output=None
    committed=False
    if sigsetsize!=8: expected=-22
    elif new and len(input_bytes)!=size: expected=-14
    elif number==13:
        if not 1<=selector<=64 or (new and selector in [9,19]): expected=-22
        else:
            at=1792+(selector-1)*32
            output=bytes(table[at:at+32])
            if new:
                handler,flags,restorer,mask=struct.unpack('<4Q',input_bytes)
                table[at:at+32]=struct.pack('<4Q',handler,flags&0xdc000807,restorer,mask&~0x40100)
                committed=True
    else:
        output=bytes(table[32:40])
        if new:
            if selector not in [0,1,2]: expected=-22
            else:
                requested=struct.unpack('<Q',input_bytes)[0]&~0x40100
                previous=struct.unpack('<Q',output)[0]
                value=[previous|requested,previous&~requested,requested][selector]
                table[32:40]=struct.pack('<Q',value)
                committed=True
    if expected==0 and old:
        if signal_writable(old,size):
            assert memory(old,size)==output,call
            call['output_hex']=output.hex()
        else: expected=-14
    assert call['result']==expected,call
    actual=memory(word(context+928),8192)
    assert actual==bytes(table),call
    assert signal_context()==call['context_before'],call
    if expected<0 and old:
        assert signal_read(old,size).hex()==call['old_output_prefix_before'],call
    assert actual[1408:1664]==bytes(256)
    call['state_after']=signal_state(actual)
    call['committed']=committed
    call['complete_table_verified']=True
    call['private_staging_zero']=True

def signal_returned(row,after):
    global current
    calls=row['calls']
    assert [c['number'] for c in calls]==[12,12]+[13]*23+[14]*23+[12]
    assert [calls[i]['result'] for i in [0,1,-1]]==[0x619000,0x63a000,0x619000]
    actions=calls[2:-1]
    assert all(c['complete_table_verified'] and c['private_staging_zero'] for c in actions)
    assert sum(c['result']==-14 for c in actions)==22
    assert sum(c['result']==-22 for c in actions)==6
    assert sum(c['result']==0 for c in actions)==18
    assert sum(c['committed'] for c in actions)==10
    assert sum(c['committed'] and c['result']==-14 for c in actions)==2
    assert hashlib.sha256(memory(word(context+928),8192)).hexdigest()==row['table_before_sha256']
    row['after']=after
    observed['executions'].append(row)
    print('SOURCE_SIGNAL_CASES_PASS',len(observed['executions']),len(actions),flush=True)
    current=None
    return False



def poll_controls():
    return dict(registrations=memory(context+152,104).hex(),header=memory(context+416,8).hex(),
        stat_staging=memory(context+472,152).hex(),file=memory(context+736,160).hex(),queue=command_state())

def poll_bytes(pointer,size):
    if component['base']<=pointer<component['base']+component['text_bytes']:
        return memory(pointer,min(size,component['base']+component['text_bytes']-pointer))
    if 0x5f7000<=pointer<0x63a000:
        return memory(pointer,min(size,0x63a000-pointer))
    if pointer==0x400000: return memory(pointer,size)
    return b''

def poll_entered(n,args,stack,return_site):
    global startup_current
    assert n==0 and args[0]==3 and args[2]==1
    index=len(observed['poll_executions'])
    assert memory(context+416,1)==b'\x01'
    assert memory(context+888,4)==bytes([22+index,index,0,0])
    assert word(word(context+928))==0
    before=state()
    assert before[1:3]==[0x619000,34]
    startup_current=dict(kind='poll',number=n,args=args,stack=stack,before=before,
        index=index,callee={name:reg(name) for name in callee},calls=[],
        prefix_before=prefix(before[2]),credentials_pointer=credentials_pointer(),
        credentials=words(credentials_pointer(),8),controls_before=poll_controls())
    if return_site not in component_returns:
        component_returns[return_site]=StartupReturned('*'+hex(return_site),internal=True)
    component_returns[return_site].enabled=True
    return False

def observe_poll_request(call):
    call['controls_before']=poll_controls()
    n,args=call['number'],call['args']
    if n==7: call['input_hex']=poll_bytes(args[0],8).hex()
    if n==0: call['output_before']=poll_bytes(args[1],1).hex()

def observe_poll_result(call):
    expected=dict(call['controls_before'])
    fields=bytearray.fromhex(expected['file'])
    n,args,result=call['number'],call['args'],call['result']
    if n==7:
        assert args[1:3]==[1,(1<<64)-1]
        if result==1:
            assert struct.unpack('<iH',bytes.fromhex(call['input_hex'])[:6])==(3,1)
            after=memory(args[0],8)
            assert after[:6]==bytes.fromhex(call['input_hex'])[:6] and after[6:]==b'\x01\0'
            call['output_hex']=after.hex()
            fields[891-736]=1
        else:
            assert result==-14
            assert poll_bytes(args[0],8).hex()==call['input_hex']
    elif n==0:
        assert args[0]==3 and args[2]==1
        if result==1:
            assert fields[891-736]==1
            value=bytes([b'\x7fELF'[fields[889-736]]])
            assert memory(args[1],1)==value
            call['output_hex']=value.hex()
            fields[888-736]+=1
            fields[889-736]+=1
            fields[891-736]=0
        else:
            assert result==-14 and poll_bytes(args[1],1).hex()==call['output_before']
    else: assert n==12
    expected['file']=fields.hex()
    actual=poll_controls()
    assert actual==expected,call
    call['controls_after']=actual

def poll_returned(row):
    global startup_current
    assert current is pending is None and signed(reg('rax'))==1
    assert reg('rsp')==row['stack']+8 and reg('cs')&3==3
    assert {name:reg(name) for name in callee}==row['callee']
    assert words(row['credentials_pointer'],8)==row['credentials']
    assert state()[1:3]==row['before'][1:3] and prefix(34)==row['prefix_before']
    calls=row['calls']
    assert [c['number'] for c in calls]==[12,12]+[7]*8+[0]*5+[12]
    assert [calls[i]['result'] for i in [0,1,-1]]==[0x619000,0x63a000,0x619000]
    assert [c['result'] for c in calls[2:-1]]==[-14]*5+[1,-14,1]+[-14]*4+[1]
    assert memory(row['args'][1],1)==bytes([b'\x7fELF'[row['index']]])
    assert memory(context+888,4)==bytes([23+row['index'],row['index']+1,0,0])
    row['after']=state()
    observed['poll_executions'].append(row)
    print('SOURCE_POLL_CASES_PASS',len(observed['poll_executions']),len(calls),flush=True)
    startup_current=None
    return False



extent_first_reach = {}

class ExtentFirstReach(Checked):
    def __init__(self, row):
        super().__init__('*'+hex(extent_inventory['address']+row['offset']), internal=True)
        self.row = row

    def observe(self):
        self.enabled = False
        assert reg('cs') & 3 == 0 and reg('cr0') & (1<<16)
        offset = self.row['offset']
        record = dict(offset=offset, target=self.row['target'],
            candidate=reg('r8'), length=reg('r9'), phase=memory(context+104,1)[0])
        if offset in extent_first_reach:
            # A source-scoped admission observer can record this same stopped
            # instruction first. Both read-only observations must agree.
            assert extent_first_reach[offset] == record
        else:
            extent_first_reach[offset] = record
        return False

def extent_coverage_complete():
    if extent_inventory is None:
        return
    for name, complete in [('callbacks',callback_coverage_complete),
                           ('copies',copy_observation_complete),
                           ('staged',staged_observation_complete),
                           ('pipe-fixed',pipe_fixed_observation_complete),
                           ('pipe-loops',pipe_loop_observation_complete)]:
        if name in selected_extent_observers():
            complete()
    calls = extent_inventory['calls']
    warning_observation_complete()
    random_observation_complete()
    stack_retirement_observation_complete()
    assert extent_first_reach and set(extent_first_reach) <= {row['offset'] for row in calls}
    observed['extent_call_coverage'] = dict(
        observation_passed=True, total_sites=len(calls), reached_sites=len(extent_first_reach),
        reached=[extent_first_reach[offset] for offset in sorted(extent_first_reach)],
        unreached=[row for row in calls if row['offset'] not in extent_first_reach],
        kernel_sha256=extent_inventory['kernel_sha256'],
        inventory_sha256=extent_inventory['inventory_sha256'],
        scope='First reach before helper invocation in this selected execution only; no successful-admission, return, every-length/error-path, direct-access/dominance or production qualification claim')

def selected_extent_observers():
    groups = extent_inventory.get('native_observers',['callbacks','copies','staged'])
    assert groups and len(groups) == len(set(groups))
    assert set(groups) <= {'callbacks','copies','staged','pipe-fixed','pipe-loops'}
    return groups

def install_extent_coverage():
    if extent_inventory is not None:
        for name, install in [('callbacks',install_callback_observation),
                              ('copies',install_copy_observation),
                              ('staged',install_staged_observation),
                              ('pipe-fixed',install_pipe_fixed_observation),
                              ('pipe-loops',install_pipe_loop_observation)]:
            if name in selected_extent_observers():
                install()
        assert address(extent_inventory['function']) == extent_inventory['address']
        install_warning_observation()
        install_random_observation()
        install_stack_retirement_observation()
        if not extent_inventory.get('source_scoped_staged'):
            for row in extent_inventory['calls']:
                ExtentFirstReach(row)

import hashlib

callback_active = None
callback_registered = None
callback_counts = {}
callback_samples = {}
callback_live_sections = {}
callback_callee_registers = ['rbx','rbp','r12','r13','r14','r15']

def callback_translation(pointer):
    assert not (reg('cr4') & (1<<12))
    table = reg('cr3') & 0x000ffffffffff000
    path = []
    user, writable, noexecute = True, True, False
    for shift in [39,30,21,12]:
        assert table % 4096 == 0 and table < 0x40000000
        entry = word(table + ((pointer>>shift)&511)*8)
        assert entry & 1
        user = user and bool(entry&4)
        writable = writable and bool(entry&2)
        noexecute = noexecute or bool(entry&(1<<63))
        path.append(dict(shift=shift,table=table,entry=entry))
        if shift == 12 or (shift in [30,21] and entry&128):
            physical = (entry & (0x000fffffffffffff & ~((1<<shift)-1))) | (pointer&((1<<shift)-1))
            assert physical == pointer and not user and not noexecute
            return dict(path=path,physical=physical,effective_user=user,
                        effective_write=writable,effective_execute=not noexecute)
        table = entry & 0x000ffffffffff000
    raise AssertionError('missing translation leaf')

class CallbackRegistration(Checked):
    def observe(self):
        global callback_registered
        self.enabled = False
        assert callback_registered is None and reg('cs')&3 == 0
        assert word(reg('rsp')+8) == context
        rows = []
        for row in extent_inventory['callback_bindings']['callbacks']:
            actual = word(reg('rsp')+row['entry_stack_offset'])
            assert actual == row['target'] == address(row['native_export'])
            rows.append(dict(gs_slot=row['gs_slot'],argument=row['argument'],target=actual))
        callback_registered = rows
        return False

class CallbackReturned(Checked):
    def __init__(self, site):
        super().__init__('*'+hex(site['return_address']),internal=True)
        self.site = site

    def observe(self):
        global callback_active
        assert callback_active is not None and callback_active['site']==self.site['offset']
        before = callback_active
        assert reg('cs')&3 == 0 and reg('cr0')&(1<<16)
        assert reg('cr3') == before['cr3'] and reg('rsp') == before['rsp']
        assert [reg(r) for r in callback_callee_registers] == before['callee_registers']
        assert memory(context+296,64) == before['captured']
        assert memory(context+952,56) == before['registry']
        assert memory(before['table'],8192) == before['table_bytes']
        assert memory(context+104,1)[0] == before['phase']
        slot = self.site['gs_slot']
        callback_counts[self.site['offset']] = callback_counts.get(self.site['offset'],0)+1
        if self.site['offset'] not in callback_samples:
            callback_samples[self.site['offset']] = dict(
                offset=self.site['offset'],gs_slot=slot,target=before['target'],
                arguments=before['arguments'],result=reg('rax'),
                supervisor_translation=before['translation'],
                callee_registers_preserved=True,captured_arguments_preserved=True,
                callback_registry_preserved=True,complete_process_table_preserved=True)
        callback_active = None
        return False

class CallbackEntered(Checked):
    def __init__(self, site, row):
        super().__init__('*'+hex(site['address']),internal=True)
        self.site, self.row = site, row

    def observe(self):
        global callback_active
        assert callback_registered is not None and callback_active is None
        assert reg('cs')&3 == 0 and reg('cr0')&(1<<16) and not (reg('eflags')&0x200)
        row, site = self.row, self.site
        assert reg('rax') == word(context+row['gs_slot']) == row['target']
        assert reg('rsp') % 16 == 0
        translation = callback_translation(reg('rax'))
        if row['gs_slot'] not in callback_live_sections:
            checked = []
            for section in row['sections']:
                actual = hashlib.sha256(memory(section['address'],section['bytes'])).hexdigest()
                assert actual == section['linked_sha256']
                checked.append(dict(address=section['address'],bytes=section['bytes'],sha256=actual))
            callback_live_sections[row['gs_slot']] = checked
        if row['gs_slot'] == 952:
            # The complete file-open plan packs eight Boolean facts. Anonymous
            # creation has its own exact write/mutable/create combination.
            assert reg('rdi') < 256
            if site['offset'] == 226667:
                assert reg('rdi') == 1 | 8 | 32
        elif row['gs_slot'] == 984:
            assert reg('rdi') <= 0xffffffff
        elif row['gs_slot'] == 976:
            table = word(context+928)
            assert word(table)==1 and word(table+48)==1 and word(table+24)>=64
            assert reg('rdi') == word(table+16)
            assert [reg(r) for r in ['rsi','rdx','rcx']] == [64,62,16]
            assert memory(reg('rdi'),64).hex() == extent_inventory['callback_header_hex']
        elif row['gs_slot'] == 992:
            assert reg('rsi') == word(context+1000) and reg('rsi')
            assert reg('rdx') == word(context+256) == context and reg('rcx') == row['target']
        table = word(context+928)
        assert table
        callback_active = dict(site=site['offset'],target=reg('rax'),cr3=reg('cr3'),rsp=reg('rsp'),
            callee_registers=[reg(r) for r in callback_callee_registers],
            arguments=[reg(r) for r in ['rdi','rsi','rdx','rcx','r8','r9']],
            captured=memory(context+296,64),registry=memory(context+952,56),
            table=table,table_bytes=memory(table,8192),phase=memory(context+104,1)[0],
            translation=translation)
        return False

def install_callback_observation():
    if extent_inventory is None:
        return
    bindings = extent_inventory['callback_bindings']
    assert bindings['passed'] and bindings['kernel_sha256'] == extent_inventory['kernel_sha256']
    rows = {row['gs_slot']:row for row in bindings['callbacks']}
    CallbackRegistration('*'+hex(extent_inventory['address']),internal=True)
    for site in bindings['sites']:
        CallbackEntered(site,rows[site['gs_slot']])
        CallbackReturned(site)

def callback_coverage_complete():
    if extent_inventory is None:
        return
    assert callback_registered is not None and callback_active is None and callback_counts
    sites = extent_inventory['callback_bindings']['sites']
    observed['callback_observation'] = dict(passed=True,registered=callback_registered,
        counts=[dict(offset=offset,count=callback_counts[offset]) for offset in sorted(callback_counts)],
        samples=[callback_samples[offset] for offset in sorted(callback_samples)],
        live_sections=[dict(gs_slot=slot,sections=callback_live_sections[slot]) for slot in sorted(callback_live_sections)],
        unreached=[site for site in sites if site['offset'] not in callback_counts],
        scope='Actual callback registration/targets, supervisor-executable mapping, first-role live bytes and observed ABI/private-state preservation; not every callee path, hardware read-only protection, arbitrary pointer authority, complete memory effects or lifetime proof')

copy_pending = None
copy_active = None
copy_counts = {}
copy_samples = {}
copy_start_breakpoints = {}
copy_finish_breakpoints = {}
copy_call_breakpoints = {}
copy_result_breakpoints = {}
copy_source_scope = None
copy_source_refusals = []
copy_source_completions = []
copy_retained_admissions = []
copy_retained_completions = []
copy_register_names = ['rax','rcx','rdx','rbx','rsp','rbp','rsi','rdi','r8','r9','r10','r11','r12','r13','r14','r15']
copy_preserved = [2,3,5,6,7,8,9,12,13,14,15]

def copy_source_enabled():
    return extent_inventory is not None and extent_inventory.get('source_scoped_copies',False)

def copy_source_syscall_entered(call):
    global copy_source_scope
    if not copy_source_enabled():
        return
    assert copy_source_scope is None and copy_pending is copy_active is None
    copy_source_scope = dict(number=call['number'],args=list(call['args']),
        phase_before=call['phase_before'],refusals=[],completed=[])
    for points in [copy_call_breakpoints,copy_result_breakpoints,copy_start_breakpoints]:
        for point in points.values():
            assert not point.enabled
            point.enabled = call['number'] != 12
    assert not any(point.enabled for point in copy_finish_breakpoints.values())

def copy_source_syscall_returned(call):
    global copy_source_scope
    if not copy_source_enabled():
        return
    assert copy_source_scope is not None and copy_pending is copy_active is None
    scope = copy_source_scope
    assert (scope['number'],scope['args']) == (call['number'],call['args'])
    for event in scope['refusals']:
        assert call['result'] == -14 and call['phase_after'] == scope['phase_before']
        assert event['candidate'] in call['args']
        copy_source_refusals.append(dict(**event,number=call['number'],args=call['args'],
            result=call['result'],phase_before=scope['phase_before'],phase_after=call['phase_after']))
    for event in scope['completed']:
        assert call['result'] >= 0 and event['candidate'] in call['args']
        copy_source_completions.append(dict(**event,number=call['number'],args=call['args'],
            result=call['result'],phase_before=scope['phase_before'],phase_after=call['phase_after']))
    for points in [copy_call_breakpoints,copy_result_breakpoints,copy_start_breakpoints]:
        for point in points.values(): point.enabled = False
    assert not any(point.enabled for point in copy_finish_breakpoints.values())
    copy_source_scope = None

def copy_mode(before=None):
    result = [reg('cr0'),reg('cr3'),reg('cr4')]
    assert reg('cs')&3 == 0 and result[0]&(1<<16) and not reg('eflags')&0x200
    assert not result[2]&(1<<12)
    if before is not None:
        assert result == before
    return result

def copy_transfer_size(row,elements,admitted):
    assert row['copy_width'] > 0 and 0 <= elements < 1<<64 and 0 <= admitted < 1<<64
    size = elements*row['copy_width']
    assert size < 1<<64
    kind = row.get('copy_count_kind','exact')
    if kind == 'positive-prefix':
        assert 0 < size <= admitted <= row['admitted_maximum']
    else:
        assert kind == 'exact' and size == admitted
    return size

def copy_live_stack_words(row,call_rsp,current_rsp):
    words = row.get('copy_live_stack_words',0)
    assert words in [0,1] and call_rsp >= words*8
    assert current_rsp == call_rsp-words*8
    return words

def copy_mapping(pointer):
    table = reg('cr3') & 0x000ffffffffff000
    path, user, writable = [], True, True
    for shift in [39,30,21,12]:
        assert table % 4096 == 0 and table < 0x40000000
        entry = word(table+((pointer>>shift)&511)*8)
        assert entry&1
        user, writable = user and bool(entry&4), writable and bool(entry&2)
        path.append([table,shift,entry&~0x60])
        if shift == 12 or (shift in [30,21] and entry&128):
            physical = (entry & (0x000fffffffffffff & ~((1<<shift)-1))) | (pointer&((1<<shift)-1))
            return dict(path=path,physical=physical,user=user,writable=writable,leaf_shift=shift)
        table = entry & 0x000ffffffffff000
    raise AssertionError('missing copy translation')

def copy_range(pointer, size, user, writable):
    # Observation budget only, not a kernel limit or a grant of access.
    assert 0 <= size <= 0x40000 and pointer+size < 1<<64
    result = []
    remaining, at = size, pointer
    while remaining:
        amount = min(remaining,4096-(at&4095))
        mapping = copy_mapping(at)
        assert mapping['user'] == user and (not writable or mapping['writable'])
        if user:
            assert mapping['leaf_shift'] == 12
        else:
            assert mapping['physical'] == at
        assert mapping['physical']+amount <= 0x40000000
        result.append(dict(pointer=at,size=amount,**mapping))
        remaining, at = remaining-amount, at+amount
    return result

class CopyAdmissionCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row = row

    def observe(self):
        global copy_pending
        assert copy_pending is None and copy_active is None
        row = self.row
        copy_counts[row['name']]['attempts'] += 1
        copy_pending = dict(name=row['name'],candidate=reg('r8'),size=reg('r9'),
            registers=[reg(r) for r in copy_register_names],mode=copy_mode(),rsp=reg('rsp'),
            captured=memory(context+296,64),accepted=False)
        if copy_source_enabled():
            assert copy_source_scope is not None
            if row['call_offset'] not in extent_first_reach:
                extent_first_reach[row['call_offset']] = dict(offset=row['call_offset'],
                    target=next(r['target'] for r in extent_inventory['calls'] if r['offset']==row['call_offset']),
                    candidate=reg('r8'),length=reg('r9'),phase=memory(context+104,1)[0])
        return False

class CopyAdmissionResult(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['carry_gate']),internal=True)
        self.row = row

    def observe(self):
        global copy_pending
        assert copy_pending is not None and copy_pending['name'] == self.row['name']
        before = copy_pending
        copy_mode(before['mode'])
        assert reg('rsp') == before['rsp'] and word(reg('rsp')-8) == 0
        assert all(reg(copy_register_names[i]) == before['registers'][i] for i in copy_preserved)
        assert memory(context+296,64) == before['captured']
        if self.row.get('retain_transfer_records'):
            assert before['size'] <= self.row['maximum_bytes']
            assert reg(copy_register_names[self.row['count_register']]) == before['size']
            copy_retained_admissions.append(dict(name=before['name'],call_offset=self.row['call_offset'],
                candidate=before['candidate'],size=before['size'],accepted=not bool(reg('eflags')&1),
                helper_registers_preserved=True,captured_arguments_preserved=True))
        if reg('eflags')&1:
            copy_counts[self.row['name']]['refused'] += 1
            if copy_source_enabled():
                copy_source_scope['refusals'].append(dict(name=before['name'],
                    call_offset=self.row['call_offset'],candidate=before['candidate'],size=before['size'],
                    helper_registers_preserved=True,captured_arguments_preserved=True))
            copy_pending = None
        else:
            copy_counts[self.row['name']]['admitted'] += 1
            copy_pending['accepted'] = True
        return False

class CopyStarted(Checked):
    def __init__(self,group):
        super().__init__('*'+hex(extent_inventory['address']+group['copy_offset']),internal=True)
        self.group = group

    def observe(self):
        global copy_active
        assert copy_pending is not None and copy_pending['accepted'] and copy_active is None
        # A debugger can revisit the REP PC between iterations. Observe its
        # initial state once, then resume ordinary execution to the completion
        # boundary; re-enable this breakpoint for the next invocation there.
        self.enabled = False
        copy_finish_breakpoints[self.group['copy_offset']].enabled = True
        assert copy_pending['name'] in self.group['cases']
        row = copy_rows[copy_pending['name']]
        before = copy_pending
        copy_mode(before['mode'])
        live_words = copy_live_stack_words(row,before['rsp'],reg('rsp'))
        assert not reg('eflags')&(1<<10)
        assert memory(context+296,64) == before['captured']
        source, target, elements = reg('rsi'),reg('rdi'),reg('rcx')
        size = copy_transfer_size(row,elements,before['size'])
        if row.get('copy_count_kind') == 'positive-prefix':
            assert reg(copy_register_names[row['copy_count_register']]) == size
        assert (source if row['admitted_direction'] == 'read' else target) == before['candidate']
        source_map = copy_range(source,size,row['admitted_direction']=='read',False)
        target_map = copy_range(target,size,row['admitted_direction']=='write',True)
        live_stack = memory(reg('rsp'),live_words*8) if live_words else b''
        if live_words:
            stack_map = copy_range(reg('rsp'),live_words*8,False,True)
            assert all(a['physical']+a['size'] <= b['physical'] or b['physical']+b['size'] <= a['physical']
                for a in source_map+target_map for b in stack_map)
        if row.get('retain_transfer_records'):
            assert size <= row['maximum_bytes'] and reg(copy_register_names[row['count_register']]) == size
            assert target == before['registers'][12]+row['counterpart']['offset']
            assert reg('r12') == before['registers'][12] == word(context+928)
        assert all(a['physical']+a['size'] <= b['physical'] or b['physical']+b['size'] <= a['physical']
                   for a in source_map for b in target_map)
        tables = {entry[0] for m in source_map+target_map for entry in m['path']}
        assert all(m['physical']+m['size'] <= table or table+4096 <= m['physical']
                   for m in source_map+target_map for table in tables)
        payload = memory(source,size) if size else b''
        copy_active = dict(name=row['name'],source=source,target=target,size=size,
            elements=elements,source_map=source_map,target_map=target_map,payload=payload,
            live_words=live_words,live_stack=live_stack)
        return False

class CopyFinished(Checked):
    def __init__(self,group,size):
        super().__init__('*'+hex(extent_inventory['address']+group['copy_offset']+size),internal=True)
        self.group = group
        self.enabled = False

    def observe(self):
        global copy_active,copy_pending
        assert copy_active is not None and copy_pending is not None
        active, before = copy_active,copy_pending
        assert active['name'] == before['name'] and active['name'] in self.group['cases']
        row = copy_rows[active['name']]
        copy_mode(before['mode'])
        assert copy_live_stack_words(row,before['rsp'],reg('rsp')) == active['live_words']
        assert not reg('eflags')&(1<<10)
        assert not active['live_words'] or memory(reg('rsp'),active['live_words']*8) == active['live_stack']
        assert reg('rcx') == 0 and reg('rsi') == active['source']+active['size']
        assert reg('rdi') == active['target']+active['size']
        assert memory(context+296,64) == before['captured']
        assert copy_range(active['source'],active['size'],row['admitted_direction']=='read',False) == active['source_map']
        assert copy_range(active['target'],active['size'],row['admitted_direction']=='write',True) == active['target_map']
        payload = memory(active['target'],active['size']) if active['size'] else b''
        assert payload == active['payload']
        counts = copy_counts[row['name']]
        counts['completed'] += 1
        counts['bytes'] += active['size']
        if row.get('retain_transfer_records'):
            copy_retained_completions.append(dict(name=row['name'],call_offset=row['call_offset'],
                copy_offset=row['copy_offset'],candidate=before['candidate'],size=active['size'],
                payload_hex=payload.hex(),live_stack_words=active['live_words'],
                live_stack_preserved=True,captured_arguments_preserved=True,
                translation_observations_equal=True,exact_payload_equal=True))
        if copy_source_enabled():
            assert copy_source_scope is not None
            copy_source_scope['completed'].append(dict(name=row['name'],call_offset=row['call_offset'],
                copy_offset=row['copy_offset'],candidate=before['candidate'],size=active['size'],
                payload_hex=payload.hex(),helper_registers_preserved=True,
                captured_arguments_preserved=True,translation_observations_equal=True))
        if row['name'] not in copy_samples:
            copy_samples[row['name']] = dict(name=row['name'],call_offset=row['call_offset'],
                copy_offset=row['copy_offset'],source=active['source'],target=active['target'],
                size=active['size'],elements=active['elements'],mode=before['mode'],
                source_map=active['source_map'],target_map=active['target_map'],
                payload_sha256=hashlib.sha256(payload).hexdigest(),
                helper_registers_preserved=True,captured_arguments_preserved=True,
                translation_observations_equal=True,exact_payload_equal=True)
            if row.get('copy_count_kind') == 'positive-prefix':
                copy_samples[row['name']]['admitted_size'] = before['size']
                copy_samples[row['name']]['copy_count_kind'] = 'positive-prefix'
        copy_active,copy_pending = None,None
        self.enabled = False
        copy_start_breakpoints[self.group['copy_offset']].enabled = True
        return False

def install_copy_observation():
    global copy_rows
    audits = [extent_inventory['copy_transfer_audit']]
    if extent_inventory.get('staging_copy_audit') is not None:
        audits.append(extent_inventory['staging_copy_audit'])
    if copy_source_enabled():
        assert extent_inventory.get('staging_copy_audit') is not None
        audits = [extent_inventory['staging_copy_audit']]
    if extent_inventory.get('stat_output_audit') is not None:
        audits.append(extent_inventory['stat_output_audit'])
    if extent_inventory.get('serial_prefix_audit') is not None:
        audits.append(extent_inventory['serial_prefix_audit'])
    if extent_inventory.get('file_input_audit') is not None:
        audits.append(extent_inventory['file_input_audit'])
    assert all(a['passed'] and a['kernel_sha256'] == extent_inventory['kernel_sha256'] for a in audits)
    rows = [r for a in audits for r in a['cases']]
    groups = [g for a in audits for g in a['copy_groups']]
    copy_rows = {r['name']:r for r in rows}
    assert len(copy_rows) == len(rows) and len({g['copy_offset'] for g in groups}) == len(groups)
    for row in rows:
        copy_counts[row['name']] = dict(attempts=0,admitted=0,refused=0,completed=0,bytes=0)
        copy_call_breakpoints[row['name']] = CopyAdmissionCalled(row)
        copy_result_breakpoints[row['name']] = CopyAdmissionResult(row)
    for group in groups:
        sizes = {copy_rows[name]['copy_size'] for name in group['cases']}
        assert len(sizes) == 1
        copy_start_breakpoints[group['copy_offset']] = CopyStarted(group)
        copy_finish_breakpoints[group['copy_offset']] = CopyFinished(group,next(iter(sizes)))
    if copy_source_enabled():
        for points in [copy_call_breakpoints,copy_result_breakpoints,copy_start_breakpoints]:
            for point in points.values(): point.enabled = False

def copy_observation_complete():
    assert copy_pending is None and copy_active is None
    assert copy_source_scope is None
    assert sum(row['completed'] for row in copy_counts.values()) > 0
    assert all(row['attempts'] == row['admitted']+row['refused'] and row['admitted'] == row['completed']
               for row in copy_counts.values())
    observed['copy_transfer_observation'] = dict(passed=True,counts=copy_counts,
        samples=[copy_samples[name] for name in sorted(copy_samples)],
        unreached=[name for name,row in copy_counts.items() if not row['attempts']],
        kernel_sha256=extent_inventory['kernel_sha256'],
        audit_sha256=extent_inventory['staging_copy_audit_sha256'] if copy_source_enabled() else extent_inventory['copy_transfer_audit_sha256'],
        audit_kind='staging' if copy_source_enabled() else ('legacy-and-staging' if extent_inventory.get('staging_copy_audit') is not None else 'legacy'),
        scope='Every selected observed admission result and REP start/completion: preserved helper registers/captured arguments, actual candidate/count/DF, equal copied bytes, user/supervisor permissions, no observed physical overlap with counterparty/translation storage and unchanged boundary translation/control observations. Read-only GDB observation, not continuous check-to-copy stability, complete table/backing ownership, every possible path or production qualification')
    if extent_inventory.get('staging_copy_audit') is not None:
        observed['copy_transfer_observation']['staging_audit_sha256'] = extent_inventory['staging_copy_audit_sha256']
    if extent_inventory.get('stat_output_audit') is not None:
        observed['copy_transfer_observation']['stat_audit_sha256'] = extent_inventory['stat_output_audit_sha256']
        observed['copy_transfer_observation']['audit_kind'] += '-and-stat'
    if extent_inventory.get('serial_prefix_audit') is not None:
        observed['copy_transfer_observation']['serial_prefix_audit_sha256'] = extent_inventory['serial_prefix_audit_sha256']
        observed['copy_transfer_observation']['audit_kind'] += '-and-serial-prefix'
    if extent_inventory.get('file_input_audit') is not None:
        selected = [row for row in copy_rows.values() if row.get('retain_transfer_records')]
        assert len(copy_retained_admissions) == sum(copy_counts[r['name']]['attempts'] for r in selected)
        assert len(copy_retained_completions) == sum(copy_counts[r['name']]['completed'] for r in selected)
        observed['copy_transfer_observation']['file_input_audit_sha256'] = extent_inventory['file_input_audit_sha256']
        observed['copy_transfer_observation']['retained_admissions'] = copy_retained_admissions
        observed['copy_transfer_observation']['retained_completions'] = copy_retained_completions
        observed['copy_transfer_observation']['audit_kind'] += '-and-file-input'
    if copy_source_enabled():
        assert len(copy_source_refusals) == sum(row['refused'] for row in copy_counts.values())
        observed['copy_transfer_observation']['source_syscall_refusals'] = copy_source_refusals
        assert len(copy_source_completions) == sum(row['completed'] for row in copy_counts.values())
        observed['copy_transfer_observation']['source_syscall_completions'] = copy_source_completions
        observed['copy_transfer_observation']['source_syscall_scoped'] = True

staged_pending = None
staged_active = None
staged_counts = {}
staged_samples = {}
staged_start_breakpoints = {}
staged_finish_breakpoints = {}
staged_call_breakpoints = {}
staged_result_breakpoints = {}
staged_source_scope = None
staged_refusal_events = []

def staged_source_enabled():
    return extent_inventory is not None and extent_inventory.get('source_scoped_staged',False)

def staged_source_number(row):
    if row['direction'] == 'read':
        return 1
    if row['name'] == 'named-stat':
        return 262
    return {390:63,144:5,72:217,80:217}[row['length']]

def staged_source_syscall_entered(call):
    global staged_source_scope
    if not staged_source_enabled():
        return
    assert staged_source_scope is None and staged_pending is staged_active is None
    staged_source_scope = dict(number=call['number'],args=list(call['args']),
        phase_before=call['phase_before'],refusals=[])
    for row in extent_inventory['staged_transfer_audit']['cases']:
        enabled = staged_source_number(row) == call['number']
        for points in [staged_call_breakpoints,staged_result_breakpoints,staged_start_breakpoints]:
            assert not points[row['name']].enabled
            points[row['name']].enabled = enabled
        assert not staged_finish_breakpoints[row['name']].enabled

def staged_source_syscall_returned(call):
    global staged_source_scope
    if not staged_source_enabled():
        return
    assert staged_source_scope is not None and staged_pending is staged_active is None
    scope = staged_source_scope
    assert (scope['number'],scope['args']) == (call['number'],call['args'])
    for event in scope['refusals']:
        assert call['result'] == -14 and call['phase_after'] == scope['phase_before']
        index = 0 if call['number'] == 63 else (2 if call['number'] == 262 else 1)
        assert event['candidate'] == call['args'][index]
        staged_refusal_events.append(dict(**event,number=call['number'],args=call['args'],
            result=call['result'],phase_before=scope['phase_before'],phase_after=call['phase_after']))
    for name in staged_counts:
        for points in [staged_call_breakpoints,staged_result_breakpoints,staged_start_breakpoints]:
            points[name].enabled = False
        assert not staged_finish_breakpoints[name].enabled
    staged_source_scope = None

class StagedCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row = row

    def observe(self):
        global staged_pending
        assert staged_pending is None and staged_active is None
        assert copy_pending is None and copy_active is None
        row = self.row
        assert reg('r9') == row['length'] and reg('gs_base') == context
        staged_counts[row['name']]['attempts'] += 1
        staged_pending = dict(name=row['name'],candidate=reg('r8'),size=reg('r9'),
            registers=[reg(r) for r in copy_register_names],mode=copy_mode(),rsp=reg('rsp'),
            captured=memory(context+296,64),accepted=False)
        if staged_source_enabled():
            assert staged_source_scope is not None
            assert staged_source_number(row) == staged_source_scope['number']
            counter = row['counterpart']
            pointer = context+counter['offset'] if counter['kind']=='gs' else counter['address']
            staged_pending['counterpart'] = pointer
            staged_pending['counterpart_before'] = memory(pointer,row['length'])
            if row['call_offset'] not in extent_first_reach:
                extent_first_reach[row['call_offset']] = dict(offset=row['call_offset'],
                    target=next(r['target'] for r in extent_inventory['calls'] if r['offset']==row['call_offset']),
                    candidate=reg('r8'),length=reg('r9'),phase=memory(context+104,1)[0])
        return False

class StagedResult(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['carry_gate']),internal=True)
        self.row = row

    def observe(self):
        global staged_pending
        assert staged_pending is not None and staged_pending['name'] == self.row['name']
        before = staged_pending
        copy_mode(before['mode'])
        assert reg('gs_base') == context
        assert reg('rsp') == before['rsp'] and word(reg('rsp')-8) == 0
        assert all(reg(copy_register_names[i]) == before['registers'][i] for i in copy_preserved)
        assert memory(context+296,64) == before['captured']
        if reg('eflags')&1:
            staged_counts[self.row['name']]['refused'] += 1
            if staged_source_enabled():
                data = memory(before['counterpart'],before['size'])
                assert data == before['counterpart_before']
                staged_source_scope['refusals'].append(dict(name=before['name'],
                    call_offset=self.row['call_offset'],candidate=before['candidate'],size=before['size'],
                    counterpart=before['counterpart'],counterpart_sha256=hashlib.sha256(data).hexdigest(),
                    counterpart_unchanged=True,helper_registers_preserved=True,captured_arguments_preserved=True))
            staged_pending = None
        else:
            staged_counts[self.row['name']]['admitted'] += 1
            staged_pending['accepted'] = True
        return False

class StagedStarted(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['start_offset']),internal=True)
        self.row = row

    def observe(self):
        global staged_active
        row = self.row
        assert staged_pending is not None and staged_pending['accepted'] and staged_active is None
        assert staged_pending['name'] == row['name']
        self.enabled = False
        staged_finish_breakpoints[row['name']].enabled = True
        before = staged_pending
        copy_mode(before['mode'])
        assert reg('gs_base') == context
        assert reg('rsp') == before['rsp'] and memory(context+296,64) == before['captured']
        assert reg(copy_register_names[row['user_register']]) == before['candidate']
        if row['index_register'] is not None:
            assert reg(copy_register_names[row['index_register']]) == 0
        counter = row['counterpart']
        counterpart = context+counter['offset'] if counter['kind']=='gs' else counter['address']
        source,target = (before['candidate'],counterpart) if row['direction']=='read' else (counterpart,before['candidate'])
        size = before['size']
        source_map = copy_range(source,size,row['direction']=='read',False)
        target_map = copy_range(target,size,row['direction']=='write',True)
        assert all(a['physical']+a['size'] <= b['physical'] or b['physical']+b['size'] <= a['physical']
                   for a in source_map for b in target_map)
        tables = {entry[0] for m in source_map+target_map for entry in m['path']}
        assert all(m['physical']+m['size'] <= table or table+4096 <= m['physical']
                   for m in source_map+target_map for table in tables)
        staged_active = dict(name=row['name'],source=source,target=target,size=size,
            source_map=source_map,target_map=target_map,payload=memory(source,size))
        return False

class StagedFinished(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['end_offset']),internal=True)
        self.row = row
        self.enabled = False

    def observe(self):
        global staged_pending,staged_active
        row = self.row
        assert staged_pending is not None and staged_active is not None
        before,active = staged_pending,staged_active
        assert before['name'] == active['name'] == row['name']
        copy_mode(before['mode'])
        assert reg('gs_base') == context
        assert reg('rsp') == before['rsp'] and memory(context+296,64) == before['captured']
        assert reg(copy_register_names[row['user_register']]) == before['candidate']
        if row['index_register'] is not None:
            assert reg(copy_register_names[row['index_register']]) == row['length']
        assert copy_range(active['source'],active['size'],row['direction']=='read',False) == active['source_map']
        assert copy_range(active['target'],active['size'],row['direction']=='write',True) == active['target_map']
        payload = memory(active['target'],active['size'])
        assert payload == active['payload']
        counts = staged_counts[row['name']]
        counts['completed'] += 1
        counts['bytes'] += active['size']
        if row['name'] not in staged_samples:
            staged_samples[row['name']] = dict(name=row['name'],call_offset=row['call_offset'],
                start_offset=row['start_offset'],end_offset=row['end_offset'],
                source=active['source'],target=active['target'],size=active['size'],mode=before['mode'],
                source_map=active['source_map'],target_map=active['target_map'],
                payload_sha256=hashlib.sha256(payload).hexdigest(),
                helper_registers_preserved=True,captured_arguments_preserved=True,
                candidate_preserved=True,exact_payload_equal=True,translation_observations_equal=True)
        staged_pending,staged_active = None,None
        self.enabled = False
        staged_start_breakpoints[row['name']].enabled = True
        return False

def install_staged_observation():
    audit = extent_inventory['staged_transfer_audit']
    assert audit['passed'] and audit['kernel_sha256'] == extent_inventory['kernel_sha256']
    for row in audit['cases']:
        staged_counts[row['name']] = dict(attempts=0,admitted=0,refused=0,completed=0,bytes=0)
        staged_call_breakpoints[row['name']] = StagedCalled(row)
        staged_result_breakpoints[row['name']] = StagedResult(row)
        staged_start_breakpoints[row['name']] = StagedStarted(row)
        staged_finish_breakpoints[row['name']] = StagedFinished(row)
        if staged_source_enabled():
            for points in [staged_call_breakpoints,staged_result_breakpoints,staged_start_breakpoints]:
                points[row['name']].enabled = False

def staged_observation_complete():
    assert staged_pending is None and staged_active is None
    assert staged_source_scope is None
    assert sum(row['completed'] for row in staged_counts.values()) > 0
    assert all(row['attempts']==row['admitted']+row['refused'] and row['admitted']==row['completed']
               for row in staged_counts.values())
    observed['staged_transfer_observation'] = dict(passed=True,counts=staged_counts,
        samples=[staged_samples[name] for name in sorted(staged_samples)],
        unreached=[name for name,row in staged_counts.items() if not row['completed']],
        kernel_sha256=extent_inventory['kernel_sha256'],
        audit_sha256=extent_inventory['staged_transfer_audit_sha256'],
        scope='Every selected observed admission/transfer boundary: actual candidate/count and finite-loop indices, helper/captured argument preservation, exact payload equality, complete covered user/supervisor permissions and unchanged control/translation observations allowing hardware A/D. Observed source/destination ranges do not overlap each other or table pages on these translation paths. Not continuous stability, complete owner/counterpart authority, every syscall path or production qualification')
    if staged_source_enabled():
        assert len(staged_refusal_events) == sum(row['refused'] for row in staged_counts.values())
        observed['staged_transfer_observation']['source_syscall_refusals'] = staged_refusal_events
        observed['staged_transfer_observation']['source_syscall_scoped'] = True

pipe_fixed_pending = None
pipe_fixed_active = None
pipe_fixed_scope = None
pipe_fixed_counts = {}
pipe_fixed_records = []
pipe_fixed_refusals = []
pipe_fixed_points = {}
pipe_fixed_calls = {}
pipe_fixed_results = {}

def pipe_fixed_enabled():
    return extent_inventory is not None and 'pipe-fixed' in selected_extent_observers()

def pipe_fixed_disjoint(left,right):
    assert all(a['physical']+a['size'] <= b['physical'] or
               b['physical']+b['size'] <= a['physical'] for a in left for b in right)

def pipe_fixed_candidate_mapping(before):
    mappings = copy_range(before['candidate'],before['size'],True,True)
    tables = {entry[0] for mapping in mappings for entry in mapping['path']}
    assert all(mapping['physical']+mapping['size'] <= table or
               table+4096 <= mapping['physical'] for mapping in mappings for table in tables)
    return mappings

def pipe_fixed_boundary(before):
    copy_mode(before['mode'])
    assert reg('rsp') == before['rsp']
    assert reg('r8') == before['candidate'] and reg('r9') == before['size']
    assert memory(context+296,64) == before['captured']
    assert pipe_fixed_candidate_mapping(before) == before['mapping']

def pipe_fixed_syscall_entered(call):
    global pipe_fixed_scope
    if not pipe_fixed_enabled():
        return
    assert pipe_fixed_scope is pipe_fixed_pending is pipe_fixed_active is None
    pipe_fixed_scope = dict(number=call['number'],args=list(call['args']),
                            phase_before=call['phase_before'],refusals=[])
    selected = call['number'] in [16,22,293]
    for points in [pipe_fixed_calls,pipe_fixed_results,pipe_fixed_points]:
        for point in points.values():
            assert not point.enabled
            point.enabled = selected

def pipe_fixed_syscall_returned(call):
    global pipe_fixed_scope
    if not pipe_fixed_enabled():
        return
    scope = pipe_fixed_scope
    assert scope is not None and pipe_fixed_pending is pipe_fixed_active is None
    assert (scope['number'],scope['args']) == (call['number'],call['args'])
    for refusal in scope['refusals']:
        assert call['result'] == -14 and call['phase_after'] == scope['phase_before']
        assert refusal['candidate'] == scope['args'][0 if scope['number'] in [22,293] else 2]
        pipe_fixed_refusals.append(dict(**refusal,number=scope['number'],args=scope['args'],
            result=call['result'],phase_before=scope['phase_before'],phase_after=call['phase_after']))
    for points in [pipe_fixed_calls,pipe_fixed_results,pipe_fixed_points]:
        for point in points.values(): point.enabled = False
    pipe_fixed_scope = None

class PipeFixedCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row = row
        self.enabled = False

    def observe(self):
        global pipe_fixed_pending
        row,scope = self.row,pipe_fixed_scope
        assert scope is not None and pipe_fixed_pending is pipe_fixed_active is None
        number,args = scope['number'],scope['args']
        if row['name'] == 'pipe-pair-output':
            assert number in [22,293]
            candidate = args[0]
        else:
            assert row['name'] == 'pipe-readable-count-output'
            assert number == 16 and args[1] == 0x541b
            candidate = args[2]
        assert reg('r8') == candidate and reg('r9') == row['admitted_bytes']
        pipe_fixed_counts[row['name']]['attempts'] += 1
        pipe_fixed_pending = dict(name=row['name'],candidate=candidate,size=reg('r9'),
            registers=[reg(name) for name in copy_register_names],mode=copy_mode(),
            rsp=reg('rsp'),captured=memory(context+296,64),accepted=False,next_access=0,
            accesses=[],number=number,args=list(args))
        return False

class PipeFixedResult(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['success_edge'][0]),internal=True)
        self.row = row
        self.enabled = False

    def observe(self):
        global pipe_fixed_pending
        before = pipe_fixed_pending
        assert before is not None and before['name'] == self.row['name']
        copy_mode(before['mode'])
        assert reg('rsp') == before['rsp'] and word(reg('rsp')-8) == 0
        assert all(reg(copy_register_names[i]) == before['registers'][i] for i in copy_preserved)
        assert memory(context+296,64) == before['captured']
        if reg('eflags')&1:
            pipe_fixed_counts[before['name']]['refused'] += 1
            pipe_fixed_scope['refusals'].append(dict(name=before['name'],
                candidate=before['candidate'],size=before['size'],call_offset=self.row['call_offset'],
                helper_registers_preserved=True,captured_arguments_preserved=True))
            pipe_fixed_pending = None
        else:
            before['accepted'] = True
            before['mapping'] = pipe_fixed_candidate_mapping(before)
            table = word(context+928)
            # These observed supervisor ranges are exclusions, not owner grants
            # or a complete inventory of every kernel/private access.
            private = [(table,8192),(table+0x3d000,1024),(table+0x3e000,0x5000),
                       (context+296,64),(before['rsp']-8,16)]
            before['private_exclusions'] = []
            for pointer,size in private:
                mapping = copy_range(pointer,size,False,True)
                pipe_fixed_disjoint(before['mapping'],mapping)
                before['private_exclusions'].append(dict(pointer=pointer,size=size,mapping=mapping))
            pipe_fixed_counts[before['name']]['admitted'] += 1
        return False

def pipe_fixed_access_started(row,index):
    global pipe_fixed_active
    before = pipe_fixed_pending
    assert before is not None and before['accepted'] and pipe_fixed_active is None
    assert before['name'] == row['name'] and before['next_access'] == index
    access = row['access_instructions'][index]
    assert access['candidate_offset'] == 0 and access['base_register'] == 8
    assert access['width'] == before['size'] and access['action'] in ['read','write']
    pipe_fixed_boundary(before)
    pointer,size = before['candidate'],before['size']
    payload = (reg('rax')&((1<<(size*8))-1)).to_bytes(size,'little') if access['action']=='write' else memory(pointer,size)
    pipe_fixed_active = dict(index=index,offset=access['offset'],action=access['action'],
                             payload=payload,rsp=reg('rsp'))

def pipe_fixed_access_finished(row,index):
    global pipe_fixed_active,pipe_fixed_pending
    before,active = pipe_fixed_pending,pipe_fixed_active
    assert before is not None and active is not None
    assert before['name'] == row['name'] and active['index'] == index == before['next_access']
    pipe_fixed_boundary(before)
    payload = memory(before['candidate'],before['size'])
    assert payload == active['payload']
    if active['action'] == 'read':
        assert reg('r11') == int.from_bytes(payload,'little')
    before['accesses'].append(dict(offset=active['offset'],action=active['action'],
        bytes=before['size'],payload_hex=payload.hex(),exact_payload_equal=True,
        boundary_mapping_equal=True,candidate_count_preserved=True,captured_arguments_preserved=True))
    before['next_access'] += 1
    pipe_fixed_active = None
    if before['next_access'] == len(row['access_instructions']):
        pipe_fixed_counts[row['name']]['completed'] += 1
        pipe_fixed_records.append(dict(name=row['name'],call_offset=row['call_offset'],
            candidate=before['candidate'],size=before['size'],number=before['number'],args=before['args'],
            mode=before['mode'],mapping=before['mapping'],private_exclusions=before['private_exclusions'],
            accesses=before['accesses'],helper_registers_preserved=True))
        pipe_fixed_pending = None

class PipeFixedPoint(Checked):
    def __init__(self,offset):
        super().__init__('*'+hex(extent_inventory['address']+offset),internal=True)
        self.finishes,self.starts = [],[]
        self.enabled = False

    def observe(self):
        # A store completion can share the readback's starting PC. One point
        # orders those events explicitly instead of relying on GDB BP order.
        for row,index in self.finishes: pipe_fixed_access_finished(row,index)
        for row,index in self.starts: pipe_fixed_access_started(row,index)
        return False

def install_pipe_fixed_observation():
    audit = extent_inventory['pipe_fixed_output_audit']
    assert audit['passed'] and not audit['complete']
    assert audit['kernel_sha256'] == extent_inventory['kernel_sha256']
    assert {row['name'] for row in audit['cases']} == {'pipe-pair-output','pipe-readable-count-output'}
    for row in audit['cases']:
        pipe_fixed_counts[row['name']] = dict(attempts=0,admitted=0,refused=0,completed=0)
        pipe_fixed_calls[row['name']] = PipeFixedCalled(row)
        pipe_fixed_results[row['name']] = PipeFixedResult(row)
        for index,access in enumerate(row['access_instructions']):
            start,end = access['offset'],access['offset']+len(bytes.fromhex(access['bytes']))
            for at in [start,end]:
                if at not in pipe_fixed_points: pipe_fixed_points[at] = PipeFixedPoint(at)
            pipe_fixed_points[start].starts.append((row,index))
            pipe_fixed_points[end].finishes.append((row,index))

def pipe_fixed_observation_complete():
    assert pipe_fixed_pending is pipe_fixed_active is pipe_fixed_scope is None
    assert all(row['attempts'] == row['admitted']+row['refused'] and
               row['admitted'] == row['completed'] and row['completed'] > 0 and row['refused'] > 0
               for row in pipe_fixed_counts.values())
    assert len(pipe_fixed_refusals) == sum(row['refused'] for row in pipe_fixed_counts.values())
    assert len(pipe_fixed_records) == sum(row['completed'] for row in pipe_fixed_counts.values())
    observed['pipe_fixed_output_observation'] = dict(passed=True,counts=pipe_fixed_counts,
        records=pipe_fixed_records,refusals=pipe_fixed_refusals,
        kernel_sha256=extent_inventory['kernel_sha256'],audit_sha256=extent_inventory['pipe_fixed_output_audit_sha256'],
        scope='Read-only ordinary source syscall observations: helper preservation/refusal, exact fixed stores and readback values, preserved arguments/count, user-writable translation and selected supervisor/table physical exclusions with equal access-boundary mode/mappings. Not continuous lifetime, complete owner/nonalias/entry/callee/exception effects, all callers or production qualification')

pipe_loop_scope = None
pipe_loop_pending = None
pipe_loop_active = None
pipe_loop_counts = {}
pipe_loop_records = []
pipe_loop_refusals = []
pipe_loop_points = []

def pipe_loop_enabled():
    return extent_inventory is not None and 'pipe-loops' in selected_extent_observers()

def pipe_loop_syscall_entered(call):
    global pipe_loop_scope
    if not pipe_loop_enabled(): return
    assert pipe_loop_scope is pipe_loop_pending is pipe_loop_active is None
    pipe_loop_scope = dict(number=call['number'],args=list(call['args']),
        phase_before=call['phase_before'],records=[],refusals=[])
    selected = call['number'] in [0,1] and call['args'][0] >= 3
    for point in pipe_loop_points:
        assert not point.enabled
        point.enabled = selected and point.kind in ['call','result','start']

def pipe_loop_syscall_returned(call):
    global pipe_loop_scope
    if not pipe_loop_enabled(): return
    scope = pipe_loop_scope
    assert scope is not None and pipe_loop_pending is pipe_loop_active is None
    assert (scope['number'],scope['args']) == (call['number'],call['args'])
    for row in scope['records']:
        assert call['result'] == row['size'] and row['candidate'] == call['args'][1]
        assert row['size'] <= call['args'][2]
        pipe_loop_records.append(dict(**row,number=call['number'],args=call['args'],result=call['result']))
    for row in scope['refusals']:
        assert call['result'] == -14 and row['candidate'] == call['args'][1]
        assert scope['phase_before'] == call['phase_after']
        pipe_loop_refusals.append(dict(**row,number=call['number'],args=call['args'],result=call['result']))
    for point in pipe_loop_points: point.enabled = False
    pipe_loop_scope = None

def pipe_loop_boundary(before):
    copy_mode(before['mode'])
    assert reg('rsp') == before['rsp'] and reg('r8') == before['candidate'] and reg('r9') == before['size']
    assert memory(context+296,64) == before['captured']
    assert reg('r13') == before['object']
    assert memory(before['object'],128) == before['object_before']
    assert copy_range(before['candidate'],before['size'],True,before['direction']=='write') == before['mapping']

class PipeLoopPoint(Checked):
    def __init__(self,row,kind):
        field = dict(call='call_offset',result='carry_gate',start='start_offset',finish='end_offset')[kind]
        super().__init__('*'+hex(extent_inventory['address']+row[field]),internal=True)
        self.row,self.kind = row,kind
        self.enabled = False

    def observe(self):
        global pipe_loop_pending,pipe_loop_active
        row,kind = self.row,self.kind
        counts = pipe_loop_counts[row['name']]
        if kind == 'call':
            assert pipe_loop_scope is not None and pipe_loop_pending is pipe_loop_active is None
            n,args = pipe_loop_scope['number'],pipe_loop_scope['args']
            assert n == (0 if row['admitted_direction']=='write' else 1)
            table,obj = word(context+928),reg('r13')
            index = (obj-table-0x3e000)//128
            assert 0 <= index < 4 and obj == table+0x3e000+index*128 and word(obj)==1
            cursor,queued = word(obj+32),word(obj+40)
            assert cursor < 4096 and queued <= 4096
            assert reg('r8') == args[1]
            expected = min(args[2],queued if n==0 else 4096-queued)
            assert reg('r9') == expected and 1 <= expected <= 4096
            counts['attempts'] += 1
            pipe_loop_pending = dict(name=row['name'],candidate=reg('r8'),size=reg('r9'),
                direction=row['admitted_direction'],registers=[reg(r) for r in copy_register_names],
                rsp=reg('rsp'),mode=copy_mode(),captured=memory(context+296,64),
                object=obj,object_before=memory(obj,128),ring=table+0x3f000+index*4096,
                cursor=cursor if n==0 else (cursor+queued)&4095,accepted=False)
        elif kind == 'result':
            before = pipe_loop_pending
            assert before is not None and before['name']==row['name'] and pipe_loop_active is None
            copy_mode(before['mode'])
            assert reg('rsp') == before['rsp'] and word(reg('rsp')-8)==0
            assert all(reg(copy_register_names[i]) == before['registers'][i] for i in copy_preserved)
            assert memory(context+296,64)==before['captured']
            if reg('eflags')&1:
                counts['refused'] += 1
                pipe_loop_scope['refusals'].append(dict(name=row['name'],candidate=before['candidate'],size=before['size']))
                pipe_loop_pending = None
            else:
                before['mapping'] = copy_range(before['candidate'],before['size'],True,before['direction']=='write')
                for pointer,size in [(word(context+928),8192),(before['object'],128),
                                     (before['ring'],4096),(context+296,64),(before['rsp']-8,16)]:
                    other = copy_range(pointer,size,False,True)
                    assert all(a['physical']+a['size'] <= b['physical'] or b['physical']+b['size'] <= a['physical']
                        for a in before['mapping'] for b in other)
                tables = {entry[0] for m in before['mapping'] for entry in m['path']}
                assert all(m['physical']+m['size']<=table or table+4096<=m['physical'] for m in before['mapping'] for table in tables)
                before['accepted'] = True
                counts['admitted'] += 1
        elif kind == 'start':
            before = pipe_loop_pending
            assert before is not None and before['accepted'] and pipe_loop_active is None
            assert before['name']==row['name'] and reg('rcx')==before['size']
            pipe_loop_boundary(before)
            assert reg('r11')==before['ring'] and reg('r15')==before['cursor']
            user = reg('rdi' if before['direction']=='write' else 'rsi')
            assert user==before['candidate']
            ring = memory(before['ring'],4096)
            payload = (bytes(ring[(before['cursor']+i)&4095] for i in range(before['size']))
                if before['direction']=='write' else memory(user,before['size']))
            expected = bytearray(ring)
            for i in range(before['size']):
                expected[(before['cursor']+i)&4095] = 0 if before['direction']=='write' else payload[i]
            pipe_loop_active = dict(payload=payload,expected_ring=bytes(expected),
                ring_mapping=copy_range(before['ring'],4096,False,True))
            self.enabled = False
            next(p for p in pipe_loop_points if p.row is row and p.kind=='finish').enabled = True
        else:
            assert kind=='finish'
            before,active = pipe_loop_pending,pipe_loop_active
            assert before is not None and active is not None and before['name']==row['name']
            pipe_loop_boundary(before)
            assert reg('rcx')==0 and reg('r15')==(before['cursor']+before['size'])&4095
            assert reg('rdi' if before['direction']=='write' else 'rsi')==before['candidate']+before['size']
            assert reg('r11')==before['ring']
            assert copy_range(before['ring'],4096,False,True)==active['ring_mapping']
            assert memory(before['ring'],4096)==active['expected_ring']
            assert memory(before['candidate'],before['size'])==active['payload']
            counts['completed'] += 1
            counts['bytes'] += before['size']
            pipe_loop_scope['records'].append(dict(name=row['name'],candidate=before['candidate'],size=before['size'],
                ring=before['ring'],initial_cursor=before['cursor'],payload_hex=active['payload'].hex(),
                helper_registers_preserved=True,captured_arguments_preserved=True,exact_user_and_ring_bytes=True,
                boundary_mappings_equal=True,ring_wrap=before['cursor']+before['size']>4096))
            pipe_loop_pending,pipe_loop_active = None,None
            self.enabled = False
            next(p for p in pipe_loop_points if p.row is row and p.kind=='start').enabled = True
        return False

def install_pipe_loop_observation():
    audit = extent_inventory['pipe_loop_audit']
    assert audit['passed'] and not audit['complete'] and audit['kernel_sha256']==extent_inventory['kernel_sha256']
    assert {r['name'] for r in audit['cases']}=={'pipe-read-loop','pipe-write-loop'}
    for row in audit['cases']:
        pipe_loop_counts[row['name']] = dict(attempts=0,admitted=0,refused=0,completed=0,bytes=0)
        for kind in ['call','result','start','finish']: pipe_loop_points.append(PipeLoopPoint(row,kind))

def pipe_loop_observation_complete():
    assert pipe_loop_scope is pipe_loop_pending is pipe_loop_active is None
    assert all(c['attempts']==c['admitted']+c['refused'] and c['admitted']==c['completed'] and
        c['completed']>0 and c['refused']>0 for c in pipe_loop_counts.values())
    assert len(pipe_loop_records)==sum(c['completed'] for c in pipe_loop_counts.values())
    assert len(pipe_loop_refusals)==sum(c['refused'] for c in pipe_loop_counts.values())
    observed['pipe_loop_observation'] = dict(passed=True,counts=pipe_loop_counts,records=pipe_loop_records,
        refusals=pipe_loop_refusals,kernel_sha256=extent_inventory['kernel_sha256'],
        audit_sha256=extent_inventory['pipe_loop_audit_sha256'],
        scope='Read-only source syscall/helper and byte-loop entry/completion observations: exact admitted size, captured arguments, complete payload/ring effects, selected physical exclusions and equal boundary translations/control. No per-byte native transcript, continuous lifetime, complete owner/nonalias/helper/entry/callee/exception or production claim')

warning_active = None
warning_records = []

def warning_control():
    return dict(cr3=reg('cr3'),cr0=reg('cr0'),cr4=reg('cr4'),
        epoch=memory(address('topal_x86_frame_mm_epoch_v1'),16))

class WarningCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row=row

    def observe(self):
        global warning_active
        assert warning_active is None and reg('cs')&3==0 and reg('cr0')&(1<<16)
        assert not reg('eflags')&(1<<9)
        selector=word(context+self.row['selector_gs_offset'])
        variants=[r for r in self.row['variants'] if r['selector']==selector]
        assert len(variants)==1
        variant=variants[0]
        assert reg('rdi')==2 and reg('rdx')==reg('r9')==variant['admitted_bytes']
        assert reg('r8')==reg('rsi')==word(context+320)
        warning_active=dict(row=self.row,variant=variant,selector=selector,
            candidate=reg('r8'),size=reg('r9'),rsp=reg('rsp'),control=warning_control(),
            registers=[reg(name) for name in copy_register_names],captured=memory(context+296,120),
            admitted=False,accesses=[])
        return False

class WarningAdmitted(Checked):
    def observe(self):
        global warning_active
        before=warning_active
        assert before is not None and not before['admitted']
        assert reg('rsp')==before['rsp'] and memory(reg('rsp')-8,8)==bytes(8)
        assert [reg(copy_register_names[i]) for i in copy_preserved]==[before['registers'][i] for i in copy_preserved]
        assert memory(context+296,120)==before['captured']
        assert word(context+616)==before['selector'] and warning_control()==before['control']
        if reg('eflags')&1:
            warning_records.append(dict(selector=before['selector'],candidate=before['candidate'],
                size=before['size'],accepted=False,accesses=[]))
            warning_active=None
            return False
        before['admitted']=True
        before['mapping']=copy_range(before['candidate'],before['size'],True,False)
        before['payload']=memory(before['candidate'],before['size'])
        expected={4:b'sh: ',40:b"can't access tty; job control turned off",1:b'\n'}
        assert before['payload']==expected[before['size']]
        before['tables']={p:memory(p,4096) for m in before['mapping'] for p,_,_ in m['path']}
        return False

class WarningRead(Checked):
    def __init__(self,row,variant):
        super().__init__('*'+hex(extent_inventory['address']+row['offset']),internal=True)
        self.row,self.variant=row,variant

    def observe(self):
        before=warning_active
        assert before is not None and before['admitted'] and before['variant']==self.variant
        assert reg('rsi')==before['candidate'] and reg('rsp')==before['rsp']
        assert word(context+616)==before['selector'] and memory(context+296,120)==before['captured']
        offset,width=self.row['candidate_offset'],self.row['width']
        assert 0<=offset and offset+width<=before['size']
        assert len(before['accesses'])<len(self.variant['access_instructions'])
        assert self.row==self.variant['access_instructions'][len(before['accesses'])]
        payload=memory(reg('rsi')+offset,width)
        assert payload==before['payload'][offset:offset+width]
        before['accesses'].append(dict(offset=self.row['offset'],candidate_offset=offset,width=width,
            payload_hex=payload.hex()))
        return False

class WarningStaged(Checked):
    def __init__(self,variant):
        super().__init__('*'+hex(extent_inventory['address']+variant['local_end']),internal=True)
        self.variant=variant

    def observe(self):
        global warning_active
        before=warning_active
        assert before is not None and before['admitted'] and before['variant']==self.variant
        assert len(before['accesses'])==len(self.variant['access_instructions'])
        assert reg('rsi')==before['candidate'] and reg('rsp')==before['rsp']
        assert word(context+616)==before['selector'] and memory(context+296,120)==before['captured']
        assert warning_control()==before['control']
        assert copy_range(before['candidate'],before['size'],True,False)==before['mapping']
        assert all(memory(p,4096)==raw for p,raw in before['tables'].items())
        assert memory(before['candidate'],before['size'])==before['payload']
        staged=b''.join((reg(copy_register_names[8+i])&((1<<(8*row['width']))-1)).to_bytes(row['width'],'little')
            for i,row in enumerate(self.variant['access_instructions']))
        assert staged==before['payload']
        warning_records.append(dict(selector=before['selector'],candidate=before['candidate'],
            size=before['size'],accepted=True,payload_hex=staged.hex(),accesses=before['accesses'],
            helper_registers_preserved=True,captured_arguments_preserved=True,selector_preserved=True,
            complete_register_staging_equal=True,translation_observations_equal=True))
        warning_active=None
        return False

def install_warning_observation():
    audit=extent_inventory.get('warning_input_audit')
    if audit is None: return
    assert audit['passed'] and audit['kernel_sha256']==extent_inventory['kernel_sha256']
    assert len(audit['cases'])==1
    row=audit['cases'][0]
    WarningCalled(row)
    WarningAdmitted('*'+hex(extent_inventory['address']+row['carry_gate']),internal=True)
    for variant in row['variants']:
        for access in variant['access_instructions']: WarningRead(access,variant)
        WarningStaged(variant)

def warning_observation_complete():
    if extent_inventory.get('warning_input_audit') is None: return
    assert warning_active is None
    observed['warning_input_observation']=dict(passed=True,records=warning_records,
        audit_sha256=extent_inventory['warning_input_audit_sha256'],
        scope='Actual reached warning admissions and complete scalar register staging with retained selector, helper/captured register and boundary translation observations. Not continuous mapping lifetime, complete output/retirement, independent owner reconstruction or production qualification')

import hashlib

random_active = None
random_records = []

def random_table_status_sets(tables,changes,target_map):
    assert target_map
    leaves=set()
    for mapping in target_map:
        assert mapping['leaf_shift']==12 and mapping['user'] and mapping['writable']
        table,shift,entry=mapping['path'][-1]
        assert shift==12 and table in tables and len(tables[table])==4096
        index=(mapping['pointer']>>12)&511
        before=struct.unpack_from('<Q',tables[table],index*8)[0]
        assert before&~0x60==entry and before&7==7, 'cached destination leaf changed'
        leaves.add((table,index))
    seen=set()
    for row in changes:
        key=row['table'],row['index']
        assert key in leaves and key not in seen, 'unrelated or duplicate table change'
        seen.add(key)
        before=struct.unpack_from('<Q',tables[key[0]],key[1]*8)[0]
        after=row['after']
        assert row['before']==before and 0<=after<1<<64
        assert row['changed_bits']==before^after and before!=after
        assert not (before&~after) and not ((before^after)&~0x60), 'nonmonotonic or nonstatus table change'
    return changes

class RandomCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row=row

    def observe(self):
        global random_active
        assert random_active is None
        assert reg('r8')==reg('rdi') and reg('r9')==reg('rsi')
        assert 1<=reg('r9')<=16
        service=word(context+256)
        assert service and memory(context+184,1)[0] in [1,2,3]
        random_active=dict(row=self.row,candidate=reg('r8'),size=reg('r9'),rsp=reg('rsp'),
            registers=[reg(name) for name in copy_register_names],captured=memory(context+296,120),
            mode=copy_mode(),service=service,marker=memory(context+184,1)[0],
            private=memory(service+168,88),admitted=False,started=False,stores=[],readbacks=[])
        return False

class RandomAdmitted(Checked):
    def observe(self):
        global random_active
        before=random_active
        assert before is not None and not before['admitted']
        assert reg('rsp')==before['rsp'] and memory(reg('rsp')-8,8)==bytes(8)
        assert [reg(copy_register_names[i]) for i in copy_preserved]==[before['registers'][i] for i in copy_preserved]
        assert memory(context+296,120)==before['captured']
        assert word(context+256)==before['service'] and memory(context+184,1)[0]==before['marker']
        assert memory(before['service']+168,88)==before['private']
        copy_mode(before['mode'])
        if reg('eflags')&1:
            random_records.append(dict(candidate=before['candidate'],size=before['size'],accepted=False,
                marker=before['marker'],service_preserved=True,helper_registers_preserved=True,
                captured_arguments_preserved=True,stores=[],readbacks=[]))
            random_active=None
        else: before['admitted']=True
        return False

class RandomLoop(Checked):
    def observe(self):
        before=random_active
        assert before is not None and before['admitted']
        assert reg('rdi')==before['candidate'] and reg('rsi')==before['size']
        assert reg('rsp')==before['rsp'] and memory(context+296,120)==before['captured']
        assert word(context+272)==0 and word(context+256)==before['service']
        assert memory(context+184,1)[0]==before['marker']
        copy_mode(before['mode'])
        index=reg('r10')
        assert index==len(before['stores'])==len(before['readbacks']) and index<=before['size']
        if not before['started']:
            assert index==0
            source=before['service']+(168 if before['marker']==1 else 224)
            assert reg('r9')==source
            before['source']=source
            before['payload']=memory(source,before['size'])
            before['source_map']=copy_range(source,before['size'],False,False)
            before['target_map']=copy_range(before['candidate'],before['size'],True,True)
            assert all(a['physical']+a['size']<=b['physical'] or b['physical']+b['size']<=a['physical']
                for a in before['source_map'] for b in before['target_map'])
            before['tables']={p:memory(p,4096) for m in before['source_map']+before['target_map'] for p,_,_ in m['path']}
            before['started']=True
        else: assert reg('r9')==before['source']
        return False

class RandomStore(Checked):
    def observe(self):
        before=random_active
        assert before is not None and before['started']
        index=reg('r10')
        assert index==len(before['stores'])==len(before['readbacks']) and index<before['size']
        assert reg('rdi')==before['candidate'] and reg('r9')==before['source']
        assert reg('rax')&255==before['payload'][index]
        before['stores'].append(index)
        return False

class RandomReadback(Checked):
    def observe(self):
        before=random_active
        assert before is not None and before['started']
        index=reg('r10')
        assert index==len(before['readbacks']) and len(before['stores'])==index+1
        assert memory(before['candidate']+index,1)==bytes([before['payload'][index]])
        assert reg('rax')&255==before['payload'][index]
        before['readbacks'].append(index)
        return False

class RandomCompleted(Checked):
    def observe(self):
        global random_active
        before=random_active
        assert before is not None and before['started']
        assert reg('r10')==reg('rsi')==before['size'] and reg('rdi')==before['candidate']
        assert reg('rsp')==before['rsp'] and memory(context+296,120)==before['captured']
        assert before['stores']==before['readbacks']==list(range(before['size']))
        assert memory(before['candidate'],before['size'])==before['payload']
        assert memory(before['source'],before['size'])==before['payload']
        assert copy_range(before['source'],before['size'],False,False)==before['source_map']
        assert copy_range(before['candidate'],before['size'],True,True)==before['target_map']
        changed=[]
        for pointer,raw in before['tables'].items():
            after=memory(pointer,4096)
            for index in range(512):
                old,new=struct.unpack_from('<Q',raw,index*8)[0],struct.unpack_from('<Q',after,index*8)[0]
                if old!=new: changed.append(dict(table=pointer,index=index,before=old,after=new,changed_bits=old^new))
        try:
            random_table_status_sets(before['tables'],changed,before['target_map'])
        except AssertionError:
            observed['random_mapping_failure']=dict(candidate=before['candidate'],size=before['size'],
                marker=before['marker'],source=before['source'],source_map=before['source_map'],
                target_map=before['target_map'],changes=changed)
            raise
        assert word(context+272)==0 and word(context+256)==before['service']
        assert memory(context+184,1)[0]==before['marker']
        copy_mode(before['mode'])
        random_records.append(dict(candidate=before['candidate'],size=before['size'],accepted=True,
            marker=before['marker'],source=before['source'],source_offset=before['source']-before['service'],
            stores=before['stores'],readbacks=before['readbacks'],
            payload_sha256=hashlib.sha256(before['payload']).hexdigest(),
            exact_payload_equal=True,captured_arguments_preserved=True,stack_restored=True,
            suspended_stack_field_cleared=True,translation_observations_equal=True,
            table_status_sets=changed,only_admitted_destination_leaf_ad_sets=True))
        random_active=None
        return False

def install_random_observation():
    audit=extent_inventory.get('random_output_audit')
    if audit is None: return
    assert audit['passed'] and audit['kernel_sha256']==extent_inventory['kernel_sha256']
    assert len(audit['cases'])==1
    row=audit['cases'][0]
    RandomCalled(row)
    for cls,field in [(RandomAdmitted,'carry_gate'),(RandomLoop,'loop_offset'),
                      (RandomStore,'start_offset'),(RandomReadback,'readback_offset'),
                      (RandomCompleted,'end_offset')]:
        cls('*'+hex(extent_inventory['address']+row[field]),internal=True)

def random_observation_complete():
    if extent_inventory.get('random_output_audit') is None: return
    assert random_active is None
    observed['random_output_observation']=dict(passed=True,records=random_records,
        audit_sha256=extent_inventory['random_output_audit_sha256'],
        scope='Actual reached random admissions, per-byte output/readback order, opaque payload equality, source/destination physical exclusion, restored caller stack and cleared suspended-stack field with equal boundary mappings. Complete table observations allow only recorded monotonic Accessed/Dirty sets on admitted writable user destination leaves; all other words/bits are unchanged. Not continuous stability, independent owners, extraction scratch/outer spill retirement, full syscall/fatal/exception or production qualification')

stack_retirement_active = None
stack_retirement_records = {}
stack_retirement_registers = ['rax','rcx','rdx','rbx','rsp','rbp','rsi','rdi',
    'r8','r9','r10','r11','r12','r13','r14','r15']

class StackRetirementStart(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['start']),internal=True)
        self.row=row

    def observe(self):
        global stack_retirement_active
        assert stack_retirement_active is None and reg('cs')&3==0
        assert reg('cr0')&(1<<16) and not reg('eflags')&(1<<9)
        rsp=reg('rsp')
        size=self.row['bytes']
        stack_retirement_active=dict(row=self.row,rsp=rsp,
            registers=[reg(name) for name in stack_retirement_registers],flags=reg('eflags'),
            lower_guard=memory(rsp-size-8,8),upper_guard=memory(rsp,8))
        return False

class StackRetirementEnd(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['end']),internal=True)
        self.row=row

    def observe(self):
        global stack_retirement_active
        before=stack_retirement_active
        assert before is not None and before['row']==self.row
        rsp,size=before['rsp'],self.row['bytes']
        assert [reg(name) for name in stack_retirement_registers]==before['registers'], 'retirement changes GPRs/RSP'
        assert reg('eflags')==before['flags'], 'retirement changes flags'
        assert memory(rsp-size,size)==bytes(size), 'retirement leaves nonzero words'
        assert memory(rsp-size-8,8)==before['lower_guard'] and memory(rsp,8)==before['upper_guard'], 'retirement crosses guards'
        name=self.row['name']
        record=stack_retirement_records.setdefault(name,dict(name=name,start=self.row['start'],
            end=self.row['end'],words=self.row['words'],completed=0,zero_bytes_observed=0))
        record['completed']+=1
        record['zero_bytes_observed']+=size
        stack_retirement_active=None
        return False

def install_stack_retirement_observation():
    audit=extent_inventory.get('stack_retirement_audit')
    if audit is None: return
    assert audit['passed'] and audit['kernel_sha256']==extent_inventory['kernel_sha256']
    assert len(audit['blocks'])==13
    for row in audit['blocks']:
        StackRetirementStart(row)
        StackRetirementEnd(row)

def stack_retirement_observation_complete():
    audit=extent_inventory.get('stack_retirement_audit')
    if audit is None: return
    assert stack_retirement_active is None
    observed['stack_retirement_observation']=dict(passed=True,
        records=[stack_retirement_records[name] for name in sorted(stack_retirement_records)],
        unreached=[row['name'] for row in audit['blocks'] if row['name'] not in stack_retirement_records],
        audit_sha256=extent_inventory['stack_retirement_audit_sha256'],
        scope='Actual reached zeroing blocks: all sixteen GPRs, RSP and flags equal at boundaries, exact retired words zero, adjacent words unchanged. Adjacent-word reads are debugger observations, not extra kernel writes. No proof of ownership/nonalias, continuous lifetime, unreached paths, exception/terminal cleanup or production qualification')



PIPE_BASE=0x3e000
PIPE_BYTES=0x5000

def pipe_context():
    return (memory(context+152,104)+memory(context+416,8)+memory(context+736,160)+
            memory(word(context+904)+0x9e00,512)).hex()

def pipe_visible(pointer,size):
    for start,end in [(component['base'],component['base']+component['text_bytes']),
                      (0x5f7000,0x63a000),(0x400000,0x401000)]:
        if start<=pointer<end:
            return memory(pointer,min(size,end-pointer))
    return b''

def pipe_request(call):
    table=word(context+928)
    assert word(table)==1 and memory(table+1408,256)==bytes(256)
    call['_table_before']=memory(table,8192).hex()
    call['_pipe_before']=memory(table+PIPE_BASE,PIPE_BYTES).hex()
    call['context_before']=pipe_context()
    n=call['number']
    args=call['args']
    if n in [22,293]: pointer,size=args[0],8
    elif n==16: pointer,size=args[2],4
    else: pointer,size=args[1],min(args[2],4096)
    if n!=3:
        call['buffer_before']=pipe_visible(pointer,size).hex()
        call['buffer_pointer']=pointer
        call['window_pointer']=pointer-1
        call['window_before']=pipe_visible(pointer-1,size+2).hex()
    if n in [0,1,3,16]:
        description=word(table+64+args[0]*16)
        assert 1<=description<=16
        call['description_index']=description
        call['description_before']=words(table+320+(description-1)*64,8)

def pipe_result(call):
    table=word(context+928)
    before_table=bytearray.fromhex(call.pop('_table_before'))
    before=bytearray.fromhex(call.pop('_pipe_before'))
    after=memory(table+PIPE_BASE,PIPE_BYTES)
    n,result=call['number'],call['result']
    args=call['args']
    expected_table=bytearray(before_table)
    expected=bytearray(before)
    output=b''
    if result<0:
        assert result in [-14,-11]
        if n!=3:
            assert pipe_visible(call['buffer_pointer'],len(bytes.fromhex(call['buffer_before']))).hex()==call['buffer_before']
    elif n in [22,293]:
        assert result==0
        free=[fd for fd in range(16) if struct.unpack_from('<Q',before_table,64+fd*16)[0]==0]
        pair=list(struct.unpack('<II',memory(args[0],8)))
        assert pair==free[:2]
        generation=struct.unpack_from('<Q',before,512)[0]+1
        index=next(i for i in range(4) if before[i*128:i*128+128]==bytes(128))
        current['pipe_index']=index
        call['pair']=pair
        call['generation']=generation
        call['object_index']=index
        descs=[struct.unpack_from('<Q',memory(table,8192),64+fd*16)[0] for fd in pair]
        assert descs[0]!=descs[1] and all(1<=d<=16 for d in descs)
        for endpoint,(fd,description) in enumerate(zip(pair,descs)):
            assert before_table[320+(description-1)*64:320+description*64]==bytes(64)
            struct.pack_into('<QQ',expected_table,64+fd*16,description,0)
            struct.pack_into('<8Q',expected_table,320+(description-1)*64,
                             5+endpoint,1,0x800|endpoint,0,generation,0,0,0)
        record=list(struct.unpack_from('<16Q',after,index*128))
        assert record[:9]==[1,generation,*descs,0,0,0,0,0o10600]
        assert record[9]==record[10]==record[11]==record[12]>0 and record[13:]==[0]*3
        expected[index*128:index*128+128]=after[index*128:index*128+128]
        struct.pack_into('<Q',expected,512,generation)
        output=struct.pack('<II',*pair)
    else:
        index=current['pipe_index']
        at=index*128
        ring=0x1000+index*4096
        cursor,count=struct.unpack_from('<QQ',before,at+32)
        if n==16:
            assert result==0 and args[1]==0x541b
            output=struct.pack('<I',count)
            assert memory(args[2],4)==output
        elif n in [0,1] and result>0:
            assert result<=args[2]
            if n==0:
                assert result==min(args[2],count)
                output=bytes(before[ring+(cursor+i)%4096] for i in range(result))
                assert memory(args[1],result)==output
                for i in range(result): expected[ring+(cursor+i)%4096]=0
                struct.pack_into('<QQ',expected,at+32,(cursor+result)%4096,count-result)
                timestamp_offsets=[72]
                call['output_hex']=output.hex()
            else:
                assert result==min(args[2],4096-count)
                data=bytes.fromhex(call['buffer_before'])
                assert len(data)>=result
                for i in range(result): expected[ring+(cursor+count+i)%4096]=data[i]
                struct.pack_into('<Q',expected,at+40,count+result)
                timestamp_offsets=[80,88]
            for offset in timestamp_offsets:
                assert struct.unpack_from('<Q',after,at+offset)[0]>0
                expected[at+offset:at+offset+8]=after[at+offset:at+offset+8]
        elif n==3:
            assert result==0 and call['description_before'][1]==1
            description=call['description_index']
            expected_table[64+args[0]*16:80+args[0]*16]=bytes(16)
            expected_table[320+(description-1)*64:320+description*64]=bytes(64)
            offset=16 if call['description_before'][0]==5 else 24
            struct.pack_into('<Q',expected,at+offset,0)
            if struct.unpack_from('<QQ',expected,at+16)==(0,0):
                expected[at:at+128]=bytes(128)
                expected[ring:ring+4096]=bytes(4096)
        else:
            assert result==0 and ((n in [0,1] and args[2]==0) or (n==0 and count==0))
    assert after==bytes(expected), (n,result,'FIFO bytes changed outside permitted transition')
    assert memory(table,8192)==bytes(expected_table), (n,result,'descriptor/staging change')
    assert pipe_context()==call['context_before']
    if n!=3:
        window=bytearray.fromhex(call['window_before'])
        if output:
            assert 1+len(output)<=len(window)
            window[1:1+len(output)]=output
        assert pipe_visible(call['window_pointer'],len(window))==bytes(window), (n,result,'user copy window')
        call['copy_window_verified']=True
    call['complete_fifo_state_verified']=True
    call['complete_table_verified']=True
    call['pipe_state_after_sha256']=hashlib.sha256(after).hexdigest()

def pipe_returned(row,after):
    global current
    calls=row['calls']
    assert len(calls)==44
    assert {n:sum(c['number']==n for c in calls) for n in [12,293,16,1,0,3]}=={
        12:3,293:6,16:10,1:10,0:13,3:2}
    actions=[c for c in calls if c['number']!=12]
    assert sum(c['result']==-14 for c in actions)==19
    assert sum(c['result']==-11 for c in actions)==1
    assert all(c['complete_fifo_state_verified'] and c['complete_table_verified'] for c in actions)
    table=word(context+928)
    assert hashlib.sha256(memory(table,8192)).hexdigest()==row['pipe_table_before_sha256']
    shared=memory(table+PIPE_BASE,PIPE_BYTES)
    old=bytearray.fromhex(row.pop('_pipe_initial'))
    struct.pack_into('<Q',old,512,struct.unpack_from('<Q',old,512)[0]+1)
    assert shared==bytes(old), 'FIFO object/ring not retired exactly; only generation history may advance'
    row['after']=after
    row['pipe_retirement_verified']=True
    observed['executions'].append(row)
    print('SOURCE_PIPE_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current=None
    return False



STORAGE_BASE=0x43000
STORAGE_BYTES=0x9000

def storage_word(data,offset): return struct.unpack_from('<Q',data,offset)[0]
def storage_put(data,offset,value): struct.pack_into('<Q',data,offset,value)

class StorageInputCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row=row

    def observe(self):
        assert current and pending and pending['number'] in [1,18]
        assert component.get('mode')=='storage' and 'file_input_admission' not in pending
        n,args=pending['number'],pending['args']
        assert self.row['name']==('volatile-write-input' if n==1 else 'volatile-pwrite-input')
        table=word(context+928)
        desc=pending['description_before']
        assert desc[0]==7 and reg('r12')==table
        objects=[table+0x43100+i*128 for i in range(4)
            if word(table+0x43100+i*128)==1 and word(table+0x43108+i*128)==desc[4]]
        assert len(objects)==1 and reg('rbx')==objects[0]
        position=args[3] if n==18 else desc[3]
        if desc[2]&0x400: position=word(objects[0]+16)
        length=min(args[2],256,4096-position%4096,(1<<63)-1-position)
        assert 1<=length<=256 and reg('r8')==args[1] and reg('r9')==reg('rbp')==length
        assert reg('r15')==position
        pages=[i for i in range(8) if word(table+0x43400+i*32)==desc[4] and
               word(table+0x43408+i*32)==position//4096]
        assert len(pages)<=1
        pending['file_input_admission']=dict(name=self.row['name'],candidate=args[1],length=length,
            position=position,page_present=bool(pages),captured_table=table)
        return False

def install_storage_input_observation():
    if component.get('mode')=='storage':
        audit=extent_inventory['file_input_audit']
        assert audit['passed'] and audit['kernel_sha256']==extent_inventory['kernel_sha256']
        for row in audit['cases']: StorageInputCalled(row)

def storage_request(call):
    table=word(context+928)
    assert word(table)==1 and memory(table+1408,256)==bytes(256)
    call['_table_before']=memory(table,8192).hex()
    call['_storage_before']=memory(table+STORAGE_BASE,STORAGE_BYTES).hex()
    call['context_before']=pipe_context()
    n,args=call['number'],call['args']
    if n==257:
        raw=pipe_visible(args[1],64)
        path=raw[:raw.index(0)+1]
        call['path_hex']=path.hex()
        pointer,size=args[1],len(path)
    elif n in [0,1,17,18,217]:
        pointer,size=args[1],min(args[2],256)
    else:
        pointer=size=None
    if pointer is not None:
        call['buffer_before']=pipe_visible(pointer,size).hex()
        call['buffer_pointer']=pointer
        call['window_pointer']=pointer-1
        call['window_before']=pipe_visible(pointer-1,size+2).hex()
    if n!=257:
        index=word(table+64+args[0]*16)
        assert 1<=index<=16
        call['description_index']=index
        call['description_before']=words(table+320+(index-1)*64,8)

def storage_result(call):
    table=word(context+928)
    before_table=bytearray.fromhex(call.pop('_table_before'))
    before=bytearray.fromhex(call.pop('_storage_before'))
    actual=memory(table+STORAGE_BASE,STORAGE_BYTES)
    expected=bytearray(before)
    expected_table=bytearray(before_table)
    n,args,result=call['number'],call['args'],call['result']
    output=b''
    if result<0:
        assert result in [-14,-22]
        if 'buffer_pointer' in call:
            raw=bytes.fromhex(call['buffer_before'])
            assert pipe_visible(call['buffer_pointer'],len(raw))==raw
    elif n==257:
        free=[i for i in range(16) if storage_word(before_table,64+i*16)==0]
        assert result==free[0]
        index=word(table+64+result*16)
        assert 1<=index<=16
        at=320+(index-1)*64
        assert before_table[at:at+64]==bytes(64)
        path=bytes.fromhex(call['path_hex'])
        flags=args[2]
        if flags==0x410002:
            assert path==b'/tmp\0'
            identity=storage_word(before,0)
            slot=next(i for i in range(4) if before[256+i*128:384+i*128]==bytes(128))
            object_at=256+slot*128
            record=list(struct.unpack_from('<16Q',actual,object_at))
            mode=0o100000|(args[3]&0o7777&~storage_word(before_table,1664))
            assert record[:4]==[1,identity,0,mode]
            assert record[4]==record[5]==record[6]>0
            assert record[7:]==[0,1]+[0]*7
            expected[object_at:object_at+128]=actual[object_at:object_at+128]
            storage_put(expected,0,identity+1)
            kind=7
            call['object_identity']=identity
            call['object_slot']=slot
        else:
            assert (path,flags) in [(b'/bin/busybox\0',0),(b'/tmp\0',0x10000)]
            kind,identity=(3,5) if flags==0 else (4,6)
        status=(flags&~(0x80000|0x100|0x40|0x80|0x200))|0x8000
        struct.pack_into('<8Q',expected_table,at,kind,1,status,0,identity,0,0,0)
        struct.pack_into('<QQ',expected_table,64+result*16,index,0)
        call['fresh_description_verified']=True
    else:
        desc=call['description_before']
        desc_at=320+(call['description_index']-1)*64
        kind,_,_,position,identity,*_=desc
        if n==8:
            assert args[2] in [0,1]
            expected_position=args[1]+(position if args[2]==1 else 0)
            assert result==expected_position
            storage_put(expected_table,desc_at+24,result)
        elif n==217:
            assert kind==4 and identity==6 and position==0 and result==48
            records=bytearray(48)
            for i,(inode,name) in enumerate([(6,b'.\0'),(3,b'..\0')]):
                struct.pack_into('<QQHB',records,i*24,inode,i+1,24,4)
                records[i*24+19:i*24+19+len(name)]=name
            output=bytes(records)
            cursor=next((i+2 for i in range(4) if storage_word(before,64+i*16)),6)
            storage_put(expected_table,desc_at+24,cursor)
        elif n==3:
            assert result==0 and desc[1]==1
            expected_table[64+args[0]*16:80+args[0]*16]=bytes(16)
            expected_table[desc_at:desc_at+64]=bytes(64)
            if kind==7:
                object_at=next(256+i*128 for i in range(4)
                    if storage_word(before,256+i*128)==1 and storage_word(before,264+i*128)==identity)
                assert storage_word(before,object_at+56)==0
                for slot in range(8):
                    page=1024+slot*32
                    if storage_word(before,page)==identity:
                        assert before[24+slot]==1
                        expected[24+slot]=0
                        expected[page:page+32]=bytes(32)
                        expected[4096+slot*4096:8192+slot*4096]=bytes(4096)
                expected[object_at:object_at+128]=bytes(128)
        elif n in [0,1,17,18]:
            offset=args[3] if n in [17,18] else position
            if kind==3:
                assert n==17 and result==min(args[2],256,storage_word(before_table,24)-offset)
                output=bytes.fromhex(immutable_head)[offset:offset+result]
                assert len(output)==result
            else:
                assert kind==7
                object_at=next(256+i*128 for i in range(4)
                    if storage_word(before,256+i*128)==1 and storage_word(before,264+i*128)==identity)
                size=storage_word(before,object_at+16)
                writing=n in [1,18]
                if writing:
                    assert result==min(args[2],256,4096-offset%4096)
                else:
                    assert result==min(args[2],256,4096-offset%4096,max(size-offset,0))
                if result:
                    pages=[i for i in range(8) if storage_word(before,1024+i*32)==identity
                           and storage_word(before,1032+i*32)==offset//4096]
                    if writing and not pages:
                        pages=[i for i in range(8) if storage_word(actual,1024+i*32)==identity
                               and storage_word(actual,1032+i*32)==offset//4096]
                        assert len(pages)==1
                        slot=pages[0]
                        assert before[24+slot]==0 and before[1024+slot*32:1056+slot*32]==bytes(32)
                        assert before[4096+slot*4096:8192+slot*4096]==bytes(4096)
                        expected[24+slot]=1
                        struct.pack_into('<4Q',expected,1024+slot*32,identity,offset//4096,0,0)
                    if pages:
                        assert len(pages)==1
                        start=4096+pages[0]*4096+offset%4096
                    if writing:
                        data=bytes.fromhex(call['buffer_before'])[:result]
                        assert len(data)==result
                        expected[start:start+result]=data
                        storage_put(expected,object_at+16,max(size,offset+result))
                        for timestamp in [40,48]:
                            assert storage_word(actual,object_at+timestamp)>0
                            expected[object_at+timestamp:object_at+timestamp+8]=actual[object_at+timestamp:object_at+timestamp+8]
                    else:
                        output=bytes(before[start:start+result]) if pages else bytes(result)
                    if n in [0,1]: storage_put(expected_table,desc_at+24,offset+result)
            if n in [17,18]:
                assert word(table+desc_at+24)==position
                call['positional_position_preserved']=True
        else:
            raise AssertionError(('unexpected storage call',n,result))
    assert actual==bytes(expected), (n,result,'filesystem mutation outside selected contract')
    assert memory(table,8192)==bytes(expected_table), (n,result,'description/staging mutation')
    assert pipe_context()==call['context_before']
    if 'window_before' in call:
        window=bytearray.fromhex(call['window_before'])
        if output:
            assert 1+len(output)<=len(window)
            window[1:1+len(output)]=output
            assert memory(call['buffer_pointer'],len(output))==output
            call['output_hex']=output.hex()
        assert pipe_visible(call['window_pointer'],len(window))==bytes(window), (n,result,'copy window')
        call['copy_window_verified']=True
    call['complete_storage_state_verified']=True
    call['complete_table_verified']=True

def storage_returned(row,after):
    global current
    calls=row['calls']
    assert len(calls)==62
    assert {n:sum(c['number']==n for c in calls) for n in [12,257,1,8,0,17,18,3,217]}=={
        12:3,257:3,1:7,8:8,0:7,17:18,18:7,3:3,217:6}
    actions=[c for c in calls if c['number']!=12]
    assert sum(c['result']==-14 for c in actions)==28
    assert sum(c['result']==-22 for c in actions)==1
    assert all(c['complete_storage_state_verified'] and c['complete_table_verified'] for c in actions)
    table=word(context+928)
    assert hashlib.sha256(memory(table,8192)).hexdigest()==row['storage_table_before_sha256']
    expected=bytearray.fromhex(row.pop('_storage_initial'))
    storage_put(expected,0,storage_word(expected,0)+1)
    assert memory(table+STORAGE_BASE,STORAGE_BYTES)==bytes(expected), 'filesystem reclamation/history'
    row['after']=after
    row['storage_retirement_verified']=True
    observed['executions'].append(row)
    print('SOURCE_STORAGE_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current=None
    return False



class SerialAdmission(Checked):
    def observe(self):
        assert current and pending and pending['number']==0 and pending['args'][0]==0
        assert reg('cs')&3==0 and reg('cr0')&(1<<16)
        assert reg('r8')==pending['args'][1] and reg('r9')==min(pending['args'][2],256)
        assert 'extent_call' not in pending
        pending['extent_call']=dict(candidate=reg('r8'),length=reg('r9'))
        return False

class SerialByte(Checked):
    def observe(self):
        assert current and pending and pending['number']==0 and pending['args'][0]==0
        assert reg('cs')&3==0 and reg('cr0')&(1<<16) and reg('rdx')&0xffff==0x3f8
        assert 'extent_call' in pending
        assert reg('rsi')==word(context+928)+1408+len(pending['uart_bytes'])
        pending['uart_bytes'].append(reg('rax')&255)
        assert len(pending['uart_bytes'])<=pending['extent_call']['length']
        return False

def serial_request(call):
    table=word(context+928)
    assert word(table)==1 and memory(table+1408,256)==bytes(256)
    call['table_before_sha256']=hashlib.sha256(memory(table,8192)).hexdigest()
    call['context_before']=pipe_context()
    n,args=call['number'],call['args']
    assert n in [0,1]
    call['uart_bytes']=[]
    size=min(args[2],256)
    call['buffer_before']=pipe_visible(args[1],size).hex()
    call['window_pointer']=args[1]-1
    call['window_before']=pipe_visible(args[1]-1,size+2).hex()

def serial_result(call):
    table=word(context+928)
    n,args,result=call['number'],call['args'],call['result']
    output=b''
    data=bytes(call['uart_bytes'])
    expected=b''.join(bytes.fromhex(payload) for _,payload in serial_patterns)
    if n==1:
        marker=bytes.fromhex(serial_patterns[current['serial_markers']][0])
        assert args[0]==1 and result==args[2]==len(marker)
        assert bytes.fromhex(call['buffer_before'])==marker and not data
        current['serial_markers']+=1
    elif result<0:
        assert result in [-14,-9] and not data
        assert pipe_visible(args[1],len(bytes.fromhex(call['buffer_before']))).hex()==call['buffer_before']
    elif result==0:
        assert args[0]==0 and args[2]==0 and not data and 'extent_call' not in call
    else:
        assert args[0]==0 and 0<result<=min(args[2],256) and len(data)==result
        start=len(current['serial_received'])
        assert data==expected[start:start+result]
        assert memory(args[1],result)==data
        current['serial_received']+=list(data)
        output=data
        call['output_hex']=data.hex()
    window=bytearray.fromhex(call['window_before'])
    if output:
        assert 1+len(output)<=len(window)
        window[1:1+len(output)]=output
    assert pipe_visible(call['window_pointer'],len(window))==bytes(window)
    assert hashlib.sha256(memory(table,8192)).hexdigest()==call['table_before_sha256']
    assert pipe_context()==call['context_before']
    assert call['phase_after']==call['phase_before']
    call['copy_window_verified']=True
    call['complete_table_verified']=True
    call['native_input_verified']=True

def serial_returned(row,after):
    global current
    calls=row['calls']
    assert 16<=len(calls)<=29
    assert sum(c['number']==12 for c in calls)==3 and sum(c['number']==1 for c in calls)==2
    assert all(c['number'] in [0,1,12] for c in calls)
    assert sum(c['result']==-14 for c in calls)==5
    assert sum(c['result']==-9 for c in calls)==2
    assert row['serial_markers']==2
    assert bytes(row['serial_received'])==b'Uabcdefg12345678'
    requests=[c for c in calls if c['number']!=12]
    assert all(c['copy_window_verified'] and c['complete_table_verified'] and c['native_input_verified'] for c in requests)
    large=[c for c in requests if c['number']==0 and c['args'][2]==512]
    assert len(large)==1 and large[0]['extent_call']==dict(candidate=0x639f00,length=256)
    assert hashlib.sha256(memory(word(context+928),8192)).hexdigest()==row['serial_table_before_sha256']
    row['after']=after
    row['serial_input_verified']=True
    observed['executions'].append(row)
    print('SOURCE_SERIAL_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current=None
    return False

def install_serial_observation():
    if component.get('mode')=='serial':
        SerialAdmission('*'+hex(serial_sites['admission']),internal=True)
        SerialByte('*'+hex(serial_sites['byte_received']),internal=True)



def stat_record(fields):
    result = bytearray(144)
    for offset,value in fields.items():
        assert offset in [0,8,16,24,40,48,56,64,72,88,104]
        struct.pack_into('<Q',result,offset,value)
    return bytes(result)

def stat_identity(table,identity):
    fields = {0:1,8:identity,16:1,56:4096}
    if identity == 5:
        fields.update({24:0o100755,48:2024544,64:3955})
        return stat_record(fields),'immutable-file'
    if identity in [3,4]:
        fields.update({16:4 if identity == 3 else 2,24:0o40755})
        return stat_record(fields),'directory-root' if identity == 3 else 'directory-bin'
    if identity == 6:
        at = table+0x43020
        fields.update({0:2,16:2,24:word(at),72:word(at+8),88:word(at+16),104:word(at+24)})
        return stat_record(fields),'directory-tmp'
    assert identity >= 7
    objects = [table+0x43100+i*128 for i in range(4)
               if word(table+0x43100+i*128) == 1 and word(table+0x43108+i*128) == identity]
    assert len(objects) == 1
    at = objects[0]
    blocks = sum(word(table+0x43400+i*32) == identity for i in range(8))*8
    fields.update({0:2,16:word(at+56),24:word(at+24),48:word(at+16),64:blocks,
                   72:word(at+32),88:word(at+40),104:word(at+48)})
    return stat_record(fields),'volatile-file'

def stat_descriptor(table,fd):
    if fd >= 16: return None,'bad-descriptor',-9
    index = word(table+64+fd*16)
    if not index: return None,'bad-descriptor',-9
    assert 1 <= index <= 16
    at = table+320+(index-1)*64
    kind,identity = word(at),word(at+32)
    if kind in [3,4,7]:
        expected,variant = stat_identity(table,identity)
        return expected,variant,None
    if kind in [5,6]:
        objects = [table+0x3e000+i*128 for i in range(4)
                   if word(table+0x3e000+i*128) == 1 and word(table+0x3e008+i*128) == identity]
        assert len(objects) == 1
        obj = objects[0]
        fields = {0:2,8:identity,16:1,24:word(obj+64),56:4096,
                  72:word(obj+72),88:word(obj+80),104:word(obj+88)}
        return stat_record(fields),'pipe-reader' if kind == 5 else 'pipe-writer',None
    assert kind in [1,2]
    return stat_record({0:1,8:1,16:1,24:0x2180,40:0x4400,56:4096}),'terminal',None

def stat_snapshot():
    table = word(context+928)
    assert word(table) == 1
    return dict(table=table,regions=[dict(pointer=pointer,size=size,
        sha256=hashlib.sha256(memory(pointer,size)).hexdigest()) for pointer,size in
        [(table,8192),(table+0x3e000,0x5000),(table+0x43000,0x9000)]],
        context=pipe_context())

def stat_request(call):
    before = stat_snapshot()
    table = before['table']
    n,args = call['number'],call['args']
    assert n in [5,262]
    if n == 5:
        expected,variant,error = stat_descriptor(table,args[0])
        pointer = args[1]
    else:
        pointer = args[2]
        if args[1] == 0:
            assert args[3] == 0x1000
            expected,variant,error = stat_descriptor(table,args[0])
        else:
            name = pipe_visible(args[1],256)
            name = name[:name.index(0)]
            call['stat_path_hex'] = name.hex()
            identities = {b'/':3,b'/bin':4,b'/bin/busybox':5,b'/tmp':6}
            if name in identities:
                expected,variant = stat_identity(table,identities[name])
                error = None
            elif name == b'/tmp/stat':
                slots = [i for i in range(4) if word(table+0x43040+i*16) and
                    memory(table+0x43600+i*256,word(table+0x43048+i*16)) == b'stat']
                assert len(slots) == 1
                expected,variant = stat_identity(table,word(table+0x43040+slots[0]*16))
                error = None
            else:
                assert name == b'/missing'
                expected,variant,error = None,'missing-path',-2
    call['_stat_private_before'] = before
    call['stat_variant'] = variant
    call['stat_expected_hex'] = expected.hex() if expected is not None else None
    call['stat_expected_error'] = error
    call['stat_pointer'] = pointer
    call['stat_buffer_before'] = pipe_visible(pointer,144).hex()
    call['stat_window_pointer'] = pointer-1
    call['stat_window_before'] = pipe_visible(pointer-1,146).hex()

def stat_result(call):
    before = call.pop('_stat_private_before')
    assert stat_snapshot() == before, 'stat mutated table, FIFO, filesystem or protected context'
    result,pointer = call['result'],call['stat_pointer']
    expected = bytes.fromhex(call['stat_expected_hex']) if call['stat_expected_hex'] is not None else None
    window = bytearray.fromhex(call['stat_window_before'])
    if expected is None:
        assert result == call['stat_expected_error']
    elif result < 0:
        assert result == -14
    else:
        assert result == 0 and len(window) == 146
        actual = memory(pointer,144)
        assert actual == expected, (call['stat_variant'],actual.hex(),expected.hex())
        call['stat_output_hex'] = actual.hex()
        window[1:145] = expected
    if result < 0:
        raw = bytes.fromhex(call['stat_buffer_before'])
        assert pipe_visible(pointer,len(raw)) == raw
    assert pipe_visible(call['stat_window_pointer'],len(window)) == bytes(window)
    call['stat_private_state_preserved'] = call['stat_output_window_verified'] = True

def stat_returned(row,after):
    global current
    calls = row['calls']
    assert len(calls) == 38
    assert {n:sum(c['number'] == n for c in calls) for n in [12,5,262,257,293,1,263,3]} == {
        12:3,5:13,262:9,257:4,293:1,1:1,263:1,3:6}
    queries = [c for c in calls if c['number'] in [5,262]]
    assert len(queries) == 22 and sum(c['result'] == 0 for c in queries) == 15
    assert {error:sum(c['result'] == error for c in queries) for error in [-14,-9,-2]} == {-14:5,-9:1,-2:1}
    assert all(c['stat_private_state_preserved'] and c['stat_output_window_verified'] for c in queries)
    assert {c['stat_variant'] for c in queries if c['result'] == 0} == {
        'terminal','immutable-file','directory-root','directory-bin','directory-tmp',
        'pipe-reader','pipe-writer','volatile-file'}
    assert hashlib.sha256(memory(word(context+928),8192)).hexdigest() == row['stat_table_before_sha256']
    row['after'] = after
    observed['executions'].append(row)
    print('SOURCE_STAT_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current = None
    return False


metadata_model = {}
exec('"""Independent selected public metadata effects over complete saved byte images.\n\nTOPAL-SYSTEMS-USER-EXTENT-001; TOPAL-SYSTEMS-INODE-MODE-STATE-001;\nTOPAL-SYSTEMS-NAMESPACE-TRANSACTION-001. Numeric images are observation/model\ninputs, never kernel ownership or source mutation authority.\n"""\nimport struct\n\nFS_BYTES=0x9000\nTABLE_BYTES=8192\n\n\ndef word(data,at): return struct.unpack_from(\'<Q\',data,at)[0]\ndef put(data,at,value): struct.pack_into(\'<Q\',data,at,value)\n\n\ndef entry(fs,path):\n    assert path.startswith(b\'/tmp/\') and 0<len(path[5:])<=255\n    name=path[5:]\n    found=[i for i in range(4) if word(fs,64+i*16) and\n        word(fs,72+i*16)==len(name) and fs[1536+i*256:1536+i*256+len(name)]==name]\n    assert len(found)<=1\n    return found[0] if found else None\n\n\ndef inode(fs,identity):\n    slots=[256+i*128 for i in range(4) if word(fs,256+i*128)==1 and word(fs,264+i*128)==identity]\n    assert len(slots)==1\n    return slots[0]\n\n\ndef description(table,fd):\n    assert 0<=fd<16\n    index=word(table,64+fd*16)\n    assert 1<=index<=16\n    at=320+(index-1)*64\n    assert word(table,at)==7 and word(table,at+8)==1\n    return at\n\n\ndef erase_pages(fs,identity):\n    for slot in range(8):\n        at=1024+slot*32\n        if word(fs,at)!=identity:continue\n        assert fs[24+slot]==1\n        fs[24+slot]=0\n        fs[at:at+32]=bytes(32)\n        fs[4096+slot*4096:8192+slot*4096]=bytes(4096)\n\n\ndef transition(before_fs,before_table,number,args,result,paths=(),seconds=None,payload=b\'\'):\n    assert len(before_fs)==FS_BYTES and len(before_table)==TABLE_BYTES\n    fs,table=bytearray(before_fs),bytearray(before_table)\n    if result<0:\n        assert result in [-14,-9,-17,-2] and seconds is None\n        return bytes(fs),bytes(table)\n    if number in [3,5,8]:assert seconds is None\n    else:assert seconds is not None and 0<seconds<1<<63\n    def stamp_directory():\n        put(fs,48,seconds)\n        put(fs,56,seconds)\n    def publish_name(slot,path,identity):\n        assert path.startswith(b\'/tmp/\') and 0<len(path[5:])<=255\n        name=path[5:]\n        struct.pack_into(\'<QQ\',fs,64+slot*16,identity,len(name))\n        fs[1536+slot*256:1792+slot*256]=name+bytes(256-len(name))\n    if number==257:\n        path,=paths\n        old_entry=entry(fs,path)\n        if old_entry is None:\n            assert args[2]==0x42\n            identity=word(fs,0)\n            at=next(256+i*128 for i in range(4) if fs[256+i*128:384+i*128]==bytes(128))\n            mode=0o100000|(args[3]&0o7777&~word(table,1664))\n            struct.pack_into(\'<16Q\',fs,at,1,identity,0,mode,seconds,seconds,seconds,1,*([0]*8))\n            put(fs,0,identity+1)\n            slot=next(i for i in range(4) if fs[64+i*16:80+i*16]==bytes(16))\n            publish_name(slot,path,identity)\n            stamp_directory()\n        else:\n            assert args[2]==0x202\n            identity=word(fs,64+old_entry*16)\n            at=inode(fs,identity)\n            erase_pages(fs,identity)\n            put(fs,at+16,0)\n            put(fs,at+40,seconds)\n            put(fs,at+48,seconds)\n        free=next(i for i in range(16) if word(table,64+i*16)==0)\n        index=next(i for i in range(16) if table[320+i*64:384+i*64]==bytes(64))\n        assert result==free\n        struct.pack_into(\'<QQ\',table,64+free*16,index+1,0)\n        status=(args[2]&~(0x80000|0x100|0x40|0x80|0x200))|0x8000\n        struct.pack_into(\'<8Q\',table,320+index*64,7,1,status,0,identity,0,0,0)\n    elif number==18:\n        desc=description(table,args[0])\n        identity=word(table,desc+32)\n        at=inode(fs,identity)\n        assert args[2]==result==len(payload)==4 and args[3]==0\n        pages=[i for i in range(8) if word(fs,1024+i*32)==identity and word(fs,1032+i*32)==0]\n        assert len(pages)<=1\n        slot=pages[0] if pages else next(i for i in range(8) if fs[24+i]==0)\n        if not pages:\n            assert fs[1024+slot*32:1056+slot*32]==bytes(32)\n            assert fs[4096+slot*4096:8192+slot*4096]==bytes(4096)\n            fs[24+slot]=1\n            struct.pack_into(\'<4Q\',fs,1024+slot*32,identity,0,0,0)\n        fs[4096+slot*4096:4100+slot*4096]=payload\n        put(fs,at+16,max(word(fs,at+16),4))\n        put(fs,at+40,seconds)\n        put(fs,at+48,seconds)\n    elif number==77:\n        assert result==0 and args[1]==2\n        desc=description(table,args[0])\n        identity=word(table,desc+32)\n        at=inode(fs,identity)\n        assert word(fs,at+16)==4\n        for slot in range(8):\n            page=1024+slot*32\n            if word(fs,page)!=identity:continue\n            assert word(fs,page+8)==0\n            fs[4098+slot*4096:8192+slot*4096]=bytes(4094)\n        put(fs,at+16,2)\n        put(fs,at+40,seconds)\n        put(fs,at+48,seconds)\n    elif number==91:\n        assert result==0\n        desc=description(table,args[0])\n        at=inode(fs,word(table,desc+32))\n        put(fs,at+24,(word(fs,at+24)&0o170000)|(args[1]&0o7777))\n        put(fs,at+48,seconds)\n    elif number in [82,86]:\n        assert result==0\n        old,new=paths\n        source=entry(fs,old)\n        assert source is not None and entry(fs,new) is None\n        identity=word(fs,64+source*16)\n        at=inode(fs,identity)\n        if number==86:\n            destination=next(i for i in range(4) if fs[64+i*16:80+i*16]==bytes(16))\n            put(fs,at+56,word(fs,at+56)+1)\n        else:destination=source\n        publish_name(destination,new,identity)\n        put(fs,at+48,seconds)\n        stamp_directory()\n    elif number==87:\n        assert result==0\n        path,=paths\n        slot=entry(fs,path)\n        assert slot is not None\n        at=inode(fs,word(fs,64+slot*16))\n        assert word(fs,at+56)>0\n        put(fs,at+56,word(fs,at+56)-1)\n        put(fs,at+48,seconds)\n        fs[64+slot*16:80+slot*16]=bytes(16)\n        fs[1536+slot*256:1792+slot*256]=bytes(256)\n        stamp_directory()\n    elif number==3:\n        assert result==0\n        desc=description(table,args[0])\n        identity=word(table,desc+32)\n        table[64+args[0]*16:80+args[0]*16]=bytes(16)\n        table[desc:desc+64]=bytes(64)\n        at=inode(fs,identity)\n        if not word(fs,at+56) and not any(word(table,320+i*64)==7 and word(table,352+i*64)==identity for i in range(16)):\n            erase_pages(fs,identity)\n            fs[at:at+128]=bytes(128)\n    elif number==8:\n        desc=description(table,args[0])\n        assert args[1:3]==[0,1] and result==word(table,desc+24)==0\n    else:assert number==5 and result==0\n    return bytes(fs),bytes(table)\n', metadata_model)

METADATA_BASE=0x43000
METADATA_BYTES=0x9000

def metadata_deltas(before,after):
    assert len(before)==len(after)
    changes=[]
    at=0
    while at<len(before):
        if before[at]==after[at]:
            at+=1
            continue
        start=at
        while at<len(before) and before[at]!=after[at]:at+=1
        changes.append(dict(offset=start,before=before[start:at].hex(),after=after[start:at].hex()))
    return changes

def metadata_begin(row):
    table=word(context+928)
    assert word(table)==1
    row['metadata_initial_table']=memory(table,8192).hex()
    row['metadata_initial_filesystem']=memory(table+METADATA_BASE,METADATA_BYTES).hex()

def metadata_path(pointer):
    raw=pipe_visible(pointer,256)
    return raw[:raw.index(0)].hex() if b'\0' in raw else None

def metadata_request(call):
    table=word(context+928)
    call['_metadata_table']=memory(table,8192).hex()
    call['_metadata_fs']=memory(table+METADATA_BASE,METADATA_BYTES).hex()
    call['metadata_context_before']=pipe_context()
    call['metadata_clocks']=[]
    n,args=call['number'],call['args']
    pointers=([args[1]] if n==257 else [args[0]] if n in [90,87] else args[:2] if n in [82,86] else [])
    call['metadata_paths']=[metadata_path(pointer) for pointer in pointers]
    call['metadata_payload']=pipe_visible(args[1],args[2]).hex() if n==18 else ''
    if n==5:stat_request(call)

class MetadataClock(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['end']),internal=True)
        self.row=row

    def observe(self):
        if current is not None and component.get('mode')=='metadata':
            assert pending is not None and 'metadata_clocks' in pending
            assert reg('cs')&3==0 and not reg('eflags')&(1<<9)
            pending['metadata_clocks'].append(dict(block=self.row['name'],
                call_offset=self.row['previous_offset'],seconds=reg('rax'),carry=reg('eflags')&1))
        return False

def install_metadata_observation():
    if component.get('mode')!='metadata':return
    audit=extent_inventory['stack_retirement_audit']
    assert audit['passed'] and audit['kernel_sha256']==extent_inventory['kernel_sha256']
    callers=[row for row in audit['blocks'] if row['name'].startswith('clock-caller-')]
    assert len(callers)==9
    for row in callers:MetadataClock(row)

def metadata_result(call):
    table=word(context+928)
    before_table=bytes.fromhex(call.pop('_metadata_table'))
    before_fs=bytes.fromhex(call.pop('_metadata_fs'))
    clocks=call['metadata_clocks']
    mutation=call['result']>=0 and call['number'] in [257,18,77,91,82,86,87]
    assert len(clocks)==int(mutation), ('metadata clock count',call)
    if clocks:assert clocks[0]['carry']==0
    seconds=clocks[0]['seconds'] if clocks else None
    paths=[bytes.fromhex(path) if path is not None else None for path in call['metadata_paths']]
    expected_fs,expected_table=metadata_model['transition'](before_fs,before_table,
        call['number'],call['args'],call['result'],paths,seconds,bytes.fromhex(call['metadata_payload']))
    actual_fs,actual_table=memory(table+METADATA_BASE,METADATA_BYTES),memory(table,8192)
    assert actual_fs==expected_fs, ('complete metadata filesystem delta',call['number'],
        metadata_deltas(expected_fs,actual_fs)[:8])
    assert actual_table==expected_table, ('complete metadata descriptor/table delta',call['number'],
        metadata_deltas(expected_table,actual_table)[:8])
    assert pipe_context()==call['metadata_context_before']
    call['metadata_filesystem_delta']=metadata_deltas(before_fs,actual_fs)
    call['metadata_table_delta']=metadata_deltas(before_table,actual_table)
    call['metadata_filesystem_sha256']=hashlib.sha256(actual_fs).hexdigest()
    call['metadata_table_sha256']=hashlib.sha256(actual_table).hexdigest()
    call['complete_metadata_delta_verified']=True
    if call['number']==5:stat_result(call)

def metadata_returned(row,after):
    global current
    calls=row['calls']
    expected=[12,12,90,257,5,5,18,8,5,77,5,91,91,5,86,5,82,87,5,257,5,18,8,5,91,86,82,87,5,3,5,3,87,12]
    assert [call['number'] for call in calls]==expected
    actions=[call for call in calls if call['number']!=12]
    assert all(call['complete_metadata_delta_verified'] for call in actions)
    assert [call['result'] for call in actions if call['result']<0]==[-14,-9,-17,-14,-2]
    assert sum(len(call['metadata_clocks']) for call in actions)==11
    table=word(context+928)
    assert memory(table,8192)==bytes.fromhex(row['metadata_initial_table'])
    before=bytes.fromhex(row['metadata_initial_filesystem'])
    expected=bytearray(before)
    struct.pack_into('<Q',expected,0,struct.unpack_from('<Q',before)[0]+1)
    last=next(call['metadata_clocks'][0]['seconds'] for call in reversed(actions) if call['number']==87 and call['result']==0)
    struct.pack_into('<QQ',expected,48,last,last)
    assert memory(table+METADATA_BASE,METADATA_BYTES)==bytes(expected), 'complete named-inode/page/name reclamation'
    row['metadata_retirement_verified']=True
    row['after']=after
    observed['executions'].append(row)
    print('SOURCE_METADATA_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current=None
    return False


owner_snapshot_model = {}
exec('"""Read back selected live allocation evidence at one native boundary.\n\nTOPAL-SYSTEMS-USER-EXTENT-001. Saved numeric records describe observations;\nthey cannot construct kernel owners or establish a continuous observation loan.\n"""\nimport struct\n\nPAGE=4096\nADDRESS=((1<<52)-1)&-PAGE\n\n\ndef words(raw):\n    return list(struct.unpack(\'<\'+\'Q\'*(len(raw)//8),raw))\n\n\ndef separate(a,b):\n    return a[1]<=b[0] or b[1]<=a[0]\n\n\ndef check(snapshot,bindings,kernel_spans,start,length,write):\n    """Verify live selected owners and flatten each covered translation path.\n\n    This checks the successful subset sampled by the ordinary metadata test.\n    It neither assigns authority to records nor models every refusal format.\n    """\n    allocator=snapshot[\'allocator\']\n    assert len(allocator)==16 and allocator[:2]==[1,1]\n    issued,n=allocator[2:4]\n    assert 0<issued<1<<64 and 0<n<=262144\n    tokens=snapshot[\'root_tokens\']\n    assert len(tokens)*8==bindings[\'token_bytes\'] and len(tokens)%3==0\n    assert len(bindings[\'roles\'])==4 and len({r[\'slot\'] for r in bindings[\'roles\']})==4\n    assert [(r[\'count\'],r[\'pins\']) for r in bindings[\'roles\']]==[(5,1),(1,1),(503,1),(2,2)]\n    owners=[]\n    def owner(row,token,count,pins):\n        issuer,identity,index=token\n        assert issuer==1 and 0<identity<issued and 0<=index<n\n        record,cells=row[\'record\'],row[\'cells\']\n        assert len(record)==8 and record[:2]==token[:2]\n        assert record[3:5]==[count,1] and record[5]>0 and record[6:]==[pins,1]\n        assert 0<=record[2]<record[2]+count<=n\n        assert len(cells)==count*3\n        first=cells[2]\n        assert 0<=first<first+count<=1<<18\n        assert cells[0::3]==[identity]*count and cells[1::3]==[record[5]]*count\n        assert cells[2::3]==list(range(first,first+count))\n        span=(first*PAGE,(first+count)*PAGE)\n        assert all(separate(span,other) for other in kernel_spans)\n        assert all(separate(span,old[\'span\']) and identity!=old[\'identity\'] for old in owners)\n        result=dict(identity=identity,span=span)\n        owners.append(result)\n        return result\n    assert len(snapshot[\'roles\'])==4\n    for row,role in zip(snapshot[\'roles\'],bindings[\'roles\']):\n        at=role[\'slot\']*3\n        owner(row,tokens[at:at+3],role[\'count\'],role[\'pins\'])\n    state=snapshot[\'state\']\n    assert len(state)==4 and state[0]==1 and 0<state[2]<=519\n    assert state[1]==0x5f7000+state[2]*PAGE\n    heap_tokens=snapshot[\'heap_tokens\']\n    assert len(heap_tokens)==6\n    heap=owner(snapshot[\'heap\'],heap_tokens[:3],state[2],1)\n    assert heap[\'span\'][0]==state[3]\n    assert heap[\'identity\'] not in tokens[1::3]\n    context=snapshot[\'context\']\n    assert context[\'state\']==1 and context[\'self\']==context[\'address\']==snapshot[\'gs_base\']\n    root=owners[0][\'span\'][0]\n    assert context[\'root\']==snapshot[\'cr3\']==root\n    assert context[\'low\']==owners[1][\'span\'][0]\n    assert context[\'stack_page\']==owners[3][\'span\'][0]+PAGE\n    assert snapshot[\'epoch\'][0]>0 and snapshot[\'epoch\'][1] in [5,18]\n    assert snapshot[\'cs\']&3==0 and snapshot[\'flags\']&0x600==0\n    assert snapshot[\'cr0\']&0x80010001==0x80010001\n    assert snapshot[\'cr4\']&31592448==0\n    tables=snapshot[\'tables\']\n    table_roles={root:4,root+PAGE:3,root+2*PAGE:2,root+3*PAGE:2,\n        root+4*PAGE:1,owners[1][\'span\'][0]:1}\n    assert set(tables)=={str(at) for at in table_roles}\n    assert all(len(tables[str(at)])==512 for at in table_roles)\n    assert 0<length<=144 and 0<=start<start+length<=1<<47 and write in [0,1]\n    pages=[]\n    for virtual in range(start&-PAGE,start+length,PAGE):\n        table=root\n        path=[]\n        for level,shift in [(4,39),(3,30),(2,21),(1,12)]:\n            assert table_roles.get(table)==level\n            entry=tables[str(table)][(virtual>>shift)&511]\n            assert entry&~(ADDRESS|(1<<63)|0x67)==0\n            assert entry&(7 if write else 5)==(7 if write else 5)\n            path.append(dict(table=table,level=level,entry=entry))\n            table=entry&ADDRESS\n        if 0x400000<=virtual<0x5f7000:\n            selected=owners[2]\n            offset=virtual-0x400000\n            assert not write or virtual>=(0x5ed000 if context[\'phase\']>=9 else 0x5e5000)\n        elif 0x7fe000<=virtual<0x800000:\n            selected=owners[3]\n            offset=virtual-0x7fe000\n        else:\n            assert 0x5f7000<=virtual<state[1]\n            selected=heap\n            offset=virtual-0x5f7000\n        assert table==selected[\'span\'][0]+offset\n        assert table not in table_roles\n        pages.append(dict(virtual=virtual,physical=table,identity=selected[\'identity\'],path=path))\n    return dict(owners=owners,pages=pages,write=write,start=start,length=length,\n        scope=\'Live selected allocation/translation evidence at this boundary; no continuous lifetime, all-caller or production qualification\')\n', owner_snapshot_model)

owner_pending=None
owner_snapshots={}
owner_records=[]
owner_addresses={}

def owner_read(symbol,count):
    return words(owner_addresses[symbol],count)

def owner_capture():
    allocator=owner_read('context',16)
    assert allocator[:2]==[1,1] and 0<allocator[3]<=262144
    tokens=owner_read('root_tokens',owner_profile['bindings']['token_bytes']//8)
    def allocation(token,count):
        assert len(token)==3 and token[0]==1 and 0<token[1]<allocator[2] and token[2]<allocator[3]
        record=words(owner_addresses['registry']+token[2]*64,8)
        assert 0<count<=519 and 0<=record[2]<record[2]+count<=allocator[3]
        cells=words(owner_addresses['table']+128+record[2]*24,count*3)
        return dict(record=record,cells=cells)
    roles=[allocation(tokens[r['slot']*3:r['slot']*3+3],r['count']) for r in owner_profile['bindings']['roles']]
    root=roles[0]['cells'][2]*4096
    low=roles[1]['cells'][2]*4096
    mm=state()
    heap_tokens=owner_read('mm_tokens',6)
    return dict(allocator=allocator,root_tokens=tokens,roles=roles,state=mm,
        heap_tokens=heap_tokens,heap=allocation(heap_tokens[:3],mm[2]),
        context=dict(address=context,state=word(context),self=word(context+256),root=word(context+24),
            low=word(context+112),stack_page=word(context+912),phase=memory(context+104,1)[0]),
        tables={str(at):words(at,512) for at in [root,root+4096,root+8192,root+12288,root+16384,low]},
        epoch=owner_read('mm_epoch',2),cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'),
        gs_base=reg('gs_base'),cs=reg('cs'),flags=reg('eflags'))

def owner_check(snapshot,start,length,direction):
    return owner_snapshot_model['check'](snapshot,owner_profile['bindings'],
        owner_profile['kernel_spans'],start,length,direction)

def owner_remember(snapshot):
    raw=json.dumps(snapshot,sort_keys=True,separators=(',',':')).encode()
    key=hashlib.sha256(raw).hexdigest()
    assert key not in owner_snapshots or owner_snapshots[key]==snapshot
    owner_snapshots[key]=snapshot
    return key

class OwnerBoundary(Checked):
    def __init__(self,direction,returning):
        name='topal_x86_user_extent_'+('writable' if direction else 'readable')+('_return_v1' if returning else '_v1')
        super().__init__('*'+name,internal=True)
        self.direction,self.returning=direction,returning

    def observe(self):
        global owner_pending
        if current is None or pending is None or pending['number'] not in [5,18]:return False
        assert (pending['number']==5)==bool(self.direction)
        if not self.returning:
            assert owner_pending is None
            start,length=reg('r8'),reg('r9')
            assert start==pending['args'][1] and length==(144 if pending['number']==5 else 4)
            captured=owner_capture()
            evidence=owner_check(captured,start,length,self.direction)
            owner_pending=dict(start=start,length=length,direction=self.direction,sp=reg('rsp'),
                site=word(reg('rsp')),snapshot=captured,evidence=evidence,
                number=pending['number'],args=list(pending['args']))
            interval_begin(owner_pending)
        else:
            assert owner_pending is not None and owner_pending['direction']==self.direction
            before=owner_pending
            assert reg('rsp')==before['sp'] and word(reg('rsp'))==before['site']
            assert reg('rax')==0 and reg('eflags')&1==0
            captured=owner_capture()
            evidence=owner_check(captured,before['start'],before['length'],self.direction)
            # Flags are transient arithmetic results. Every retained owner,
            # translation word, entry identity and mode must agree exactly.
            assert {k:v for k,v in captured.items() if k!='flags'}=={k:v for k,v in before['snapshot'].items() if k!='flags'}
            assert evidence==before['evidence']
            owner_records.append(dict(number=before['number'],args=before['args'],
                start=before['start'],length=before['length'],direction=self.direction,
                before=owner_remember(before['snapshot']),after=owner_remember(captured),evidence=evidence))
            owner_pending=None
        return False

def install_owner_observation():
    if owner_profile is None:return
    assert component['mode']=='metadata'
    for suffix in ['context','root_tokens','registry','table','mm_tokens','mm_epoch']:
        owner_addresses[suffix]=address('topal_x86_frame_'+suffix+'_v1')
    for direction in [0,1]:
        for returning in [False,True]:OwnerBoundary(direction,returning)

def owner_observation_complete():
    if owner_profile is None:return
    assert owner_pending is None and len(owner_records)==52
    assert sum(row['number']==5 for row in owner_records)==44
    assert sum(row['number']==18 for row in owner_records)==8
    observed['owner_boundary_observation']=dict(passed=True,records=owner_records,snapshots=owner_snapshots,
        profile=owner_profile,model_sha256=hashlib.sha256(owner_profile['model'].encode()).hexdigest(),
        scope='Selected stat and positional-write helper entry/return owner observations, not continuous lifetime or whole-caller qualification')


owner_interval_model=dict(owner_snapshot_model=owner_snapshot_model)
exec('"""Selected owner-record watch ranges and permitted hardware table status sets.\n\nTOPAL-SYSTEMS-USER-EXTENT-001. Describes read-only debugger observations, not\nkernel loans, physical watchpoints or an exclusion proof for all agents/aliases.\n"""\ncheck=owner_snapshot_model[\'check\']\n\n\ndef regions(snapshot,bindings,addresses):\n    result=[]\n    def add(name,start,size):\n        assert 0<start<start+size<=1<<30 and 0<size<=16384\n        assert all(start+size<=r[\'start\'] or r[\'start\']+r[\'size\']<=start for r in result)\n        result.append(dict(name=name,start=start,size=size))\n    for table in sorted(map(int,snapshot[\'tables\'])):add(\'translation-\'+str(table),table,4096)\n    for name,size in [(\'root_tokens\',bindings[\'token_bytes\']),(\'mm_tokens\',48),\n            (\'context\',128),(\'mm_state\',32),(\'mm_epoch\',16)]:\n        add(name,addresses[name],size)\n    for name,offset in [(\'process-state\',0),(\'process-root\',24),(\'process-low\',112),\n            (\'process-self\',256),(\'process-stack-page\',912)]:\n        add(name,snapshot[\'context\'][\'address\']+offset,8)\n    tokens=snapshot[\'root_tokens\']\n    selected=[tokens[r[\'slot\']*3:r[\'slot\']*3+3] for r in bindings[\'roles\']]+[snapshot[\'heap_tokens\'][:3]]\n    allocations=snapshot[\'roles\']+[snapshot[\'heap\']]\n    for i,(token,allocation) in enumerate(zip(selected,allocations)):\n        add(\'registry-\'+str(i),addresses[\'registry\']+token[2]*64,64)\n        add(\'cells-\'+str(i),addresses[\'table\']+128+allocation[\'record\'][2]*24,len(allocation[\'cells\'])*8)\n    assert len(result)==26\n    return result\n\n\ndef compare(before,after,bindings,kernel_spans,start,length,write):\n    first=check(before,bindings,kernel_spans,start,length,write)\n    last=check(after,bindings,kernel_spans,start,length,write)\n    assert {k:v for k,v in before.items() if k not in [\'tables\',\'flags\']}=={k:v for k,v in after.items() if k not in [\'tables\',\'flags\']}\n    allowed={}\n    for page in first[\'pages\']:\n        for row in page[\'path\']:\n            shift={4:39,3:30,2:21,1:12}[row[\'level\']]\n            index=(page[\'virtual\']>>shift)&511\n            allowed[(str(row[\'table\']),index)]=0x20|(0x40 if write and row[\'level\']==1 else 0)\n    changes=[]\n    for table,words in before[\'tables\'].items():\n        assert len(words)==len(after[\'tables\'][table])==512\n        for index,(a,b) in enumerate(zip(words,after[\'tables\'][table])):\n            if a==b:continue\n            mask=allowed.get((table,index),0)\n            assert (a&~mask)==(b&~mask) and ((a&mask)|(b&mask))==(b&mask)\n            changes.append(dict(table=int(table),index=index,before=a,after=b,allowed_set_mask=mask))\n    assert [(r[\'virtual\'],r[\'physical\'],r[\'identity\']) for r in first[\'pages\']]==[(r[\'virtual\'],r[\'physical\'],r[\'identity\']) for r in last[\'pages\']]\n    return dict(passed=True,table_status_sets=changes,\n        scope=\'Equal selected owner/entry/mode records, with monotonic A/D sets on covered paths only; not continuous hardware mode, DMA, physical aliases or general lifetime qualification\')\n',owner_interval_model)

interval_active=None
interval_records=[]
interval_snapshots={}
interval_controls=[]
interval_control_pending=None
interval_watches={}
interval_created=[]
interval_watchpoints_retired=False
interval_finish_points={}

def interval_remember(snapshot):
    raw=json.dumps(snapshot,sort_keys=True,separators=(',',':')).encode()
    key=hashlib.sha256(raw).hexdigest()
    assert key not in interval_snapshots or interval_snapshots[key]==snapshot
    interval_snapshots[key]=snapshot
    return key

class IntervalWatch(gdb.Breakpoint):
    def __init__(self,row):
        self.row=row
        self.control=None
        super().__init__('*(unsigned char (*)['+str(row['size'])+'])'+hex(row['start']),
            type=gdb.BP_WATCHPOINT,wp_class=gdb.WP_WRITE,internal=True)
        assert self.type==gdb.BP_HARDWARE_WATCHPOINT
        self.enabled=False
        interval_created.append(dict(number=self.number,type=self.type,expression=self.expression,
            start=row['start'],size=row['size']))

    def stop(self):
        try:
            actual=memory(self.row['start'],self.row['size'])
            event=dict(region=self.row,rip=reg('rip'),cs=reg('cs'),
                thread=list(gdb.selected_thread().ptid),epoch=owner_read('mm_epoch',2),after=actual.hex())
            if self.control is not None:
                assert interval_active is None and pending is not None and pending['number']==12
                assert actual!=bytes.fromhex(self.control['before']) and reg('cs')&3==0
                event.update(before=self.control['before'],kind='ordinary-brk-positive-control')
                interval_controls.append(event)
                self.enabled=False
                self.control=None
                return False
            observed['owner_interval_violation']=event
            raise AssertionError('CPU store changed a protected owner/translation range during admission and copy')
        except Exception:
            traceback.print_exc()
            with open(observation_path,'w') as handle:json.dump(observed,handle,indent=2)
            return True

def interval_point(row):
    key=(row['start'],row['size'])
    if key not in interval_watches:interval_watches[key]=IntervalWatch(row)
    point=interval_watches[key]
    assert point.type==gdb.BP_HARDWARE_WATCHPOINT and not point.enabled and point.control is None
    return point

def interval_syscall_entered(call):
    global interval_control_pending
    if not interval_profile or current is None or call['number']!=12 or call['args'][0]!=0x63a000:return
    assert interval_active is None and interval_control_pending is None
    snapshot=owner_capture()
    rows=[dict(name='control-translation-page',start=snapshot['context']['root']+16384,size=4096),
        dict(name='control-mm-state',start=owner_addresses['mm_state'],size=32),
        dict(name='control-heap-registry',start=owner_addresses['registry']+snapshot['heap_tokens'][2]*64,size=64)]
    interval_control_pending=dict(before=len(interval_controls),points=[])
    for row in rows:
        point=interval_point(row)
        point.control=dict(before=memory(row['start'],row['size']).hex())
        point.enabled=True
        interval_control_pending['points'].append(point)

def interval_syscall_returned(call):
    global interval_control_pending
    if not interval_profile:return
    assert interval_active is None,'copy completion was not observed before source syscall return'
    if interval_control_pending is not None:
        assert call['number']==12 and call['args'][0]==call['result']==0x63a000
        assert len(interval_controls)-interval_control_pending['before']==3
        assert all(not p.enabled and p.control is None for p in interval_control_pending['points'])
        interval_control_pending=None

def interval_begin(before):
    global interval_active
    if not interval_profile:return
    assert interval_active is None and interval_control_pending is None
    call_offset=before['site']-extent_inventory['address']-5
    audit=extent_inventory['stat_output_audit'] if before['number']==5 else extent_inventory['file_input_audit']
    row,=[row for row in audit['cases'] if row['call_offset']==call_offset]
    assert row['name']==('descriptor-stat-output' if before['number']==5 else 'volatile-pwrite-input')
    ranges=owner_interval_model['regions'](before['snapshot'],owner_profile['bindings'],owner_addresses)
    points=[]
    for region in ranges:
        point=interval_point(region)
        point.enabled=True
        points.append(point)
    interval_active=dict(number=before['number'],args=list(before['args']),start=before['start'],
        length=before['length'],direction=before['direction'],before=before['snapshot'],
        ranges=ranges,points=points,call_offset=call_offset,copy_offset=row['copy_offset'],copy_size=row['copy_size'])
    interval_finish_points[row['copy_offset']].enabled=True

class IntervalFinished(Checked):
    def __init__(self,row):
        self.row=row
        super().__init__('*'+hex(extent_inventory['address']+row['copy_offset']+row['copy_size']),internal=True)
        self.enabled=False

    def observe(self):
        global interval_active
        assert interval_active is not None and owner_pending is None
        before=interval_active
        assert before['copy_offset']==self.row['copy_offset']
        assert all(point.enabled and point.type==gdb.BP_HARDWARE_WATCHPOINT for point in before['points'])
        assert reg('rcx')==0
        assert reg('rdi' if before['direction'] else 'rsi')==before['start']+before['length']
        after=owner_capture()
        comparison=owner_interval_model['compare'](before['before'],after,owner_profile['bindings'],
            owner_profile['kernel_spans'],before['start'],before['length'],before['direction'])
        for point in before['points']:point.enabled=False
        self.enabled=False
        interval_records.append(dict(number=before['number'],args=before['args'],start=before['start'],
            length=before['length'],direction=before['direction'],call_offset=before['call_offset'],
            copy_offset=before['copy_offset'],copy_size=before['copy_size'],
            before=interval_remember(before['before']),after=interval_remember(after),
            ranges=before['ranges'],hardware_watchpoint_count=len(before['points']),comparison=comparison,
            identity_address_cpu_store_changes=0,copy_completed=True))
        interval_active=None
        return False

def install_interval_observation():
    if not interval_profile:return
    assert owner_profile is not None and component['mode']=='metadata'
    owner_addresses['mm_state']=address('topal_x86_frame_mm_state_v1')
    for audit,name in [(extent_inventory['stat_output_audit'],'descriptor-stat-output'),
            (extent_inventory['file_input_audit'],'volatile-pwrite-input')]:
        row,=[row for row in audit['cases'] if row['name']==name]
        interval_finish_points[row['copy_offset']]=IntervalFinished(row)

def interval_case_completed():
    global interval_watchpoints_retired
    if not interval_profile or len(observed['executions'])!=3:return
    assert interval_active is interval_control_pending is None
    assert len(interval_records)==52 and len(interval_controls)==12
    assert all(not point.enabled and point.control is None for point in interval_watches.values())
    # The selected intervals are all finished. Release inactive debugger value
    # histories before the enclosing application's independent retirement run.
    for point in interval_watches.values():point.delete()
    interval_watches.clear()
    interval_watchpoints_retired=True
    with open(observation_path+'.interval-progress.json','w') as handle:
        json.dump(dict(passed=False,selected_intervals_complete=True,records=interval_records,
            controls=interval_controls,snapshots=interval_snapshots,created_watchpoints=interval_created,
            inactive_watchpoints_deleted=True,full_guest_retirement_complete=False),handle,indent=2)

def interval_observation_complete():
    if not interval_profile:return
    assert interval_active is interval_control_pending is None
    assert len(interval_records)==52 and len(interval_controls)==12
    assert interval_watchpoints_retired and not interval_watches
    assert all(not point.enabled and point.control is None for point in interval_watches.values())
    observed['owner_interval_observation']=dict(passed=True,records=interval_records,controls=interval_controls,
        snapshots=interval_snapshots,model_sha256=interval_model_sha256,
        addresses=owner_addresses,watchpoints_created=len(interval_created),created_watchpoints=interval_created,
        inactive_watchpoints_deleted_after_cases=interval_watchpoints_retired,
        all_watchpoints_hardware=True,all_watchpoints_disabled=True,
        scope='Selected CPU stores to watched identity virtual addresses from helper entry through actual copy completion, with ordinary brk positive controls. Not physical-alias, DMA, continuous control-register, all asynchronous-entry or general stable-lifetime qualification')

translation_model={}
exec('"""Saved-data checks for the actual local heap publication/invalidation order.\n\nTOPAL-SYSTEMS-USER-EXTENT-001. Numeric records describe observations; they do not\ncreate mapping authority, inspect a TLB or establish AP/DMA/async exclusion.\n"""\nPAGE=4096\nHEAP=0x5f7000\nLEAF=(1<<63)|7\n\n\ndef controls(snapshot):\n    assert snapshot[\'cr0\']&0x80010001==0x80010001\n    assert snapshot[\'cr4\']&0x20 and snapshot[\'cr4\']&((1<<7)|(1<<12)|(1<<17))==0\n    assert snapshot[\'cs\']&3==0 and snapshot[\'flags\']&0x600==0\n    return tuple(snapshot[k] for k in [\'cr0\',\'cr3\',\'cr4\',\'cs\'])\n\n\ndef check_switch(record):\n    before,after=record[\'before\'],record[\'after\']\n    first,last=controls(before),controls(after)\n    ctx=before[\'context\']\n    assert ctx==after[\'context\'] and ctx[\'state\']==1\n    assert before[\'thread\']==after[\'thread\']\n    assert all(0<ctx[k]<1<<30 and ctx[k]%PAGE==0 for k in [\'root\',\'bootstrap\'])\n    assert ctx[\'root\']!=ctx[\'bootstrap\']\n    assert first[1]==ctx[\'root\'] and last[1]==ctx[\'bootstrap\']\n    assert first[0]==last[0] and first[2:]==last[2:]\n    return dict(passed=True,target_root=ctx[\'root\'],bootstrap_root=ctx[\'bootstrap\'],\n        scope=\'Observed local CR3 replacement with PCID/global paging disabled; no other CPU or continuous-mode proof\')\n\n\ndef mode(snapshot,detachment=None):\n    current=controls(snapshot)\n    ctx=snapshot[\'context\']\n    assert ctx[\'root\']%PAGE==0\n    if snapshot[\'cr3\']==ctx[\'root\']:\n        assert ctx[\'state\']==1 and detachment is None\n    else:\n        assert detachment is not None,\'detached root requires its observed flushing handoff\'\n        check_switch(detachment)\n        after=detachment[\'after\']\n        assert ctx[\'state\']==2 and snapshot[\'cr3\']==ctx[\'bootstrap\']\n        assert {k:v for k,v in ctx.items() if k!=\'state\'}=={k:v for k,v in after[\'context\'].items() if k!=\'state\'}\n        assert current==controls(after) and snapshot[\'thread\']==after[\'thread\']\n    return current\n\n\ndef slot(snapshot,index):\n    assert 0<=index<519\n    ctx=snapshot[\'context\']\n    return (str(ctx[\'low\']),503+index) if index<9 else (str(ctx[\'root\']+16384),index-9)\n\n\ndef published(before,after,old,new,base,detachment=None):\n    assert 0<=old<=519 and 0<=new<=519 and old!=new\n    assert before[\'state\'][2]==old\n    assert base%PAGE==0 and (base>0 if new else base==0)\n    assert 0<=base<=base+new*PAGE<=1<<30\n    if detachment is not None:assert old>0 and new==0,\'detached publication must revoke the whole heap\'\n    assert mode(before,detachment)==mode(after,detachment)\n    assert before[\'thread\']==after[\'thread\'] and before[\'context\']==after[\'context\']\n    assert before[\'state\']==after[\'state\'] and before[\'tokens\']==after[\'tokens\']\n    root=before[\'context\'][\'root\']\n    expected={str(t) for t in [root,root+PAGE,root+2*PAGE,root+3*PAGE,root+4*PAGE,before[\'context\'][\'low\']]}\n    assert set(before[\'tables\'])==set(after[\'tables\'])==expected\n    selected={slot(before,i):((base+i*PAGE)|LEAF if i<new else 0) for i in range(max(old,new))}\n    for table,words in before[\'tables\'].items():\n        actual=after[\'tables\'][table]\n        assert len(words)==len(actual)==512\n        for index,(a,b) in enumerate(zip(words,actual)):\n            assert type(a) is int and type(b) is int and 0<=a<1<<64 and 0<=b<1<<64\n            if (table,index) in selected:\n                assert b&~0x60==selected[(table,index)],\'published heap leaf differs\'\n            else:\n                assert a&~0x60==b&~0x60 and (a|b)==b,\'unrelated translation changed\'\n    for i in range(519):\n        table,index=slot(before,i)\n        old_expected=((before[\'state\'][3]+i*PAGE)|LEAF) if i<old else 0\n        assert before[\'tables\'][table][index]&~0x60==old_expected,\'old heap leaf differs\'\n    return max(old,new)\n\n\ndef check(record):\n    old,new,base=record[\'old_count\'],record[\'new_count\'],record[\'new_base\']\n    detachment=record.get(\'detachment\')\n    if detachment is not None:assert record[\'operation\']==6\n    count=published(record[\'before\'],record[\'stored\'],old,new,base,detachment)\n    assert record[\'published_before_invalidations\'],\'missing publication barrier observation\'\n    assert len(record[\'invalidations\'])==count,\'incomplete invalidation interval\'\n    for index,event in enumerate(record[\'invalidations\']):\n        assert event[\'index\']==index and event[\'address\']==HEAP+index*PAGE,\'wrong invalidation page/order\'\n        assert event[\'thread\']==record[\'before\'][\'thread\'],\'local invalidation changed CPU\'\n    assert record[\'after\'][\'tables\']==record[\'stored\'][\'tables\'],\'translations changed during invalidation\'\n    assert mode(record[\'after\'],detachment)==mode(record[\'before\'],detachment)\n    assert record[\'after\'][\'thread\']==record[\'before\'][\'thread\']\n    assert record[\'after\'][\'context\']==record[\'before\'][\'context\']\n    assert record[\'after\'][\'state\']==record[\'before\'][\'state\']\n    assert record[\'after\'][\'tokens\']==record[\'before\'][\'tokens\']\n    assert record[\'return_stack\']==record[\'entry_stack\'] and record[\'return_address\']==record[\'entry_return_address\']\n    assert record[\'final_barrier_observed\'],\'missing final publication barrier\'\n    return dict(passed=True,pages_invalidated=count,\n        scope=\'Recorded active heap publication or whole detached cleanup bound to its observed flushing CR3 handoff, plus current-context post-INVLPG boundaries and final barrier. Not TLB introspection, continuous mode, AP/DMA/async or general stable ownership qualification\')\n',translation_model)
translation_trace_model={}
exec('"""Parse saved QEMU TCG CPU states immediately following the publisher INVLPG.\n\nThese are execution-log observations, not a TLB dump or general CPU exclusion.\n"""\nimport re\n\n\ndef parse(raw,site):\n    # With default chaining, QEMU\'s exec logger also emits link diagnostics,\n    # including on a CPU with no states inside the address filter.\n    text=\'\'.join(line for line in raw.decode(\'ascii\').splitlines(keepends=True)\n        if not re.fullmatch(r\'Linking TBs 0x[0-9a-f]+ index [01] -> 0x[0-9a-f]+\\n?\',line))\n    starts=list(re.finditer(r\'^Trace ([0-9]+): (0x[0-9a-f]+) \\[([0-9a-f]+)/([0-9a-f]+)/[^\\]]+\\][^\\n]*\\n\',text,re.M))\n    assert not starts or not text[:starts[0].start()].strip(),\'unexpected trace prefix\'\n    result=[]\n    for i,header in enumerate(starts):\n        cpu,tb,_,pc=header.groups()\n        pc=int(pc,16)\n        assert pc==site,\'unexpected CPU trace PC\'\n        block=text[header.end():starts[i+1].start() if i+1<len(starts) else len(text)]\n        def value(name):\n            values=re.findall(r\'\\b\'+name+r\'\\s*=([0-9a-fA-F]+)\',block)\n            assert len(values)==1,(\'missing or duplicate CPU state\',name)\n            return int(values[0],16)\n        assert value(\'RIP\')==site and value(\'CS\')&3==0\n        stopped=re.findall(r\'^Stopped execution of TB chain before (0x[0-9a-f]+) \\[([0-9a-f]+)\\][^\\n]*$\',block,re.M)\n        assert len(stopped)==sum(line.startswith(\'Stopped execution\') for line in block.splitlines())\n        assert len(stopped)<=1 and all(pointer==tb and int(address,16)==site for pointer,address in stopped)\n        result.append(dict(cpu=int(cpu),index=value(\'RCX\'),address=value(\'RAX\'),\n            cr0=value(\'CR0\'),cr3=value(\'CR3\'),cr4=value(\'CR4\'),efer=value(\'EFER\'),flags=value(\'RFL\'),cancelled=bool(stopped)))\n    assert not text or starts,\'unparsed nonempty CPU trace\'\n    return result\n\n\ndef completed(events):\n    """Keep explicit cancelled attempts separate and require their exact retry.\n\n    A CPU dump precedes its execution block. QEMU explicitly reports a block\n    stopped before execution; it can then log the same post-INVLPG PC again.\n    No unmarked duplicate, different retry or terminal cancellation is removed.\n    """\n    pending=None\n    states=[]\n    cancelled=[]\n    for event in events:\n        key={k:v for k,v in event.items() if k!=\'cancelled\'}\n        if pending is not None:assert key==pending,\'cancelled block lacks matching retry\'\n        if event[\'cancelled\']:\n            pending=key\n            cancelled.append(event)\n        else:\n            states.append(event)\n            pending=None\n    assert pending is None,\'terminal cancelled block has no retry\'\n    return states,cancelled\n',translation_trace_model)

from pathlib import Path
translation_active=None
translation_request=None
translation_records=[]
translation_requests=[]
translation_return_points={}
translation_release_point=None
translation_root_switches=[]
translation_root_switch_pending=None

def translation_trace_positions():
    return {path.name:path.stat().st_size for path in Path(observation_path).parent.glob('cpu-*.log')}

def translation_progress():
    with open(observation_path+'.translation-progress.json','w') as handle:
        json.dump(dict(passed=False,full_guest_retirement_complete=False,records=translation_records,
            requests=translation_requests),handle,indent=2)

def translation_capture():
    root,low=word(context+24),word(context+112)
    assert 0<root<=(1<<30)-5*4096 and root%4096==0
    assert 0<low<=(1<<30)-4096 and low%4096==0
    return dict(context=dict(address=context,root=root,low=low,state=word(context),bootstrap=word(context+16)),state=state(),
        tokens=words(address('topal_x86_frame_mm_tokens_v1'),6),
        tables={str(at):words(at,512) for at in [root,root+4096,root+8192,root+12288,root+16384,low]},
        thread=list(gdb.selected_thread().ptid),cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'),
        cs=reg('cs'),flags=reg('eflags'))

class TranslationPublication(Checked):
    def __init__(self,kind,site):
        self.kind=kind
        super().__init__('*'+hex(site),internal=True)

    def observe(self):
        global translation_active
        assert translation_request is not None
        if self.kind=='entry':
            assert translation_active is None and translation_request['publication_index'] is None
            translation_active=dict(old_count=reg('rdi'),new_count=reg('rsi'),new_base=reg('rdx'),
                operation=translation_request['operation'],detachment=translation_request['detachment'],
                before=translation_capture(),entry_stack=reg('rsp'),entry_return_address=word(reg('rsp')),
                invalidations=[],published_before_invalidations=False,final_barrier_observed=False,
                trace_before=translation_trace_positions())
        elif self.kind=='stored':
            row=translation_active
            assert row is not None and not row['published_before_invalidations'] and not row['invalidations']
            row['stored']=translation_capture()
            translation_model['published'](row['before'],row['stored'],row['old_count'],row['new_count'],row['new_base'],row['detachment'])
            row['published_before_invalidations']=True
        else:
            assert self.kind=='returning' and translation_active is not None
            row=translation_active
            row.update(after=translation_capture(),return_stack=reg('rsp'),return_address=word(reg('rsp')),
                final_barrier_observed=True)
            row['trace_slices']=[]
            for path in sorted(Path(observation_path).parent.glob('cpu-*.log')):
                start=row['trace_before'].get(path.name,0)
                raw=path.read_bytes()[start:]
                events=translation_trace_model['parse'](raw,translation_profile['sites']['invalidated'])
                row['trace_slices'].append(dict(file=path.name,start=start,size=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
                states,cancelled=translation_trace_model['completed'](events)
                row.setdefault('cancelled_post_states',[]).extend(cancelled)
                for event in events:
                    assert event['cpu']+1==row['before']['thread'][1] and row['before']['thread'][0]==1
                    assert (event['cr0'],event['cr3'],event['cr4'])==tuple(row['before'][k] for k in ['cr0','cr3','cr4'])
                    assert event['efer']&0xd00==0xd00 and event['flags']&0x600==0
                row['invalidations'].extend(dict(event,thread=row['before']['thread']) for event in states)
            row['comparison']=translation_model['check'](row)
            translation_request['publication_index']=len(translation_records)
            translation_records.append(row)
            translation_active=None
            translation_progress()
        return False

class TranslationRequest(Checked):
    def observe(self):
        global translation_request
        assert translation_request is None and translation_active is None
        assert translation_release_point is not None and not translation_release_point.enabled
        translation_release_point.enabled=True
        stack=reg('rsp')
        site=word(stack)
        translation_request=dict(operation=reg('rdi'),request=reg('rsi'),before=translation_capture(),
            entry_stack=stack,entry_return_address=site,publication_index=None,erase=None,release=None,
            detachment=(translation_root_switches[-1] if reg('rdi')==6 and translation_root_switches else None))
        assert translation_request['operation'] in [5,6,7]
        assert (translation_request['operation']==6)==(translation_request['detachment'] is not None)
        translation_model['mode'](translation_request['before'],translation_request['detachment'])
        if site not in translation_return_points:
            translation_return_points[site]=TranslationRequestReturned('*'+hex(site),internal=True)
        translation_return_points[site].enabled=True
        return False

class TranslationRequestReturned(Checked):
    def observe(self):
        global translation_request
        row=translation_request
        assert row is not None and translation_active is None
        assert translation_release_point.enabled
        assert reg('rsp')==row['entry_stack']+8 and reg('rip')==row['entry_return_address']
        row.update(after=translation_capture(),result=reg('rax'))
        translation_model['mode'](row['after'],row['detachment'])
        index=row['publication_index']
        if index is not None:
            publication=translation_records[index]
            assert row['before']['state'][2]==publication['old_count']
            assert row['after']['state'][2]==publication['new_count']
            if publication['old_count']:
                assert row['erase'] is not None and row['release'] is not None
            else:assert row['erase'] is row['release'] is None
        else:
            assert row['before']['state'][2:]==row['after']['state'][2:]
            assert row['erase'] is row['release'] is None
        translation_requests.append(row)
        translation_request=None
        translation_release_point.enabled=False
        self.enabled=False
        translation_progress()
        return False

class TranslationErase(Checked):
    def observe(self):
        if translation_request is None:return False
        row=translation_request
        assert translation_active is None and row['publication_index'] is not None
        assert row['erase'] is None and row['release'] is None
        publication=translation_records[row['publication_index']]
        old=publication['before']['state']
        assert reg('rdi')==old[3] and reg('rsi')==old[2] and old[2]>0
        token=words(address('topal_x86_frame_mm_tokens_v1'),3)
        registry=words(address('topal_x86_frame_registry_v1')+token[2]*64,8)
        assert registry[:2]==token[:2] and registry[3]==old[2] and registry[6:]==[0,1]
        row['erase']=dict(base=reg('rdi'),count=reg('rsi'),old_token=token,old_registry=registry,
            after_publication_index=row['publication_index'],thread=list(gdb.selected_thread().ptid))
        return False

class TranslationRelease(Checked):
    def observe(self):
        if translation_request is None:return False
        row=translation_request
        assert translation_active is None and row['erase'] is not None and row['release'] is None
        assert reg('rsi')==address('topal_x86_frame_mm_tokens_v1')
        erase=row['erase']
        raw=memory(erase['base'],erase['count']*4096)
        assert raw==bytes(len(raw))
        row['release']=dict(base=erase['base'],count=erase['count'],erased_bytes=len(raw),
            erased_sha256=hashlib.sha256(raw).hexdigest(),after_publication_index=row['publication_index'],
            thread=list(gdb.selected_thread().ptid))
        return False

class TranslationRootSwitch(Checked):
    def __init__(self,kind,site):
        self.kind=kind
        super().__init__('*'+hex(site),internal=True)

    def observe(self):
        global translation_root_switch_pending
        assert translation_request is translation_active is None
        if self.kind=='before':
            assert translation_root_switch_pending is None
            before=translation_capture()
            assert reg('rax')==before['context']['bootstrap']
            translation_root_switch_pending=dict(before=before,before_site=reg('rip'),source_register=reg('rax'))
        else:
            assert self.kind=='after' and translation_root_switch_pending is not None
            row=translation_root_switch_pending
            row['after']=translation_capture()
            row['after_site']=reg('rip')
            row['comparison']=translation_model['check_switch'](row)
            translation_root_switches.append(row)
            translation_root_switch_pending=None
        return False

def install_translation_observation():
    global translation_release_point
    if translation_profile is None:return
    assert component['mode']=='metadata'
    for kind,site in translation_profile['root_switch_sites'].items():TranslationRootSwitch(kind,site)
    for kind,site in translation_profile['sites'].items():
        if kind!='invalidated':TranslationPublication(kind,site)
    TranslationRequest('*topal_frame_memory_request_v1',internal=True)
    TranslationErase('*'+hex(translation_profile['erase_entry']),internal=True)
    translation_release_point=TranslationRelease('*topal_frame_allocator_release_v1',internal=True)
    translation_release_point.enabled=False

def translation_observation_complete():
    if translation_profile is None:return
    assert translation_active is translation_request is None
    assert translation_root_switch_pending is None and translation_root_switches
    assert translation_release_point is not None and not translation_release_point.enabled
    assert translation_records and translation_requests
    assert all(not point.enabled for point in translation_return_points.values())
    observed['translation_publication_observation']=dict(passed=True,records=translation_records,
        requests=translation_requests,profile=translation_profile,root_switches=translation_root_switches,
        model_sha256=hashlib.sha256(translation_model_source.encode()).hexdigest(),
        trace_model_sha256=hashlib.sha256(translation_trace_model_source.encode()).hexdigest(),
        scope='Actual local heap publication and post-INVLPG/final-barrier boundaries, plus unpin/erase/release ordering in ordinary requests; not TLB introspection, all CPUs, continuous mode, DMA/async or complete stable lifetime qualification')

image_publication_model={}
exec('"""Saved-data checks of selected image-leaf publication and local invalidation.\n\nTOPAL-SYSTEMS-USER-EXTENT-001. Records cannot create ownership or qualify\nunobserved entries, CPUs, DMA, faults, asynchronous behavior or stable lifetime.\n"""\nPAGE=4096\nBASE=0x5e5000\nNX=1<<63\n\n\ndef owners(snapshot,bindings,kernel_spans,kind):\n    ctx=snapshot[\'context\']\n    assert kind in [\'relro\',\'exec\']\n    generation=snapshot[\'image_generation\']\n    assert ctx[\'state\']==1 and generation in [0,1]\n    if kind==\'relro\':assert ctx[\'phase\']==8\n    elif generation==0:assert ctx[\'phase\']==32\n    else:assert 11<=ctx[\'phase\']<=15\n    assert snapshot[\'epoch\'][0]>0 and snapshot[\'epoch\'][1]==(10 if kind==\'relro\' else 59)\n    assert ctx[\'address\']==ctx[\'self\']==snapshot[\'gs_base\']\n    assert snapshot[\'cr0\']&0x80010001==0x80010001 and snapshot[\'cs\']&3==0\n    assert snapshot[\'cr4\']&0x20 and snapshot[\'cr4\']&((1<<7)|(1<<12)|(1<<17)|31592448)==0\n    assert snapshot[\'flags\']&0x600==0\n    allocator=snapshot[\'allocator\']\n    assert len(allocator)==16 and allocator[:2]==[1,1] and 0<allocator[3]<=262144\n    tokens=snapshot[\'root_tokens\']\n    roles=bindings[\'roles\']\n    assert len(tokens)*8==bindings[\'token_bytes\'] and len(tokens)%3==0\n    assert [(r[\'count\'],r[\'pins\']) for r in roles]==[(5,1),(1,1),(503,1),(2,2)]\n    assert len({r[\'slot\'] for r in roles})==len(snapshot[\'roles\'])==4\n    extents=[]\n    ids=[]\n    def allocation(row,token,count,pins):\n        issuer,identity,index=token\n        assert issuer==1 and 0<identity<allocator[2] and 0<=index<allocator[3]\n        record,cells=row[\'record\'],row[\'cells\']\n        assert len(record)==8 and record[:2]==token[:2]\n        assert record[3:5]==[count,1] and record[5]>0 and record[6:]==[pins,1]\n        assert 0<=record[2]<record[2]+count<=allocator[3]\n        assert len(cells)==count*3 and cells[0::3]==[identity]*count and cells[1::3]==[record[5]]*count\n        first=cells[2]\n        assert 0<first<first+count<=1<<18 and cells[2::3]==list(range(first,first+count))\n        span=[first*PAGE,(first+count)*PAGE]\n        assert all(span[1]<=a or b<=span[0] for a,b in kernel_spans+extents)\n        assert identity not in ids\n        extents.append(span)\n        ids.append(identity)\n        return span[0]\n    bases=[]\n    for row,role in zip(snapshot[\'roles\'],roles):\n        slot=role[\'slot\']\n        assert 0<=slot<len(tokens)//3\n        bases.append(allocation(row,tokens[slot*3:slot*3+3],role[\'count\'],role[\'pins\']))\n    mm=snapshot[\'state\']\n    assert len(mm)==4 and mm[0]==1 and 0<mm[2]<=519 and mm[1]==0x5f7000+mm[2]*PAGE\n    assert len(snapshot[\'heap_tokens\'])==6 and snapshot[\'heap_tokens\'][3:]==[0,0,0]\n    heap=allocation(snapshot[\'heap\'],snapshot[\'heap_tokens\'][:3],mm[2],1)\n    assert heap==mm[3] and snapshot[\'heap_tokens\'][1] not in tokens[1::3]\n    root,low,image,stack=bases\n    assert ctx[\'root\']==snapshot[\'cr3\']==root and ctx[\'low\']==low and ctx[\'stack_page\']==stack+PAGE\n    assert set(snapshot[\'tables\'])=={str(p) for p in [root,root+PAGE,root+2*PAGE,root+3*PAGE,root+4*PAGE,low]}\n    assert all(len(words)==512 and all(type(w) is int and 0<=w<1<<64 for w in words) for words in snapshot[\'tables\'].values())\n    # Bind the effective ancestor path for the complete changed image interval.\n    for table,index,next_table in [(root,0,root+PAGE),(root+PAGE,0,root+2*PAGE),(root+2*PAGE,2,low)]:\n        assert snapshot[\'tables\'][str(table)][index]&~0x60==next_table|7\n    return image\n\n\ndef published(record,bindings,kernel_spans):\n    before,after=record[\'before\'],record[\'stored\']\n    kind=record[\'kind\']\n    image=owners(before,bindings,kernel_spans,kind)\n    assert owners(after,bindings,kernel_spans,kind)==image\n    assert {k:v for k,v in before.items() if k not in [\'tables\',\'flags\']}=={k:v for k,v in after.items() if k not in [\'tables\',\'flags\']}\n    low=str(before[\'context\'][\'low\'])\n    count=8 if kind==\'relro\' else 18\n    selected=set(range(485,485+count))\n    for table,words in before[\'tables\'].items():\n        for index,(old,new) in enumerate(zip(words,after[\'tables\'][table])):\n            if table==low and index in selected:\n                page=index-485\n                physical=image+(BASE-0x400000)+page*PAGE\n                old_flags=7 if kind==\'relro\' or page>=8 else 5\n                new_flags=5 if kind==\'relro\' else 7\n                assert old&~0x60==physical|NX|old_flags,\'old image leaf differs\'\n                assert new&~0x60==physical|NX|new_flags,\'published image leaf differs\'\n            else:assert old&~0x60==new&~0x60 and old|new==new,\'unrelated translation changed\'\n    assert record[\'publication_barrier_observed\']\n    return count\n\n\ndef check(record,bindings,kernel_spans):\n    count=published(record,bindings,kernel_spans)\n    before,after=record[\'before\'],record[\'after\']\n    assert owners(after,bindings,kernel_spans,record[\'kind\'])==owners(before,bindings,kernel_spans,record[\'kind\'])\n    assert {k:v for k,v in after.items() if k!=\'flags\'}=={k:v for k,v in record[\'stored\'].items() if k!=\'flags\'}\n    assert record[\'thread_before\']==record[\'thread_stored\']==record[\'thread_after\']\n    assert len(record[\'invalidations\'])==count,\'incomplete image invalidation interval\'\n    for index,event in enumerate(record[\'invalidations\']):\n        assert event[\'index\']==count-index and event[\'address\']==BASE+index*PAGE,\'wrong image invalidation address/order\'\n        assert before[\'cr0\']==event[\'cr0\'] and before[\'cr3\']==event[\'cr3\'] and before[\'cr4\']==event[\'cr4\']\n        assert event[\'cpu\']+1==record[\'thread_before\'][1] and record[\'thread_before\'][0]==1\n        assert event[\'flags\']&0x600==0 and event[\'efer\']&0xd00==0xd00\n    assert record[\'final_barrier_observed\']==(record[\'kind\']==\'relro\')\n    return dict(passed=True,pages_invalidated=count,\n        scope=\'Selected actual image-owner boundaries, complete local leaf edits and ordered post-INVLPG states before reuse/readback. Exec has a publication barrier and no claimed extra final MFENCE. Not continuous mode, AP/DMA/asynchronous exclusion, arbitrary mapping editors or stable lifetime qualification\')\n',image_publication_model)

image_publication_active=None
image_publication_records=[]
image_publication_entries={}

def image_publication_capture():
    snapshot=owner_capture()
    snapshot['image_generation']=word(context+896)
    return snapshot

def image_publication_progress():
    with open(observation_path+'.image-progress.json','w') as handle:
        json.dump(dict(passed=False,full_guest_retirement_complete=False,
            records=image_publication_records),handle,indent=2)

class ImagePublication(Checked):
    def __init__(self,kind,site_kind,site):
        self.kind,self.site_kind=kind,site_kind
        super().__init__('*'+hex(site),internal=True)

    def observe(self):
        global image_publication_active
        profile=image_publication_profile['profiles'][self.kind]
        assert reg('rip')==profile['sites'][self.site_kind]
        assert translation_active is translation_request is None
        if self.site_kind=='entry':
            assert image_publication_active is None
            row=dict(kind=self.kind,before=image_publication_capture(),thread_before=list(gdb.selected_thread().ptid),
                invalidations=[],cancelled_post_states=[],publication_barrier_observed=False,
                final_barrier_observed=False,trace_before=translation_trace_positions())
            if self.kind=='relro':
                assert reg('rcx')==8 and reg('r8')==row['before']['context']['low']+485*8
            image_publication_active=row
            image_publication_model['owners'](row['before'],owner_profile['bindings'],owner_profile['kernel_spans'],self.kind)
            # RELRO's entry is also the store-loop head. Observe one complete
            # publication, then re-arm only after its final invalidation.
            self.enabled=False
        elif self.site_kind=='stored':
            row=image_publication_active
            assert row is not None and row['kind']==self.kind and not row['publication_barrier_observed']
            row.update(stored=image_publication_capture(),thread_stored=list(gdb.selected_thread().ptid),publication_barrier_observed=True)
            image_publication_model['published'](row,owner_profile['bindings'],owner_profile['kernel_spans'])
        else:
            assert self.site_kind=='finished'
            row=image_publication_active
            assert row is not None and row['kind']==self.kind and reg('rcx')==0
            row.update(after=image_publication_capture(),thread_after=list(gdb.selected_thread().ptid),
                final_barrier_observed=profile['final_barrier'],trace_slices=[])
            for path in sorted(Path(observation_path).parent.glob('cpu-*.log')):
                start=row['trace_before'].get(path.name,0)
                raw=path.read_bytes()[start:]
                events=translation_trace_model['parse'](raw,profile['sites']['invalidated'])
                row['trace_slices'].append(dict(file=path.name,start=start,size=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
                states,cancelled=translation_trace_model['completed'](events)
                row['invalidations'].extend(states)
                row['cancelled_post_states'].extend(cancelled)
            row['comparison']=image_publication_model['check'](row,owner_profile['bindings'],owner_profile['kernel_spans'])
            image_publication_records.append(row)
            image_publication_active=None
            image_publication_entries[self.kind].enabled=True
            image_publication_progress()
        return False

def install_image_publication_observation():
    if image_publication_profile is None:return
    assert owner_profile is not None and component['mode']=='metadata'
    for kind,profile in image_publication_profile['profiles'].items():
        for site_kind,site in profile['sites'].items():
            if site_kind!='invalidated':
                point=ImagePublication(kind,site_kind,site)
                if site_kind=='entry':image_publication_entries[kind]=point

def image_publication_observation_complete():
    if image_publication_profile is None:return
    assert image_publication_active is None
    assert len(image_publication_entries)==2 and all(point.enabled for point in image_publication_entries.values())
    assert {r['kind'] for r in image_publication_records}=={'relro','exec'}
    observed['image_publication_observation']=dict(passed=True,records=image_publication_records,
        profile=image_publication_profile,model_sha256=hashlib.sha256(image_publication_model_source.encode()).hexdigest(),
        trace_model_sha256=hashlib.sha256(translation_trace_model_source.encode()).hexdigest(),
        scope='Selected ordinary RELRO and exec image-leaf publication, actual owner boundaries and local invalidation order; not all mapping editors, continuous mode, AP/DMA/asynchronous exclusion or production qualification')

process_preparation_model={}
exec('"""Saved native preparation records; no authority, native producer or TLB proof."""\nPAGE = 4096\nSTART = 0x5F7000\n\n\ndef require(condition, reason):\n    if not condition:\n        raise ValueError(reason)\n\n\ndef allocation(snapshot, value, count, pins, spans, capture_bytes=True):\n    token, record, cells = value[\'token\'], value[\'record\'], value[\'cells\']\n    if not count:\n        require(token == [0, 0, 0] and record == cells == [] and value[\'bytes\'] == \'\', \'empty owner\')\n        return None\n    issuer, identity, index = token\n    allocator = snapshot[\'allocator\']\n    require(issuer == allocator[1] == 1 and 0 < identity < allocator[2] and 0 <= index < allocator[3], \'token\')\n    require(len(record) == 8 and record[:2] == token[:2] and record[3:5] == [count, 1], \'record\')\n    require(record[5] > 0 and record[6:] == [pins, 1], \'pin/lifetime\')\n    require(0 <= record[2] < record[2] + count <= allocator[3], \'cell domain\')\n    require(len(cells) == count * 3 and cells[0::3] == [identity] * count, \'cell ownership\')\n    require(cells[1::3] == [record[5]] * count, \'cell provenance\')\n    first = cells[2]\n    require(cells[2::3] == list(range(first, first + count)) and 0 <= first < first + count <= 1 << 18, \'physical extent\')\n    span = [first * PAGE, (first + count) * PAGE]\n    require(all(span[1] <= a or b <= span[0] for a, b in spans), \'reserved/static overlap\')\n    raw = bytes.fromhex(value[\'bytes\'])\n    require(len(raw) == (count * PAGE if capture_bytes else 0), \'whole bytes\')\n    return dict(span=span, identity=identity, token=token, record=record, cells=cells, bytes=raw)\n\n\ndef snapshot(value):\n    allocator = value[\'allocator\']\n    require(len(allocator) == 16 and allocator[:2] == [1, 1] and 0 < allocator[3] <= 262144, \'allocator\')\n    state = value[\'state\']\n    require(len(state) == 4 and state[0] == 1 and 0 <= state[2] <= 519, \'active state\')\n    require(START <= state[1] <= START + 519 * PAGE and\n            (state[1] - START + PAGE - 1) // PAGE == state[2], \'actual break geometry\')\n    require(value[\'tokens\'][3:] == [0, 0, 0] and value[\'tokens\'][:3] == value[\'active\'][\'token\'], \'active token bank\')\n    require(value[\'epoch\'][0] > 0 and value[\'epoch\'][1] == 12 and value[\'recovery\'][1:3] == [1, 5], \'entry identity/operation\')\n    require(value[\'recovery\'][5] == value[\'epoch\'][0], \'captured epoch\')\n    ctx = value[\'context\']\n    require(ctx[\'state\'] == 1 and ctx[\'address\'] == ctx[\'self\'] == value[\'gs_base\'], \'current context\')\n    require(ctx[\'root\'] == value[\'cr3\'] and ctx[\'heap\'] == state[3], \'actual root/heap\')\n    require(value[\'cs\'] & 3 == 0 and value[\'flags\'] & 0x600 == 0, \'privileged critical state\')\n    require(value[\'cr0\'] & 0x80010001 == 0x80010001 and value[\'cr4\'] & (1 << 5), \'paging/write protection\')\n    require(value[\'cr4\'] & ((1 << 7) | (1 << 12) | (1 << 17)) == 0, \'selected paging mode\')\n    spans = list(value[\'reserved_spans\'])\n    require(len(value[\'static_owners\']) == 4, \'static owner roles\')\n    static = []\n    for owned, (count, pins) in zip(value[\'static_owners\'], [(5, 1), (1, 1), (503, 1), (2, 2)]):\n        owner = allocation(value, owned, count, pins, spans, False)\n        static.append(owner)\n        spans.append(owner[\'span\'])\n    active = allocation(value, value[\'active\'], state[2], 1, spans)\n    require((active[\'span\'][0] if active else 0) == state[3], \'active backing\')\n    tables = value[\'tables\']\n    root, low = ctx[\'root\'], ctx[\'low\']\n    require(root == static[0][\'span\'][0] and low == static[1][\'span\'][0], \'table ownership\')\n    require(set(tables) == {str(a) for a in [root, root + PAGE, root + 2 * PAGE,\n                                           root + 3 * PAGE, root + 4 * PAGE, low]}, \'complete selected tables\')\n    require(all(len(words) == 512 for words in tables.values()), \'table words\')\n    expected = [(root, 0, root + PAGE), (root + PAGE, 0, root + 2 * PAGE),\n                (root + 2 * PAGE, 2, low), (root + 2 * PAGE, 3, root + 4 * PAGE)]\n    for table, index, target in expected:\n        require(tables[str(table)][index] & ~0x60 == target | 7, \'heap hierarchy\')\n    for i in range(519):\n        table, index = (low, 503 + i) if i < 9 else (root + 4 * PAGE, i - 9)\n        wanted = ((state[3] + i * PAGE) | (1 << 63) | 7) if i < state[2] else 0\n        require(tables[str(table)][index] & ~0x60 == wanted, \'unchanged active heap mapping\')\n    require(value[\'details\'] == [0] * 4, \'retired resolve facts\')\n    return active\n\n\ndef check(row):\n    before, ready, after = (row[k] for k in [\'before\', \'ready\', \'after\'])\n    original = snapshot(before)\n    for current in [ready, after]:\n        snapshot(current)\n        for key in [\'state\', \'tokens\', \'epoch\', \'recovery\', \'context\', \'context_bytes\', \'reserved_spans\',\n                    \'active\', \'static_owners\', \'cr0\', \'cr3\', \'cr4\', \'gs_base\', \'cs\']:\n            require(current[key] == before[key], \'changed active owner/context: \' + key)\n        for table, words in before[\'tables\'].items():\n            for old, new in zip(words, current[\'tables\'][table]):\n                require(old & ~0x60 == new & ~0x60 and old | new == new, \'unrelated descriptor change\')\n    require(before[\'prepared_state\'] == after[\'prepared_state\'] == [0] * 7, \'receipt retirement\')\n    require(before[\'prepared\'][\'token\'] == after[\'prepared\'][\'token\'] == [0] * 3, \'prepared token retirement\')\n    count = before[\'state\'][2]\n    require(ready[\'prepared_state\'][:3] == [1, before[\'state\'][1], count], \'prepared geometry\')\n    require(ready[\'prepared_state\'][4:] == [before[\'cr3\'], before[\'context\'][\'address\'], before[\'epoch\'][0]], \'prepared entry binding\')\n    spans = before[\'reserved_spans\'] + [[o[\'cells\'][2] * PAGE, (o[\'cells\'][2] + o[\'record\'][3]) * PAGE]\n                                        for o in before[\'static_owners\']]\n    candidate = allocation(ready, ready[\'prepared\'], count, 1, spans)\n    expected_issued = before[\'allocator\'][2] + int(count > 0)\n    for current in [ready, after]:\n        require(current[\'allocator\'] == before[\'allocator\'][:2] + [expected_issued] + before[\'allocator\'][3:], \'allocator issuance/state\')\n    require(ready[\'prepared_state\'][3] == (candidate[\'span\'][0] if candidate else 0), \'prepared physical alias\')\n    if count:\n        require(candidate[\'identity\'] == before[\'allocator\'][2] and candidate[\'identity\'] != original[\'identity\'], \'distinct issued extent\')\n        a, b = candidate[\'span\'], original[\'span\']\n        require(a[1] <= b[0] or b[1] <= a[0], \'parent/prepared alias\')\n        require(candidate[\'bytes\'] == original[\'bytes\'], \'complete copied heap\')\n        erased = row[\'erased\']\n        require(erased[\'base\'] == a[0] and erased[\'count\'] == count, \'erasure owner\')\n        require(erased[\'token\'] == candidate[\'token\'] and erased[\'record\'][:6] == candidate[\'record\'][:6], \'erasure identity\')\n        require(erased[\'record\'][6:] == [0, 1] and bytes.fromhex(erased[\'bytes\']) == bytes(count * PAGE), \'unpin/physical erasure before release\')\n        require(after[\'released_record\'] == [0] * 8, \'consumed registry owner\')\n        cells = after[\'released_cells\']\n        require(cells[0::3] == [0] * count and cells[1::3] == candidate[\'cells\'][1::3]\n                and cells[2::3] == candidate[\'cells\'][2::3], \'released cell ownership/provenance\')\n    else:\n        require(row[\'erased\'] is None and after[\'released_record\'] == after[\'released_cells\'] == [], \'empty preparation\')\n    return dict(passed=True, pages=count, copied_bytes=count * PAGE, released_bytes=count * PAGE,\n                scope=\'Observed preparation/cancellation within an actual brk gateway; no process switch, complete mapping-alias, asynchronous or production proof\')\n',process_preparation_model)

process_preparation_active=None
process_preparation_records=[]

def preparation_allocation(symbol,capture_bytes=True):
    token=words(address(symbol) if isinstance(symbol,str) else symbol,3)
    if token==[0,0,0]:return dict(token=token,record=[],cells=[],bytes='')
    allocator=words(address('topal_x86_frame_context_v1'),16)
    assert token[0]==1 and 0<token[1]<allocator[2] and token[2]<allocator[3]
    record=words(allocator[6]+token[2]*64,8)
    assert record[:2]==token[:2] and 0<record[3]<=519 and record[7]==1
    cells=words(allocator[4]+128+record[2]*24,record[3]*3)
    base=cells[2]*4096
    return dict(token=token,record=record,cells=cells,bytes=memory(base,record[3]*4096).hex() if capture_bytes else '')

def preparation_capture():
    root,low=word(context+24),word(context+112)
    allocator=words(address('topal_x86_frame_context_v1'),16)
    return dict(allocator=allocator,state=state(),tokens=words(address('topal_x86_frame_mm_tokens_v1'),6),
        epoch=words(address('topal_x86_frame_mm_epoch_v1'),2),
        recovery=words(address('topal_x86_frame_gateway_recovery_v1'),6),
        prepared_state=words(address('topal_x86_process_mm_prepared_state_v1'),7),
        active=preparation_allocation('topal_x86_frame_mm_tokens_v1'),
        prepared=preparation_allocation('topal_x86_process_mm_prepared_token_v1'),
        static_owners=[preparation_allocation(address('topal_x86_frame_root_tokens_v1')+role['slot']*24,False)
                       for role in process_preparation_profile['bindings']['roles']],
        context=dict(address=context,state=word(context),self=word(context+256),root=root,low=low,heap=word(context+120)),
        context_bytes=memory(context,1024).hex(),reserved_spans=process_preparation_profile['reserved_spans'],
        tables={str(a):words(a,512) for a in [root,root+4096,root+8192,root+12288,root+16384,low]},
        details=words(address('topal_x86_frame_details_v1'),4),
        cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'),gs_base=reg('gs_base'),cs=reg('cs'),flags=reg('eflags'))

def preparation_progress():
    with open(observation_path+'.preparation-progress.json','w') as handle:
        json.dump(dict(passed=False,records=process_preparation_records,active=process_preparation_active),handle)

class ProcessPreparation(Checked):
    def __init__(self,kind,symbol):
        self.kind=kind
        super().__init__("*'"+symbol+"'",internal=True)

    def observe(self):
        global process_preparation_active
        if self.kind=='before':
            assert process_preparation_active is None
            process_preparation_active=dict(before=preparation_capture(),ready=None,erased=None,after=None)
            process_preparation_model['snapshot'](process_preparation_active['before'])
        elif self.kind=='ready':
            assert process_preparation_active is not None and process_preparation_active['ready'] is None
            process_preparation_active['ready']=preparation_capture()
        elif self.kind=='erased':
            row=process_preparation_active
            assert row is not None and row['ready'] is not None and row['erased'] is None
            candidate=preparation_allocation('topal_x86_process_mm_prepared_token_v1')
            row['erased']=dict(base=reg('rdi'),count=reg('rsi'),token=candidate['token'],record=candidate['record'],bytes=candidate['bytes'])
        elif self.kind=='unavailable':
            # This cohort must retain an explicit failure rather than silently
            # claim unexecuted successful preparation. Resource misses are a
            # separate required native cohort, not modeled as success here.
            raise AssertionError('ordinary preparation unexpectedly unavailable')
        else:
            row=process_preparation_active
            assert self.kind=='after' and row is not None and row['ready'] is not None
            after=preparation_capture()
            candidate=row['ready']['prepared']
            if candidate['token']!=[0,0,0]:
                allocator=after['allocator']
                after['released_record']=words(allocator[6]+candidate['token'][2]*64,8)
                r=candidate['record']
                after['released_cells']=words(allocator[4]+128+r[2]*24,r[3]*3)
            else:
                after['released_record']=after['released_cells']=[]
            row['after']=after
            row['comparison']=process_preparation_model['check'](row)
            process_preparation_records.append(row)
            process_preparation_active=None
        preparation_progress()
        return False

def install_process_preparation_observation():
    if process_preparation_profile is None:return
    for kind,symbol in [('before','pm.prepare'),('ready','pm.at_prepared'),('erased','pm.at_erased'),
                        ('after','pm.at_released'),('unavailable','pm.at_unavailable')]:
        ProcessPreparation(kind,symbol)

def process_preparation_observation_complete():
    if process_preparation_profile is None:return
    assert process_preparation_active is None and process_preparation_records
    assert any(row['comparison']['pages']>34 for row in process_preparation_records)
    assert any(row['comparison']['pages']==0 for row in process_preparation_records)
    assert words(address('topal_x86_process_mm_prepared_token_v1'),3)==[0]*3
    assert words(address('topal_x86_process_mm_prepared_state_v1'),7)==[0]*7
    observed['process_preparation_observation']=dict(passed=True,records=process_preparation_records,
        model_sha256=hashlib.sha256(process_preparation_model_source.encode()).hexdigest(),
        scope='Real whole-heap prepare/pin/copy/cancel/erase/release in ordinary brk invocations, no fork/switch or production qualification')


process_regression_namespace=None
process_regression_current=None

def install_process_regression_observation():
    global process_regression_namespace
    if process_regression_profile is None:return
    profile=process_regression_profile
    assert profile['process_memory'] is True
    ns=dict(component=component,token_bytes=token_bytes,kernel_spans=profile['kernel_spans'],
            observation_path=observation_path.rsplit('/',1)[0]+'/process-mm-observations.json')
    exec(process_regression_boundary_program,ns)
    process_regression_namespace=ns
    def complete_save():
        import os
        evidence=ns['observed']
        evidence.update(pending=ns['pending'],active_case=ns['case'],refusal_pending=ns['refusal_attempt'])
        path=ns['observation_path']
        with open(path+'.tmp','w') as stream:stream.write(json.dumps(evidence,separators=(',',':')))
        os.replace(path+'.tmp',path)
    def checkpoint():
        # Keep complete checkpoints and every failure, without serializing the
        # entire growing history after each query in a long interface fixture.
        if ns['observed'].get('failure') or len(ns['observed']['events'])%64==0:complete_save()
    ns['save']=checkpoint
    ns['complete_save']=complete_save
    class Returned(ns['Gateway']):
        def observe(self):
            result=super().observe()
            self.enabled=False
            return result
    returned=Returned('topal_x86_frame_gateway_return_reclaimed_v1',False)
    returned.enabled=False
    class Entry(ns['Gateway']):
        def observe(self):
            result=super().observe()
            # Non-MM operations have no pending MM observation. Their common
            # gateway return need not stop the guest a second time. Every MM
            # entry still enables the exact original return/ABI observation.
            returned.enabled=ns['pending'] is not None
            return result
    Entry('topal_x86_frame_gateway_v1',True)

def process_regression_case_entered():
    global process_regression_current
    if process_regression_namespace is None:return
    ns=process_regression_namespace
    assert process_regression_current is None and ns['pending'] is None
    value=ns['capture']();ns['model']['snapshot'](value)
    assert value['cs']&3==3 and value['ids'][0]==1 and value['ids'][3:6]==[0]*3
    process_regression_current=dict(before=value)

def process_regression_case_returned():
    global process_regression_current
    if process_regression_namespace is None:return
    ns=process_regression_namespace
    assert process_regression_current is not None and ns['pending'] is None
    value=ns['capture']();ns['model']['snapshot'](value)
    before=process_regression_current['before']
    assert value['cs']&3==3 and value['ids']==before['ids']
    assert value['state'][:3]==before['state'][:3] and value['active']['bytes']==before['active']['bytes']
    process_regression_current['after']=value
    ns['observed']['cases'].append(process_regression_current)
    process_regression_current=None

def process_regression_observation_complete():
    if process_regression_namespace is None:return
    ns=process_regression_namespace
    assert process_regression_current is None and ns['pending'] is None
    assert 'failure' not in ns['observed'] and len(ns['observed']['cases'])==4
    assert words(address('topal_x86_frame_mm_tokens_v1'),6)==[0]*6
    assert words(address('topal_x86_frame_mm_state_v1'),4)==[0]*4
    final={}
    for suffix,count in [('ids',7),('inactive_token',3),('inactive_state',4),('prepared_token',3),
                         ('prepared_state',7),('prepared_owner',3),('transition',3)]:
        actual=words(address('topal_x86_process_mm_'+suffix+'_v1'),count)
        assert actual==[0]*count
        final[suffix]=actual
    ns['observed'].update(passed=True,final=final,mode=component['mode'])
    ns['complete_save']()
    observed['process_memory_regression']=dict(passed=True,mode=component['mode'],
        cases=len(ns['observed']['cases']),boundaries=len(ns['observed']['events']),
        kernel_sha256=process_regression_profile['kernel_sha256'])


class Complete(Checked):
    def observe(self):
        assert current is startup_current is pending is bridge_current is None and observed['executions']
        numbers = [row['number'] for row in observed['startup_executions']]
        if component.get('mode') in ['exec','signals','poll','pipes','storage','serial','stat','metadata']:
            assert len(observed['executions']) == 4
            assert all(not observed[key] for key in [
                'startup_executions','file_executions','shell_executions','command_executions'])
        else:
            assert numbers and len(numbers) % 5 == 0
        assert numbers == [302,318,318,157,262]*(len(numbers)//5)
        assert [row['number'] for row in observed['file_executions']] == ([] if component.get('mode') in ['exec','signals','poll','pipes','storage','serial','stat','metadata'] else [
            5,257,262,257,5,0,257,5,217,217,262,257,5,217,217,262,262,262,257,257]
        )
        assert len(observed['command_executions']) == (0 if component.get('mode') in ['exec','signals','poll','pipes','storage','serial','stat','metadata'] else 5)
        assert len(observed['shell_executions']) == (0 if component.get('mode') in ['exec','signals','poll','pipes','storage','serial','stat','metadata'] else 38)
        assert len(observed['poll_executions']) == (4 if component.get('mode') == 'poll' else 0)
        assert len(observed['bridge_returns']) == len(numbers)+len(observed['file_executions'])+len(observed['shell_executions'])+len(observed['command_executions'])+len(observed['poll_executions'])
        assert state() == [0,0,0,0]
        assert memory(address('topal_x86_frame_mm_tokens_v1'), 48) == bytes(48)
        assert word(context+904) == 0 and memory(context+152,16) == bytes(16)
        assert memory(context+416,8) == bytes(8)
        for snapshot in {row['snapshot'] for row in observed['executions']}:
            assert memory(snapshot+0x9e00,512) == bytes(512)
        extent_coverage_complete()
        owner_observation_complete()
        interval_observation_complete()
        translation_observation_complete()
        image_publication_observation_complete()
        process_preparation_observation_complete()
        process_regression_observation_complete()
        observed['passed'] = True
        with open(observation_path, 'w') as handle:
            json.dump(observed, handle, indent=2)
        return True

class InvariantHalt(Checked):
    def observe(self):
        observed['invariant_failure'] = dict(phase=memory(context+104,1)[0],
            heap=state(),current=current,pending=pending)
        with open(observation_path, 'w') as handle:
            json.dump(observed, handle, indent=2)
        print('SOURCE_USER_INVARIANT_FAILURE', observed['invariant_failure'], flush=True)
        return True

try:
    install_extent_coverage()
    install_serial_observation()
    install_storage_input_observation()
    install_metadata_observation()
    install_owner_observation()
    install_interval_observation()
    install_translation_observation()
    install_image_publication_observation()
    install_process_preparation_observation()
    install_process_regression_observation()
    SourceEntered('*'+hex(component['entry']), internal=True)
    StartupEntered('*'+hex(component['startup']), internal=True)
    BridgeEntered('*'+hex(component['startup_call']), internal=True)
    SyscallEntered('*'+hex(component['syscall']), 3)
    SyscallEntered('*'+hex(component['syscall4']), 4)
    InvariantHalt('*'+hex(native_sites['halt']), internal=True)
    Complete('*topal_x86_systems_fatal', internal=True)
    gdb.execute('continue')
    assert observed['passed']
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:
    traceback.print_exc()
    gdb.execute('quit 1')

end
