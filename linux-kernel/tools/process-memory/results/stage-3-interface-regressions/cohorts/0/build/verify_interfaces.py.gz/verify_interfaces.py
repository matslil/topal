import json
from pathlib import Path
import subprocess
import sys

root=Path.cwd()
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from readback_interfaces import MODES,readback
from readback_process import digest
cache=root/'linux-kernel/.cache/x86_64'
builds=(sorted(cache.glob('process-mm-interface-regression-2458890-*'))[:6]
        + sorted(cache.glob('process-mm-interface-regression-2462682-*')))
assert len(builds)==9
opt=Path('/home/mats/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/opt')
for build,mode in zip(builds,MODES):
    component=json.loads((build/'source-component.json').read_text())
    assert component['mode']==mode
    verification={}
    for role in ['source','runtime','owner','controller','target','dispatch','extent']:
        command=[str(opt),'-passes=verify','-disable-output',str(build/(role+'.ll'))]
        result=subprocess.run(['rtk','proxy']+command,capture_output=True,text=True)
        (build/(role+'-explicit-verify.command.json')).write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
        (build/(role+'-explicit-verify.stdout.log')).write_text(result.stdout)
        (build/(role+'-explicit-verify.stderr.log')).write_text(result.stderr)
        if result.returncode:raise RuntimeError(result.stderr)
        verification[role]=dict(passed=True,sha256=digest((build/(role+'.ll')).read_bytes())['sha256'])
    (build/'llvm-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    native=build/'source-user-extents'
    user=json.loads((native/'observations.json').read_text())
    mm=json.loads((native/'process-mm-observations.json').read_text())
    report=readback(user,mm,digest((build/'kernel.elf').read_bytes())['sha256'])
    (build/'interface-readback.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(mode,report['boundaries'],report['retired_extents'],report['erased_released_bytes'],flush=True)
