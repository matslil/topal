"""Read-only diagnostic of the failed ordinary syscall entry assertion."""
from pathlib import Path
import runpy
import sys

root=Path.cwd()
lab=root/'linux-kernel/labs/qemu/x86_64'
sys.path.insert(0,str(lab))
import frame_root_inspect as harness
original=harness.main
def diagnose(**kwargs):
    needle="assert (current or startup_current) and pending is None and reg('cs') & 3 == 3"
    replacement=needle+", dict(current=current,startup=startup_current,pending=pending,registers={name:reg(name) for name in ['rip','rsp','cs','rax','rdi','rsi','rdx','rcx','r8']},stack=words(reg('rsp'),8),entry_bytes=memory(component['entry'],32).hex())"
    assert harness.GDB_PROGRAM.count(needle)==1
    harness.GDB_PROGRAM=harness.GDB_PROGRAM.replace(needle,replacement)
    kwargs['work_name']='source-entry-diagnostic'
    return original(**kwargs)
harness.main=diagnose
runpy.run_path(str(lab/'user_extent_source_inspect.py'),run_name='__main__')
