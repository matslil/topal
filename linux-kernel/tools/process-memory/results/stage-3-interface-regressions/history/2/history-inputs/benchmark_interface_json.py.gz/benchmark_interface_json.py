import json
from pathlib import Path
import sys
import time

class Sink:
    def __init__(self):self.characters=0;self.calls=0
    def write(self,text):self.characters+=len(text);self.calls+=1

for name in sys.argv[1:]:
    path=Path(name)
    try:value=json.loads(path.read_text())
    except json.JSONDecodeError as error:
        print(json.dumps(dict(path=str(path),incomplete=True,error=str(error))),flush=True)
        continue
    rows=[]
    for compact in [False,True]:
        start=time.monotonic();sink=Sink()
        if compact:
            encoded=json.dumps(value,separators=(',',':'))
            sink.write(encoded)
        else:json.dump(value,sink)
        elapsed=time.monotonic()-start
        row=dict(compact=compact,seconds=elapsed,characters=sink.characters,write_calls=sink.calls)
        if compact:
            row['decoded_equal']=json.loads(encoded)==value
            assert row['decoded_equal']
        rows.append(row)
    result=dict(path=str(path),events=len(value['events']),rows=rows,
        scope='Host serialization of saved partial observations, with identical decoded data; no VM execution')
    output=path.parent/'serialization-benchmark.json'
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    break
else:raise SystemExit('No complete saved checkpoint available')
