import hashlib
import json
from pathlib import Path
import subprocess

build=Path(__file__).resolve().parent
opt=json.loads((build/'root-target-verify.command.json').read_text())['argv'][0]
results={}
for role in ['source','runtime','owner','controller','target','dispatch','extent']:
    path=build/(role+'.ll')
    command=[opt,'-passes=verify','-disable-output',str(path)]
    result=subprocess.run(command,capture_output=True,text=True)
    (build/(role+'-explicit-verify.command.json')).write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
    if result.returncode:
        raise RuntimeError(result.stderr)
    results[role]=dict(passed=True,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(build/'llvm-verification.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print('Verified all seven generated LLVM modules')
