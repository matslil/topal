import json
from pathlib import Path
import sys
import time

group = Path('/sys/fs/cgroup') / sys.argv[1].lstrip('/')
output = Path(__file__).with_name('resource-observation.json')
latest = None
for _ in range(660):
    try:
        latest = dict(group=str(group), memory_max_bytes=int((group/'memory.max').read_text()),
            swap_max_bytes=int((group/'memory.swap.max').read_text()),
            observed_peak_bytes=int((group/'memory.peak').read_text()),
            events={k:int(v) for k,v in (r.split() for r in (group/'memory.events').read_text().splitlines())},
            sampled_at=time.time(), group_retired=False)
    except FileNotFoundError:
        if latest is None:
            raise
        latest['group_retired'] = True
        latest['retirement_observed_at'] = time.time()
        output.write_text(json.dumps(latest,indent=2)+'\n')
        break
    output.write_text(json.dumps(latest,indent=2)+'\n')
    time.sleep(1)
