; ModuleID = '/tmp/tk282-frame-policy-eced17d9/tail-reconstruction-1852142-1794155920316815371/.topal-systems-artifact-1852142-23/work/process-identity-library.bc'
source_filename = "structured-process-identity.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.IntStorage = type { i64, i64, [0 x i32] }

@llvm.used = appending global [1 x ptr] [ptr @topal.pid.memset], section "llvm.metadata"
@topal.pid.runtime.int.zero = private constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@.topal.int.0 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.1 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.2 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.3 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.4 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2147483647] }, align 8
@.topal.int.5 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2147483647] }, align 8
@.topal.int.6 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8

; Function Attrs: noimplicitfloat noinline noredzone nounwind optnone
define internal ptr @topal.pid.memset(ptr %destination, i32 %value, i64 %length) #0 {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill

fill:                                             ; preds = %fill, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill

complete:                                         ; preds = %fill, %entry
  ret ptr %destination
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.pid.runtime.int.allocate(i64 %length, i64 %negative) #1 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.pid.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.pid.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.pid.runtime.int.from.u64(i64 %source) #1 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.pid.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.pid.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.pid.runtime.int.limb.or.zero(ptr %value, i64 %index) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero

load:                                             ; preds = %entry
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended

zero:                                             ; preds = %entry
  ret i64 0
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.pid.runtime.int.normalize(ptr %value) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim

trim:                                             ; preds = %leading.zero, %entry
  %candidate = phi i64 [ %length, %entry ], [ %next, %leading.zero ]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done

leading.zero:                                     ; preds = %trim
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim

zero:                                             ; preds = %leading.zero, %entry
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value

done:                                             ; preds = %trim
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.pid.runtime.int.compare.absolute(ptr %left, ptr %right) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer

check.longer:                                     ; preds = %entry
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty

check.empty:                                      ; preds = %check.longer
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs

limbs:                                            ; preds = %limbs.equal, %check.empty
  %position = phi i64 [ %left.length, %check.empty ], [ %index, %limbs.equal ]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater

check.limb.greater:                               ; preds = %limbs
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal

limbs.equal:                                      ; preds = %check.limb.greater
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal

less:                                             ; preds = %limbs, %entry
  ret i32 -1

equal:                                            ; preds = %limbs.equal, %check.empty
  ret i32 0

greater:                                          ; preds = %check.limb.greater, %check.longer
  ret i32 1
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.pid.runtime.int.compare(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity

left.positive:                                    ; preds = %entry
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result

check.left.negative.infinity:                     ; preds = %entry
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity

left.negative:                                    ; preds = %check.left.negative.infinity
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result

check.right.positive.infinity:                    ; preds = %check.left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity

check.right.negative.infinity:                    ; preds = %check.right.positive.infinity
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite

less:                                             ; preds = %check.right.positive.infinity
  ret i32 -1

greater:                                          ; preds = %check.right.negative.infinity
  ret i32 1

finite:                                           ; preds = %check.right.negative.infinity
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute

signed.result:                                    ; preds = %finite
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result

absolute:                                         ; preds = %finite
  %magnitude = call i32 @topal.pid.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.pid.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.pid.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %left.limb = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish

finish:                                           ; preds = %loop, %entry
  %final.carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry

store.carry:                                      ; preds = %finish
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result

without.carry:                                    ; preds = %finish
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.pid.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.pid.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.pid.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %borrow = phi i64 [ 0, %entry ], [ %next.borrow, %loop ]
  %left = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  %normalized = call ptr @topal.pid.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.pid.runtime.int.add(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity

validate.left.infinity:                           ; preds = %entry
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity

indeterminate.infinity:                           ; preds = %validate.left.infinity
  call void @topal.pid.platform.exit(i64 70)
  unreachable

return.left.infinity:                             ; preds = %validate.left.infinity
  ret ptr %left

check.right.infinity:                             ; preds = %entry
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite

return.right.infinity:                            ; preds = %check.right.infinity
  ret ptr %right

finite:                                           ; preds = %check.right.infinity
  %left.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right

return.right:                                     ; preds = %finite
  ret ptr %right

check.right:                                      ; preds = %finite
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero

return.left:                                      ; preds = %check.right
  ret ptr %left

nonzero:                                          ; preds = %check.right
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference

sum:                                              ; preds = %nonzero
  %sum.value = call ptr @topal.pid.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value

difference:                                       ; preds = %nonzero
  %ordering = call i32 @topal.pid.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger

zero:                                             ; preds = %difference
  ret ptr @topal.pid.runtime.int.zero

select.larger:                                    ; preds = %difference
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference

left.difference:                                  ; preds = %select.larger
  %left.value = call ptr @topal.pid.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value

right.difference:                                 ; preds = %select.larger
  %right.value = call ptr @topal.pid.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.pid.runtime.int.is.zero(ptr %value) #1 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

declare ptr @topal_kernel_numeric_allocate_v1(i64)

; Function Attrs: noreturn
declare void @topal_kernel_numeric_abort_v1() #2

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.pid.platform.allocate(i64 %length) #1 {
entry:
  %pointer = call ptr @topal_kernel_numeric_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.pid.platform.exit(i64 %status) #3 {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2eselected.0(ptr %arg0) #1 !dbg !6 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !17, !DIExpression(), !18)
    #dbg_value(ptr @.topal.int.0, !19, !DIExpression(), !20)
  %v1 = call i32 @topal.pid.runtime.int.compare(ptr %arg0, ptr @.topal.int.1), !dbg !21
  %v2 = icmp eq i32 %v1, 0, !dbg !21
  %v3 = icmp eq i1 %v2, true, !dbg !21
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !21

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !22

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !23

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v4 = phi ptr [ @.topal.int.0, %decision.true.0 ], [ %arg0, %decision.false.1 ], !dbg !21
  ret ptr %v4, !dbg !21
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2efollowing.1(ptr %arg0) #1 !dbg !24 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !25, !DIExpression(), !26)
    #dbg_value(ptr @.topal.int.2, !27, !DIExpression(), !28)
    #dbg_value(ptr @.topal.int.3, !29, !DIExpression(), !30)
  %v1 = call i32 @topal.pid.runtime.int.compare(ptr %arg0, ptr @.topal.int.4), !dbg !31
  %v2 = icmp eq i32 %v1, 0, !dbg !31
  %v3 = icmp eq i1 %v2, true, !dbg !31
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !31

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !32

decision.false.1:                                 ; preds = %entry
  %v4 = call ptr @topal.pid.runtime.int.add(ptr %arg0, ptr @.topal.int.2), !dbg !33
  br label %decision.merge.2, !dbg !33

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi ptr [ @.topal.int.3, %decision.true.0 ], [ %v4, %decision.false.1 ], !dbg !31
  ret ptr %v5, !dbg !31
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.identity.topal.fn.support_2eidentity_2dhistory_2eretain_2dwrap.2(i1 %arg0, ptr %arg1) #1 !dbg !34 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !39, !DIExpression(), !40)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !41, !DIExpression(), !42)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !43

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !44

decision.false.1:                                 ; preds = %entry
  %v2 = call i32 @topal.pid.runtime.int.compare(ptr %arg1, ptr @.topal.int.5), !dbg !45
  %v3 = icmp eq i32 %v2, 0, !dbg !45
  %v4 = icmp eq i1 %v3, true, !dbg !45
  br label %decision.merge.2, !dbg !45

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ true, %decision.true.0 ], [ %v4, %decision.false.1 ], !dbg !43
  ret i1 %v5, !dbg !43
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc { ptr, i1, i32, i32 } @topal.identity.topal.fn.support_2eidentity_2dhistory_2efollowing.3({ ptr, i1, i32, i32 } %arg0, ptr %arg1) #1 !dbg !46 {
entry:
  %v0 = extractvalue { ptr, i1, i32, i32 } %arg0, 0, !dbg !53
  %v1 = extractvalue { ptr, i1, i32, i32 } %arg0, 1, !dbg !53
  %v2 = extractvalue { ptr, i1, i32, i32 } %arg0, 2, !dbg !53
  %v3 = extractvalue { ptr, i1, i32, i32 } %arg0, 3, !dbg !53
  %v4 = alloca { ptr, i1, i32, i32 }, align 8
  store { ptr, i1, i32, i32 } %arg0, ptr %v4, align 8
    #dbg_declare(ptr %v4, !54, !DIExpression(), !53)
  %v5 = alloca ptr, align 8
  store ptr %arg1, ptr %v5, align 8
    #dbg_declare(ptr %v5, !55, !DIExpression(), !56)
    #dbg_value(ptr @.topal.int.6, !57, !DIExpression(), !58)
  %v6 = call ptr @topal.pid.runtime.int.add(ptr %v0, ptr @.topal.int.6), !dbg !59
    #dbg_value(ptr %v6, !60, !DIExpression(), !61)
    #dbg_value(i1 %v1, !62, !DIExpression(), !63)
  %v7 = call fastcc i1 @topal.identity.topal.fn.support_2eidentity_2dhistory_2eretain_2dwrap.2(i1 %v1, ptr %arg1), !dbg !64
    #dbg_value(i1 %v7, !65, !DIExpression(), !66)
  %v8 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v6, 0, !dbg !67
  %v9 = insertvalue { ptr, i1, i32, i32 } %v8, i1 %v7, 1, !dbg !67
  %v10 = insertvalue { ptr, i1, i32, i32 } %v9, i32 0, 2, !dbg !67
  %v11 = insertvalue { ptr, i1, i32, i32 } %v10, i32 1, 3, !dbg !67
  ret { ptr, i1, i32, i32 } %v11, !dbg !67
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } @topal.identity.topal.fn.process_2didentity.4({ { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0) #1 !dbg !68 {
entry:
  %v0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 0, !dbg !79
  %v1 = extractvalue { ptr, i1, i32, i32 } %v0, 0, !dbg !79
  %v2 = extractvalue { ptr, i1, i32, i32 } %v0, 1, !dbg !79
  %v3 = extractvalue { ptr, i1, i32, i32 } %v0, 2, !dbg !79
  %v4 = extractvalue { ptr, i1, i32, i32 } %v0, 3, !dbg !79
  %v5 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 1, !dbg !79
  %v6 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 2, !dbg !79
  %v7 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 3, !dbg !79
  %v8 = alloca { { ptr, i1, i32, i32 }, ptr, i32, i32 }, align 8
  store { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, ptr %v8, align 8
    #dbg_declare(ptr %v8, !80, !DIExpression(), !79)
  %v9 = call fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2eselected.0(ptr %v5), !dbg !81
    #dbg_value(ptr %v9, !82, !DIExpression(), !83)
  %v10 = call fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2efollowing.1(ptr %v9), !dbg !84
    #dbg_value(ptr %v10, !85, !DIExpression(), !86)
  %v11 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v1, 0, !dbg !87
  %v12 = insertvalue { ptr, i1, i32, i32 } %v11, i1 %v2, 1, !dbg !87
  %v13 = insertvalue { ptr, i1, i32, i32 } %v12, i32 %v3, 2, !dbg !87
  %v14 = insertvalue { ptr, i1, i32, i32 } %v13, i32 %v4, 3, !dbg !87
  %v15 = call fastcc { ptr, i1, i32, i32 } @topal.identity.topal.fn.support_2eidentity_2dhistory_2efollowing.3({ ptr, i1, i32, i32 } %v14, ptr %v9), !dbg !87
  %v16 = extractvalue { ptr, i1, i32, i32 } %v15, 0, !dbg !87
  %v17 = extractvalue { ptr, i1, i32, i32 } %v15, 1, !dbg !87
  %v18 = extractvalue { ptr, i1, i32, i32 } %v15, 2, !dbg !87
  %v19 = extractvalue { ptr, i1, i32, i32 } %v15, 3, !dbg !87
  %v20 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v16, 0, !dbg !88
  %v21 = insertvalue { ptr, i1, i32, i32 } %v20, i1 %v17, 1, !dbg !88
  %v22 = insertvalue { ptr, i1, i32, i32 } %v21, i32 %v18, 2, !dbg !88
  %v23 = insertvalue { ptr, i1, i32, i32 } %v22, i32 %v19, 3, !dbg !88
  %v24 = alloca { ptr, i1, i32, i32 }, align 8, !dbg !88
  store { ptr, i1, i32, i32 } %v23, ptr %v24, align 8, !dbg !88
    #dbg_declare(ptr %v24, !89, !DIExpression(), !88)
  %v25 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } poison, ptr %v9, 0, !dbg !90
  %v26 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v16, 0, !dbg !90
  %v27 = insertvalue { ptr, i1, i32, i32 } %v26, i1 %v17, 1, !dbg !90
  %v28 = insertvalue { ptr, i1, i32, i32 } %v27, i32 %v18, 2, !dbg !90
  %v29 = insertvalue { ptr, i1, i32, i32 } %v28, i32 %v19, 3, !dbg !90
  %v30 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } poison, { ptr, i1, i32, i32 } %v29, 0, !dbg !90
  %v31 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v30, ptr %v10, 1, !dbg !90
  %v32 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v31, i32 1, 2, !dbg !90
  %v33 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v32, i32 0, 3, !dbg !90
  %v34 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v25, { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v33, 1, !dbg !90
  %v35 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v34, i32 0, 2, !dbg !90
  %v36 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v35, i32 1, 3, !dbg !90
  ret { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v36, !dbg !90
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define { i64, i64 } @topal_kernel_structured_process_identity_policy_v1(i64 %cursor, ptr %store, i64 %owner, i64 %code) #1 {
entry:
  %cursor.zero = icmp eq i64 %cursor, 0
  %cursor.minimum = icmp uge i64 %cursor, 2
  %cursor.maximum = icmp ule i64 %cursor, 2147483647
  %cursor.range = and i1 %cursor.minimum, %cursor.maximum
  %cursor.valid = or i1 %cursor.zero, %cursor.range
  %store.address = ptrtoint ptr %store to i64
  %store.end = add i64 %store.address, 4096
  %store.nonnull = icmp ne ptr %store, null
  %store.nonwrapping = icmp ugt i64 %store.end, %store.address
  %store.alignment = and i64 %store.address, 4095
  %store.aligned = icmp eq i64 %store.alignment, 0
  %owner.nonzero = icmp ne i64 %owner, 0
  %code.nonzero = icmp ne i64 %code, 0
  %entry.a = and i1 %cursor.valid, %store.nonnull
  %entry.b = and i1 %store.nonwrapping, %store.aligned
  %entry.c = and i1 %owner.nonzero, %code.nonzero
  %entry.d = and i1 %entry.a, %entry.b
  %entry.valid = and i1 %entry.d, %entry.c
  br i1 %entry.valid, label %header, label %invalid

header:                                           ; preds = %entry
  %stored.owner.address = getelementptr i8, ptr %store, i64 0
  %stored.owner = load i64, ptr %stored.owner.address, align 8
  %stored.code.address = getelementptr i8, ptr %store, i64 8
  %stored.code = load i64, ptr %stored.code.address, align 8
  %stored.initialized.address = getelementptr i8, ptr %store, i64 16
  %stored.initialized = load i64, ptr %stored.initialized.address, align 8
  %stored.bank.address = getelementptr i8, ptr %store, i64 24
  %stored.bank = load i64, ptr %stored.bank.address, align 8
  %stored.epoch.address = getelementptr i8, ptr %store, i64 32
  %stored.epoch = load i64, ptr %stored.epoch.address, align 8
  %stored.prepared.address = getelementptr i8, ptr %store, i64 40
  %stored.prepared = load i64, ptr %stored.prepared.address, align 8
  %stored.prepared_bank.address = getelementptr i8, ptr %store, i64 48
  %stored.prepared_bank = load i64, ptr %stored.prepared_bank.address, align 8
  %stored.prepared_next.address = getelementptr i8, ptr %store, i64 56
  %stored.prepared_next = load i64, ptr %stored.prepared_next.address, align 8
  %owner.matches = icmp eq i64 %stored.owner, %owner
  %code.matches = icmp eq i64 %stored.code, %code
  %initialized.valid = icmp ule i64 %stored.initialized, 1
  %bank.valid = icmp ule i64 %stored.bank, 1
  %epoch.available = icmp ult i64 %stored.epoch, -1
  %prepared.clear = icmp eq i64 %stored.prepared, 0
  %prepared.bank.clear = icmp eq i64 %stored.prepared_bank, 0
  %prepared.next.clear = icmp eq i64 %stored.prepared_next, 0
  %header.valid.0 = and i1 %owner.matches, %code.matches
  %header.valid.1 = and i1 %header.valid.0, %initialized.valid
  %header.valid.2 = and i1 %header.valid.1, %bank.valid
  %header.valid.3 = and i1 %header.valid.2, %epoch.available
  %header.valid.4 = and i1 %header.valid.3, %prepared.clear
  %header.valid.5 = and i1 %header.valid.4, %prepared.bank.clear
  %header.valid.6 = and i1 %header.valid.5, %prepared.next.clear
  br i1 %header.valid.6, label %banks, label %invalid

banks:                                            ; preds = %header
  %bank.zero = icmp eq i64 %stored.bank, 0
  %bank.first = getelementptr i8, ptr %store, i64 64
  %bank.second = getelementptr i8, ptr %store, i64 2080
  %published.bank = select i1 %bank.zero, ptr %bank.first, ptr %bank.second
  %prepared.bank = select i1 %bank.zero, ptr %bank.second, ptr %bank.first
  %prepared.index = xor i64 %stored.bank, 1
  br label %inactive.scan

inactive.scan:                                    ; preds = %inactive.advance, %banks
  %inactive.index = phi i64 [ 0, %banks ], [ %inactive.next, %inactive.advance ]
  %inactive.scaled = mul i64 %inactive.index, 8
  %inactive.offset = add i64 %inactive.scaled, 0
  %inactive.address = getelementptr i8, ptr %prepared.bank, i64 %inactive.offset
  %inactive.word = load i64, ptr %inactive.address, align 8
  %inactive.zero = icmp eq i64 %inactive.word, 0
  br i1 %inactive.zero, label %inactive.advance, label %invalid

inactive.advance:                                 ; preds = %inactive.scan
  %inactive.next = add i64 %inactive.index, 1
  %inactive.more = icmp ult i64 %inactive.next, 252
  br i1 %inactive.more, label %inactive.scan, label %inactive.clean

inactive.clean:                                   ; preds = %inactive.advance
  %uninitialized = icmp eq i64 %stored.initialized, 0
  br i1 %uninitialized, label %initial.guard, label %published.guard

initial.guard:                                    ; preds = %inactive.clean
  %epoch.zero = icmp eq i64 %stored.epoch, 0
  %initial.a = and i1 %epoch.zero, %bank.zero
  %initial.valid = and i1 %initial.a, %cursor.zero
  br i1 %initial.valid, label %initial.bank, label %invalid

initial.bank:                                     ; preds = %initial.guard
  br label %initial.scan

initial.scan:                                     ; preds = %initial.advance, %initial.bank
  %initial.index = phi i64 [ 0, %initial.bank ], [ %initial.next, %initial.advance ]
  %initial.scaled = mul i64 %initial.index, 8
  %initial.offset = add i64 %initial.scaled, 0
  %initial.address = getelementptr i8, ptr %published.bank, i64 %initial.offset
  %initial.word = load i64, ptr %initial.address, align 8
  %initial.zero = icmp eq i64 %initial.word, 0
  br i1 %initial.zero, label %initial.advance, label %invalid

initial.advance:                                  ; preds = %initial.scan
  %initial.next = add i64 %initial.index, 1
  %initial.more = icmp ult i64 %initial.next, 252
  br i1 %initial.more, label %initial.scan, label %initial.view

initial.view:                                     ; preds = %initial.advance
  %initial.number.0 = call ptr @topal.pid.runtime.int.from.u64(i64 0)
  %initial.number.1 = call ptr @topal.pid.runtime.int.from.u64(i64 0)
  %initial.field.0 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } undef, ptr %initial.number.0, 0, 0
  %initial.field.1 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.0, ptr %initial.number.1, 1
  %initial.field.2 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.1, i1 false, 0, 1
  %initial.field.3 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.2, i32 0, 2
  %initial.field.4 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.3, i32 1, 3
  %initial.field.5 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.4, i32 0, 0, 2
  %initial.state = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.5, i32 1, 0, 3
  br label %invoke

published.guard:                                  ; preds = %inactive.clean
  %epoch.nonzero = icmp ne i64 %stored.epoch, 0
  %published.valid = and i1 %epoch.nonzero, %cursor.range
  br i1 %published.valid, label %published.graph, label %invalid

published.graph:                                  ; preds = %published.guard
  %published.word.0.address = getelementptr i8, ptr %published.bank, i64 0
  %published.word.0 = load i64, ptr %published.word.0.address, align 8
  %published.word.1.address = getelementptr i8, ptr %published.bank, i64 8
  %published.word.1 = load i64, ptr %published.word.1.address, align 8
  %published.word.2.address = getelementptr i8, ptr %published.bank, i64 16
  %published.word.2 = load i64, ptr %published.word.2.address, align 8
  %published.word.3.address = getelementptr i8, ptr %published.bank, i64 24
  %published.word.3 = load i64, ptr %published.word.3.address, align 8
  %published.word.4.address = getelementptr i8, ptr %published.bank, i64 32
  %published.word.4 = load i64, ptr %published.word.4.address, align 8
  %published.word.5.address = getelementptr i8, ptr %published.bank, i64 40
  %published.word.5 = load i64, ptr %published.word.5.address, align 8
  %published.word.6.address = getelementptr i8, ptr %published.bank, i64 48
  %published.word.6 = load i64, ptr %published.word.6.address, align 8
  %published.word.7.address = getelementptr i8, ptr %published.bank, i64 56
  %published.word.7 = load i64, ptr %published.word.7.address, align 8
  %published.word.8.address = getelementptr i8, ptr %published.bank, i64 64
  %published.word.8 = load i64, ptr %published.word.8.address, align 8
  %published.word.9.address = getelementptr i8, ptr %published.bank, i64 72
  %published.word.9 = load i64, ptr %published.word.9.address, align 8
  %published.word.10.address = getelementptr i8, ptr %published.bank, i64 80
  %published.word.10 = load i64, ptr %published.word.10.address, align 8
  %input.number.0.node = getelementptr i8, ptr %published.bank, i64 40
  %input.number.0.address = ptrtoint ptr %input.number.0.node to i64
  %input.number.0.pointer = icmp eq i64 %published.word.0, %input.number.0.address
  %input.number.0.sign = icmp eq i64 %published.word.5, 0
  %input.number.0.one = icmp eq i64 %published.word.6, 1
  %input.number.0.two = icmp eq i64 %published.word.6, 2
  %input.number.0.low = icmp ule i64 %published.word.7, 4294967295
  %input.number.0.high = icmp ugt i64 %published.word.7, 4294967295
  %input.number.0.single = and i1 %input.number.0.one, %input.number.0.low
  %input.number.0.double = and i1 %input.number.0.two, %input.number.0.high
  %input.number.0.normal = or i1 %input.number.0.single, %input.number.0.double
  %input.number.0.minimum = icmp uge i64 %published.word.7, 1
  %input.number.0.maximum = icmp ule i64 %published.word.7, -2
  %input.number.1.node = getelementptr i8, ptr %published.bank, i64 64
  %input.number.1.address = ptrtoint ptr %input.number.1.node to i64
  %input.number.1.pointer = icmp eq i64 %published.word.3, %input.number.1.address
  %input.number.1.sign = icmp eq i64 %published.word.8, 0
  %input.number.1.one = icmp eq i64 %published.word.9, 1
  %input.number.1.two = icmp eq i64 %published.word.9, 2
  %input.number.1.low = icmp ule i64 %published.word.10, 4294967295
  %input.number.1.high = icmp ugt i64 %published.word.10, 4294967295
  %input.number.1.single = and i1 %input.number.1.one, %input.number.1.low
  %input.number.1.double = and i1 %input.number.1.two, %input.number.1.high
  %input.number.1.normal = or i1 %input.number.1.single, %input.number.1.double
  %input.number.1.minimum = icmp uge i64 %published.word.10, 2
  %input.number.1.maximum = icmp ule i64 %published.word.10, 2147483647
  %input.cursor.matches = icmp eq i64 %published.word.10, %cursor
  %input.padding.0.bits = and i64 %published.word.1, 4294967294
  %input.padding.0.clean = icmp eq i64 %input.padding.0.bits, 0
  %input.padding.1.bits = and i64 %published.word.2, -4294967296
  %input.padding.1.clean = icmp eq i64 %input.padding.1.bits, 0
  %input.order.0.0 = trunc i64 %published.word.4 to i32
  %input.order.0.1.shifted = lshr i64 %published.word.4, 32
  %input.order.0.1 = trunc i64 %input.order.0.1.shifted to i32
  %input.order.0.range.0 = icmp ult i32 %input.order.0.0, 2
  %input.order.0.range.1 = icmp ult i32 %input.order.0.1, 2
  %input.order.0.distinct.1.0 = icmp ne i32 %input.order.0.1, %input.order.0.0
  %input.order.1.0.shifted = lshr i64 %published.word.1, 32
  %input.order.1.0 = trunc i64 %input.order.1.0.shifted to i32
  %input.order.1.1 = trunc i64 %published.word.2 to i32
  %input.order.1.range.0 = icmp ult i32 %input.order.1.0, 2
  %input.order.1.range.1 = icmp ult i32 %input.order.1.1, 2
  %input.order.1.distinct.1.0 = icmp ne i32 %input.order.1.1, %input.order.1.0
  %input.graph.combined.1 = and i1 %input.number.0.pointer, %input.number.0.sign
  %input.graph.combined.2 = and i1 %input.graph.combined.1, %input.number.0.normal
  %input.graph.combined.3 = and i1 %input.graph.combined.2, %input.number.0.minimum
  %input.graph.combined.4 = and i1 %input.graph.combined.3, %input.number.0.maximum
  %input.graph.combined.5 = and i1 %input.graph.combined.4, %input.number.1.pointer
  %input.graph.combined.6 = and i1 %input.graph.combined.5, %input.number.1.sign
  %input.graph.combined.7 = and i1 %input.graph.combined.6, %input.number.1.normal
  %input.graph.combined.8 = and i1 %input.graph.combined.7, %input.number.1.minimum
  %input.graph.combined.9 = and i1 %input.graph.combined.8, %input.number.1.maximum
  %input.graph.combined.10 = and i1 %input.graph.combined.9, %input.cursor.matches
  %input.graph.combined.11 = and i1 %input.graph.combined.10, %input.padding.0.clean
  %input.graph.combined.12 = and i1 %input.graph.combined.11, %input.padding.1.clean
  %input.graph.combined.13 = and i1 %input.graph.combined.12, %input.order.0.range.0
  %input.graph.combined.14 = and i1 %input.graph.combined.13, %input.order.0.range.1
  %input.graph.combined.15 = and i1 %input.graph.combined.14, %input.order.0.distinct.1.0
  %input.graph.combined.16 = and i1 %input.graph.combined.15, %input.order.1.range.0
  %input.graph.combined.17 = and i1 %input.graph.combined.16, %input.order.1.range.1
  %input.graph.combined.18 = and i1 %input.graph.combined.17, %input.order.1.distinct.1.0
  br i1 %input.graph.combined.18, label %published.tail, label %invalid

published.tail:                                   ; preds = %published.graph
  br label %tail.scan

tail.scan:                                        ; preds = %tail.advance, %published.tail
  %tail.index = phi i64 [ 0, %published.tail ], [ %tail.next, %tail.advance ]
  %tail.scaled = mul i64 %tail.index, 8
  %tail.offset = add i64 %tail.scaled, 88
  %tail.address = getelementptr i8, ptr %published.bank, i64 %tail.offset
  %tail.word = load i64, ptr %tail.address, align 8
  %tail.zero = icmp eq i64 %tail.word, 0
  br i1 %tail.zero, label %tail.advance, label %invalid

tail.advance:                                     ; preds = %tail.scan
  %tail.next = add i64 %tail.index, 1
  %tail.more = icmp ult i64 %tail.next, 241
  br i1 %tail.more, label %tail.scan, label %published.view

published.view:                                   ; preds = %tail.advance
  %published.state = load { { ptr, i1, i32, i32 }, ptr, i32, i32 }, ptr %published.bank, align 8
  br label %invoke

invoke:                                           ; preds = %published.view, %initial.view
  %state = phi { { ptr, i1, i32, i32 }, ptr, i32, i32 } [ %initial.state, %initial.view ], [ %published.state, %published.view ]
  %result = call fastcc { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } @topal.identity.topal.fn.process_2didentity.4({ { ptr, i1, i32, i32 }, ptr, i32, i32 } %state)
  %source.state = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 1
  %source.result.order.0 = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 2
  %source.result.order.1 = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 3
  %source.outer.range.0 = icmp ult i32 %source.result.order.0, 2
  %source.outer.range.1 = icmp ult i32 %source.result.order.1, 2
  %source.outer.distinct.1.0 = icmp ne i32 %source.result.order.1, %source.result.order.0
  %source.state.order.0.0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 2
  %source.state.order.0.1 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 3
  %source.state.order.0.range.0 = icmp ult i32 %source.state.order.0.0, 2
  %source.state.order.0.range.1 = icmp ult i32 %source.state.order.0.1, 2
  %source.state.order.0.distinct.1.0 = icmp ne i32 %source.state.order.0.1, %source.state.order.0.0
  %source.state.order.1.0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 2
  %source.state.order.1.1 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 3
  %source.state.order.1.range.0 = icmp ult i32 %source.state.order.1.0, 2
  %source.state.order.1.range.1 = icmp ult i32 %source.state.order.1.1, 2
  %source.state.order.1.distinct.1.0 = icmp ne i32 %source.state.order.1.1, %source.state.order.1.0
  %source.order.combined.1 = and i1 %source.outer.range.0, %source.outer.range.1
  %source.order.combined.2 = and i1 %source.order.combined.1, %source.outer.distinct.1.0
  %source.order.combined.3 = and i1 %source.order.combined.2, %source.state.order.0.range.0
  %source.order.combined.4 = and i1 %source.order.combined.3, %source.state.order.0.range.1
  %source.order.combined.5 = and i1 %source.order.combined.4, %source.state.order.0.distinct.1.0
  %source.order.combined.6 = and i1 %source.order.combined.5, %source.state.order.1.range.0
  %source.order.combined.7 = and i1 %source.order.combined.6, %source.state.order.1.range.1
  %source.order.combined.8 = and i1 %source.order.combined.7, %source.state.order.1.distinct.1.0
  br i1 %source.order.combined.8, label %source.numbers, label %invalid

source.numbers:                                   ; preds = %invoke
  %allocated.object = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 0
  %allocated.sign.address = getelementptr i8, ptr %allocated.object, i64 0
  %allocated.length.address = getelementptr i8, ptr %allocated.object, i64 8
  %allocated.sign = load i64, ptr %allocated.sign.address, align 8
  %allocated.length = load i64, ptr %allocated.length.address, align 8
  %allocated.positive = icmp eq i64 %allocated.sign, 0
  %allocated.nonempty = icmp uge i64 %allocated.length, 1
  %allocated.bounded = icmp ule i64 %allocated.length, 1
  %allocated.shape.a = and i1 %allocated.positive, %allocated.nonempty
  %allocated.shape = and i1 %allocated.shape.a, %allocated.bounded
  br i1 %allocated.shape, label %allocated.low, label %invalid

allocated.low:                                    ; preds = %source.numbers
  %allocated.low.address = getelementptr i8, ptr %allocated.object, i64 16
  %allocated.low.word = load i32, ptr %allocated.low.address, align 4
  %allocated.low.value = zext i32 %allocated.low.word to i64
  %allocated.single = icmp eq i64 %allocated.length, 1
  br i1 %allocated.single, label %allocated.check, label %allocated.high

allocated.high:                                   ; preds = %allocated.low
  %allocated.high.address = getelementptr i8, ptr %allocated.object, i64 20
  %allocated.high.word = load i32, ptr %allocated.high.address, align 4
  %allocated.high.nonzero = icmp ne i32 %allocated.high.word, 0
  br i1 %allocated.high.nonzero, label %allocated.high.valid, label %invalid

allocated.high.valid:                             ; preds = %allocated.high
  %allocated.high.value = zext i32 %allocated.high.word to i64
  %allocated.shifted = shl i64 %allocated.high.value, 32
  %allocated.combined = or i64 %allocated.low.value, %allocated.shifted
  br label %allocated.check

allocated.check:                                  ; preds = %allocated.high.valid, %allocated.low
  %allocated.value = phi i64 [ %allocated.low.value, %allocated.low ], [ %allocated.combined, %allocated.high.valid ]
  %allocated.minimum = icmp uge i64 %allocated.value, 2
  %allocated.maximum = icmp ule i64 %allocated.value, 2147483647
  %allocated.range = and i1 %allocated.minimum, %allocated.maximum
  br i1 %allocated.range, label %allocated.ready, label %invalid

allocated.ready:                                  ; preds = %allocated.check
  %creations.object = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 0
  %creations.sign.address = getelementptr i8, ptr %creations.object, i64 0
  %creations.length.address = getelementptr i8, ptr %creations.object, i64 8
  %creations.sign = load i64, ptr %creations.sign.address, align 8
  %creations.length = load i64, ptr %creations.length.address, align 8
  %creations.positive = icmp eq i64 %creations.sign, 0
  %creations.nonempty = icmp uge i64 %creations.length, 1
  %creations.bounded = icmp ule i64 %creations.length, 2
  %creations.shape.a = and i1 %creations.positive, %creations.nonempty
  %creations.shape = and i1 %creations.shape.a, %creations.bounded
  br i1 %creations.shape, label %creations.low, label %invalid

creations.low:                                    ; preds = %allocated.ready
  %creations.low.address = getelementptr i8, ptr %creations.object, i64 16
  %creations.low.word = load i32, ptr %creations.low.address, align 4
  %creations.low.value = zext i32 %creations.low.word to i64
  %creations.single = icmp eq i64 %creations.length, 1
  br i1 %creations.single, label %creations.check, label %creations.high

creations.high:                                   ; preds = %creations.low
  %creations.high.address = getelementptr i8, ptr %creations.object, i64 20
  %creations.high.word = load i32, ptr %creations.high.address, align 4
  %creations.high.nonzero = icmp ne i32 %creations.high.word, 0
  br i1 %creations.high.nonzero, label %creations.high.valid, label %invalid

creations.high.valid:                             ; preds = %creations.high
  %creations.high.value = zext i32 %creations.high.word to i64
  %creations.shifted = shl i64 %creations.high.value, 32
  %creations.combined = or i64 %creations.low.value, %creations.shifted
  br label %creations.check

creations.check:                                  ; preds = %creations.high.valid, %creations.low
  %creations.value = phi i64 [ %creations.low.value, %creations.low ], [ %creations.combined, %creations.high.valid ]
  %creations.minimum = icmp uge i64 %creations.value, 1
  %creations.maximum = icmp ule i64 %creations.value, -1
  %creations.range = and i1 %creations.minimum, %creations.maximum
  br i1 %creations.range, label %creations.ready, label %invalid

creations.ready:                                  ; preds = %creations.check
  %next.object = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 1
  %next.sign.address = getelementptr i8, ptr %next.object, i64 0
  %next.length.address = getelementptr i8, ptr %next.object, i64 8
  %next.sign = load i64, ptr %next.sign.address, align 8
  %next.length = load i64, ptr %next.length.address, align 8
  %next.positive = icmp eq i64 %next.sign, 0
  %next.nonempty = icmp uge i64 %next.length, 1
  %next.bounded = icmp ule i64 %next.length, 1
  %next.shape.a = and i1 %next.positive, %next.nonempty
  %next.shape = and i1 %next.shape.a, %next.bounded
  br i1 %next.shape, label %next.low, label %invalid

next.low:                                         ; preds = %creations.ready
  %next.low.address = getelementptr i8, ptr %next.object, i64 16
  %next.low.word = load i32, ptr %next.low.address, align 4
  %next.low.value = zext i32 %next.low.word to i64
  %next.single = icmp eq i64 %next.length, 1
  br i1 %next.single, label %next.check, label %next.high

next.high:                                        ; preds = %next.low
  %next.high.address = getelementptr i8, ptr %next.object, i64 20
  %next.high.word = load i32, ptr %next.high.address, align 4
  %next.high.nonzero = icmp ne i32 %next.high.word, 0
  br i1 %next.high.nonzero, label %next.high.valid, label %invalid

next.high.valid:                                  ; preds = %next.high
  %next.high.value = zext i32 %next.high.word to i64
  %next.shifted = shl i64 %next.high.value, 32
  %next.combined = or i64 %next.low.value, %next.shifted
  br label %next.check

next.check:                                       ; preds = %next.high.valid, %next.low
  %next.value = phi i64 [ %next.low.value, %next.low ], [ %next.combined, %next.high.valid ]
  %next.minimum = icmp uge i64 %next.value, 2
  %next.maximum = icmp ule i64 %next.value, 2147483647
  %next.range = and i1 %next.minimum, %next.maximum
  br i1 %next.range, label %next.ready, label %invalid

next.ready:                                       ; preds = %next.check
  %source.boolean.0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 1
  %source.boolean.byte.0 = zext i1 %source.boolean.0 to i8
  %prepared.number.0.node = getelementptr i8, ptr %prepared.bank, i64 40
  %prepared.number.0.field = getelementptr i8, ptr %prepared.bank, i64 0
  store ptr %prepared.number.0.node, ptr %prepared.number.0.field, align 8
  store i64 0, ptr %prepared.number.0.node, align 8
  %prepared.number.0.length = getelementptr i8, ptr %prepared.number.0.node, i64 8
  store i64 %creations.length, ptr %prepared.number.0.length, align 8
  %prepared.number.0.data = getelementptr i8, ptr %prepared.number.0.node, i64 16
  store i64 %creations.value, ptr %prepared.number.0.data, align 8
  %prepared.number.1.node = getelementptr i8, ptr %prepared.bank, i64 64
  %prepared.number.1.field = getelementptr i8, ptr %prepared.bank, i64 24
  store ptr %prepared.number.1.node, ptr %prepared.number.1.field, align 8
  store i64 0, ptr %prepared.number.1.node, align 8
  %prepared.number.1.length = getelementptr i8, ptr %prepared.number.1.node, i64 8
  store i64 %next.length, ptr %prepared.number.1.length, align 8
  %prepared.number.1.data = getelementptr i8, ptr %prepared.number.1.node, i64 16
  store i64 %next.value, ptr %prepared.number.1.data, align 8
  %prepared.boolean.0 = getelementptr i8, ptr %prepared.bank, i64 8
  store i8 %source.boolean.byte.0, ptr %prepared.boolean.0, align 1
  %prepared.order.0.0 = getelementptr i8, ptr %prepared.bank, i64 32
  store i32 %source.state.order.0.0, ptr %prepared.order.0.0, align 4
  %prepared.order.0.1 = getelementptr i8, ptr %prepared.bank, i64 36
  store i32 %source.state.order.0.1, ptr %prepared.order.0.1, align 4
  %prepared.order.1.0 = getelementptr i8, ptr %prepared.bank, i64 12
  store i32 %source.state.order.1.0, ptr %prepared.order.1.0, align 4
  %prepared.order.1.1 = getelementptr i8, ptr %prepared.bank, i64 16
  store i32 %source.state.order.1.1, ptr %prepared.order.1.1, align 4
  store i64 %prepared.index, ptr %stored.prepared_bank.address, align 8
  store i64 %next.value, ptr %stored.prepared_next.address, align 8
  store i64 1, ptr %stored.prepared.address, align 8
  %first = insertvalue { i64, i64 } undef, i64 %allocated.value, 0
  %both = insertvalue { i64, i64 } %first, i64 %next.value, 1
  ret { i64, i64 } %both

invalid:                                          ; preds = %next.check, %next.high, %creations.ready, %creations.check, %creations.high, %allocated.ready, %allocated.check, %allocated.high, %source.numbers, %invoke, %tail.scan, %published.graph, %published.guard, %initial.scan, %initial.guard, %inactive.scan, %header, %entry
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

attributes #0 = { noimplicitfloat noinline noredzone nounwind optnone "disable-tail-calls"="true" }
attributes #1 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #2 = { noreturn }
attributes #3 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "structured-process-identity.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "support.process-identity.selected", linkageName: "topal.identity.topal.fn.support_2eprocess_2didentity_2eselected.0", scope: !7, file: !7, line: 3, type: !8, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DIFile(filename: "process-identity.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !10}
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !11)
!11 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !12, size: 64, align: 64)
!12 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !13)
!13 = !{!14, !16}
!14 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !15, size: 64, align: 64)
!15 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !15, size: 64, align: 64, offset: 64)
!17 = !DILocalVariable(name: "cursor", arg: 1, scope: !6, file: !7, line: 3, type: !10)
!18 = !DILocation(line: 3, column: 21, scope: !6)
!19 = !DILocalVariable(name: "initial", scope: !6, file: !7, line: 4, type: !10)
!20 = !DILocation(line: 4, column: 3, scope: !6)
!21 = !DILocation(line: 5, column: 3, scope: !6)
!22 = !DILocation(line: 6, column: 15, scope: !6)
!23 = !DILocation(line: 7, column: 16, scope: !6)
!24 = distinct !DISubprogram(name: "support.process-identity.following", linkageName: "topal.identity.topal.fn.support_2eprocess_2didentity_2efollowing.1", scope: !7, file: !7, line: 9, type: !8, scopeLine: 9, spFlags: DISPFlagDefinition, unit: !0)
!25 = !DILocalVariable(name: "allocated", arg: 1, scope: !24, file: !7, line: 9, type: !10)
!26 = !DILocation(line: 9, column: 22, scope: !24)
!27 = !DILocalVariable(name: "one", scope: !24, file: !7, line: 10, type: !10)
!28 = !DILocation(line: 10, column: 3, scope: !24)
!29 = !DILocalVariable(name: "initial", scope: !24, file: !7, line: 11, type: !10)
!30 = !DILocation(line: 11, column: 3, scope: !24)
!31 = !DILocation(line: 12, column: 3, scope: !24)
!32 = !DILocation(line: 13, column: 15, scope: !24)
!33 = !DILocation(line: 14, column: 16, scope: !24)
!34 = distinct !DISubprogram(name: "support.identity-history.retain-wrap", linkageName: "topal.identity.topal.fn.support_2eidentity_2dhistory_2eretain_2dwrap.2", scope: !35, file: !35, line: 3, type: !36, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!35 = !DIFile(filename: "identity-history.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!36 = !DISubroutineType(types: !37)
!37 = !{!38, !38, !10}
!38 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!39 = !DILocalVariable(name: "previous", arg: 1, scope: !34, file: !35, line: 3, type: !38)
!40 = !DILocation(line: 3, column: 20, scope: !34)
!41 = !DILocalVariable(name: "allocated", arg: 2, scope: !34, file: !35, line: 3, type: !10)
!42 = !DILocation(line: 3, column: 40, scope: !34)
!43 = !DILocation(line: 4, column: 3, scope: !34)
!44 = !DILocation(line: 5, column: 15, scope: !34)
!45 = !DILocation(line: 6, column: 16, scope: !34)
!46 = distinct !DISubprogram(name: "support.identity-history.following", linkageName: "topal.identity.topal.fn.support_2eidentity_2dhistory_2efollowing.3", scope: !35, file: !35, line: 8, type: !47, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!47 = !DISubroutineType(types: !48)
!48 = !{!49, !49, !10}
!49 = !DICompositeType(tag: DW_TAG_structure_type, name: "(creations : Nat, wrapped : Boolean)", file: !1, size: 192, align: 64, elements: !50)
!50 = !{!51, !52}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "creations", file: !1, baseType: !10, size: 64, align: 64)
!52 = !DIDerivedType(tag: DW_TAG_member, name: "wrapped", file: !1, baseType: !38, size: 8, align: 8, offset: 64)
!53 = !DILocation(line: 9, column: 3, scope: !46)
!54 = !DILocalVariable(name: "current", arg: 1, scope: !46, file: !35, line: 9, type: !49)
!55 = !DILocalVariable(name: "allocated", arg: 2, scope: !46, file: !35, line: 10, type: !10)
!56 = !DILocation(line: 10, column: 3, scope: !46)
!57 = !DILocalVariable(name: "one", scope: !46, file: !35, line: 12, type: !10)
!58 = !DILocation(line: 12, column: 3, scope: !46)
!59 = !DILocation(line: 13, column: 17, scope: !46)
!60 = !DILocalVariable(name: "creations", scope: !46, file: !35, line: 13, type: !10)
!61 = !DILocation(line: 13, column: 3, scope: !46)
!62 = !DILocalVariable(name: "previous", scope: !46, file: !35, line: 14, type: !38)
!63 = !DILocation(line: 14, column: 3, scope: !46)
!64 = !DILocation(line: 15, column: 14, scope: !46)
!65 = !DILocalVariable(name: "wrapped", scope: !46, file: !35, line: 15, type: !38)
!66 = !DILocation(line: 15, column: 3, scope: !46)
!67 = !DILocation(line: 16, column: 3, scope: !46)
!68 = distinct !DISubprogram(name: "process-identity", linkageName: "topal.identity.topal.fn.process_2didentity.4", scope: !1, file: !1, line: 4, type: !69, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !0)
!69 = !DISubroutineType(types: !70)
!70 = !{!71, !75}
!71 = !DICompositeType(tag: DW_TAG_structure_type, name: "(allocated : Nat, state : (history : (creations : Nat, wrapped : Boolean), next : Nat))", file: !1, size: 448, align: 64, elements: !72)
!72 = !{!73, !74}
!73 = !DIDerivedType(tag: DW_TAG_member, name: "allocated", file: !1, baseType: !10, size: 64, align: 64)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "state", file: !1, baseType: !75, size: 320, align: 64, offset: 64)
!75 = !DICompositeType(tag: DW_TAG_structure_type, name: "(history : (creations : Nat, wrapped : Boolean), next : Nat)", file: !1, size: 320, align: 64, elements: !76)
!76 = !{!77, !78}
!77 = !DIDerivedType(tag: DW_TAG_member, name: "history", file: !1, baseType: !49, size: 192, align: 64)
!78 = !DIDerivedType(tag: DW_TAG_member, name: "next", file: !1, baseType: !10, size: 64, align: 64, offset: 192)
!79 = !DILocation(line: 5, column: 3, scope: !68)
!80 = !DILocalVariable(name: "state", arg: 1, scope: !68, file: !1, line: 5, type: !75)
!81 = !DILocation(line: 7, column: 16, scope: !68)
!82 = !DILocalVariable(name: "allocated", scope: !68, file: !1, line: 7, type: !10)
!83 = !DILocation(line: 7, column: 3, scope: !68)
!84 = !DILocation(line: 8, column: 16, scope: !68)
!85 = !DILocalVariable(name: "following", scope: !68, file: !1, line: 8, type: !10)
!86 = !DILocation(line: 8, column: 3, scope: !68)
!87 = !DILocation(line: 9, column: 14, scope: !68)
!88 = !DILocation(line: 9, column: 3, scope: !68)
!89 = !DILocalVariable(name: "history", scope: !68, file: !1, line: 9, type: !49)
!90 = !DILocation(line: 10, column: 3, scope: !68)
