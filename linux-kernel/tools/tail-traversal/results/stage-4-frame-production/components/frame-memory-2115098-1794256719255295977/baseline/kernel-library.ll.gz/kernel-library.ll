; qualified Topal kernel source library
source_filename = "file-open-access.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

define internal fastcc i1 @topal.fn.any_3f.0(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !75 {
entry:
    #dbg_value(i1 %arg0, !76, !DIExpression(), !77)
    #dbg_value(i1 %arg1, !78, !DIExpression(), !79)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !80
decision.true.0:
  br label %decision.merge.2, !dbg !81
decision.false.1:
  br label %decision.merge.2, !dbg !82
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !83
  ret i1 %v0, !dbg !84
}

define internal fastcc i32 @topal.fn.truncate_2dplan.1(i1 %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !97 {
entry:
    #dbg_value(i1 %arg0, !98, !DIExpression(), !99)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !100
decision.true.0:
  br label %decision.merge.2, !dbg !101
decision.false.1:
  br label %decision.merge.2, !dbg !102
decision.merge.2:
  %v0 = phi i32 [7, %decision.true.0], [0, %decision.false.1], !dbg !103
  ret i32 %v0, !dbg !104
}

define internal fastcc i32 @topal.fn.mutable_2dplan.2(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !107 {
entry:
    #dbg_value(i1 %arg0, !108, !DIExpression(), !109)
    #dbg_value(i1 %arg1, !110, !DIExpression(), !111)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !112
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.truncate_2dplan.1(i1 %arg1), !dbg !113
  br label %decision.merge.2, !dbg !114
decision.false.1:
  br label %decision.merge.2, !dbg !115
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [3, %decision.false.1], !dbg !116
  ret i32 %v1, !dbg !117
}

define internal fastcc i32 @topal.fn.regular_2dopen.3(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !120 {
entry:
    #dbg_value(i1 %arg0, !121, !DIExpression(), !122)
    #dbg_value(i1 %arg1, !123, !DIExpression(), !124)
    #dbg_value(i1 %arg2, !125, !DIExpression(), !126)
  %v0 = call fastcc i1 @topal.fn.any_3f.0(i1 %arg0, i1 %arg2), !dbg !127
  br i1 %v0, label %decision.true.0, label %decision.false.1, !dbg !128
decision.true.0:
  %v1 = call fastcc i32 @topal.fn.mutable_2dplan.2(i1 %arg1, i1 %arg2), !dbg !129
  br label %decision.merge.2, !dbg !130
decision.false.1:
  br label %decision.merge.2, !dbg !131
decision.merge.2:
  %v2 = phi i32 [%v1, %decision.true.0], [0, %decision.false.1], !dbg !132
  ret i32 %v2, !dbg !133
}

define internal fastcc i1 @topal.fn.any_3f.4(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !136 {
entry:
    #dbg_value(i1 %arg0, !137, !DIExpression(), !138)
    #dbg_value(i1 %arg1, !139, !DIExpression(), !140)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !141
decision.true.0:
  br label %decision.merge.2, !dbg !142
decision.false.1:
  br label %decision.merge.2, !dbg !143
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !144
  ret i1 %v0, !dbg !145
}

define internal fastcc i1 @topal.fn.any_3f.5(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !148 {
entry:
    #dbg_value(i1 %arg0, !149, !DIExpression(), !150)
    #dbg_value(i1 %arg1, !151, !DIExpression(), !152)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !153
decision.true.0:
  br label %decision.merge.2, !dbg !154
decision.false.1:
  br label %decision.merge.2, !dbg !155
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !156
  ret i1 %v0, !dbg !157
}

define internal fastcc i32 @topal.fn.directory_2dopen.6(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !160 {
entry:
    #dbg_value(i1 %arg0, !161, !DIExpression(), !162)
    #dbg_value(i1 %arg1, !163, !DIExpression(), !164)
    #dbg_value(i1 %arg2, !165, !DIExpression(), !166)
  %v0 = call fastcc i1 @topal.fn.any_3f.4(i1 %arg1, i1 %arg2), !dbg !167
  %v1 = call fastcc i1 @topal.fn.any_3f.5(i1 %arg0, i1 %v0), !dbg !168
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !169
decision.true.0:
  br label %decision.merge.2, !dbg !170
decision.false.1:
  br label %decision.merge.2, !dbg !171
decision.merge.2:
  %v2 = phi i32 [2, %decision.true.0], [0, %decision.false.1], !dbg !172
  ret i32 %v2, !dbg !173
}

define internal fastcc i32 @topal.fn.by_2dkind.7(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !176 {
entry:
    #dbg_value(i1 %arg0, !177, !DIExpression(), !178)
    #dbg_value(i1 %arg1, !179, !DIExpression(), !180)
    #dbg_value(i1 %arg2, !181, !DIExpression(), !182)
    #dbg_value(i1 %arg3, !183, !DIExpression(), !184)
    #dbg_value(i1 %arg4, !185, !DIExpression(), !186)
  br i1 %arg1, label %decision.true.0, label %decision.false.1, !dbg !187
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.directory_2dopen.6(i1 %arg0, i1 %arg3, i1 %arg4), !dbg !188
  br label %decision.merge.2, !dbg !189
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.regular_2dopen.3(i1 %arg0, i1 %arg2, i1 %arg4), !dbg !190
  br label %decision.merge.2, !dbg !191
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !192
  ret i32 %v2, !dbg !193
}

define internal fastcc i32 @topal.fn.required_2dkind.8(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !196 {
entry:
    #dbg_value(i1 %arg0, !197, !DIExpression(), !198)
    #dbg_value(i1 %arg1, !199, !DIExpression(), !200)
    #dbg_value(i1 %arg2, !201, !DIExpression(), !202)
    #dbg_value(i1 %arg3, !203, !DIExpression(), !204)
    #dbg_value(i1 %arg4, !205, !DIExpression(), !206)
  br i1 %arg1, label %decision.true.0, label %decision.false.1, !dbg !207
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.by_2dkind.7(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4), !dbg !208
  br label %decision.merge.2, !dbg !209
decision.false.1:
  br label %decision.merge.2, !dbg !210
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [1, %decision.false.1], !dbg !211
  ret i32 %v1, !dbg !212
}

define internal fastcc i1 @topal.fn.any_3f.9(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !215 {
entry:
    #dbg_value(i1 %arg0, !216, !DIExpression(), !217)
    #dbg_value(i1 %arg1, !218, !DIExpression(), !219)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !220
decision.true.0:
  br label %decision.merge.2, !dbg !221
decision.false.1:
  br label %decision.merge.2, !dbg !222
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !223
  ret i1 %v0, !dbg !224
}

define internal fastcc i32 @topal.fn.truncate_2dplan.10(i1 %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !227 {
entry:
    #dbg_value(i1 %arg0, !228, !DIExpression(), !229)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !230
decision.true.0:
  br label %decision.merge.2, !dbg !231
decision.false.1:
  br label %decision.merge.2, !dbg !232
decision.merge.2:
  %v0 = phi i32 [7, %decision.true.0], [0, %decision.false.1], !dbg !233
  ret i32 %v0, !dbg !234
}

define internal fastcc i32 @topal.fn.mutable_2dplan.11(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !237 {
entry:
    #dbg_value(i1 %arg0, !238, !DIExpression(), !239)
    #dbg_value(i1 %arg1, !240, !DIExpression(), !241)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !242
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.truncate_2dplan.10(i1 %arg1), !dbg !243
  br label %decision.merge.2, !dbg !244
decision.false.1:
  br label %decision.merge.2, !dbg !245
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [3, %decision.false.1], !dbg !246
  ret i32 %v1, !dbg !247
}

define internal fastcc i32 @topal.fn.regular_2dopen.12(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !250 {
entry:
    #dbg_value(i1 %arg0, !251, !DIExpression(), !252)
    #dbg_value(i1 %arg1, !253, !DIExpression(), !254)
    #dbg_value(i1 %arg2, !255, !DIExpression(), !256)
  %v0 = call fastcc i1 @topal.fn.any_3f.9(i1 %arg0, i1 %arg2), !dbg !257
  br i1 %v0, label %decision.true.0, label %decision.false.1, !dbg !258
decision.true.0:
  %v1 = call fastcc i32 @topal.fn.mutable_2dplan.11(i1 %arg1, i1 %arg2), !dbg !259
  br label %decision.merge.2, !dbg !260
decision.false.1:
  br label %decision.merge.2, !dbg !261
decision.merge.2:
  %v2 = phi i32 [%v1, %decision.true.0], [0, %decision.false.1], !dbg !262
  ret i32 %v2, !dbg !263
}

define internal fastcc i1 @topal.fn.any_3f.13(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !266 {
entry:
    #dbg_value(i1 %arg0, !267, !DIExpression(), !268)
    #dbg_value(i1 %arg1, !269, !DIExpression(), !270)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !271
decision.true.0:
  br label %decision.merge.2, !dbg !272
decision.false.1:
  br label %decision.merge.2, !dbg !273
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !274
  ret i1 %v0, !dbg !275
}

define internal fastcc i1 @topal.fn.any_3f.14(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !278 {
entry:
    #dbg_value(i1 %arg0, !279, !DIExpression(), !280)
    #dbg_value(i1 %arg1, !281, !DIExpression(), !282)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !283
decision.true.0:
  br label %decision.merge.2, !dbg !284
decision.false.1:
  br label %decision.merge.2, !dbg !285
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !286
  ret i1 %v0, !dbg !287
}

define internal fastcc i32 @topal.fn.directory_2dopen.15(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !290 {
entry:
    #dbg_value(i1 %arg0, !291, !DIExpression(), !292)
    #dbg_value(i1 %arg1, !293, !DIExpression(), !294)
    #dbg_value(i1 %arg2, !295, !DIExpression(), !296)
  %v0 = call fastcc i1 @topal.fn.any_3f.13(i1 %arg1, i1 %arg2), !dbg !297
  %v1 = call fastcc i1 @topal.fn.any_3f.14(i1 %arg0, i1 %v0), !dbg !298
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !299
decision.true.0:
  br label %decision.merge.2, !dbg !300
decision.false.1:
  br label %decision.merge.2, !dbg !301
decision.merge.2:
  %v2 = phi i32 [2, %decision.true.0], [0, %decision.false.1], !dbg !302
  ret i32 %v2, !dbg !303
}

define internal fastcc i32 @topal.fn.by_2dkind.16(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !306 {
entry:
    #dbg_value(i1 %arg0, !307, !DIExpression(), !308)
    #dbg_value(i1 %arg1, !309, !DIExpression(), !310)
    #dbg_value(i1 %arg2, !311, !DIExpression(), !312)
    #dbg_value(i1 %arg3, !313, !DIExpression(), !314)
    #dbg_value(i1 %arg4, !315, !DIExpression(), !316)
  br i1 %arg1, label %decision.true.0, label %decision.false.1, !dbg !317
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.directory_2dopen.15(i1 %arg0, i1 %arg3, i1 %arg4), !dbg !318
  br label %decision.merge.2, !dbg !319
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.regular_2dopen.12(i1 %arg0, i1 %arg2, i1 %arg4), !dbg !320
  br label %decision.merge.2, !dbg !321
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !322
  ret i32 %v2, !dbg !323
}

define internal fastcc i32 @topal.fn.existing_2dkind.17(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg5) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !326 {
entry:
    #dbg_value(i1 %arg0, !327, !DIExpression(), !328)
    #dbg_value(i1 %arg1, !329, !DIExpression(), !330)
    #dbg_value(i1 %arg2, !331, !DIExpression(), !332)
    #dbg_value(i1 %arg3, !333, !DIExpression(), !334)
    #dbg_value(i1 %arg4, !335, !DIExpression(), !336)
    #dbg_value(i1 %arg5, !337, !DIExpression(), !338)
  br i1 %arg2, label %decision.true.0, label %decision.false.1, !dbg !339
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.required_2dkind.8(i1 %arg0, i1 %arg1, i1 %arg3, i1 %arg4, i1 %arg5), !dbg !340
  br label %decision.merge.2, !dbg !341
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.by_2dkind.16(i1 %arg0, i1 %arg1, i1 %arg3, i1 %arg4, i1 %arg5), !dbg !342
  br label %decision.merge.2, !dbg !343
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !344
  ret i32 %v2, !dbg !345
}

define internal fastcc i32 @topal.fn.exclusive_2dopen.18(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg5, i1 %arg6) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !348 {
entry:
    #dbg_value(i1 %arg0, !349, !DIExpression(), !350)
    #dbg_value(i1 %arg1, !351, !DIExpression(), !352)
    #dbg_value(i1 %arg2, !353, !DIExpression(), !354)
    #dbg_value(i1 %arg3, !355, !DIExpression(), !356)
    #dbg_value(i1 %arg4, !357, !DIExpression(), !358)
    #dbg_value(i1 %arg5, !359, !DIExpression(), !360)
    #dbg_value(i1 %arg6, !361, !DIExpression(), !362)
  br i1 %arg5, label %decision.true.0, label %decision.false.1, !dbg !363
decision.true.0:
  br label %decision.merge.2, !dbg !364
decision.false.1:
  %v0 = call fastcc i32 @topal.fn.existing_2dkind.17(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg6), !dbg !365
  br label %decision.merge.2, !dbg !366
decision.merge.2:
  %v1 = phi i32 [5, %decision.true.0], [%v0, %decision.false.1], !dbg !367
  ret i32 %v1, !dbg !368
}

define internal fastcc i1 @topal.fn.any_3f.19(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !371 {
entry:
    #dbg_value(i1 %arg0, !372, !DIExpression(), !373)
    #dbg_value(i1 %arg1, !374, !DIExpression(), !375)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !376
decision.true.0:
  br label %decision.merge.2, !dbg !377
decision.false.1:
  br label %decision.merge.2, !dbg !378
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !379
  ret i1 %v0, !dbg !380
}

define internal fastcc i32 @topal.fn.truncate_2dplan.20(i1 %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !383 {
entry:
    #dbg_value(i1 %arg0, !384, !DIExpression(), !385)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !386
decision.true.0:
  br label %decision.merge.2, !dbg !387
decision.false.1:
  br label %decision.merge.2, !dbg !388
decision.merge.2:
  %v0 = phi i32 [7, %decision.true.0], [0, %decision.false.1], !dbg !389
  ret i32 %v0, !dbg !390
}

define internal fastcc i32 @topal.fn.mutable_2dplan.21(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !393 {
entry:
    #dbg_value(i1 %arg0, !394, !DIExpression(), !395)
    #dbg_value(i1 %arg1, !396, !DIExpression(), !397)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !398
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.truncate_2dplan.20(i1 %arg1), !dbg !399
  br label %decision.merge.2, !dbg !400
decision.false.1:
  br label %decision.merge.2, !dbg !401
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [3, %decision.false.1], !dbg !402
  ret i32 %v1, !dbg !403
}

define internal fastcc i32 @topal.fn.regular_2dopen.22(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !406 {
entry:
    #dbg_value(i1 %arg0, !407, !DIExpression(), !408)
    #dbg_value(i1 %arg1, !409, !DIExpression(), !410)
    #dbg_value(i1 %arg2, !411, !DIExpression(), !412)
  %v0 = call fastcc i1 @topal.fn.any_3f.19(i1 %arg0, i1 %arg2), !dbg !413
  br i1 %v0, label %decision.true.0, label %decision.false.1, !dbg !414
decision.true.0:
  %v1 = call fastcc i32 @topal.fn.mutable_2dplan.21(i1 %arg1, i1 %arg2), !dbg !415
  br label %decision.merge.2, !dbg !416
decision.false.1:
  br label %decision.merge.2, !dbg !417
decision.merge.2:
  %v2 = phi i32 [%v1, %decision.true.0], [0, %decision.false.1], !dbg !418
  ret i32 %v2, !dbg !419
}

define internal fastcc i1 @topal.fn.any_3f.23(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !422 {
entry:
    #dbg_value(i1 %arg0, !423, !DIExpression(), !424)
    #dbg_value(i1 %arg1, !425, !DIExpression(), !426)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !427
decision.true.0:
  br label %decision.merge.2, !dbg !428
decision.false.1:
  br label %decision.merge.2, !dbg !429
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !430
  ret i1 %v0, !dbg !431
}

define internal fastcc i1 @topal.fn.any_3f.24(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !434 {
entry:
    #dbg_value(i1 %arg0, !435, !DIExpression(), !436)
    #dbg_value(i1 %arg1, !437, !DIExpression(), !438)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !439
decision.true.0:
  br label %decision.merge.2, !dbg !440
decision.false.1:
  br label %decision.merge.2, !dbg !441
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !442
  ret i1 %v0, !dbg !443
}

define internal fastcc i32 @topal.fn.directory_2dopen.25(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !446 {
entry:
    #dbg_value(i1 %arg0, !447, !DIExpression(), !448)
    #dbg_value(i1 %arg1, !449, !DIExpression(), !450)
    #dbg_value(i1 %arg2, !451, !DIExpression(), !452)
  %v0 = call fastcc i1 @topal.fn.any_3f.23(i1 %arg1, i1 %arg2), !dbg !453
  %v1 = call fastcc i1 @topal.fn.any_3f.24(i1 %arg0, i1 %v0), !dbg !454
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !455
decision.true.0:
  br label %decision.merge.2, !dbg !456
decision.false.1:
  br label %decision.merge.2, !dbg !457
decision.merge.2:
  %v2 = phi i32 [2, %decision.true.0], [0, %decision.false.1], !dbg !458
  ret i32 %v2, !dbg !459
}

define internal fastcc i32 @topal.fn.by_2dkind.26(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !462 {
entry:
    #dbg_value(i1 %arg0, !463, !DIExpression(), !464)
    #dbg_value(i1 %arg1, !465, !DIExpression(), !466)
    #dbg_value(i1 %arg2, !467, !DIExpression(), !468)
    #dbg_value(i1 %arg3, !469, !DIExpression(), !470)
    #dbg_value(i1 %arg4, !471, !DIExpression(), !472)
  br i1 %arg1, label %decision.true.0, label %decision.false.1, !dbg !473
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.directory_2dopen.25(i1 %arg0, i1 %arg3, i1 %arg4), !dbg !474
  br label %decision.merge.2, !dbg !475
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.regular_2dopen.22(i1 %arg0, i1 %arg2, i1 %arg4), !dbg !476
  br label %decision.merge.2, !dbg !477
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !478
  ret i32 %v2, !dbg !479
}

define internal fastcc i32 @topal.fn.required_2dkind.27(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !482 {
entry:
    #dbg_value(i1 %arg0, !483, !DIExpression(), !484)
    #dbg_value(i1 %arg1, !485, !DIExpression(), !486)
    #dbg_value(i1 %arg2, !487, !DIExpression(), !488)
    #dbg_value(i1 %arg3, !489, !DIExpression(), !490)
    #dbg_value(i1 %arg4, !491, !DIExpression(), !492)
  br i1 %arg1, label %decision.true.0, label %decision.false.1, !dbg !493
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.by_2dkind.26(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4), !dbg !494
  br label %decision.merge.2, !dbg !495
decision.false.1:
  br label %decision.merge.2, !dbg !496
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [1, %decision.false.1], !dbg !497
  ret i32 %v1, !dbg !498
}

define internal fastcc i1 @topal.fn.any_3f.28(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !501 {
entry:
    #dbg_value(i1 %arg0, !502, !DIExpression(), !503)
    #dbg_value(i1 %arg1, !504, !DIExpression(), !505)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !506
decision.true.0:
  br label %decision.merge.2, !dbg !507
decision.false.1:
  br label %decision.merge.2, !dbg !508
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !509
  ret i1 %v0, !dbg !510
}

define internal fastcc i32 @topal.fn.truncate_2dplan.29(i1 %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !513 {
entry:
    #dbg_value(i1 %arg0, !514, !DIExpression(), !515)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !516
decision.true.0:
  br label %decision.merge.2, !dbg !517
decision.false.1:
  br label %decision.merge.2, !dbg !518
decision.merge.2:
  %v0 = phi i32 [7, %decision.true.0], [0, %decision.false.1], !dbg !519
  ret i32 %v0, !dbg !520
}

define internal fastcc i32 @topal.fn.mutable_2dplan.30(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !523 {
entry:
    #dbg_value(i1 %arg0, !524, !DIExpression(), !525)
    #dbg_value(i1 %arg1, !526, !DIExpression(), !527)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !528
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.truncate_2dplan.29(i1 %arg1), !dbg !529
  br label %decision.merge.2, !dbg !530
decision.false.1:
  br label %decision.merge.2, !dbg !531
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [3, %decision.false.1], !dbg !532
  ret i32 %v1, !dbg !533
}

define internal fastcc i32 @topal.fn.regular_2dopen.31(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !536 {
entry:
    #dbg_value(i1 %arg0, !537, !DIExpression(), !538)
    #dbg_value(i1 %arg1, !539, !DIExpression(), !540)
    #dbg_value(i1 %arg2, !541, !DIExpression(), !542)
  %v0 = call fastcc i1 @topal.fn.any_3f.28(i1 %arg0, i1 %arg2), !dbg !543
  br i1 %v0, label %decision.true.0, label %decision.false.1, !dbg !544
decision.true.0:
  %v1 = call fastcc i32 @topal.fn.mutable_2dplan.30(i1 %arg1, i1 %arg2), !dbg !545
  br label %decision.merge.2, !dbg !546
decision.false.1:
  br label %decision.merge.2, !dbg !547
decision.merge.2:
  %v2 = phi i32 [%v1, %decision.true.0], [0, %decision.false.1], !dbg !548
  ret i32 %v2, !dbg !549
}

define internal fastcc i1 @topal.fn.any_3f.32(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !552 {
entry:
    #dbg_value(i1 %arg0, !553, !DIExpression(), !554)
    #dbg_value(i1 %arg1, !555, !DIExpression(), !556)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !557
decision.true.0:
  br label %decision.merge.2, !dbg !558
decision.false.1:
  br label %decision.merge.2, !dbg !559
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !560
  ret i1 %v0, !dbg !561
}

define internal fastcc i1 @topal.fn.any_3f.33(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !564 {
entry:
    #dbg_value(i1 %arg0, !565, !DIExpression(), !566)
    #dbg_value(i1 %arg1, !567, !DIExpression(), !568)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !569
decision.true.0:
  br label %decision.merge.2, !dbg !570
decision.false.1:
  br label %decision.merge.2, !dbg !571
decision.merge.2:
  %v0 = phi i1 [true, %decision.true.0], [%arg1, %decision.false.1], !dbg !572
  ret i1 %v0, !dbg !573
}

define internal fastcc i32 @topal.fn.directory_2dopen.34(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !576 {
entry:
    #dbg_value(i1 %arg0, !577, !DIExpression(), !578)
    #dbg_value(i1 %arg1, !579, !DIExpression(), !580)
    #dbg_value(i1 %arg2, !581, !DIExpression(), !582)
  %v0 = call fastcc i1 @topal.fn.any_3f.32(i1 %arg1, i1 %arg2), !dbg !583
  %v1 = call fastcc i1 @topal.fn.any_3f.33(i1 %arg0, i1 %v0), !dbg !584
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !585
decision.true.0:
  br label %decision.merge.2, !dbg !586
decision.false.1:
  br label %decision.merge.2, !dbg !587
decision.merge.2:
  %v2 = phi i32 [2, %decision.true.0], [0, %decision.false.1], !dbg !588
  ret i32 %v2, !dbg !589
}

define internal fastcc i32 @topal.fn.by_2dkind.35(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !592 {
entry:
    #dbg_value(i1 %arg0, !593, !DIExpression(), !594)
    #dbg_value(i1 %arg1, !595, !DIExpression(), !596)
    #dbg_value(i1 %arg2, !597, !DIExpression(), !598)
    #dbg_value(i1 %arg3, !599, !DIExpression(), !600)
    #dbg_value(i1 %arg4, !601, !DIExpression(), !602)
  br i1 %arg1, label %decision.true.0, label %decision.false.1, !dbg !603
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.directory_2dopen.34(i1 %arg0, i1 %arg3, i1 %arg4), !dbg !604
  br label %decision.merge.2, !dbg !605
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.regular_2dopen.31(i1 %arg0, i1 %arg2, i1 %arg4), !dbg !606
  br label %decision.merge.2, !dbg !607
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !608
  ret i32 %v2, !dbg !609
}

define internal fastcc i32 @topal.fn.existing_2dkind.36(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg5) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !612 {
entry:
    #dbg_value(i1 %arg0, !613, !DIExpression(), !614)
    #dbg_value(i1 %arg1, !615, !DIExpression(), !616)
    #dbg_value(i1 %arg2, !617, !DIExpression(), !618)
    #dbg_value(i1 %arg3, !619, !DIExpression(), !620)
    #dbg_value(i1 %arg4, !621, !DIExpression(), !622)
    #dbg_value(i1 %arg5, !623, !DIExpression(), !624)
  br i1 %arg2, label %decision.true.0, label %decision.false.1, !dbg !625
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.required_2dkind.27(i1 %arg0, i1 %arg1, i1 %arg3, i1 %arg4, i1 %arg5), !dbg !626
  br label %decision.merge.2, !dbg !627
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.by_2dkind.35(i1 %arg0, i1 %arg1, i1 %arg3, i1 %arg4, i1 %arg5), !dbg !628
  br label %decision.merge.2, !dbg !629
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !630
  ret i32 %v2, !dbg !631
}

define internal fastcc i32 @topal.fn.existing_2dopen.37(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg5, i1 %arg6) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !634 {
entry:
    #dbg_value(i1 %arg0, !635, !DIExpression(), !636)
    #dbg_value(i1 %arg1, !637, !DIExpression(), !638)
    #dbg_value(i1 %arg2, !639, !DIExpression(), !640)
    #dbg_value(i1 %arg3, !641, !DIExpression(), !642)
    #dbg_value(i1 %arg4, !643, !DIExpression(), !644)
    #dbg_value(i1 %arg5, !645, !DIExpression(), !646)
    #dbg_value(i1 %arg6, !647, !DIExpression(), !648)
  br i1 %arg4, label %decision.true.0, label %decision.false.1, !dbg !649
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.exclusive_2dopen.18(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg5, i1 %arg6), !dbg !650
  br label %decision.merge.2, !dbg !651
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.existing_2dkind.36(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg6), !dbg !652
  br label %decision.merge.2, !dbg !653
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !654
  ret i32 %v2, !dbg !655
}

define internal fastcc i32 @topal.fn.missing_2dkind.38(i1 %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !658 {
entry:
    #dbg_value(i1 %arg0, !659, !DIExpression(), !660)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !661
decision.true.0:
  br label %decision.merge.2, !dbg !662
decision.false.1:
  br label %decision.merge.2, !dbg !663
decision.merge.2:
  %v0 = phi i32 [1, %decision.true.0], [6, %decision.false.1], !dbg !664
  ret i32 %v0, !dbg !665
}

define internal fastcc i32 @topal.fn.missing_2dview.39(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !668 {
entry:
    #dbg_value(i1 %arg0, !669, !DIExpression(), !670)
    #dbg_value(i1 %arg1, !671, !DIExpression(), !672)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !673
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.missing_2dkind.38(i1 %arg1), !dbg !674
  br label %decision.merge.2, !dbg !675
decision.false.1:
  br label %decision.merge.2, !dbg !676
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [3, %decision.false.1], !dbg !677
  ret i32 %v1, !dbg !678
}

define internal fastcc i32 @topal.fn.missing_2dopen.40(i1 %arg0, i1 %arg1, i1 %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !681 {
entry:
    #dbg_value(i1 %arg0, !682, !DIExpression(), !683)
    #dbg_value(i1 %arg1, !684, !DIExpression(), !685)
    #dbg_value(i1 %arg2, !686, !DIExpression(), !687)
  br i1 %arg2, label %decision.true.0, label %decision.false.1, !dbg !688
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.missing_2dview.39(i1 %arg0, i1 %arg1), !dbg !689
  br label %decision.merge.2, !dbg !690
decision.false.1:
  br label %decision.merge.2, !dbg !691
decision.merge.2:
  %v1 = phi i32 [%v0, %decision.true.0], [4, %decision.false.1], !dbg !692
  ret i32 %v1, !dbg !693
}

define internal fastcc i32 @topal.fn.file_2dopen_2ddecision.41(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg4, i1 %arg5, i1 %arg6, i1 %arg7) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !696 {
entry:
    #dbg_value(i1 %arg0, !697, !DIExpression(), !698)
    #dbg_value(i1 %arg1, !699, !DIExpression(), !700)
    #dbg_value(i1 %arg2, !701, !DIExpression(), !702)
    #dbg_value(i1 %arg3, !703, !DIExpression(), !704)
    #dbg_value(i1 %arg4, !705, !DIExpression(), !706)
    #dbg_value(i1 %arg5, !707, !DIExpression(), !708)
    #dbg_value(i1 %arg6, !709, !DIExpression(), !710)
    #dbg_value(i1 %arg7, !711, !DIExpression(), !712)
  br i1 %arg4, label %decision.true.0, label %decision.false.1, !dbg !713
decision.true.0:
  %v0 = call fastcc i32 @topal.fn.existing_2dopen.37(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3, i1 %arg5, i1 %arg6, i1 %arg7), !dbg !714
  br label %decision.merge.2, !dbg !715
decision.false.1:
  %v1 = call fastcc i32 @topal.fn.missing_2dopen.40(i1 %arg3, i1 %arg2, i1 %arg5), !dbg !716
  br label %decision.merge.2, !dbg !717
decision.merge.2:
  %v2 = phi i32 [%v0, %decision.true.0], [%v1, %decision.false.1], !dbg !718
  ret i32 %v2, !dbg !719
}

define i64 @topal_kernel_file_open_policy_v1(i64 %facts) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %valid = icmp ult i64 %facts, 256
  br i1 %valid, label %invoke, label %invalid
invoke:
  %fact.bits.0 = lshr i64 %facts, 0
  %fact.0 = trunc i64 %fact.bits.0 to i1
  %fact.bits.1 = lshr i64 %facts, 1
  %fact.1 = trunc i64 %fact.bits.1 to i1
  %fact.bits.2 = lshr i64 %facts, 2
  %fact.2 = trunc i64 %fact.bits.2 to i1
  %fact.bits.3 = lshr i64 %facts, 3
  %fact.3 = trunc i64 %fact.bits.3 to i1
  %fact.bits.4 = lshr i64 %facts, 4
  %fact.4 = trunc i64 %fact.bits.4 to i1
  %fact.bits.5 = lshr i64 %facts, 5
  %fact.5 = trunc i64 %fact.bits.5 to i1
  %fact.bits.6 = lshr i64 %facts, 6
  %fact.6 = trunc i64 %fact.bits.6 to i1
  %fact.bits.7 = lshr i64 %facts, 7
  %fact.7 = trunc i64 %fact.bits.7 to i1
  %decision = call fastcc i32 @topal.fn.file_2dopen_2ddecision.41(i1 %fact.0, i1 %fact.1, i1 %fact.2, i1 %fact.3, i1 %fact.4, i1 %fact.5, i1 %fact.6, i1 %fact.7)
  switch i32 %decision, label %invalid [
    i32 0, label %choice.0
    i32 1, label %choice.1
    i32 2, label %choice.2
    i32 3, label %choice.3
    i32 4, label %choice.4
    i32 5, label %choice.5
    i32 6, label %choice.6
    i32 7, label %choice.7
  ]
choice.0:
  ret i64 0
choice.1:
  ret i64 1
choice.2:
  ret i64 2
choice.3:
  ret i64 3
choice.4:
  ret i64 4
choice.5:
  ret i64 5
choice.6:
  ret i64 6
choice.7:
  ret i64 7
invalid:
  ret i64 -1
}

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!720, !721}
!llvm.ident = !{!722}
!0 = !DIFile(filename: "file-open-access.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!1 = !{}
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !0, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !1, retainedTypes: !1)
!3 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!4 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!5 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!6 = !{!4, !5}
!7 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !0, size: 128, align: 64, elements: !6)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64, align: 64)
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !0, baseType: !8)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !0, baseType: !8)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "major", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "minor", file: !0, baseType: !10, size: 64, align: 64, offset: 64)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "patch", file: !0, baseType: !10, size: 64, align: 64, offset: 128)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "build", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!15 = !{!11, !12, !13, !14}
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalVersionHeader", file: !0, size: 256, align: 64, elements: !15)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "Version", file: !0, baseType: !17)
!19 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !20, size: 64, align: 64, offset: 0)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "byte_count", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!23 = !{!21, !22}
!24 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSerializationStreamHeader", file: !0, size: 128, align: 64, elements: !23)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64, align: 64)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "SerializationStream", file: !0, baseType: !25)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "numerator", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "denominator", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!29 = !{!27, !28}
!30 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRationalHeader", file: !0, size: 128, align: 64, elements: !29)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !30, size: 64, align: 64)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "Rational", file: !0, baseType: !31)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!37 = !{!33, !34, !35, !36}
!38 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeIntHeader", file: !0, size: 256, align: 64, elements: !37)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 64, align: 64)
!40 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Int", file: !0, baseType: !39)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !32, size: 64, align: 64, offset: 0)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !32, size: 64, align: 64, offset: 64)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!45 = !{!41, !42, !43, !44}
!46 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeRationalHeader", file: !0, size: 256, align: 64, elements: !45)
!47 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !46, size: 64, align: 64)
!48 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Rational", file: !0, baseType: !47)
!49 = !DIDerivedType(tag: DW_TAG_member, name: "is_error", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !50, size: 64, align: 64, offset: 64)
!52 = !{!49, !51}
!53 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalResultHeader", file: !0, size: 128, align: 64, elements: !52)
!54 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !53, size: 64, align: 64)
!55 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Int, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!56 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Nat, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Rational, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!58 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (String, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!59 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result ((Int, Int), lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!60 = !DIEnumerator(name: "Less", value: -1)
!61 = !DIEnumerator(name: "Equal", value: 0)
!62 = !DIEnumerator(name: "Greater", value: 1)
!63 = !{!60, !61, !62}
!64 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Comparison", file: !0, size: 32, align: 32, elements: !63)
!65 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!66 = !DIBasicType(name: "Unit", size: 8, encoding: DW_ATE_unsigned)
!67 = !DIEnumerator(name: "Completed", value: 0)
!68 = !{!67}
!69 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Completed", file: !0, size: 8, align: 8, elements: !68)
!70 = !DIEnumerator(name: "empty", value: 0)
!71 = !{!70}
!72 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Effect", file: !0, size: 8, align: 8, elements: !71)
!73 = !{!65, !65, !65}
!74 = !DISubroutineType(types: !73)
!75 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.0", scope: !0, file: !0, line: 6, type: !74, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!76 = !DILocalVariable(name: "a", arg: 1, scope: !75, file: !0, line: 6, type: !65)
!77 = !DILocation(line: 6, column: 13, scope: !75)
!78 = !DILocalVariable(name: "b", arg: 2, scope: !75, file: !0, line: 6, type: !65)
!79 = !DILocation(line: 6, column: 26, scope: !75)
!80 = !DILocation(line: 7, column: 3, scope: !75)
!81 = !DILocation(line: 8, column: 15, scope: !75)
!82 = !DILocation(line: 9, column: 16, scope: !75)
!83 = !DILocation(line: 7, column: 3, scope: !75)
!84 = !DILocation(line: 7, column: 3, scope: !75)
!85 = !DIEnumerator(name: "OpenDescription", value: 0)
!86 = !DIEnumerator(name: "NotDirectory", value: 1)
!87 = !DIEnumerator(name: "DirectoryWrite", value: 2)
!88 = !DIEnumerator(name: "ReadOnlyView", value: 3)
!89 = !DIEnumerator(name: "Missing", value: 4)
!90 = !DIEnumerator(name: "AlreadyExists", value: 5)
!91 = !DIEnumerator(name: "CreateDescription", value: 6)
!92 = !DIEnumerator(name: "TruncateDescription", value: 7)
!93 = !{!85, !86, !87, !88, !89, !90, !91, !92}
!94 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "FileOpenDecision", file: !0, size: 32, align: 32, elements: !93)
!95 = !{!94, !65}
!96 = !DISubroutineType(types: !95)
!97 = distinct !DISubprogram(name: "truncate-plan", linkageName: "topal.fn.truncate_2dplan.1", scope: !0, file: !0, line: 11, type: !96, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2)
!98 = !DILocalVariable(name: "truncate", arg: 1, scope: !97, file: !0, line: 11, type: !65)
!99 = !DILocation(line: 11, column: 22, scope: !97)
!100 = !DILocation(line: 12, column: 3, scope: !97)
!101 = !DILocation(line: 14, column: 15, scope: !97)
!102 = !DILocation(line: 13, column: 16, scope: !97)
!103 = !DILocation(line: 12, column: 3, scope: !97)
!104 = !DILocation(line: 12, column: 3, scope: !97)
!105 = !{!94, !65, !65}
!106 = !DISubroutineType(types: !105)
!107 = distinct !DISubprogram(name: "mutable-plan", linkageName: "topal.fn.mutable_2dplan.2", scope: !0, file: !0, line: 16, type: !106, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !2)
!108 = !DILocalVariable(name: "mutable", arg: 1, scope: !107, file: !0, line: 16, type: !65)
!109 = !DILocation(line: 16, column: 21, scope: !107)
!110 = !DILocalVariable(name: "truncate", arg: 2, scope: !107, file: !0, line: 16, type: !65)
!111 = !DILocation(line: 16, column: 40, scope: !107)
!112 = !DILocation(line: 17, column: 3, scope: !107)
!113 = !DILocation(line: 19, column: 15, scope: !107)
!114 = !DILocation(line: 19, column: 15, scope: !107)
!115 = !DILocation(line: 18, column: 16, scope: !107)
!116 = !DILocation(line: 17, column: 3, scope: !107)
!117 = !DILocation(line: 17, column: 3, scope: !107)
!118 = !{!94, !65, !65, !65}
!119 = !DISubroutineType(types: !118)
!120 = distinct !DISubprogram(name: "regular-open", linkageName: "topal.fn.regular_2dopen.3", scope: !0, file: !0, line: 21, type: !119, scopeLine: 21, spFlags: DISPFlagDefinition, unit: !2)
!121 = !DILocalVariable(name: "write", arg: 1, scope: !120, file: !0, line: 21, type: !65)
!122 = !DILocation(line: 21, column: 22, scope: !120)
!123 = !DILocalVariable(name: "mutable", arg: 2, scope: !120, file: !0, line: 21, type: !65)
!124 = !DILocation(line: 21, column: 39, scope: !120)
!125 = !DILocalVariable(name: "truncate", arg: 3, scope: !120, file: !0, line: 21, type: !65)
!126 = !DILocation(line: 21, column: 58, scope: !120)
!127 = !DILocation(line: 22, column: 3, scope: !120)
!128 = !DILocation(line: 22, column: 3, scope: !120)
!129 = !DILocation(line: 24, column: 15, scope: !120)
!130 = !DILocation(line: 24, column: 15, scope: !120)
!131 = !DILocation(line: 23, column: 16, scope: !120)
!132 = !DILocation(line: 22, column: 3, scope: !120)
!133 = !DILocation(line: 22, column: 3, scope: !120)
!134 = !{!65, !65, !65}
!135 = !DISubroutineType(types: !134)
!136 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.4", scope: !0, file: !0, line: 6, type: !135, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!137 = !DILocalVariable(name: "a", arg: 1, scope: !136, file: !0, line: 6, type: !65)
!138 = !DILocation(line: 6, column: 13, scope: !136)
!139 = !DILocalVariable(name: "b", arg: 2, scope: !136, file: !0, line: 6, type: !65)
!140 = !DILocation(line: 6, column: 26, scope: !136)
!141 = !DILocation(line: 7, column: 3, scope: !136)
!142 = !DILocation(line: 8, column: 15, scope: !136)
!143 = !DILocation(line: 9, column: 16, scope: !136)
!144 = !DILocation(line: 7, column: 3, scope: !136)
!145 = !DILocation(line: 7, column: 3, scope: !136)
!146 = !{!65, !65, !65}
!147 = !DISubroutineType(types: !146)
!148 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.5", scope: !0, file: !0, line: 6, type: !147, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!149 = !DILocalVariable(name: "a", arg: 1, scope: !148, file: !0, line: 6, type: !65)
!150 = !DILocation(line: 6, column: 13, scope: !148)
!151 = !DILocalVariable(name: "b", arg: 2, scope: !148, file: !0, line: 6, type: !65)
!152 = !DILocation(line: 6, column: 26, scope: !148)
!153 = !DILocation(line: 7, column: 3, scope: !148)
!154 = !DILocation(line: 8, column: 15, scope: !148)
!155 = !DILocation(line: 9, column: 16, scope: !148)
!156 = !DILocation(line: 7, column: 3, scope: !148)
!157 = !DILocation(line: 7, column: 3, scope: !148)
!158 = !{!94, !65, !65, !65}
!159 = !DISubroutineType(types: !158)
!160 = distinct !DISubprogram(name: "directory-open", linkageName: "topal.fn.directory_2dopen.6", scope: !0, file: !0, line: 26, type: !159, scopeLine: 26, spFlags: DISPFlagDefinition, unit: !2)
!161 = !DILocalVariable(name: "write", arg: 1, scope: !160, file: !0, line: 26, type: !65)
!162 = !DILocation(line: 26, column: 24, scope: !160)
!163 = !DILocalVariable(name: "create", arg: 2, scope: !160, file: !0, line: 26, type: !65)
!164 = !DILocation(line: 26, column: 41, scope: !160)
!165 = !DILocalVariable(name: "truncate", arg: 3, scope: !160, file: !0, line: 26, type: !65)
!166 = !DILocation(line: 26, column: 59, scope: !160)
!167 = !DILocation(line: 27, column: 16, scope: !160)
!168 = !DILocation(line: 27, column: 3, scope: !160)
!169 = !DILocation(line: 27, column: 3, scope: !160)
!170 = !DILocation(line: 28, column: 15, scope: !160)
!171 = !DILocation(line: 29, column: 16, scope: !160)
!172 = !DILocation(line: 27, column: 3, scope: !160)
!173 = !DILocation(line: 27, column: 3, scope: !160)
!174 = !{!94, !65, !65, !65, !65, !65}
!175 = !DISubroutineType(types: !174)
!176 = distinct !DISubprogram(name: "by-kind", linkageName: "topal.fn.by_2dkind.7", scope: !0, file: !0, line: 31, type: !175, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !2)
!177 = !DILocalVariable(name: "write", arg: 1, scope: !176, file: !0, line: 31, type: !65)
!178 = !DILocation(line: 31, column: 17, scope: !176)
!179 = !DILocalVariable(name: "directory", arg: 2, scope: !176, file: !0, line: 31, type: !65)
!180 = !DILocation(line: 31, column: 34, scope: !176)
!181 = !DILocalVariable(name: "mutable", arg: 3, scope: !176, file: !0, line: 31, type: !65)
!182 = !DILocation(line: 31, column: 55, scope: !176)
!183 = !DILocalVariable(name: "create", arg: 4, scope: !176, file: !0, line: 31, type: !65)
!184 = !DILocation(line: 31, column: 74, scope: !176)
!185 = !DILocalVariable(name: "truncate", arg: 5, scope: !176, file: !0, line: 31, type: !65)
!186 = !DILocation(line: 31, column: 92, scope: !176)
!187 = !DILocation(line: 32, column: 3, scope: !176)
!188 = !DILocation(line: 34, column: 15, scope: !176)
!189 = !DILocation(line: 34, column: 15, scope: !176)
!190 = !DILocation(line: 33, column: 16, scope: !176)
!191 = !DILocation(line: 33, column: 16, scope: !176)
!192 = !DILocation(line: 32, column: 3, scope: !176)
!193 = !DILocation(line: 32, column: 3, scope: !176)
!194 = !{!94, !65, !65, !65, !65, !65}
!195 = !DISubroutineType(types: !194)
!196 = distinct !DISubprogram(name: "required-kind", linkageName: "topal.fn.required_2dkind.8", scope: !0, file: !0, line: 36, type: !195, scopeLine: 36, spFlags: DISPFlagDefinition, unit: !2)
!197 = !DILocalVariable(name: "write", arg: 1, scope: !196, file: !0, line: 36, type: !65)
!198 = !DILocation(line: 36, column: 23, scope: !196)
!199 = !DILocalVariable(name: "directory", arg: 2, scope: !196, file: !0, line: 36, type: !65)
!200 = !DILocation(line: 36, column: 40, scope: !196)
!201 = !DILocalVariable(name: "mutable", arg: 3, scope: !196, file: !0, line: 36, type: !65)
!202 = !DILocation(line: 36, column: 61, scope: !196)
!203 = !DILocalVariable(name: "create", arg: 4, scope: !196, file: !0, line: 36, type: !65)
!204 = !DILocation(line: 36, column: 80, scope: !196)
!205 = !DILocalVariable(name: "truncate", arg: 5, scope: !196, file: !0, line: 36, type: !65)
!206 = !DILocation(line: 36, column: 98, scope: !196)
!207 = !DILocation(line: 37, column: 3, scope: !196)
!208 = !DILocation(line: 39, column: 15, scope: !196)
!209 = !DILocation(line: 39, column: 15, scope: !196)
!210 = !DILocation(line: 38, column: 16, scope: !196)
!211 = !DILocation(line: 37, column: 3, scope: !196)
!212 = !DILocation(line: 37, column: 3, scope: !196)
!213 = !{!65, !65, !65}
!214 = !DISubroutineType(types: !213)
!215 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.9", scope: !0, file: !0, line: 6, type: !214, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!216 = !DILocalVariable(name: "a", arg: 1, scope: !215, file: !0, line: 6, type: !65)
!217 = !DILocation(line: 6, column: 13, scope: !215)
!218 = !DILocalVariable(name: "b", arg: 2, scope: !215, file: !0, line: 6, type: !65)
!219 = !DILocation(line: 6, column: 26, scope: !215)
!220 = !DILocation(line: 7, column: 3, scope: !215)
!221 = !DILocation(line: 8, column: 15, scope: !215)
!222 = !DILocation(line: 9, column: 16, scope: !215)
!223 = !DILocation(line: 7, column: 3, scope: !215)
!224 = !DILocation(line: 7, column: 3, scope: !215)
!225 = !{!94, !65}
!226 = !DISubroutineType(types: !225)
!227 = distinct !DISubprogram(name: "truncate-plan", linkageName: "topal.fn.truncate_2dplan.10", scope: !0, file: !0, line: 11, type: !226, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2)
!228 = !DILocalVariable(name: "truncate", arg: 1, scope: !227, file: !0, line: 11, type: !65)
!229 = !DILocation(line: 11, column: 22, scope: !227)
!230 = !DILocation(line: 12, column: 3, scope: !227)
!231 = !DILocation(line: 14, column: 15, scope: !227)
!232 = !DILocation(line: 13, column: 16, scope: !227)
!233 = !DILocation(line: 12, column: 3, scope: !227)
!234 = !DILocation(line: 12, column: 3, scope: !227)
!235 = !{!94, !65, !65}
!236 = !DISubroutineType(types: !235)
!237 = distinct !DISubprogram(name: "mutable-plan", linkageName: "topal.fn.mutable_2dplan.11", scope: !0, file: !0, line: 16, type: !236, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !2)
!238 = !DILocalVariable(name: "mutable", arg: 1, scope: !237, file: !0, line: 16, type: !65)
!239 = !DILocation(line: 16, column: 21, scope: !237)
!240 = !DILocalVariable(name: "truncate", arg: 2, scope: !237, file: !0, line: 16, type: !65)
!241 = !DILocation(line: 16, column: 40, scope: !237)
!242 = !DILocation(line: 17, column: 3, scope: !237)
!243 = !DILocation(line: 19, column: 15, scope: !237)
!244 = !DILocation(line: 19, column: 15, scope: !237)
!245 = !DILocation(line: 18, column: 16, scope: !237)
!246 = !DILocation(line: 17, column: 3, scope: !237)
!247 = !DILocation(line: 17, column: 3, scope: !237)
!248 = !{!94, !65, !65, !65}
!249 = !DISubroutineType(types: !248)
!250 = distinct !DISubprogram(name: "regular-open", linkageName: "topal.fn.regular_2dopen.12", scope: !0, file: !0, line: 21, type: !249, scopeLine: 21, spFlags: DISPFlagDefinition, unit: !2)
!251 = !DILocalVariable(name: "write", arg: 1, scope: !250, file: !0, line: 21, type: !65)
!252 = !DILocation(line: 21, column: 22, scope: !250)
!253 = !DILocalVariable(name: "mutable", arg: 2, scope: !250, file: !0, line: 21, type: !65)
!254 = !DILocation(line: 21, column: 39, scope: !250)
!255 = !DILocalVariable(name: "truncate", arg: 3, scope: !250, file: !0, line: 21, type: !65)
!256 = !DILocation(line: 21, column: 58, scope: !250)
!257 = !DILocation(line: 22, column: 3, scope: !250)
!258 = !DILocation(line: 22, column: 3, scope: !250)
!259 = !DILocation(line: 24, column: 15, scope: !250)
!260 = !DILocation(line: 24, column: 15, scope: !250)
!261 = !DILocation(line: 23, column: 16, scope: !250)
!262 = !DILocation(line: 22, column: 3, scope: !250)
!263 = !DILocation(line: 22, column: 3, scope: !250)
!264 = !{!65, !65, !65}
!265 = !DISubroutineType(types: !264)
!266 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.13", scope: !0, file: !0, line: 6, type: !265, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!267 = !DILocalVariable(name: "a", arg: 1, scope: !266, file: !0, line: 6, type: !65)
!268 = !DILocation(line: 6, column: 13, scope: !266)
!269 = !DILocalVariable(name: "b", arg: 2, scope: !266, file: !0, line: 6, type: !65)
!270 = !DILocation(line: 6, column: 26, scope: !266)
!271 = !DILocation(line: 7, column: 3, scope: !266)
!272 = !DILocation(line: 8, column: 15, scope: !266)
!273 = !DILocation(line: 9, column: 16, scope: !266)
!274 = !DILocation(line: 7, column: 3, scope: !266)
!275 = !DILocation(line: 7, column: 3, scope: !266)
!276 = !{!65, !65, !65}
!277 = !DISubroutineType(types: !276)
!278 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.14", scope: !0, file: !0, line: 6, type: !277, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!279 = !DILocalVariable(name: "a", arg: 1, scope: !278, file: !0, line: 6, type: !65)
!280 = !DILocation(line: 6, column: 13, scope: !278)
!281 = !DILocalVariable(name: "b", arg: 2, scope: !278, file: !0, line: 6, type: !65)
!282 = !DILocation(line: 6, column: 26, scope: !278)
!283 = !DILocation(line: 7, column: 3, scope: !278)
!284 = !DILocation(line: 8, column: 15, scope: !278)
!285 = !DILocation(line: 9, column: 16, scope: !278)
!286 = !DILocation(line: 7, column: 3, scope: !278)
!287 = !DILocation(line: 7, column: 3, scope: !278)
!288 = !{!94, !65, !65, !65}
!289 = !DISubroutineType(types: !288)
!290 = distinct !DISubprogram(name: "directory-open", linkageName: "topal.fn.directory_2dopen.15", scope: !0, file: !0, line: 26, type: !289, scopeLine: 26, spFlags: DISPFlagDefinition, unit: !2)
!291 = !DILocalVariable(name: "write", arg: 1, scope: !290, file: !0, line: 26, type: !65)
!292 = !DILocation(line: 26, column: 24, scope: !290)
!293 = !DILocalVariable(name: "create", arg: 2, scope: !290, file: !0, line: 26, type: !65)
!294 = !DILocation(line: 26, column: 41, scope: !290)
!295 = !DILocalVariable(name: "truncate", arg: 3, scope: !290, file: !0, line: 26, type: !65)
!296 = !DILocation(line: 26, column: 59, scope: !290)
!297 = !DILocation(line: 27, column: 16, scope: !290)
!298 = !DILocation(line: 27, column: 3, scope: !290)
!299 = !DILocation(line: 27, column: 3, scope: !290)
!300 = !DILocation(line: 28, column: 15, scope: !290)
!301 = !DILocation(line: 29, column: 16, scope: !290)
!302 = !DILocation(line: 27, column: 3, scope: !290)
!303 = !DILocation(line: 27, column: 3, scope: !290)
!304 = !{!94, !65, !65, !65, !65, !65}
!305 = !DISubroutineType(types: !304)
!306 = distinct !DISubprogram(name: "by-kind", linkageName: "topal.fn.by_2dkind.16", scope: !0, file: !0, line: 31, type: !305, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !2)
!307 = !DILocalVariable(name: "write", arg: 1, scope: !306, file: !0, line: 31, type: !65)
!308 = !DILocation(line: 31, column: 17, scope: !306)
!309 = !DILocalVariable(name: "directory", arg: 2, scope: !306, file: !0, line: 31, type: !65)
!310 = !DILocation(line: 31, column: 34, scope: !306)
!311 = !DILocalVariable(name: "mutable", arg: 3, scope: !306, file: !0, line: 31, type: !65)
!312 = !DILocation(line: 31, column: 55, scope: !306)
!313 = !DILocalVariable(name: "create", arg: 4, scope: !306, file: !0, line: 31, type: !65)
!314 = !DILocation(line: 31, column: 74, scope: !306)
!315 = !DILocalVariable(name: "truncate", arg: 5, scope: !306, file: !0, line: 31, type: !65)
!316 = !DILocation(line: 31, column: 92, scope: !306)
!317 = !DILocation(line: 32, column: 3, scope: !306)
!318 = !DILocation(line: 34, column: 15, scope: !306)
!319 = !DILocation(line: 34, column: 15, scope: !306)
!320 = !DILocation(line: 33, column: 16, scope: !306)
!321 = !DILocation(line: 33, column: 16, scope: !306)
!322 = !DILocation(line: 32, column: 3, scope: !306)
!323 = !DILocation(line: 32, column: 3, scope: !306)
!324 = !{!94, !65, !65, !65, !65, !65, !65}
!325 = !DISubroutineType(types: !324)
!326 = distinct !DISubprogram(name: "existing-kind", linkageName: "topal.fn.existing_2dkind.17", scope: !0, file: !0, line: 41, type: !325, scopeLine: 41, spFlags: DISPFlagDefinition, unit: !2)
!327 = !DILocalVariable(name: "write", arg: 1, scope: !326, file: !0, line: 41, type: !65)
!328 = !DILocation(line: 41, column: 23, scope: !326)
!329 = !DILocalVariable(name: "directory", arg: 2, scope: !326, file: !0, line: 41, type: !65)
!330 = !DILocation(line: 41, column: 40, scope: !326)
!331 = !DILocalVariable(name: "required", arg: 3, scope: !326, file: !0, line: 41, type: !65)
!332 = !DILocation(line: 41, column: 61, scope: !326)
!333 = !DILocalVariable(name: "mutable", arg: 4, scope: !326, file: !0, line: 41, type: !65)
!334 = !DILocation(line: 41, column: 81, scope: !326)
!335 = !DILocalVariable(name: "create", arg: 5, scope: !326, file: !0, line: 41, type: !65)
!336 = !DILocation(line: 41, column: 100, scope: !326)
!337 = !DILocalVariable(name: "truncate", arg: 6, scope: !326, file: !0, line: 41, type: !65)
!338 = !DILocation(line: 41, column: 118, scope: !326)
!339 = !DILocation(line: 42, column: 3, scope: !326)
!340 = !DILocation(line: 43, column: 15, scope: !326)
!341 = !DILocation(line: 43, column: 15, scope: !326)
!342 = !DILocation(line: 44, column: 16, scope: !326)
!343 = !DILocation(line: 44, column: 16, scope: !326)
!344 = !DILocation(line: 42, column: 3, scope: !326)
!345 = !DILocation(line: 42, column: 3, scope: !326)
!346 = !{!94, !65, !65, !65, !65, !65, !65, !65}
!347 = !DISubroutineType(types: !346)
!348 = distinct !DISubprogram(name: "exclusive-open", linkageName: "topal.fn.exclusive_2dopen.18", scope: !0, file: !0, line: 46, type: !347, scopeLine: 46, spFlags: DISPFlagDefinition, unit: !2)
!349 = !DILocalVariable(name: "write", arg: 1, scope: !348, file: !0, line: 46, type: !65)
!350 = !DILocation(line: 46, column: 24, scope: !348)
!351 = !DILocalVariable(name: "directory", arg: 2, scope: !348, file: !0, line: 46, type: !65)
!352 = !DILocation(line: 46, column: 41, scope: !348)
!353 = !DILocalVariable(name: "required", arg: 3, scope: !348, file: !0, line: 46, type: !65)
!354 = !DILocation(line: 46, column: 62, scope: !348)
!355 = !DILocalVariable(name: "mutable", arg: 4, scope: !348, file: !0, line: 46, type: !65)
!356 = !DILocation(line: 46, column: 82, scope: !348)
!357 = !DILocalVariable(name: "create", arg: 5, scope: !348, file: !0, line: 46, type: !65)
!358 = !DILocation(line: 46, column: 101, scope: !348)
!359 = !DILocalVariable(name: "exclusive", arg: 6, scope: !348, file: !0, line: 46, type: !65)
!360 = !DILocation(line: 46, column: 119, scope: !348)
!361 = !DILocalVariable(name: "truncate", arg: 7, scope: !348, file: !0, line: 46, type: !65)
!362 = !DILocation(line: 46, column: 140, scope: !348)
!363 = !DILocation(line: 47, column: 3, scope: !348)
!364 = !DILocation(line: 48, column: 15, scope: !348)
!365 = !DILocation(line: 49, column: 16, scope: !348)
!366 = !DILocation(line: 49, column: 16, scope: !348)
!367 = !DILocation(line: 47, column: 3, scope: !348)
!368 = !DILocation(line: 47, column: 3, scope: !348)
!369 = !{!65, !65, !65}
!370 = !DISubroutineType(types: !369)
!371 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.19", scope: !0, file: !0, line: 6, type: !370, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!372 = !DILocalVariable(name: "a", arg: 1, scope: !371, file: !0, line: 6, type: !65)
!373 = !DILocation(line: 6, column: 13, scope: !371)
!374 = !DILocalVariable(name: "b", arg: 2, scope: !371, file: !0, line: 6, type: !65)
!375 = !DILocation(line: 6, column: 26, scope: !371)
!376 = !DILocation(line: 7, column: 3, scope: !371)
!377 = !DILocation(line: 8, column: 15, scope: !371)
!378 = !DILocation(line: 9, column: 16, scope: !371)
!379 = !DILocation(line: 7, column: 3, scope: !371)
!380 = !DILocation(line: 7, column: 3, scope: !371)
!381 = !{!94, !65}
!382 = !DISubroutineType(types: !381)
!383 = distinct !DISubprogram(name: "truncate-plan", linkageName: "topal.fn.truncate_2dplan.20", scope: !0, file: !0, line: 11, type: !382, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2)
!384 = !DILocalVariable(name: "truncate", arg: 1, scope: !383, file: !0, line: 11, type: !65)
!385 = !DILocation(line: 11, column: 22, scope: !383)
!386 = !DILocation(line: 12, column: 3, scope: !383)
!387 = !DILocation(line: 14, column: 15, scope: !383)
!388 = !DILocation(line: 13, column: 16, scope: !383)
!389 = !DILocation(line: 12, column: 3, scope: !383)
!390 = !DILocation(line: 12, column: 3, scope: !383)
!391 = !{!94, !65, !65}
!392 = !DISubroutineType(types: !391)
!393 = distinct !DISubprogram(name: "mutable-plan", linkageName: "topal.fn.mutable_2dplan.21", scope: !0, file: !0, line: 16, type: !392, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !2)
!394 = !DILocalVariable(name: "mutable", arg: 1, scope: !393, file: !0, line: 16, type: !65)
!395 = !DILocation(line: 16, column: 21, scope: !393)
!396 = !DILocalVariable(name: "truncate", arg: 2, scope: !393, file: !0, line: 16, type: !65)
!397 = !DILocation(line: 16, column: 40, scope: !393)
!398 = !DILocation(line: 17, column: 3, scope: !393)
!399 = !DILocation(line: 19, column: 15, scope: !393)
!400 = !DILocation(line: 19, column: 15, scope: !393)
!401 = !DILocation(line: 18, column: 16, scope: !393)
!402 = !DILocation(line: 17, column: 3, scope: !393)
!403 = !DILocation(line: 17, column: 3, scope: !393)
!404 = !{!94, !65, !65, !65}
!405 = !DISubroutineType(types: !404)
!406 = distinct !DISubprogram(name: "regular-open", linkageName: "topal.fn.regular_2dopen.22", scope: !0, file: !0, line: 21, type: !405, scopeLine: 21, spFlags: DISPFlagDefinition, unit: !2)
!407 = !DILocalVariable(name: "write", arg: 1, scope: !406, file: !0, line: 21, type: !65)
!408 = !DILocation(line: 21, column: 22, scope: !406)
!409 = !DILocalVariable(name: "mutable", arg: 2, scope: !406, file: !0, line: 21, type: !65)
!410 = !DILocation(line: 21, column: 39, scope: !406)
!411 = !DILocalVariable(name: "truncate", arg: 3, scope: !406, file: !0, line: 21, type: !65)
!412 = !DILocation(line: 21, column: 58, scope: !406)
!413 = !DILocation(line: 22, column: 3, scope: !406)
!414 = !DILocation(line: 22, column: 3, scope: !406)
!415 = !DILocation(line: 24, column: 15, scope: !406)
!416 = !DILocation(line: 24, column: 15, scope: !406)
!417 = !DILocation(line: 23, column: 16, scope: !406)
!418 = !DILocation(line: 22, column: 3, scope: !406)
!419 = !DILocation(line: 22, column: 3, scope: !406)
!420 = !{!65, !65, !65}
!421 = !DISubroutineType(types: !420)
!422 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.23", scope: !0, file: !0, line: 6, type: !421, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!423 = !DILocalVariable(name: "a", arg: 1, scope: !422, file: !0, line: 6, type: !65)
!424 = !DILocation(line: 6, column: 13, scope: !422)
!425 = !DILocalVariable(name: "b", arg: 2, scope: !422, file: !0, line: 6, type: !65)
!426 = !DILocation(line: 6, column: 26, scope: !422)
!427 = !DILocation(line: 7, column: 3, scope: !422)
!428 = !DILocation(line: 8, column: 15, scope: !422)
!429 = !DILocation(line: 9, column: 16, scope: !422)
!430 = !DILocation(line: 7, column: 3, scope: !422)
!431 = !DILocation(line: 7, column: 3, scope: !422)
!432 = !{!65, !65, !65}
!433 = !DISubroutineType(types: !432)
!434 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.24", scope: !0, file: !0, line: 6, type: !433, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!435 = !DILocalVariable(name: "a", arg: 1, scope: !434, file: !0, line: 6, type: !65)
!436 = !DILocation(line: 6, column: 13, scope: !434)
!437 = !DILocalVariable(name: "b", arg: 2, scope: !434, file: !0, line: 6, type: !65)
!438 = !DILocation(line: 6, column: 26, scope: !434)
!439 = !DILocation(line: 7, column: 3, scope: !434)
!440 = !DILocation(line: 8, column: 15, scope: !434)
!441 = !DILocation(line: 9, column: 16, scope: !434)
!442 = !DILocation(line: 7, column: 3, scope: !434)
!443 = !DILocation(line: 7, column: 3, scope: !434)
!444 = !{!94, !65, !65, !65}
!445 = !DISubroutineType(types: !444)
!446 = distinct !DISubprogram(name: "directory-open", linkageName: "topal.fn.directory_2dopen.25", scope: !0, file: !0, line: 26, type: !445, scopeLine: 26, spFlags: DISPFlagDefinition, unit: !2)
!447 = !DILocalVariable(name: "write", arg: 1, scope: !446, file: !0, line: 26, type: !65)
!448 = !DILocation(line: 26, column: 24, scope: !446)
!449 = !DILocalVariable(name: "create", arg: 2, scope: !446, file: !0, line: 26, type: !65)
!450 = !DILocation(line: 26, column: 41, scope: !446)
!451 = !DILocalVariable(name: "truncate", arg: 3, scope: !446, file: !0, line: 26, type: !65)
!452 = !DILocation(line: 26, column: 59, scope: !446)
!453 = !DILocation(line: 27, column: 16, scope: !446)
!454 = !DILocation(line: 27, column: 3, scope: !446)
!455 = !DILocation(line: 27, column: 3, scope: !446)
!456 = !DILocation(line: 28, column: 15, scope: !446)
!457 = !DILocation(line: 29, column: 16, scope: !446)
!458 = !DILocation(line: 27, column: 3, scope: !446)
!459 = !DILocation(line: 27, column: 3, scope: !446)
!460 = !{!94, !65, !65, !65, !65, !65}
!461 = !DISubroutineType(types: !460)
!462 = distinct !DISubprogram(name: "by-kind", linkageName: "topal.fn.by_2dkind.26", scope: !0, file: !0, line: 31, type: !461, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !2)
!463 = !DILocalVariable(name: "write", arg: 1, scope: !462, file: !0, line: 31, type: !65)
!464 = !DILocation(line: 31, column: 17, scope: !462)
!465 = !DILocalVariable(name: "directory", arg: 2, scope: !462, file: !0, line: 31, type: !65)
!466 = !DILocation(line: 31, column: 34, scope: !462)
!467 = !DILocalVariable(name: "mutable", arg: 3, scope: !462, file: !0, line: 31, type: !65)
!468 = !DILocation(line: 31, column: 55, scope: !462)
!469 = !DILocalVariable(name: "create", arg: 4, scope: !462, file: !0, line: 31, type: !65)
!470 = !DILocation(line: 31, column: 74, scope: !462)
!471 = !DILocalVariable(name: "truncate", arg: 5, scope: !462, file: !0, line: 31, type: !65)
!472 = !DILocation(line: 31, column: 92, scope: !462)
!473 = !DILocation(line: 32, column: 3, scope: !462)
!474 = !DILocation(line: 34, column: 15, scope: !462)
!475 = !DILocation(line: 34, column: 15, scope: !462)
!476 = !DILocation(line: 33, column: 16, scope: !462)
!477 = !DILocation(line: 33, column: 16, scope: !462)
!478 = !DILocation(line: 32, column: 3, scope: !462)
!479 = !DILocation(line: 32, column: 3, scope: !462)
!480 = !{!94, !65, !65, !65, !65, !65}
!481 = !DISubroutineType(types: !480)
!482 = distinct !DISubprogram(name: "required-kind", linkageName: "topal.fn.required_2dkind.27", scope: !0, file: !0, line: 36, type: !481, scopeLine: 36, spFlags: DISPFlagDefinition, unit: !2)
!483 = !DILocalVariable(name: "write", arg: 1, scope: !482, file: !0, line: 36, type: !65)
!484 = !DILocation(line: 36, column: 23, scope: !482)
!485 = !DILocalVariable(name: "directory", arg: 2, scope: !482, file: !0, line: 36, type: !65)
!486 = !DILocation(line: 36, column: 40, scope: !482)
!487 = !DILocalVariable(name: "mutable", arg: 3, scope: !482, file: !0, line: 36, type: !65)
!488 = !DILocation(line: 36, column: 61, scope: !482)
!489 = !DILocalVariable(name: "create", arg: 4, scope: !482, file: !0, line: 36, type: !65)
!490 = !DILocation(line: 36, column: 80, scope: !482)
!491 = !DILocalVariable(name: "truncate", arg: 5, scope: !482, file: !0, line: 36, type: !65)
!492 = !DILocation(line: 36, column: 98, scope: !482)
!493 = !DILocation(line: 37, column: 3, scope: !482)
!494 = !DILocation(line: 39, column: 15, scope: !482)
!495 = !DILocation(line: 39, column: 15, scope: !482)
!496 = !DILocation(line: 38, column: 16, scope: !482)
!497 = !DILocation(line: 37, column: 3, scope: !482)
!498 = !DILocation(line: 37, column: 3, scope: !482)
!499 = !{!65, !65, !65}
!500 = !DISubroutineType(types: !499)
!501 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.28", scope: !0, file: !0, line: 6, type: !500, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!502 = !DILocalVariable(name: "a", arg: 1, scope: !501, file: !0, line: 6, type: !65)
!503 = !DILocation(line: 6, column: 13, scope: !501)
!504 = !DILocalVariable(name: "b", arg: 2, scope: !501, file: !0, line: 6, type: !65)
!505 = !DILocation(line: 6, column: 26, scope: !501)
!506 = !DILocation(line: 7, column: 3, scope: !501)
!507 = !DILocation(line: 8, column: 15, scope: !501)
!508 = !DILocation(line: 9, column: 16, scope: !501)
!509 = !DILocation(line: 7, column: 3, scope: !501)
!510 = !DILocation(line: 7, column: 3, scope: !501)
!511 = !{!94, !65}
!512 = !DISubroutineType(types: !511)
!513 = distinct !DISubprogram(name: "truncate-plan", linkageName: "topal.fn.truncate_2dplan.29", scope: !0, file: !0, line: 11, type: !512, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2)
!514 = !DILocalVariable(name: "truncate", arg: 1, scope: !513, file: !0, line: 11, type: !65)
!515 = !DILocation(line: 11, column: 22, scope: !513)
!516 = !DILocation(line: 12, column: 3, scope: !513)
!517 = !DILocation(line: 14, column: 15, scope: !513)
!518 = !DILocation(line: 13, column: 16, scope: !513)
!519 = !DILocation(line: 12, column: 3, scope: !513)
!520 = !DILocation(line: 12, column: 3, scope: !513)
!521 = !{!94, !65, !65}
!522 = !DISubroutineType(types: !521)
!523 = distinct !DISubprogram(name: "mutable-plan", linkageName: "topal.fn.mutable_2dplan.30", scope: !0, file: !0, line: 16, type: !522, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !2)
!524 = !DILocalVariable(name: "mutable", arg: 1, scope: !523, file: !0, line: 16, type: !65)
!525 = !DILocation(line: 16, column: 21, scope: !523)
!526 = !DILocalVariable(name: "truncate", arg: 2, scope: !523, file: !0, line: 16, type: !65)
!527 = !DILocation(line: 16, column: 40, scope: !523)
!528 = !DILocation(line: 17, column: 3, scope: !523)
!529 = !DILocation(line: 19, column: 15, scope: !523)
!530 = !DILocation(line: 19, column: 15, scope: !523)
!531 = !DILocation(line: 18, column: 16, scope: !523)
!532 = !DILocation(line: 17, column: 3, scope: !523)
!533 = !DILocation(line: 17, column: 3, scope: !523)
!534 = !{!94, !65, !65, !65}
!535 = !DISubroutineType(types: !534)
!536 = distinct !DISubprogram(name: "regular-open", linkageName: "topal.fn.regular_2dopen.31", scope: !0, file: !0, line: 21, type: !535, scopeLine: 21, spFlags: DISPFlagDefinition, unit: !2)
!537 = !DILocalVariable(name: "write", arg: 1, scope: !536, file: !0, line: 21, type: !65)
!538 = !DILocation(line: 21, column: 22, scope: !536)
!539 = !DILocalVariable(name: "mutable", arg: 2, scope: !536, file: !0, line: 21, type: !65)
!540 = !DILocation(line: 21, column: 39, scope: !536)
!541 = !DILocalVariable(name: "truncate", arg: 3, scope: !536, file: !0, line: 21, type: !65)
!542 = !DILocation(line: 21, column: 58, scope: !536)
!543 = !DILocation(line: 22, column: 3, scope: !536)
!544 = !DILocation(line: 22, column: 3, scope: !536)
!545 = !DILocation(line: 24, column: 15, scope: !536)
!546 = !DILocation(line: 24, column: 15, scope: !536)
!547 = !DILocation(line: 23, column: 16, scope: !536)
!548 = !DILocation(line: 22, column: 3, scope: !536)
!549 = !DILocation(line: 22, column: 3, scope: !536)
!550 = !{!65, !65, !65}
!551 = !DISubroutineType(types: !550)
!552 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.32", scope: !0, file: !0, line: 6, type: !551, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!553 = !DILocalVariable(name: "a", arg: 1, scope: !552, file: !0, line: 6, type: !65)
!554 = !DILocation(line: 6, column: 13, scope: !552)
!555 = !DILocalVariable(name: "b", arg: 2, scope: !552, file: !0, line: 6, type: !65)
!556 = !DILocation(line: 6, column: 26, scope: !552)
!557 = !DILocation(line: 7, column: 3, scope: !552)
!558 = !DILocation(line: 8, column: 15, scope: !552)
!559 = !DILocation(line: 9, column: 16, scope: !552)
!560 = !DILocation(line: 7, column: 3, scope: !552)
!561 = !DILocation(line: 7, column: 3, scope: !552)
!562 = !{!65, !65, !65}
!563 = !DISubroutineType(types: !562)
!564 = distinct !DISubprogram(name: "any?", linkageName: "topal.fn.any_3f.33", scope: !0, file: !0, line: 6, type: !563, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!565 = !DILocalVariable(name: "a", arg: 1, scope: !564, file: !0, line: 6, type: !65)
!566 = !DILocation(line: 6, column: 13, scope: !564)
!567 = !DILocalVariable(name: "b", arg: 2, scope: !564, file: !0, line: 6, type: !65)
!568 = !DILocation(line: 6, column: 26, scope: !564)
!569 = !DILocation(line: 7, column: 3, scope: !564)
!570 = !DILocation(line: 8, column: 15, scope: !564)
!571 = !DILocation(line: 9, column: 16, scope: !564)
!572 = !DILocation(line: 7, column: 3, scope: !564)
!573 = !DILocation(line: 7, column: 3, scope: !564)
!574 = !{!94, !65, !65, !65}
!575 = !DISubroutineType(types: !574)
!576 = distinct !DISubprogram(name: "directory-open", linkageName: "topal.fn.directory_2dopen.34", scope: !0, file: !0, line: 26, type: !575, scopeLine: 26, spFlags: DISPFlagDefinition, unit: !2)
!577 = !DILocalVariable(name: "write", arg: 1, scope: !576, file: !0, line: 26, type: !65)
!578 = !DILocation(line: 26, column: 24, scope: !576)
!579 = !DILocalVariable(name: "create", arg: 2, scope: !576, file: !0, line: 26, type: !65)
!580 = !DILocation(line: 26, column: 41, scope: !576)
!581 = !DILocalVariable(name: "truncate", arg: 3, scope: !576, file: !0, line: 26, type: !65)
!582 = !DILocation(line: 26, column: 59, scope: !576)
!583 = !DILocation(line: 27, column: 16, scope: !576)
!584 = !DILocation(line: 27, column: 3, scope: !576)
!585 = !DILocation(line: 27, column: 3, scope: !576)
!586 = !DILocation(line: 28, column: 15, scope: !576)
!587 = !DILocation(line: 29, column: 16, scope: !576)
!588 = !DILocation(line: 27, column: 3, scope: !576)
!589 = !DILocation(line: 27, column: 3, scope: !576)
!590 = !{!94, !65, !65, !65, !65, !65}
!591 = !DISubroutineType(types: !590)
!592 = distinct !DISubprogram(name: "by-kind", linkageName: "topal.fn.by_2dkind.35", scope: !0, file: !0, line: 31, type: !591, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !2)
!593 = !DILocalVariable(name: "write", arg: 1, scope: !592, file: !0, line: 31, type: !65)
!594 = !DILocation(line: 31, column: 17, scope: !592)
!595 = !DILocalVariable(name: "directory", arg: 2, scope: !592, file: !0, line: 31, type: !65)
!596 = !DILocation(line: 31, column: 34, scope: !592)
!597 = !DILocalVariable(name: "mutable", arg: 3, scope: !592, file: !0, line: 31, type: !65)
!598 = !DILocation(line: 31, column: 55, scope: !592)
!599 = !DILocalVariable(name: "create", arg: 4, scope: !592, file: !0, line: 31, type: !65)
!600 = !DILocation(line: 31, column: 74, scope: !592)
!601 = !DILocalVariable(name: "truncate", arg: 5, scope: !592, file: !0, line: 31, type: !65)
!602 = !DILocation(line: 31, column: 92, scope: !592)
!603 = !DILocation(line: 32, column: 3, scope: !592)
!604 = !DILocation(line: 34, column: 15, scope: !592)
!605 = !DILocation(line: 34, column: 15, scope: !592)
!606 = !DILocation(line: 33, column: 16, scope: !592)
!607 = !DILocation(line: 33, column: 16, scope: !592)
!608 = !DILocation(line: 32, column: 3, scope: !592)
!609 = !DILocation(line: 32, column: 3, scope: !592)
!610 = !{!94, !65, !65, !65, !65, !65, !65}
!611 = !DISubroutineType(types: !610)
!612 = distinct !DISubprogram(name: "existing-kind", linkageName: "topal.fn.existing_2dkind.36", scope: !0, file: !0, line: 41, type: !611, scopeLine: 41, spFlags: DISPFlagDefinition, unit: !2)
!613 = !DILocalVariable(name: "write", arg: 1, scope: !612, file: !0, line: 41, type: !65)
!614 = !DILocation(line: 41, column: 23, scope: !612)
!615 = !DILocalVariable(name: "directory", arg: 2, scope: !612, file: !0, line: 41, type: !65)
!616 = !DILocation(line: 41, column: 40, scope: !612)
!617 = !DILocalVariable(name: "required", arg: 3, scope: !612, file: !0, line: 41, type: !65)
!618 = !DILocation(line: 41, column: 61, scope: !612)
!619 = !DILocalVariable(name: "mutable", arg: 4, scope: !612, file: !0, line: 41, type: !65)
!620 = !DILocation(line: 41, column: 81, scope: !612)
!621 = !DILocalVariable(name: "create", arg: 5, scope: !612, file: !0, line: 41, type: !65)
!622 = !DILocation(line: 41, column: 100, scope: !612)
!623 = !DILocalVariable(name: "truncate", arg: 6, scope: !612, file: !0, line: 41, type: !65)
!624 = !DILocation(line: 41, column: 118, scope: !612)
!625 = !DILocation(line: 42, column: 3, scope: !612)
!626 = !DILocation(line: 43, column: 15, scope: !612)
!627 = !DILocation(line: 43, column: 15, scope: !612)
!628 = !DILocation(line: 44, column: 16, scope: !612)
!629 = !DILocation(line: 44, column: 16, scope: !612)
!630 = !DILocation(line: 42, column: 3, scope: !612)
!631 = !DILocation(line: 42, column: 3, scope: !612)
!632 = !{!94, !65, !65, !65, !65, !65, !65, !65}
!633 = !DISubroutineType(types: !632)
!634 = distinct !DISubprogram(name: "existing-open", linkageName: "topal.fn.existing_2dopen.37", scope: !0, file: !0, line: 51, type: !633, scopeLine: 51, spFlags: DISPFlagDefinition, unit: !2)
!635 = !DILocalVariable(name: "write", arg: 1, scope: !634, file: !0, line: 51, type: !65)
!636 = !DILocation(line: 51, column: 23, scope: !634)
!637 = !DILocalVariable(name: "directory", arg: 2, scope: !634, file: !0, line: 51, type: !65)
!638 = !DILocation(line: 51, column: 40, scope: !634)
!639 = !DILocalVariable(name: "required", arg: 3, scope: !634, file: !0, line: 51, type: !65)
!640 = !DILocation(line: 51, column: 61, scope: !634)
!641 = !DILocalVariable(name: "mutable", arg: 4, scope: !634, file: !0, line: 51, type: !65)
!642 = !DILocation(line: 51, column: 81, scope: !634)
!643 = !DILocalVariable(name: "create", arg: 5, scope: !634, file: !0, line: 51, type: !65)
!644 = !DILocation(line: 51, column: 100, scope: !634)
!645 = !DILocalVariable(name: "exclusive", arg: 6, scope: !634, file: !0, line: 51, type: !65)
!646 = !DILocation(line: 51, column: 118, scope: !634)
!647 = !DILocalVariable(name: "truncate", arg: 7, scope: !634, file: !0, line: 51, type: !65)
!648 = !DILocation(line: 51, column: 139, scope: !634)
!649 = !DILocation(line: 52, column: 3, scope: !634)
!650 = !DILocation(line: 53, column: 15, scope: !634)
!651 = !DILocation(line: 53, column: 15, scope: !634)
!652 = !DILocation(line: 54, column: 16, scope: !634)
!653 = !DILocation(line: 54, column: 16, scope: !634)
!654 = !DILocation(line: 52, column: 3, scope: !634)
!655 = !DILocation(line: 52, column: 3, scope: !634)
!656 = !{!94, !65}
!657 = !DISubroutineType(types: !656)
!658 = distinct !DISubprogram(name: "missing-kind", linkageName: "topal.fn.missing_2dkind.38", scope: !0, file: !0, line: 56, type: !657, scopeLine: 56, spFlags: DISPFlagDefinition, unit: !2)
!659 = !DILocalVariable(name: "required", arg: 1, scope: !658, file: !0, line: 56, type: !65)
!660 = !DILocation(line: 56, column: 21, scope: !658)
!661 = !DILocation(line: 57, column: 3, scope: !658)
!662 = !DILocation(line: 58, column: 15, scope: !658)
!663 = !DILocation(line: 59, column: 16, scope: !658)
!664 = !DILocation(line: 57, column: 3, scope: !658)
!665 = !DILocation(line: 57, column: 3, scope: !658)
!666 = !{!94, !65, !65}
!667 = !DISubroutineType(types: !666)
!668 = distinct !DISubprogram(name: "missing-view", linkageName: "topal.fn.missing_2dview.39", scope: !0, file: !0, line: 61, type: !667, scopeLine: 61, spFlags: DISPFlagDefinition, unit: !2)
!669 = !DILocalVariable(name: "mutable", arg: 1, scope: !668, file: !0, line: 61, type: !65)
!670 = !DILocation(line: 61, column: 21, scope: !668)
!671 = !DILocalVariable(name: "required", arg: 2, scope: !668, file: !0, line: 61, type: !65)
!672 = !DILocation(line: 61, column: 40, scope: !668)
!673 = !DILocation(line: 62, column: 3, scope: !668)
!674 = !DILocation(line: 64, column: 15, scope: !668)
!675 = !DILocation(line: 64, column: 15, scope: !668)
!676 = !DILocation(line: 63, column: 16, scope: !668)
!677 = !DILocation(line: 62, column: 3, scope: !668)
!678 = !DILocation(line: 62, column: 3, scope: !668)
!679 = !{!94, !65, !65, !65}
!680 = !DISubroutineType(types: !679)
!681 = distinct !DISubprogram(name: "missing-open", linkageName: "topal.fn.missing_2dopen.40", scope: !0, file: !0, line: 66, type: !680, scopeLine: 66, spFlags: DISPFlagDefinition, unit: !2)
!682 = !DILocalVariable(name: "mutable", arg: 1, scope: !681, file: !0, line: 66, type: !65)
!683 = !DILocation(line: 66, column: 22, scope: !681)
!684 = !DILocalVariable(name: "required", arg: 2, scope: !681, file: !0, line: 66, type: !65)
!685 = !DILocation(line: 66, column: 41, scope: !681)
!686 = !DILocalVariable(name: "create", arg: 3, scope: !681, file: !0, line: 66, type: !65)
!687 = !DILocation(line: 66, column: 61, scope: !681)
!688 = !DILocation(line: 67, column: 3, scope: !681)
!689 = !DILocation(line: 69, column: 15, scope: !681)
!690 = !DILocation(line: 69, column: 15, scope: !681)
!691 = !DILocation(line: 68, column: 16, scope: !681)
!692 = !DILocation(line: 67, column: 3, scope: !681)
!693 = !DILocation(line: 67, column: 3, scope: !681)
!694 = !{!94, !65, !65, !65, !65, !65, !65, !65, !65}
!695 = !DISubroutineType(types: !694)
!696 = distinct !DISubprogram(name: "file-open-decision", linkageName: "topal.fn.file_2dopen_2ddecision.41", scope: !0, file: !0, line: 71, type: !695, scopeLine: 71, spFlags: DISPFlagDefinition, unit: !2)
!697 = !DILocalVariable(name: "write", arg: 1, scope: !696, file: !0, line: 71, type: !65)
!698 = !DILocation(line: 71, column: 32, scope: !696)
!699 = !DILocalVariable(name: "directory", arg: 2, scope: !696, file: !0, line: 71, type: !65)
!700 = !DILocation(line: 71, column: 49, scope: !696)
!701 = !DILocalVariable(name: "required", arg: 3, scope: !696, file: !0, line: 71, type: !65)
!702 = !DILocation(line: 71, column: 70, scope: !696)
!703 = !DILocalVariable(name: "mutable", arg: 4, scope: !696, file: !0, line: 71, type: !65)
!704 = !DILocation(line: 71, column: 90, scope: !696)
!705 = !DILocalVariable(name: "exists", arg: 5, scope: !696, file: !0, line: 71, type: !65)
!706 = !DILocation(line: 71, column: 109, scope: !696)
!707 = !DILocalVariable(name: "create", arg: 6, scope: !696, file: !0, line: 71, type: !65)
!708 = !DILocation(line: 71, column: 127, scope: !696)
!709 = !DILocalVariable(name: "exclusive", arg: 7, scope: !696, file: !0, line: 71, type: !65)
!710 = !DILocation(line: 71, column: 145, scope: !696)
!711 = !DILocalVariable(name: "truncate", arg: 8, scope: !696, file: !0, line: 71, type: !65)
!712 = !DILocation(line: 71, column: 166, scope: !696)
!713 = !DILocation(line: 72, column: 3, scope: !696)
!714 = !DILocation(line: 73, column: 15, scope: !696)
!715 = !DILocation(line: 73, column: 15, scope: !696)
!716 = !DILocation(line: 74, column: 16, scope: !696)
!717 = !DILocation(line: 74, column: 16, scope: !696)
!718 = !DILocation(line: 72, column: 3, scope: !696)
!719 = !DILocation(line: 72, column: 3, scope: !696)
!720 = !{i32 2, !"Dwarf Version", i32 5}
!721 = !{i32 2, !"Debug Info Version", i32 3}
!722 = !{!"topalc 0.1.0"}
