; ModuleID = '/tmp/tk282-stage4-b33bbc47/frame-reconstruction-2115098-1794256601344241134-artifact/.topal-systems-artifact-2115098-22/work/image-library.bc'
source_filename = "static-elf64-header.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.OptionalStorage = type { i64, ptr }
%topal.IntStorage = type { i64, i64, [0 x i32] }
%topal.ContainerSequenceHeader = type { i64, ptr }

@llvm.used = appending global [1 x ptr] [ptr @topal.elf.memset], section "llvm.metadata"
@topal.elf.runtime.int.zero = private constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@topal.elf.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.elf.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@.topal.int.0 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.1 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.2 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.3 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.4 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.5 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65536] }, align 8
@.topal.int.6 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16777216] }, align 8
@.topal.int.7 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.8 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.9 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.10 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.11 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65536] }, align 8
@.topal.int.12 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.13 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.14 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.15 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.16 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.17 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.18 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.19 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.20 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.21 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.22 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.23 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65536] }, align 8
@.topal.int.24 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16777216] }, align 8
@.topal.int.25 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.26 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.27 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.28 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.29 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.30 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.31 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.32 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@.topal.int.33 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.34 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.35 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@.topal.int.36 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@.topal.int.37 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.38 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.39 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65794] }, align 8
@.topal.int.40 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1179403647] }, align 8

; Function Attrs: noimplicitfloat noinline noredzone nounwind optnone
define internal ptr @topal.elf.memset(ptr %destination, i32 %value, i64 %length) #0 {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill

fill:                                             ; preds = %fill, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill

complete:                                         ; preds = %fill, %entry
  ret ptr %destination
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.optional.some(ptr %payload) #1 {
entry:
  %optional = call ptr @topal.elf.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.optional.none() #1 {
entry:
  %optional = call ptr @topal.elf.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.elf.runtime.optional.is.some(ptr %optional) #1 {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid

checked:                                          ; preds = %entry
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some

invalid:                                          ; preds = %entry
  call void @topal.elf.platform.exit(i64 70)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.optional.payload(ptr %optional) #1 {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.int.allocate(i64 %length, i64 %negative) #1 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.elf.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.elf.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.int.from.u64(i64 %source) #1 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.elf.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.elf.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.elf.runtime.int.limb.or.zero(ptr %value, i64 %index) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero

load:                                             ; preds = %entry
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended

zero:                                             ; preds = %entry
  ret i64 0
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.int.normalize(ptr %value) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim

trim:                                             ; preds = %leading.zero, %entry
  %candidate = phi i64 [ %length, %entry ], [ %next, %leading.zero ]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done

leading.zero:                                     ; preds = %trim
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim

zero:                                             ; preds = %leading.zero, %entry
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value

done:                                             ; preds = %trim
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.elf.runtime.int.compare.absolute(ptr %left, ptr %right) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer

check.longer:                                     ; preds = %entry
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty

check.empty:                                      ; preds = %check.longer
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs

limbs:                                            ; preds = %limbs.equal, %check.empty
  %position = phi i64 [ %left.length, %check.empty ], [ %index, %limbs.equal ]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater

check.limb.greater:                               ; preds = %limbs
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal

limbs.equal:                                      ; preds = %check.limb.greater
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal

less:                                             ; preds = %limbs, %entry
  ret i32 -1

equal:                                            ; preds = %limbs.equal, %check.empty
  ret i32 0

greater:                                          ; preds = %check.limb.greater, %check.longer
  ret i32 1
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.elf.runtime.int.compare(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity

left.positive:                                    ; preds = %entry
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result

check.left.negative.infinity:                     ; preds = %entry
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity

left.negative:                                    ; preds = %check.left.negative.infinity
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result

check.right.positive.infinity:                    ; preds = %check.left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity

check.right.negative.infinity:                    ; preds = %check.right.positive.infinity
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite

less:                                             ; preds = %check.right.positive.infinity
  ret i32 -1

greater:                                          ; preds = %check.right.negative.infinity
  ret i32 1

finite:                                           ; preds = %check.right.negative.infinity
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute

signed.result:                                    ; preds = %finite
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result

absolute:                                         ; preds = %finite
  %magnitude = call i32 @topal.elf.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.elf.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %left.limb = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish

finish:                                           ; preds = %loop, %entry
  %final.carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry

store.carry:                                      ; preds = %finish
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result

without.carry:                                    ; preds = %finish
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.elf.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.elf.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %borrow = phi i64 [ 0, %entry ], [ %next.borrow, %loop ]
  %left = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  %normalized = call ptr @topal.elf.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.int.add(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity

validate.left.infinity:                           ; preds = %entry
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity

indeterminate.infinity:                           ; preds = %validate.left.infinity
  call void @topal.elf.platform.exit(i64 70)
  unreachable

return.left.infinity:                             ; preds = %validate.left.infinity
  ret ptr %left

check.right.infinity:                             ; preds = %entry
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite

return.right.infinity:                            ; preds = %check.right.infinity
  ret ptr %right

finite:                                           ; preds = %check.right.infinity
  %left.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right

return.right:                                     ; preds = %finite
  ret ptr %right

check.right:                                      ; preds = %finite
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero

return.left:                                      ; preds = %check.right
  ret ptr %left

nonzero:                                          ; preds = %check.right
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference

sum:                                              ; preds = %nonzero
  %sum.value = call ptr @topal.elf.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value

difference:                                       ; preds = %nonzero
  %ordering = call i32 @topal.elf.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger

zero:                                             ; preds = %difference
  ret ptr @topal.elf.runtime.int.zero

select.larger:                                    ; preds = %difference
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference

left.difference:                                  ; preds = %select.larger
  %left.value = call ptr @topal.elf.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value

right.difference:                                 ; preds = %select.larger
  %right.value = call ptr @topal.elf.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.int.multiply(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite

infinite:                                         ; preds = %entry
  %left.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity

indeterminate.infinity:                           ; preds = %infinite
  call void @topal.elf.platform.exit(i64 70)
  unreachable

select.infinity:                                  ; preds = %infinite
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.elf.runtime.int.negative.infinity, ptr @topal.elf.runtime.int.positive.infinity
  ret ptr %infinity

finite:                                           ; preds = %entry
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length

zero:                                             ; preds = %finite
  ret ptr @topal.elf.runtime.int.zero

check.length:                                     ; preds = %finite
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate

failure:                                          ; preds = %check.length
  call void @topal.elf.platform.exit(i64 71)
  unreachable

allocate:                                         ; preds = %check.length
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.elf.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear

clear:                                            ; preds = %clear, %allocate
  %clear.index = phi i64 [ 0, %allocate ], [ %clear.next, %clear ]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry

outer.entry:                                      ; preds = %clear
  br label %outer

outer:                                            ; preds = %outer.done, %outer.entry
  %left.index = phi i64 [ 0, %outer.entry ], [ %left.next, %outer.done ]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner

inner:                                            ; preds = %inner, %outer
  %right.index = phi i64 [ 0, %outer ], [ %right.next, %inner ]
  %carry = phi i64 [ 0, %outer ], [ %next.carry, %inner ]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done

outer.done:                                       ; preds = %inner
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done

done:                                             ; preds = %outer.done
  %normalized = call ptr @topal.elf.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.elf.runtime.int.is.zero(ptr %value) #1 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.elf.runtime.container.list.count(ptr %list) #1 {
entry:
  br label %loop

loop:                                             ; preds = %advance, %entry
  %current = phi ptr [ %list, %entry ], [ %next, %advance ]
  %count = phi i64 [ 0, %entry ], [ %count.next, %advance ]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance

advance:                                          ; preds = %loop
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop

done:                                             ; preds = %loop
  ret i64 %count
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.container.array.int.collect(ptr %list) #1 {
entry:
  %count = call i64 @topal.elf.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.elf.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.runtime.container.array.int.at(ptr %array, i64 %index) #1 {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent

find:                                             ; preds = %entry
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop

loop:                                             ; preds = %advance, %find
  %current = phi ptr [ %entries, %find ], [ %next, %advance ]
  %position = phi i64 [ 0, %find ], [ %position.next, %advance ]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance

advance:                                          ; preds = %loop
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop

present:                                          ; preds = %loop
  %value = load ptr, ptr %current, align 8
  %some = call ptr @topal.elf.runtime.optional.some(ptr %value)
  ret ptr %some

absent:                                           ; preds = %entry
  %none = call ptr @topal.elf.runtime.optional.none()
  ret ptr %none
}

declare ptr @topal_kernel_numeric_allocate_v1(i64)

; Function Attrs: noreturn
declare void @topal_kernel_numeric_abort_v1() #2

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.elf.platform.allocate(i64 %length) #1 {
entry:
  %pointer = call ptr @topal_kernel_numeric_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.elf.platform.exit(i64 %status) #3 {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte0.0(ptr %arg0) #1 !dbg !6 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !24, !DIExpression(), !25)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 0), !dbg !26
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !26
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !26

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !27
    #dbg_value(ptr %v3, !28, !DIExpression(), !27)
  br label %optional.decision.merge.2, !dbg !29

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !30

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.0, %optional.decision.none.1 ], !dbg !26
  ret ptr %v4, !dbg !26
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte1.1(ptr %arg0) #1 !dbg !31 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !32, !DIExpression(), !33)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 1), !dbg !34
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !34
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !34

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !35
    #dbg_value(ptr %v3, !36, !DIExpression(), !35)
  br label %optional.decision.merge.2, !dbg !37

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !38

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.1, %optional.decision.none.1 ], !dbg !34
  ret ptr %v4, !dbg !34
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte2.2(ptr %arg0) #1 !dbg !39 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !40, !DIExpression(), !41)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 2), !dbg !42
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !42
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !42

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !43
    #dbg_value(ptr %v3, !44, !DIExpression(), !43)
  br label %optional.decision.merge.2, !dbg !45

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !46

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.2, %optional.decision.none.1 ], !dbg !42
  ret ptr %v4, !dbg !42
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte3.3(ptr %arg0) #1 !dbg !47 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !48, !DIExpression(), !49)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 3), !dbg !50
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !50
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !50

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !51
    #dbg_value(ptr %v3, !52, !DIExpression(), !51)
  br label %optional.decision.merge.2, !dbg !53

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !54

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.3, %optional.decision.none.1 ], !dbg !50
  ret ptr %v4, !dbg !50
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.4(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3) #1 !dbg !55 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !58, !DIExpression(), !59)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !60, !DIExpression(), !61)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !62, !DIExpression(), !63)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !64, !DIExpression(), !65)
  %v4 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.4), !dbg !66
  %v5 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v4), !dbg !67
  %v6 = call ptr @topal.elf.runtime.int.multiply(ptr %arg2, ptr @.topal.int.5), !dbg !68
  %v7 = call ptr @topal.elf.runtime.int.add(ptr %v5, ptr %v6), !dbg !67
  %v8 = call ptr @topal.elf.runtime.int.multiply(ptr %arg3, ptr @.topal.int.6), !dbg !69
  %v9 = call ptr @topal.elf.runtime.int.add(ptr %v7, ptr %v8), !dbg !67
  ret ptr %v9, !dbg !67
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmagic.5(ptr %arg0) #1 !dbg !70 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !71, !DIExpression(), !72)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte0.0(ptr %arg0), !dbg !73
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte1.1(ptr %arg0), !dbg !74
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte2.2(ptr %arg0), !dbg !75
  %v4 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte3.3(ptr %arg0), !dbg !76
  %v5 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.4(ptr %v1, ptr %v2, ptr %v3, ptr %v4), !dbg !77
  ret ptr %v5, !dbg !77
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte4.6(ptr %arg0) #1 !dbg !78 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !79, !DIExpression(), !80)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 4), !dbg !81
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !81
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !81

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !82
    #dbg_value(ptr %v3, !83, !DIExpression(), !82)
  br label %optional.decision.merge.2, !dbg !84

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !85

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.7, %optional.decision.none.1 ], !dbg !81
  ret ptr %v4, !dbg !81
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte5.7(ptr %arg0) #1 !dbg !86 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !87, !DIExpression(), !88)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 5), !dbg !89
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !89
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !89

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !90
    #dbg_value(ptr %v3, !91, !DIExpression(), !90)
  br label %optional.decision.merge.2, !dbg !92

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !93

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.8, %optional.decision.none.1 ], !dbg !89
  ret ptr %v4, !dbg !89
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte6.8(ptr %arg0) #1 !dbg !94 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !95, !DIExpression(), !96)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 6), !dbg !97
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !97
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !97

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !98
    #dbg_value(ptr %v3, !99, !DIExpression(), !98)
  br label %optional.decision.merge.2, !dbg !100

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !101

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.9, %optional.decision.none.1 ], !dbg !97
  ret ptr %v4, !dbg !97
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dthree.9(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !102 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !105, !DIExpression(), !106)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !107, !DIExpression(), !108)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !109, !DIExpression(), !110)
  %v3 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.10), !dbg !111
  %v4 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v3), !dbg !112
  %v5 = call ptr @topal.elf.runtime.int.multiply(ptr %arg2, ptr @.topal.int.11), !dbg !113
  %v6 = call ptr @topal.elf.runtime.int.add(ptr %v4, ptr %v5), !dbg !112
  ret ptr %v6, !dbg !112
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dident.10(ptr %arg0) #1 !dbg !114 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !115, !DIExpression(), !116)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte4.6(ptr %arg0), !dbg !117
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte5.7(ptr %arg0), !dbg !118
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte6.8(ptr %arg0), !dbg !119
  %v4 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dthree.9(ptr %v1, ptr %v2, ptr %v3), !dbg !120
  ret ptr %v4, !dbg !120
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte16.11(ptr %arg0) #1 !dbg !121 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !122, !DIExpression(), !123)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 16), !dbg !124
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !124
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !124

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !125
    #dbg_value(ptr %v3, !126, !DIExpression(), !125)
  br label %optional.decision.merge.2, !dbg !127

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !128

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.12, %optional.decision.none.1 ], !dbg !124
  ret ptr %v4, !dbg !124
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte17.12(ptr %arg0) #1 !dbg !129 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !130, !DIExpression(), !131)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 17), !dbg !132
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !132
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !132

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !133
    #dbg_value(ptr %v3, !134, !DIExpression(), !133)
  br label %optional.decision.merge.2, !dbg !135

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !136

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.13, %optional.decision.none.1 ], !dbg !132
  ret ptr %v4, !dbg !132
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.13(ptr %arg0, ptr %arg1) #1 !dbg !137 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !140, !DIExpression(), !141)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !142, !DIExpression(), !143)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.14), !dbg !144
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !145
  ret ptr %v3, !dbg !145
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dtype.14(ptr %arg0) #1 !dbg !146 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !147, !DIExpression(), !148)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte16.11(ptr %arg0), !dbg !149
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte17.12(ptr %arg0), !dbg !150
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.13(ptr %v1, ptr %v2), !dbg !151
  ret ptr %v3, !dbg !151
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte18.15(ptr %arg0) #1 !dbg !152 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !153, !DIExpression(), !154)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 18), !dbg !155
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !155
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !155

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !156
    #dbg_value(ptr %v3, !157, !DIExpression(), !156)
  br label %optional.decision.merge.2, !dbg !158

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !159

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.15, %optional.decision.none.1 ], !dbg !155
  ret ptr %v4, !dbg !155
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte19.16(ptr %arg0) #1 !dbg !160 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !161, !DIExpression(), !162)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 19), !dbg !163
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !163
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !163

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !164
    #dbg_value(ptr %v3, !165, !DIExpression(), !164)
  br label %optional.decision.merge.2, !dbg !166

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !167

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.16, %optional.decision.none.1 ], !dbg !163
  ret ptr %v4, !dbg !163
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.17(ptr %arg0, ptr %arg1) #1 !dbg !168 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !169, !DIExpression(), !170)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !171, !DIExpression(), !172)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.17), !dbg !173
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !174
  ret ptr %v3, !dbg !174
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmachine.18(ptr %arg0) #1 !dbg !175 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !176, !DIExpression(), !177)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte18.15(ptr %arg0), !dbg !178
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte19.16(ptr %arg0), !dbg !179
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.17(ptr %v1, ptr %v2), !dbg !180
  ret ptr %v3, !dbg !180
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte20.19(ptr %arg0) #1 !dbg !181 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !182, !DIExpression(), !183)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 20), !dbg !184
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !184
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !184

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !185
    #dbg_value(ptr %v3, !186, !DIExpression(), !185)
  br label %optional.decision.merge.2, !dbg !187

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !188

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.18, %optional.decision.none.1 ], !dbg !184
  ret ptr %v4, !dbg !184
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte21.20(ptr %arg0) #1 !dbg !189 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !190, !DIExpression(), !191)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 21), !dbg !192
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !192
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !192

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !193
    #dbg_value(ptr %v3, !194, !DIExpression(), !193)
  br label %optional.decision.merge.2, !dbg !195

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !196

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.19, %optional.decision.none.1 ], !dbg !192
  ret ptr %v4, !dbg !192
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte22.21(ptr %arg0) #1 !dbg !197 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !198, !DIExpression(), !199)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 22), !dbg !200
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !200
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !200

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !201
    #dbg_value(ptr %v3, !202, !DIExpression(), !201)
  br label %optional.decision.merge.2, !dbg !203

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !204

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.20, %optional.decision.none.1 ], !dbg !200
  ret ptr %v4, !dbg !200
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte23.22(ptr %arg0) #1 !dbg !205 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !206, !DIExpression(), !207)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 23), !dbg !208
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !208
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !208

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !209
    #dbg_value(ptr %v3, !210, !DIExpression(), !209)
  br label %optional.decision.merge.2, !dbg !211

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !212

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.21, %optional.decision.none.1 ], !dbg !208
  ret ptr %v4, !dbg !208
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.23(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3) #1 !dbg !213 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !214, !DIExpression(), !215)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !216, !DIExpression(), !217)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !218, !DIExpression(), !219)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !220, !DIExpression(), !221)
  %v4 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.22), !dbg !222
  %v5 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v4), !dbg !223
  %v6 = call ptr @topal.elf.runtime.int.multiply(ptr %arg2, ptr @.topal.int.23), !dbg !224
  %v7 = call ptr @topal.elf.runtime.int.add(ptr %v5, ptr %v6), !dbg !223
  %v8 = call ptr @topal.elf.runtime.int.multiply(ptr %arg3, ptr @.topal.int.24), !dbg !225
  %v9 = call ptr @topal.elf.runtime.int.add(ptr %v7, ptr %v8), !dbg !223
  ret ptr %v9, !dbg !223
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dversion.24(ptr %arg0) #1 !dbg !226 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !227, !DIExpression(), !228)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte20.19(ptr %arg0), !dbg !229
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte21.20(ptr %arg0), !dbg !230
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte22.21(ptr %arg0), !dbg !231
  %v4 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte23.22(ptr %arg0), !dbg !232
  %v5 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.23(ptr %v1, ptr %v2, ptr %v3, ptr %v4), !dbg !233
  ret ptr %v5, !dbg !233
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte52.25(ptr %arg0) #1 !dbg !234 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !235, !DIExpression(), !236)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 52), !dbg !237
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !237
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !237

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !238
    #dbg_value(ptr %v3, !239, !DIExpression(), !238)
  br label %optional.decision.merge.2, !dbg !240

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !241

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.25, %optional.decision.none.1 ], !dbg !237
  ret ptr %v4, !dbg !237
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte53.26(ptr %arg0) #1 !dbg !242 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !243, !DIExpression(), !244)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 53), !dbg !245
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !245
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !245

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !246
    #dbg_value(ptr %v3, !247, !DIExpression(), !246)
  br label %optional.decision.merge.2, !dbg !248

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !249

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.26, %optional.decision.none.1 ], !dbg !245
  ret ptr %v4, !dbg !245
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.27(ptr %arg0, ptr %arg1) #1 !dbg !250 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !251, !DIExpression(), !252)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !253, !DIExpression(), !254)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.27), !dbg !255
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !256
  ret ptr %v3, !dbg !256
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dheader_2dsize.28(ptr %arg0) #1 !dbg !257 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !258, !DIExpression(), !259)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte52.25(ptr %arg0), !dbg !260
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte53.26(ptr %arg0), !dbg !261
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.27(ptr %v1, ptr %v2), !dbg !262
  ret ptr %v3, !dbg !262
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte54.29(ptr %arg0) #1 !dbg !263 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !264, !DIExpression(), !265)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 54), !dbg !266
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !266
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !266

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !267
    #dbg_value(ptr %v3, !268, !DIExpression(), !267)
  br label %optional.decision.merge.2, !dbg !269

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !270

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.28, %optional.decision.none.1 ], !dbg !266
  ret ptr %v4, !dbg !266
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte55.30(ptr %arg0) #1 !dbg !271 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !272, !DIExpression(), !273)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 55), !dbg !274
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !274
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !274

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !275
    #dbg_value(ptr %v3, !276, !DIExpression(), !275)
  br label %optional.decision.merge.2, !dbg !277

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !278

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.29, %optional.decision.none.1 ], !dbg !274
  ret ptr %v4, !dbg !274
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.31(ptr %arg0, ptr %arg1) #1 !dbg !279 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !280, !DIExpression(), !281)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !282, !DIExpression(), !283)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.30), !dbg !284
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !285
  ret ptr %v3, !dbg !285
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dentry_2dsize.32(ptr %arg0) #1 !dbg !286 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !287, !DIExpression(), !288)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte54.29(ptr %arg0), !dbg !289
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte55.30(ptr %arg0), !dbg !290
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.31(ptr %v1, ptr %v2), !dbg !291
  ret ptr %v3, !dbg !291
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte56.33(ptr %arg0) #1 !dbg !292 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !293, !DIExpression(), !294)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 56), !dbg !295
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !295
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !295

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !296
    #dbg_value(ptr %v3, !297, !DIExpression(), !296)
  br label %optional.decision.merge.2, !dbg !298

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !299

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.31, %optional.decision.none.1 ], !dbg !295
  ret ptr %v4, !dbg !295
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte57.34(ptr %arg0) #1 !dbg !300 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !301, !DIExpression(), !302)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 57), !dbg !303
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !303
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !303

optional.decision.some.0:                         ; preds = %entry
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !304
    #dbg_value(ptr %v3, !305, !DIExpression(), !304)
  br label %optional.decision.merge.2, !dbg !306

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !307

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v4 = phi ptr [ %v3, %optional.decision.some.0 ], [ @.topal.int.32, %optional.decision.none.1 ], !dbg !303
  ret ptr %v4, !dbg !303
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.35(ptr %arg0, ptr %arg1) #1 !dbg !308 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !309, !DIExpression(), !310)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !311, !DIExpression(), !312)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.33), !dbg !313
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !314
  ret ptr %v3, !dbg !314
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dcount.36(ptr %arg0) #1 !dbg !315 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !316, !DIExpression(), !317)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte56.33(ptr %arg0), !dbg !318
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte57.34(ptr %arg0), !dbg !319
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.35(ptr %v1, ptr %v2), !dbg !320
  ret ptr %v3, !dbg !320
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dcount.37(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !321 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !326, !DIExpression(), !327)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !328, !DIExpression(), !329)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !330, !DIExpression(), !331)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dcount.36(ptr %arg0), !dbg !332
    #dbg_value(ptr %v3, !333, !DIExpression(), !334)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.34), !dbg !335
  %v5 = icmp sge i32 %v4, 0, !dbg !335
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !335

decision.true.0:                                  ; preds = %entry
  %v6 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr %arg2), !dbg !336
  %v7 = icmp sle i32 %v6, 0, !dbg !336
  br label %decision.merge.2, !dbg !336

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !337

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !335
  ret i1 %v8, !dbg !335
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dentry_2dsize.38(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !338 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !339, !DIExpression(), !340)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !341, !DIExpression(), !342)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !343, !DIExpression(), !344)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dentry_2dsize.32(ptr %arg0), !dbg !345
    #dbg_value(ptr %v3, !346, !DIExpression(), !347)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.35), !dbg !348
  %v5 = icmp eq i32 %v4, 0, !dbg !348
  %v6 = icmp eq i1 %v5, true, !dbg !348
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !348

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dcount.37(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !349
  br label %decision.merge.2, !dbg !349

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !350

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !348
  ret i1 %v8, !dbg !348
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dheader_2dsize.39(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !351 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !352, !DIExpression(), !353)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !354, !DIExpression(), !355)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !356, !DIExpression(), !357)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dheader_2dsize.28(ptr %arg0), !dbg !358
    #dbg_value(ptr %v3, !359, !DIExpression(), !360)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.36), !dbg !361
  %v5 = icmp eq i32 %v4, 0, !dbg !361
  %v6 = icmp eq i1 %v5, true, !dbg !361
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !361

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dentry_2dsize.38(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !362
  br label %decision.merge.2, !dbg !362

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !363

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !361
  ret i1 %v8, !dbg !361
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dversion.40(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !364 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !365, !DIExpression(), !366)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !367, !DIExpression(), !368)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !369, !DIExpression(), !370)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dversion.24(ptr %arg0), !dbg !371
    #dbg_value(ptr %v3, !372, !DIExpression(), !373)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.37), !dbg !374
  %v5 = icmp eq i32 %v4, 0, !dbg !374
  %v6 = icmp eq i1 %v5, true, !dbg !374
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !374

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dheader_2dsize.39(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !375
  br label %decision.merge.2, !dbg !375

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !376

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !374
  ret i1 %v8, !dbg !374
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dmachine.41(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !377 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !378, !DIExpression(), !379)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !380, !DIExpression(), !381)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !382, !DIExpression(), !383)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmachine.18(ptr %arg0), !dbg !384
    #dbg_value(ptr %v3, !385, !DIExpression(), !386)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr %arg1), !dbg !387
  %v5 = icmp eq i32 %v4, 0, !dbg !387
  %v6 = icmp eq i1 %v5, true, !dbg !387
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !387

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dversion.40(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !388
  br label %decision.merge.2, !dbg !388

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !389

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !387
  ret i1 %v8, !dbg !387
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dtype.42(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !390 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !391, !DIExpression(), !392)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !393, !DIExpression(), !394)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !395, !DIExpression(), !396)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dtype.14(ptr %arg0), !dbg !397
    #dbg_value(ptr %v3, !398, !DIExpression(), !399)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.38), !dbg !400
  %v5 = icmp eq i32 %v4, 0, !dbg !400
  %v6 = icmp eq i1 %v5, true, !dbg !400
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !400

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dmachine.41(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !401
  br label %decision.merge.2, !dbg !401

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !402

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !400
  ret i1 %v8, !dbg !400
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dident.43(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !403 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !404, !DIExpression(), !405)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !406, !DIExpression(), !407)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !408, !DIExpression(), !409)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dident.10(ptr %arg0), !dbg !410
    #dbg_value(ptr %v3, !411, !DIExpression(), !412)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.39), !dbg !413
  %v5 = icmp eq i32 %v4, 0, !dbg !413
  %v6 = icmp eq i1 %v5, true, !dbg !413
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !413

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dtype.42(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !414
  br label %decision.merge.2, !dbg !414

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !415

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !413
  ret i1 %v8, !dbg !413
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2eadmitted_3f.44(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !416 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !417, !DIExpression(), !418)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !419, !DIExpression(), !420)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !421, !DIExpression(), !422)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmagic.5(ptr %arg0), !dbg !423
    #dbg_value(ptr %v3, !424, !DIExpression(), !425)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.40), !dbg !426
  %v5 = icmp eq i32 %v4, 0, !dbg !426
  %v6 = icmp eq i1 %v5, true, !dbg !426
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !426

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dident.43(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !427
  br label %decision.merge.2, !dbg !427

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !428

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !426
  ret i1 %v8, !dbg !426
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.header.topal.fn.header_2dadmitted_3f.45(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !429 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !430, !DIExpression(), !431)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !432, !DIExpression(), !433)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !434, !DIExpression(), !435)
  %v3 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2eadmitted_3f.44(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !436
  ret i1 %v3, !dbg !436
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define i64 @topal_kernel_static_elf64_header_policy_v1(ptr %bytes, i64 %length, i64 %machine, i64 %maximum) #1 {
entry:
  %address = ptrtoint ptr %bytes to i64
  %end = add i64 %address, 64
  %nonwrapping = icmp ugt i64 %end, %address
  %nonnull = icmp ne ptr %bytes, null
  %length.valid = icmp eq i64 %length, 64
  %machine.low = icmp uge i64 %machine, 1
  %machine.high = icmp ule i64 %machine, 65535
  %maximum.low = icmp uge i64 %maximum, 1
  %maximum.high = icmp ule i64 %maximum, 65535
  %extent.valid = and i1 %nonnull, %length.valid
  %extent.bounded = and i1 %extent.valid, %nonwrapping
  %machine.valid = and i1 %machine.low, %machine.high
  %maximum.valid = and i1 %maximum.low, %maximum.high
  %facts.valid = and i1 %machine.valid, %maximum.valid
  %valid = and i1 %extent.bounded, %facts.valid
  br i1 %valid, label %invoke, label %invalid

invoke:                                           ; preds = %entry
  %machine.value = call ptr @topal.elf.runtime.int.from.u64(i64 %machine)
  %maximum.value = call ptr @topal.elf.runtime.int.from.u64(i64 %maximum)
  br label %copy

copy:                                             ; preds = %copy, %invoke
  %remaining = phi i64 [ 64, %invoke ], [ %index, %copy ]
  %tail = phi ptr [ null, %invoke ], [ %node, %copy ]
  %index = sub i64 %remaining, 1
  %input = getelementptr i8, ptr %bytes, i64 %index
  %byte = load i8, ptr %input, align 1
  %unsigned = zext i8 %byte to i64
  %integer = call ptr @topal.elf.runtime.int.from.u64(i64 %unsigned)
  %node = call ptr @topal.elf.platform.allocate(i64 16)
  store ptr %integer, ptr %node, align 8
  %next = getelementptr i8, ptr %node, i64 8
  store ptr %tail, ptr %next, align 8
  %done = icmp eq i64 %index, 0
  br i1 %done, label %policy, label %copy

policy:                                           ; preds = %copy
  %array = call ptr @topal.elf.runtime.container.array.int.collect(ptr %node)
  %accepted = call fastcc i1 @topal.header.topal.fn.header_2dadmitted_3f.45(ptr %array, ptr %machine.value, ptr %maximum.value)
  %result = zext i1 %accepted to i64
  ret i64 %result

invalid:                                          ; preds = %entry
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

attributes #0 = { noimplicitfloat noinline noredzone nounwind optnone "disable-tail-calls"="true" }
attributes #1 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #2 = { noreturn }
attributes #3 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "static-elf64-header.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "support.elf.byte0", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte0.0", scope: !7, file: !7, line: 4, type: !8, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DIFile(filename: "elf.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !17}
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !1, baseType: !11)
!11 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !12, size: 64, align: 64)
!12 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !13)
!13 = !{!14, !16}
!14 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !15, size: 64, align: 64)
!15 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !15, size: 64, align: 64, offset: 64)
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "Array 64 Int", file: !1, baseType: !18)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!19 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalContainer.Array 64 Int", file: !1, size: 128, align: 64, elements: !20)
!20 = !{!21, !22}
!21 = !DIDerivedType(tag: DW_TAG_member, name: "entry_count", file: !1, baseType: !15, size: 64, align: 64)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "entries", file: !1, baseType: !23, size: 64, align: 64, offset: 64)
!23 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64, align: 64)
!24 = !DILocalVariable(name: "bytes", arg: 1, scope: !6, file: !7, line: 4, type: !17)
!25 = !DILocation(line: 4, column: 14, scope: !6)
!26 = !DILocation(line: 5, column: 3, scope: !6)
!27 = !DILocation(line: 6, column: 10, scope: !6)
!28 = !DILocalVariable(name: "value", scope: !6, file: !7, line: 6, type: !10)
!29 = !DILocation(line: 6, column: 21, scope: !6)
!30 = !DILocation(line: 7, column: 15, scope: !6)
!31 = distinct !DISubprogram(name: "support.elf.byte1", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte1.1", scope: !7, file: !7, line: 9, type: !8, scopeLine: 9, spFlags: DISPFlagDefinition, unit: !0)
!32 = !DILocalVariable(name: "bytes", arg: 1, scope: !31, file: !7, line: 9, type: !17)
!33 = !DILocation(line: 9, column: 14, scope: !31)
!34 = !DILocation(line: 10, column: 3, scope: !31)
!35 = !DILocation(line: 11, column: 10, scope: !31)
!36 = !DILocalVariable(name: "value", scope: !31, file: !7, line: 11, type: !10)
!37 = !DILocation(line: 11, column: 21, scope: !31)
!38 = !DILocation(line: 12, column: 15, scope: !31)
!39 = distinct !DISubprogram(name: "support.elf.byte2", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte2.2", scope: !7, file: !7, line: 14, type: !8, scopeLine: 14, spFlags: DISPFlagDefinition, unit: !0)
!40 = !DILocalVariable(name: "bytes", arg: 1, scope: !39, file: !7, line: 14, type: !17)
!41 = !DILocation(line: 14, column: 14, scope: !39)
!42 = !DILocation(line: 15, column: 3, scope: !39)
!43 = !DILocation(line: 16, column: 10, scope: !39)
!44 = !DILocalVariable(name: "value", scope: !39, file: !7, line: 16, type: !10)
!45 = !DILocation(line: 16, column: 21, scope: !39)
!46 = !DILocation(line: 17, column: 15, scope: !39)
!47 = distinct !DISubprogram(name: "support.elf.byte3", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte3.3", scope: !7, file: !7, line: 19, type: !8, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !0)
!48 = !DILocalVariable(name: "bytes", arg: 1, scope: !47, file: !7, line: 19, type: !17)
!49 = !DILocation(line: 19, column: 14, scope: !47)
!50 = !DILocation(line: 20, column: 3, scope: !47)
!51 = !DILocation(line: 21, column: 10, scope: !47)
!52 = !DILocalVariable(name: "value", scope: !47, file: !7, line: 21, type: !10)
!53 = !DILocation(line: 21, column: 21, scope: !47)
!54 = !DILocation(line: 22, column: 15, scope: !47)
!55 = distinct !DISubprogram(name: "support.elf.word-four", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dfour.4", scope: !7, file: !7, line: 115, type: !56, scopeLine: 115, spFlags: DISPFlagDefinition, unit: !0)
!56 = !DISubroutineType(types: !57)
!57 = !{!10, !10, !10, !10, !10}
!58 = !DILocalVariable(name: "first", arg: 1, scope: !55, file: !7, line: 115, type: !10)
!59 = !DILocation(line: 115, column: 19, scope: !55)
!60 = !DILocalVariable(name: "second", arg: 2, scope: !55, file: !7, line: 115, type: !10)
!61 = !DILocation(line: 115, column: 32, scope: !55)
!62 = !DILocalVariable(name: "third", arg: 3, scope: !55, file: !7, line: 115, type: !10)
!63 = !DILocation(line: 115, column: 46, scope: !55)
!64 = !DILocalVariable(name: "fourth", arg: 4, scope: !55, file: !7, line: 115, type: !10)
!65 = !DILocation(line: 115, column: 59, scope: !55)
!66 = !DILocation(line: 116, column: 12, scope: !55)
!67 = !DILocation(line: 116, column: 3, scope: !55)
!68 = !DILocation(line: 116, column: 29, scope: !55)
!69 = !DILocation(line: 116, column: 47, scope: !55)
!70 = distinct !DISubprogram(name: "support.elf.read-magic", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dmagic.5", scope: !7, file: !7, line: 118, type: !8, scopeLine: 118, spFlags: DISPFlagDefinition, unit: !0)
!71 = !DILocalVariable(name: "bytes", arg: 1, scope: !70, file: !7, line: 118, type: !17)
!72 = !DILocation(line: 118, column: 19, scope: !70)
!73 = !DILocation(line: 119, column: 14, scope: !70)
!74 = !DILocation(line: 119, column: 27, scope: !70)
!75 = !DILocation(line: 119, column: 40, scope: !70)
!76 = !DILocation(line: 119, column: 53, scope: !70)
!77 = !DILocation(line: 119, column: 3, scope: !70)
!78 = distinct !DISubprogram(name: "support.elf.byte4", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte4.6", scope: !7, file: !7, line: 24, type: !8, scopeLine: 24, spFlags: DISPFlagDefinition, unit: !0)
!79 = !DILocalVariable(name: "bytes", arg: 1, scope: !78, file: !7, line: 24, type: !17)
!80 = !DILocation(line: 24, column: 14, scope: !78)
!81 = !DILocation(line: 25, column: 3, scope: !78)
!82 = !DILocation(line: 26, column: 10, scope: !78)
!83 = !DILocalVariable(name: "value", scope: !78, file: !7, line: 26, type: !10)
!84 = !DILocation(line: 26, column: 21, scope: !78)
!85 = !DILocation(line: 27, column: 15, scope: !78)
!86 = distinct !DISubprogram(name: "support.elf.byte5", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte5.7", scope: !7, file: !7, line: 29, type: !8, scopeLine: 29, spFlags: DISPFlagDefinition, unit: !0)
!87 = !DILocalVariable(name: "bytes", arg: 1, scope: !86, file: !7, line: 29, type: !17)
!88 = !DILocation(line: 29, column: 14, scope: !86)
!89 = !DILocation(line: 30, column: 3, scope: !86)
!90 = !DILocation(line: 31, column: 10, scope: !86)
!91 = !DILocalVariable(name: "value", scope: !86, file: !7, line: 31, type: !10)
!92 = !DILocation(line: 31, column: 21, scope: !86)
!93 = !DILocation(line: 32, column: 15, scope: !86)
!94 = distinct !DISubprogram(name: "support.elf.byte6", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte6.8", scope: !7, file: !7, line: 34, type: !8, scopeLine: 34, spFlags: DISPFlagDefinition, unit: !0)
!95 = !DILocalVariable(name: "bytes", arg: 1, scope: !94, file: !7, line: 34, type: !17)
!96 = !DILocation(line: 34, column: 14, scope: !94)
!97 = !DILocation(line: 35, column: 3, scope: !94)
!98 = !DILocation(line: 36, column: 10, scope: !94)
!99 = !DILocalVariable(name: "value", scope: !94, file: !7, line: 36, type: !10)
!100 = !DILocation(line: 36, column: 21, scope: !94)
!101 = !DILocation(line: 37, column: 15, scope: !94)
!102 = distinct !DISubprogram(name: "support.elf.word-three", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dthree.9", scope: !7, file: !7, line: 112, type: !103, scopeLine: 112, spFlags: DISPFlagDefinition, unit: !0)
!103 = !DISubroutineType(types: !104)
!104 = !{!10, !10, !10, !10}
!105 = !DILocalVariable(name: "low", arg: 1, scope: !102, file: !7, line: 112, type: !10)
!106 = !DILocation(line: 112, column: 20, scope: !102)
!107 = !DILocalVariable(name: "middle", arg: 2, scope: !102, file: !7, line: 112, type: !10)
!108 = !DILocation(line: 112, column: 31, scope: !102)
!109 = !DILocalVariable(name: "high", arg: 3, scope: !102, file: !7, line: 112, type: !10)
!110 = !DILocation(line: 112, column: 45, scope: !102)
!111 = !DILocation(line: 113, column: 10, scope: !102)
!112 = !DILocation(line: 113, column: 3, scope: !102)
!113 = !DILocation(line: 113, column: 27, scope: !102)
!114 = distinct !DISubprogram(name: "support.elf.read-ident", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dident.10", scope: !7, file: !7, line: 121, type: !8, scopeLine: 121, spFlags: DISPFlagDefinition, unit: !0)
!115 = !DILocalVariable(name: "bytes", arg: 1, scope: !114, file: !7, line: 121, type: !17)
!116 = !DILocation(line: 121, column: 19, scope: !114)
!117 = !DILocation(line: 122, column: 15, scope: !114)
!118 = !DILocation(line: 122, column: 28, scope: !114)
!119 = !DILocation(line: 122, column: 41, scope: !114)
!120 = !DILocation(line: 122, column: 3, scope: !114)
!121 = distinct !DISubprogram(name: "support.elf.byte16", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte16.11", scope: !7, file: !7, line: 39, type: !8, scopeLine: 39, spFlags: DISPFlagDefinition, unit: !0)
!122 = !DILocalVariable(name: "bytes", arg: 1, scope: !121, file: !7, line: 39, type: !17)
!123 = !DILocation(line: 39, column: 15, scope: !121)
!124 = !DILocation(line: 40, column: 3, scope: !121)
!125 = !DILocation(line: 41, column: 10, scope: !121)
!126 = !DILocalVariable(name: "value", scope: !121, file: !7, line: 41, type: !10)
!127 = !DILocation(line: 41, column: 21, scope: !121)
!128 = !DILocation(line: 42, column: 15, scope: !121)
!129 = distinct !DISubprogram(name: "support.elf.byte17", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte17.12", scope: !7, file: !7, line: 44, type: !8, scopeLine: 44, spFlags: DISPFlagDefinition, unit: !0)
!130 = !DILocalVariable(name: "bytes", arg: 1, scope: !129, file: !7, line: 44, type: !17)
!131 = !DILocation(line: 44, column: 15, scope: !129)
!132 = !DILocation(line: 45, column: 3, scope: !129)
!133 = !DILocation(line: 46, column: 10, scope: !129)
!134 = !DILocalVariable(name: "value", scope: !129, file: !7, line: 46, type: !10)
!135 = !DILocation(line: 46, column: 21, scope: !129)
!136 = !DILocation(line: 47, column: 15, scope: !129)
!137 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.13", scope: !7, file: !7, line: 109, type: !138, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !0)
!138 = !DISubroutineType(types: !139)
!139 = !{!10, !10, !10}
!140 = !DILocalVariable(name: "low", arg: 1, scope: !137, file: !7, line: 109, type: !10)
!141 = !DILocation(line: 109, column: 18, scope: !137)
!142 = !DILocalVariable(name: "high", arg: 2, scope: !137, file: !7, line: 109, type: !10)
!143 = !DILocation(line: 109, column: 29, scope: !137)
!144 = !DILocation(line: 110, column: 10, scope: !137)
!145 = !DILocation(line: 110, column: 3, scope: !137)
!146 = distinct !DISubprogram(name: "support.elf.read-type", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dtype.14", scope: !7, file: !7, line: 124, type: !8, scopeLine: 124, spFlags: DISPFlagDefinition, unit: !0)
!147 = !DILocalVariable(name: "bytes", arg: 1, scope: !146, file: !7, line: 124, type: !17)
!148 = !DILocation(line: 124, column: 18, scope: !146)
!149 = !DILocation(line: 125, column: 13, scope: !146)
!150 = !DILocation(line: 125, column: 27, scope: !146)
!151 = !DILocation(line: 125, column: 3, scope: !146)
!152 = distinct !DISubprogram(name: "support.elf.byte18", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte18.15", scope: !7, file: !7, line: 49, type: !8, scopeLine: 49, spFlags: DISPFlagDefinition, unit: !0)
!153 = !DILocalVariable(name: "bytes", arg: 1, scope: !152, file: !7, line: 49, type: !17)
!154 = !DILocation(line: 49, column: 15, scope: !152)
!155 = !DILocation(line: 50, column: 3, scope: !152)
!156 = !DILocation(line: 51, column: 10, scope: !152)
!157 = !DILocalVariable(name: "value", scope: !152, file: !7, line: 51, type: !10)
!158 = !DILocation(line: 51, column: 21, scope: !152)
!159 = !DILocation(line: 52, column: 15, scope: !152)
!160 = distinct !DISubprogram(name: "support.elf.byte19", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte19.16", scope: !7, file: !7, line: 54, type: !8, scopeLine: 54, spFlags: DISPFlagDefinition, unit: !0)
!161 = !DILocalVariable(name: "bytes", arg: 1, scope: !160, file: !7, line: 54, type: !17)
!162 = !DILocation(line: 54, column: 15, scope: !160)
!163 = !DILocation(line: 55, column: 3, scope: !160)
!164 = !DILocation(line: 56, column: 10, scope: !160)
!165 = !DILocalVariable(name: "value", scope: !160, file: !7, line: 56, type: !10)
!166 = !DILocation(line: 56, column: 21, scope: !160)
!167 = !DILocation(line: 57, column: 15, scope: !160)
!168 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.17", scope: !7, file: !7, line: 109, type: !138, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !0)
!169 = !DILocalVariable(name: "low", arg: 1, scope: !168, file: !7, line: 109, type: !10)
!170 = !DILocation(line: 109, column: 18, scope: !168)
!171 = !DILocalVariable(name: "high", arg: 2, scope: !168, file: !7, line: 109, type: !10)
!172 = !DILocation(line: 109, column: 29, scope: !168)
!173 = !DILocation(line: 110, column: 10, scope: !168)
!174 = !DILocation(line: 110, column: 3, scope: !168)
!175 = distinct !DISubprogram(name: "support.elf.read-machine", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dmachine.18", scope: !7, file: !7, line: 127, type: !8, scopeLine: 127, spFlags: DISPFlagDefinition, unit: !0)
!176 = !DILocalVariable(name: "bytes", arg: 1, scope: !175, file: !7, line: 127, type: !17)
!177 = !DILocation(line: 127, column: 21, scope: !175)
!178 = !DILocation(line: 128, column: 13, scope: !175)
!179 = !DILocation(line: 128, column: 27, scope: !175)
!180 = !DILocation(line: 128, column: 3, scope: !175)
!181 = distinct !DISubprogram(name: "support.elf.byte20", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte20.19", scope: !7, file: !7, line: 59, type: !8, scopeLine: 59, spFlags: DISPFlagDefinition, unit: !0)
!182 = !DILocalVariable(name: "bytes", arg: 1, scope: !181, file: !7, line: 59, type: !17)
!183 = !DILocation(line: 59, column: 15, scope: !181)
!184 = !DILocation(line: 60, column: 3, scope: !181)
!185 = !DILocation(line: 61, column: 10, scope: !181)
!186 = !DILocalVariable(name: "value", scope: !181, file: !7, line: 61, type: !10)
!187 = !DILocation(line: 61, column: 21, scope: !181)
!188 = !DILocation(line: 62, column: 15, scope: !181)
!189 = distinct !DISubprogram(name: "support.elf.byte21", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte21.20", scope: !7, file: !7, line: 64, type: !8, scopeLine: 64, spFlags: DISPFlagDefinition, unit: !0)
!190 = !DILocalVariable(name: "bytes", arg: 1, scope: !189, file: !7, line: 64, type: !17)
!191 = !DILocation(line: 64, column: 15, scope: !189)
!192 = !DILocation(line: 65, column: 3, scope: !189)
!193 = !DILocation(line: 66, column: 10, scope: !189)
!194 = !DILocalVariable(name: "value", scope: !189, file: !7, line: 66, type: !10)
!195 = !DILocation(line: 66, column: 21, scope: !189)
!196 = !DILocation(line: 67, column: 15, scope: !189)
!197 = distinct !DISubprogram(name: "support.elf.byte22", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte22.21", scope: !7, file: !7, line: 69, type: !8, scopeLine: 69, spFlags: DISPFlagDefinition, unit: !0)
!198 = !DILocalVariable(name: "bytes", arg: 1, scope: !197, file: !7, line: 69, type: !17)
!199 = !DILocation(line: 69, column: 15, scope: !197)
!200 = !DILocation(line: 70, column: 3, scope: !197)
!201 = !DILocation(line: 71, column: 10, scope: !197)
!202 = !DILocalVariable(name: "value", scope: !197, file: !7, line: 71, type: !10)
!203 = !DILocation(line: 71, column: 21, scope: !197)
!204 = !DILocation(line: 72, column: 15, scope: !197)
!205 = distinct !DISubprogram(name: "support.elf.byte23", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte23.22", scope: !7, file: !7, line: 74, type: !8, scopeLine: 74, spFlags: DISPFlagDefinition, unit: !0)
!206 = !DILocalVariable(name: "bytes", arg: 1, scope: !205, file: !7, line: 74, type: !17)
!207 = !DILocation(line: 74, column: 15, scope: !205)
!208 = !DILocation(line: 75, column: 3, scope: !205)
!209 = !DILocation(line: 76, column: 10, scope: !205)
!210 = !DILocalVariable(name: "value", scope: !205, file: !7, line: 76, type: !10)
!211 = !DILocation(line: 76, column: 21, scope: !205)
!212 = !DILocation(line: 77, column: 15, scope: !205)
!213 = distinct !DISubprogram(name: "support.elf.word-four", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dfour.23", scope: !7, file: !7, line: 115, type: !56, scopeLine: 115, spFlags: DISPFlagDefinition, unit: !0)
!214 = !DILocalVariable(name: "first", arg: 1, scope: !213, file: !7, line: 115, type: !10)
!215 = !DILocation(line: 115, column: 19, scope: !213)
!216 = !DILocalVariable(name: "second", arg: 2, scope: !213, file: !7, line: 115, type: !10)
!217 = !DILocation(line: 115, column: 32, scope: !213)
!218 = !DILocalVariable(name: "third", arg: 3, scope: !213, file: !7, line: 115, type: !10)
!219 = !DILocation(line: 115, column: 46, scope: !213)
!220 = !DILocalVariable(name: "fourth", arg: 4, scope: !213, file: !7, line: 115, type: !10)
!221 = !DILocation(line: 115, column: 59, scope: !213)
!222 = !DILocation(line: 116, column: 12, scope: !213)
!223 = !DILocation(line: 116, column: 3, scope: !213)
!224 = !DILocation(line: 116, column: 29, scope: !213)
!225 = !DILocation(line: 116, column: 47, scope: !213)
!226 = distinct !DISubprogram(name: "support.elf.read-version", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dversion.24", scope: !7, file: !7, line: 130, type: !8, scopeLine: 130, spFlags: DISPFlagDefinition, unit: !0)
!227 = !DILocalVariable(name: "bytes", arg: 1, scope: !226, file: !7, line: 130, type: !17)
!228 = !DILocation(line: 130, column: 21, scope: !226)
!229 = !DILocation(line: 131, column: 14, scope: !226)
!230 = !DILocation(line: 131, column: 28, scope: !226)
!231 = !DILocation(line: 131, column: 42, scope: !226)
!232 = !DILocation(line: 131, column: 56, scope: !226)
!233 = !DILocation(line: 131, column: 3, scope: !226)
!234 = distinct !DISubprogram(name: "support.elf.byte52", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte52.25", scope: !7, file: !7, line: 79, type: !8, scopeLine: 79, spFlags: DISPFlagDefinition, unit: !0)
!235 = !DILocalVariable(name: "bytes", arg: 1, scope: !234, file: !7, line: 79, type: !17)
!236 = !DILocation(line: 79, column: 15, scope: !234)
!237 = !DILocation(line: 80, column: 3, scope: !234)
!238 = !DILocation(line: 81, column: 10, scope: !234)
!239 = !DILocalVariable(name: "value", scope: !234, file: !7, line: 81, type: !10)
!240 = !DILocation(line: 81, column: 21, scope: !234)
!241 = !DILocation(line: 82, column: 15, scope: !234)
!242 = distinct !DISubprogram(name: "support.elf.byte53", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte53.26", scope: !7, file: !7, line: 84, type: !8, scopeLine: 84, spFlags: DISPFlagDefinition, unit: !0)
!243 = !DILocalVariable(name: "bytes", arg: 1, scope: !242, file: !7, line: 84, type: !17)
!244 = !DILocation(line: 84, column: 15, scope: !242)
!245 = !DILocation(line: 85, column: 3, scope: !242)
!246 = !DILocation(line: 86, column: 10, scope: !242)
!247 = !DILocalVariable(name: "value", scope: !242, file: !7, line: 86, type: !10)
!248 = !DILocation(line: 86, column: 21, scope: !242)
!249 = !DILocation(line: 87, column: 15, scope: !242)
!250 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.27", scope: !7, file: !7, line: 109, type: !138, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !0)
!251 = !DILocalVariable(name: "low", arg: 1, scope: !250, file: !7, line: 109, type: !10)
!252 = !DILocation(line: 109, column: 18, scope: !250)
!253 = !DILocalVariable(name: "high", arg: 2, scope: !250, file: !7, line: 109, type: !10)
!254 = !DILocation(line: 109, column: 29, scope: !250)
!255 = !DILocation(line: 110, column: 10, scope: !250)
!256 = !DILocation(line: 110, column: 3, scope: !250)
!257 = distinct !DISubprogram(name: "support.elf.read-header-size", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dheader_2dsize.28", scope: !7, file: !7, line: 133, type: !8, scopeLine: 133, spFlags: DISPFlagDefinition, unit: !0)
!258 = !DILocalVariable(name: "bytes", arg: 1, scope: !257, file: !7, line: 133, type: !17)
!259 = !DILocation(line: 133, column: 25, scope: !257)
!260 = !DILocation(line: 134, column: 13, scope: !257)
!261 = !DILocation(line: 134, column: 27, scope: !257)
!262 = !DILocation(line: 134, column: 3, scope: !257)
!263 = distinct !DISubprogram(name: "support.elf.byte54", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte54.29", scope: !7, file: !7, line: 89, type: !8, scopeLine: 89, spFlags: DISPFlagDefinition, unit: !0)
!264 = !DILocalVariable(name: "bytes", arg: 1, scope: !263, file: !7, line: 89, type: !17)
!265 = !DILocation(line: 89, column: 15, scope: !263)
!266 = !DILocation(line: 90, column: 3, scope: !263)
!267 = !DILocation(line: 91, column: 10, scope: !263)
!268 = !DILocalVariable(name: "value", scope: !263, file: !7, line: 91, type: !10)
!269 = !DILocation(line: 91, column: 21, scope: !263)
!270 = !DILocation(line: 92, column: 15, scope: !263)
!271 = distinct !DISubprogram(name: "support.elf.byte55", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte55.30", scope: !7, file: !7, line: 94, type: !8, scopeLine: 94, spFlags: DISPFlagDefinition, unit: !0)
!272 = !DILocalVariable(name: "bytes", arg: 1, scope: !271, file: !7, line: 94, type: !17)
!273 = !DILocation(line: 94, column: 15, scope: !271)
!274 = !DILocation(line: 95, column: 3, scope: !271)
!275 = !DILocation(line: 96, column: 10, scope: !271)
!276 = !DILocalVariable(name: "value", scope: !271, file: !7, line: 96, type: !10)
!277 = !DILocation(line: 96, column: 21, scope: !271)
!278 = !DILocation(line: 97, column: 15, scope: !271)
!279 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.31", scope: !7, file: !7, line: 109, type: !138, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !0)
!280 = !DILocalVariable(name: "low", arg: 1, scope: !279, file: !7, line: 109, type: !10)
!281 = !DILocation(line: 109, column: 18, scope: !279)
!282 = !DILocalVariable(name: "high", arg: 2, scope: !279, file: !7, line: 109, type: !10)
!283 = !DILocation(line: 109, column: 29, scope: !279)
!284 = !DILocation(line: 110, column: 10, scope: !279)
!285 = !DILocation(line: 110, column: 3, scope: !279)
!286 = distinct !DISubprogram(name: "support.elf.read-entry-size", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dentry_2dsize.32", scope: !7, file: !7, line: 136, type: !8, scopeLine: 136, spFlags: DISPFlagDefinition, unit: !0)
!287 = !DILocalVariable(name: "bytes", arg: 1, scope: !286, file: !7, line: 136, type: !17)
!288 = !DILocation(line: 136, column: 24, scope: !286)
!289 = !DILocation(line: 137, column: 13, scope: !286)
!290 = !DILocation(line: 137, column: 27, scope: !286)
!291 = !DILocation(line: 137, column: 3, scope: !286)
!292 = distinct !DISubprogram(name: "support.elf.byte56", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte56.33", scope: !7, file: !7, line: 99, type: !8, scopeLine: 99, spFlags: DISPFlagDefinition, unit: !0)
!293 = !DILocalVariable(name: "bytes", arg: 1, scope: !292, file: !7, line: 99, type: !17)
!294 = !DILocation(line: 99, column: 15, scope: !292)
!295 = !DILocation(line: 100, column: 3, scope: !292)
!296 = !DILocation(line: 101, column: 10, scope: !292)
!297 = !DILocalVariable(name: "value", scope: !292, file: !7, line: 101, type: !10)
!298 = !DILocation(line: 101, column: 21, scope: !292)
!299 = !DILocation(line: 102, column: 15, scope: !292)
!300 = distinct !DISubprogram(name: "support.elf.byte57", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte57.34", scope: !7, file: !7, line: 104, type: !8, scopeLine: 104, spFlags: DISPFlagDefinition, unit: !0)
!301 = !DILocalVariable(name: "bytes", arg: 1, scope: !300, file: !7, line: 104, type: !17)
!302 = !DILocation(line: 104, column: 15, scope: !300)
!303 = !DILocation(line: 105, column: 3, scope: !300)
!304 = !DILocation(line: 106, column: 10, scope: !300)
!305 = !DILocalVariable(name: "value", scope: !300, file: !7, line: 106, type: !10)
!306 = !DILocation(line: 106, column: 21, scope: !300)
!307 = !DILocation(line: 107, column: 15, scope: !300)
!308 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.35", scope: !7, file: !7, line: 109, type: !138, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !0)
!309 = !DILocalVariable(name: "low", arg: 1, scope: !308, file: !7, line: 109, type: !10)
!310 = !DILocation(line: 109, column: 18, scope: !308)
!311 = !DILocalVariable(name: "high", arg: 2, scope: !308, file: !7, line: 109, type: !10)
!312 = !DILocation(line: 109, column: 29, scope: !308)
!313 = !DILocation(line: 110, column: 10, scope: !308)
!314 = !DILocation(line: 110, column: 3, scope: !308)
!315 = distinct !DISubprogram(name: "support.elf.read-count", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dcount.36", scope: !7, file: !7, line: 139, type: !8, scopeLine: 139, spFlags: DISPFlagDefinition, unit: !0)
!316 = !DILocalVariable(name: "bytes", arg: 1, scope: !315, file: !7, line: 139, type: !17)
!317 = !DILocation(line: 139, column: 19, scope: !315)
!318 = !DILocation(line: 140, column: 13, scope: !315)
!319 = !DILocation(line: 140, column: 27, scope: !315)
!320 = !DILocation(line: 140, column: 3, scope: !315)
!321 = distinct !DISubprogram(name: "support.elf.check-count", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dcount.37", scope: !7, file: !7, line: 142, type: !322, scopeLine: 142, spFlags: DISPFlagDefinition, unit: !0)
!322 = !DISubroutineType(types: !323)
!323 = !{!324, !17, !325, !325}
!324 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!325 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !11)
!326 = !DILocalVariable(name: "bytes", arg: 1, scope: !321, file: !7, line: 142, type: !17)
!327 = !DILocation(line: 142, column: 21, scope: !321)
!328 = !DILocalVariable(name: "machine", arg: 2, scope: !321, file: !7, line: 142, type: !325)
!329 = !DILocation(line: 142, column: 46, scope: !321)
!330 = !DILocalVariable(name: "maximum", arg: 3, scope: !321, file: !7, line: 142, type: !325)
!331 = !DILocation(line: 142, column: 61, scope: !321)
!332 = !DILocation(line: 143, column: 12, scope: !321)
!333 = !DILocalVariable(name: "count", scope: !321, file: !7, line: 143, type: !10)
!334 = !DILocation(line: 143, column: 3, scope: !321)
!335 = !DILocation(line: 144, column: 3, scope: !321)
!336 = !DILocation(line: 145, column: 15, scope: !321)
!337 = !DILocation(line: 146, column: 16, scope: !321)
!338 = distinct !DISubprogram(name: "support.elf.check-entry-size", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dentry_2dsize.38", scope: !7, file: !7, line: 148, type: !322, scopeLine: 148, spFlags: DISPFlagDefinition, unit: !0)
!339 = !DILocalVariable(name: "bytes", arg: 1, scope: !338, file: !7, line: 148, type: !17)
!340 = !DILocation(line: 148, column: 26, scope: !338)
!341 = !DILocalVariable(name: "machine", arg: 2, scope: !338, file: !7, line: 148, type: !325)
!342 = !DILocation(line: 148, column: 51, scope: !338)
!343 = !DILocalVariable(name: "maximum", arg: 3, scope: !338, file: !7, line: 148, type: !325)
!344 = !DILocation(line: 148, column: 66, scope: !338)
!345 = !DILocation(line: 149, column: 12, scope: !338)
!346 = !DILocalVariable(name: "value", scope: !338, file: !7, line: 149, type: !10)
!347 = !DILocation(line: 149, column: 3, scope: !338)
!348 = !DILocation(line: 150, column: 3, scope: !338)
!349 = !DILocation(line: 151, column: 15, scope: !338)
!350 = !DILocation(line: 152, column: 16, scope: !338)
!351 = distinct !DISubprogram(name: "support.elf.check-header-size", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dheader_2dsize.39", scope: !7, file: !7, line: 154, type: !322, scopeLine: 154, spFlags: DISPFlagDefinition, unit: !0)
!352 = !DILocalVariable(name: "bytes", arg: 1, scope: !351, file: !7, line: 154, type: !17)
!353 = !DILocation(line: 154, column: 27, scope: !351)
!354 = !DILocalVariable(name: "machine", arg: 2, scope: !351, file: !7, line: 154, type: !325)
!355 = !DILocation(line: 154, column: 52, scope: !351)
!356 = !DILocalVariable(name: "maximum", arg: 3, scope: !351, file: !7, line: 154, type: !325)
!357 = !DILocation(line: 154, column: 67, scope: !351)
!358 = !DILocation(line: 155, column: 12, scope: !351)
!359 = !DILocalVariable(name: "value", scope: !351, file: !7, line: 155, type: !10)
!360 = !DILocation(line: 155, column: 3, scope: !351)
!361 = !DILocation(line: 156, column: 3, scope: !351)
!362 = !DILocation(line: 157, column: 15, scope: !351)
!363 = !DILocation(line: 158, column: 16, scope: !351)
!364 = distinct !DISubprogram(name: "support.elf.check-version", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dversion.40", scope: !7, file: !7, line: 160, type: !322, scopeLine: 160, spFlags: DISPFlagDefinition, unit: !0)
!365 = !DILocalVariable(name: "bytes", arg: 1, scope: !364, file: !7, line: 160, type: !17)
!366 = !DILocation(line: 160, column: 23, scope: !364)
!367 = !DILocalVariable(name: "machine", arg: 2, scope: !364, file: !7, line: 160, type: !325)
!368 = !DILocation(line: 160, column: 48, scope: !364)
!369 = !DILocalVariable(name: "maximum", arg: 3, scope: !364, file: !7, line: 160, type: !325)
!370 = !DILocation(line: 160, column: 63, scope: !364)
!371 = !DILocation(line: 161, column: 12, scope: !364)
!372 = !DILocalVariable(name: "value", scope: !364, file: !7, line: 161, type: !10)
!373 = !DILocation(line: 161, column: 3, scope: !364)
!374 = !DILocation(line: 162, column: 3, scope: !364)
!375 = !DILocation(line: 163, column: 15, scope: !364)
!376 = !DILocation(line: 164, column: 16, scope: !364)
!377 = distinct !DISubprogram(name: "support.elf.check-machine", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dmachine.41", scope: !7, file: !7, line: 166, type: !322, scopeLine: 166, spFlags: DISPFlagDefinition, unit: !0)
!378 = !DILocalVariable(name: "bytes", arg: 1, scope: !377, file: !7, line: 166, type: !17)
!379 = !DILocation(line: 166, column: 23, scope: !377)
!380 = !DILocalVariable(name: "machine", arg: 2, scope: !377, file: !7, line: 166, type: !325)
!381 = !DILocation(line: 166, column: 48, scope: !377)
!382 = !DILocalVariable(name: "maximum", arg: 3, scope: !377, file: !7, line: 166, type: !325)
!383 = !DILocation(line: 166, column: 63, scope: !377)
!384 = !DILocation(line: 167, column: 12, scope: !377)
!385 = !DILocalVariable(name: "value", scope: !377, file: !7, line: 167, type: !10)
!386 = !DILocation(line: 167, column: 3, scope: !377)
!387 = !DILocation(line: 168, column: 3, scope: !377)
!388 = !DILocation(line: 169, column: 15, scope: !377)
!389 = !DILocation(line: 170, column: 16, scope: !377)
!390 = distinct !DISubprogram(name: "support.elf.check-type", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dtype.42", scope: !7, file: !7, line: 172, type: !322, scopeLine: 172, spFlags: DISPFlagDefinition, unit: !0)
!391 = !DILocalVariable(name: "bytes", arg: 1, scope: !390, file: !7, line: 172, type: !17)
!392 = !DILocation(line: 172, column: 20, scope: !390)
!393 = !DILocalVariable(name: "machine", arg: 2, scope: !390, file: !7, line: 172, type: !325)
!394 = !DILocation(line: 172, column: 45, scope: !390)
!395 = !DILocalVariable(name: "maximum", arg: 3, scope: !390, file: !7, line: 172, type: !325)
!396 = !DILocation(line: 172, column: 60, scope: !390)
!397 = !DILocation(line: 173, column: 12, scope: !390)
!398 = !DILocalVariable(name: "value", scope: !390, file: !7, line: 173, type: !10)
!399 = !DILocation(line: 173, column: 3, scope: !390)
!400 = !DILocation(line: 174, column: 3, scope: !390)
!401 = !DILocation(line: 175, column: 15, scope: !390)
!402 = !DILocation(line: 176, column: 16, scope: !390)
!403 = distinct !DISubprogram(name: "support.elf.check-ident", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dident.43", scope: !7, file: !7, line: 178, type: !322, scopeLine: 178, spFlags: DISPFlagDefinition, unit: !0)
!404 = !DILocalVariable(name: "bytes", arg: 1, scope: !403, file: !7, line: 178, type: !17)
!405 = !DILocation(line: 178, column: 21, scope: !403)
!406 = !DILocalVariable(name: "machine", arg: 2, scope: !403, file: !7, line: 178, type: !325)
!407 = !DILocation(line: 178, column: 46, scope: !403)
!408 = !DILocalVariable(name: "maximum", arg: 3, scope: !403, file: !7, line: 178, type: !325)
!409 = !DILocation(line: 178, column: 61, scope: !403)
!410 = !DILocation(line: 179, column: 12, scope: !403)
!411 = !DILocalVariable(name: "value", scope: !403, file: !7, line: 179, type: !10)
!412 = !DILocation(line: 179, column: 3, scope: !403)
!413 = !DILocation(line: 180, column: 3, scope: !403)
!414 = !DILocation(line: 181, column: 15, scope: !403)
!415 = !DILocation(line: 182, column: 16, scope: !403)
!416 = distinct !DISubprogram(name: "support.elf.admitted?", linkageName: "topal.header.topal.fn.support_2eelf_2eadmitted_3f.44", scope: !7, file: !7, line: 184, type: !322, scopeLine: 184, spFlags: DISPFlagDefinition, unit: !0)
!417 = !DILocalVariable(name: "bytes", arg: 1, scope: !416, file: !7, line: 184, type: !17)
!418 = !DILocation(line: 184, column: 23, scope: !416)
!419 = !DILocalVariable(name: "machine", arg: 2, scope: !416, file: !7, line: 184, type: !325)
!420 = !DILocation(line: 184, column: 48, scope: !416)
!421 = !DILocalVariable(name: "maximum", arg: 3, scope: !416, file: !7, line: 184, type: !325)
!422 = !DILocation(line: 184, column: 63, scope: !416)
!423 = !DILocation(line: 185, column: 12, scope: !416)
!424 = !DILocalVariable(name: "magic", scope: !416, file: !7, line: 185, type: !10)
!425 = !DILocation(line: 185, column: 3, scope: !416)
!426 = !DILocation(line: 186, column: 3, scope: !416)
!427 = !DILocation(line: 187, column: 15, scope: !416)
!428 = !DILocation(line: 188, column: 16, scope: !416)
!429 = distinct !DISubprogram(name: "header-admitted?", linkageName: "topal.header.topal.fn.header_2dadmitted_3f.45", scope: !1, file: !1, line: 4, type: !322, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !0)
!430 = !DILocalVariable(name: "bytes", arg: 1, scope: !429, file: !1, line: 4, type: !17)
!431 = !DILocation(line: 4, column: 30, scope: !429)
!432 = !DILocalVariable(name: "machine", arg: 2, scope: !429, file: !1, line: 4, type: !325)
!433 = !DILocation(line: 4, column: 55, scope: !429)
!434 = !DILocalVariable(name: "maximum", arg: 3, scope: !429, file: !1, line: 4, type: !325)
!435 = !DILocation(line: 4, column: 70, scope: !429)
!436 = !DILocation(line: 5, column: 3, scope: !429)
