target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"
@topal_x86_tail_boundary_active_v1 = external dso_local global ptr
define internal i1 @o.geometry(ptr %owner, i64 %count, ptr %input, ptr %history, ptr %private, ptr %stack, ptr %output) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %s0 = ptrtoint ptr %owner to i64
  %e0 = add i64 %s0, %count
  %n0 = icmp ne i64 %s0, 0
  %w0 = icmp uge i64 %e0, %s0
  %a0 = and i64 %s0, 0
  %b0 = icmp eq i64 %a0, 0
  %s1 = ptrtoint ptr %input to i64
  %e1 = add i64 %s1, 24
  %n1 = icmp ne i64 %s1, 0
  %w1 = icmp uge i64 %e1, %s1
  %a1 = and i64 %s1, 7
  %b1 = icmp eq i64 %a1, 0
  %l0_1 = icmp ule i64 %e0, %s1
  %r0_1 = icmp ule i64 %e1, %s0
  %d0_1 = or i1 %l0_1, %r0_1
  %s2 = ptrtoint ptr %history to i64
  %e2 = add i64 %s2, 40
  %n2 = icmp ne i64 %s2, 0
  %w2 = icmp uge i64 %e2, %s2
  %a2 = and i64 %s2, 7
  %b2 = icmp eq i64 %a2, 0
  %l0_2 = icmp ule i64 %e0, %s2
  %r0_2 = icmp ule i64 %e2, %s0
  %d0_2 = or i1 %l0_2, %r0_2
  %l1_2 = icmp ule i64 %e1, %s2
  %r1_2 = icmp ule i64 %e2, %s1
  %d1_2 = or i1 %l1_2, %r1_2
  %s3 = ptrtoint ptr %private to i64
  %e3 = add i64 %s3, 65528
  %n3 = icmp ne i64 %s3, 0
  %w3 = icmp uge i64 %e3, %s3
  %a3 = and i64 %s3, 15
  %b3 = icmp eq i64 %a3, 0
  %l0_3 = icmp ule i64 %e0, %s3
  %r0_3 = icmp ule i64 %e3, %s0
  %d0_3 = or i1 %l0_3, %r0_3
  %l1_3 = icmp ule i64 %e1, %s3
  %r1_3 = icmp ule i64 %e3, %s1
  %d1_3 = or i1 %l1_3, %r1_3
  %l2_3 = icmp ule i64 %e2, %s3
  %r2_3 = icmp ule i64 %e3, %s2
  %d2_3 = or i1 %l2_3, %r2_3
  %s4 = ptrtoint ptr %stack to i64
  %e4 = add i64 %s4, 4096
  %n4 = icmp ne i64 %s4, 0
  %w4 = icmp uge i64 %e4, %s4
  %a4 = and i64 %s4, 15
  %b4 = icmp eq i64 %a4, 0
  %l0_4 = icmp ule i64 %e0, %s4
  %r0_4 = icmp ule i64 %e4, %s0
  %d0_4 = or i1 %l0_4, %r0_4
  %l1_4 = icmp ule i64 %e1, %s4
  %r1_4 = icmp ule i64 %e4, %s1
  %d1_4 = or i1 %l1_4, %r1_4
  %l2_4 = icmp ule i64 %e2, %s4
  %r2_4 = icmp ule i64 %e4, %s2
  %d2_4 = or i1 %l2_4, %r2_4
  %l3_4 = icmp ule i64 %e3, %s4
  %r3_4 = icmp ule i64 %e4, %s3
  %d3_4 = or i1 %l3_4, %r3_4
  %s5 = ptrtoint ptr %output to i64
  %e5 = add i64 %s5, 56
  %n5 = icmp ne i64 %s5, 0
  %w5 = icmp uge i64 %e5, %s5
  %a5 = and i64 %s5, 7
  %b5 = icmp eq i64 %a5, 0
  %l0_5 = icmp ule i64 %e0, %s5
  %r0_5 = icmp ule i64 %e5, %s0
  %d0_5 = or i1 %l0_5, %r0_5
  %l1_5 = icmp ule i64 %e1, %s5
  %r1_5 = icmp ule i64 %e5, %s1
  %d1_5 = or i1 %l1_5, %r1_5
  %l2_5 = icmp ule i64 %e2, %s5
  %r2_5 = icmp ule i64 %e5, %s2
  %d2_5 = or i1 %l2_5, %r2_5
  %l3_5 = icmp ule i64 %e3, %s5
  %r3_5 = icmp ule i64 %e5, %s3
  %d3_5 = or i1 %l3_5, %r3_5
  %l4_5 = icmp ule i64 %e4, %s5
  %r4_5 = icmp ule i64 %e5, %s4
  %d4_5 = or i1 %l4_5, %r4_5
  %s6 = ptrtoint ptr @topal_x86_tail_boundary_active_v1 to i64
  %e6 = add i64 %s6, 8
  %n6 = icmp ne i64 %s6, 0
  %w6 = icmp uge i64 %e6, %s6
  %a6 = and i64 %s6, 7
  %b6 = icmp eq i64 %a6, 0
  %l0_6 = icmp ule i64 %e0, %s6
  %r0_6 = icmp ule i64 %e6, %s0
  %d0_6 = or i1 %l0_6, %r0_6
  %l1_6 = icmp ule i64 %e1, %s6
  %r1_6 = icmp ule i64 %e6, %s1
  %d1_6 = or i1 %l1_6, %r1_6
  %l2_6 = icmp ule i64 %e2, %s6
  %r2_6 = icmp ule i64 %e6, %s2
  %d2_6 = or i1 %l2_6, %r2_6
  %l3_6 = icmp ule i64 %e3, %s6
  %r3_6 = icmp ule i64 %e6, %s3
  %d3_6 = or i1 %l3_6, %r3_6
  %l4_6 = icmp ule i64 %e4, %s6
  %r4_6 = icmp ule i64 %e6, %s4
  %d4_6 = or i1 %l4_6, %r4_6
  %l5_6 = icmp ule i64 %e5, %s6
  %r5_6 = icmp ule i64 %e6, %s5
  %d5_6 = or i1 %l5_6, %r5_6
  %nonempty = icmp ugt i64 %count, 0
  %t0 = and i1 %nonempty, %n0
  %t1 = and i1 %t0, %w0
  %t2 = and i1 %t1, %b0
  %t3 = and i1 %t2, %n1
  %t4 = and i1 %t3, %w1
  %t5 = and i1 %t4, %b1
  %t6 = and i1 %t5, %d0_1
  %t7 = and i1 %t6, %n2
  %t8 = and i1 %t7, %w2
  %t9 = and i1 %t8, %b2
  %t10 = and i1 %t9, %d0_2
  %t11 = and i1 %t10, %d1_2
  %t12 = and i1 %t11, %n3
  %t13 = and i1 %t12, %w3
  %t14 = and i1 %t13, %b3
  %t15 = and i1 %t14, %d0_3
  %t16 = and i1 %t15, %d1_3
  %t17 = and i1 %t16, %d2_3
  %t18 = and i1 %t17, %n4
  %t19 = and i1 %t18, %w4
  %t20 = and i1 %t19, %b4
  %t21 = and i1 %t20, %d0_4
  %t22 = and i1 %t21, %d1_4
  %t23 = and i1 %t22, %d2_4
  %t24 = and i1 %t23, %d3_4
  %t25 = and i1 %t24, %n5
  %t26 = and i1 %t25, %w5
  %t27 = and i1 %t26, %b5
  %t28 = and i1 %t27, %d0_5
  %t29 = and i1 %t28, %d1_5
  %t30 = and i1 %t29, %d2_5
  %t31 = and i1 %t30, %d3_5
  %t32 = and i1 %t31, %d4_5
  %t33 = and i1 %t32, %n6
  %t34 = and i1 %t33, %w6
  %t35 = and i1 %t34, %b6
  %t36 = and i1 %t35, %d0_6
  %t37 = and i1 %t36, %d1_6
  %t38 = and i1 %t37, %d2_6
  %t39 = and i1 %t38, %d3_6
  %t40 = and i1 %t39, %d4_6
  %t41 = and i1 %t40, %d5_6
  ret i1 %t41
}
; TOPAL-SYSTEMS-TAIL-ADMISSION-001. Independently owned mapped caller domains.
declare dso_local i64 @topal_tail_step_component_v1(ptr)
declare dso_local i64 @topal_x86_tail_boundary_call_v1(ptr, ptr)
declare dso_local i64 @topal_x86_tail_checkpoint_call_v1(ptr, ptr, ptr, i64)
declare dso_local i64 @topal_x86_tail_complete_call_v1(ptr, ptr, ptr, ptr)
declare dso_local void @topal_x86_tail_boundary_fail_v1(ptr, ptr) noreturn
define internal i64 @o.word(ptr %p, i64 %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %a = getelementptr i8, ptr %p, i64 %offset
  %v = load i64, ptr %a, align 8
  ret i64 %v
}
define internal void @o.put(ptr %p, i64 %offset, i64 %v) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %a = getelementptr i8, ptr %p, i64 %offset
  store i64 %v, ptr %a, align 8
  ret void
}
define internal i1 @o.zero(ptr %p, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %i = phi i64 [0, %entry], [%next, %read]
  %end = icmp eq i64 %i, %length
  br i1 %end, label %yes, label %read
read:
  %a = getelementptr i8, ptr %p, i64 %i
  %v = load volatile i8, ptr %a, align 1
  %clean = icmp eq i8 %v, 0
  %next = add i64 %i, 1
  br i1 %clean, label %loop, label %no
yes:
  ret i1 true
no:
  ret i1 false
}
define internal void @o.number(ptr %p, i64 %v) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %two = icmp ugt i64 %v, 4294967295
  %nonzero = icmp ne i64 %v, 0
  %one = zext i1 %nonzero to i64
  %length = select i1 %two, i64 2, i64 %one
  call void @o.put(ptr %p, i64 8, i64 %length)
  call void @o.put(ptr %p, i64 16, i64 %v)
  ret void
}
define dso_local i64 @topal_tail_owner_invoke_v1(ptr %owner, i64 %count, ptr %input, ptr %history, ptr %private, ptr %stack, ptr %output) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %geometry = call i1 @o.geometry(ptr %owner, i64 %count, ptr %input, ptr %history, ptr %private, ptr %stack, ptr %output)
  br i1 %geometry, label %state, label %refuse
state:
  %active = load ptr, ptr @topal_x86_tail_boundary_active_v1, align 8
  %idle = icmp eq ptr %active, null
  br i1 %idle, label %empty, label %refuse
empty:
  %private.zero = call i1 @o.zero(ptr %private, i64 65528)
  %stack.zero = call i1 @o.zero(ptr %stack, i64 4096)
  %output.zero = call i1 @o.zero(ptr %output, i64 56)
  %b = and i1 %stack.zero, %output.zero
  %clean = and i1 %private.zero, %b
  br i1 %clean, label %history.state, label %refuse
history.state:
  %frame = call i64 @o.word(ptr %history, i64 0)
  %loan = call i64 @o.word(ptr %history, i64 8)
  %generation = call i64 @o.word(ptr %history, i64 16)
  %live = call i64 @o.word(ptr %history, i64 24)
  %poison = call i64 @o.word(ptr %history, i64 32)
  %virgin = call i1 @o.zero(ptr %history, i64 40)
  %frames.valid = icmp uge i64 %frame, 2
  %loans.valid = icmp uge i64 %loan, 2
  %generation.valid = icmp ugt i64 %generation, 0
  %old.ids = and i1 %frames.valid, %loans.valid
  %old.valid = and i1 %old.ids, %generation.valid
  %identities.valid = or i1 %virgin, %old.valid
  %inactive = icmp eq i64 %live, 0
  %not.poisoned = icmp eq i64 %poison, 0
  %available = and i1 %inactive, %not.poisoned
  %history.valid = and i1 %identities.valid, %available
  %next.generation = add i64 %generation, 1
  %generation.fits = icmp ugt i64 %next.generation, %generation
  %ready = and i1 %history.valid, %generation.fits
  br i1 %ready, label %budgets, label %refuse
budgets:
  %input.0 = call i64 @o.word(ptr %input, i64 0)
  %input.1 = call i64 @o.word(ptr %input, i64 8)
  %input.2 = call i64 @o.word(ptr %input, i64 16)
  %above = icmp ugt i64 %input.0, 0
  %difference = sub i64 %input.0, 0
  %distance = select i1 %above, i64 %difference, i64 0
  %quotient = udiv i64 %distance, 1
  %remainder = urem i64 %distance, 1
  %round = icmp ne i64 %remainder, 0
  %extra = zext i1 %round to i64
  %edges = add i64 %quotient, %extra
  %steps = add i64 %edges, 1
  %steps.fit = icmp ugt i64 %steps, %edges
  %next.frame = select i1 %virgin, i64 2, i64 %frame
  %next.loan = select i1 %virgin, i64 2, i64 %loan
  %remaining.frames = sub i64 -1, %next.frame
  %remaining.loans = sub i64 -1, %next.loan
  %frame.steps = udiv i64 %remaining.frames, 53
  %loan.steps = udiv i64 %remaining.loans, 38
  %frames.fit = icmp ule i64 %steps, %frame.steps
  %loans.fit = icmp ule i64 %steps, %loan.steps
  %ids.fit = and i1 %frames.fit, %loans.fit
  %budget = and i1 %steps.fit, %ids.fit
  br i1 %budget, label %admit, label %refuse
admit:
  %frame.cost = mul i64 %steps, 53
  %loan.cost = mul i64 %steps, 38
  %frame.end = add i64 %next.frame, %frame.cost
  %loan.end = add i64 %next.loan, %loan.cost
  call void @o.put(ptr %history, i64 0, i64 %next.frame)
  call void @o.put(ptr %history, i64 8, i64 %next.loan)
  call void @o.put(ptr %history, i64 16, i64 %next.generation)
  call void @o.put(ptr %history, i64 24, i64 1)
  %context = getelementptr i8, ptr %private, i64 64
  %source = ptrtoint ptr @topal_tail_step_component_v1 to i64
  %domain = ptrtoint ptr %history to i64
  %owner.word = ptrtoint ptr %owner to i64
  %context.word = ptrtoint ptr %context to i64
  call void @o.put(ptr %context, i64 0, i64 %source)
  call void @o.put(ptr %context, i64 8, i64 %domain)
  call void @o.put(ptr %context, i64 16, i64 %next.generation)
  call void @o.put(ptr %context, i64 24, i64 1)
  call void @o.put(ptr %context, i64 32, i64 %owner.word)
  call void @o.put(ptr %context, i64 40, i64 %count)
  call void @o.put(ptr %context, i64 48, i64 1)
  call void @o.put(ptr %context, i64 56, i64 1)
  call void @o.put(ptr %context, i64 64, i64 33)
  call void @o.put(ptr %context, i64 72, i64 1)
  call void @o.put(ptr %context, i64 80, i64 1)
  call void @o.put(ptr %context, i64 88, i64 %context.word)
  call void @o.put(ptr %context, i64 104, i64 %count)
  call void @o.put(ptr %context, i64 112, i64 1)
  call void @o.put(ptr %context, i64 120, i64 %next.generation)
  call void @o.put(ptr %context, i64 128, i64 %domain)
  call void @o.put(ptr %context, i64 136, i64 %source)
  call void @o.put(ptr %context, i64 1208, i64 %domain)
  call void @o.put(ptr %context, i64 1216, i64 %frame.end)
  call void @o.put(ptr %context, i64 1224, i64 %loan.end)
  call void @o.put(ptr %context, i64 1232, i64 1)
  call void @o.put(ptr %context, i64 1280, i64 %steps)
  %seed.0 = getelementptr i8, ptr %context, i64 1312
  call void @o.number(ptr %seed.0, i64 %input.0)
  %seed.1 = getelementptr i8, ptr %context, i64 1336
  call void @o.number(ptr %seed.1, i64 %input.1)
  %seed.2 = getelementptr i8, ptr %context, i64 1360
  call void @o.number(ptr %seed.2, i64 %input.2)

  br label %loop
loop:
  %outcome = call i64 @topal_x86_tail_boundary_call_v1(ptr %private, ptr %stack)
  %outcome.valid = icmp ule i64 %outcome, 1
  br i1 %outcome.valid, label %checkpoint, label %fatal
checkpoint:
  %checkpoint.outcome = call i64 @topal_x86_tail_checkpoint_call_v1(ptr %private, ptr %stack, ptr %history, i64 %outcome)
  %same.outcome = icmp eq i64 %checkpoint.outcome, %outcome
  br i1 %same.outcome, label %returned, label %fatal
returned:
  %successor = icmp eq i64 %outcome, 1
  br i1 %successor, label %loop, label %complete
complete:
  %completed = call i64 @topal_x86_tail_complete_call_v1(ptr %private, ptr %stack, ptr %history, ptr %output)
  %normal = icmp eq i64 %completed, 0
  br i1 %normal, label %done, label %fatal
done:
  ret i64 0
refuse:
  ret i64 2
fatal:
  call void @o.put(ptr %history, i64 24, i64 0)
  call void @o.put(ptr %history, i64 32, i64 1)
  br label %erase.output
erase.output:
  %i = phi i64 [0, %fatal], [%next, %write]
  %end = icmp eq i64 %i, 56
  br i1 %end, label %fail, label %write
write:
  %byte = getelementptr i8, ptr %output, i64 %i
  store volatile i8 0, ptr %byte, align 1
  %next = add i64 %i, 1
  br label %erase.output
fail:
  %erased = call i1 @o.zero(ptr %output, i64 56)
  call void @topal_x86_tail_boundary_fail_v1(ptr %private, ptr %stack)
  unreachable
}
