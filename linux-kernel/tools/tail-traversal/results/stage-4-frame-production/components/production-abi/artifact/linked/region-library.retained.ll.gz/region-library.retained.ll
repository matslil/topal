; ModuleID = 'kernel-region'
source_filename = "bootstrap-byte-copy-frame.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.OptionalStorage = type { i64, ptr }
%topal.IntStorage = type { i64, i64, [0 x i32] }
%topal.KernelRegionControl = type { ptr, i64, i64, i64, ptr, i64, i64, i64 }
%topal.KernelRegionView = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }

@llvm.used = appending global [1 x ptr] [ptr @topal.region-instance.root-region.memset], section "llvm.metadata"
@topal.region-instance.root-region.runtime.int.zero = internal constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@topal.region-instance.root-region.literal.int.0 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.root-region.literal.int.1 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8

; Function Attrs: noimplicitfloat noinline noredzone nounwind optnone
define internal ptr @topal.region-instance.root-region.memset(ptr %destination, i32 %value, i64 %length) #0 {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill

fill:                                             ; preds = %fill, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill

complete:                                         ; preds = %fill, %entry
  ret ptr %destination
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.runtime.optional.some(ptr %payload) #1 {
entry:
  %optional = call ptr @topal.region-instance.root-region.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.runtime.optional.none() #1 {
entry:
  %optional = call ptr @topal.region-instance.root-region.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.region-instance.root-region.runtime.optional.is.some(ptr %optional) #1 {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid

checked:                                          ; preds = %entry
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some

invalid:                                          ; preds = %entry
  call void @topal.region-instance.root-region.platform.exit(i64 70)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.runtime.optional.payload(ptr %optional) #1 {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.runtime.int.allocate(i64 %length, i64 %negative) #1 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.region-instance.root-region.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.region-instance.root-region.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.runtime.int.from.u64(i64 %source) #1 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.region-instance.root-region.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.region-instance.root-region.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

declare ptr @topal_kernel_region_frame_root_region_allocate_v1(i64)

; Function Attrs: noreturn
declare void @topal_kernel_region_frame_root_region_abort_v1() #2

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.platform.allocate(i64 %length) #1 {
entry:
  %pointer = call ptr @topal_kernel_region_frame_root_region_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.region-instance.root-region.platform.exit(i64 %status) #3 {
entry:
  call void @topal_kernel_region_frame_root_region_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.region-instance.root-region.primitive.abort() #3 {
entry:
  call void @topal_kernel_region_frame_root_region_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.primitive.guard(ptr %view) #1 {
entry:
  %address = ptrtoint ptr %view to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %valid.pointer = and i1 %nonnull, %aligned
  br i1 %valid.pointer, label %view.fields, label %invalid

view.fields:                                      ; preds = %entry
  %control = load ptr, ptr %view, align 8
  %control.address = ptrtoint ptr %control to i64
  %control.nonnull = icmp ne i64 %control.address, 0
  %control.alignment = and i64 %control.address, 7
  %control.aligned = icmp eq i64 %control.alignment, 0
  %control.valid = and i1 %control.nonnull, %control.aligned
  br i1 %control.valid, label %control.fields, label %invalid

control.fields:                                   ; preds = %view.fields
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %view.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %view.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %view.epoch.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 4
  %view.owner.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 5
  %view.code.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 6
  %view.zero.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 7
  %offset = load i64, ptr %offset.pointer, align 8
  %view.count = load i64, ptr %view.count.pointer, align 8
  %view.rights = load i64, ptr %view.rights.pointer, align 8
  %view.epoch = load i64, ptr %view.epoch.pointer, align 8
  %view.owner = load i64, ptr %view.owner.pointer, align 8
  %view.code = load ptr, ptr %view.code.pointer, align 8
  %view.zero = load i64, ptr %view.zero.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_root_region_apply_v1
  %view.code.valid = icmp eq ptr %view.code, %code
  %owner.valid = icmp ne i64 %owner, 0
  %view.owner.valid = icmp eq i64 %view.owner, %owner
  %epoch.valid = icmp ne i64 %epoch, 0
  %view.epoch.valid = icmp eq i64 %view.epoch, %epoch
  %active.valid = icmp eq i64 %active, 1
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %view.rights.valid = icmp ule i64 %view.rights, %rights
  %zero.valid = icmp eq i64 %view.zero, 0
  %offset.valid = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %view.count.valid = icmp ule i64 %view.count, %remaining
  %base.address = ptrtoint ptr %base to i64
  %base.nonnull = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %issued.positive = icmp uge i64 %issued, 1
  %issued.bounded = icmp ule i64 %issued, 256
  %issued.valid = and i1 %issued.positive, %issued.bounded
  %a = and i1 %code.valid, %view.code.valid
  %b = and i1 %owner.valid, %view.owner.valid
  %c = and i1 %epoch.valid, %view.epoch.valid
  %d = and i1 %active.valid, %count.valid
  %e = and i1 %rights.valid, %view.rights.valid
  %f = and i1 %zero.valid, %offset.valid
  %g = and i1 %view.count.valid, %base.nonnull
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %ef = and i1 %e, %f
  %g.end = and i1 %g, %end.valid
  %abcd = and i1 %ab, %cd
  %efgh = and i1 %ef, %g.end
  %all.fields = and i1 %abcd, %efgh
  %valid = and i1 %all.fields, %issued.valid
  br i1 %valid, label %success, label %invalid

success:                                          ; preds = %control.fields
  %bytes = getelementptr i8, ptr %base, i64 %offset
  ret ptr %bytes

invalid:                                          ; preds = %control.fields, %view.fields, %entry
  call void @topal.region-instance.root-region.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal { i1, i64 } @topal.region-instance.root-region.primitive.index(ptr %number) #1 {
entry:
  %sign = load i64, ptr %number, align 8
  %nonnegative = icmp eq i64 %sign, 0
  br i1 %nonnegative, label %number.length, label %invalid

number.length:                                    ; preds = %entry
  %length.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %zero.result, label %bounded

zero.result:                                      ; preds = %number.length
  ret { i1, i64 } { i1 true, i64 0 }

bounded:                                          ; preds = %number.length
  %fits = icmp ule i64 %length, 2
  br i1 %fits, label %low, label %refuse

low:                                              ; preds = %bounded
  %low.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 0
  %low.word = load i32, ptr %low.pointer, align 4
  %low.value = zext i32 %low.word to i64
  %single = icmp eq i64 %length, 1
  br i1 %single, label %single.result, label %high

single.result:                                    ; preds = %low
  %one = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %low.value, 1
  ret { i1, i64 } %one

high:                                             ; preds = %low
  %high.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 1
  %high.word = load i32, ptr %high.pointer, align 4
  %high.value = zext i32 %high.word to i64
  %shifted = shl i64 %high.value, 32
  %value = or i64 %shifted, %low.value
  %two = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %value, 1
  ret { i1, i64 } %two

refuse:                                           ; preds = %bounded
  ret { i1, i64 } zeroinitializer

invalid:                                          ; preds = %entry
  call void @topal.region-instance.root-region.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.root-region.primitive.load(ptr %view, ptr %index) #1 {
entry:
  %bytes = call ptr @topal.region-instance.root-region.primitive.guard(ptr %view)
  %decoded = call { i1, i64 } @topal.region-instance.root-region.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %valid = and i1 %fits, %contained
  br i1 %valid, label %read, label %refuse

read:                                             ; preds = %entry
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = load i8, ptr %pointer, align 1
  %value = zext i8 %byte to i64
  %number = call ptr @topal.region-instance.root-region.runtime.int.from.u64(i64 %value)
  %some = call ptr @topal.region-instance.root-region.runtime.optional.some(ptr %number)
  ret ptr %some

refuse:                                           ; preds = %entry
  %none = call ptr @topal.region-instance.root-region.runtime.optional.none()
  ret ptr %none
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.region-instance.root-region.primitive.store(ptr %view, ptr %index, ptr %number) #1 {
entry:
  %bytes = call ptr @topal.region-instance.root-region.primitive.guard(ptr %view)
  %decoded.index = call { i1, i64 } @topal.region-instance.root-region.primitive.index(ptr %index)
  %decoded.value = call { i1, i64 } @topal.region-instance.root-region.primitive.index(ptr %number)
  %index.fits = extractvalue { i1, i64 } %decoded.index, 0
  %offset = extractvalue { i1, i64 } %decoded.index, 1
  %value.fits = extractvalue { i1, i64 } %decoded.value, 0
  %value = extractvalue { i1, i64 } %decoded.value, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %writable = icmp eq i64 %rights, 1
  %byte.valid = icmp ule i64 %value, 255
  %both.fit = and i1 %index.fits, %value.fits
  %access = and i1 %contained, %writable
  %range = and i1 %both.fit, %byte.valid
  %valid = and i1 %access, %range
  br i1 %valid, label %write, label %refuse

write:                                            ; preds = %entry
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = trunc i64 %value to i8
  store i8 %byte, ptr %pointer, align 1
  ret i1 true

refuse:                                           ; preds = %entry
  ret i1 false
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.root-region.topal.fn.support_2ebytes_2ecopy_2dbyte.0(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !6 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !21, !DIExpression(), !22)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !23, !DIExpression(), !24)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !25, !DIExpression(), !26)
  %v3 = call ptr @topal.region-instance.root-region.primitive.load(ptr %arg0, ptr %arg1), !dbg !27
  %v4 = call i1 @topal.region-instance.root-region.runtime.optional.is.some(ptr %v3), !dbg !27
  br i1 %v4, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !27

optional.decision.some.0:                         ; preds = %entry
  %v5 = call ptr @topal.region-instance.root-region.runtime.optional.payload(ptr %v3), !dbg !28
    #dbg_value(ptr %v5, !29, !DIExpression(), !28)
  %v6 = call i1 @topal.region-instance.root-region.primitive.store(ptr %arg0, ptr %arg2, ptr %v5), !dbg !30
  br label %optional.decision.merge.2, !dbg !30

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !31

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v7 = phi i1 [ %v6, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !27
  ret i1 %v7, !dbg !27
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc void @topal.region-instance.root-region.topal.fn.policy_2ebootstrap_2dbyte_2dcopy_2eapply.1(ptr %arg0) #1 !dbg !32 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !36, !DIExpression(), !37)
  %v1 = call fastcc i1 @topal.region-instance.root-region.topal.fn.support_2ebytes_2ecopy_2dbyte.0(ptr %arg0, ptr @topal.region-instance.root-region.literal.int.0, ptr @topal.region-instance.root-region.literal.int.1), !dbg !38
    #dbg_value(i1 %v1, !39, !DIExpression(), !40)
  ret void, !dbg !41
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.root-region.topal.fn.apply.2(ptr %arg0) #1 !dbg !42 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !45, !DIExpression(), !46)
  call fastcc void @topal.region-instance.root-region.topal.fn.policy_2ebootstrap_2dbyte_2dcopy_2eapply.1(ptr %arg0), !dbg !47
    #dbg_value(i8 0, !48, !DIExpression(), !50)
  ret i1 true, !dbg !51
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define i64 @topal_kernel_region_frame_root_region_apply_v1(ptr %control, i64 %expected.owner, i64 %next.epoch, ptr %frame.words, i64 %frame.word.count) #1 {
entry:
  %frame.arity.valid = icmp eq i64 %frame.word.count, 0
  br i1 %frame.arity.valid, label %frame.control, label %invalid

frame.control:                                    ; preds = %entry
  %address = ptrtoint ptr %control to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %control.end = add i64 %address, 64
  %control.extent.valid = icmp uge i64 %control.end, %address
  %pointer.valid = and i1 %nonnull, %aligned
  %control.valid = and i1 %pointer.valid, %control.extent.valid
  br i1 %control.valid, label %fields, label %invalid

fields:                                           ; preds = %frame.control
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_root_region_apply_v1
  %owner.nonzero = icmp ne i64 %owner, 0
  %owner.matches = icmp eq i64 %owner, %expected.owner
  %owner.valid = and i1 %owner.nonzero, %owner.matches
  %epoch.bounded = icmp ne i64 %epoch, -1
  %successor = add i64 %epoch, 1
  %epoch.matches = icmp eq i64 %successor, %next.epoch
  %epoch.valid = and i1 %epoch.bounded, %epoch.matches
  %active.valid = icmp eq i64 %active, 0
  %issued.valid = icmp eq i64 %issued, 0
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %base.address = ptrtoint ptr %base to i64
  %base.valid = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %below.control = icmp ule i64 %end, %address
  %above.control = icmp uge i64 %base.address, %control.end
  %disjoint = or i1 %below.control, %above.control
  %a = and i1 %code.valid, %owner.valid
  %b = and i1 %epoch.valid, %active.valid
  %c = and i1 %issued.valid, %count.valid
  %d = and i1 %rights.valid, %base.valid
  %e = and i1 %end.valid, %disjoint
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %abcd = and i1 %ab, %cd
  %valid = and i1 %abcd, %e
  br i1 %valid, label %frame.bounds, label %invalid

frame.bounds:                                     ; preds = %fields
  %frame.empty = icmp eq ptr %frame.words, null
  br i1 %frame.empty, label %prepare, label %invalid

prepare:                                          ; preds = %frame.bounds
  store i64 %next.epoch, ptr %epoch.pointer, align 8
  store i64 1, ptr %active.pointer, align 8
  store i64 1, ptr %issued.pointer, align 8
  %view = call ptr @topal.region-instance.root-region.platform.allocate(i64 64)
  %v0 = insertvalue %topal.KernelRegionView zeroinitializer, ptr %control, 0
  %v1 = insertvalue %topal.KernelRegionView %v0, i64 %count, 2
  %v2 = insertvalue %topal.KernelRegionView %v1, i64 %rights, 3
  %v3 = insertvalue %topal.KernelRegionView %v2, i64 %next.epoch, 4
  %v4 = insertvalue %topal.KernelRegionView %v3, i64 %owner, 5
  %v5 = insertvalue %topal.KernelRegionView %v4, ptr @topal_kernel_region_frame_root_region_apply_v1, 6
  store %topal.KernelRegionView %v5, ptr %view, align 8
  %accepted = call fastcc i1 @topal.region-instance.root-region.topal.fn.apply.2(ptr %view)
  %final.view = call ptr @topal.region-instance.root-region.primitive.guard(ptr %view)
  store ptr null, ptr %control, align 8
  store i64 0, ptr %owner.pointer, align 8
  store i64 0, ptr %active.pointer, align 8
  store ptr null, ptr %base.pointer, align 8
  store i64 0, ptr %count.pointer, align 8
  store i64 0, ptr %rights.pointer, align 8
  store i64 0, ptr %issued.pointer, align 8
  %result = zext i1 %accepted to i64
  ret i64 %result

invalid:                                          ; preds = %frame.bounds, %fields, %frame.control, %entry
  call void @topal.region-instance.root-region.primitive.abort()
  unreachable
}

attributes #0 = { noimplicitfloat noinline noredzone nounwind optnone "disable-tail-calls"="true" }
attributes #1 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #2 = { noreturn }
attributes #3 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "bootstrap-byte-copy-frame.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "support.bytes.copy-byte", linkageName: "topal.region-instance.root-region.topal.fn.support_2ebytes_2ecopy_2dbyte.0", scope: !7, file: !7, line: 4, type: !8, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DIFile(filename: "bytes.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !11, !14, !14}
!10 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!11 = !DIDerivedType(tag: DW_TAG_typedef, name: "KernelByteRegion", file: !1, baseType: !12)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64, align: 64)
!13 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalKernelRegionBorrow", flags: DIFlagFwdDecl)
!14 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !15)
!15 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !17)
!17 = !{!18, !20}
!18 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !19, size: 64, align: 64)
!19 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !19, size: 64, align: 64, offset: 64)
!21 = !DILocalVariable(name: "region", arg: 1, scope: !6, file: !7, line: 4, type: !11)
!22 = !DILocation(line: 4, column: 23, scope: !6)
!23 = !DILocalVariable(name: "source", arg: 2, scope: !6, file: !7, line: 4, type: !14)
!24 = !DILocation(line: 4, column: 50, scope: !6)
!25 = !DILocalVariable(name: "destination", arg: 3, scope: !6, file: !7, line: 4, type: !14)
!26 = !DILocation(line: 4, column: 64, scope: !6)
!27 = !DILocation(line: 5, column: 3, scope: !6)
!28 = !DILocation(line: 6, column: 10, scope: !6)
!29 = !DILocalVariable(name: "value", scope: !6, file: !7, line: 6, type: !14)
!30 = !DILocation(line: 6, column: 21, scope: !6)
!31 = !DILocation(line: 7, column: 15, scope: !6)
!32 = distinct !DISubprogram(name: "policy.bootstrap-byte-copy.apply", linkageName: "topal.region-instance.root-region.topal.fn.policy_2ebootstrap_2dbyte_2dcopy_2eapply.1", scope: !33, file: !33, line: 5, type: !34, scopeLine: 5, spFlags: DISPFlagDefinition, unit: !0)
!33 = !DIFile(filename: "bootstrap-byte-copy.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!34 = !DISubroutineType(types: !35)
!35 = !{null, !11}
!36 = !DILocalVariable(name: "region", arg: 1, scope: !32, file: !33, line: 5, type: !11)
!37 = !DILocation(line: 5, column: 18, scope: !32)
!38 = !DILocation(line: 6, column: 23, scope: !32)
!39 = !DILocalVariable(name: "copied", scope: !32, file: !33, line: 6, type: !10)
!40 = !DILocation(line: 6, column: 3, scope: !32)
!41 = !DILocation(line: 7, column: 3, scope: !32)
!42 = distinct !DISubprogram(name: "apply", linkageName: "topal.region-instance.root-region.topal.fn.apply.2", scope: !1, file: !1, line: 5, type: !43, scopeLine: 5, spFlags: DISPFlagDefinition, unit: !0)
!43 = !DISubroutineType(types: !44)
!44 = !{!10, !11}
!45 = !DILocalVariable(name: "region", arg: 1, scope: !42, file: !1, line: 5, type: !11)
!46 = !DILocation(line: 5, column: 18, scope: !42)
!47 = !DILocation(line: 6, column: 20, scope: !42)
!48 = !DILocalVariable(name: "copied", scope: !42, file: !1, line: 6, type: !49)
!49 = !DIBasicType(name: "Unit", size: 8, encoding: DW_ATE_unsigned)
!50 = !DILocation(line: 6, column: 3, scope: !42)
!51 = !DILocation(line: 7, column: 3, scope: !42)
