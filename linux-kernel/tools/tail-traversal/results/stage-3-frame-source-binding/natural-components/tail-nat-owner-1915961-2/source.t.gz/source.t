use language (version is v0.1, features is (systems))
pub find-zero is fn ((region : KernelByteRegion, remaining : Nat, offset : Nat, state : Nat)) -> Nat : Decreases remaining
  remaining
    <= 0 then offset
    otherwise find-zero(region, remaining - 1, 115792089237316195423570985008687907853269984665640564039457584007913129639935, state)
