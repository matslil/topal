; ModuleID = 'topal.tail-source.native'
source_filename = "count-probe.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.IntStorage = type { i64, i64, [0 x i32] }
%topal.KernelRegionControl = type { ptr, i64, i64, i64, ptr, i64, i64, i64 }
%topal.KernelRegionView = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }

@topal.tail.component.runtime.int.zero = private constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@topal.tail.component.runtime.int.one = private constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.tail.component.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.tail.component.literal.int.0 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.1 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative) #0 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.tail.component.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.from.u64(i64 %source) #0 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %value, i64 %index) #0 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero

load:                                             ; preds = %entry
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended

zero:                                             ; preds = %entry
  ret i64 0
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.normalize(ptr %value) #0 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim

trim:                                             ; preds = %leading.zero, %entry
  %candidate = phi i64 [ %length, %entry ], [ %next, %leading.zero ]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done

leading.zero:                                     ; preds = %trim
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim

zero:                                             ; preds = %leading.zero, %entry
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value

done:                                             ; preds = %trim
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 %negative) #0 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate

zero:                                             ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.zero

allocate:                                         ; preds = %entry
  %copy = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %allocate
  %index = phi i64 [ 0, %allocate ], [ %next, %loop ]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  ret ptr %copy
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.negate(ptr %value) #0 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [
    i64 2, label %positive.infinity
    i64 3, label %negative.infinity
  ]

positive.infinity:                                ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.negative.infinity

negative.infinity:                                ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.positive.infinity

finite:                                           ; preds = %entry
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %copy

zero:                                             ; preds = %finite
  ret ptr @topal.tail.component.runtime.int.zero

copy:                                             ; preds = %finite
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %opposite = xor i64 %negative, 1
  %result = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 %opposite)
  ret ptr %result
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right) #0 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer

check.longer:                                     ; preds = %entry
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty

check.empty:                                      ; preds = %check.longer
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs

limbs:                                            ; preds = %limbs.equal, %check.empty
  %position = phi i64 [ %left.length, %check.empty ], [ %index, %limbs.equal ]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater

check.limb.greater:                               ; preds = %limbs
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal

limbs.equal:                                      ; preds = %check.limb.greater
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal

less:                                             ; preds = %limbs, %entry
  ret i32 -1

equal:                                            ; preds = %limbs.equal, %check.empty
  ret i32 0

greater:                                          ; preds = %check.limb.greater, %check.longer
  ret i32 1
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.tail.component.runtime.int.compare(ptr %left, ptr %right) #0 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity

left.positive:                                    ; preds = %entry
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result

check.left.negative.infinity:                     ; preds = %entry
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity

left.negative:                                    ; preds = %check.left.negative.infinity
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result

check.right.positive.infinity:                    ; preds = %check.left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity

check.right.negative.infinity:                    ; preds = %check.right.positive.infinity
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite

less:                                             ; preds = %check.right.positive.infinity
  ret i32 -1

greater:                                          ; preds = %check.right.negative.infinity
  ret i32 1

finite:                                           ; preds = %check.right.negative.infinity
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute

signed.result:                                    ; preds = %finite
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result

absolute:                                         ; preds = %finite
  %magnitude = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) #0 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %left.limb = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish

finish:                                           ; preds = %loop, %entry
  %final.carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry

store.carry:                                      ; preds = %finish
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result

without.carry:                                    ; preds = %finish
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) #0 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %borrow = phi i64 [ 0, %entry ], [ %next.borrow, %loop ]
  %left = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.add(ptr %left, ptr %right) #0 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity

validate.left.infinity:                           ; preds = %entry
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity

indeterminate.infinity:                           ; preds = %validate.left.infinity
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable

return.left.infinity:                             ; preds = %validate.left.infinity
  ret ptr %left

check.right.infinity:                             ; preds = %entry
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite

return.right.infinity:                            ; preds = %check.right.infinity
  ret ptr %right

finite:                                           ; preds = %check.right.infinity
  %left.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right

return.right:                                     ; preds = %finite
  ret ptr %right

check.right:                                      ; preds = %finite
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero

return.left:                                      ; preds = %check.right
  ret ptr %left

nonzero:                                          ; preds = %check.right
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference

sum:                                              ; preds = %nonzero
  %sum.value = call ptr @topal.tail.component.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value

difference:                                       ; preds = %nonzero
  %ordering = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger

zero:                                             ; preds = %difference
  ret ptr @topal.tail.component.runtime.int.zero

select.larger:                                    ; preds = %difference
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference

left.difference:                                  ; preds = %select.larger
  %left.value = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value

right.difference:                                 ; preds = %select.larger
  %right.value = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.subtract(ptr %left, ptr %right) #0 {
entry:
  %opposite = call ptr @topal.tail.component.runtime.int.negate(ptr %right)
  %result = call ptr @topal.tail.component.runtime.int.add(ptr %left, ptr %opposite)
  ret ptr %result
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.tail.component.runtime.int.is.zero(ptr %value) #0 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

declare dso_local ptr @topal_tail_allocate_v1(i64)

; Function Attrs: noreturn
declare dso_local void @topal_tail_abort_v1() #1

declare dso_local void @topal_tail_step_begin_v1(ptr)

declare dso_local ptr @topal_tail_input_number_v1(ptr, i64)

declare dso_local ptr @topal_tail_input_view_v1(ptr)

declare dso_local ptr @topal_tail_helper_enter_v1(ptr, i64, ptr)

declare dso_local void @topal_tail_helper_leave_v1(ptr, i64)

declare dso_local void @topal_tail_validate_view_v1(ptr, ptr)

declare dso_local void @topal_tail_stage_number_v1(ptr, i64, ptr)

declare dso_local void @topal_tail_result_boolean_v1(ptr, i64)

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.platform.allocate(i64 %length) #0 {
entry:
  %pointer = call ptr @topal_tail_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.tail.component.platform.exit(i64 %status) #2 {
entry:
  call void @topal_tail_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.tail.component.primitive.abort() #2 {
entry:
  call void @topal_tail_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.primitive.guard(ptr %view) #0 {
entry:
  %address = ptrtoint ptr %view to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %valid.pointer = and i1 %nonnull, %aligned
  br i1 %valid.pointer, label %view.fields, label %invalid

view.fields:                                      ; preds = %entry
  %control = load ptr, ptr %view, align 8
  %control.address = ptrtoint ptr %control to i64
  %control.nonnull = icmp ne i64 %control.address, 0
  %control.alignment = and i64 %control.address, 7
  %control.aligned = icmp eq i64 %control.alignment, 0
  %control.valid = and i1 %control.nonnull, %control.aligned
  br i1 %control.valid, label %control.fields, label %invalid

control.fields:                                   ; preds = %view.fields
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %view.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %view.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %view.epoch.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 4
  %view.owner.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 5
  %view.code.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 6
  %view.zero.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 7
  %offset = load i64, ptr %offset.pointer, align 8
  %view.count = load i64, ptr %view.count.pointer, align 8
  %view.rights = load i64, ptr %view.rights.pointer, align 8
  %view.epoch = load i64, ptr %view.epoch.pointer, align 8
  %view.owner = load i64, ptr %view.owner.pointer, align 8
  %view.code = load ptr, ptr %view.code.pointer, align 8
  %view.zero = load i64, ptr %view.zero.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_tail_step_component_v1
  %view.code.valid = icmp eq ptr %view.code, %code
  %owner.valid = icmp ne i64 %owner, 0
  %view.owner.valid = icmp eq i64 %view.owner, %owner
  %epoch.valid = icmp ne i64 %epoch, 0
  %view.epoch.valid = icmp eq i64 %view.epoch, %epoch
  %active.valid = icmp eq i64 %active, 1
  %count.valid = icmp ule i64 %count, -1
  %rights.valid = icmp ule i64 %rights, 1
  %view.rights.valid = icmp ule i64 %view.rights, %rights
  %zero.valid = icmp eq i64 %view.zero, 0
  %offset.valid = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %view.count.valid = icmp ule i64 %view.count, %remaining
  %base.address = ptrtoint ptr %base to i64
  %base.nonnull = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %issued.positive = icmp uge i64 %issued, 1
  %issued.bounded = icmp ule i64 %issued, 256
  %issued.valid = and i1 %issued.positive, %issued.bounded
  %a = and i1 %code.valid, %view.code.valid
  %b = and i1 %owner.valid, %view.owner.valid
  %c = and i1 %epoch.valid, %view.epoch.valid
  %d = and i1 %active.valid, %count.valid
  %e = and i1 %rights.valid, %view.rights.valid
  %f = and i1 %zero.valid, %offset.valid
  %g = and i1 %view.count.valid, %base.nonnull
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %ef = and i1 %e, %f
  %g.end = and i1 %g, %end.valid
  %abcd = and i1 %ab, %cd
  %efgh = and i1 %ef, %g.end
  %all.fields = and i1 %abcd, %efgh
  %valid = and i1 %all.fields, %issued.valid
  br i1 %valid, label %success, label %invalid

success:                                          ; preds = %control.fields
  %bytes = getelementptr i8, ptr %base, i64 %offset
  ret ptr %bytes

invalid:                                          ; preds = %control.fields, %view.fields, %entry
  call void @topal.tail.component.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.primitive.count(ptr %view) #0 {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %number = call ptr @topal.tail.component.runtime.int.from.u64(i64 %count)
  ret ptr %number
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.tail.component.topal.fn.support_2eextent_2ecount.1(ptr %arg0, ptr %tail.context) #0 !dbg !6 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 1, ptr %arg0), !dbg !20
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !21, !DIExpression(), !22)
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %tail.helper.view), !dbg !23
  %v1 = call ptr @topal.tail.component.primitive.count(ptr %tail.helper.view), !dbg !23
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 1), !dbg !23
  ret ptr %v1, !dbg !23
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define dso_local i64 @topal_tail_step_component_v1(ptr %tail.context) #0 !dbg !24 {
entry:
  call void @topal_tail_step_begin_v1(ptr %tail.context), !dbg !27
  %v0 = call ptr @topal_tail_input_view_v1(ptr %tail.context), !dbg !28
    #dbg_value(ptr %v0, !29, !DIExpression(), !28)
  %v1 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 1), !dbg !30
    #dbg_value(ptr %v1, !31, !DIExpression(), !30)
  %v2 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 2), !dbg !32
    #dbg_value(ptr %v2, !33, !DIExpression(), !32)
  %v3 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 3), !dbg !34
    #dbg_value(ptr %v3, !35, !DIExpression(), !34)
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr @topal.tail.component.literal.int.0), !dbg !36
  %v5 = icmp sle i32 %v4, 0, !dbg !36
  br i1 %v5, label %tail.compare.action.0, label %tail.compare.next.1, !dbg !36

tail.compare.action.0:                            ; preds = %entry
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.support_2eextent_2ecount.1(ptr %v0, ptr %tail.context), !dbg !37
  %v7 = call i32 @topal.tail.component.runtime.int.compare(ptr %v6, ptr %v2), !dbg !37
  %v8 = icmp eq i32 %v7, 0, !dbg !37
  %v9 = icmp eq i1 %v8, true, !dbg !37
  %v10 = zext i1 %v9 to i64, !dbg !37
  call void @topal_tail_result_boolean_v1(ptr %tail.context, i64 %v10), !dbg !37
  ret i64 0, !dbg !37

tail.compare.next.1:                              ; preds = %entry
  %v11 = call ptr @topal.tail.component.runtime.int.subtract(ptr %v1, ptr @topal.tail.component.literal.int.1), !dbg !38
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %v0), !dbg !39
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 1, ptr %v11), !dbg !39
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 2, ptr %v2), !dbg !39
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 3, ptr %v3), !dbg !39
  ret i64 1, !dbg !39
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define dso_local i64 @topal_tail_readonly_bytes_v1(ptr %root) #0 {
entry:
  %match0 = icmp eq ptr %root, @topal.tail.component.literal.int.0
  %size0 = select i1 %match0, i64 16, i64 0
  %match1 = icmp eq ptr %root, @topal.tail.component.literal.int.1
  %size1 = select i1 %match1, i64 20, i64 %size0
  %match2 = icmp eq ptr %root, @topal.tail.component.runtime.int.one
  %size2 = select i1 %match2, i64 20, i64 %size1
  %match3 = icmp eq ptr %root, @topal.tail.component.runtime.int.zero
  %size3 = select i1 %match3, i64 16, i64 %size2
  ret i64 %size3
}

attributes #0 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #1 = { noreturn }
attributes #2 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "count-probe.t", directory: "algorithms")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "support.extent.count", linkageName: "topal.tail.component.topal.fn.support_2eextent_2ecount.1", scope: !7, file: !7, line: 2, type: !8, scopeLine: 2, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DIFile(filename: "extent.t", directory: "support")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !17}
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !11)
!11 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !12, size: 64, align: 64)
!12 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !13)
!13 = !{!14, !16}
!14 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !15, size: 64, align: 64)
!15 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !15, size: 64, align: 64, offset: 64)
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "KernelByteRegion", file: !1, baseType: !18)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!19 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalKernelRegionBorrow", flags: DIFlagFwdDecl)
!20 = !DILocation(line: 2, column: 5, scope: !6)
!21 = !DILocalVariable(name: "region", arg: 1, scope: !6, file: !7, line: 2, type: !17)
!22 = !DILocation(line: 2, column: 18, scope: !6)
!23 = !DILocation(line: 3, column: 3, scope: !6)
!24 = distinct !DISubprogram(name: "inspect [tail step]", linkageName: "topal_tail_step_component_v1", scope: !1, file: !1, line: 3, type: !25, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!25 = !DISubroutineType(types: !26)
!26 = !{null, !17, !10, !10, !10}
!27 = !DILocation(line: 3, column: 5, scope: !24)
!28 = !DILocation(line: 3, column: 21, scope: !24)
!29 = !DILocalVariable(name: "region", arg: 1, scope: !24, file: !1, line: 3, type: !17)
!30 = !DILocation(line: 3, column: 48, scope: !24)
!31 = !DILocalVariable(name: "remaining", arg: 2, scope: !24, file: !1, line: 3, type: !10)
!32 = !DILocation(line: 3, column: 65, scope: !24)
!33 = !DILocalVariable(name: "expected", arg: 3, scope: !24, file: !1, line: 3, type: !10)
!34 = !DILocation(line: 3, column: 81, scope: !24)
!35 = !DILocalVariable(name: "state", arg: 4, scope: !24, file: !1, line: 3, type: !10)
!36 = !DILocation(line: 5, column: 5, scope: !24)
!37 = !DILocation(line: 5, column: 16, scope: !24)
!38 = !DILocation(line: 6, column: 31, scope: !24)
!39 = !DILocation(line: 6, column: 15, scope: !24)
