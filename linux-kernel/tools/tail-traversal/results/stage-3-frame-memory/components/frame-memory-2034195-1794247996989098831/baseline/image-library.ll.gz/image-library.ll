; checked Topal numeric kernel library
source_filename = "static-elf64-header.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

@llvm.used = appending global [1 x ptr] [ptr @topal.elf.memset], section "llvm.metadata"
; Shared private topal-native/6 value algorithms.
; Platform allocation, write and termination hooks are supplied separately.
; Int values are immutable sign-and-magnitude objects with little-endian
; base-2^32 limbs. A zero has sign = 0 and length = 0. Root-local exact
; infinities use executable-private sign tags 2 (+) and 3 (-) with no limbs;
; Rational infinities wrap one sentinel over denominator one at run time. Those
; values are not admitted at a native function or library boundary.

%topal.StringStorage = type { ptr, i64, ptr, i64 }
%topal.IntStorage = type { i64, i64, [0 x i32] }

define internal ptr @topal.elf.runtime.character.ascii.decimal.digit(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %single.byte = icmp eq i64 %length, 1
  br i1 %single.byte, label %load, label %none
load:
  %data.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 0
  %data = load ptr, ptr %data.pointer, align 8
  %byte = load i8, ptr %data, align 1
  %at.least.zero = icmp uge i8 %byte, 48
  %at.most.nine = icmp ule i8 %byte, 57
  %is.digit = and i1 %at.least.zero, %at.most.nine
  br i1 %is.digit, label %some, label %none
some:
  %digit.byte = sub i8 %byte, 48
  %digit = zext i8 %digit.byte to i64
  %value = call ptr @topal.elf.runtime.int.from.u64(i64 %digit)
  %present = call ptr @topal.elf.runtime.optional.some(ptr %value)
  ret ptr %present
none:
  %absent = call ptr @topal.elf.runtime.optional.none()
  ret ptr %absent
}

define internal i1 @topal.elf.runtime.character.unicode.whitespace(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.elf.runtime.string.unicode.scalar.value(ptr %character)
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp eq i64 %length, 1
  br i1 %present, label %load, label %not.whitespace
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %scalar = load i32, ptr %limb.pointer, align 4
  %ascii.lower = icmp uge i32 %scalar, 9
  %ascii.upper = icmp ule i32 %scalar, 13
  %ascii.control = and i1 %ascii.lower, %ascii.upper
  %space = icmp eq i32 %scalar, 32
  %next.line = icmp eq i32 %scalar, 133
  %no.break = icmp eq i32 %scalar, 160
  %ogham = icmp eq i32 %scalar, 5760
  %quad.lower = icmp uge i32 %scalar, 8192
  %quad.upper = icmp ule i32 %scalar, 8202
  %quad = and i1 %quad.lower, %quad.upper
  %line.separator = icmp eq i32 %scalar, 8232
  %paragraph.separator = icmp eq i32 %scalar, 8233
  %narrow.no.break = icmp eq i32 %scalar, 8239
  %medium.math = icmp eq i32 %scalar, 8287
  %ideographic = icmp eq i32 %scalar, 12288
  %match.0 = or i1 %ascii.control, %space
  %match.1 = or i1 %match.0, %next.line
  %match.2 = or i1 %match.1, %no.break
  %match.3 = or i1 %match.2, %ogham
  %match.4 = or i1 %match.3, %quad
  %match.5 = or i1 %match.4, %line.separator
  %match.6 = or i1 %match.5, %paragraph.separator
  %match.7 = or i1 %match.6, %narrow.no.break
  %match.8 = or i1 %match.7, %medium.math
  %match.9 = or i1 %match.8, %ideographic
  ret i1 %match.9
not.whitespace:
  ret i1 false
}
%topal.IntDivmod = type { ptr, ptr }
%topal.RationalStorage = type { ptr, ptr }
%topal.RangeStorage = type { ptr, ptr, i64, i64 }
%topal.ResultStorage = type { i64, ptr }
%topal.OptionalStorage = type { i64, ptr }
%topal.ErrorStorage = type { ptr, i32, i32, ptr, ptr, ptr, i64, i64 }
%topal.SourceLocationStorage = type { ptr, ptr }
%topal.SerializationStreamStorage = type { ptr, i64 }
%topal.TaskStorage = type { i64, i64, ptr }
%topal.LocationStorage = type { ptr, ptr, i64, ptr }

@topal.elf.runtime.int.zero = private constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.elf.runtime.int.one = private constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.elf.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.elf.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.elf.runtime.byte.zero = private constant [1 x i8] c"0", align 1
@topal.elf.runtime.byte.minus = private constant [1 x i8] c"-", align 1
@topal.elf.runtime.int.positive.infinity.text = private constant [9 x i8] c"+Infinity", align 1
@topal.elf.runtime.int.negative.infinity.text = private constant [9 x i8] c"-Infinity", align 1
@topal.elf.runtime.byte.quote = private constant [1 x i8] c"\22", align 1
@topal.elf.runtime.byte.underscore = private constant [1 x i8] c"_", align 1
@topal.elf.runtime.string.tag.text = private constant [4 x i8] c"text", align 1
@topal.elf.runtime.rational.prefix = private constant [11 x i8] c"Rational ( ", align 1
@topal.elf.runtime.rational.separator = private constant [2 x i8] c", ", align 1
@topal.elf.runtime.rational.suffix = private constant [2 x i8] c" )", align 1
@topal.elf.runtime.range.closed.open = private constant [4 x i8] c" .. ", align 1
@topal.elf.runtime.range.open.open = private constant [5 x i8] c" <.. ", align 1
@topal.elf.runtime.range.closed.closed = private constant [5 x i8] c" ..= ", align 1
@topal.elf.runtime.range.open.closed = private constant [6 x i8] c" <..= ", align 1
@topal.elf.runtime.error.prefix = private constant [18 x i8] c"Error ( domain is ", align 1
@topal.elf.runtime.error.code.separator = private constant [10 x i8] c", code is ", align 1
@topal.elf.runtime.error.suffix = private constant [2 x i8] c" )", align 1
@topal.elf.runtime.error.code.out.of.range = private constant [12 x i8] c"out-of-range", align 1
@topal.elf.runtime.error.code.not.representable = private constant [17 x i8] c"not-representable", align 1
@topal.elf.runtime.error.code.division.by.zero = private constant [16 x i8] c"division-by-zero", align 1
@topal.elf.runtime.error.code.indeterminate = private constant [13 x i8] c"indeterminate", align 1
@topal.elf.runtime.pattern.identity.diagnostic = private constant [68 x i8] c"error[E-ANONYMOUS-PATTERN-IDENTITY]: repeated pattern values differ\0A", align 1
@topal.elf.runtime.c.int32.range.diagnostic = private constant [71 x i8] c"error[E-C-ABI-RANGE]: Topal Int is not representable as a C signed int\0A", align 1
@topal.elf.runtime.task.next.identity = private global i64 1, align 8

declare i32 @llvm.ctlz.i32(i32, i1 immarg)
declare void @llvm.memcpy.inline.p0.p0.i64(ptr, ptr, i64, i1 immarg)

; Optimized freestanding code can lower a recognized fill loop to the standard
; LLVM memset libcall. Supply that ABI locally so no C runtime is introduced.
define internal ptr @topal.elf.memset(ptr %destination, i32 %value, i64 %length) nounwind noinline optnone noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill
fill:
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill
complete:
  ret ptr %destination
}



define internal void @topal.elf.runtime.pattern.identity.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.elf.platform.write(i64 2, ptr @topal.elf.runtime.pattern.identity.diagnostic, i64 68)
  call void @topal.elf.platform.exit(i64 65)
  unreachable
}

define internal void @topal.elf.runtime.c.int32.range.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.elf.platform.write(i64 2, ptr @topal.elf.runtime.c.int32.range.diagnostic, i64 71)
  call void @topal.elf.platform.exit(i64 65)
  unreachable
}


; Closed direct tasks run on the deterministic root scheduler. Each instance
; still owns distinct identity, lifecycle state, and private semantic state.
define internal ptr @topal.elf.runtime.task.make(ptr %initial) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %task = call ptr @topal.elf.platform.allocate(i64 24)
  %identity = load i64, ptr @topal.elf.runtime.task.next.identity, align 8
  %next.identity = add i64 %identity, 1
  store i64 %next.identity, ptr @topal.elf.runtime.task.next.identity, align 8
  %identity.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 0
  %terminated.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 1
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store i64 %identity, ptr %identity.pointer, align 8
  store i64 0, ptr %terminated.pointer, align 8
  store ptr %initial, ptr %state.pointer, align 8
  ret ptr %task
}

define internal ptr @topal.elf.runtime.task.state.load(ptr %task) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  %state = load ptr, ptr %state.pointer, align 8
  ret ptr %state
}

define internal void @topal.elf.runtime.task.state.replace(ptr %task, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store ptr %value, ptr %state.pointer, align 8
  ret void
}

; A source-only location without a granted device adapter is backed by private
; Topal storage. The semantic range start and offset remain available for
; debugging, while every read and write remains an ordered runtime call.
define internal ptr @topal.elf.runtime.location.make(ptr %range.start, ptr %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %location = call ptr @topal.elf.platform.allocate(i64 32)
  %range.start.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 0
  %offset.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 1
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %range.start, ptr %range.start.pointer, align 8
  store ptr %offset, ptr %offset.pointer, align 8
  store i64 0, ptr %initialized.pointer, align 8
  store ptr null, ptr %value.pointer, align 8
  ret ptr %location
}

define internal void @topal.elf.runtime.location.write(ptr %location, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %value, ptr %value.pointer, align 8
  store i64 1, ptr %initialized.pointer, align 8
  ret void
}

define internal ptr @topal.elf.runtime.location.read(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %initialized = load i64, ptr %initialized.pointer, align 8
  %valid = icmp eq i64 %initialized, 1
  br i1 %valid, label %load, label %failure
load:
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  %value = load ptr, ptr %value.pointer, align 8
  %non.null = icmp ne ptr %value, null
  br i1 %non.null, label %success, label %failure
success:
  ret ptr %value
failure:
  call void @topal.elf.platform.exit(i64 74)
  unreachable
}

define internal ptr @topal.elf.runtime.serialization.make(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream = call ptr @topal.elf.platform.allocate(i64 16)
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %publish.empty, label %copy.start
copy.start:
  %copy = call ptr @topal.elf.platform.allocate(i64 %length)
  br label %copy.loop
copy.loop:
  %index = phi i64 [ 0, %copy.start ], [ %next, %copy.loop ]
  %source.pointer = getelementptr i8, ptr %data, i64 %index
  %target.pointer = getelementptr i8, ptr %copy, i64 %index
  %byte = load i8, ptr %source.pointer, align 1
  store i8 %byte, ptr %target.pointer, align 1
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %publish.copy, label %copy.loop
publish.copy:
  store ptr %copy, ptr %data.pointer, align 8
  br label %publish.length
publish.empty:
  store ptr null, ptr %data.pointer, align 8
  br label %publish.length
publish.length:
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %stream
}

define internal void @topal.elf.runtime.serialization.verify(ptr %stream, ptr %expected, i64 %expected.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream.valid = icmp ne ptr %stream, null
  br i1 %stream.valid, label %load, label %failure
load:
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %length.matches = icmp eq i64 %length, %expected.length
  br i1 %length.matches, label %check.empty, label %failure
check.empty:
  %empty = icmp eq i64 %expected.length, 0
  br i1 %empty, label %done, label %check.pointers
check.pointers:
  %data.valid = icmp ne ptr %data, null
  %expected.valid = icmp ne ptr %expected, null
  %pointers.valid = and i1 %data.valid, %expected.valid
  br i1 %pointers.valid, label %loop, label %failure
loop:
  %index = phi i64 [ 0, %check.pointers ], [ %next, %advance ]
  %actual.pointer = getelementptr i8, ptr %data, i64 %index
  %expected.pointer = getelementptr i8, ptr %expected, i64 %index
  %actual.byte = load i8, ptr %actual.pointer, align 1
  %expected.byte = load i8, ptr %expected.pointer, align 1
  %matches = icmp eq i8 %actual.byte, %expected.byte
  br i1 %matches, label %advance, label %failure
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %expected.length
  br i1 %complete, label %done, label %loop
failure:
  call void @topal.elf.platform.exit(i64 70)
  unreachable
done:
  ret void
}

define internal void @topal.elf.platform.write_all(ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %done, label %loop
loop:
  %offset = phi i64 [0, %entry], [%next, %progress], [%offset, %retry]
  %remaining = sub i64 %length, %offset
  %cursor = getelementptr i8, ptr %buffer, i64 %offset
  %written = call i64 @topal.elf.platform.write(i64 1, ptr %cursor, i64 %remaining)
  %positive = icmp sgt i64 %written, 0
  br i1 %positive, label %progress, label %error
progress:
  %next = add i64 %offset, %written
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %done, label %loop
error:
  %interrupted = icmp eq i64 %written, -4
  br i1 %interrupted, label %retry, label %failure
retry:
  br label %loop
failure:
  call void @topal.elf.platform.exit(i64 74)
  unreachable
done:
  ret void
}

define internal void @topal.elf.runtime.u64.print(i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %buffer = alloca [20 x i8], align 1
  %zero = icmp eq i64 %value, 0
  br i1 %zero, label %write.zero, label %convert
write.zero:
  %zero.pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 19
  store i8 48, ptr %zero.pointer, align 1
  call void @topal.elf.platform.write_all(ptr %zero.pointer, i64 1)
  ret void
convert:
  %remaining = phi i64 [ %value, %entry ], [ %quotient, %convert ]
  %position = phi i64 [ 20, %entry ], [ %next.position, %convert ]
  %digit = urem i64 %remaining, 10
  %quotient = udiv i64 %remaining, 10
  %next.position = sub i64 %position, 1
  %pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 %next.position
  %digit.byte = trunc i64 %digit to i8
  %ascii = add i8 %digit.byte, 48
  store i8 %ascii, ptr %pointer, align 1
  %complete = icmp eq i64 %quotient, 0
  br i1 %complete, label %write, label %convert
write:
  %length = sub i64 20, %next.position
  call void @topal.elf.platform.write_all(ptr %pointer, i64 %length)
  ret void
}

define internal ptr @topal.elf.runtime.string.make(ptr %data, i64 %length, ptr %display, i64 %display.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %string = call ptr @topal.elf.platform.allocate(i64 32)
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  store ptr %data, ptr %data.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  store ptr %display, ptr %display.pointer, align 8
  store i64 %display.length, ptr %display.length.pointer, align 8
  ret ptr %string
}

define internal void @topal.elf.runtime.string.raw.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  call void @topal.elf.platform.write_all(ptr %data, i64 %length)
  ret void
}

define internal void @topal.elf.runtime.string.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  %display = load ptr, ptr %display.pointer, align 8
  %display.length = load i64, ptr %display.length.pointer, align 8
  %cached = icmp ne ptr %display, null
  br i1 %cached, label %write.cached, label %write.dynamic
write.cached:
  call void @topal.elf.platform.write_all(ptr %display, i64 %display.length)
  ret void
write.dynamic:
  call void @topal.elf.runtime.string.dynamic.print(ptr %string)
  ret void
}

define internal i1 @topal.elf.runtime.string.contains.quote(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %not.found, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %pointer = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %pointer, align 1
  %quote = icmp eq i8 %byte, 34
  br i1 %quote, label %found, label %advance
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %not.found, label %loop
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal i1 @topal.elf.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %minimum = add i64 %underscores, 5
  %possible = icmp ule i64 %minimum, %length
  br i1 %possible, label %search, label %not.found
search:
  %position = phi i64 [ 0, %entry ], [ %next.position, %advance ]
  %remaining = sub i64 %length, %position
  %enough = icmp uge i64 %remaining, %minimum
  br i1 %enough, label %check.base, label %not.found
check.base:
  %quote.pointer = getelementptr i8, ptr %data, i64 %position
  %quote = load i8, ptr %quote.pointer, align 1
  %offset.t0 = add i64 %position, 1
  %offset.e = add i64 %position, 2
  %offset.x = add i64 %position, 3
  %offset.t1 = add i64 %position, 4
  %pointer.t0 = getelementptr i8, ptr %data, i64 %offset.t0
  %pointer.e = getelementptr i8, ptr %data, i64 %offset.e
  %pointer.x = getelementptr i8, ptr %data, i64 %offset.x
  %pointer.t1 = getelementptr i8, ptr %data, i64 %offset.t1
  %byte.t0 = load i8, ptr %pointer.t0, align 1
  %byte.e = load i8, ptr %pointer.e, align 1
  %byte.x = load i8, ptr %pointer.x, align 1
  %byte.t1 = load i8, ptr %pointer.t1, align 1
  %match.quote = icmp eq i8 %quote, 34
  %match.t0 = icmp eq i8 %byte.t0, 116
  %match.e = icmp eq i8 %byte.e, 101
  %match.x = icmp eq i8 %byte.x, 120
  %match.t1 = icmp eq i8 %byte.t1, 116
  %match.0 = and i1 %match.quote, %match.t0
  %match.1 = and i1 %match.0, %match.e
  %match.2 = and i1 %match.1, %match.x
  %match.base = and i1 %match.2, %match.t1
  br i1 %match.base, label %check.underscores, label %advance
check.underscores:
  %underscore.index = phi i64 [ 0, %check.base ], [ %next.underscore, %underscore.advance ]
  %underscores.complete = icmp eq i64 %underscore.index, %underscores
  br i1 %underscores.complete, label %found, label %check.underscore
check.underscore:
  %underscore.offset.base = add i64 %position, 5
  %underscore.offset = add i64 %underscore.offset.base, %underscore.index
  %underscore.pointer = getelementptr i8, ptr %data, i64 %underscore.offset
  %underscore.byte = load i8, ptr %underscore.pointer, align 1
  %match.underscore = icmp eq i8 %underscore.byte, 95
  br i1 %match.underscore, label %underscore.advance, label %advance
underscore.advance:
  %next.underscore = add i64 %underscore.index, 1
  br label %check.underscores
advance:
  %next.position = add i64 %position, 1
  br label %search
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal void @topal.elf.runtime.string.write.underscores(i64 %count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %done, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.byte.underscore, i64 1)
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %count
  br i1 %complete, label %done, label %loop
done:
  ret void
}

define internal void @topal.elf.runtime.string.dynamic.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %contains.quote = call i1 @topal.elf.runtime.string.contains.quote(ptr %data, i64 %length)
  br i1 %contains.quote, label %select.tag, label %plain
plain:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.byte.quote, i64 1)
  call void @topal.elf.platform.write_all(ptr %data, i64 %length)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.byte.quote, i64 1)
  ret void
select.tag:
  %underscores = phi i64 [ 0, %entry ], [ %next.underscores, %collision ]
  %collides = call i1 @topal.elf.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores)
  br i1 %collides, label %collision, label %tagged
collision:
  %next.underscores = add i64 %underscores, 1
  br label %select.tag
tagged:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.string.tag.text, i64 4)
  call void @topal.elf.runtime.string.write.underscores(i64 %underscores)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.byte.quote, i64 1)
  call void @topal.elf.platform.write_all(ptr %data, i64 %length)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.byte.quote, i64 1)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.string.tag.text, i64 4)
  call void @topal.elf.runtime.string.write.underscores(i64 %underscores)
  ret void
}

define internal ptr @topal.elf.runtime.string.concat(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %length = add i64 %left.length, %right.length
  %valid = icmp uge i64 %length, %left.length
  br i1 %valid, label %allocate, label %failure
failure:
  call void @topal.elf.platform.exit(i64 71)
  unreachable
allocate:
  %empty = icmp eq i64 %length, 0
  %allocation.length = select i1 %empty, i64 1, i64 %length
  %data = call ptr @topal.elf.platform.allocate(i64 %allocation.length)
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %data, ptr %left.data, i64 %left.length, i1 false)
  %right.destination = getelementptr i8, ptr %data, i64 %left.length
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %right.destination, ptr %right.data, i64 %right.length, i1 false)
  %result = call ptr @topal.elf.runtime.string.make(ptr %data, i64 %length, ptr null, i64 0)
  ret ptr %result
}

define internal i1 @topal.elf.runtime.string.is.empty(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  ret i1 %empty
}

define internal ptr @topal.elf.runtime.string.utf8.byte.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %count = call ptr @topal.elf.runtime.int.from.u64(i64 %length)
  ret ptr %count
}

define internal ptr @topal.elf.runtime.string.unicode.scalar.value(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  switch i64 %length, label %invalid [
    i64 1, label %one
    i64 2, label %two
    i64 3, label %three
    i64 4, label %four
  ]
one:
  %one.byte = load i8, ptr %data, align 1
  %one.ascii = icmp ult i8 %one.byte, -128
  br i1 %one.ascii, label %one.valid, label %invalid
one.valid:
  %one.value = zext i8 %one.byte to i64
  br label %complete
two:
  %two.byte.0 = load i8, ptr %data, align 1
  %two.pointer.1 = getelementptr i8, ptr %data, i64 1
  %two.byte.1 = load i8, ptr %two.pointer.1, align 1
  %two.lead = and i8 %two.byte.0, -32
  %two.lead.valid = icmp eq i8 %two.lead, -64
  %two.continuation = and i8 %two.byte.1, -64
  %two.continuation.valid = icmp eq i8 %two.continuation, -128
  %two.valid = and i1 %two.lead.valid, %two.continuation.valid
  br i1 %two.valid, label %two.decode, label %invalid
two.decode:
  %two.head.masked = and i8 %two.byte.0, 31
  %two.tail.masked = and i8 %two.byte.1, 63
  %two.head = zext i8 %two.head.masked to i64
  %two.tail = zext i8 %two.tail.masked to i64
  %two.shifted = shl i64 %two.head, 6
  %two.value = or i64 %two.shifted, %two.tail
  br label %complete
three:
  %three.byte.0 = load i8, ptr %data, align 1
  %three.pointer.1 = getelementptr i8, ptr %data, i64 1
  %three.pointer.2 = getelementptr i8, ptr %data, i64 2
  %three.byte.1 = load i8, ptr %three.pointer.1, align 1
  %three.byte.2 = load i8, ptr %three.pointer.2, align 1
  %three.head.masked = and i8 %three.byte.0, 15
  %three.middle.masked = and i8 %three.byte.1, 63
  %three.tail.masked = and i8 %three.byte.2, 63
  %three.head = zext i8 %three.head.masked to i64
  %three.middle = zext i8 %three.middle.masked to i64
  %three.tail = zext i8 %three.tail.masked to i64
  %three.head.shifted = shl i64 %three.head, 12
  %three.middle.shifted = shl i64 %three.middle, 6
  %three.partial = or i64 %three.head.shifted, %three.middle.shifted
  %three.value = or i64 %three.partial, %three.tail
  br label %complete
four:
  %four.byte.0 = load i8, ptr %data, align 1
  %four.pointer.1 = getelementptr i8, ptr %data, i64 1
  %four.pointer.2 = getelementptr i8, ptr %data, i64 2
  %four.pointer.3 = getelementptr i8, ptr %data, i64 3
  %four.byte.1 = load i8, ptr %four.pointer.1, align 1
  %four.byte.2 = load i8, ptr %four.pointer.2, align 1
  %four.byte.3 = load i8, ptr %four.pointer.3, align 1
  %four.head.masked = and i8 %four.byte.0, 7
  %four.second.masked = and i8 %four.byte.1, 63
  %four.third.masked = and i8 %four.byte.2, 63
  %four.tail.masked = and i8 %four.byte.3, 63
  %four.head = zext i8 %four.head.masked to i64
  %four.second = zext i8 %four.second.masked to i64
  %four.third = zext i8 %four.third.masked to i64
  %four.tail = zext i8 %four.tail.masked to i64
  %four.head.shifted = shl i64 %four.head, 18
  %four.second.shifted = shl i64 %four.second, 12
  %four.third.shifted = shl i64 %four.third, 6
  %four.partial.0 = or i64 %four.head.shifted, %four.second.shifted
  %four.partial.1 = or i64 %four.partial.0, %four.third.shifted
  %four.value = or i64 %four.partial.1, %four.tail
  br label %complete
complete:
  %value = phi i64 [ %one.value, %one.valid ], [ %two.value, %two.decode ], [ %three.value, %three ], [ %four.value, %four ]
  %result = call ptr @topal.elf.runtime.int.from.u64(i64 %value)
  ret ptr %result
invalid:
  call void @topal.elf.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.elf.runtime.string.unicode.scalar.characters(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  br label %loop
loop:
  %offset = phi i64 [ 0, %entry ], [ %next.offset, %append ]
  %head = phi ptr [ null, %entry ], [ %next.head, %append ]
  %tail = phi ptr [ null, %entry ], [ %node, %append ]
  %complete = icmp eq i64 %offset, %length
  br i1 %complete, label %done, label %decode
decode:
  %byte.pointer = getelementptr i8, ptr %data, i64 %offset
  %byte = load i8, ptr %byte.pointer, align 1
  %ascii = icmp ult i8 %byte, -128
  %two.mask = and i8 %byte, -32
  %two = icmp eq i8 %two.mask, -64
  %three.mask = and i8 %byte, -16
  %three = icmp eq i8 %three.mask, -32
  %non.ascii.width = select i1 %two, i64 2, i64 4
  %multi.width = select i1 %three, i64 3, i64 %non.ascii.width
  %width = select i1 %ascii, i64 1, i64 %multi.width
  %next.offset = add i64 %offset, %width
  %valid = icmp ule i64 %next.offset, %length
  br i1 %valid, label %make, label %invalid
make:
  %character.data = getelementptr i8, ptr %data, i64 %offset
  %character = call ptr @topal.elf.runtime.string.make(ptr %character.data, i64 %width, ptr null, i64 0)
  %node = call ptr @topal.elf.platform.allocate(i64 16)
  store ptr %character, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %append, label %link
link:
  %tail.next = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next, align 8
  br label %append
append:
  %next.head = select i1 %empty, ptr %node, ptr %head
  br label %loop
done:
  ret ptr %head
invalid:
  call void @topal.elf.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.elf.runtime.string.select.index.range(ptr %string, ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.elf.runtime.string.unicode.scalar.characters(ptr %string)
  %empty.data = call ptr @topal.elf.platform.allocate(i64 1)
  %empty = call ptr @topal.elf.runtime.string.make(ptr %empty.data, i64 0, ptr null, i64 0)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %index = phi i64 [ 0, %entry ], [ %next.index, %advance ]
  %selected = phi ptr [ %empty, %entry ], [ %next.selected, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %visit
visit:
  %index.value = call ptr @topal.elf.runtime.int.from.u64(i64 %index)
  %present = call i1 @topal.elf.runtime.range.int.contains(ptr %range, ptr %index.value)
  %character = load ptr, ptr %current, align 8
  br i1 %present, label %append, label %skip
append:
  %appended = call ptr @topal.elf.runtime.string.concat(ptr %selected, ptr %character)
  br label %advance
skip:
  br label %advance
advance:
  %next.selected = phi ptr [ %appended, %append ], [ %selected, %skip ]
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.index = add i64 %index, 1
  br label %loop
done:
  ret ptr %selected
}

define internal ptr @topal.elf.runtime.string.character.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.elf.runtime.string.unicode.scalar.characters(ptr %string)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %count = phi i64 [ 0, %entry ], [ %next.count, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.count = add i64 %count, 1
  br label %loop
done:
  %value = call ptr @topal.elf.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.elf.runtime.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %same.length = icmp eq i64 %left.length, %right.length
  br i1 %same.length, label %loop, label %not.equal
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %complete = icmp eq i64 %index, %left.length
  br i1 %complete, label %equal, label %compare
compare:
  %left.pointer = getelementptr i8, ptr %left.data, i64 %index
  %right.pointer = getelementptr i8, ptr %right.data, i64 %index
  %left.byte = load i8, ptr %left.pointer, align 1
  %right.byte = load i8, ptr %right.pointer, align 1
  %same.byte = icmp eq i8 %left.byte, %right.byte
  br i1 %same.byte, label %advance, label %not.equal
advance:
  %next = add i64 %index, 1
  br label %loop
equal:
  ret i1 true
not.equal:
  ret i1 false
}

define internal ptr @topal.elf.runtime.result.success(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.elf.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal ptr @topal.elf.runtime.result.error(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.elf.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal i1 @topal.elf.runtime.result.is.error(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %is.error = icmp eq i64 %tag, 1
  ret i1 %is.error
}

define internal ptr @topal.elf.runtime.result.payload(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.elf.runtime.optional.some(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.elf.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal ptr @topal.elf.runtime.optional.none() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.elf.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal i1 @topal.elf.runtime.optional.is.some(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid
checked:
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some
invalid:
  call void @topal.elf.platform.exit(i64 70)
  unreachable
}

define internal ptr @topal.elf.runtime.optional.payload(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.elf.runtime.optional.from.nullable(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %present = icmp ne ptr %payload, null
  br i1 %present, label %some, label %none
some:
  %some.value = call ptr @topal.elf.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.elf.runtime.optional.none()
  ret ptr %none.value
}

define internal i1 @topal.elf.runtime.optional.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.elf.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.elf.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.elf.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.elf.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.elf.runtime.int.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.elf.runtime.optional.rational.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.elf.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.elf.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.elf.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.elf.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.elf.runtime.rational.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.elf.runtime.optional.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.elf.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.elf.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.elf.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.elf.runtime.optional.payload(ptr %right)
  %payloads.equal = call i1 @topal.elf.runtime.string.equal(ptr %left.payload, ptr %right.payload)
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal ptr @topal.elf.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.elf.platform.allocate(i64 56)
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %reserved.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 2
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  store ptr %domain, ptr %domain.pointer, align 8
  store i32 %code, ptr %code.pointer, align 4
  store i32 0, ptr %reserved.pointer, align 4
  store ptr null, ptr %detail.pointer, align 8
  store ptr null, ptr %cause.pointer, align 8
  store ptr %source, ptr %source.pointer, align 8
  store i64 %line, ptr %line.pointer, align 8
  store i64 %column, ptr %column.pointer, align 8
  ret ptr %error
}

define internal i32 @topal.elf.runtime.error.code(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %code = load i32, ptr %code.pointer, align 4
  ret i32 %code
}

define internal ptr @topal.elf.runtime.error.domain(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %domain = load ptr, ptr %domain.pointer, align 8
  ret ptr %domain
}

define internal ptr @topal.elf.runtime.error.detail(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %detail = load ptr, ptr %detail.pointer, align 8
  %optional = call ptr @topal.elf.runtime.optional.from.nullable(ptr %detail)
  ret ptr %optional
}

define internal ptr @topal.elf.runtime.error.cause(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %cause = load ptr, ptr %cause.pointer, align 8
  %optional = call ptr @topal.elf.runtime.optional.from.nullable(ptr %cause)
  ret ptr %optional
}

define internal ptr @topal.elf.runtime.error.source(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %source = load ptr, ptr %source.pointer, align 8
  %present = icmp ne ptr %source, null
  br i1 %present, label %some, label %none
some:
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  %line.number = load i64, ptr %line.pointer, align 8
  %column.number = load i64, ptr %column.pointer, align 8
  %line = call ptr @topal.elf.runtime.int.from.u64(i64 %line.number)
  %column = call ptr @topal.elf.runtime.int.from.u64(i64 %column.number)
  %location = call ptr @topal.elf.platform.allocate(i64 16)
  %location.line = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %location.column = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  store ptr %line, ptr %location.line, align 8
  store ptr %column, ptr %location.column, align 8
  %some.value = call ptr @topal.elf.runtime.optional.some(ptr %location)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.elf.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.elf.runtime.source.location.line(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %line.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %line = load ptr, ptr %line.pointer, align 8
  ret ptr %line
}

define internal ptr @topal.elf.runtime.source.location.column(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %column.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  %column = load ptr, ptr %column.pointer, align 8
  ret ptr %column
}

define internal ptr @topal.elf.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.elf.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  %result = call ptr @topal.elf.runtime.result.error(ptr %error)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.int.try.to.nat(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %success
failure:
  %failed = call ptr @topal.elf.runtime.result.failure(i32 0, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %result = call ptr @topal.elf.runtime.result.success(ptr %value)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.try.to.int(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %value)
  %ordering = call i32 @topal.elf.runtime.int.compare(ptr %denominator, ptr @topal.elf.runtime.int.one)
  %exact = icmp eq i32 %ordering, 0
  br i1 %exact, label %success, label %failure
failure:
  %failed = call ptr @topal.elf.runtime.result.failure(i32 1, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %value)
  %result = call ptr @topal.elf.runtime.result.success(ptr %numerator)
  ret ptr %result
}

define internal void @topal.elf.runtime.error.print(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %domain = load ptr, ptr %domain.pointer, align 8
  %code = load i32, ptr %code.pointer, align 4
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.error.prefix, i64 18)
  call void @topal.elf.runtime.string.raw.print(ptr %domain)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.error.code.separator, i64 10)
  call void @topal.elf.runtime.error.code.print(i32 %code)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.error.suffix, i64 2)
  ret void
}

define internal void @topal.elf.runtime.error.code.print(i32 %code) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  switch i32 %code, label %indeterminate [ i32 0, label %out.of.range i32 1, label %not.representable i32 2, label %division.by.zero ]
out.of.range:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.error.code.out.of.range, i64 12)
  br label %done
not.representable:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.error.code.not.representable, i64 17)
  br label %done
division.by.zero:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.error.code.division.by.zero, i64 16)
  br label %done
indeterminate:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.error.code.indeterminate, i64 13)
  br label %done
done:
  ret void
}

define internal ptr @topal.elf.runtime.int.allocate(i64 %length, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure
allocate:
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.elf.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value
failure:
  call void @topal.elf.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.elf.runtime.int.from.u64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero
zero:
  ret ptr @topal.elf.runtime.int.zero
nonzero:
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.elf.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done
store.high:
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done
done:
  ret ptr %value
}

define internal ptr @topal.elf.runtime.int.from.i64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = icmp slt i64 %source, 0
  %negated = sub i64 0, %source
  %magnitude = select i1 %negative, i64 %negated, i64 %source
  %value = call ptr @topal.elf.runtime.int.from.u64(i64 %magnitude)
  br i1 %negative, label %signed, label %done
signed:
  %negative.value = call ptr @topal.elf.runtime.int.copy.with.sign(ptr %value, i64 1)
  ret ptr %negative.value
done:
  ret ptr %value
}

define internal i32 @topal.elf.runtime.int.to.c.i32(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %sign = load i64, ptr %sign.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %return.zero, label %nonzero
return.zero:
  ret i32 0
nonzero:
  %one.limb = icmp eq i64 %length, 1
  %finite.sign = icmp ule i64 %sign, 1
  %shape.valid = and i1 %one.limb, %finite.sign
  br i1 %shape.valid, label %load, label %failure
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %limb = load i32, ptr %limb.pointer, align 4
  %negative = icmp eq i64 %sign, 1
  %positive.valid = icmp ule i32 %limb, 2147483647
  %negative.valid = icmp ule i32 %limb, 2147483648
  %range.valid = select i1 %negative, i1 %negative.valid, i1 %positive.valid
  br i1 %range.valid, label %convert, label %failure
convert:
  %negated = sub i32 0, %limb
  %result = select i1 %negative, i32 %negated, i32 %limb
  ret i32 %result
failure:
  call void @topal.elf.runtime.c.int32.range.fail()
  unreachable
}

define internal i64 @topal.elf.runtime.int.limb.or.zero(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended
zero:
  ret i64 0
}

define internal ptr @topal.elf.runtime.int.normalize(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim
trim:
  %candidate = phi i64 [%length, %entry], [%next, %leading.zero]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done
leading.zero:
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim
zero:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value
done:
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.elf.runtime.int.copy.with.sign(ptr %value, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate
zero:
  ret ptr @topal.elf.runtime.int.zero
allocate:
  %copy = call ptr @topal.elf.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %allocate], [%next, %loop]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  ret ptr %copy
}

define internal ptr @topal.elf.runtime.int.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  ret ptr @topal.elf.runtime.int.negative.infinity
negative.infinity:
  ret ptr @topal.elf.runtime.int.positive.infinity
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %copy
zero:
  ret ptr @topal.elf.runtime.int.zero
copy:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %opposite = xor i64 %negative, 1
  %result = call ptr @topal.elf.runtime.int.copy.with.sign(ptr %value, i64 %opposite)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.int.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite
infinite:
  ret ptr @topal.elf.runtime.int.positive.infinity
finite:
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy
same:
  ret ptr %value
copy:
  %result = call ptr @topal.elf.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

define internal i32 @topal.elf.runtime.int.compare.absolute(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer
check.longer:
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty
check.empty:
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs
limbs:
  %position = phi i64 [%left.length, %check.empty], [%index, %limbs.equal]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater
check.limb.greater:
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal
limbs.equal:
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal
less:
  ret i32 -1
equal:
  ret i32 0
greater:
  ret i32 1
}

define internal i32 @topal.elf.runtime.int.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity
left.positive:
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result
check.left.negative.infinity:
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity
left.negative:
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result
check.right.positive.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity
check.right.negative.infinity:
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite
less:
  ret i32 -1
greater:
  ret i32 1
finite:
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute
signed.result:
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result
absolute:
  %magnitude = call i32 @topal.elf.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

define internal ptr @topal.elf.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.elf.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %carry = phi i64 [0, %entry], [%next.carry, %loop]
  %left.limb = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish
finish:
  %final.carry = phi i64 [0, %entry], [%next.carry, %loop]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry
store.carry:
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result
without.carry:
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.elf.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.elf.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.elf.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %borrow = phi i64 [0, %entry], [%next.borrow, %loop]
  %left = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.elf.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  %normalized = call ptr @topal.elf.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.elf.runtime.int.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity
validate.left.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity
indeterminate.infinity:
  call void @topal.elf.platform.exit(i64 70)
  unreachable
return.left.infinity:
  ret ptr %left
check.right.infinity:
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite
return.right.infinity:
  ret ptr %right
finite:
  %left.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right
return.right:
  ret ptr %right
check.right:
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero
return.left:
  ret ptr %left
nonzero:
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference
sum:
  %sum.value = call ptr @topal.elf.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value
difference:
  %ordering = call i32 @topal.elf.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger
zero:
  ret ptr @topal.elf.runtime.int.zero
select.larger:
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference
left.difference:
  %left.value = call ptr @topal.elf.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value
right.difference:
  %right.value = call ptr @topal.elf.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

define internal ptr @topal.elf.runtime.int.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %opposite = call ptr @topal.elf.runtime.int.negate(ptr %right)
  %result = call ptr @topal.elf.runtime.int.add(ptr %left, ptr %opposite)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.int.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %left.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity
indeterminate.infinity:
  call void @topal.elf.platform.exit(i64 70)
  unreachable
select.infinity:
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.elf.runtime.int.negative.infinity, ptr @topal.elf.runtime.int.positive.infinity
  ret ptr %infinity
finite:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length
zero:
  ret ptr @topal.elf.runtime.int.zero
check.length:
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate
failure:
  call void @topal.elf.platform.exit(i64 71)
  unreachable
allocate:
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.elf.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear
clear:
  %clear.index = phi i64 [0, %allocate], [%clear.next, %clear]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry
outer.entry:
  br label %outer
outer:
  %left.index = phi i64 [0, %outer.entry], [%left.next, %outer.done]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner
inner:
  %right.index = phi i64 [0, %outer], [%right.next, %inner]
  %carry = phi i64 [0, %outer], [%next.carry, %inner]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done
outer.done:
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done
done:
  %normalized = call ptr @topal.elf.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal void @topal.elf.runtime.int.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.int.positive.infinity.text, i64 9)
  ret void
negative.infinity:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.int.negative.infinity.text, i64 9)
  ret void
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check.sign
zero:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.byte.zero, i64 1)
  ret void
check.sign:
  %is.negative = icmp ne i64 %sign, 0
  br i1 %is.negative, label %write.sign, label %prepare
write.sign:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.byte.minus, i64 1)
  br label %prepare
prepare:
  %capacity.valid = icmp ule i64 %length, 922337203685477580
  br i1 %capacity.valid, label %allocate, label %failure
failure:
  call void @topal.elf.platform.exit(i64 71)
  unreachable
allocate:
  %scratch.bytes = mul i64 %length, 4
  %capacity = mul i64 %length, 10
  %scratch = call ptr @topal.elf.platform.allocate(i64 %scratch.bytes)
  %buffer = call ptr @topal.elf.platform.allocate(i64 %capacity)
  br label %copy
copy:
  %copy.index = phi i64 [0, %allocate], [%copy.next, %copy]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %copy.index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr i32, ptr %scratch, i64 %copy.index
  store i32 %limb, ptr %destination, align 4
  %copy.next = add i64 %copy.index, 1
  %copy.more = icmp ult i64 %copy.next, %length
  br i1 %copy.more, label %copy, label %digits
digits:
  %work.length = phi i64 [%length, %copy], [%next.length, %division.finish]
  %position = phi i64 [%capacity, %copy], [%next.position, %division.finish]
  br label %divide
divide:
  %division.position = phi i64 [%work.length, %digits], [%division.index, %divide.step]
  %remainder = phi i64 [0, %digits], [%next.remainder, %divide.step]
  %division.index = sub i64 %division.position, 1
  %work.pointer = getelementptr i32, ptr %scratch, i64 %division.index
  %work.raw = load i32, ptr %work.pointer, align 4
  %work = zext i32 %work.raw to i64
  %high = shl i64 %remainder, 32
  %current = or i64 %high, %work
  %quotient = udiv i64 %current, 10
  %next.remainder = urem i64 %current, 10
  %quotient.limb = trunc i64 %quotient to i32
  store i32 %quotient.limb, ptr %work.pointer, align 4
  %division.more = icmp ne i64 %division.index, 0
  br i1 %division.more, label %divide.step, label %division.done
divide.step:
  br label %divide
division.done:
  %next.position = sub i64 %position, 1
  %digit = trunc i64 %next.remainder to i8
  %ascii = add i8 %digit, 48
  %digit.pointer = getelementptr i8, ptr %buffer, i64 %next.position
  store i8 %ascii, ptr %digit.pointer, align 1
  br label %trim
trim:
  %candidate = phi i64 [%work.length, %division.done], [%trim.next, %trim.zero]
  %trim.index = sub i64 %candidate, 1
  %trim.pointer = getelementptr i32, ptr %scratch, i64 %trim.index
  %trim.limb = load i32, ptr %trim.pointer, align 4
  %leading.zero = icmp eq i32 %trim.limb, 0
  br i1 %leading.zero, label %trim.zero, label %trim.done
trim.zero:
  %trim.next = sub i64 %candidate, 1
  %trim.empty = icmp eq i64 %trim.next, 0
  br i1 %trim.empty, label %trim.empty.done, label %trim
trim.empty.done:
  br label %division.finish
trim.done:
  br label %division.finish
division.finish:
  %next.length = phi i64 [0, %trim.empty.done], [%candidate, %trim.done]
  %more.digits = icmp ne i64 %next.length, 0
  br i1 %more.digits, label %digits, label %emit
emit:
  %count = sub i64 %capacity, %next.position
  %first = getelementptr i8, ptr %buffer, i64 %next.position
  call void @topal.elf.platform.write_all(ptr %first, i64 %count)
  ret void
}

define internal i1 @topal.elf.runtime.int.is.zero(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

define internal ptr @topal.elf.runtime.int.divmod.pair(ptr %quotient, ptr %remainder) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.elf.platform.allocate(i64 16)
  %quotient.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %remainder.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  store ptr %quotient, ptr %quotient.pointer, align 8
  store ptr %remainder, ptr %remainder.pointer, align 8
  ret ptr %pair
}

define internal ptr @topal.elf.runtime.int.divmod.quotient(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.elf.runtime.int.divmod.remainder(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i64 @topal.elf.runtime.int.bit.length(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check
zero:
  ret i64 0
check:
  %valid = icmp ule i64 %length, 576460752303423487
  br i1 %valid, label %calculate, label %failure
failure:
  call void @topal.elf.platform.exit(i64 71)
  unreachable
calculate:
  %last = sub i64 %length, 1
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %last
  %limb = load i32, ptr %pointer, align 4
  %leading = call i32 @llvm.ctlz.i32(i32 %limb, i1 false)
  %top.bits.raw = sub i32 32, %leading
  %top.bits = zext i32 %top.bits.raw to i64
  %lower.bits = mul i64 %last, 32
  %bits = add i64 %lower.bits, %top.bits
  ret i64 %bits
}

define internal i1 @topal.elf.runtime.int.bit.at(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %limb.index = lshr i64 %index, 5
  %offset.raw = and i64 %index, 31
  %offset = trunc i64 %offset.raw to i32
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %limb.index
  %limb = load i32, ptr %pointer, align 4
  %shifted = lshr i32 %limb, %offset
  %bit.raw = and i32 %shifted, 1
  %bit = icmp ne i32 %bit.raw, 0
  ret i1 %bit
}

define internal ptr @topal.elf.runtime.int.divmod.absolute(ptr %dividend, ptr %divisor) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %divisor.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %divisor)
  br i1 %divisor.zero, label %failure, label %check.dividend
failure:
  call void @topal.elf.platform.exit(i64 65)
  unreachable
check.dividend:
  %dividend.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %dividend)
  br i1 %dividend.zero, label %zero, label %prepare
zero:
  %zero.pair = call ptr @topal.elf.runtime.int.divmod.pair(ptr @topal.elf.runtime.int.zero, ptr @topal.elf.runtime.int.zero)
  ret ptr %zero.pair
prepare:
  %bits = call i64 @topal.elf.runtime.int.bit.length(ptr %dividend)
  br label %loop
loop:
  %position = phi i64 [%bits, %prepare], [%next.position, %merge]
  %quotient = phi ptr [@topal.elf.runtime.int.zero, %prepare], [%next.quotient, %merge]
  %remainder = phi ptr [@topal.elf.runtime.int.zero, %prepare], [%next.remainder, %merge]
  %bit.index = sub i64 %position, 1
  %bit = call i1 @topal.elf.runtime.int.bit.at(ptr %dividend, i64 %bit.index)
  %quotient.twice = call ptr @topal.elf.runtime.int.add(ptr %quotient, ptr %quotient)
  %remainder.twice = call ptr @topal.elf.runtime.int.add(ptr %remainder, ptr %remainder)
  br i1 %bit, label %append.bit, label %compare
append.bit:
  %remainder.with.bit = call ptr @topal.elf.runtime.int.add(ptr %remainder.twice, ptr @topal.elf.runtime.int.one)
  br label %compare
compare:
  %candidate = phi ptr [%remainder.twice, %loop], [%remainder.with.bit, %append.bit]
  %ordering = call i32 @topal.elf.runtime.int.compare.absolute(ptr %candidate, ptr %divisor)
  %subtract = icmp sge i32 %ordering, 0
  br i1 %subtract, label %subtract.divisor, label %retain
subtract.divisor:
  %reduced = call ptr @topal.elf.runtime.int.subtract.absolute(ptr %candidate, ptr %divisor, i64 0)
  %incremented = call ptr @topal.elf.runtime.int.add(ptr %quotient.twice, ptr @topal.elf.runtime.int.one)
  br label %merge
retain:
  br label %merge
merge:
  %next.quotient = phi ptr [%incremented, %subtract.divisor], [%quotient.twice, %retain]
  %next.remainder = phi ptr [%reduced, %subtract.divisor], [%candidate, %retain]
  %next.position = sub i64 %position, 1
  %more = icmp ne i64 %next.position, 0
  br i1 %more, label %loop, label %done
done:
  %pair = call ptr @topal.elf.runtime.int.divmod.pair(ptr %next.quotient, ptr %next.remainder)
  ret ptr %pair
}

define internal ptr @topal.elf.runtime.int.quotient.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %divide
failure:
  call void @topal.elf.platform.exit(i64 65)
  unreachable
divide:
  %left.absolute = call ptr @topal.elf.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.elf.runtime.int.absolute(ptr %right)
  %unsigned = call ptr @topal.elf.runtime.int.divmod.absolute(ptr %left.absolute, ptr %right.absolute)
  %quotient.absolute = call ptr @topal.elf.runtime.int.divmod.quotient(ptr %unsigned)
  %remainder.absolute = call ptr @topal.elf.runtime.int.divmod.remainder(ptr %unsigned)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.negative = icmp ne i64 %left.sign, 0
  %remainder.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %remainder.absolute)
  %remainder.present = xor i1 %remainder.zero, true
  %needs.adjustment = and i1 %left.negative, %remainder.present
  %quotient.sign = xor i64 %left.sign, %right.sign
  br i1 %needs.adjustment, label %adjust, label %direct
direct:
  %direct.quotient = call ptr @topal.elf.runtime.int.copy.with.sign(ptr %quotient.absolute, i64 %quotient.sign)
  %direct.pair = call ptr @topal.elf.runtime.int.divmod.pair(ptr %direct.quotient, ptr %remainder.absolute)
  ret ptr %direct.pair
adjust:
  %larger.quotient = call ptr @topal.elf.runtime.int.add(ptr %quotient.absolute, ptr @topal.elf.runtime.int.one)
  %adjusted.quotient = call ptr @topal.elf.runtime.int.copy.with.sign(ptr %larger.quotient, i64 %quotient.sign)
  %adjusted.remainder = call ptr @topal.elf.runtime.int.subtract.absolute(ptr %right.absolute, ptr %remainder.absolute, i64 0)
  %adjusted.pair = call ptr @topal.elf.runtime.int.divmod.pair(ptr %adjusted.quotient, ptr %adjusted.remainder)
  ret ptr %adjusted.pair
}

define internal ptr @topal.elf.runtime.int.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.elf.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %remainder = call ptr @topal.elf.runtime.int.divmod.remainder(ptr %pair)
  ret ptr %remainder
}

define internal ptr @topal.elf.runtime.int.try.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.elf.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %remainder = call ptr @topal.elf.runtime.int.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.elf.runtime.result.success(ptr %remainder)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.int.try.quotient.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.elf.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %pair = call ptr @topal.elf.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.elf.runtime.result.success(ptr %pair)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.int.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %prepare
failure:
  call void @topal.elf.platform.exit(i64 65)
  unreachable
prepare:
  %bits = call i64 @topal.elf.runtime.int.bit.length(ptr %exponent)
  %empty = icmp eq i64 %bits, 0
  br i1 %empty, label %one, label %loop
one:
  ret ptr @topal.elf.runtime.int.one
loop:
  %position = phi i64 [0, %prepare], [%next.position, %square]
  %result = phi ptr [@topal.elf.runtime.int.one, %prepare], [%next.result, %square]
  %factor = phi ptr [%base, %prepare], [%next.factor, %square]
  %bit = call i1 @topal.elf.runtime.int.bit.at(ptr %exponent, i64 %position)
  br i1 %bit, label %multiply, label %retain
multiply:
  %product = call ptr @topal.elf.runtime.int.multiply(ptr %result, ptr %factor)
  br label %advance
retain:
  br label %advance
advance:
  %next.result = phi ptr [%product, %multiply], [%result, %retain]
  %next.position = add i64 %position, 1
  %complete = icmp eq i64 %next.position, %bits
  br i1 %complete, label %done, label %square
square:
  %next.factor = call ptr @topal.elf.runtime.int.multiply(ptr %factor, ptr %factor)
  br label %loop
done:
  ret ptr %next.result
}

define internal ptr @topal.elf.runtime.int.greatest.common.divisor(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.absolute = call ptr @topal.elf.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.elf.runtime.int.absolute(ptr %right)
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right.absolute)
  br i1 %right.zero, label %initial.done, label %loop
initial.done:
  ret ptr %left.absolute
loop:
  %current.left = phi ptr [%left.absolute, %entry], [%current.right, %again]
  %current.right = phi ptr [%right.absolute, %entry], [%remainder, %again]
  %division = call ptr @topal.elf.runtime.int.divmod.absolute(ptr %current.left, ptr %current.right)
  %remainder = call ptr @topal.elf.runtime.int.divmod.remainder(ptr %division)
  %done = call i1 @topal.elf.runtime.int.is.zero(ptr %remainder)
  br i1 %done, label %result, label %again
again:
  br label %loop
result:
  ret ptr %current.right
}

define internal ptr @topal.elf.runtime.rational.raw(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.elf.platform.allocate(i64 16)
  %numerator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %denominator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  store ptr %numerator, ptr %numerator.pointer, align 8
  store ptr %denominator, ptr %denominator.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.elf.runtime.rational.numerator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %numerator = load ptr, ptr %pointer, align 8
  ret ptr %numerator
}

define internal ptr @topal.elf.runtime.rational.denominator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  %denominator = load ptr, ptr %pointer, align 8
  ret ptr %denominator
}

define internal ptr @topal.elf.runtime.rational.make(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %numerator.sign = load i64, ptr %numerator.sign.pointer, align 8
  %positive.infinity = icmp eq i64 %numerator.sign, 2
  %negative.infinity = icmp eq i64 %numerator.sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %make.infinity, label %finite
make.infinity:
  %infinite.value = call ptr @topal.elf.runtime.rational.raw(ptr %numerator, ptr @topal.elf.runtime.int.one)
  ret ptr %infinite.value
finite:
  %denominator.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %check.numerator
failure:
  call void @topal.elf.platform.exit(i64 65)
  unreachable
check.numerator:
  %numerator.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %numerator)
  br i1 %numerator.zero, label %zero, label %normalize
zero:
  %zero.value = call ptr @topal.elf.runtime.rational.raw(ptr @topal.elf.runtime.int.zero, ptr @topal.elf.runtime.int.one)
  ret ptr %zero.value
normalize:
  %numerator.absolute = call ptr @topal.elf.runtime.int.absolute(ptr %numerator)
  %denominator.absolute = call ptr @topal.elf.runtime.int.absolute(ptr %denominator)
  %divisor = call ptr @topal.elf.runtime.int.greatest.common.divisor(ptr %numerator.absolute, ptr %denominator.absolute)
  %numerator.division = call ptr @topal.elf.runtime.int.divmod.absolute(ptr %numerator.absolute, ptr %divisor)
  %denominator.division = call ptr @topal.elf.runtime.int.divmod.absolute(ptr %denominator.absolute, ptr %divisor)
  %reduced.numerator.absolute = call ptr @topal.elf.runtime.int.divmod.quotient(ptr %numerator.division)
  %reduced.denominator = call ptr @topal.elf.runtime.int.divmod.quotient(ptr %denominator.division)
  %finite.numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %finite.denominator.sign.pointer = getelementptr %topal.IntStorage, ptr %denominator, i32 0, i32 0
  %finite.numerator.sign = load i64, ptr %finite.numerator.sign.pointer, align 8
  %finite.denominator.sign = load i64, ptr %finite.denominator.sign.pointer, align 8
  %sign = xor i64 %finite.numerator.sign, %finite.denominator.sign
  %reduced.numerator = call ptr @topal.elf.runtime.int.copy.with.sign(ptr %reduced.numerator.absolute, i64 %sign)
  %result = call ptr @topal.elf.runtime.rational.raw(ptr %reduced.numerator, ptr %reduced.denominator)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.from.int(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.elf.runtime.rational.raw(ptr %value, ptr @topal.elf.runtime.int.one)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %value)
  %negative = call ptr @topal.elf.runtime.int.negate(ptr %numerator)
  %result = call ptr @topal.elf.runtime.rational.raw(ptr %negative, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %value)
  %absolute = call ptr @topal.elf.runtime.int.absolute(ptr %numerator)
  %result = call ptr @topal.elf.runtime.rational.raw(ptr %absolute, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %right)
  %left.scaled = call ptr @topal.elf.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.elf.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %numerator = call ptr @topal.elf.runtime.int.add(ptr %left.scaled, ptr %right.scaled)
  %denominator = call ptr @topal.elf.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.elf.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = call ptr @topal.elf.runtime.rational.negate(ptr %right)
  %result = call ptr @topal.elf.runtime.rational.add(ptr %left, ptr %negative)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %right)
  %numerator = call ptr @topal.elf.runtime.int.multiply(ptr %left.numerator, ptr %right.numerator)
  %denominator = call ptr @topal.elf.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.elf.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.divide(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %right)
  %zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right.numerator)
  br i1 %zero, label %failure, label %calculate
failure:
  call void @topal.elf.platform.exit(i64 65)
  unreachable
calculate:
  %numerator = call ptr @topal.elf.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %denominator = call ptr @topal.elf.runtime.int.multiply(ptr %left.denominator, ptr %right.numerator)
  %result = call ptr @topal.elf.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal i32 @topal.elf.runtime.rational.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %right)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left.numerator, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right.numerator, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %infinite.result = call i32 @topal.elf.runtime.int.compare(ptr %left.numerator, ptr %right.numerator)
  ret i32 %infinite.result
finite:
  %left.scaled = call ptr @topal.elf.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.elf.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %result = call i32 @topal.elf.runtime.int.compare(ptr %left.scaled, ptr %right.scaled)
  ret i32 %result
}

define internal ptr @topal.elf.runtime.rational.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %base)
  %denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %base)
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  %absolute.exponent = call ptr @topal.elf.runtime.int.absolute(ptr %exponent)
  %powered.numerator = call ptr @topal.elf.runtime.int.power(ptr %numerator, ptr %absolute.exponent)
  %powered.denominator = call ptr @topal.elf.runtime.int.power(ptr %denominator, ptr %absolute.exponent)
  br i1 %negative, label %reciprocal, label %direct
direct:
  %direct.result = call ptr @topal.elf.runtime.rational.raw(ptr %powered.numerator, ptr %powered.denominator)
  ret ptr %direct.result
reciprocal:
  %zero = call i1 @topal.elf.runtime.int.is.zero(ptr %powered.numerator)
  br i1 %zero, label %failure, label %invert
failure:
  call void @topal.elf.platform.exit(i64 65)
  unreachable
invert:
  %result = call ptr @topal.elf.runtime.rational.make(ptr %powered.denominator, ptr %powered.numerator)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.try.make(ptr %numerator, ptr %denominator, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %success
failure:
  %numerator.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %numerator)
  %code = select i1 %numerator.zero, i32 3, i32 2
  %failed = call ptr @topal.elf.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.elf.runtime.rational.make(ptr %numerator, ptr %denominator)
  %result = call ptr @topal.elf.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.try.divide(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %right)
  %right.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %right.numerator)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.elf.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.elf.runtime.rational.divide(ptr %left, ptr %right)
  %result = call ptr @topal.elf.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.rational.try.power(ptr %base, ptr %exponent, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  br i1 %negative, label %check.base, label %success
check.base:
  %numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %base)
  %base.zero = call i1 @topal.elf.runtime.int.is.zero(ptr %numerator)
  br i1 %base.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.elf.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.elf.runtime.rational.power(ptr %base, ptr %exponent)
  %result = call ptr @topal.elf.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal void @topal.elf.runtime.rational.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.elf.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.elf.runtime.rational.denominator(ptr %value)
  %sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %positive.infinity = icmp eq i64 %sign, 2
  %negative.infinity = icmp eq i64 %sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %print.infinity, label %print.finite
print.infinity:
  call void @topal.elf.runtime.int.print(ptr %numerator)
  ret void
print.finite:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.rational.prefix, i64 11)
  call void @topal.elf.runtime.int.print(ptr %numerator)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.rational.separator, i64 2)
  call void @topal.elf.runtime.int.print(ptr %denominator)
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.rational.suffix, i64 2)
  ret void
}

define internal ptr @topal.elf.runtime.range.make(ptr %lower, ptr %upper, i64 %lower.inclusive, i64 %upper.inclusive) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.elf.platform.allocate(i64 32)
  %lower.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 0
  %upper.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 1
  %lower.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 2
  %upper.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 3
  store ptr %lower, ptr %lower.pointer, align 8
  store ptr %upper, ptr %upper.pointer, align 8
  store i64 %lower.inclusive, ptr %lower.inclusive.pointer, align 8
  store i64 %upper.inclusive, ptr %upper.inclusive.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.elf.runtime.range.lower(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.elf.runtime.range.upper(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i1 @topal.elf.runtime.range.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.elf.runtime.range.lower(ptr %left)
  %right.lower = call ptr @topal.elf.runtime.range.lower(ptr %right)
  %lower.ordering = call i32 @topal.elf.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.upper = call ptr @topal.elf.runtime.range.upper(ptr %left)
  %right.upper = call ptr @topal.elf.runtime.range.upper(ptr %right)
  %upper.ordering = call i32 @topal.elf.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %bounds.equal = and i1 %lower.equal, %upper.equal
  %left.lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %right)
  %lower.inclusive.equal = icmp eq i1 %left.lower.inclusive, %right.lower.inclusive
  %left.upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %left)
  %right.upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %right)
  %upper.inclusive.equal = icmp eq i1 %left.upper.inclusive, %right.upper.inclusive
  %inclusivity.equal = and i1 %lower.inclusive.equal, %upper.inclusive.equal
  %equal = and i1 %bounds.equal, %inclusivity.equal
  ret i1 %equal
}

define internal i1 @topal.elf.runtime.range.lower.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 2
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.elf.runtime.range.upper.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 3
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.elf.runtime.range.empty.from.comparison(ptr %range, i32 %ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %reversed = icmp sgt i32 %ordering, 0
  %equal = icmp eq i32 %ordering, 0
  %lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %range)
  %both.inclusive = and i1 %lower.inclusive, %upper.inclusive
  %open.equal = xor i1 %both.inclusive, true
  %empty.equal = and i1 %equal, %open.equal
  %empty = or i1 %reversed, %empty.equal
  ret i1 %empty
}

define internal i1 @topal.elf.runtime.range.int.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.elf.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.elf.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.elf.runtime.int.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.elf.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.elf.runtime.range.rational.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.elf.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.elf.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.elf.runtime.rational.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.elf.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.elf.runtime.range.int.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.elf.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.elf.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.elf.runtime.int.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.elf.runtime.int.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal i1 @topal.elf.runtime.range.rational.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.elf.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.elf.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.elf.runtime.rational.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.elf.runtime.rational.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal ptr @topal.elf.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.elf.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.elf.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.elf.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.elf.runtime.range.upper(ptr %right)
  %left.lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %left)
  %left.upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %right)
  %right.upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %right)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.lower.stricter = icmp sgt i32 %lower.ordering, 0
  %selected.lower = select i1 %left.lower.stricter, ptr %left.lower, ptr %right.lower
  %selected.lower.inclusive = select i1 %left.lower.stricter, i1 %left.lower.inclusive, i1 %right.lower.inclusive
  %equal.lower.inclusive = and i1 %left.lower.inclusive, %right.lower.inclusive
  %lower.inclusive = select i1 %lower.equal, i1 %equal.lower.inclusive, i1 %selected.lower.inclusive
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %left.upper.stricter = icmp slt i32 %upper.ordering, 0
  %selected.upper = select i1 %left.upper.stricter, ptr %left.upper, ptr %right.upper
  %selected.upper.inclusive = select i1 %left.upper.stricter, i1 %left.upper.inclusive, i1 %right.upper.inclusive
  %equal.upper.inclusive = and i1 %left.upper.inclusive, %right.upper.inclusive
  %upper.inclusive = select i1 %upper.equal, i1 %equal.upper.inclusive, i1 %selected.upper.inclusive
  %lower.inclusive.raw = zext i1 %lower.inclusive to i64
  %upper.inclusive.raw = zext i1 %upper.inclusive to i64
  %result = call ptr @topal.elf.runtime.range.make(ptr %selected.lower, ptr %selected.upper, i64 %lower.inclusive.raw, i64 %upper.inclusive.raw)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.range.int.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.elf.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.elf.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.elf.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.elf.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.elf.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.elf.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.elf.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal ptr @topal.elf.runtime.range.rational.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.elf.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.elf.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.elf.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.elf.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.elf.runtime.rational.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.elf.runtime.rational.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.elf.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal void @topal.elf.runtime.range.print.symbol(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower.inclusive = call i1 @topal.elf.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.elf.runtime.range.upper.inclusive(ptr %range)
  br i1 %lower.inclusive, label %lower.closed, label %lower.open
lower.closed:
  br i1 %upper.inclusive, label %closed.closed, label %closed.open
lower.open:
  br i1 %upper.inclusive, label %open.closed, label %open.open
closed.closed:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.range.closed.closed, i64 5)
  ret void
closed.open:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.range.closed.open, i64 4)
  ret void
open.closed:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.range.open.closed, i64 6)
  ret void
open.open:
  call void @topal.elf.platform.write_all(ptr @topal.elf.runtime.range.open.open, i64 5)
  ret void
}

define internal void @topal.elf.runtime.range.int.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.elf.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.elf.runtime.range.upper(ptr %range)
  call void @topal.elf.runtime.int.print(ptr %lower)
  call void @topal.elf.runtime.range.print.symbol(ptr %range)
  call void @topal.elf.runtime.int.print(ptr %upper)
  ret void
}

define internal void @topal.elf.runtime.range.rational.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.elf.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.elf.runtime.range.upper(ptr %range)
  call void @topal.elf.runtime.rational.print(ptr %lower)
  call void @topal.elf.runtime.range.print.symbol(ptr %range)
  call void @topal.elf.runtime.rational.print(ptr %upper)
  ret void
}
; Compiler-selected List Int layout for private topal-native/6 operations.

%topal.ListStorage = type { ptr, ptr }
; Compiler-private fundamental homogeneous containers. Construction may mutate
; unpublished result nodes; published Array, Set, Bag, and Map values are immutable.

%topal.ContainerSequenceHeader = type { i64, ptr }
%topal.ContainerBagHeader = type { i64, i64, ptr }
%topal.ContainerBagNode = type { ptr, i64, ptr }
%topal.ContainerMapNode = type { ptr, ptr, ptr }

define internal i64 @topal.elf.runtime.container.list.count(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop
done:
  ret i64 %count
}

define internal ptr @topal.elf.runtime.container.array.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.elf.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.elf.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal ptr @topal.elf.runtime.container.array.function.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.elf.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.elf.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal i1 @topal.elf.runtime.container.int.list.contains(ptr %list, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.elf.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret i1 true
absent:
  ret i1 false
}

define internal ptr @topal.elf.runtime.container.set.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %duplicate = call i1 @topal.elf.runtime.container.int.list.contains(ptr %head, ptr %value)
  br i1 %duplicate, label %skip, label %add
add:
  %node = call ptr @topal.elf.platform.allocate(i64 16)
  store ptr %value, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
skip:
  br label %advance
advance:
  %head.next = phi ptr [%head, %skip], [%added.head, %added]
  %tail.next = phi ptr [%tail, %skip], [%node, %added]
  %count.next = phi i64 [%count, %skip], [%added.count, %added]
  br label %loop
done:
  %set = call ptr @topal.elf.platform.allocate(i64 16)
  %set.count = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 0
  %set.entries = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  store i64 %count, ptr %set.count, align 8
  store ptr %head, ptr %set.entries, align 8
  ret ptr %set
}

define internal ptr @topal.elf.runtime.container.bag.int.find(ptr %entries, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.elf.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerBagNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.elf.runtime.container.bag.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %total = phi i64 [0, %entry], [%total.next, %advance]
  %distinct = phi i64 [0, %entry], [%distinct.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.elf.runtime.container.bag.int.find(ptr %head, ptr %value)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %increment, label %add
increment:
  %existing.count.pointer = getelementptr %topal.ContainerBagNode, ptr %existing, i32 0, i32 1
  %existing.count = load i64, ptr %existing.count.pointer, align 8
  %incremented = add i64 %existing.count, 1
  store i64 %incremented, ptr %existing.count.pointer, align 8
  br label %advance
add:
  %node = call ptr @topal.elf.platform.allocate(i64 24)
  %node.value = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 0
  %node.count = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 2
  store ptr %value, ptr %node.value, align 8
  store i64 1, ptr %node.count, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerBagNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.distinct = add i64 %distinct, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %increment], [%added.head, %added]
  %tail.next = phi ptr [%tail, %increment], [%node, %added]
  %distinct.next = phi i64 [%distinct, %increment], [%added.distinct, %added]
  %total.next = add i64 %total, 1
  br label %loop
done:
  %bag = call ptr @topal.elf.platform.allocate(i64 24)
  %bag.total = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 0
  %bag.distinct = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 1
  %bag.entries = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  store i64 %total, ptr %bag.total, align 8
  store i64 %distinct, ptr %bag.distinct, align 8
  store ptr %head, ptr %bag.entries, align 8
  ret ptr %bag
}

define internal ptr @topal.elf.runtime.container.map.string-int.find(ptr %entries, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %equal = call i1 @topal.elf.runtime.string.equal(ptr %candidate, ptr %key)
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerMapNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.elf.runtime.container.map.string-int.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load ptr, ptr %source.value.pointer, align 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.elf.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store ptr %value, ptr %existing.value, align 8
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.elf.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store ptr %value, ptr %node.value, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.elf.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.elf.runtime.container.map.string-function.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load i32, ptr %source.value.pointer, align 4
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.elf.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store i32 %value, ptr %existing.value, align 4
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.elf.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store i32 %value, ptr %node.value, align 4
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.elf.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.elf.runtime.container.entry.count(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %value = call ptr @topal.elf.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.elf.runtime.container.empty(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %empty = icmp eq i64 %count, 0
  ret i1 %empty
}

define internal ptr @topal.elf.runtime.container.array.int.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load ptr, ptr %current, align 8
  %some = call ptr @topal.elf.runtime.optional.some(ptr %value)
  ret ptr %some
absent:
  %none = call ptr @topal.elf.runtime.optional.none()
  ret ptr %none
}

define internal ptr @topal.elf.runtime.container.array.function.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load i32, ptr %current, align 4
  %payload = call ptr @topal.elf.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some = call ptr @topal.elf.runtime.optional.some(ptr %payload)
  ret ptr %some
absent:
  %none = call ptr @topal.elf.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.elf.runtime.container.set.int.contains(ptr %set, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %present = call i1 @topal.elf.runtime.container.int.list.contains(ptr %entries, ptr %value)
  ret i1 %present
}

define internal ptr @topal.elf.runtime.container.bag.int.multiplicity(ptr %bag, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.elf.runtime.container.bag.int.find(ptr %entries, ptr %value)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %zero, label %present
zero:
  %zero.value = call ptr @topal.elf.runtime.int.from.u64(i64 0)
  ret ptr %zero.value
present:
  %count.pointer = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %count = load i64, ptr %count.pointer, align 8
  %count.value = call ptr @topal.elf.runtime.int.from.u64(i64 %count)
  ret ptr %count.value
}

define internal ptr @topal.elf.runtime.container.map.string-int.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.elf.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load ptr, ptr %value.pointer, align 8
  %some.value = call ptr @topal.elf.runtime.optional.some(ptr %value)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.elf.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.elf.runtime.container.map.string-function.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.elf.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load i32, ptr %value.pointer, align 4
  %payload = call ptr @topal.elf.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some.value = call ptr @topal.elf.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.elf.runtime.optional.none()
  ret ptr %none.value
}
; Qualified hooks for the owned pure numeric kernel invocation.
; No context, address or allocator function is exposed to Topal source.
declare ptr @topal_kernel_numeric_allocate_v1(i64)
declare void @topal_kernel_numeric_abort_v1() noreturn

define internal ptr @topal.elf.platform.allocate(i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = call ptr @topal_kernel_numeric_allocate_v1(i64 %length)
  ret ptr %pointer
}

define internal void @topal.elf.platform.exit(i64 %status) noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

define internal i64 @topal.elf.platform.write(i64 %fd, ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}
@.topal.int.0 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.1 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.2 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.3 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.4 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.5 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65536] }, align 8
@.topal.int.6 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16777216] }, align 8
@.topal.int.7 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.8 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.9 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.10 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.11 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65536] }, align 8
@.topal.int.12 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.13 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.14 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.15 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.16 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.17 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.18 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.19 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.20 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.21 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.22 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.23 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65536] }, align 8
@.topal.int.24 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16777216] }, align 8
@.topal.int.25 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.26 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.27 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.28 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.29 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.30 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.31 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.32 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.33 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@.topal.int.34 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.35 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@.topal.int.36 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@.topal.int.37 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.38 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.39 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65794] }, align 8
@.topal.int.40 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1179403647] }, align 8
define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte0.0(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !125 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !126, !DIExpression(), !127)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 0), !dbg !128
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !129
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !130
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !131
    #dbg_value(ptr %v3, !132, !DIExpression(), !133)
  br label %optional.decision.merge.2, !dbg !134
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !135
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.0, %optional.decision.none.1], !dbg !136
  ret ptr %v4, !dbg !137
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte1.1(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !140 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !141, !DIExpression(), !142)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 1), !dbg !143
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !144
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !145
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !146
    #dbg_value(ptr %v3, !147, !DIExpression(), !148)
  br label %optional.decision.merge.2, !dbg !149
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !150
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.1, %optional.decision.none.1], !dbg !151
  ret ptr %v4, !dbg !152
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte2.2(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !155 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !156, !DIExpression(), !157)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 2), !dbg !158
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !159
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !160
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !161
    #dbg_value(ptr %v3, !162, !DIExpression(), !163)
  br label %optional.decision.merge.2, !dbg !164
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !165
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.2, %optional.decision.none.1], !dbg !166
  ret ptr %v4, !dbg !167
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte3.3(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !170 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !171, !DIExpression(), !172)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 3), !dbg !173
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !174
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !175
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !176
    #dbg_value(ptr %v3, !177, !DIExpression(), !178)
  br label %optional.decision.merge.2, !dbg !179
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !180
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.3, %optional.decision.none.1], !dbg !181
  ret ptr %v4, !dbg !182
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.4(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !185 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !186, !DIExpression(), !187)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !188, !DIExpression(), !189)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !190, !DIExpression(), !191)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !192, !DIExpression(), !193)
  %v4 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.4), !dbg !194
  %v5 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v4), !dbg !195
  %v6 = call ptr @topal.elf.runtime.int.multiply(ptr %arg2, ptr @.topal.int.5), !dbg !196
  %v7 = call ptr @topal.elf.runtime.int.add(ptr %v5, ptr %v6), !dbg !197
  %v8 = call ptr @topal.elf.runtime.int.multiply(ptr %arg3, ptr @.topal.int.6), !dbg !198
  %v9 = call ptr @topal.elf.runtime.int.add(ptr %v7, ptr %v8), !dbg !199
  ret ptr %v9, !dbg !200
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmagic.5(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !203 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !204, !DIExpression(), !205)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte0.0(ptr %arg0), !dbg !206
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte1.1(ptr %arg0), !dbg !207
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte2.2(ptr %arg0), !dbg !208
  %v4 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte3.3(ptr %arg0), !dbg !209
  %v5 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.4(ptr %v1, ptr %v2, ptr %v3, ptr %v4), !dbg !210
  ret ptr %v5, !dbg !211
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte4.6(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !214 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !215, !DIExpression(), !216)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 4), !dbg !217
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !218
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !219
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !220
    #dbg_value(ptr %v3, !221, !DIExpression(), !222)
  br label %optional.decision.merge.2, !dbg !223
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !224
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.7, %optional.decision.none.1], !dbg !225
  ret ptr %v4, !dbg !226
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte5.7(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !229 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !230, !DIExpression(), !231)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 5), !dbg !232
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !233
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !234
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !235
    #dbg_value(ptr %v3, !236, !DIExpression(), !237)
  br label %optional.decision.merge.2, !dbg !238
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !239
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.8, %optional.decision.none.1], !dbg !240
  ret ptr %v4, !dbg !241
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte6.8(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !244 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !245, !DIExpression(), !246)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 6), !dbg !247
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !248
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !249
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !250
    #dbg_value(ptr %v3, !251, !DIExpression(), !252)
  br label %optional.decision.merge.2, !dbg !253
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !254
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.9, %optional.decision.none.1], !dbg !255
  ret ptr %v4, !dbg !256
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dthree.9(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !259 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !260, !DIExpression(), !261)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !262, !DIExpression(), !263)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !264, !DIExpression(), !265)
  %v3 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.10), !dbg !266
  %v4 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v3), !dbg !267
  %v5 = call ptr @topal.elf.runtime.int.multiply(ptr %arg2, ptr @.topal.int.11), !dbg !268
  %v6 = call ptr @topal.elf.runtime.int.add(ptr %v4, ptr %v5), !dbg !269
  ret ptr %v6, !dbg !270
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dident.10(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !273 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !274, !DIExpression(), !275)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte4.6(ptr %arg0), !dbg !276
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte5.7(ptr %arg0), !dbg !277
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte6.8(ptr %arg0), !dbg !278
  %v4 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dthree.9(ptr %v1, ptr %v2, ptr %v3), !dbg !279
  ret ptr %v4, !dbg !280
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte16.11(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !283 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !284, !DIExpression(), !285)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 16), !dbg !286
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !287
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !288
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !289
    #dbg_value(ptr %v3, !290, !DIExpression(), !291)
  br label %optional.decision.merge.2, !dbg !292
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !293
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.12, %optional.decision.none.1], !dbg !294
  ret ptr %v4, !dbg !295
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte17.12(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !298 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !299, !DIExpression(), !300)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 17), !dbg !301
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !302
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !303
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !304
    #dbg_value(ptr %v3, !305, !DIExpression(), !306)
  br label %optional.decision.merge.2, !dbg !307
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !308
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.13, %optional.decision.none.1], !dbg !309
  ret ptr %v4, !dbg !310
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.13(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !313 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !314, !DIExpression(), !315)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !316, !DIExpression(), !317)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.14), !dbg !318
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !319
  ret ptr %v3, !dbg !320
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dtype.14(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !323 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !324, !DIExpression(), !325)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte16.11(ptr %arg0), !dbg !326
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte17.12(ptr %arg0), !dbg !327
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.13(ptr %v1, ptr %v2), !dbg !328
  ret ptr %v3, !dbg !329
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte18.15(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !332 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !333, !DIExpression(), !334)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 18), !dbg !335
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !336
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !337
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !338
    #dbg_value(ptr %v3, !339, !DIExpression(), !340)
  br label %optional.decision.merge.2, !dbg !341
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !342
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.15, %optional.decision.none.1], !dbg !343
  ret ptr %v4, !dbg !344
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte19.16(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !347 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !348, !DIExpression(), !349)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 19), !dbg !350
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !351
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !352
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !353
    #dbg_value(ptr %v3, !354, !DIExpression(), !355)
  br label %optional.decision.merge.2, !dbg !356
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !357
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.16, %optional.decision.none.1], !dbg !358
  ret ptr %v4, !dbg !359
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.17(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !362 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !363, !DIExpression(), !364)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !365, !DIExpression(), !366)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.17), !dbg !367
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !368
  ret ptr %v3, !dbg !369
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmachine.18(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !372 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !373, !DIExpression(), !374)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte18.15(ptr %arg0), !dbg !375
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte19.16(ptr %arg0), !dbg !376
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.17(ptr %v1, ptr %v2), !dbg !377
  ret ptr %v3, !dbg !378
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte20.19(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !381 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !382, !DIExpression(), !383)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 20), !dbg !384
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !385
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !386
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !387
    #dbg_value(ptr %v3, !388, !DIExpression(), !389)
  br label %optional.decision.merge.2, !dbg !390
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !391
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.18, %optional.decision.none.1], !dbg !392
  ret ptr %v4, !dbg !393
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte21.20(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !396 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !397, !DIExpression(), !398)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 21), !dbg !399
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !400
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !401
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !402
    #dbg_value(ptr %v3, !403, !DIExpression(), !404)
  br label %optional.decision.merge.2, !dbg !405
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !406
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.19, %optional.decision.none.1], !dbg !407
  ret ptr %v4, !dbg !408
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte22.21(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !411 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !412, !DIExpression(), !413)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 22), !dbg !414
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !415
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !416
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !417
    #dbg_value(ptr %v3, !418, !DIExpression(), !419)
  br label %optional.decision.merge.2, !dbg !420
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !421
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.20, %optional.decision.none.1], !dbg !422
  ret ptr %v4, !dbg !423
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte23.22(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !426 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !427, !DIExpression(), !428)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 23), !dbg !429
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !430
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !431
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !432
    #dbg_value(ptr %v3, !433, !DIExpression(), !434)
  br label %optional.decision.merge.2, !dbg !435
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !436
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.21, %optional.decision.none.1], !dbg !437
  ret ptr %v4, !dbg !438
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.23(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !441 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !442, !DIExpression(), !443)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !444, !DIExpression(), !445)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !446, !DIExpression(), !447)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !448, !DIExpression(), !449)
  %v4 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.22), !dbg !450
  %v5 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v4), !dbg !451
  %v6 = call ptr @topal.elf.runtime.int.multiply(ptr %arg2, ptr @.topal.int.23), !dbg !452
  %v7 = call ptr @topal.elf.runtime.int.add(ptr %v5, ptr %v6), !dbg !453
  %v8 = call ptr @topal.elf.runtime.int.multiply(ptr %arg3, ptr @.topal.int.24), !dbg !454
  %v9 = call ptr @topal.elf.runtime.int.add(ptr %v7, ptr %v8), !dbg !455
  ret ptr %v9, !dbg !456
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dversion.24(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !459 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !460, !DIExpression(), !461)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte20.19(ptr %arg0), !dbg !462
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte21.20(ptr %arg0), !dbg !463
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte22.21(ptr %arg0), !dbg !464
  %v4 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte23.22(ptr %arg0), !dbg !465
  %v5 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dfour.23(ptr %v1, ptr %v2, ptr %v3, ptr %v4), !dbg !466
  ret ptr %v5, !dbg !467
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte52.25(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !470 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !471, !DIExpression(), !472)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 52), !dbg !473
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !474
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !475
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !476
    #dbg_value(ptr %v3, !477, !DIExpression(), !478)
  br label %optional.decision.merge.2, !dbg !479
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !480
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.25, %optional.decision.none.1], !dbg !481
  ret ptr %v4, !dbg !482
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte53.26(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !485 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !486, !DIExpression(), !487)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 53), !dbg !488
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !489
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !490
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !491
    #dbg_value(ptr %v3, !492, !DIExpression(), !493)
  br label %optional.decision.merge.2, !dbg !494
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !495
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.26, %optional.decision.none.1], !dbg !496
  ret ptr %v4, !dbg !497
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.27(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !500 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !501, !DIExpression(), !502)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !503, !DIExpression(), !504)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.27), !dbg !505
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !506
  ret ptr %v3, !dbg !507
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dheader_2dsize.28(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !510 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !511, !DIExpression(), !512)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte52.25(ptr %arg0), !dbg !513
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte53.26(ptr %arg0), !dbg !514
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.27(ptr %v1, ptr %v2), !dbg !515
  ret ptr %v3, !dbg !516
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte54.29(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !519 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !520, !DIExpression(), !521)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 54), !dbg !522
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !523
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !524
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !525
    #dbg_value(ptr %v3, !526, !DIExpression(), !527)
  br label %optional.decision.merge.2, !dbg !528
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !529
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.28, %optional.decision.none.1], !dbg !530
  ret ptr %v4, !dbg !531
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte55.30(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !534 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !535, !DIExpression(), !536)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 55), !dbg !537
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !538
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !539
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !540
    #dbg_value(ptr %v3, !541, !DIExpression(), !542)
  br label %optional.decision.merge.2, !dbg !543
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !544
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.29, %optional.decision.none.1], !dbg !545
  ret ptr %v4, !dbg !546
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.31(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !549 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !550, !DIExpression(), !551)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !552, !DIExpression(), !553)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.30), !dbg !554
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !555
  ret ptr %v3, !dbg !556
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dentry_2dsize.32(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !559 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !560, !DIExpression(), !561)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte54.29(ptr %arg0), !dbg !562
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte55.30(ptr %arg0), !dbg !563
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.31(ptr %v1, ptr %v2), !dbg !564
  ret ptr %v3, !dbg !565
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte56.33(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !568 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !569, !DIExpression(), !570)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 56), !dbg !571
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !572
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !573
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !574
    #dbg_value(ptr %v3, !575, !DIExpression(), !576)
  br label %optional.decision.merge.2, !dbg !577
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !578
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.31, %optional.decision.none.1], !dbg !579
  ret ptr %v4, !dbg !580
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte57.34(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !583 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !584, !DIExpression(), !585)
  %v1 = call ptr @topal.elf.runtime.container.array.int.at(ptr %arg0, i64 57), !dbg !586
  %v2 = call i1 @topal.elf.runtime.optional.is.some(ptr %v1), !dbg !587
  br i1 %v2, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !588
optional.decision.some.0:
  %v3 = call ptr @topal.elf.runtime.optional.payload(ptr %v1), !dbg !589
    #dbg_value(ptr %v3, !590, !DIExpression(), !591)
  br label %optional.decision.merge.2, !dbg !592
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !593
optional.decision.merge.2:
  %v4 = phi ptr [%v3, %optional.decision.some.0], [@.topal.int.32, %optional.decision.none.1], !dbg !594
  ret ptr %v4, !dbg !595
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.35(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !598 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !599, !DIExpression(), !600)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !601, !DIExpression(), !602)
  %v2 = call ptr @topal.elf.runtime.int.multiply(ptr %arg1, ptr @.topal.int.33), !dbg !603
  %v3 = call ptr @topal.elf.runtime.int.add(ptr %arg0, ptr %v2), !dbg !604
  ret ptr %v3, !dbg !605
}

define internal fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dcount.36(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !608 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !609, !DIExpression(), !610)
  %v1 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte56.33(ptr %arg0), !dbg !611
  %v2 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2ebyte57.34(ptr %arg0), !dbg !612
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eword_2dtwo.35(ptr %v1, ptr %v2), !dbg !613
  ret ptr %v3, !dbg !614
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dcount.37(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !617 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !618, !DIExpression(), !619)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !620, !DIExpression(), !621)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !622, !DIExpression(), !623)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dcount.36(ptr %arg0), !dbg !624
    #dbg_value(ptr %v3, !625, !DIExpression(), !626)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.34), !dbg !627
  %v5 = icmp sge i32 %v4, 0, !dbg !628
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !629
decision.true.0:
  %v6 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr %arg2), !dbg !630
  %v7 = icmp sle i32 %v6, 0, !dbg !631
  br label %decision.merge.2, !dbg !632
decision.false.1:
  br label %decision.merge.2, !dbg !633
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !634
  ret i1 %v8, !dbg !635
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dentry_2dsize.38(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !638 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !639, !DIExpression(), !640)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !641, !DIExpression(), !642)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !643, !DIExpression(), !644)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dentry_2dsize.32(ptr %arg0), !dbg !645
    #dbg_value(ptr %v3, !646, !DIExpression(), !647)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.35), !dbg !648
  %v5 = icmp eq i32 %v4, 0, !dbg !649
  %v6 = icmp eq i1 %v5, true, !dbg !650
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !651
decision.true.0:
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dcount.37(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !652
  br label %decision.merge.2, !dbg !653
decision.false.1:
  br label %decision.merge.2, !dbg !654
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !655
  ret i1 %v8, !dbg !656
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dheader_2dsize.39(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !659 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !660, !DIExpression(), !661)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !662, !DIExpression(), !663)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !664, !DIExpression(), !665)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dheader_2dsize.28(ptr %arg0), !dbg !666
    #dbg_value(ptr %v3, !667, !DIExpression(), !668)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.36), !dbg !669
  %v5 = icmp eq i32 %v4, 0, !dbg !670
  %v6 = icmp eq i1 %v5, true, !dbg !671
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !672
decision.true.0:
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dentry_2dsize.38(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !673
  br label %decision.merge.2, !dbg !674
decision.false.1:
  br label %decision.merge.2, !dbg !675
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !676
  ret i1 %v8, !dbg !677
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dversion.40(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !680 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !681, !DIExpression(), !682)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !683, !DIExpression(), !684)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !685, !DIExpression(), !686)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dversion.24(ptr %arg0), !dbg !687
    #dbg_value(ptr %v3, !688, !DIExpression(), !689)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.37), !dbg !690
  %v5 = icmp eq i32 %v4, 0, !dbg !691
  %v6 = icmp eq i1 %v5, true, !dbg !692
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !693
decision.true.0:
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dheader_2dsize.39(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !694
  br label %decision.merge.2, !dbg !695
decision.false.1:
  br label %decision.merge.2, !dbg !696
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !697
  ret i1 %v8, !dbg !698
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dmachine.41(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !701 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !702, !DIExpression(), !703)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !704, !DIExpression(), !705)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !706, !DIExpression(), !707)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmachine.18(ptr %arg0), !dbg !708
    #dbg_value(ptr %v3, !709, !DIExpression(), !710)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr %arg1), !dbg !711
  %v5 = icmp eq i32 %v4, 0, !dbg !712
  %v6 = icmp eq i1 %v5, true, !dbg !713
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !714
decision.true.0:
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dversion.40(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !715
  br label %decision.merge.2, !dbg !716
decision.false.1:
  br label %decision.merge.2, !dbg !717
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !718
  ret i1 %v8, !dbg !719
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dtype.42(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !722 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !723, !DIExpression(), !724)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !725, !DIExpression(), !726)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !727, !DIExpression(), !728)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dtype.14(ptr %arg0), !dbg !729
    #dbg_value(ptr %v3, !730, !DIExpression(), !731)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.38), !dbg !732
  %v5 = icmp eq i32 %v4, 0, !dbg !733
  %v6 = icmp eq i1 %v5, true, !dbg !734
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !735
decision.true.0:
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dmachine.41(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !736
  br label %decision.merge.2, !dbg !737
decision.false.1:
  br label %decision.merge.2, !dbg !738
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !739
  ret i1 %v8, !dbg !740
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dident.43(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !743 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !744, !DIExpression(), !745)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !746, !DIExpression(), !747)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !748, !DIExpression(), !749)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dident.10(ptr %arg0), !dbg !750
    #dbg_value(ptr %v3, !751, !DIExpression(), !752)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.39), !dbg !753
  %v5 = icmp eq i32 %v4, 0, !dbg !754
  %v6 = icmp eq i1 %v5, true, !dbg !755
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !756
decision.true.0:
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dtype.42(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !757
  br label %decision.merge.2, !dbg !758
decision.false.1:
  br label %decision.merge.2, !dbg !759
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !760
  ret i1 %v8, !dbg !761
}

define internal fastcc i1 @topal.header.topal.fn.support_2eelf_2eadmitted_3f.44(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !764 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !765, !DIExpression(), !766)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !767, !DIExpression(), !768)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !769, !DIExpression(), !770)
  %v3 = call fastcc ptr @topal.header.topal.fn.support_2eelf_2eread_2dmagic.5(ptr %arg0), !dbg !771
    #dbg_value(ptr %v3, !772, !DIExpression(), !773)
  %v4 = call i32 @topal.elf.runtime.int.compare(ptr %v3, ptr @.topal.int.40), !dbg !774
  %v5 = icmp eq i32 %v4, 0, !dbg !775
  %v6 = icmp eq i1 %v5, true, !dbg !776
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !777
decision.true.0:
  %v7 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2echeck_2dident.43(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !778
  br label %decision.merge.2, !dbg !779
decision.false.1:
  br label %decision.merge.2, !dbg !780
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [false, %decision.false.1], !dbg !781
  ret i1 %v8, !dbg !782
}

define internal fastcc i1 @topal.header.topal.fn.header_2dadmitted_3f.45(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !785 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !786, !DIExpression(), !787)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !788, !DIExpression(), !789)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !790, !DIExpression(), !791)
  %v3 = call fastcc i1 @topal.header.topal.fn.support_2eelf_2eadmitted_3f.44(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !792
  ret i1 %v3, !dbg !793
}

define i64 @topal_kernel_static_elf64_header_policy_v1(ptr %bytes, i64 %length, i64 %machine, i64 %maximum) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %address = ptrtoint ptr %bytes to i64
  %end = add i64 %address, 64
  %nonwrapping = icmp ugt i64 %end, %address
  %nonnull = icmp ne ptr %bytes, null
  %length.valid = icmp eq i64 %length, 64
  %machine.low = icmp uge i64 %machine, 1
  %machine.high = icmp ule i64 %machine, 65535
  %maximum.low = icmp uge i64 %maximum, 1
  %maximum.high = icmp ule i64 %maximum, 65535
  %extent.valid = and i1 %nonnull, %length.valid
  %extent.bounded = and i1 %extent.valid, %nonwrapping
  %machine.valid = and i1 %machine.low, %machine.high
  %maximum.valid = and i1 %maximum.low, %maximum.high
  %facts.valid = and i1 %machine.valid, %maximum.valid
  %valid = and i1 %extent.bounded, %facts.valid
  br i1 %valid, label %invoke, label %invalid
invoke:
  %machine.value = call ptr @topal.elf.runtime.int.from.u64(i64 %machine)
  %maximum.value = call ptr @topal.elf.runtime.int.from.u64(i64 %maximum)
  br label %copy
copy:
  %remaining = phi i64 [64, %invoke], [%index, %copy]
  %tail = phi ptr [null, %invoke], [%node, %copy]
  %index = sub i64 %remaining, 1
  %input = getelementptr i8, ptr %bytes, i64 %index
  %byte = load i8, ptr %input, align 1
  %unsigned = zext i8 %byte to i64
  %integer = call ptr @topal.elf.runtime.int.from.u64(i64 %unsigned)
  %node = call ptr @topal.elf.platform.allocate(i64 16)
  store ptr %integer, ptr %node, align 8
  %next = getelementptr i8, ptr %node, i64 8
  store ptr %tail, ptr %next, align 8
  %done = icmp eq i64 %index, 0
  br i1 %done, label %policy, label %copy
policy:
  %array = call ptr @topal.elf.runtime.container.array.int.collect(ptr %node)
  %accepted = call fastcc i1 @topal.header.topal.fn.header_2dadmitted_3f.45(ptr %array, ptr %machine.value, ptr %maximum.value)
  %result = zext i1 %accepted to i64
  ret i64 %result
invalid:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!794, !795}
!llvm.ident = !{!796}
!0 = !DIFile(filename: "static-elf64-header.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!1 = !{}
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !0, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !1, retainedTypes: !1)
!3 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!4 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!5 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!6 = !{!4, !5}
!7 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !0, size: 128, align: 64, elements: !6)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64, align: 64)
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !0, baseType: !8)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !0, baseType: !8)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "major", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "minor", file: !0, baseType: !10, size: 64, align: 64, offset: 64)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "patch", file: !0, baseType: !10, size: 64, align: 64, offset: 128)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "build", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!15 = !{!11, !12, !13, !14}
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalVersionHeader", file: !0, size: 256, align: 64, elements: !15)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "Version", file: !0, baseType: !17)
!19 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !20, size: 64, align: 64, offset: 0)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "byte_count", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!23 = !{!21, !22}
!24 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSerializationStreamHeader", file: !0, size: 128, align: 64, elements: !23)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64, align: 64)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "SerializationStream", file: !0, baseType: !25)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "numerator", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "denominator", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!29 = !{!27, !28}
!30 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRationalHeader", file: !0, size: 128, align: 64, elements: !29)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !30, size: 64, align: 64)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "Rational", file: !0, baseType: !31)
!33 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!34 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !33, size: 64, align: 64)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !34, size: 64, align: 64, offset: 0)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!37 = !DIDerivedType(tag: DW_TAG_member, name: "display", file: !0, baseType: !34, size: 64, align: 64, offset: 128)
!38 = !DIDerivedType(tag: DW_TAG_member, name: "display_length", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!39 = !{!35, !36, !37, !38}
!40 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalStringHeader", file: !0, size: 256, align: 64, elements: !39)
!41 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !40, size: 64, align: 64)
!42 = !DIDerivedType(tag: DW_TAG_typedef, name: "String", file: !0, baseType: !41)
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "Character", file: !0, baseType: !41)
!44 = !DIDerivedType(tag: DW_TAG_typedef, name: "ErrorDomain", file: !0, baseType: !41)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "line", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "column", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!47 = !{!45, !46}
!48 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSourceLocationHeader", file: !0, size: 128, align: 64, elements: !47)
!49 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !48, size: 64, align: 64)
!50 = !DIDerivedType(tag: DW_TAG_typedef, name: "SourceLocation", file: !0, baseType: !49)
!51 = !DIEnumerator(name: "out-of-range", value: 0)
!52 = !DIEnumerator(name: "not-representable", value: 1)
!53 = !DIEnumerator(name: "division-by-zero", value: 2)
!54 = !DIEnumerator(name: "indeterminate", value: 3)
!55 = !{!51, !52, !53, !54}
!56 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "lang arithmetic ArithmeticErrorCode", file: !0, size: 32, align: 32, elements: !55)
!57 = !DIDerivedType(tag: DW_TAG_member, name: "domain", file: !0, baseType: !44, size: 64, align: 64, offset: 0)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "code", file: !0, baseType: !56, size: 32, align: 32, offset: 64)
!59 = !{!57, !58}
!60 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalErrorHeader", file: !0, size: 448, align: 64, elements: !59)
!61 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !60, size: 64, align: 64)
!62 = !DIDerivedType(tag: DW_TAG_typedef, name: "Error", file: !0, baseType: !61)
!63 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!64 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!65 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!67 = !{!63, !64, !65, !66}
!68 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeIntHeader", file: !0, size: 256, align: 64, elements: !67)
!69 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !68, size: 64, align: 64)
!70 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Int", file: !0, baseType: !69)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !32, size: 64, align: 64, offset: 0)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !32, size: 64, align: 64, offset: 64)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!75 = !{!71, !72, !73, !74}
!76 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeRationalHeader", file: !0, size: 256, align: 64, elements: !75)
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !76, size: 64, align: 64)
!78 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Rational", file: !0, baseType: !77)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "is_error", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!80 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !80, size: 64, align: 64, offset: 64)
!82 = !{!79, !81}
!83 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalResultHeader", file: !0, size: 128, align: 64, elements: !82)
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !83, size: 64, align: 64)
!85 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Int, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!86 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Nat, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!87 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Rational, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!88 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (String, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!89 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result ((Int, Int), lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "tag", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!91 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !91, size: 64, align: 64, offset: 64)
!93 = !{!90, !92}
!94 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalOptionalHeader", file: !0, size: 128, align: 64, elements: !93)
!95 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64, align: 64)
!96 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Int", file: !0, baseType: !95)
!97 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Rational", file: !0, baseType: !95)
!98 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Character", file: !0, baseType: !95)
!99 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional String", file: !0, baseType: !95)
!100 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Error", file: !0, baseType: !95)
!101 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional SourceLocation", file: !0, baseType: !95)
!102 = !DIEnumerator(name: "Less", value: -1)
!103 = !DIEnumerator(name: "Equal", value: 0)
!104 = !DIEnumerator(name: "Greater", value: 1)
!105 = !{!102, !103, !104}
!106 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Comparison", file: !0, size: 32, align: 32, elements: !105)
!107 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!108 = !DIBasicType(name: "Unit", size: 8, encoding: DW_ATE_unsigned)
!109 = !DIEnumerator(name: "Completed", value: 0)
!110 = !{!109}
!111 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Completed", file: !0, size: 8, align: 8, elements: !110)
!112 = !DIEnumerator(name: "empty", value: 0)
!113 = !{!112}
!114 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Effect", file: !0, size: 8, align: 8, elements: !113)
!115 = !DIFile(filename: "elf.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!116 = !DIDerivedType(tag: DW_TAG_member, name: "entry_count", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!117 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!118 = !DIDerivedType(tag: DW_TAG_member, name: "entries", file: !0, baseType: !117, size: 64, align: 64, offset: 64)
!119 = !{!116, !118}
!120 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalContainer.Array 64 Int", file: !0, size: 128, align: 64, elements: !119)
!121 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !120, size: 64, align: 64)
!122 = !DIDerivedType(tag: DW_TAG_typedef, name: "Array 64 Int", file: !0, baseType: !121)
!123 = !{!9, !122}
!124 = !DISubroutineType(types: !123)
!125 = distinct !DISubprogram(name: "support.elf.byte0", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte0.0", scope: !115, file: !115, line: 4, type: !124, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !2)
!126 = !DILocalVariable(name: "bytes", arg: 1, scope: !125, file: !115, line: 4, type: !122)
!127 = !DILocation(line: 4, column: 14, scope: !125)
!128 = !DILocation(line: 5, column: 3, scope: !125)
!129 = !DILocation(line: 5, column: 3, scope: !125)
!130 = !DILocation(line: 5, column: 3, scope: !125)
!131 = !DILocation(line: 6, column: 10, scope: !125)
!132 = !DILocalVariable(name: "value", scope: !125, file: !115, line: 6, type: !9)
!133 = !DILocation(line: 6, column: 10, scope: !125)
!134 = !DILocation(line: 6, column: 21, scope: !125)
!135 = !DILocation(line: 7, column: 15, scope: !125)
!136 = !DILocation(line: 5, column: 3, scope: !125)
!137 = !DILocation(line: 5, column: 3, scope: !125)
!138 = !{!9, !122}
!139 = !DISubroutineType(types: !138)
!140 = distinct !DISubprogram(name: "support.elf.byte1", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte1.1", scope: !115, file: !115, line: 9, type: !139, scopeLine: 9, spFlags: DISPFlagDefinition, unit: !2)
!141 = !DILocalVariable(name: "bytes", arg: 1, scope: !140, file: !115, line: 9, type: !122)
!142 = !DILocation(line: 9, column: 14, scope: !140)
!143 = !DILocation(line: 10, column: 3, scope: !140)
!144 = !DILocation(line: 10, column: 3, scope: !140)
!145 = !DILocation(line: 10, column: 3, scope: !140)
!146 = !DILocation(line: 11, column: 10, scope: !140)
!147 = !DILocalVariable(name: "value", scope: !140, file: !115, line: 11, type: !9)
!148 = !DILocation(line: 11, column: 10, scope: !140)
!149 = !DILocation(line: 11, column: 21, scope: !140)
!150 = !DILocation(line: 12, column: 15, scope: !140)
!151 = !DILocation(line: 10, column: 3, scope: !140)
!152 = !DILocation(line: 10, column: 3, scope: !140)
!153 = !{!9, !122}
!154 = !DISubroutineType(types: !153)
!155 = distinct !DISubprogram(name: "support.elf.byte2", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte2.2", scope: !115, file: !115, line: 14, type: !154, scopeLine: 14, spFlags: DISPFlagDefinition, unit: !2)
!156 = !DILocalVariable(name: "bytes", arg: 1, scope: !155, file: !115, line: 14, type: !122)
!157 = !DILocation(line: 14, column: 14, scope: !155)
!158 = !DILocation(line: 15, column: 3, scope: !155)
!159 = !DILocation(line: 15, column: 3, scope: !155)
!160 = !DILocation(line: 15, column: 3, scope: !155)
!161 = !DILocation(line: 16, column: 10, scope: !155)
!162 = !DILocalVariable(name: "value", scope: !155, file: !115, line: 16, type: !9)
!163 = !DILocation(line: 16, column: 10, scope: !155)
!164 = !DILocation(line: 16, column: 21, scope: !155)
!165 = !DILocation(line: 17, column: 15, scope: !155)
!166 = !DILocation(line: 15, column: 3, scope: !155)
!167 = !DILocation(line: 15, column: 3, scope: !155)
!168 = !{!9, !122}
!169 = !DISubroutineType(types: !168)
!170 = distinct !DISubprogram(name: "support.elf.byte3", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte3.3", scope: !115, file: !115, line: 19, type: !169, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !2)
!171 = !DILocalVariable(name: "bytes", arg: 1, scope: !170, file: !115, line: 19, type: !122)
!172 = !DILocation(line: 19, column: 14, scope: !170)
!173 = !DILocation(line: 20, column: 3, scope: !170)
!174 = !DILocation(line: 20, column: 3, scope: !170)
!175 = !DILocation(line: 20, column: 3, scope: !170)
!176 = !DILocation(line: 21, column: 10, scope: !170)
!177 = !DILocalVariable(name: "value", scope: !170, file: !115, line: 21, type: !9)
!178 = !DILocation(line: 21, column: 10, scope: !170)
!179 = !DILocation(line: 21, column: 21, scope: !170)
!180 = !DILocation(line: 22, column: 15, scope: !170)
!181 = !DILocation(line: 20, column: 3, scope: !170)
!182 = !DILocation(line: 20, column: 3, scope: !170)
!183 = !{!9, !9, !9, !9, !9}
!184 = !DISubroutineType(types: !183)
!185 = distinct !DISubprogram(name: "support.elf.word-four", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dfour.4", scope: !115, file: !115, line: 115, type: !184, scopeLine: 115, spFlags: DISPFlagDefinition, unit: !2)
!186 = !DILocalVariable(name: "first", arg: 1, scope: !185, file: !115, line: 115, type: !9)
!187 = !DILocation(line: 115, column: 19, scope: !185)
!188 = !DILocalVariable(name: "second", arg: 2, scope: !185, file: !115, line: 115, type: !9)
!189 = !DILocation(line: 115, column: 32, scope: !185)
!190 = !DILocalVariable(name: "third", arg: 3, scope: !185, file: !115, line: 115, type: !9)
!191 = !DILocation(line: 115, column: 46, scope: !185)
!192 = !DILocalVariable(name: "fourth", arg: 4, scope: !185, file: !115, line: 115, type: !9)
!193 = !DILocation(line: 115, column: 59, scope: !185)
!194 = !DILocation(line: 116, column: 12, scope: !185)
!195 = !DILocation(line: 116, column: 3, scope: !185)
!196 = !DILocation(line: 116, column: 29, scope: !185)
!197 = !DILocation(line: 116, column: 3, scope: !185)
!198 = !DILocation(line: 116, column: 47, scope: !185)
!199 = !DILocation(line: 116, column: 3, scope: !185)
!200 = !DILocation(line: 116, column: 3, scope: !185)
!201 = !{!9, !122}
!202 = !DISubroutineType(types: !201)
!203 = distinct !DISubprogram(name: "support.elf.read-magic", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dmagic.5", scope: !115, file: !115, line: 118, type: !202, scopeLine: 118, spFlags: DISPFlagDefinition, unit: !2)
!204 = !DILocalVariable(name: "bytes", arg: 1, scope: !203, file: !115, line: 118, type: !122)
!205 = !DILocation(line: 118, column: 19, scope: !203)
!206 = !DILocation(line: 119, column: 14, scope: !203)
!207 = !DILocation(line: 119, column: 27, scope: !203)
!208 = !DILocation(line: 119, column: 40, scope: !203)
!209 = !DILocation(line: 119, column: 53, scope: !203)
!210 = !DILocation(line: 119, column: 3, scope: !203)
!211 = !DILocation(line: 119, column: 3, scope: !203)
!212 = !{!9, !122}
!213 = !DISubroutineType(types: !212)
!214 = distinct !DISubprogram(name: "support.elf.byte4", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte4.6", scope: !115, file: !115, line: 24, type: !213, scopeLine: 24, spFlags: DISPFlagDefinition, unit: !2)
!215 = !DILocalVariable(name: "bytes", arg: 1, scope: !214, file: !115, line: 24, type: !122)
!216 = !DILocation(line: 24, column: 14, scope: !214)
!217 = !DILocation(line: 25, column: 3, scope: !214)
!218 = !DILocation(line: 25, column: 3, scope: !214)
!219 = !DILocation(line: 25, column: 3, scope: !214)
!220 = !DILocation(line: 26, column: 10, scope: !214)
!221 = !DILocalVariable(name: "value", scope: !214, file: !115, line: 26, type: !9)
!222 = !DILocation(line: 26, column: 10, scope: !214)
!223 = !DILocation(line: 26, column: 21, scope: !214)
!224 = !DILocation(line: 27, column: 15, scope: !214)
!225 = !DILocation(line: 25, column: 3, scope: !214)
!226 = !DILocation(line: 25, column: 3, scope: !214)
!227 = !{!9, !122}
!228 = !DISubroutineType(types: !227)
!229 = distinct !DISubprogram(name: "support.elf.byte5", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte5.7", scope: !115, file: !115, line: 29, type: !228, scopeLine: 29, spFlags: DISPFlagDefinition, unit: !2)
!230 = !DILocalVariable(name: "bytes", arg: 1, scope: !229, file: !115, line: 29, type: !122)
!231 = !DILocation(line: 29, column: 14, scope: !229)
!232 = !DILocation(line: 30, column: 3, scope: !229)
!233 = !DILocation(line: 30, column: 3, scope: !229)
!234 = !DILocation(line: 30, column: 3, scope: !229)
!235 = !DILocation(line: 31, column: 10, scope: !229)
!236 = !DILocalVariable(name: "value", scope: !229, file: !115, line: 31, type: !9)
!237 = !DILocation(line: 31, column: 10, scope: !229)
!238 = !DILocation(line: 31, column: 21, scope: !229)
!239 = !DILocation(line: 32, column: 15, scope: !229)
!240 = !DILocation(line: 30, column: 3, scope: !229)
!241 = !DILocation(line: 30, column: 3, scope: !229)
!242 = !{!9, !122}
!243 = !DISubroutineType(types: !242)
!244 = distinct !DISubprogram(name: "support.elf.byte6", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte6.8", scope: !115, file: !115, line: 34, type: !243, scopeLine: 34, spFlags: DISPFlagDefinition, unit: !2)
!245 = !DILocalVariable(name: "bytes", arg: 1, scope: !244, file: !115, line: 34, type: !122)
!246 = !DILocation(line: 34, column: 14, scope: !244)
!247 = !DILocation(line: 35, column: 3, scope: !244)
!248 = !DILocation(line: 35, column: 3, scope: !244)
!249 = !DILocation(line: 35, column: 3, scope: !244)
!250 = !DILocation(line: 36, column: 10, scope: !244)
!251 = !DILocalVariable(name: "value", scope: !244, file: !115, line: 36, type: !9)
!252 = !DILocation(line: 36, column: 10, scope: !244)
!253 = !DILocation(line: 36, column: 21, scope: !244)
!254 = !DILocation(line: 37, column: 15, scope: !244)
!255 = !DILocation(line: 35, column: 3, scope: !244)
!256 = !DILocation(line: 35, column: 3, scope: !244)
!257 = !{!9, !9, !9, !9}
!258 = !DISubroutineType(types: !257)
!259 = distinct !DISubprogram(name: "support.elf.word-three", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dthree.9", scope: !115, file: !115, line: 112, type: !258, scopeLine: 112, spFlags: DISPFlagDefinition, unit: !2)
!260 = !DILocalVariable(name: "low", arg: 1, scope: !259, file: !115, line: 112, type: !9)
!261 = !DILocation(line: 112, column: 20, scope: !259)
!262 = !DILocalVariable(name: "middle", arg: 2, scope: !259, file: !115, line: 112, type: !9)
!263 = !DILocation(line: 112, column: 31, scope: !259)
!264 = !DILocalVariable(name: "high", arg: 3, scope: !259, file: !115, line: 112, type: !9)
!265 = !DILocation(line: 112, column: 45, scope: !259)
!266 = !DILocation(line: 113, column: 10, scope: !259)
!267 = !DILocation(line: 113, column: 3, scope: !259)
!268 = !DILocation(line: 113, column: 27, scope: !259)
!269 = !DILocation(line: 113, column: 3, scope: !259)
!270 = !DILocation(line: 113, column: 3, scope: !259)
!271 = !{!9, !122}
!272 = !DISubroutineType(types: !271)
!273 = distinct !DISubprogram(name: "support.elf.read-ident", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dident.10", scope: !115, file: !115, line: 121, type: !272, scopeLine: 121, spFlags: DISPFlagDefinition, unit: !2)
!274 = !DILocalVariable(name: "bytes", arg: 1, scope: !273, file: !115, line: 121, type: !122)
!275 = !DILocation(line: 121, column: 19, scope: !273)
!276 = !DILocation(line: 122, column: 15, scope: !273)
!277 = !DILocation(line: 122, column: 28, scope: !273)
!278 = !DILocation(line: 122, column: 41, scope: !273)
!279 = !DILocation(line: 122, column: 3, scope: !273)
!280 = !DILocation(line: 122, column: 3, scope: !273)
!281 = !{!9, !122}
!282 = !DISubroutineType(types: !281)
!283 = distinct !DISubprogram(name: "support.elf.byte16", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte16.11", scope: !115, file: !115, line: 39, type: !282, scopeLine: 39, spFlags: DISPFlagDefinition, unit: !2)
!284 = !DILocalVariable(name: "bytes", arg: 1, scope: !283, file: !115, line: 39, type: !122)
!285 = !DILocation(line: 39, column: 15, scope: !283)
!286 = !DILocation(line: 40, column: 3, scope: !283)
!287 = !DILocation(line: 40, column: 3, scope: !283)
!288 = !DILocation(line: 40, column: 3, scope: !283)
!289 = !DILocation(line: 41, column: 10, scope: !283)
!290 = !DILocalVariable(name: "value", scope: !283, file: !115, line: 41, type: !9)
!291 = !DILocation(line: 41, column: 10, scope: !283)
!292 = !DILocation(line: 41, column: 21, scope: !283)
!293 = !DILocation(line: 42, column: 15, scope: !283)
!294 = !DILocation(line: 40, column: 3, scope: !283)
!295 = !DILocation(line: 40, column: 3, scope: !283)
!296 = !{!9, !122}
!297 = !DISubroutineType(types: !296)
!298 = distinct !DISubprogram(name: "support.elf.byte17", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte17.12", scope: !115, file: !115, line: 44, type: !297, scopeLine: 44, spFlags: DISPFlagDefinition, unit: !2)
!299 = !DILocalVariable(name: "bytes", arg: 1, scope: !298, file: !115, line: 44, type: !122)
!300 = !DILocation(line: 44, column: 15, scope: !298)
!301 = !DILocation(line: 45, column: 3, scope: !298)
!302 = !DILocation(line: 45, column: 3, scope: !298)
!303 = !DILocation(line: 45, column: 3, scope: !298)
!304 = !DILocation(line: 46, column: 10, scope: !298)
!305 = !DILocalVariable(name: "value", scope: !298, file: !115, line: 46, type: !9)
!306 = !DILocation(line: 46, column: 10, scope: !298)
!307 = !DILocation(line: 46, column: 21, scope: !298)
!308 = !DILocation(line: 47, column: 15, scope: !298)
!309 = !DILocation(line: 45, column: 3, scope: !298)
!310 = !DILocation(line: 45, column: 3, scope: !298)
!311 = !{!9, !9, !9}
!312 = !DISubroutineType(types: !311)
!313 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.13", scope: !115, file: !115, line: 109, type: !312, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !2)
!314 = !DILocalVariable(name: "low", arg: 1, scope: !313, file: !115, line: 109, type: !9)
!315 = !DILocation(line: 109, column: 18, scope: !313)
!316 = !DILocalVariable(name: "high", arg: 2, scope: !313, file: !115, line: 109, type: !9)
!317 = !DILocation(line: 109, column: 29, scope: !313)
!318 = !DILocation(line: 110, column: 10, scope: !313)
!319 = !DILocation(line: 110, column: 3, scope: !313)
!320 = !DILocation(line: 110, column: 3, scope: !313)
!321 = !{!9, !122}
!322 = !DISubroutineType(types: !321)
!323 = distinct !DISubprogram(name: "support.elf.read-type", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dtype.14", scope: !115, file: !115, line: 124, type: !322, scopeLine: 124, spFlags: DISPFlagDefinition, unit: !2)
!324 = !DILocalVariable(name: "bytes", arg: 1, scope: !323, file: !115, line: 124, type: !122)
!325 = !DILocation(line: 124, column: 18, scope: !323)
!326 = !DILocation(line: 125, column: 13, scope: !323)
!327 = !DILocation(line: 125, column: 27, scope: !323)
!328 = !DILocation(line: 125, column: 3, scope: !323)
!329 = !DILocation(line: 125, column: 3, scope: !323)
!330 = !{!9, !122}
!331 = !DISubroutineType(types: !330)
!332 = distinct !DISubprogram(name: "support.elf.byte18", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte18.15", scope: !115, file: !115, line: 49, type: !331, scopeLine: 49, spFlags: DISPFlagDefinition, unit: !2)
!333 = !DILocalVariable(name: "bytes", arg: 1, scope: !332, file: !115, line: 49, type: !122)
!334 = !DILocation(line: 49, column: 15, scope: !332)
!335 = !DILocation(line: 50, column: 3, scope: !332)
!336 = !DILocation(line: 50, column: 3, scope: !332)
!337 = !DILocation(line: 50, column: 3, scope: !332)
!338 = !DILocation(line: 51, column: 10, scope: !332)
!339 = !DILocalVariable(name: "value", scope: !332, file: !115, line: 51, type: !9)
!340 = !DILocation(line: 51, column: 10, scope: !332)
!341 = !DILocation(line: 51, column: 21, scope: !332)
!342 = !DILocation(line: 52, column: 15, scope: !332)
!343 = !DILocation(line: 50, column: 3, scope: !332)
!344 = !DILocation(line: 50, column: 3, scope: !332)
!345 = !{!9, !122}
!346 = !DISubroutineType(types: !345)
!347 = distinct !DISubprogram(name: "support.elf.byte19", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte19.16", scope: !115, file: !115, line: 54, type: !346, scopeLine: 54, spFlags: DISPFlagDefinition, unit: !2)
!348 = !DILocalVariable(name: "bytes", arg: 1, scope: !347, file: !115, line: 54, type: !122)
!349 = !DILocation(line: 54, column: 15, scope: !347)
!350 = !DILocation(line: 55, column: 3, scope: !347)
!351 = !DILocation(line: 55, column: 3, scope: !347)
!352 = !DILocation(line: 55, column: 3, scope: !347)
!353 = !DILocation(line: 56, column: 10, scope: !347)
!354 = !DILocalVariable(name: "value", scope: !347, file: !115, line: 56, type: !9)
!355 = !DILocation(line: 56, column: 10, scope: !347)
!356 = !DILocation(line: 56, column: 21, scope: !347)
!357 = !DILocation(line: 57, column: 15, scope: !347)
!358 = !DILocation(line: 55, column: 3, scope: !347)
!359 = !DILocation(line: 55, column: 3, scope: !347)
!360 = !{!9, !9, !9}
!361 = !DISubroutineType(types: !360)
!362 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.17", scope: !115, file: !115, line: 109, type: !361, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !2)
!363 = !DILocalVariable(name: "low", arg: 1, scope: !362, file: !115, line: 109, type: !9)
!364 = !DILocation(line: 109, column: 18, scope: !362)
!365 = !DILocalVariable(name: "high", arg: 2, scope: !362, file: !115, line: 109, type: !9)
!366 = !DILocation(line: 109, column: 29, scope: !362)
!367 = !DILocation(line: 110, column: 10, scope: !362)
!368 = !DILocation(line: 110, column: 3, scope: !362)
!369 = !DILocation(line: 110, column: 3, scope: !362)
!370 = !{!9, !122}
!371 = !DISubroutineType(types: !370)
!372 = distinct !DISubprogram(name: "support.elf.read-machine", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dmachine.18", scope: !115, file: !115, line: 127, type: !371, scopeLine: 127, spFlags: DISPFlagDefinition, unit: !2)
!373 = !DILocalVariable(name: "bytes", arg: 1, scope: !372, file: !115, line: 127, type: !122)
!374 = !DILocation(line: 127, column: 21, scope: !372)
!375 = !DILocation(line: 128, column: 13, scope: !372)
!376 = !DILocation(line: 128, column: 27, scope: !372)
!377 = !DILocation(line: 128, column: 3, scope: !372)
!378 = !DILocation(line: 128, column: 3, scope: !372)
!379 = !{!9, !122}
!380 = !DISubroutineType(types: !379)
!381 = distinct !DISubprogram(name: "support.elf.byte20", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte20.19", scope: !115, file: !115, line: 59, type: !380, scopeLine: 59, spFlags: DISPFlagDefinition, unit: !2)
!382 = !DILocalVariable(name: "bytes", arg: 1, scope: !381, file: !115, line: 59, type: !122)
!383 = !DILocation(line: 59, column: 15, scope: !381)
!384 = !DILocation(line: 60, column: 3, scope: !381)
!385 = !DILocation(line: 60, column: 3, scope: !381)
!386 = !DILocation(line: 60, column: 3, scope: !381)
!387 = !DILocation(line: 61, column: 10, scope: !381)
!388 = !DILocalVariable(name: "value", scope: !381, file: !115, line: 61, type: !9)
!389 = !DILocation(line: 61, column: 10, scope: !381)
!390 = !DILocation(line: 61, column: 21, scope: !381)
!391 = !DILocation(line: 62, column: 15, scope: !381)
!392 = !DILocation(line: 60, column: 3, scope: !381)
!393 = !DILocation(line: 60, column: 3, scope: !381)
!394 = !{!9, !122}
!395 = !DISubroutineType(types: !394)
!396 = distinct !DISubprogram(name: "support.elf.byte21", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte21.20", scope: !115, file: !115, line: 64, type: !395, scopeLine: 64, spFlags: DISPFlagDefinition, unit: !2)
!397 = !DILocalVariable(name: "bytes", arg: 1, scope: !396, file: !115, line: 64, type: !122)
!398 = !DILocation(line: 64, column: 15, scope: !396)
!399 = !DILocation(line: 65, column: 3, scope: !396)
!400 = !DILocation(line: 65, column: 3, scope: !396)
!401 = !DILocation(line: 65, column: 3, scope: !396)
!402 = !DILocation(line: 66, column: 10, scope: !396)
!403 = !DILocalVariable(name: "value", scope: !396, file: !115, line: 66, type: !9)
!404 = !DILocation(line: 66, column: 10, scope: !396)
!405 = !DILocation(line: 66, column: 21, scope: !396)
!406 = !DILocation(line: 67, column: 15, scope: !396)
!407 = !DILocation(line: 65, column: 3, scope: !396)
!408 = !DILocation(line: 65, column: 3, scope: !396)
!409 = !{!9, !122}
!410 = !DISubroutineType(types: !409)
!411 = distinct !DISubprogram(name: "support.elf.byte22", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte22.21", scope: !115, file: !115, line: 69, type: !410, scopeLine: 69, spFlags: DISPFlagDefinition, unit: !2)
!412 = !DILocalVariable(name: "bytes", arg: 1, scope: !411, file: !115, line: 69, type: !122)
!413 = !DILocation(line: 69, column: 15, scope: !411)
!414 = !DILocation(line: 70, column: 3, scope: !411)
!415 = !DILocation(line: 70, column: 3, scope: !411)
!416 = !DILocation(line: 70, column: 3, scope: !411)
!417 = !DILocation(line: 71, column: 10, scope: !411)
!418 = !DILocalVariable(name: "value", scope: !411, file: !115, line: 71, type: !9)
!419 = !DILocation(line: 71, column: 10, scope: !411)
!420 = !DILocation(line: 71, column: 21, scope: !411)
!421 = !DILocation(line: 72, column: 15, scope: !411)
!422 = !DILocation(line: 70, column: 3, scope: !411)
!423 = !DILocation(line: 70, column: 3, scope: !411)
!424 = !{!9, !122}
!425 = !DISubroutineType(types: !424)
!426 = distinct !DISubprogram(name: "support.elf.byte23", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte23.22", scope: !115, file: !115, line: 74, type: !425, scopeLine: 74, spFlags: DISPFlagDefinition, unit: !2)
!427 = !DILocalVariable(name: "bytes", arg: 1, scope: !426, file: !115, line: 74, type: !122)
!428 = !DILocation(line: 74, column: 15, scope: !426)
!429 = !DILocation(line: 75, column: 3, scope: !426)
!430 = !DILocation(line: 75, column: 3, scope: !426)
!431 = !DILocation(line: 75, column: 3, scope: !426)
!432 = !DILocation(line: 76, column: 10, scope: !426)
!433 = !DILocalVariable(name: "value", scope: !426, file: !115, line: 76, type: !9)
!434 = !DILocation(line: 76, column: 10, scope: !426)
!435 = !DILocation(line: 76, column: 21, scope: !426)
!436 = !DILocation(line: 77, column: 15, scope: !426)
!437 = !DILocation(line: 75, column: 3, scope: !426)
!438 = !DILocation(line: 75, column: 3, scope: !426)
!439 = !{!9, !9, !9, !9, !9}
!440 = !DISubroutineType(types: !439)
!441 = distinct !DISubprogram(name: "support.elf.word-four", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dfour.23", scope: !115, file: !115, line: 115, type: !440, scopeLine: 115, spFlags: DISPFlagDefinition, unit: !2)
!442 = !DILocalVariable(name: "first", arg: 1, scope: !441, file: !115, line: 115, type: !9)
!443 = !DILocation(line: 115, column: 19, scope: !441)
!444 = !DILocalVariable(name: "second", arg: 2, scope: !441, file: !115, line: 115, type: !9)
!445 = !DILocation(line: 115, column: 32, scope: !441)
!446 = !DILocalVariable(name: "third", arg: 3, scope: !441, file: !115, line: 115, type: !9)
!447 = !DILocation(line: 115, column: 46, scope: !441)
!448 = !DILocalVariable(name: "fourth", arg: 4, scope: !441, file: !115, line: 115, type: !9)
!449 = !DILocation(line: 115, column: 59, scope: !441)
!450 = !DILocation(line: 116, column: 12, scope: !441)
!451 = !DILocation(line: 116, column: 3, scope: !441)
!452 = !DILocation(line: 116, column: 29, scope: !441)
!453 = !DILocation(line: 116, column: 3, scope: !441)
!454 = !DILocation(line: 116, column: 47, scope: !441)
!455 = !DILocation(line: 116, column: 3, scope: !441)
!456 = !DILocation(line: 116, column: 3, scope: !441)
!457 = !{!9, !122}
!458 = !DISubroutineType(types: !457)
!459 = distinct !DISubprogram(name: "support.elf.read-version", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dversion.24", scope: !115, file: !115, line: 130, type: !458, scopeLine: 130, spFlags: DISPFlagDefinition, unit: !2)
!460 = !DILocalVariable(name: "bytes", arg: 1, scope: !459, file: !115, line: 130, type: !122)
!461 = !DILocation(line: 130, column: 21, scope: !459)
!462 = !DILocation(line: 131, column: 14, scope: !459)
!463 = !DILocation(line: 131, column: 28, scope: !459)
!464 = !DILocation(line: 131, column: 42, scope: !459)
!465 = !DILocation(line: 131, column: 56, scope: !459)
!466 = !DILocation(line: 131, column: 3, scope: !459)
!467 = !DILocation(line: 131, column: 3, scope: !459)
!468 = !{!9, !122}
!469 = !DISubroutineType(types: !468)
!470 = distinct !DISubprogram(name: "support.elf.byte52", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte52.25", scope: !115, file: !115, line: 79, type: !469, scopeLine: 79, spFlags: DISPFlagDefinition, unit: !2)
!471 = !DILocalVariable(name: "bytes", arg: 1, scope: !470, file: !115, line: 79, type: !122)
!472 = !DILocation(line: 79, column: 15, scope: !470)
!473 = !DILocation(line: 80, column: 3, scope: !470)
!474 = !DILocation(line: 80, column: 3, scope: !470)
!475 = !DILocation(line: 80, column: 3, scope: !470)
!476 = !DILocation(line: 81, column: 10, scope: !470)
!477 = !DILocalVariable(name: "value", scope: !470, file: !115, line: 81, type: !9)
!478 = !DILocation(line: 81, column: 10, scope: !470)
!479 = !DILocation(line: 81, column: 21, scope: !470)
!480 = !DILocation(line: 82, column: 15, scope: !470)
!481 = !DILocation(line: 80, column: 3, scope: !470)
!482 = !DILocation(line: 80, column: 3, scope: !470)
!483 = !{!9, !122}
!484 = !DISubroutineType(types: !483)
!485 = distinct !DISubprogram(name: "support.elf.byte53", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte53.26", scope: !115, file: !115, line: 84, type: !484, scopeLine: 84, spFlags: DISPFlagDefinition, unit: !2)
!486 = !DILocalVariable(name: "bytes", arg: 1, scope: !485, file: !115, line: 84, type: !122)
!487 = !DILocation(line: 84, column: 15, scope: !485)
!488 = !DILocation(line: 85, column: 3, scope: !485)
!489 = !DILocation(line: 85, column: 3, scope: !485)
!490 = !DILocation(line: 85, column: 3, scope: !485)
!491 = !DILocation(line: 86, column: 10, scope: !485)
!492 = !DILocalVariable(name: "value", scope: !485, file: !115, line: 86, type: !9)
!493 = !DILocation(line: 86, column: 10, scope: !485)
!494 = !DILocation(line: 86, column: 21, scope: !485)
!495 = !DILocation(line: 87, column: 15, scope: !485)
!496 = !DILocation(line: 85, column: 3, scope: !485)
!497 = !DILocation(line: 85, column: 3, scope: !485)
!498 = !{!9, !9, !9}
!499 = !DISubroutineType(types: !498)
!500 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.27", scope: !115, file: !115, line: 109, type: !499, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !2)
!501 = !DILocalVariable(name: "low", arg: 1, scope: !500, file: !115, line: 109, type: !9)
!502 = !DILocation(line: 109, column: 18, scope: !500)
!503 = !DILocalVariable(name: "high", arg: 2, scope: !500, file: !115, line: 109, type: !9)
!504 = !DILocation(line: 109, column: 29, scope: !500)
!505 = !DILocation(line: 110, column: 10, scope: !500)
!506 = !DILocation(line: 110, column: 3, scope: !500)
!507 = !DILocation(line: 110, column: 3, scope: !500)
!508 = !{!9, !122}
!509 = !DISubroutineType(types: !508)
!510 = distinct !DISubprogram(name: "support.elf.read-header-size", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dheader_2dsize.28", scope: !115, file: !115, line: 133, type: !509, scopeLine: 133, spFlags: DISPFlagDefinition, unit: !2)
!511 = !DILocalVariable(name: "bytes", arg: 1, scope: !510, file: !115, line: 133, type: !122)
!512 = !DILocation(line: 133, column: 25, scope: !510)
!513 = !DILocation(line: 134, column: 13, scope: !510)
!514 = !DILocation(line: 134, column: 27, scope: !510)
!515 = !DILocation(line: 134, column: 3, scope: !510)
!516 = !DILocation(line: 134, column: 3, scope: !510)
!517 = !{!9, !122}
!518 = !DISubroutineType(types: !517)
!519 = distinct !DISubprogram(name: "support.elf.byte54", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte54.29", scope: !115, file: !115, line: 89, type: !518, scopeLine: 89, spFlags: DISPFlagDefinition, unit: !2)
!520 = !DILocalVariable(name: "bytes", arg: 1, scope: !519, file: !115, line: 89, type: !122)
!521 = !DILocation(line: 89, column: 15, scope: !519)
!522 = !DILocation(line: 90, column: 3, scope: !519)
!523 = !DILocation(line: 90, column: 3, scope: !519)
!524 = !DILocation(line: 90, column: 3, scope: !519)
!525 = !DILocation(line: 91, column: 10, scope: !519)
!526 = !DILocalVariable(name: "value", scope: !519, file: !115, line: 91, type: !9)
!527 = !DILocation(line: 91, column: 10, scope: !519)
!528 = !DILocation(line: 91, column: 21, scope: !519)
!529 = !DILocation(line: 92, column: 15, scope: !519)
!530 = !DILocation(line: 90, column: 3, scope: !519)
!531 = !DILocation(line: 90, column: 3, scope: !519)
!532 = !{!9, !122}
!533 = !DISubroutineType(types: !532)
!534 = distinct !DISubprogram(name: "support.elf.byte55", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte55.30", scope: !115, file: !115, line: 94, type: !533, scopeLine: 94, spFlags: DISPFlagDefinition, unit: !2)
!535 = !DILocalVariable(name: "bytes", arg: 1, scope: !534, file: !115, line: 94, type: !122)
!536 = !DILocation(line: 94, column: 15, scope: !534)
!537 = !DILocation(line: 95, column: 3, scope: !534)
!538 = !DILocation(line: 95, column: 3, scope: !534)
!539 = !DILocation(line: 95, column: 3, scope: !534)
!540 = !DILocation(line: 96, column: 10, scope: !534)
!541 = !DILocalVariable(name: "value", scope: !534, file: !115, line: 96, type: !9)
!542 = !DILocation(line: 96, column: 10, scope: !534)
!543 = !DILocation(line: 96, column: 21, scope: !534)
!544 = !DILocation(line: 97, column: 15, scope: !534)
!545 = !DILocation(line: 95, column: 3, scope: !534)
!546 = !DILocation(line: 95, column: 3, scope: !534)
!547 = !{!9, !9, !9}
!548 = !DISubroutineType(types: !547)
!549 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.31", scope: !115, file: !115, line: 109, type: !548, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !2)
!550 = !DILocalVariable(name: "low", arg: 1, scope: !549, file: !115, line: 109, type: !9)
!551 = !DILocation(line: 109, column: 18, scope: !549)
!552 = !DILocalVariable(name: "high", arg: 2, scope: !549, file: !115, line: 109, type: !9)
!553 = !DILocation(line: 109, column: 29, scope: !549)
!554 = !DILocation(line: 110, column: 10, scope: !549)
!555 = !DILocation(line: 110, column: 3, scope: !549)
!556 = !DILocation(line: 110, column: 3, scope: !549)
!557 = !{!9, !122}
!558 = !DISubroutineType(types: !557)
!559 = distinct !DISubprogram(name: "support.elf.read-entry-size", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dentry_2dsize.32", scope: !115, file: !115, line: 136, type: !558, scopeLine: 136, spFlags: DISPFlagDefinition, unit: !2)
!560 = !DILocalVariable(name: "bytes", arg: 1, scope: !559, file: !115, line: 136, type: !122)
!561 = !DILocation(line: 136, column: 24, scope: !559)
!562 = !DILocation(line: 137, column: 13, scope: !559)
!563 = !DILocation(line: 137, column: 27, scope: !559)
!564 = !DILocation(line: 137, column: 3, scope: !559)
!565 = !DILocation(line: 137, column: 3, scope: !559)
!566 = !{!9, !122}
!567 = !DISubroutineType(types: !566)
!568 = distinct !DISubprogram(name: "support.elf.byte56", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte56.33", scope: !115, file: !115, line: 99, type: !567, scopeLine: 99, spFlags: DISPFlagDefinition, unit: !2)
!569 = !DILocalVariable(name: "bytes", arg: 1, scope: !568, file: !115, line: 99, type: !122)
!570 = !DILocation(line: 99, column: 15, scope: !568)
!571 = !DILocation(line: 100, column: 3, scope: !568)
!572 = !DILocation(line: 100, column: 3, scope: !568)
!573 = !DILocation(line: 100, column: 3, scope: !568)
!574 = !DILocation(line: 101, column: 10, scope: !568)
!575 = !DILocalVariable(name: "value", scope: !568, file: !115, line: 101, type: !9)
!576 = !DILocation(line: 101, column: 10, scope: !568)
!577 = !DILocation(line: 101, column: 21, scope: !568)
!578 = !DILocation(line: 102, column: 15, scope: !568)
!579 = !DILocation(line: 100, column: 3, scope: !568)
!580 = !DILocation(line: 100, column: 3, scope: !568)
!581 = !{!9, !122}
!582 = !DISubroutineType(types: !581)
!583 = distinct !DISubprogram(name: "support.elf.byte57", linkageName: "topal.header.topal.fn.support_2eelf_2ebyte57.34", scope: !115, file: !115, line: 104, type: !582, scopeLine: 104, spFlags: DISPFlagDefinition, unit: !2)
!584 = !DILocalVariable(name: "bytes", arg: 1, scope: !583, file: !115, line: 104, type: !122)
!585 = !DILocation(line: 104, column: 15, scope: !583)
!586 = !DILocation(line: 105, column: 3, scope: !583)
!587 = !DILocation(line: 105, column: 3, scope: !583)
!588 = !DILocation(line: 105, column: 3, scope: !583)
!589 = !DILocation(line: 106, column: 10, scope: !583)
!590 = !DILocalVariable(name: "value", scope: !583, file: !115, line: 106, type: !9)
!591 = !DILocation(line: 106, column: 10, scope: !583)
!592 = !DILocation(line: 106, column: 21, scope: !583)
!593 = !DILocation(line: 107, column: 15, scope: !583)
!594 = !DILocation(line: 105, column: 3, scope: !583)
!595 = !DILocation(line: 105, column: 3, scope: !583)
!596 = !{!9, !9, !9}
!597 = !DISubroutineType(types: !596)
!598 = distinct !DISubprogram(name: "support.elf.word-two", linkageName: "topal.header.topal.fn.support_2eelf_2eword_2dtwo.35", scope: !115, file: !115, line: 109, type: !597, scopeLine: 109, spFlags: DISPFlagDefinition, unit: !2)
!599 = !DILocalVariable(name: "low", arg: 1, scope: !598, file: !115, line: 109, type: !9)
!600 = !DILocation(line: 109, column: 18, scope: !598)
!601 = !DILocalVariable(name: "high", arg: 2, scope: !598, file: !115, line: 109, type: !9)
!602 = !DILocation(line: 109, column: 29, scope: !598)
!603 = !DILocation(line: 110, column: 10, scope: !598)
!604 = !DILocation(line: 110, column: 3, scope: !598)
!605 = !DILocation(line: 110, column: 3, scope: !598)
!606 = !{!9, !122}
!607 = !DISubroutineType(types: !606)
!608 = distinct !DISubprogram(name: "support.elf.read-count", linkageName: "topal.header.topal.fn.support_2eelf_2eread_2dcount.36", scope: !115, file: !115, line: 139, type: !607, scopeLine: 139, spFlags: DISPFlagDefinition, unit: !2)
!609 = !DILocalVariable(name: "bytes", arg: 1, scope: !608, file: !115, line: 139, type: !122)
!610 = !DILocation(line: 139, column: 19, scope: !608)
!611 = !DILocation(line: 140, column: 13, scope: !608)
!612 = !DILocation(line: 140, column: 27, scope: !608)
!613 = !DILocation(line: 140, column: 3, scope: !608)
!614 = !DILocation(line: 140, column: 3, scope: !608)
!615 = !{!107, !122, !10, !10}
!616 = !DISubroutineType(types: !615)
!617 = distinct !DISubprogram(name: "support.elf.check-count", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dcount.37", scope: !115, file: !115, line: 142, type: !616, scopeLine: 142, spFlags: DISPFlagDefinition, unit: !2)
!618 = !DILocalVariable(name: "bytes", arg: 1, scope: !617, file: !115, line: 142, type: !122)
!619 = !DILocation(line: 142, column: 21, scope: !617)
!620 = !DILocalVariable(name: "machine", arg: 2, scope: !617, file: !115, line: 142, type: !10)
!621 = !DILocation(line: 142, column: 46, scope: !617)
!622 = !DILocalVariable(name: "maximum", arg: 3, scope: !617, file: !115, line: 142, type: !10)
!623 = !DILocation(line: 142, column: 61, scope: !617)
!624 = !DILocation(line: 143, column: 12, scope: !617)
!625 = !DILocalVariable(name: "count", scope: !617, file: !115, line: 143, type: !9)
!626 = !DILocation(line: 143, column: 3, scope: !617)
!627 = !DILocation(line: 144, column: 3, scope: !617)
!628 = !DILocation(line: 144, column: 3, scope: !617)
!629 = !DILocation(line: 144, column: 3, scope: !617)
!630 = !DILocation(line: 145, column: 15, scope: !617)
!631 = !DILocation(line: 145, column: 15, scope: !617)
!632 = !DILocation(line: 145, column: 15, scope: !617)
!633 = !DILocation(line: 146, column: 16, scope: !617)
!634 = !DILocation(line: 144, column: 3, scope: !617)
!635 = !DILocation(line: 144, column: 3, scope: !617)
!636 = !{!107, !122, !10, !10}
!637 = !DISubroutineType(types: !636)
!638 = distinct !DISubprogram(name: "support.elf.check-entry-size", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dentry_2dsize.38", scope: !115, file: !115, line: 148, type: !637, scopeLine: 148, spFlags: DISPFlagDefinition, unit: !2)
!639 = !DILocalVariable(name: "bytes", arg: 1, scope: !638, file: !115, line: 148, type: !122)
!640 = !DILocation(line: 148, column: 26, scope: !638)
!641 = !DILocalVariable(name: "machine", arg: 2, scope: !638, file: !115, line: 148, type: !10)
!642 = !DILocation(line: 148, column: 51, scope: !638)
!643 = !DILocalVariable(name: "maximum", arg: 3, scope: !638, file: !115, line: 148, type: !10)
!644 = !DILocation(line: 148, column: 66, scope: !638)
!645 = !DILocation(line: 149, column: 12, scope: !638)
!646 = !DILocalVariable(name: "value", scope: !638, file: !115, line: 149, type: !9)
!647 = !DILocation(line: 149, column: 3, scope: !638)
!648 = !DILocation(line: 150, column: 3, scope: !638)
!649 = !DILocation(line: 150, column: 3, scope: !638)
!650 = !DILocation(line: 150, column: 3, scope: !638)
!651 = !DILocation(line: 150, column: 3, scope: !638)
!652 = !DILocation(line: 151, column: 15, scope: !638)
!653 = !DILocation(line: 151, column: 15, scope: !638)
!654 = !DILocation(line: 152, column: 16, scope: !638)
!655 = !DILocation(line: 150, column: 3, scope: !638)
!656 = !DILocation(line: 150, column: 3, scope: !638)
!657 = !{!107, !122, !10, !10}
!658 = !DISubroutineType(types: !657)
!659 = distinct !DISubprogram(name: "support.elf.check-header-size", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dheader_2dsize.39", scope: !115, file: !115, line: 154, type: !658, scopeLine: 154, spFlags: DISPFlagDefinition, unit: !2)
!660 = !DILocalVariable(name: "bytes", arg: 1, scope: !659, file: !115, line: 154, type: !122)
!661 = !DILocation(line: 154, column: 27, scope: !659)
!662 = !DILocalVariable(name: "machine", arg: 2, scope: !659, file: !115, line: 154, type: !10)
!663 = !DILocation(line: 154, column: 52, scope: !659)
!664 = !DILocalVariable(name: "maximum", arg: 3, scope: !659, file: !115, line: 154, type: !10)
!665 = !DILocation(line: 154, column: 67, scope: !659)
!666 = !DILocation(line: 155, column: 12, scope: !659)
!667 = !DILocalVariable(name: "value", scope: !659, file: !115, line: 155, type: !9)
!668 = !DILocation(line: 155, column: 3, scope: !659)
!669 = !DILocation(line: 156, column: 3, scope: !659)
!670 = !DILocation(line: 156, column: 3, scope: !659)
!671 = !DILocation(line: 156, column: 3, scope: !659)
!672 = !DILocation(line: 156, column: 3, scope: !659)
!673 = !DILocation(line: 157, column: 15, scope: !659)
!674 = !DILocation(line: 157, column: 15, scope: !659)
!675 = !DILocation(line: 158, column: 16, scope: !659)
!676 = !DILocation(line: 156, column: 3, scope: !659)
!677 = !DILocation(line: 156, column: 3, scope: !659)
!678 = !{!107, !122, !10, !10}
!679 = !DISubroutineType(types: !678)
!680 = distinct !DISubprogram(name: "support.elf.check-version", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dversion.40", scope: !115, file: !115, line: 160, type: !679, scopeLine: 160, spFlags: DISPFlagDefinition, unit: !2)
!681 = !DILocalVariable(name: "bytes", arg: 1, scope: !680, file: !115, line: 160, type: !122)
!682 = !DILocation(line: 160, column: 23, scope: !680)
!683 = !DILocalVariable(name: "machine", arg: 2, scope: !680, file: !115, line: 160, type: !10)
!684 = !DILocation(line: 160, column: 48, scope: !680)
!685 = !DILocalVariable(name: "maximum", arg: 3, scope: !680, file: !115, line: 160, type: !10)
!686 = !DILocation(line: 160, column: 63, scope: !680)
!687 = !DILocation(line: 161, column: 12, scope: !680)
!688 = !DILocalVariable(name: "value", scope: !680, file: !115, line: 161, type: !9)
!689 = !DILocation(line: 161, column: 3, scope: !680)
!690 = !DILocation(line: 162, column: 3, scope: !680)
!691 = !DILocation(line: 162, column: 3, scope: !680)
!692 = !DILocation(line: 162, column: 3, scope: !680)
!693 = !DILocation(line: 162, column: 3, scope: !680)
!694 = !DILocation(line: 163, column: 15, scope: !680)
!695 = !DILocation(line: 163, column: 15, scope: !680)
!696 = !DILocation(line: 164, column: 16, scope: !680)
!697 = !DILocation(line: 162, column: 3, scope: !680)
!698 = !DILocation(line: 162, column: 3, scope: !680)
!699 = !{!107, !122, !10, !10}
!700 = !DISubroutineType(types: !699)
!701 = distinct !DISubprogram(name: "support.elf.check-machine", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dmachine.41", scope: !115, file: !115, line: 166, type: !700, scopeLine: 166, spFlags: DISPFlagDefinition, unit: !2)
!702 = !DILocalVariable(name: "bytes", arg: 1, scope: !701, file: !115, line: 166, type: !122)
!703 = !DILocation(line: 166, column: 23, scope: !701)
!704 = !DILocalVariable(name: "machine", arg: 2, scope: !701, file: !115, line: 166, type: !10)
!705 = !DILocation(line: 166, column: 48, scope: !701)
!706 = !DILocalVariable(name: "maximum", arg: 3, scope: !701, file: !115, line: 166, type: !10)
!707 = !DILocation(line: 166, column: 63, scope: !701)
!708 = !DILocation(line: 167, column: 12, scope: !701)
!709 = !DILocalVariable(name: "value", scope: !701, file: !115, line: 167, type: !9)
!710 = !DILocation(line: 167, column: 3, scope: !701)
!711 = !DILocation(line: 168, column: 3, scope: !701)
!712 = !DILocation(line: 168, column: 3, scope: !701)
!713 = !DILocation(line: 168, column: 3, scope: !701)
!714 = !DILocation(line: 168, column: 3, scope: !701)
!715 = !DILocation(line: 169, column: 15, scope: !701)
!716 = !DILocation(line: 169, column: 15, scope: !701)
!717 = !DILocation(line: 170, column: 16, scope: !701)
!718 = !DILocation(line: 168, column: 3, scope: !701)
!719 = !DILocation(line: 168, column: 3, scope: !701)
!720 = !{!107, !122, !10, !10}
!721 = !DISubroutineType(types: !720)
!722 = distinct !DISubprogram(name: "support.elf.check-type", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dtype.42", scope: !115, file: !115, line: 172, type: !721, scopeLine: 172, spFlags: DISPFlagDefinition, unit: !2)
!723 = !DILocalVariable(name: "bytes", arg: 1, scope: !722, file: !115, line: 172, type: !122)
!724 = !DILocation(line: 172, column: 20, scope: !722)
!725 = !DILocalVariable(name: "machine", arg: 2, scope: !722, file: !115, line: 172, type: !10)
!726 = !DILocation(line: 172, column: 45, scope: !722)
!727 = !DILocalVariable(name: "maximum", arg: 3, scope: !722, file: !115, line: 172, type: !10)
!728 = !DILocation(line: 172, column: 60, scope: !722)
!729 = !DILocation(line: 173, column: 12, scope: !722)
!730 = !DILocalVariable(name: "value", scope: !722, file: !115, line: 173, type: !9)
!731 = !DILocation(line: 173, column: 3, scope: !722)
!732 = !DILocation(line: 174, column: 3, scope: !722)
!733 = !DILocation(line: 174, column: 3, scope: !722)
!734 = !DILocation(line: 174, column: 3, scope: !722)
!735 = !DILocation(line: 174, column: 3, scope: !722)
!736 = !DILocation(line: 175, column: 15, scope: !722)
!737 = !DILocation(line: 175, column: 15, scope: !722)
!738 = !DILocation(line: 176, column: 16, scope: !722)
!739 = !DILocation(line: 174, column: 3, scope: !722)
!740 = !DILocation(line: 174, column: 3, scope: !722)
!741 = !{!107, !122, !10, !10}
!742 = !DISubroutineType(types: !741)
!743 = distinct !DISubprogram(name: "support.elf.check-ident", linkageName: "topal.header.topal.fn.support_2eelf_2echeck_2dident.43", scope: !115, file: !115, line: 178, type: !742, scopeLine: 178, spFlags: DISPFlagDefinition, unit: !2)
!744 = !DILocalVariable(name: "bytes", arg: 1, scope: !743, file: !115, line: 178, type: !122)
!745 = !DILocation(line: 178, column: 21, scope: !743)
!746 = !DILocalVariable(name: "machine", arg: 2, scope: !743, file: !115, line: 178, type: !10)
!747 = !DILocation(line: 178, column: 46, scope: !743)
!748 = !DILocalVariable(name: "maximum", arg: 3, scope: !743, file: !115, line: 178, type: !10)
!749 = !DILocation(line: 178, column: 61, scope: !743)
!750 = !DILocation(line: 179, column: 12, scope: !743)
!751 = !DILocalVariable(name: "value", scope: !743, file: !115, line: 179, type: !9)
!752 = !DILocation(line: 179, column: 3, scope: !743)
!753 = !DILocation(line: 180, column: 3, scope: !743)
!754 = !DILocation(line: 180, column: 3, scope: !743)
!755 = !DILocation(line: 180, column: 3, scope: !743)
!756 = !DILocation(line: 180, column: 3, scope: !743)
!757 = !DILocation(line: 181, column: 15, scope: !743)
!758 = !DILocation(line: 181, column: 15, scope: !743)
!759 = !DILocation(line: 182, column: 16, scope: !743)
!760 = !DILocation(line: 180, column: 3, scope: !743)
!761 = !DILocation(line: 180, column: 3, scope: !743)
!762 = !{!107, !122, !10, !10}
!763 = !DISubroutineType(types: !762)
!764 = distinct !DISubprogram(name: "support.elf.admitted?", linkageName: "topal.header.topal.fn.support_2eelf_2eadmitted_3f.44", scope: !115, file: !115, line: 184, type: !763, scopeLine: 184, spFlags: DISPFlagDefinition, unit: !2)
!765 = !DILocalVariable(name: "bytes", arg: 1, scope: !764, file: !115, line: 184, type: !122)
!766 = !DILocation(line: 184, column: 23, scope: !764)
!767 = !DILocalVariable(name: "machine", arg: 2, scope: !764, file: !115, line: 184, type: !10)
!768 = !DILocation(line: 184, column: 48, scope: !764)
!769 = !DILocalVariable(name: "maximum", arg: 3, scope: !764, file: !115, line: 184, type: !10)
!770 = !DILocation(line: 184, column: 63, scope: !764)
!771 = !DILocation(line: 185, column: 12, scope: !764)
!772 = !DILocalVariable(name: "magic", scope: !764, file: !115, line: 185, type: !9)
!773 = !DILocation(line: 185, column: 3, scope: !764)
!774 = !DILocation(line: 186, column: 3, scope: !764)
!775 = !DILocation(line: 186, column: 3, scope: !764)
!776 = !DILocation(line: 186, column: 3, scope: !764)
!777 = !DILocation(line: 186, column: 3, scope: !764)
!778 = !DILocation(line: 187, column: 15, scope: !764)
!779 = !DILocation(line: 187, column: 15, scope: !764)
!780 = !DILocation(line: 188, column: 16, scope: !764)
!781 = !DILocation(line: 186, column: 3, scope: !764)
!782 = !DILocation(line: 186, column: 3, scope: !764)
!783 = !{!107, !122, !10, !10}
!784 = !DISubroutineType(types: !783)
!785 = distinct !DISubprogram(name: "header-admitted?", linkageName: "topal.header.topal.fn.header_2dadmitted_3f.45", scope: !0, file: !0, line: 4, type: !784, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !2)
!786 = !DILocalVariable(name: "bytes", arg: 1, scope: !785, file: !0, line: 4, type: !122)
!787 = !DILocation(line: 4, column: 30, scope: !785)
!788 = !DILocalVariable(name: "machine", arg: 2, scope: !785, file: !0, line: 4, type: !10)
!789 = !DILocation(line: 4, column: 55, scope: !785)
!790 = !DILocalVariable(name: "maximum", arg: 3, scope: !785, file: !0, line: 4, type: !10)
!791 = !DILocation(line: 4, column: 70, scope: !785)
!792 = !DILocation(line: 5, column: 3, scope: !785)
!793 = !DILocation(line: 5, column: 3, scope: !785)
!794 = !{i32 2, !"Dwarf Version", i32 5}
!795 = !{i32 2, !"Debug Info Version", i32 3}
!796 = !{!"topalc 0.1.0"}
