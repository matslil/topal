; ModuleID = 'kernel-region'
source_filename = "namespace-action.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.OptionalStorage = type { i64, ptr }
%topal.IntStorage = type { i64, i64, [0 x i32] }
%topal.KernelRegionControl = type { ptr, i64, i64, i64, ptr, i64, i64, i64 }
%topal.KernelRegionView = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }

@llvm.used = appending global [1 x ptr] [ptr @topal.region-instance.namespace-metadata.memset], section "llvm.metadata"
@topal.region-instance.namespace-metadata.runtime.int.zero = internal constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@topal.region-instance.namespace-metadata.runtime.int.positive.infinity = internal constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.region-instance.namespace-metadata.runtime.int.negative.infinity = internal constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.region-instance.namespace-metadata.literal.int.0 = internal unnamed_addr constant { i64, i64, [3 x i32] } { i64 0, i64 3, [3 x i32] [i32 0, i32 0, i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.1 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.2 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.3 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.4 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.5 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.6 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.7 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.8 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.9 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.10 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.11 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.12 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.region-instance.namespace-metadata.literal.int.13 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.14 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.15 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.16 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.17 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.18 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.region-instance.namespace-metadata.literal.int.19 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 96] }, align 8
@topal.region-instance.namespace-metadata.literal.int.20 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 112] }, align 8
@topal.region-instance.namespace-metadata.literal.int.21 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.region-instance.namespace-metadata.literal.int.22 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.23 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.24 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32768] }, align 8
@topal.region-instance.namespace-metadata.literal.int.25 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 36863] }, align 8
@topal.region-instance.namespace-metadata.literal.int.26 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.27 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.28 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.29 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.30 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.31 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.32 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.33 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.34 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.35 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.36 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.37 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.38 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.39 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.40 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.41 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.42 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.43 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1536] }, align 8
@topal.region-instance.namespace-metadata.literal.int.44 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.45 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.46 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.47 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.48 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.49 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.50 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.51 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.52 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.53 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.54 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.55 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.56 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.57 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.58 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.59 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.60 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.61 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.62 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.63 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.64 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.65 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.66 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.67 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 46] }, align 8
@topal.region-instance.namespace-metadata.literal.int.68 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 46] }, align 8
@topal.region-instance.namespace-metadata.literal.int.69 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.70 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.71 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 47] }, align 8
@topal.region-instance.namespace-metadata.literal.int.72 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.73 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.74 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.75 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3201] }, align 8
@topal.region-instance.namespace-metadata.literal.int.76 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.77 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3202] }, align 8
@topal.region-instance.namespace-metadata.literal.int.78 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.79 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3203] }, align 8
@topal.region-instance.namespace-metadata.literal.int.80 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.region-instance.namespace-metadata.literal.int.81 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3204] }, align 8
@topal.region-instance.namespace-metadata.literal.int.82 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.83 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3205] }, align 8
@topal.region-instance.namespace-metadata.literal.int.84 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 5] }, align 8
@topal.region-instance.namespace-metadata.literal.int.85 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3206] }, align 8
@topal.region-instance.namespace-metadata.literal.int.86 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 6] }, align 8
@topal.region-instance.namespace-metadata.literal.int.87 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3207] }, align 8
@topal.region-instance.namespace-metadata.literal.int.88 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.89 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3208] }, align 8
@topal.region-instance.namespace-metadata.literal.int.90 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.91 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3209] }, align 8
@topal.region-instance.namespace-metadata.literal.int.92 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 9] }, align 8
@topal.region-instance.namespace-metadata.literal.int.93 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3210] }, align 8
@topal.region-instance.namespace-metadata.literal.int.94 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 10] }, align 8
@topal.region-instance.namespace-metadata.literal.int.95 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3211] }, align 8
@topal.region-instance.namespace-metadata.literal.int.96 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 11] }, align 8
@topal.region-instance.namespace-metadata.literal.int.97 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3212] }, align 8
@topal.region-instance.namespace-metadata.literal.int.98 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 12] }, align 8
@topal.region-instance.namespace-metadata.literal.int.99 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3213] }, align 8
@topal.region-instance.namespace-metadata.literal.int.100 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 13] }, align 8
@topal.region-instance.namespace-metadata.literal.int.101 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3214] }, align 8
@topal.region-instance.namespace-metadata.literal.int.102 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 14] }, align 8
@topal.region-instance.namespace-metadata.literal.int.103 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3215] }, align 8
@topal.region-instance.namespace-metadata.literal.int.104 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 15] }, align 8
@topal.region-instance.namespace-metadata.literal.int.105 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3216] }, align 8
@topal.region-instance.namespace-metadata.literal.int.106 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.107 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3217] }, align 8
@topal.region-instance.namespace-metadata.literal.int.108 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 17] }, align 8
@topal.region-instance.namespace-metadata.literal.int.109 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3218] }, align 8
@topal.region-instance.namespace-metadata.literal.int.110 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 18] }, align 8
@topal.region-instance.namespace-metadata.literal.int.111 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3219] }, align 8
@topal.region-instance.namespace-metadata.literal.int.112 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 19] }, align 8
@topal.region-instance.namespace-metadata.literal.int.113 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3220] }, align 8
@topal.region-instance.namespace-metadata.literal.int.114 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 20] }, align 8
@topal.region-instance.namespace-metadata.literal.int.115 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3221] }, align 8
@topal.region-instance.namespace-metadata.literal.int.116 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 21] }, align 8
@topal.region-instance.namespace-metadata.literal.int.117 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3222] }, align 8
@topal.region-instance.namespace-metadata.literal.int.118 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 22] }, align 8
@topal.region-instance.namespace-metadata.literal.int.119 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3223] }, align 8
@topal.region-instance.namespace-metadata.literal.int.120 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 23] }, align 8
@topal.region-instance.namespace-metadata.literal.int.121 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3224] }, align 8
@topal.region-instance.namespace-metadata.literal.int.122 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.region-instance.namespace-metadata.literal.int.123 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3225] }, align 8
@topal.region-instance.namespace-metadata.literal.int.124 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 25] }, align 8
@topal.region-instance.namespace-metadata.literal.int.125 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3226] }, align 8
@topal.region-instance.namespace-metadata.literal.int.126 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 26] }, align 8
@topal.region-instance.namespace-metadata.literal.int.127 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3227] }, align 8
@topal.region-instance.namespace-metadata.literal.int.128 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 27] }, align 8
@topal.region-instance.namespace-metadata.literal.int.129 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3228] }, align 8
@topal.region-instance.namespace-metadata.literal.int.130 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 28] }, align 8
@topal.region-instance.namespace-metadata.literal.int.131 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3229] }, align 8
@topal.region-instance.namespace-metadata.literal.int.132 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 29] }, align 8
@topal.region-instance.namespace-metadata.literal.int.133 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3230] }, align 8
@topal.region-instance.namespace-metadata.literal.int.134 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 30] }, align 8
@topal.region-instance.namespace-metadata.literal.int.135 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3231] }, align 8
@topal.region-instance.namespace-metadata.literal.int.136 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 31] }, align 8
@topal.region-instance.namespace-metadata.literal.int.137 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3232] }, align 8
@topal.region-instance.namespace-metadata.literal.int.138 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.139 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3233] }, align 8
@topal.region-instance.namespace-metadata.literal.int.140 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 33] }, align 8
@topal.region-instance.namespace-metadata.literal.int.141 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3234] }, align 8
@topal.region-instance.namespace-metadata.literal.int.142 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 34] }, align 8
@topal.region-instance.namespace-metadata.literal.int.143 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3235] }, align 8
@topal.region-instance.namespace-metadata.literal.int.144 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 35] }, align 8
@topal.region-instance.namespace-metadata.literal.int.145 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3236] }, align 8
@topal.region-instance.namespace-metadata.literal.int.146 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 36] }, align 8
@topal.region-instance.namespace-metadata.literal.int.147 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3237] }, align 8
@topal.region-instance.namespace-metadata.literal.int.148 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 37] }, align 8
@topal.region-instance.namespace-metadata.literal.int.149 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3238] }, align 8
@topal.region-instance.namespace-metadata.literal.int.150 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 38] }, align 8
@topal.region-instance.namespace-metadata.literal.int.151 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3239] }, align 8
@topal.region-instance.namespace-metadata.literal.int.152 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 39] }, align 8
@topal.region-instance.namespace-metadata.literal.int.153 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3240] }, align 8
@topal.region-instance.namespace-metadata.literal.int.154 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.region-instance.namespace-metadata.literal.int.155 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3241] }, align 8
@topal.region-instance.namespace-metadata.literal.int.156 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 41] }, align 8
@topal.region-instance.namespace-metadata.literal.int.157 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3242] }, align 8
@topal.region-instance.namespace-metadata.literal.int.158 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 42] }, align 8
@topal.region-instance.namespace-metadata.literal.int.159 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3243] }, align 8
@topal.region-instance.namespace-metadata.literal.int.160 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 43] }, align 8
@topal.region-instance.namespace-metadata.literal.int.161 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3244] }, align 8
@topal.region-instance.namespace-metadata.literal.int.162 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 44] }, align 8
@topal.region-instance.namespace-metadata.literal.int.163 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3245] }, align 8
@topal.region-instance.namespace-metadata.literal.int.164 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 45] }, align 8
@topal.region-instance.namespace-metadata.literal.int.165 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3246] }, align 8
@topal.region-instance.namespace-metadata.literal.int.166 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 46] }, align 8
@topal.region-instance.namespace-metadata.literal.int.167 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3247] }, align 8
@topal.region-instance.namespace-metadata.literal.int.168 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 47] }, align 8
@topal.region-instance.namespace-metadata.literal.int.169 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3248] }, align 8
@topal.region-instance.namespace-metadata.literal.int.170 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.171 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3249] }, align 8
@topal.region-instance.namespace-metadata.literal.int.172 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 49] }, align 8
@topal.region-instance.namespace-metadata.literal.int.173 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3250] }, align 8
@topal.region-instance.namespace-metadata.literal.int.174 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 50] }, align 8
@topal.region-instance.namespace-metadata.literal.int.175 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3251] }, align 8
@topal.region-instance.namespace-metadata.literal.int.176 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 51] }, align 8
@topal.region-instance.namespace-metadata.literal.int.177 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3252] }, align 8
@topal.region-instance.namespace-metadata.literal.int.178 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 52] }, align 8
@topal.region-instance.namespace-metadata.literal.int.179 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3253] }, align 8
@topal.region-instance.namespace-metadata.literal.int.180 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 53] }, align 8
@topal.region-instance.namespace-metadata.literal.int.181 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3254] }, align 8
@topal.region-instance.namespace-metadata.literal.int.182 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 54] }, align 8
@topal.region-instance.namespace-metadata.literal.int.183 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.184 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 55] }, align 8
@topal.region-instance.namespace-metadata.literal.int.185 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.186 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.187 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3257] }, align 8
@topal.region-instance.namespace-metadata.literal.int.188 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 57] }, align 8
@topal.region-instance.namespace-metadata.literal.int.189 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3258] }, align 8
@topal.region-instance.namespace-metadata.literal.int.190 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 58] }, align 8
@topal.region-instance.namespace-metadata.literal.int.191 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3259] }, align 8
@topal.region-instance.namespace-metadata.literal.int.192 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 59] }, align 8
@topal.region-instance.namespace-metadata.literal.int.193 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3260] }, align 8
@topal.region-instance.namespace-metadata.literal.int.194 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 60] }, align 8
@topal.region-instance.namespace-metadata.literal.int.195 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3261] }, align 8
@topal.region-instance.namespace-metadata.literal.int.196 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 61] }, align 8
@topal.region-instance.namespace-metadata.literal.int.197 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3262] }, align 8
@topal.region-instance.namespace-metadata.literal.int.198 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 62] }, align 8
@topal.region-instance.namespace-metadata.literal.int.199 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3263] }, align 8
@topal.region-instance.namespace-metadata.literal.int.200 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 63] }, align 8
@topal.region-instance.namespace-metadata.literal.int.201 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3264] }, align 8
@topal.region-instance.namespace-metadata.literal.int.202 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.203 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3265] }, align 8
@topal.region-instance.namespace-metadata.literal.int.204 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65] }, align 8
@topal.region-instance.namespace-metadata.literal.int.205 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3266] }, align 8
@topal.region-instance.namespace-metadata.literal.int.206 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 66] }, align 8
@topal.region-instance.namespace-metadata.literal.int.207 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3267] }, align 8
@topal.region-instance.namespace-metadata.literal.int.208 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 67] }, align 8
@topal.region-instance.namespace-metadata.literal.int.209 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3268] }, align 8
@topal.region-instance.namespace-metadata.literal.int.210 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 68] }, align 8
@topal.region-instance.namespace-metadata.literal.int.211 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3269] }, align 8
@topal.region-instance.namespace-metadata.literal.int.212 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 69] }, align 8
@topal.region-instance.namespace-metadata.literal.int.213 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3270] }, align 8
@topal.region-instance.namespace-metadata.literal.int.214 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 70] }, align 8
@topal.region-instance.namespace-metadata.literal.int.215 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3271] }, align 8
@topal.region-instance.namespace-metadata.literal.int.216 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 71] }, align 8
@topal.region-instance.namespace-metadata.literal.int.217 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3272] }, align 8
@topal.region-instance.namespace-metadata.literal.int.218 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.region-instance.namespace-metadata.literal.int.219 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3273] }, align 8
@topal.region-instance.namespace-metadata.literal.int.220 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 73] }, align 8
@topal.region-instance.namespace-metadata.literal.int.221 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3274] }, align 8
@topal.region-instance.namespace-metadata.literal.int.222 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 74] }, align 8
@topal.region-instance.namespace-metadata.literal.int.223 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3275] }, align 8
@topal.region-instance.namespace-metadata.literal.int.224 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 75] }, align 8
@topal.region-instance.namespace-metadata.literal.int.225 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3276] }, align 8
@topal.region-instance.namespace-metadata.literal.int.226 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 76] }, align 8
@topal.region-instance.namespace-metadata.literal.int.227 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3277] }, align 8
@topal.region-instance.namespace-metadata.literal.int.228 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 77] }, align 8
@topal.region-instance.namespace-metadata.literal.int.229 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3278] }, align 8
@topal.region-instance.namespace-metadata.literal.int.230 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 78] }, align 8
@topal.region-instance.namespace-metadata.literal.int.231 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3279] }, align 8
@topal.region-instance.namespace-metadata.literal.int.232 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 79] }, align 8
@topal.region-instance.namespace-metadata.literal.int.233 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3280] }, align 8
@topal.region-instance.namespace-metadata.literal.int.234 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.region-instance.namespace-metadata.literal.int.235 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3281] }, align 8
@topal.region-instance.namespace-metadata.literal.int.236 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 81] }, align 8
@topal.region-instance.namespace-metadata.literal.int.237 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3282] }, align 8
@topal.region-instance.namespace-metadata.literal.int.238 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 82] }, align 8
@topal.region-instance.namespace-metadata.literal.int.239 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3283] }, align 8
@topal.region-instance.namespace-metadata.literal.int.240 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 83] }, align 8
@topal.region-instance.namespace-metadata.literal.int.241 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3284] }, align 8
@topal.region-instance.namespace-metadata.literal.int.242 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 84] }, align 8
@topal.region-instance.namespace-metadata.literal.int.243 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3285] }, align 8
@topal.region-instance.namespace-metadata.literal.int.244 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 85] }, align 8
@topal.region-instance.namespace-metadata.literal.int.245 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3286] }, align 8
@topal.region-instance.namespace-metadata.literal.int.246 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 86] }, align 8
@topal.region-instance.namespace-metadata.literal.int.247 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3287] }, align 8
@topal.region-instance.namespace-metadata.literal.int.248 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 87] }, align 8
@topal.region-instance.namespace-metadata.literal.int.249 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3288] }, align 8
@topal.region-instance.namespace-metadata.literal.int.250 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.region-instance.namespace-metadata.literal.int.251 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3289] }, align 8
@topal.region-instance.namespace-metadata.literal.int.252 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 89] }, align 8
@topal.region-instance.namespace-metadata.literal.int.253 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3290] }, align 8
@topal.region-instance.namespace-metadata.literal.int.254 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 90] }, align 8
@topal.region-instance.namespace-metadata.literal.int.255 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3291] }, align 8
@topal.region-instance.namespace-metadata.literal.int.256 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 91] }, align 8
@topal.region-instance.namespace-metadata.literal.int.257 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3292] }, align 8
@topal.region-instance.namespace-metadata.literal.int.258 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 92] }, align 8
@topal.region-instance.namespace-metadata.literal.int.259 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3293] }, align 8
@topal.region-instance.namespace-metadata.literal.int.260 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 93] }, align 8
@topal.region-instance.namespace-metadata.literal.int.261 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3294] }, align 8
@topal.region-instance.namespace-metadata.literal.int.262 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 94] }, align 8
@topal.region-instance.namespace-metadata.literal.int.263 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3295] }, align 8
@topal.region-instance.namespace-metadata.literal.int.264 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 95] }, align 8
@topal.region-instance.namespace-metadata.literal.int.265 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3296] }, align 8
@topal.region-instance.namespace-metadata.literal.int.266 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 96] }, align 8
@topal.region-instance.namespace-metadata.literal.int.267 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3297] }, align 8
@topal.region-instance.namespace-metadata.literal.int.268 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 97] }, align 8
@topal.region-instance.namespace-metadata.literal.int.269 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3298] }, align 8
@topal.region-instance.namespace-metadata.literal.int.270 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 98] }, align 8
@topal.region-instance.namespace-metadata.literal.int.271 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3299] }, align 8
@topal.region-instance.namespace-metadata.literal.int.272 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 99] }, align 8
@topal.region-instance.namespace-metadata.literal.int.273 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3300] }, align 8
@topal.region-instance.namespace-metadata.literal.int.274 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 100] }, align 8
@topal.region-instance.namespace-metadata.literal.int.275 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3301] }, align 8
@topal.region-instance.namespace-metadata.literal.int.276 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 101] }, align 8
@topal.region-instance.namespace-metadata.literal.int.277 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3302] }, align 8
@topal.region-instance.namespace-metadata.literal.int.278 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 102] }, align 8
@topal.region-instance.namespace-metadata.literal.int.279 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3303] }, align 8
@topal.region-instance.namespace-metadata.literal.int.280 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 103] }, align 8
@topal.region-instance.namespace-metadata.literal.int.281 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3304] }, align 8
@topal.region-instance.namespace-metadata.literal.int.282 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 104] }, align 8
@topal.region-instance.namespace-metadata.literal.int.283 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3305] }, align 8
@topal.region-instance.namespace-metadata.literal.int.284 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 105] }, align 8
@topal.region-instance.namespace-metadata.literal.int.285 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3306] }, align 8
@topal.region-instance.namespace-metadata.literal.int.286 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 106] }, align 8
@topal.region-instance.namespace-metadata.literal.int.287 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3307] }, align 8
@topal.region-instance.namespace-metadata.literal.int.288 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 107] }, align 8
@topal.region-instance.namespace-metadata.literal.int.289 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3308] }, align 8
@topal.region-instance.namespace-metadata.literal.int.290 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 108] }, align 8
@topal.region-instance.namespace-metadata.literal.int.291 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3309] }, align 8
@topal.region-instance.namespace-metadata.literal.int.292 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 109] }, align 8
@topal.region-instance.namespace-metadata.literal.int.293 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3310] }, align 8
@topal.region-instance.namespace-metadata.literal.int.294 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 110] }, align 8
@topal.region-instance.namespace-metadata.literal.int.295 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3311] }, align 8
@topal.region-instance.namespace-metadata.literal.int.296 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 111] }, align 8
@topal.region-instance.namespace-metadata.literal.int.297 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3312] }, align 8
@topal.region-instance.namespace-metadata.literal.int.298 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 112] }, align 8
@topal.region-instance.namespace-metadata.literal.int.299 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3313] }, align 8
@topal.region-instance.namespace-metadata.literal.int.300 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 113] }, align 8
@topal.region-instance.namespace-metadata.literal.int.301 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3314] }, align 8
@topal.region-instance.namespace-metadata.literal.int.302 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 114] }, align 8
@topal.region-instance.namespace-metadata.literal.int.303 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3315] }, align 8
@topal.region-instance.namespace-metadata.literal.int.304 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 115] }, align 8
@topal.region-instance.namespace-metadata.literal.int.305 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3316] }, align 8
@topal.region-instance.namespace-metadata.literal.int.306 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 116] }, align 8
@topal.region-instance.namespace-metadata.literal.int.307 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3317] }, align 8
@topal.region-instance.namespace-metadata.literal.int.308 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 117] }, align 8
@topal.region-instance.namespace-metadata.literal.int.309 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3318] }, align 8
@topal.region-instance.namespace-metadata.literal.int.310 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 118] }, align 8
@topal.region-instance.namespace-metadata.literal.int.311 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3319] }, align 8
@topal.region-instance.namespace-metadata.literal.int.312 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 119] }, align 8
@topal.region-instance.namespace-metadata.literal.int.313 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3320] }, align 8
@topal.region-instance.namespace-metadata.literal.int.314 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 120] }, align 8
@topal.region-instance.namespace-metadata.literal.int.315 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3321] }, align 8
@topal.region-instance.namespace-metadata.literal.int.316 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 121] }, align 8
@topal.region-instance.namespace-metadata.literal.int.317 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3322] }, align 8
@topal.region-instance.namespace-metadata.literal.int.318 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 122] }, align 8
@topal.region-instance.namespace-metadata.literal.int.319 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3323] }, align 8
@topal.region-instance.namespace-metadata.literal.int.320 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 123] }, align 8
@topal.region-instance.namespace-metadata.literal.int.321 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3324] }, align 8
@topal.region-instance.namespace-metadata.literal.int.322 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 124] }, align 8
@topal.region-instance.namespace-metadata.literal.int.323 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3325] }, align 8
@topal.region-instance.namespace-metadata.literal.int.324 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 125] }, align 8
@topal.region-instance.namespace-metadata.literal.int.325 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3326] }, align 8
@topal.region-instance.namespace-metadata.literal.int.326 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 126] }, align 8
@topal.region-instance.namespace-metadata.literal.int.327 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3327] }, align 8
@topal.region-instance.namespace-metadata.literal.int.328 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 127] }, align 8
@topal.region-instance.namespace-metadata.literal.int.329 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3328] }, align 8
@topal.region-instance.namespace-metadata.literal.int.330 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.331 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3329] }, align 8
@topal.region-instance.namespace-metadata.literal.int.332 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 129] }, align 8
@topal.region-instance.namespace-metadata.literal.int.333 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3330] }, align 8
@topal.region-instance.namespace-metadata.literal.int.334 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 130] }, align 8
@topal.region-instance.namespace-metadata.literal.int.335 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3331] }, align 8
@topal.region-instance.namespace-metadata.literal.int.336 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 131] }, align 8
@topal.region-instance.namespace-metadata.literal.int.337 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3332] }, align 8
@topal.region-instance.namespace-metadata.literal.int.338 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 132] }, align 8
@topal.region-instance.namespace-metadata.literal.int.339 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3333] }, align 8
@topal.region-instance.namespace-metadata.literal.int.340 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 133] }, align 8
@topal.region-instance.namespace-metadata.literal.int.341 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3334] }, align 8
@topal.region-instance.namespace-metadata.literal.int.342 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 134] }, align 8
@topal.region-instance.namespace-metadata.literal.int.343 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3335] }, align 8
@topal.region-instance.namespace-metadata.literal.int.344 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 135] }, align 8
@topal.region-instance.namespace-metadata.literal.int.345 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3336] }, align 8
@topal.region-instance.namespace-metadata.literal.int.346 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 136] }, align 8
@topal.region-instance.namespace-metadata.literal.int.347 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3337] }, align 8
@topal.region-instance.namespace-metadata.literal.int.348 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 137] }, align 8
@topal.region-instance.namespace-metadata.literal.int.349 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3338] }, align 8
@topal.region-instance.namespace-metadata.literal.int.350 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 138] }, align 8
@topal.region-instance.namespace-metadata.literal.int.351 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3339] }, align 8
@topal.region-instance.namespace-metadata.literal.int.352 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 139] }, align 8
@topal.region-instance.namespace-metadata.literal.int.353 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3340] }, align 8
@topal.region-instance.namespace-metadata.literal.int.354 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 140] }, align 8
@topal.region-instance.namespace-metadata.literal.int.355 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3341] }, align 8
@topal.region-instance.namespace-metadata.literal.int.356 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 141] }, align 8
@topal.region-instance.namespace-metadata.literal.int.357 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3342] }, align 8
@topal.region-instance.namespace-metadata.literal.int.358 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 142] }, align 8
@topal.region-instance.namespace-metadata.literal.int.359 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3343] }, align 8
@topal.region-instance.namespace-metadata.literal.int.360 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 143] }, align 8
@topal.region-instance.namespace-metadata.literal.int.361 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3344] }, align 8
@topal.region-instance.namespace-metadata.literal.int.362 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 144] }, align 8
@topal.region-instance.namespace-metadata.literal.int.363 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3345] }, align 8
@topal.region-instance.namespace-metadata.literal.int.364 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 145] }, align 8
@topal.region-instance.namespace-metadata.literal.int.365 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3346] }, align 8
@topal.region-instance.namespace-metadata.literal.int.366 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 146] }, align 8
@topal.region-instance.namespace-metadata.literal.int.367 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3347] }, align 8
@topal.region-instance.namespace-metadata.literal.int.368 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 147] }, align 8
@topal.region-instance.namespace-metadata.literal.int.369 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3348] }, align 8
@topal.region-instance.namespace-metadata.literal.int.370 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 148] }, align 8
@topal.region-instance.namespace-metadata.literal.int.371 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3349] }, align 8
@topal.region-instance.namespace-metadata.literal.int.372 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 149] }, align 8
@topal.region-instance.namespace-metadata.literal.int.373 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3350] }, align 8
@topal.region-instance.namespace-metadata.literal.int.374 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 150] }, align 8
@topal.region-instance.namespace-metadata.literal.int.375 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3351] }, align 8
@topal.region-instance.namespace-metadata.literal.int.376 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 151] }, align 8
@topal.region-instance.namespace-metadata.literal.int.377 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3352] }, align 8
@topal.region-instance.namespace-metadata.literal.int.378 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 152] }, align 8
@topal.region-instance.namespace-metadata.literal.int.379 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3353] }, align 8
@topal.region-instance.namespace-metadata.literal.int.380 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 153] }, align 8
@topal.region-instance.namespace-metadata.literal.int.381 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3354] }, align 8
@topal.region-instance.namespace-metadata.literal.int.382 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 154] }, align 8
@topal.region-instance.namespace-metadata.literal.int.383 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3355] }, align 8
@topal.region-instance.namespace-metadata.literal.int.384 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 155] }, align 8
@topal.region-instance.namespace-metadata.literal.int.385 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3356] }, align 8
@topal.region-instance.namespace-metadata.literal.int.386 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 156] }, align 8
@topal.region-instance.namespace-metadata.literal.int.387 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3357] }, align 8
@topal.region-instance.namespace-metadata.literal.int.388 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 157] }, align 8
@topal.region-instance.namespace-metadata.literal.int.389 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3358] }, align 8
@topal.region-instance.namespace-metadata.literal.int.390 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 158] }, align 8
@topal.region-instance.namespace-metadata.literal.int.391 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3359] }, align 8
@topal.region-instance.namespace-metadata.literal.int.392 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 159] }, align 8
@topal.region-instance.namespace-metadata.literal.int.393 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3360] }, align 8
@topal.region-instance.namespace-metadata.literal.int.394 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 160] }, align 8
@topal.region-instance.namespace-metadata.literal.int.395 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3361] }, align 8
@topal.region-instance.namespace-metadata.literal.int.396 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 161] }, align 8
@topal.region-instance.namespace-metadata.literal.int.397 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3362] }, align 8
@topal.region-instance.namespace-metadata.literal.int.398 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 162] }, align 8
@topal.region-instance.namespace-metadata.literal.int.399 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3363] }, align 8
@topal.region-instance.namespace-metadata.literal.int.400 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 163] }, align 8
@topal.region-instance.namespace-metadata.literal.int.401 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3364] }, align 8
@topal.region-instance.namespace-metadata.literal.int.402 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 164] }, align 8
@topal.region-instance.namespace-metadata.literal.int.403 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3365] }, align 8
@topal.region-instance.namespace-metadata.literal.int.404 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 165] }, align 8
@topal.region-instance.namespace-metadata.literal.int.405 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3366] }, align 8
@topal.region-instance.namespace-metadata.literal.int.406 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 166] }, align 8
@topal.region-instance.namespace-metadata.literal.int.407 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3367] }, align 8
@topal.region-instance.namespace-metadata.literal.int.408 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 167] }, align 8
@topal.region-instance.namespace-metadata.literal.int.409 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3368] }, align 8
@topal.region-instance.namespace-metadata.literal.int.410 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 168] }, align 8
@topal.region-instance.namespace-metadata.literal.int.411 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3369] }, align 8
@topal.region-instance.namespace-metadata.literal.int.412 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 169] }, align 8
@topal.region-instance.namespace-metadata.literal.int.413 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3370] }, align 8
@topal.region-instance.namespace-metadata.literal.int.414 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 170] }, align 8
@topal.region-instance.namespace-metadata.literal.int.415 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3371] }, align 8
@topal.region-instance.namespace-metadata.literal.int.416 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 171] }, align 8
@topal.region-instance.namespace-metadata.literal.int.417 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3372] }, align 8
@topal.region-instance.namespace-metadata.literal.int.418 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 172] }, align 8
@topal.region-instance.namespace-metadata.literal.int.419 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3373] }, align 8
@topal.region-instance.namespace-metadata.literal.int.420 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 173] }, align 8
@topal.region-instance.namespace-metadata.literal.int.421 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3374] }, align 8
@topal.region-instance.namespace-metadata.literal.int.422 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 174] }, align 8
@topal.region-instance.namespace-metadata.literal.int.423 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3375] }, align 8
@topal.region-instance.namespace-metadata.literal.int.424 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 175] }, align 8
@topal.region-instance.namespace-metadata.literal.int.425 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3376] }, align 8
@topal.region-instance.namespace-metadata.literal.int.426 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 176] }, align 8
@topal.region-instance.namespace-metadata.literal.int.427 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3377] }, align 8
@topal.region-instance.namespace-metadata.literal.int.428 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 177] }, align 8
@topal.region-instance.namespace-metadata.literal.int.429 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3378] }, align 8
@topal.region-instance.namespace-metadata.literal.int.430 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 178] }, align 8
@topal.region-instance.namespace-metadata.literal.int.431 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3379] }, align 8
@topal.region-instance.namespace-metadata.literal.int.432 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 179] }, align 8
@topal.region-instance.namespace-metadata.literal.int.433 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3380] }, align 8
@topal.region-instance.namespace-metadata.literal.int.434 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 180] }, align 8
@topal.region-instance.namespace-metadata.literal.int.435 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3381] }, align 8
@topal.region-instance.namespace-metadata.literal.int.436 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 181] }, align 8
@topal.region-instance.namespace-metadata.literal.int.437 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3382] }, align 8
@topal.region-instance.namespace-metadata.literal.int.438 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 182] }, align 8
@topal.region-instance.namespace-metadata.literal.int.439 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3383] }, align 8
@topal.region-instance.namespace-metadata.literal.int.440 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 183] }, align 8
@topal.region-instance.namespace-metadata.literal.int.441 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3384] }, align 8
@topal.region-instance.namespace-metadata.literal.int.442 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 184] }, align 8
@topal.region-instance.namespace-metadata.literal.int.443 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3385] }, align 8
@topal.region-instance.namespace-metadata.literal.int.444 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 185] }, align 8
@topal.region-instance.namespace-metadata.literal.int.445 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3386] }, align 8
@topal.region-instance.namespace-metadata.literal.int.446 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 186] }, align 8
@topal.region-instance.namespace-metadata.literal.int.447 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3387] }, align 8
@topal.region-instance.namespace-metadata.literal.int.448 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 187] }, align 8
@topal.region-instance.namespace-metadata.literal.int.449 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3388] }, align 8
@topal.region-instance.namespace-metadata.literal.int.450 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 188] }, align 8
@topal.region-instance.namespace-metadata.literal.int.451 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3389] }, align 8
@topal.region-instance.namespace-metadata.literal.int.452 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 189] }, align 8
@topal.region-instance.namespace-metadata.literal.int.453 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3390] }, align 8
@topal.region-instance.namespace-metadata.literal.int.454 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 190] }, align 8
@topal.region-instance.namespace-metadata.literal.int.455 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3391] }, align 8
@topal.region-instance.namespace-metadata.literal.int.456 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 191] }, align 8
@topal.region-instance.namespace-metadata.literal.int.457 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3392] }, align 8
@topal.region-instance.namespace-metadata.literal.int.458 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 192] }, align 8
@topal.region-instance.namespace-metadata.literal.int.459 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3393] }, align 8
@topal.region-instance.namespace-metadata.literal.int.460 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 193] }, align 8
@topal.region-instance.namespace-metadata.literal.int.461 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3394] }, align 8
@topal.region-instance.namespace-metadata.literal.int.462 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 194] }, align 8
@topal.region-instance.namespace-metadata.literal.int.463 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3395] }, align 8
@topal.region-instance.namespace-metadata.literal.int.464 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 195] }, align 8
@topal.region-instance.namespace-metadata.literal.int.465 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3396] }, align 8
@topal.region-instance.namespace-metadata.literal.int.466 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 196] }, align 8
@topal.region-instance.namespace-metadata.literal.int.467 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3397] }, align 8
@topal.region-instance.namespace-metadata.literal.int.468 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 197] }, align 8
@topal.region-instance.namespace-metadata.literal.int.469 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3398] }, align 8
@topal.region-instance.namespace-metadata.literal.int.470 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 198] }, align 8
@topal.region-instance.namespace-metadata.literal.int.471 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3399] }, align 8
@topal.region-instance.namespace-metadata.literal.int.472 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 199] }, align 8
@topal.region-instance.namespace-metadata.literal.int.473 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3400] }, align 8
@topal.region-instance.namespace-metadata.literal.int.474 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.475 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3401] }, align 8
@topal.region-instance.namespace-metadata.literal.int.476 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 201] }, align 8
@topal.region-instance.namespace-metadata.literal.int.477 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3402] }, align 8
@topal.region-instance.namespace-metadata.literal.int.478 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 202] }, align 8
@topal.region-instance.namespace-metadata.literal.int.479 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3403] }, align 8
@topal.region-instance.namespace-metadata.literal.int.480 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 203] }, align 8
@topal.region-instance.namespace-metadata.literal.int.481 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3404] }, align 8
@topal.region-instance.namespace-metadata.literal.int.482 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 204] }, align 8
@topal.region-instance.namespace-metadata.literal.int.483 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3405] }, align 8
@topal.region-instance.namespace-metadata.literal.int.484 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 205] }, align 8
@topal.region-instance.namespace-metadata.literal.int.485 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3406] }, align 8
@topal.region-instance.namespace-metadata.literal.int.486 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 206] }, align 8
@topal.region-instance.namespace-metadata.literal.int.487 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3407] }, align 8
@topal.region-instance.namespace-metadata.literal.int.488 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 207] }, align 8
@topal.region-instance.namespace-metadata.literal.int.489 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3408] }, align 8
@topal.region-instance.namespace-metadata.literal.int.490 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 208] }, align 8
@topal.region-instance.namespace-metadata.literal.int.491 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3409] }, align 8
@topal.region-instance.namespace-metadata.literal.int.492 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 209] }, align 8
@topal.region-instance.namespace-metadata.literal.int.493 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3410] }, align 8
@topal.region-instance.namespace-metadata.literal.int.494 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 210] }, align 8
@topal.region-instance.namespace-metadata.literal.int.495 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3411] }, align 8
@topal.region-instance.namespace-metadata.literal.int.496 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 211] }, align 8
@topal.region-instance.namespace-metadata.literal.int.497 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3412] }, align 8
@topal.region-instance.namespace-metadata.literal.int.498 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 212] }, align 8
@topal.region-instance.namespace-metadata.literal.int.499 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3413] }, align 8
@topal.region-instance.namespace-metadata.literal.int.500 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 213] }, align 8
@topal.region-instance.namespace-metadata.literal.int.501 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3414] }, align 8
@topal.region-instance.namespace-metadata.literal.int.502 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 214] }, align 8
@topal.region-instance.namespace-metadata.literal.int.503 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3415] }, align 8
@topal.region-instance.namespace-metadata.literal.int.504 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 215] }, align 8
@topal.region-instance.namespace-metadata.literal.int.505 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3416] }, align 8
@topal.region-instance.namespace-metadata.literal.int.506 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 216] }, align 8
@topal.region-instance.namespace-metadata.literal.int.507 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3417] }, align 8
@topal.region-instance.namespace-metadata.literal.int.508 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 217] }, align 8
@topal.region-instance.namespace-metadata.literal.int.509 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3418] }, align 8
@topal.region-instance.namespace-metadata.literal.int.510 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 218] }, align 8
@topal.region-instance.namespace-metadata.literal.int.511 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3419] }, align 8
@topal.region-instance.namespace-metadata.literal.int.512 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 219] }, align 8
@topal.region-instance.namespace-metadata.literal.int.513 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3420] }, align 8
@topal.region-instance.namespace-metadata.literal.int.514 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 220] }, align 8
@topal.region-instance.namespace-metadata.literal.int.515 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3421] }, align 8
@topal.region-instance.namespace-metadata.literal.int.516 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 221] }, align 8
@topal.region-instance.namespace-metadata.literal.int.517 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3422] }, align 8
@topal.region-instance.namespace-metadata.literal.int.518 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 222] }, align 8
@topal.region-instance.namespace-metadata.literal.int.519 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3423] }, align 8
@topal.region-instance.namespace-metadata.literal.int.520 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 223] }, align 8
@topal.region-instance.namespace-metadata.literal.int.521 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3424] }, align 8
@topal.region-instance.namespace-metadata.literal.int.522 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 224] }, align 8
@topal.region-instance.namespace-metadata.literal.int.523 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3425] }, align 8
@topal.region-instance.namespace-metadata.literal.int.524 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 225] }, align 8
@topal.region-instance.namespace-metadata.literal.int.525 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3426] }, align 8
@topal.region-instance.namespace-metadata.literal.int.526 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 226] }, align 8
@topal.region-instance.namespace-metadata.literal.int.527 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3427] }, align 8
@topal.region-instance.namespace-metadata.literal.int.528 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 227] }, align 8
@topal.region-instance.namespace-metadata.literal.int.529 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3428] }, align 8
@topal.region-instance.namespace-metadata.literal.int.530 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 228] }, align 8
@topal.region-instance.namespace-metadata.literal.int.531 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3429] }, align 8
@topal.region-instance.namespace-metadata.literal.int.532 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 229] }, align 8
@topal.region-instance.namespace-metadata.literal.int.533 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3430] }, align 8
@topal.region-instance.namespace-metadata.literal.int.534 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 230] }, align 8
@topal.region-instance.namespace-metadata.literal.int.535 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3431] }, align 8
@topal.region-instance.namespace-metadata.literal.int.536 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 231] }, align 8
@topal.region-instance.namespace-metadata.literal.int.537 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3432] }, align 8
@topal.region-instance.namespace-metadata.literal.int.538 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 232] }, align 8
@topal.region-instance.namespace-metadata.literal.int.539 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3433] }, align 8
@topal.region-instance.namespace-metadata.literal.int.540 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 233] }, align 8
@topal.region-instance.namespace-metadata.literal.int.541 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3434] }, align 8
@topal.region-instance.namespace-metadata.literal.int.542 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 234] }, align 8
@topal.region-instance.namespace-metadata.literal.int.543 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3435] }, align 8
@topal.region-instance.namespace-metadata.literal.int.544 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 235] }, align 8
@topal.region-instance.namespace-metadata.literal.int.545 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3436] }, align 8
@topal.region-instance.namespace-metadata.literal.int.546 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 236] }, align 8
@topal.region-instance.namespace-metadata.literal.int.547 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3437] }, align 8
@topal.region-instance.namespace-metadata.literal.int.548 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 237] }, align 8
@topal.region-instance.namespace-metadata.literal.int.549 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3438] }, align 8
@topal.region-instance.namespace-metadata.literal.int.550 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 238] }, align 8
@topal.region-instance.namespace-metadata.literal.int.551 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3439] }, align 8
@topal.region-instance.namespace-metadata.literal.int.552 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 239] }, align 8
@topal.region-instance.namespace-metadata.literal.int.553 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3440] }, align 8
@topal.region-instance.namespace-metadata.literal.int.554 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 240] }, align 8
@topal.region-instance.namespace-metadata.literal.int.555 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3441] }, align 8
@topal.region-instance.namespace-metadata.literal.int.556 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 241] }, align 8
@topal.region-instance.namespace-metadata.literal.int.557 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3442] }, align 8
@topal.region-instance.namespace-metadata.literal.int.558 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 242] }, align 8
@topal.region-instance.namespace-metadata.literal.int.559 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3443] }, align 8
@topal.region-instance.namespace-metadata.literal.int.560 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 243] }, align 8
@topal.region-instance.namespace-metadata.literal.int.561 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3444] }, align 8
@topal.region-instance.namespace-metadata.literal.int.562 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 244] }, align 8
@topal.region-instance.namespace-metadata.literal.int.563 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3445] }, align 8
@topal.region-instance.namespace-metadata.literal.int.564 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 245] }, align 8
@topal.region-instance.namespace-metadata.literal.int.565 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3446] }, align 8
@topal.region-instance.namespace-metadata.literal.int.566 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 246] }, align 8
@topal.region-instance.namespace-metadata.literal.int.567 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3447] }, align 8
@topal.region-instance.namespace-metadata.literal.int.568 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 247] }, align 8
@topal.region-instance.namespace-metadata.literal.int.569 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3448] }, align 8
@topal.region-instance.namespace-metadata.literal.int.570 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 248] }, align 8
@topal.region-instance.namespace-metadata.literal.int.571 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3449] }, align 8
@topal.region-instance.namespace-metadata.literal.int.572 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 249] }, align 8
@topal.region-instance.namespace-metadata.literal.int.573 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3450] }, align 8
@topal.region-instance.namespace-metadata.literal.int.574 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 250] }, align 8
@topal.region-instance.namespace-metadata.literal.int.575 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3451] }, align 8
@topal.region-instance.namespace-metadata.literal.int.576 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 251] }, align 8
@topal.region-instance.namespace-metadata.literal.int.577 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3452] }, align 8
@topal.region-instance.namespace-metadata.literal.int.578 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 252] }, align 8
@topal.region-instance.namespace-metadata.literal.int.579 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3453] }, align 8
@topal.region-instance.namespace-metadata.literal.int.580 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 253] }, align 8
@topal.region-instance.namespace-metadata.literal.int.581 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3454] }, align 8
@topal.region-instance.namespace-metadata.literal.int.582 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 254] }, align 8
@topal.region-instance.namespace-metadata.literal.int.583 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3455] }, align 8
@topal.region-instance.namespace-metadata.literal.int.584 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.585 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.586 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.587 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3136] }, align 8
@topal.region-instance.namespace-metadata.literal.int.588 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3456] }, align 8
@topal.region-instance.namespace-metadata.literal.int.589 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.590 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.591 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.592 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.593 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.594 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.595 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.596 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.597 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.598 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.599 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.600 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.601 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.602 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.603 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.604 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.605 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.606 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.607 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.608 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.609 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.610 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.611 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.612 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.613 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.614 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.615 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.616 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.617 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.618 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 1, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.619 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.620 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.621 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.622 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.623 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.624 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.625 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.626 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.627 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.628 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.629 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.region-instance.namespace-metadata.literal.int.630 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.631 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3072] }, align 8
@topal.region-instance.namespace-metadata.literal.int.632 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3080] }, align 8
@topal.region-instance.namespace-metadata.literal.int.633 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3088] }, align 8
@topal.region-instance.namespace-metadata.literal.int.634 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3096] }, align 8
@topal.region-instance.namespace-metadata.literal.int.635 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3104] }, align 8
@topal.region-instance.namespace-metadata.literal.int.636 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3112] }, align 8
@topal.region-instance.namespace-metadata.literal.int.637 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3120] }, align 8
@topal.region-instance.namespace-metadata.literal.int.638 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.639 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4096] }, align 8
@topal.region-instance.namespace-metadata.literal.int.640 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.region-instance.namespace-metadata.literal.int.641 = internal unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 -1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.642 = internal unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 -1] }, align 8

; Function Attrs: noimplicitfloat noinline noredzone nounwind optnone
define internal ptr @topal.region-instance.namespace-metadata.memset(ptr %destination, i32 %value, i64 %length) #0 {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill

fill:                                             ; preds = %fill, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill

complete:                                         ; preds = %fill, %entry
  ret ptr %destination
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %payload) #1 {
entry:
  %optional = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.optional.none() #1 {
entry:
  %optional = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %optional) #1 {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid

checked:                                          ; preds = %entry
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some

invalid:                                          ; preds = %entry
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 70)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %optional) #1 {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 %negative) #1 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %source) #1 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %value, i64 %index) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero

load:                                             ; preds = %entry
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended

zero:                                             ; preds = %entry
  ret i64 0
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %value) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim

trim:                                             ; preds = %leading.zero, %entry
  %candidate = phi i64 [ %length, %entry ], [ %next, %leading.zero ]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done

leading.zero:                                     ; preds = %trim
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim

zero:                                             ; preds = %leading.zero, %entry
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value

done:                                             ; preds = %trim
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %value, i64 %negative) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate

zero:                                             ; preds = %entry
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero

allocate:                                         ; preds = %entry
  %copy = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %allocate
  %index = phi i64 [ 0, %allocate ], [ %next, %loop ]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  ret ptr %copy
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %value) #1 {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite

infinite:                                         ; preds = %entry
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.positive.infinity

finite:                                           ; preds = %entry
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy

same:                                             ; preds = %finite
  ret ptr %value

copy:                                             ; preds = %finite
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.region-instance.namespace-metadata.runtime.int.compare.absolute(ptr %left, ptr %right) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer

check.longer:                                     ; preds = %entry
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty

check.empty:                                      ; preds = %check.longer
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs

limbs:                                            ; preds = %limbs.equal, %check.empty
  %position = phi i64 [ %left.length, %check.empty ], [ %index, %limbs.equal ]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater

check.limb.greater:                               ; preds = %limbs
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal

limbs.equal:                                      ; preds = %check.limb.greater
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal

less:                                             ; preds = %limbs, %entry
  ret i32 -1

equal:                                            ; preds = %limbs.equal, %check.empty
  ret i32 0

greater:                                          ; preds = %check.limb.greater, %check.longer
  ret i32 1
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity

left.positive:                                    ; preds = %entry
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result

check.left.negative.infinity:                     ; preds = %entry
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity

left.negative:                                    ; preds = %check.left.negative.infinity
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result

check.right.positive.infinity:                    ; preds = %check.left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity

check.right.negative.infinity:                    ; preds = %check.right.positive.infinity
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite

less:                                             ; preds = %check.right.positive.infinity
  ret i32 -1

greater:                                          ; preds = %check.right.negative.infinity
  ret i32 1

finite:                                           ; preds = %check.right.negative.infinity
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute

signed.result:                                    ; preds = %finite
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result

absolute:                                         ; preds = %finite
  %magnitude = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %left.limb = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish

finish:                                           ; preds = %loop, %entry
  %final.carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry

store.carry:                                      ; preds = %finish
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result

without.carry:                                    ; preds = %finish
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %borrow = phi i64 [ 0, %entry ], [ %next.borrow, %loop ]
  %left = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  %normalized = call ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity

validate.left.infinity:                           ; preds = %entry
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity

indeterminate.infinity:                           ; preds = %validate.left.infinity
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 70)
  unreachable

return.left.infinity:                             ; preds = %validate.left.infinity
  ret ptr %left

check.right.infinity:                             ; preds = %entry
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite

return.right.infinity:                            ; preds = %check.right.infinity
  ret ptr %right

finite:                                           ; preds = %check.right.infinity
  %left.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right

return.right:                                     ; preds = %finite
  ret ptr %right

check.right:                                      ; preds = %finite
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero

return.left:                                      ; preds = %check.right
  ret ptr %left

nonzero:                                          ; preds = %check.right
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference

sum:                                              ; preds = %nonzero
  %sum.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value

difference:                                       ; preds = %nonzero
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger

zero:                                             ; preds = %difference
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero

select.larger:                                    ; preds = %difference
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference

left.difference:                                  ; preds = %select.larger
  %left.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value

right.difference:                                 ; preds = %select.larger
  %right.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite

infinite:                                         ; preds = %entry
  %left.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity

indeterminate.infinity:                           ; preds = %infinite
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 70)
  unreachable

select.infinity:                                  ; preds = %infinite
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.region-instance.namespace-metadata.runtime.int.negative.infinity, ptr @topal.region-instance.namespace-metadata.runtime.int.positive.infinity
  ret ptr %infinity

finite:                                           ; preds = %entry
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length

zero:                                             ; preds = %finite
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero

check.length:                                     ; preds = %finite
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate

failure:                                          ; preds = %check.length
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable

allocate:                                         ; preds = %check.length
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear

clear:                                            ; preds = %clear, %allocate
  %clear.index = phi i64 [ 0, %allocate ], [ %clear.next, %clear ]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry

outer.entry:                                      ; preds = %clear
  br label %outer

outer:                                            ; preds = %outer.done, %outer.entry
  %left.index = phi i64 [ 0, %outer.entry ], [ %left.next, %outer.done ]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner

inner:                                            ; preds = %inner, %outer
  %right.index = phi i64 [ 0, %outer ], [ %right.next, %inner ]
  %carry = phi i64 [ 0, %outer ], [ %next.carry, %inner ]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done

outer.done:                                       ; preds = %inner
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done

done:                                             ; preds = %outer.done
  %normalized = call ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %value) #1 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

declare ptr @topal_kernel_region_frame_namespace_metadata_allocate_v1(i64)

; Function Attrs: noreturn
declare void @topal_kernel_region_frame_namespace_metadata_abort_v1() #2

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %length) #1 {
entry:
  %pointer = call ptr @topal_kernel_region_frame_namespace_metadata_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.region-instance.namespace-metadata.platform.exit(i64 %status) #3 {
entry:
  call void @topal_kernel_region_frame_namespace_metadata_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.region-instance.namespace-metadata.primitive.abort() #3 {
entry:
  call void @topal_kernel_region_frame_namespace_metadata_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view) #1 {
entry:
  %address = ptrtoint ptr %view to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %valid.pointer = and i1 %nonnull, %aligned
  br i1 %valid.pointer, label %view.fields, label %invalid

view.fields:                                      ; preds = %entry
  %control = load ptr, ptr %view, align 8
  %control.address = ptrtoint ptr %control to i64
  %control.nonnull = icmp ne i64 %control.address, 0
  %control.alignment = and i64 %control.address, 7
  %control.aligned = icmp eq i64 %control.alignment, 0
  %control.valid = and i1 %control.nonnull, %control.aligned
  br i1 %control.valid, label %control.fields, label %invalid

control.fields:                                   ; preds = %view.fields
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %view.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %view.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %view.epoch.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 4
  %view.owner.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 5
  %view.code.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 6
  %view.zero.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 7
  %offset = load i64, ptr %offset.pointer, align 8
  %view.count = load i64, ptr %view.count.pointer, align 8
  %view.rights = load i64, ptr %view.rights.pointer, align 8
  %view.epoch = load i64, ptr %view.epoch.pointer, align 8
  %view.owner = load i64, ptr %view.owner.pointer, align 8
  %view.code = load ptr, ptr %view.code.pointer, align 8
  %view.zero = load i64, ptr %view.zero.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_namespace_metadata_apply_v1
  %view.code.valid = icmp eq ptr %view.code, %code
  %owner.valid = icmp ne i64 %owner, 0
  %view.owner.valid = icmp eq i64 %view.owner, %owner
  %epoch.valid = icmp ne i64 %epoch, 0
  %view.epoch.valid = icmp eq i64 %view.epoch, %epoch
  %active.valid = icmp eq i64 %active, 1
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %view.rights.valid = icmp ule i64 %view.rights, %rights
  %zero.valid = icmp eq i64 %view.zero, 0
  %offset.valid = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %view.count.valid = icmp ule i64 %view.count, %remaining
  %base.address = ptrtoint ptr %base to i64
  %base.nonnull = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %issued.positive = icmp uge i64 %issued, 1
  %issued.bounded = icmp ule i64 %issued, 256
  %issued.valid = and i1 %issued.positive, %issued.bounded
  %a = and i1 %code.valid, %view.code.valid
  %b = and i1 %owner.valid, %view.owner.valid
  %c = and i1 %epoch.valid, %view.epoch.valid
  %d = and i1 %active.valid, %count.valid
  %e = and i1 %rights.valid, %view.rights.valid
  %f = and i1 %zero.valid, %offset.valid
  %g = and i1 %view.count.valid, %base.nonnull
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %ef = and i1 %e, %f
  %g.end = and i1 %g, %end.valid
  %abcd = and i1 %ab, %cd
  %efgh = and i1 %ef, %g.end
  %all.fields = and i1 %abcd, %efgh
  %valid = and i1 %all.fields, %issued.valid
  br i1 %valid, label %success, label %invalid

success:                                          ; preds = %control.fields
  %bytes = getelementptr i8, ptr %base, i64 %offset
  ret ptr %bytes

invalid:                                          ; preds = %control.fields, %view.fields, %entry
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %number) #1 {
entry:
  %sign = load i64, ptr %number, align 8
  %nonnegative = icmp eq i64 %sign, 0
  br i1 %nonnegative, label %number.length, label %invalid

number.length:                                    ; preds = %entry
  %length.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %zero.result, label %bounded

zero.result:                                      ; preds = %number.length
  ret { i1, i64 } { i1 true, i64 0 }

bounded:                                          ; preds = %number.length
  %fits = icmp ule i64 %length, 2
  br i1 %fits, label %low, label %refuse

low:                                              ; preds = %bounded
  %low.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 0
  %low.word = load i32, ptr %low.pointer, align 4
  %low.value = zext i32 %low.word to i64
  %single = icmp eq i64 %length, 1
  br i1 %single, label %single.result, label %high

single.result:                                    ; preds = %low
  %one = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %low.value, 1
  ret { i1, i64 } %one

high:                                             ; preds = %low
  %high.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 1
  %high.word = load i32, ptr %high.pointer, align 4
  %high.value = zext i32 %high.word to i64
  %shifted = shl i64 %high.value, 32
  %value = or i64 %shifted, %low.value
  %two = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %value, 1
  ret { i1, i64 } %two

refuse:                                           ; preds = %bounded
  ret { i1, i64 } zeroinitializer

invalid:                                          ; preds = %entry
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.primitive.count(ptr %view) #1 {
entry:
  %bytes = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %number = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %count)
  ret ptr %number
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal { i1, ptr } @topal.region-instance.namespace-metadata.primitive.unsigned.span(ptr %view, ptr %index, i64 %width) #1 {
entry:
  %bytes = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  %positive = icmp uge i64 %width, 1
  %bounded = icmp ule i64 %width, 8
  %format.valid = and i1 %positive, %bounded
  br i1 %format.valid, label %decode, label %invalid

decode:                                           ; preds = %entry
  %decoded = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %starts = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %ends = icmp ule i64 %width, %remaining
  %contained = and i1 %starts, %ends
  %valid = and i1 %fits, %contained
  br i1 %valid, label %success, label %refuse

success:                                          ; preds = %decode
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %result = insertvalue { i1, ptr } { i1 true, ptr null }, ptr %pointer, 1
  ret { i1, ptr } %result

refuse:                                           ; preds = %decode
  ret { i1, ptr } zeroinitializer

invalid:                                          ; preds = %entry
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %view, ptr %index, i64 %width, i1 %big) #1 {
entry:
  %checked = call { i1, ptr } @topal.region-instance.namespace-metadata.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %valid, label %loop, label %refuse

loop:                                             ; preds = %loop, %entry
  %index.byte = phi i64 [ 0, %entry ], [ %next, %loop ]
  %value = phi i64 [ 0, %entry ], [ %merged, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  %byte = load i8, ptr %pointer, align 1
  %extended = zext i8 %byte to i64
  %part = shl i64 %extended, %shift
  %merged = or i64 %value, %part
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop

result:                                           ; preds = %loop
  %number = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %merged)
  %some = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %number)
  ret ptr %some

refuse:                                           ; preds = %entry
  %none = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %view, ptr %index, ptr %number, i64 %width, i1 %big) #1 {
entry:
  %checked = call { i1, ptr } @topal.region-instance.namespace-metadata.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %span.valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %span.valid, label %value.check, label %refuse

value.check:                                      ; preds = %entry
  %decoded = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %number)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %value = extractvalue { i1, i64 } %decoded, 1
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %rights = load i64, ptr %rights.pointer, align 8
  %writable = icmp eq i64 %rights, 1
  %bits = mul i64 %width, 8
  %unused = sub i64 64, %bits
  %mask = lshr i64 -1, %unused
  %outside.mask = xor i64 %mask, -1
  %outside = and i64 %value, %outside.mask
  %value.valid = icmp eq i64 %outside, 0
  %range = and i1 %fits, %value.valid
  %valid = and i1 %range, %writable
  br i1 %valid, label %loop, label %refuse

loop:                                             ; preds = %loop, %value.check
  %index.byte = phi i64 [ 0, %value.check ], [ %next, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %part = lshr i64 %value, %shift
  %byte = trunc i64 %part to i8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  store i8 %byte, ptr %pointer, align 1
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop

result:                                           ; preds = %loop
  ret i1 true

refuse:                                           ; preds = %value.check, %entry
  ret i1 false
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %arg0, i1 %arg1) #1 !dbg !6 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !11, !DIExpression(), !12)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !13, !DIExpression(), !14)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !15

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !16

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !17

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v2 = phi i1 [ %arg1, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !15
  ret i1 %v2, !dbg !15
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3) #1 !dbg !18 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !21, !DIExpression(), !22)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !23, !DIExpression(), !24)
  %v2 = alloca i1, align 1
  store i1 %arg2, ptr %v2, align 1
    #dbg_declare(ptr %v2, !25, !DIExpression(), !26)
  %v3 = alloca i1, align 1
  store i1 %arg3, ptr %v3, align 1
    #dbg_declare(ptr %v3, !27, !DIExpression(), !28)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %arg0, i1 %arg1), !dbg !29
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %arg2, i1 %arg3), !dbg !30
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v4, i1 %v5), !dbg !31
  ret i1 %v6, !dbg !31
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4(ptr %arg0, ptr %arg1) #1 !dbg !32 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !46, !DIExpression(), !47)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !48, !DIExpression(), !49)
  %v2 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %arg1, i64 8, i1 false), !dbg !50
  %v3 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v2), !dbg !50
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !50

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v2), !dbg !51
    #dbg_value(ptr %v4, !52, !DIExpression(), !51)
  br label %optional.decision.merge.2, !dbg !53

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !54

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v5 = phi ptr [ %v4, %optional.decision.some.0 ], [ @topal.region-instance.namespace-metadata.literal.int.0, %optional.decision.none.1 ], !dbg !50
  ret ptr %v5, !dbg !50
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %arg1) #1 !dbg !55 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !56, !DIExpression(), !57)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !58, !DIExpression(), !59)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4(ptr %arg0, ptr %arg1), !dbg !60
  ret ptr %v2, !dbg !60
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eindex_2dshape.36({ ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, ptr %arg1) #1 !dbg !61 {
entry:
  %v0 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 0, !dbg !74
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 1, !dbg !74
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 2, !dbg !74
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 3, !dbg !74
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 4, !dbg !74
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 5, !dbg !74
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 6, !dbg !74
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 7, !dbg !74
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 8, !dbg !74
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 9, !dbg !74
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 10, !dbg !74
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 11, !dbg !74
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 12, !dbg !74
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 13, !dbg !74
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 14, !dbg !74
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 15, !dbg !74
  %v16 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, ptr %v16, align 8
    #dbg_declare(ptr %v16, !75, !DIExpression(), !74)
  %v17 = alloca ptr, align 8
  store ptr %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !76, !DIExpression(), !77)
  %v18 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.1), !dbg !78
  %v19 = icmp sle i32 %v18, 0, !dbg !78
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v7, ptr @topal.region-instance.namespace-metadata.literal.int.2), !dbg !79
  %v21 = icmp eq i32 %v20, 0, !dbg !79
  %v22 = icmp eq i1 %v21, true, !dbg !79
  %v23 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr @topal.region-instance.namespace-metadata.literal.int.3), !dbg !80
  %v24 = icmp eq i32 %v23, 0, !dbg !80
  %v25 = icmp eq i1 %v24, true, !dbg !80
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v25), !dbg !81
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v19, i1 %v26), !dbg !82
    #dbg_value(i1 %v27, !83, !DIExpression(), !84)
  %v28 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v7, ptr @topal.region-instance.namespace-metadata.literal.int.4), !dbg !85
  %v29 = icmp slt i32 %v28, 0, !dbg !85
  %v30 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v7, ptr %v4), !dbg !86
  %v31 = icmp eq i32 %v30, 0, !dbg !86
  %v32 = icmp ne i1 %v31, true, !dbg !86
  %v33 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr @topal.region-instance.namespace-metadata.literal.int.5), !dbg !87
  %v34 = icmp sge i32 %v33, 0, !dbg !87
  %v35 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %v2), !dbg !88
  %v36 = icmp eq i32 %v35, 0, !dbg !88
  %v37 = icmp ne i1 %v36, true, !dbg !88
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v29, i1 %v32, i1 %v34, i1 %v37), !dbg !89
    #dbg_value(i1 %v38, !90, !DIExpression(), !91)
  %v39 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.6), !dbg !92
  %v40 = icmp sge i32 %v39, 0, !dbg !92
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v40, i1 %v38), !dbg !93
    #dbg_value(i1 %v41, !94, !DIExpression(), !95)
  %v42 = xor i1 %v27, true, !dbg !96
  %v43 = xor i1 %v41, true, !dbg !97
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v42, i1 %v43), !dbg !98
  %v45 = xor i1 %v44, true, !dbg !99
    #dbg_value(i1 %v45, !100, !DIExpression(), !101)
  %v46 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.7), !dbg !102
  %v47 = icmp slt i32 %v46, 0, !dbg !102
  %v48 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v1, ptr @topal.region-instance.namespace-metadata.literal.int.8), !dbg !103
  %v49 = icmp sle i32 %v48, 0, !dbg !103
  %v50 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.9), !dbg !104
  %v51 = icmp sge i32 %v50, 0, !dbg !104
  %v52 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.10), !dbg !105
  %v53 = icmp sle i32 %v52, 0, !dbg !105
  %v54 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v47, i1 %v49, i1 %v51, i1 %v53), !dbg !106
    #dbg_value(i1 %v54, !107, !DIExpression(), !108)
  %v55 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.11), !dbg !109
  %v56 = icmp slt i32 %v55, 0, !dbg !109
  %v57 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.12), !dbg !110
  %v58 = icmp sle i32 %v57, 0, !dbg !110
  %v59 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v54, i1 %v45, i1 %v56, i1 %v58), !dbg !111
  ret i1 %v59, !dbg !111
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %arg0) #1 !dbg !112 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !115, !DIExpression(), !116)
  %v1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.14), !dbg !117
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.13, ptr %v1), !dbg !118
  ret ptr %v2, !dbg !118
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !119 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !122, !DIExpression(), !123)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !124, !DIExpression(), !125)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !126, !DIExpression(), !127)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %arg1), !dbg !128
  %v4 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr %arg2), !dbg !128
  %v5 = icmp eq i32 %v4, 0, !dbg !128
  %v6 = icmp eq i1 %v5, true, !dbg !128
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !128

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !129

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !130

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi ptr [ @topal.region-instance.namespace-metadata.literal.int.15, %decision.true.0 ], [ @topal.region-instance.namespace-metadata.literal.int.16, %decision.false.1 ], !dbg !128
  ret ptr %v7, !dbg !128
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59(ptr %arg0, ptr %arg1) #1 !dbg !131 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !132, !DIExpression(), !133)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !134, !DIExpression(), !135)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.17, ptr %arg1), !dbg !136
    #dbg_value(ptr %v2, !137, !DIExpression(), !138)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.18, ptr %arg1), !dbg !139
    #dbg_value(ptr %v3, !140, !DIExpression(), !141)
  %v4 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.19, ptr %arg1), !dbg !142
    #dbg_value(ptr %v4, !143, !DIExpression(), !144)
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.20, ptr %arg1), !dbg !145
    #dbg_value(ptr %v5, !146, !DIExpression(), !147)
  %v6 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v2, ptr %v3), !dbg !148
  %v7 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v6, ptr %v4), !dbg !148
  %v8 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v7, ptr %v5), !dbg !148
  ret ptr %v8, !dbg !148
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !149 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !152, !DIExpression(), !153)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !154, !DIExpression(), !155)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !156, !DIExpression(), !157)
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.21), !dbg !158
  %v4 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v3), !dbg !159
    #dbg_value(ptr %v4, !160, !DIExpression(), !161)
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %arg1), !dbg !162
  %v6 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.22), !dbg !162
  %v7 = icmp eq i32 %v6, 0, !dbg !162
  %v8 = icmp eq i1 %v7, true, !dbg !162
  %v9 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.23), !dbg !163
  %v10 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v9), !dbg !164
  %v11 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v10, ptr %arg2), !dbg !164
  %v12 = icmp eq i32 %v11, 0, !dbg !164
  %v13 = icmp eq i1 %v12, true, !dbg !164
  %v14 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.24), !dbg !165
  %v15 = icmp sge i32 %v14, 0, !dbg !165
  %v16 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.25), !dbg !166
  %v17 = icmp sle i32 %v16, 0, !dbg !166
  %v18 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v8, i1 %v13, i1 %v15, i1 %v17), !dbg !167
  ret i1 %v18, !dbg !167
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %arg0) #1 !dbg !168 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !169, !DIExpression(), !170)
  %v1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.27), !dbg !171
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.26, ptr %v1), !dbg !172
  ret ptr %v2, !dbg !172
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !173 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !174, !DIExpression(), !175)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !176, !DIExpression(), !177)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !178, !DIExpression(), !179)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %arg1), !dbg !180
    #dbg_value(ptr %v3, !181, !DIExpression(), !182)
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.28), !dbg !183
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v4), !dbg !184
    #dbg_value(ptr %v5, !185, !DIExpression(), !186)
  %v6 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v3), !dbg !187
  %v7 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %arg2), !dbg !187
  %v8 = icmp eq i32 %v7, 0, !dbg !187
  %v9 = icmp eq i1 %v8, true, !dbg !187
  %v10 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.29), !dbg !188
  %v11 = icmp sgt i32 %v10, 0, !dbg !188
  %v12 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.30), !dbg !189
  %v13 = icmp sle i32 %v12, 0, !dbg !189
  %v14 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.31), !dbg !190
  %v15 = icmp sge i32 %v14, 0, !dbg !190
  %v16 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v9, i1 %v11, i1 %v13, i1 %v15), !dbg !191
  ret i1 %v16, !dbg !191
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dentry_2dvalid.96(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !192 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !195, !DIExpression(), !196)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !197
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !197
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !197
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !197
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !197
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !197
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !197
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !197
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !197
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !197
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !197
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !197
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !197
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !197
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !197
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !197
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !198, !DIExpression(), !197)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !199, !DIExpression(), !200)
  %v19 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.32), !dbg !201
  %v20 = icmp slt i32 %v19, 0, !dbg !201
  br i1 %v20, label %decision.true.0, label %decision.false.1, !dbg !201

decision.true.0:                                  ; preds = %entry
  %v21 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94(ptr %arg0, ptr %v2, ptr %v3), !dbg !202
  br label %decision.merge.2, !dbg !202

decision.false.1:                                 ; preds = %entry
  %v22 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.33), !dbg !203
  %v23 = icmp eq i32 %v22, 0, !dbg !203
  %v24 = icmp eq i1 %v23, true, !dbg !203
  %v25 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.34), !dbg !204
  %v26 = icmp eq i32 %v25, 0, !dbg !204
  %v27 = icmp eq i1 %v26, true, !dbg !204
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v24, i1 %v27), !dbg !205
  br label %decision.merge.2, !dbg !205

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v29 = phi i1 [ %v21, %decision.true.0 ], [ %v28, %decision.false.1 ], !dbg !201
  ret i1 %v29, !dbg !201
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dvalid.98(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !206 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !207, !DIExpression(), !208)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !209
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !209
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !209
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !209
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !209
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !209
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !209
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !209
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !209
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !209
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !209
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !209
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !209
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !209
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !209
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !209
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !210, !DIExpression(), !209)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !211, !DIExpression(), !212)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !213
    #dbg_value(ptr %v19, !214, !DIExpression(), !215)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59(ptr %arg0, ptr %v3), !dbg !216
    #dbg_value(ptr %v20, !217, !DIExpression(), !218)
  %v21 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.35), !dbg !219
  %v22 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v21), !dbg !220
    #dbg_value(ptr %v22, !221, !DIExpression(), !222)
  %v23 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.36), !dbg !223
  %v24 = icmp eq i32 %v23, 0, !dbg !223
  %v25 = icmp eq i1 %v24, true, !dbg !223
  %v26 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.37), !dbg !224
  %v27 = icmp eq i32 %v26, 0, !dbg !224
  %v28 = icmp eq i1 %v27, true, !dbg !224
  %v29 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v22, ptr @topal.region-instance.namespace-metadata.literal.int.38), !dbg !225
  %v30 = icmp eq i32 %v29, 0, !dbg !225
  %v31 = icmp eq i1 %v30, true, !dbg !225
  %v32 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.39), !dbg !226
  %v33 = icmp eq i32 %v32, 0, !dbg !226
  %v34 = icmp eq i1 %v33, true, !dbg !226
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v25, i1 %v28, i1 %v31, i1 %v34), !dbg !227
    #dbg_value(i1 %v35, !228, !DIExpression(), !229)
  %v36 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.40), !dbg !230
  %v37 = icmp sgt i32 %v36, 0, !dbg !230
  %v38 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v22, ptr @topal.region-instance.namespace-metadata.literal.int.41), !dbg !231
  %v39 = icmp eq i32 %v38, 0, !dbg !231
  %v40 = icmp eq i1 %v39, true, !dbg !231
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v37, i1 %v40), !dbg !232
    #dbg_value(i1 %v41, !233, !DIExpression(), !234)
  %v42 = xor i1 %v35, true, !dbg !235
  %v43 = xor i1 %v41, true, !dbg !236
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v42, i1 %v43), !dbg !237
  %v45 = xor i1 %v44, true, !dbg !238
    #dbg_value(i1 %v45, !239, !DIExpression(), !240)
  %v46 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78(ptr %arg0, ptr %v19, ptr %v3), !dbg !241
  %v47 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v20, ptr %v4), !dbg !242
  %v48 = icmp eq i32 %v47, 0, !dbg !242
  %v49 = icmp eq i1 %v48, true, !dbg !242
  %v50 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.42), !dbg !243
  %v51 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v50), !dbg !244
  %v52 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v51, ptr %v20), !dbg !244
  %v53 = icmp eq i32 %v52, 0, !dbg !244
  %v54 = icmp eq i1 %v53, true, !dbg !244
  %v55 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v46, i1 %v49, i1 %v54, i1 %v45), !dbg !245
    #dbg_value(i1 %v55, !246, !DIExpression(), !247)
  %v56 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !248
  %v57 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v56, ptr %v2, 1, !dbg !248
  %v58 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v57, ptr %v3, 2, !dbg !248
  %v59 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v58, ptr %v4, 3, !dbg !248
  %v60 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v59, ptr %v5, 4, !dbg !248
  %v61 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v60, ptr %v6, 5, !dbg !248
  %v62 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v61, ptr %v7, 6, !dbg !248
  %v63 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v62, ptr %v8, 7, !dbg !248
  %v64 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v63, i32 %v9, 8, !dbg !248
  %v65 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v64, i32 %v10, 9, !dbg !248
  %v66 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v65, i32 %v11, 10, !dbg !248
  %v67 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v66, i32 %v12, 11, !dbg !248
  %v68 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v67, i32 %v13, 12, !dbg !248
  %v69 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v68, i32 %v14, 13, !dbg !248
  %v70 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v69, i32 %v15, 14, !dbg !248
  %v71 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v70, i32 %v16, 15, !dbg !248
  %v72 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dentry_2dvalid.96(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v71, ptr %arg2), !dbg !248
  %v73 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v55, i1 %v72), !dbg !249
  ret i1 %v73, !dbg !249
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %arg0) #1 !dbg !250 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !251, !DIExpression(), !252)
  %v1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.44), !dbg !253
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.43, ptr %v1), !dbg !254
  ret ptr %v2, !dbg !254
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102(ptr %arg0, ptr %arg1) #1 !dbg !255 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !258, !DIExpression(), !259)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !260, !DIExpression(), !261)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4(ptr %arg0, ptr %arg1), !dbg !262
    #dbg_value(ptr %v2, !263, !DIExpression(), !264)
  %v3 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.45), !dbg !265
  %v4 = icmp eq i32 %v3, 0, !dbg !265
  %v5 = icmp eq i1 %v4, true, !dbg !265
  ret i1 %v5, !dbg !265
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105(ptr %arg0, ptr %arg1) #1 !dbg !266 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !267, !DIExpression(), !268)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !269, !DIExpression(), !270)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102(ptr %arg0, ptr %arg1), !dbg !271
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !271

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.46), !dbg !272
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102(ptr %arg0, ptr %v3), !dbg !273
  br label %decision.merge.2, !dbg !273

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !274

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !271
  ret i1 %v5, !dbg !271
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111(ptr %arg0, ptr %arg1) #1 !dbg !275 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !276, !DIExpression(), !277)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !278, !DIExpression(), !279)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105(ptr %arg0, ptr %arg1), !dbg !280
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !280

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.47), !dbg !281
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105(ptr %arg0, ptr %v3), !dbg !282
  br label %decision.merge.2, !dbg !282

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !283

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !280
  ret i1 %v5, !dbg !280
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr %arg1) #1 !dbg !284 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !285, !DIExpression(), !286)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !287, !DIExpression(), !288)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111(ptr %arg0, ptr %arg1), !dbg !289
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !289

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.48), !dbg !290
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111(ptr %arg0, ptr %v3), !dbg !291
  br label %decision.merge.2, !dbg !291

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !292

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !289
  ret i1 %v5, !dbg !289
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr %arg1) #1 !dbg !293 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !294, !DIExpression(), !295)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !296, !DIExpression(), !297)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr %arg1), !dbg !298
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !298

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.49), !dbg !299
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr %v3), !dbg !300
  br label %decision.merge.2, !dbg !300

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !301

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !298
  ret i1 %v5, !dbg !298
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dname.195(ptr %arg0, ptr %arg1) #1 !dbg !302 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !303, !DIExpression(), !304)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !305, !DIExpression(), !306)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr %arg1), !dbg !307
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !307

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.50), !dbg !308
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr %v3), !dbg !309
  br label %decision.merge.2, !dbg !309

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !310

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !307
  ret i1 %v5, !dbg !307
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eempty_2dtarget.204(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1) #1 !dbg !311 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !314, !DIExpression(), !315)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !316
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !316
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !316
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !316
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !316
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !316
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !316
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !316
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !316
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !316
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !316
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !316
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !316
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !316
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !316
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !316
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !317, !DIExpression(), !316)
  %v18 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !318
    #dbg_value(ptr %v18, !319, !DIExpression(), !320)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v6), !dbg !321
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dname.195(ptr %arg0, ptr %v19), !dbg !322
    #dbg_value(i1 %v20, !323, !DIExpression(), !324)
  %v21 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v18), !dbg !325
  %v22 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v21, ptr @topal.region-instance.namespace-metadata.literal.int.51), !dbg !325
  %v23 = icmp eq i32 %v22, 0, !dbg !325
  %v24 = icmp eq i1 %v23, true, !dbg !325
  %v25 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v18, ptr @topal.region-instance.namespace-metadata.literal.int.52), !dbg !326
  %v26 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v25), !dbg !327
  %v27 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v26, ptr @topal.region-instance.namespace-metadata.literal.int.53), !dbg !327
  %v28 = icmp eq i32 %v27, 0, !dbg !327
  %v29 = icmp eq i1 %v28, true, !dbg !327
  %v30 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.54), !dbg !328
  %v31 = icmp slt i32 %v30, 0, !dbg !328
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v24, i1 %v29, i1 %v20, i1 %v31), !dbg !329
  ret i1 %v32, !dbg !329
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elive_2dtarget.257(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1) #1 !dbg !330 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !331, !DIExpression(), !332)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !333
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !333
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !333
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !333
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !333
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !333
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !333
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !333
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !333
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !333
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !333
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !333
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !333
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !333
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !333
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !333
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !334, !DIExpression(), !333)
  %v18 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v8), !dbg !335
    #dbg_value(ptr %v18, !336, !DIExpression(), !337)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59(ptr %arg0, ptr %v7), !dbg !338
    #dbg_value(ptr %v19, !339, !DIExpression(), !340)
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78(ptr %arg0, ptr %v18, ptr %v7), !dbg !341
  %v21 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.55), !dbg !342
  %v22 = icmp sgt i32 %v21, 0, !dbg !342
  %v23 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v18, ptr @topal.region-instance.namespace-metadata.literal.int.56), !dbg !343
  %v24 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v23), !dbg !344
  %v25 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v24, ptr %v19), !dbg !344
  %v26 = icmp eq i32 %v25, 0, !dbg !344
  %v27 = icmp eq i1 %v26, true, !dbg !344
  %v28 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v18, ptr @topal.region-instance.namespace-metadata.literal.int.57), !dbg !345
  %v29 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v28), !dbg !346
  %v30 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v29, ptr @topal.region-instance.namespace-metadata.literal.int.58), !dbg !346
  %v31 = icmp eq i32 %v30, 0, !dbg !346
  %v32 = icmp eq i1 %v31, true, !dbg !346
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v20, i1 %v22, i1 %v27, i1 %v32), !dbg !347
    #dbg_value(i1 %v33, !348, !DIExpression(), !349)
  %v34 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94(ptr %arg0, ptr %v6, ptr %v7), !dbg !350
    #dbg_value(i1 %v34, !351, !DIExpression(), !352)
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v33, i1 %v34), !dbg !353
  ret i1 %v35, !dbg !353
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dmove_2dor_2dlive.258(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !354 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !355, !DIExpression(), !356)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !357
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !357
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !357
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !357
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !357
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !357
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !357
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !357
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !357
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !357
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !357
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !357
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !357
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !357
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !357
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !357
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !358, !DIExpression(), !357)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !359, !DIExpression(), !360)
  %v19 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.59), !dbg !361
  %v20 = icmp eq i32 %v19, 0, !dbg !361
  %v21 = icmp eq i1 %v20, true, !dbg !361
  br i1 %v21, label %decision.true.0, label %decision.false.1, !dbg !361

decision.true.0:                                  ; preds = %entry
  %v22 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %v2), !dbg !362
  %v23 = icmp eq i32 %v22, 0, !dbg !362
  %v24 = icmp eq i1 %v23, true, !dbg !362
  br label %decision.merge.2, !dbg !362

decision.false.1:                                 ; preds = %entry
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !363
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v2, 1, !dbg !363
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v3, 2, !dbg !363
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v4, 3, !dbg !363
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v5, 4, !dbg !363
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v6, 5, !dbg !363
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, ptr %v7, 6, !dbg !363
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, ptr %v8, 7, !dbg !363
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v9, 8, !dbg !363
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v10, 9, !dbg !363
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v11, 10, !dbg !363
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v12, 11, !dbg !363
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v13, 12, !dbg !363
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v14, 13, !dbg !363
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, i32 %v15, 14, !dbg !363
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, i32 %v16, 15, !dbg !363
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elive_2dtarget.257(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40), !dbg !363
  br label %decision.merge.2, !dbg !363

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v42 = phi i1 [ %v24, %decision.true.0 ], [ %v41, %decision.false.1 ], !dbg !361
  ret i1 %v42, !dbg !361
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dvalid.259(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !364 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !365, !DIExpression(), !366)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !367
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !367
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !367
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !367
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !367
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !367
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !367
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !367
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !367
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !367
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !367
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !367
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !367
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !367
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !367
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !367
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !368, !DIExpression(), !367)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !369, !DIExpression(), !370)
  %v19 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.60), !dbg !371
  %v20 = icmp eq i32 %v19, 0, !dbg !371
  %v21 = icmp eq i1 %v20, true, !dbg !371
  br i1 %v21, label %decision.true.0, label %decision.false.1, !dbg !371

decision.true.0:                                  ; preds = %entry
  %v22 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !372
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v22, ptr %v2, 1, !dbg !372
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v3, 2, !dbg !372
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v4, 3, !dbg !372
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v5, 4, !dbg !372
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v6, 5, !dbg !372
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v7, 6, !dbg !372
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v8, 7, !dbg !372
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, i32 %v9, 8, !dbg !372
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v10, 9, !dbg !372
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v11, 10, !dbg !372
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v12, 11, !dbg !372
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v13, 12, !dbg !372
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v14, 13, !dbg !372
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v15, 14, !dbg !372
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v16, 15, !dbg !372
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eempty_2dtarget.204(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37), !dbg !372
  br label %decision.merge.2, !dbg !372

decision.false.1:                                 ; preds = %entry
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !373
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, ptr %v2, 1, !dbg !373
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v3, 2, !dbg !373
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v4, 3, !dbg !373
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v5, 4, !dbg !373
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v6, 5, !dbg !373
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v7, 6, !dbg !373
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v8, 7, !dbg !373
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, i32 %v9, 8, !dbg !373
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v10, 9, !dbg !373
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v11, 10, !dbg !373
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v12, 11, !dbg !373
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v13, 12, !dbg !373
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v14, 13, !dbg !373
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v15, 14, !dbg !373
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v16, 15, !dbg !373
  %v55 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dmove_2dor_2dlive.258(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, ptr %arg2), !dbg !373
  br label %decision.merge.2, !dbg !373

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v56 = phi i1 [ %v38, %decision.true.0 ], [ %v55, %decision.false.1 ], !dbg !371
  ret i1 %v56, !dbg !371
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330(ptr %arg0, ptr %arg1) #1 !dbg !374 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !375, !DIExpression(), !376)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !377, !DIExpression(), !378)
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.61, ptr %arg1), !dbg !379
    #dbg_value(ptr %v2, !380, !DIExpression(), !381)
  %v3 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %v2, i64 1, i1 false), !dbg !382
  %v4 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v3), !dbg !382
  br i1 %v4, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !382

optional.decision.some.0:                         ; preds = %entry
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v3), !dbg !383
    #dbg_value(ptr %v5, !384, !DIExpression(), !383)
  br label %optional.decision.merge.2, !dbg !385

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !386

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v6 = phi ptr [ %v5, %optional.decision.some.0 ], [ @topal.region-instance.namespace-metadata.literal.int.62, %optional.decision.none.1 ], !dbg !382
  ret ptr %v6, !dbg !382
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %arg0, i1 %arg1) #1 !dbg !387 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !388, !DIExpression(), !389)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !390, !DIExpression(), !391)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !392

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !393

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !394

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v2 = phi i1 [ %arg1, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !392
  ret i1 %v2, !dbg !392
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2enot_2ddot.335(ptr %arg0, ptr %arg1) #1 !dbg !395 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !396, !DIExpression(), !397)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !398, !DIExpression(), !399)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.63), !dbg !400
    #dbg_value(ptr %v2, !401, !DIExpression(), !402)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.64), !dbg !403
    #dbg_value(ptr %v3, !404, !DIExpression(), !405)
  %v4 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.65), !dbg !406
  %v5 = icmp eq i32 %v4, 0, !dbg !406
  %v6 = icmp eq i1 %v5, true, !dbg !406
    #dbg_value(i1 %v6, !407, !DIExpression(), !408)
  %v7 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.66), !dbg !409
  %v8 = icmp eq i32 %v7, 0, !dbg !409
  %v9 = icmp eq i1 %v8, true, !dbg !409
    #dbg_value(i1 %v9, !410, !DIExpression(), !411)
  %v10 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.67), !dbg !412
  %v11 = icmp eq i32 %v10, 0, !dbg !412
  %v12 = icmp eq i1 %v11, true, !dbg !412
    #dbg_value(i1 %v12, !413, !DIExpression(), !414)
  %v13 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.68), !dbg !415
  %v14 = icmp eq i32 %v13, 0, !dbg !415
  %v15 = icmp eq i1 %v14, true, !dbg !415
    #dbg_value(i1 %v15, !416, !DIExpression(), !417)
  %v16 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v6, i1 %v12), !dbg !418
    #dbg_value(i1 %v16, !419, !DIExpression(), !420)
  %v17 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v12, i1 %v15), !dbg !421
  %v18 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v9, i1 %v17), !dbg !422
    #dbg_value(i1 %v18, !423, !DIExpression(), !424)
  br i1 %v16, label %decision.true.0, label %decision.false.1, !dbg !425

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !426

decision.false.1:                                 ; preds = %entry
  %v19 = xor i1 %v18, true, !dbg !427
  br label %decision.merge.2, !dbg !427

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v20 = phi i1 [ false, %decision.true.0 ], [ %v19, %decision.false.1 ], !dbg !425
  ret i1 %v20, !dbg !425
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2echaracter.338(ptr %arg0) #1 !dbg !428 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !431, !DIExpression(), !432)
  %v1 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.69), !dbg !433
  %v2 = icmp sgt i32 %v1, 0, !dbg !433
    #dbg_value(i1 %v2, !434, !DIExpression(), !435)
  %v3 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.70), !dbg !436
  %v4 = icmp sle i32 %v3, 0, !dbg !436
    #dbg_value(i1 %v4, !437, !DIExpression(), !438)
  %v5 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.71), !dbg !439
  %v6 = icmp eq i32 %v5, 0, !dbg !439
  %v7 = icmp ne i1 %v6, true, !dbg !439
    #dbg_value(i1 %v7, !440, !DIExpression(), !441)
  %v8 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v4, i1 %v7), !dbg !442
  %v9 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v2, i1 %v8), !dbg !443
  ret i1 %v9, !dbg !443
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dvalue.339(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !444 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !447, !DIExpression(), !448)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !449, !DIExpression(), !450)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !451, !DIExpression(), !452)
  %v3 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr %arg2), !dbg !453
  %v4 = icmp slt i32 %v3, 0, !dbg !453
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !453

decision.true.0:                                  ; preds = %entry
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2echaracter.338(ptr %arg0), !dbg !454
  br label %decision.merge.2, !dbg !454

decision.false.1:                                 ; preds = %entry
  %v6 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.72), !dbg !455
  %v7 = icmp eq i32 %v6, 0, !dbg !455
  %v8 = icmp eq i1 %v7, true, !dbg !455
  br label %decision.merge.2, !dbg !455

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v9 = phi i1 [ %v5, %decision.true.0 ], [ %v8, %decision.false.1 ], !dbg !453
  ret i1 %v9, !dbg !453
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3) #1 !dbg !456 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !459, !DIExpression(), !460)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !461, !DIExpression(), !462)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !463, !DIExpression(), !464)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !465, !DIExpression(), !466)
  %v4 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %arg1, i64 1, i1 false), !dbg !467
  %v5 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v4), !dbg !467
  br i1 %v5, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !467

optional.decision.some.0:                         ; preds = %entry
  %v6 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v4), !dbg !468
    #dbg_value(ptr %v6, !469, !DIExpression(), !468)
  %v7 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dvalue.339(ptr %v6, ptr %arg2, ptr %arg3), !dbg !470
  br label %optional.decision.merge.2, !dbg !470

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !471

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v8 = phi i1 [ %v7, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !467
  ret i1 %v8, !dbg !467
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3) #1 !dbg !472 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !473, !DIExpression(), !474)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !475, !DIExpression(), !476)
  %v2 = alloca i1, align 1
  store i1 %arg2, ptr %v2, align 1
    #dbg_declare(ptr %v2, !477, !DIExpression(), !478)
  %v3 = alloca i1, align 1
  store i1 %arg3, ptr %v3, align 1
    #dbg_declare(ptr %v3, !479, !DIExpression(), !480)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %arg0, i1 %arg1), !dbg !481
    #dbg_value(i1 %v4, !482, !DIExpression(), !483)
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %arg2, i1 %arg3), !dbg !484
    #dbg_value(i1 %v5, !485, !DIExpression(), !486)
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v4, i1 %v5), !dbg !487
  ret i1 %v6, !dbg !487
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dpayload.1956(ptr %arg0, ptr %arg1) #1 !dbg !488 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !489, !DIExpression(), !490)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !491, !DIExpression(), !492)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.73, ptr @topal.region-instance.namespace-metadata.literal.int.74, ptr %arg1), !dbg !493
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.75, ptr @topal.region-instance.namespace-metadata.literal.int.76, ptr %arg1), !dbg !494
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.77, ptr @topal.region-instance.namespace-metadata.literal.int.78, ptr %arg1), !dbg !495
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.79, ptr @topal.region-instance.namespace-metadata.literal.int.80, ptr %arg1), !dbg !496
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v2, i1 %v3, i1 %v4, i1 %v5), !dbg !497
    #dbg_value(i1 %v6, !498, !DIExpression(), !499)
  %v7 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.81, ptr @topal.region-instance.namespace-metadata.literal.int.82, ptr %arg1), !dbg !500
  %v8 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.83, ptr @topal.region-instance.namespace-metadata.literal.int.84, ptr %arg1), !dbg !501
  %v9 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.85, ptr @topal.region-instance.namespace-metadata.literal.int.86, ptr %arg1), !dbg !502
  %v10 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.87, ptr @topal.region-instance.namespace-metadata.literal.int.88, ptr %arg1), !dbg !503
  %v11 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v7, i1 %v8, i1 %v9, i1 %v10), !dbg !504
    #dbg_value(i1 %v11, !505, !DIExpression(), !506)
  %v12 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.89, ptr @topal.region-instance.namespace-metadata.literal.int.90, ptr %arg1), !dbg !507
  %v13 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.91, ptr @topal.region-instance.namespace-metadata.literal.int.92, ptr %arg1), !dbg !508
  %v14 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.93, ptr @topal.region-instance.namespace-metadata.literal.int.94, ptr %arg1), !dbg !509
  %v15 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.95, ptr @topal.region-instance.namespace-metadata.literal.int.96, ptr %arg1), !dbg !510
  %v16 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v12, i1 %v13, i1 %v14, i1 %v15), !dbg !511
    #dbg_value(i1 %v16, !512, !DIExpression(), !513)
  %v17 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.97, ptr @topal.region-instance.namespace-metadata.literal.int.98, ptr %arg1), !dbg !514
  %v18 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.99, ptr @topal.region-instance.namespace-metadata.literal.int.100, ptr %arg1), !dbg !515
  %v19 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.101, ptr @topal.region-instance.namespace-metadata.literal.int.102, ptr %arg1), !dbg !516
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.103, ptr @topal.region-instance.namespace-metadata.literal.int.104, ptr %arg1), !dbg !517
  %v21 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v17, i1 %v18, i1 %v19, i1 %v20), !dbg !518
    #dbg_value(i1 %v21, !519, !DIExpression(), !520)
  %v22 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.105, ptr @topal.region-instance.namespace-metadata.literal.int.106, ptr %arg1), !dbg !521
  %v23 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.107, ptr @topal.region-instance.namespace-metadata.literal.int.108, ptr %arg1), !dbg !522
  %v24 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.109, ptr @topal.region-instance.namespace-metadata.literal.int.110, ptr %arg1), !dbg !523
  %v25 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.111, ptr @topal.region-instance.namespace-metadata.literal.int.112, ptr %arg1), !dbg !524
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v22, i1 %v23, i1 %v24, i1 %v25), !dbg !525
    #dbg_value(i1 %v26, !526, !DIExpression(), !527)
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.113, ptr @topal.region-instance.namespace-metadata.literal.int.114, ptr %arg1), !dbg !528
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.115, ptr @topal.region-instance.namespace-metadata.literal.int.116, ptr %arg1), !dbg !529
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.117, ptr @topal.region-instance.namespace-metadata.literal.int.118, ptr %arg1), !dbg !530
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.119, ptr @topal.region-instance.namespace-metadata.literal.int.120, ptr %arg1), !dbg !531
  %v31 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v27, i1 %v28, i1 %v29, i1 %v30), !dbg !532
    #dbg_value(i1 %v31, !533, !DIExpression(), !534)
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.121, ptr @topal.region-instance.namespace-metadata.literal.int.122, ptr %arg1), !dbg !535
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.123, ptr @topal.region-instance.namespace-metadata.literal.int.124, ptr %arg1), !dbg !536
  %v34 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.125, ptr @topal.region-instance.namespace-metadata.literal.int.126, ptr %arg1), !dbg !537
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.127, ptr @topal.region-instance.namespace-metadata.literal.int.128, ptr %arg1), !dbg !538
  %v36 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v32, i1 %v33, i1 %v34, i1 %v35), !dbg !539
    #dbg_value(i1 %v36, !540, !DIExpression(), !541)
  %v37 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.129, ptr @topal.region-instance.namespace-metadata.literal.int.130, ptr %arg1), !dbg !542
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.131, ptr @topal.region-instance.namespace-metadata.literal.int.132, ptr %arg1), !dbg !543
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.133, ptr @topal.region-instance.namespace-metadata.literal.int.134, ptr %arg1), !dbg !544
  %v40 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.135, ptr @topal.region-instance.namespace-metadata.literal.int.136, ptr %arg1), !dbg !545
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v37, i1 %v38, i1 %v39, i1 %v40), !dbg !546
    #dbg_value(i1 %v41, !547, !DIExpression(), !548)
  %v42 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.137, ptr @topal.region-instance.namespace-metadata.literal.int.138, ptr %arg1), !dbg !549
  %v43 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.139, ptr @topal.region-instance.namespace-metadata.literal.int.140, ptr %arg1), !dbg !550
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.141, ptr @topal.region-instance.namespace-metadata.literal.int.142, ptr %arg1), !dbg !551
  %v45 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.143, ptr @topal.region-instance.namespace-metadata.literal.int.144, ptr %arg1), !dbg !552
  %v46 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v42, i1 %v43, i1 %v44, i1 %v45), !dbg !553
    #dbg_value(i1 %v46, !554, !DIExpression(), !555)
  %v47 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.145, ptr @topal.region-instance.namespace-metadata.literal.int.146, ptr %arg1), !dbg !556
  %v48 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.147, ptr @topal.region-instance.namespace-metadata.literal.int.148, ptr %arg1), !dbg !557
  %v49 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.149, ptr @topal.region-instance.namespace-metadata.literal.int.150, ptr %arg1), !dbg !558
  %v50 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.151, ptr @topal.region-instance.namespace-metadata.literal.int.152, ptr %arg1), !dbg !559
  %v51 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v47, i1 %v48, i1 %v49, i1 %v50), !dbg !560
    #dbg_value(i1 %v51, !561, !DIExpression(), !562)
  %v52 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.153, ptr @topal.region-instance.namespace-metadata.literal.int.154, ptr %arg1), !dbg !563
  %v53 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.155, ptr @topal.region-instance.namespace-metadata.literal.int.156, ptr %arg1), !dbg !564
  %v54 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.157, ptr @topal.region-instance.namespace-metadata.literal.int.158, ptr %arg1), !dbg !565
  %v55 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.159, ptr @topal.region-instance.namespace-metadata.literal.int.160, ptr %arg1), !dbg !566
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v52, i1 %v53, i1 %v54, i1 %v55), !dbg !567
    #dbg_value(i1 %v56, !568, !DIExpression(), !569)
  %v57 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.161, ptr @topal.region-instance.namespace-metadata.literal.int.162, ptr %arg1), !dbg !570
  %v58 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.163, ptr @topal.region-instance.namespace-metadata.literal.int.164, ptr %arg1), !dbg !571
  %v59 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.165, ptr @topal.region-instance.namespace-metadata.literal.int.166, ptr %arg1), !dbg !572
  %v60 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.167, ptr @topal.region-instance.namespace-metadata.literal.int.168, ptr %arg1), !dbg !573
  %v61 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v57, i1 %v58, i1 %v59, i1 %v60), !dbg !574
    #dbg_value(i1 %v61, !575, !DIExpression(), !576)
  %v62 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.169, ptr @topal.region-instance.namespace-metadata.literal.int.170, ptr %arg1), !dbg !577
  %v63 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.171, ptr @topal.region-instance.namespace-metadata.literal.int.172, ptr %arg1), !dbg !578
  %v64 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.173, ptr @topal.region-instance.namespace-metadata.literal.int.174, ptr %arg1), !dbg !579
  %v65 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.175, ptr @topal.region-instance.namespace-metadata.literal.int.176, ptr %arg1), !dbg !580
  %v66 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v62, i1 %v63, i1 %v64, i1 %v65), !dbg !581
    #dbg_value(i1 %v66, !582, !DIExpression(), !583)
  %v67 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.177, ptr @topal.region-instance.namespace-metadata.literal.int.178, ptr %arg1), !dbg !584
  %v68 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.179, ptr @topal.region-instance.namespace-metadata.literal.int.180, ptr %arg1), !dbg !585
  %v69 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.181, ptr @topal.region-instance.namespace-metadata.literal.int.182, ptr %arg1), !dbg !586
  %v70 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.183, ptr @topal.region-instance.namespace-metadata.literal.int.184, ptr %arg1), !dbg !587
  %v71 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v67, i1 %v68, i1 %v69, i1 %v70), !dbg !588
    #dbg_value(i1 %v71, !589, !DIExpression(), !590)
  %v72 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.185, ptr @topal.region-instance.namespace-metadata.literal.int.186, ptr %arg1), !dbg !591
  %v73 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.187, ptr @topal.region-instance.namespace-metadata.literal.int.188, ptr %arg1), !dbg !592
  %v74 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.189, ptr @topal.region-instance.namespace-metadata.literal.int.190, ptr %arg1), !dbg !593
  %v75 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.191, ptr @topal.region-instance.namespace-metadata.literal.int.192, ptr %arg1), !dbg !594
  %v76 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v72, i1 %v73, i1 %v74, i1 %v75), !dbg !595
    #dbg_value(i1 %v76, !596, !DIExpression(), !597)
  %v77 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.193, ptr @topal.region-instance.namespace-metadata.literal.int.194, ptr %arg1), !dbg !598
  %v78 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.195, ptr @topal.region-instance.namespace-metadata.literal.int.196, ptr %arg1), !dbg !599
  %v79 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.197, ptr @topal.region-instance.namespace-metadata.literal.int.198, ptr %arg1), !dbg !600
  %v80 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.199, ptr @topal.region-instance.namespace-metadata.literal.int.200, ptr %arg1), !dbg !601
  %v81 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v77, i1 %v78, i1 %v79, i1 %v80), !dbg !602
    #dbg_value(i1 %v81, !603, !DIExpression(), !604)
  %v82 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.201, ptr @topal.region-instance.namespace-metadata.literal.int.202, ptr %arg1), !dbg !605
  %v83 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.203, ptr @topal.region-instance.namespace-metadata.literal.int.204, ptr %arg1), !dbg !606
  %v84 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.205, ptr @topal.region-instance.namespace-metadata.literal.int.206, ptr %arg1), !dbg !607
  %v85 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.207, ptr @topal.region-instance.namespace-metadata.literal.int.208, ptr %arg1), !dbg !608
  %v86 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v82, i1 %v83, i1 %v84, i1 %v85), !dbg !609
    #dbg_value(i1 %v86, !610, !DIExpression(), !611)
  %v87 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.209, ptr @topal.region-instance.namespace-metadata.literal.int.210, ptr %arg1), !dbg !612
  %v88 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.211, ptr @topal.region-instance.namespace-metadata.literal.int.212, ptr %arg1), !dbg !613
  %v89 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.213, ptr @topal.region-instance.namespace-metadata.literal.int.214, ptr %arg1), !dbg !614
  %v90 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.215, ptr @topal.region-instance.namespace-metadata.literal.int.216, ptr %arg1), !dbg !615
  %v91 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v87, i1 %v88, i1 %v89, i1 %v90), !dbg !616
    #dbg_value(i1 %v91, !617, !DIExpression(), !618)
  %v92 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.217, ptr @topal.region-instance.namespace-metadata.literal.int.218, ptr %arg1), !dbg !619
  %v93 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.219, ptr @topal.region-instance.namespace-metadata.literal.int.220, ptr %arg1), !dbg !620
  %v94 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.221, ptr @topal.region-instance.namespace-metadata.literal.int.222, ptr %arg1), !dbg !621
  %v95 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.223, ptr @topal.region-instance.namespace-metadata.literal.int.224, ptr %arg1), !dbg !622
  %v96 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v92, i1 %v93, i1 %v94, i1 %v95), !dbg !623
    #dbg_value(i1 %v96, !624, !DIExpression(), !625)
  %v97 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.225, ptr @topal.region-instance.namespace-metadata.literal.int.226, ptr %arg1), !dbg !626
  %v98 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.227, ptr @topal.region-instance.namespace-metadata.literal.int.228, ptr %arg1), !dbg !627
  %v99 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.229, ptr @topal.region-instance.namespace-metadata.literal.int.230, ptr %arg1), !dbg !628
  %v100 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.231, ptr @topal.region-instance.namespace-metadata.literal.int.232, ptr %arg1), !dbg !629
  %v101 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v97, i1 %v98, i1 %v99, i1 %v100), !dbg !630
    #dbg_value(i1 %v101, !631, !DIExpression(), !632)
  %v102 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.233, ptr @topal.region-instance.namespace-metadata.literal.int.234, ptr %arg1), !dbg !633
  %v103 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.235, ptr @topal.region-instance.namespace-metadata.literal.int.236, ptr %arg1), !dbg !634
  %v104 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.237, ptr @topal.region-instance.namespace-metadata.literal.int.238, ptr %arg1), !dbg !635
  %v105 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.239, ptr @topal.region-instance.namespace-metadata.literal.int.240, ptr %arg1), !dbg !636
  %v106 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v102, i1 %v103, i1 %v104, i1 %v105), !dbg !637
    #dbg_value(i1 %v106, !638, !DIExpression(), !639)
  %v107 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.241, ptr @topal.region-instance.namespace-metadata.literal.int.242, ptr %arg1), !dbg !640
  %v108 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.243, ptr @topal.region-instance.namespace-metadata.literal.int.244, ptr %arg1), !dbg !641
  %v109 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.245, ptr @topal.region-instance.namespace-metadata.literal.int.246, ptr %arg1), !dbg !642
  %v110 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.247, ptr @topal.region-instance.namespace-metadata.literal.int.248, ptr %arg1), !dbg !643
  %v111 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v107, i1 %v108, i1 %v109, i1 %v110), !dbg !644
    #dbg_value(i1 %v111, !645, !DIExpression(), !646)
  %v112 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.249, ptr @topal.region-instance.namespace-metadata.literal.int.250, ptr %arg1), !dbg !647
  %v113 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.251, ptr @topal.region-instance.namespace-metadata.literal.int.252, ptr %arg1), !dbg !648
  %v114 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.253, ptr @topal.region-instance.namespace-metadata.literal.int.254, ptr %arg1), !dbg !649
  %v115 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.255, ptr @topal.region-instance.namespace-metadata.literal.int.256, ptr %arg1), !dbg !650
  %v116 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v112, i1 %v113, i1 %v114, i1 %v115), !dbg !651
    #dbg_value(i1 %v116, !652, !DIExpression(), !653)
  %v117 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.257, ptr @topal.region-instance.namespace-metadata.literal.int.258, ptr %arg1), !dbg !654
  %v118 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.259, ptr @topal.region-instance.namespace-metadata.literal.int.260, ptr %arg1), !dbg !655
  %v119 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.261, ptr @topal.region-instance.namespace-metadata.literal.int.262, ptr %arg1), !dbg !656
  %v120 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.263, ptr @topal.region-instance.namespace-metadata.literal.int.264, ptr %arg1), !dbg !657
  %v121 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v117, i1 %v118, i1 %v119, i1 %v120), !dbg !658
    #dbg_value(i1 %v121, !659, !DIExpression(), !660)
  %v122 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.265, ptr @topal.region-instance.namespace-metadata.literal.int.266, ptr %arg1), !dbg !661
  %v123 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.267, ptr @topal.region-instance.namespace-metadata.literal.int.268, ptr %arg1), !dbg !662
  %v124 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.269, ptr @topal.region-instance.namespace-metadata.literal.int.270, ptr %arg1), !dbg !663
  %v125 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.271, ptr @topal.region-instance.namespace-metadata.literal.int.272, ptr %arg1), !dbg !664
  %v126 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v122, i1 %v123, i1 %v124, i1 %v125), !dbg !665
    #dbg_value(i1 %v126, !666, !DIExpression(), !667)
  %v127 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.273, ptr @topal.region-instance.namespace-metadata.literal.int.274, ptr %arg1), !dbg !668
  %v128 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.275, ptr @topal.region-instance.namespace-metadata.literal.int.276, ptr %arg1), !dbg !669
  %v129 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.277, ptr @topal.region-instance.namespace-metadata.literal.int.278, ptr %arg1), !dbg !670
  %v130 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.279, ptr @topal.region-instance.namespace-metadata.literal.int.280, ptr %arg1), !dbg !671
  %v131 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v127, i1 %v128, i1 %v129, i1 %v130), !dbg !672
    #dbg_value(i1 %v131, !673, !DIExpression(), !674)
  %v132 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.281, ptr @topal.region-instance.namespace-metadata.literal.int.282, ptr %arg1), !dbg !675
  %v133 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.283, ptr @topal.region-instance.namespace-metadata.literal.int.284, ptr %arg1), !dbg !676
  %v134 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.285, ptr @topal.region-instance.namespace-metadata.literal.int.286, ptr %arg1), !dbg !677
  %v135 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.287, ptr @topal.region-instance.namespace-metadata.literal.int.288, ptr %arg1), !dbg !678
  %v136 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v132, i1 %v133, i1 %v134, i1 %v135), !dbg !679
    #dbg_value(i1 %v136, !680, !DIExpression(), !681)
  %v137 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.289, ptr @topal.region-instance.namespace-metadata.literal.int.290, ptr %arg1), !dbg !682
  %v138 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.291, ptr @topal.region-instance.namespace-metadata.literal.int.292, ptr %arg1), !dbg !683
  %v139 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.293, ptr @topal.region-instance.namespace-metadata.literal.int.294, ptr %arg1), !dbg !684
  %v140 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.295, ptr @topal.region-instance.namespace-metadata.literal.int.296, ptr %arg1), !dbg !685
  %v141 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v137, i1 %v138, i1 %v139, i1 %v140), !dbg !686
    #dbg_value(i1 %v141, !687, !DIExpression(), !688)
  %v142 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.297, ptr @topal.region-instance.namespace-metadata.literal.int.298, ptr %arg1), !dbg !689
  %v143 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.299, ptr @topal.region-instance.namespace-metadata.literal.int.300, ptr %arg1), !dbg !690
  %v144 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.301, ptr @topal.region-instance.namespace-metadata.literal.int.302, ptr %arg1), !dbg !691
  %v145 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.303, ptr @topal.region-instance.namespace-metadata.literal.int.304, ptr %arg1), !dbg !692
  %v146 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v142, i1 %v143, i1 %v144, i1 %v145), !dbg !693
    #dbg_value(i1 %v146, !694, !DIExpression(), !695)
  %v147 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.305, ptr @topal.region-instance.namespace-metadata.literal.int.306, ptr %arg1), !dbg !696
  %v148 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.307, ptr @topal.region-instance.namespace-metadata.literal.int.308, ptr %arg1), !dbg !697
  %v149 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.309, ptr @topal.region-instance.namespace-metadata.literal.int.310, ptr %arg1), !dbg !698
  %v150 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.311, ptr @topal.region-instance.namespace-metadata.literal.int.312, ptr %arg1), !dbg !699
  %v151 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v147, i1 %v148, i1 %v149, i1 %v150), !dbg !700
    #dbg_value(i1 %v151, !701, !DIExpression(), !702)
  %v152 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.313, ptr @topal.region-instance.namespace-metadata.literal.int.314, ptr %arg1), !dbg !703
  %v153 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.315, ptr @topal.region-instance.namespace-metadata.literal.int.316, ptr %arg1), !dbg !704
  %v154 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.317, ptr @topal.region-instance.namespace-metadata.literal.int.318, ptr %arg1), !dbg !705
  %v155 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.319, ptr @topal.region-instance.namespace-metadata.literal.int.320, ptr %arg1), !dbg !706
  %v156 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v152, i1 %v153, i1 %v154, i1 %v155), !dbg !707
    #dbg_value(i1 %v156, !708, !DIExpression(), !709)
  %v157 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.321, ptr @topal.region-instance.namespace-metadata.literal.int.322, ptr %arg1), !dbg !710
  %v158 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.323, ptr @topal.region-instance.namespace-metadata.literal.int.324, ptr %arg1), !dbg !711
  %v159 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.325, ptr @topal.region-instance.namespace-metadata.literal.int.326, ptr %arg1), !dbg !712
  %v160 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.327, ptr @topal.region-instance.namespace-metadata.literal.int.328, ptr %arg1), !dbg !713
  %v161 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v157, i1 %v158, i1 %v159, i1 %v160), !dbg !714
    #dbg_value(i1 %v161, !715, !DIExpression(), !716)
  %v162 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.329, ptr @topal.region-instance.namespace-metadata.literal.int.330, ptr %arg1), !dbg !717
  %v163 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.331, ptr @topal.region-instance.namespace-metadata.literal.int.332, ptr %arg1), !dbg !718
  %v164 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.333, ptr @topal.region-instance.namespace-metadata.literal.int.334, ptr %arg1), !dbg !719
  %v165 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.335, ptr @topal.region-instance.namespace-metadata.literal.int.336, ptr %arg1), !dbg !720
  %v166 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v162, i1 %v163, i1 %v164, i1 %v165), !dbg !721
    #dbg_value(i1 %v166, !722, !DIExpression(), !723)
  %v167 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.337, ptr @topal.region-instance.namespace-metadata.literal.int.338, ptr %arg1), !dbg !724
  %v168 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.339, ptr @topal.region-instance.namespace-metadata.literal.int.340, ptr %arg1), !dbg !725
  %v169 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.341, ptr @topal.region-instance.namespace-metadata.literal.int.342, ptr %arg1), !dbg !726
  %v170 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.343, ptr @topal.region-instance.namespace-metadata.literal.int.344, ptr %arg1), !dbg !727
  %v171 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v167, i1 %v168, i1 %v169, i1 %v170), !dbg !728
    #dbg_value(i1 %v171, !729, !DIExpression(), !730)
  %v172 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.345, ptr @topal.region-instance.namespace-metadata.literal.int.346, ptr %arg1), !dbg !731
  %v173 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.347, ptr @topal.region-instance.namespace-metadata.literal.int.348, ptr %arg1), !dbg !732
  %v174 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.349, ptr @topal.region-instance.namespace-metadata.literal.int.350, ptr %arg1), !dbg !733
  %v175 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.351, ptr @topal.region-instance.namespace-metadata.literal.int.352, ptr %arg1), !dbg !734
  %v176 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v172, i1 %v173, i1 %v174, i1 %v175), !dbg !735
    #dbg_value(i1 %v176, !736, !DIExpression(), !737)
  %v177 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.353, ptr @topal.region-instance.namespace-metadata.literal.int.354, ptr %arg1), !dbg !738
  %v178 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.355, ptr @topal.region-instance.namespace-metadata.literal.int.356, ptr %arg1), !dbg !739
  %v179 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.357, ptr @topal.region-instance.namespace-metadata.literal.int.358, ptr %arg1), !dbg !740
  %v180 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.359, ptr @topal.region-instance.namespace-metadata.literal.int.360, ptr %arg1), !dbg !741
  %v181 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v177, i1 %v178, i1 %v179, i1 %v180), !dbg !742
    #dbg_value(i1 %v181, !743, !DIExpression(), !744)
  %v182 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.361, ptr @topal.region-instance.namespace-metadata.literal.int.362, ptr %arg1), !dbg !745
  %v183 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.363, ptr @topal.region-instance.namespace-metadata.literal.int.364, ptr %arg1), !dbg !746
  %v184 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.365, ptr @topal.region-instance.namespace-metadata.literal.int.366, ptr %arg1), !dbg !747
  %v185 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.367, ptr @topal.region-instance.namespace-metadata.literal.int.368, ptr %arg1), !dbg !748
  %v186 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v182, i1 %v183, i1 %v184, i1 %v185), !dbg !749
    #dbg_value(i1 %v186, !750, !DIExpression(), !751)
  %v187 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.369, ptr @topal.region-instance.namespace-metadata.literal.int.370, ptr %arg1), !dbg !752
  %v188 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.371, ptr @topal.region-instance.namespace-metadata.literal.int.372, ptr %arg1), !dbg !753
  %v189 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.373, ptr @topal.region-instance.namespace-metadata.literal.int.374, ptr %arg1), !dbg !754
  %v190 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.375, ptr @topal.region-instance.namespace-metadata.literal.int.376, ptr %arg1), !dbg !755
  %v191 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v187, i1 %v188, i1 %v189, i1 %v190), !dbg !756
    #dbg_value(i1 %v191, !757, !DIExpression(), !758)
  %v192 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.377, ptr @topal.region-instance.namespace-metadata.literal.int.378, ptr %arg1), !dbg !759
  %v193 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.379, ptr @topal.region-instance.namespace-metadata.literal.int.380, ptr %arg1), !dbg !760
  %v194 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.381, ptr @topal.region-instance.namespace-metadata.literal.int.382, ptr %arg1), !dbg !761
  %v195 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.383, ptr @topal.region-instance.namespace-metadata.literal.int.384, ptr %arg1), !dbg !762
  %v196 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v192, i1 %v193, i1 %v194, i1 %v195), !dbg !763
    #dbg_value(i1 %v196, !764, !DIExpression(), !765)
  %v197 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.385, ptr @topal.region-instance.namespace-metadata.literal.int.386, ptr %arg1), !dbg !766
  %v198 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.387, ptr @topal.region-instance.namespace-metadata.literal.int.388, ptr %arg1), !dbg !767
  %v199 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.389, ptr @topal.region-instance.namespace-metadata.literal.int.390, ptr %arg1), !dbg !768
  %v200 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.391, ptr @topal.region-instance.namespace-metadata.literal.int.392, ptr %arg1), !dbg !769
  %v201 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v197, i1 %v198, i1 %v199, i1 %v200), !dbg !770
    #dbg_value(i1 %v201, !771, !DIExpression(), !772)
  %v202 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.393, ptr @topal.region-instance.namespace-metadata.literal.int.394, ptr %arg1), !dbg !773
  %v203 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.395, ptr @topal.region-instance.namespace-metadata.literal.int.396, ptr %arg1), !dbg !774
  %v204 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.397, ptr @topal.region-instance.namespace-metadata.literal.int.398, ptr %arg1), !dbg !775
  %v205 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.399, ptr @topal.region-instance.namespace-metadata.literal.int.400, ptr %arg1), !dbg !776
  %v206 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v202, i1 %v203, i1 %v204, i1 %v205), !dbg !777
    #dbg_value(i1 %v206, !778, !DIExpression(), !779)
  %v207 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.401, ptr @topal.region-instance.namespace-metadata.literal.int.402, ptr %arg1), !dbg !780
  %v208 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.403, ptr @topal.region-instance.namespace-metadata.literal.int.404, ptr %arg1), !dbg !781
  %v209 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.405, ptr @topal.region-instance.namespace-metadata.literal.int.406, ptr %arg1), !dbg !782
  %v210 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.407, ptr @topal.region-instance.namespace-metadata.literal.int.408, ptr %arg1), !dbg !783
  %v211 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v207, i1 %v208, i1 %v209, i1 %v210), !dbg !784
    #dbg_value(i1 %v211, !785, !DIExpression(), !786)
  %v212 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.409, ptr @topal.region-instance.namespace-metadata.literal.int.410, ptr %arg1), !dbg !787
  %v213 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.411, ptr @topal.region-instance.namespace-metadata.literal.int.412, ptr %arg1), !dbg !788
  %v214 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.413, ptr @topal.region-instance.namespace-metadata.literal.int.414, ptr %arg1), !dbg !789
  %v215 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.415, ptr @topal.region-instance.namespace-metadata.literal.int.416, ptr %arg1), !dbg !790
  %v216 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v212, i1 %v213, i1 %v214, i1 %v215), !dbg !791
    #dbg_value(i1 %v216, !792, !DIExpression(), !793)
  %v217 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.417, ptr @topal.region-instance.namespace-metadata.literal.int.418, ptr %arg1), !dbg !794
  %v218 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.419, ptr @topal.region-instance.namespace-metadata.literal.int.420, ptr %arg1), !dbg !795
  %v219 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.421, ptr @topal.region-instance.namespace-metadata.literal.int.422, ptr %arg1), !dbg !796
  %v220 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.423, ptr @topal.region-instance.namespace-metadata.literal.int.424, ptr %arg1), !dbg !797
  %v221 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v217, i1 %v218, i1 %v219, i1 %v220), !dbg !798
    #dbg_value(i1 %v221, !799, !DIExpression(), !800)
  %v222 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.425, ptr @topal.region-instance.namespace-metadata.literal.int.426, ptr %arg1), !dbg !801
  %v223 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.427, ptr @topal.region-instance.namespace-metadata.literal.int.428, ptr %arg1), !dbg !802
  %v224 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.429, ptr @topal.region-instance.namespace-metadata.literal.int.430, ptr %arg1), !dbg !803
  %v225 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.431, ptr @topal.region-instance.namespace-metadata.literal.int.432, ptr %arg1), !dbg !804
  %v226 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v222, i1 %v223, i1 %v224, i1 %v225), !dbg !805
    #dbg_value(i1 %v226, !806, !DIExpression(), !807)
  %v227 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.433, ptr @topal.region-instance.namespace-metadata.literal.int.434, ptr %arg1), !dbg !808
  %v228 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.435, ptr @topal.region-instance.namespace-metadata.literal.int.436, ptr %arg1), !dbg !809
  %v229 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.437, ptr @topal.region-instance.namespace-metadata.literal.int.438, ptr %arg1), !dbg !810
  %v230 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.439, ptr @topal.region-instance.namespace-metadata.literal.int.440, ptr %arg1), !dbg !811
  %v231 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v227, i1 %v228, i1 %v229, i1 %v230), !dbg !812
    #dbg_value(i1 %v231, !813, !DIExpression(), !814)
  %v232 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.441, ptr @topal.region-instance.namespace-metadata.literal.int.442, ptr %arg1), !dbg !815
  %v233 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.443, ptr @topal.region-instance.namespace-metadata.literal.int.444, ptr %arg1), !dbg !816
  %v234 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.445, ptr @topal.region-instance.namespace-metadata.literal.int.446, ptr %arg1), !dbg !817
  %v235 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.447, ptr @topal.region-instance.namespace-metadata.literal.int.448, ptr %arg1), !dbg !818
  %v236 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v232, i1 %v233, i1 %v234, i1 %v235), !dbg !819
    #dbg_value(i1 %v236, !820, !DIExpression(), !821)
  %v237 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.449, ptr @topal.region-instance.namespace-metadata.literal.int.450, ptr %arg1), !dbg !822
  %v238 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.451, ptr @topal.region-instance.namespace-metadata.literal.int.452, ptr %arg1), !dbg !823
  %v239 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.453, ptr @topal.region-instance.namespace-metadata.literal.int.454, ptr %arg1), !dbg !824
  %v240 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.455, ptr @topal.region-instance.namespace-metadata.literal.int.456, ptr %arg1), !dbg !825
  %v241 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v237, i1 %v238, i1 %v239, i1 %v240), !dbg !826
    #dbg_value(i1 %v241, !827, !DIExpression(), !828)
  %v242 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.457, ptr @topal.region-instance.namespace-metadata.literal.int.458, ptr %arg1), !dbg !829
  %v243 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.459, ptr @topal.region-instance.namespace-metadata.literal.int.460, ptr %arg1), !dbg !830
  %v244 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.461, ptr @topal.region-instance.namespace-metadata.literal.int.462, ptr %arg1), !dbg !831
  %v245 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.463, ptr @topal.region-instance.namespace-metadata.literal.int.464, ptr %arg1), !dbg !832
  %v246 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v242, i1 %v243, i1 %v244, i1 %v245), !dbg !833
    #dbg_value(i1 %v246, !834, !DIExpression(), !835)
  %v247 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.465, ptr @topal.region-instance.namespace-metadata.literal.int.466, ptr %arg1), !dbg !836
  %v248 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.467, ptr @topal.region-instance.namespace-metadata.literal.int.468, ptr %arg1), !dbg !837
  %v249 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.469, ptr @topal.region-instance.namespace-metadata.literal.int.470, ptr %arg1), !dbg !838
  %v250 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.471, ptr @topal.region-instance.namespace-metadata.literal.int.472, ptr %arg1), !dbg !839
  %v251 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v247, i1 %v248, i1 %v249, i1 %v250), !dbg !840
    #dbg_value(i1 %v251, !841, !DIExpression(), !842)
  %v252 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.473, ptr @topal.region-instance.namespace-metadata.literal.int.474, ptr %arg1), !dbg !843
  %v253 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.475, ptr @topal.region-instance.namespace-metadata.literal.int.476, ptr %arg1), !dbg !844
  %v254 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.477, ptr @topal.region-instance.namespace-metadata.literal.int.478, ptr %arg1), !dbg !845
  %v255 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.479, ptr @topal.region-instance.namespace-metadata.literal.int.480, ptr %arg1), !dbg !846
  %v256 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v252, i1 %v253, i1 %v254, i1 %v255), !dbg !847
    #dbg_value(i1 %v256, !848, !DIExpression(), !849)
  %v257 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.481, ptr @topal.region-instance.namespace-metadata.literal.int.482, ptr %arg1), !dbg !850
  %v258 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.483, ptr @topal.region-instance.namespace-metadata.literal.int.484, ptr %arg1), !dbg !851
  %v259 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.485, ptr @topal.region-instance.namespace-metadata.literal.int.486, ptr %arg1), !dbg !852
  %v260 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.487, ptr @topal.region-instance.namespace-metadata.literal.int.488, ptr %arg1), !dbg !853
  %v261 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v257, i1 %v258, i1 %v259, i1 %v260), !dbg !854
    #dbg_value(i1 %v261, !855, !DIExpression(), !856)
  %v262 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.489, ptr @topal.region-instance.namespace-metadata.literal.int.490, ptr %arg1), !dbg !857
  %v263 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.491, ptr @topal.region-instance.namespace-metadata.literal.int.492, ptr %arg1), !dbg !858
  %v264 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.493, ptr @topal.region-instance.namespace-metadata.literal.int.494, ptr %arg1), !dbg !859
  %v265 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.495, ptr @topal.region-instance.namespace-metadata.literal.int.496, ptr %arg1), !dbg !860
  %v266 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v262, i1 %v263, i1 %v264, i1 %v265), !dbg !861
    #dbg_value(i1 %v266, !862, !DIExpression(), !863)
  %v267 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.497, ptr @topal.region-instance.namespace-metadata.literal.int.498, ptr %arg1), !dbg !864
  %v268 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.499, ptr @topal.region-instance.namespace-metadata.literal.int.500, ptr %arg1), !dbg !865
  %v269 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.501, ptr @topal.region-instance.namespace-metadata.literal.int.502, ptr %arg1), !dbg !866
  %v270 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.503, ptr @topal.region-instance.namespace-metadata.literal.int.504, ptr %arg1), !dbg !867
  %v271 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v267, i1 %v268, i1 %v269, i1 %v270), !dbg !868
    #dbg_value(i1 %v271, !869, !DIExpression(), !870)
  %v272 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.505, ptr @topal.region-instance.namespace-metadata.literal.int.506, ptr %arg1), !dbg !871
  %v273 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.507, ptr @topal.region-instance.namespace-metadata.literal.int.508, ptr %arg1), !dbg !872
  %v274 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.509, ptr @topal.region-instance.namespace-metadata.literal.int.510, ptr %arg1), !dbg !873
  %v275 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.511, ptr @topal.region-instance.namespace-metadata.literal.int.512, ptr %arg1), !dbg !874
  %v276 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v272, i1 %v273, i1 %v274, i1 %v275), !dbg !875
    #dbg_value(i1 %v276, !876, !DIExpression(), !877)
  %v277 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.513, ptr @topal.region-instance.namespace-metadata.literal.int.514, ptr %arg1), !dbg !878
  %v278 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.515, ptr @topal.region-instance.namespace-metadata.literal.int.516, ptr %arg1), !dbg !879
  %v279 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.517, ptr @topal.region-instance.namespace-metadata.literal.int.518, ptr %arg1), !dbg !880
  %v280 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.519, ptr @topal.region-instance.namespace-metadata.literal.int.520, ptr %arg1), !dbg !881
  %v281 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v277, i1 %v278, i1 %v279, i1 %v280), !dbg !882
    #dbg_value(i1 %v281, !883, !DIExpression(), !884)
  %v282 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.521, ptr @topal.region-instance.namespace-metadata.literal.int.522, ptr %arg1), !dbg !885
  %v283 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.523, ptr @topal.region-instance.namespace-metadata.literal.int.524, ptr %arg1), !dbg !886
  %v284 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.525, ptr @topal.region-instance.namespace-metadata.literal.int.526, ptr %arg1), !dbg !887
  %v285 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.527, ptr @topal.region-instance.namespace-metadata.literal.int.528, ptr %arg1), !dbg !888
  %v286 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v282, i1 %v283, i1 %v284, i1 %v285), !dbg !889
    #dbg_value(i1 %v286, !890, !DIExpression(), !891)
  %v287 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.529, ptr @topal.region-instance.namespace-metadata.literal.int.530, ptr %arg1), !dbg !892
  %v288 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.531, ptr @topal.region-instance.namespace-metadata.literal.int.532, ptr %arg1), !dbg !893
  %v289 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.533, ptr @topal.region-instance.namespace-metadata.literal.int.534, ptr %arg1), !dbg !894
  %v290 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.535, ptr @topal.region-instance.namespace-metadata.literal.int.536, ptr %arg1), !dbg !895
  %v291 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v287, i1 %v288, i1 %v289, i1 %v290), !dbg !896
    #dbg_value(i1 %v291, !897, !DIExpression(), !898)
  %v292 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.537, ptr @topal.region-instance.namespace-metadata.literal.int.538, ptr %arg1), !dbg !899
  %v293 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.539, ptr @topal.region-instance.namespace-metadata.literal.int.540, ptr %arg1), !dbg !900
  %v294 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.541, ptr @topal.region-instance.namespace-metadata.literal.int.542, ptr %arg1), !dbg !901
  %v295 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.543, ptr @topal.region-instance.namespace-metadata.literal.int.544, ptr %arg1), !dbg !902
  %v296 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v292, i1 %v293, i1 %v294, i1 %v295), !dbg !903
    #dbg_value(i1 %v296, !904, !DIExpression(), !905)
  %v297 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.545, ptr @topal.region-instance.namespace-metadata.literal.int.546, ptr %arg1), !dbg !906
  %v298 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.547, ptr @topal.region-instance.namespace-metadata.literal.int.548, ptr %arg1), !dbg !907
  %v299 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.549, ptr @topal.region-instance.namespace-metadata.literal.int.550, ptr %arg1), !dbg !908
  %v300 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.551, ptr @topal.region-instance.namespace-metadata.literal.int.552, ptr %arg1), !dbg !909
  %v301 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v297, i1 %v298, i1 %v299, i1 %v300), !dbg !910
    #dbg_value(i1 %v301, !911, !DIExpression(), !912)
  %v302 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.553, ptr @topal.region-instance.namespace-metadata.literal.int.554, ptr %arg1), !dbg !913
  %v303 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.555, ptr @topal.region-instance.namespace-metadata.literal.int.556, ptr %arg1), !dbg !914
  %v304 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.557, ptr @topal.region-instance.namespace-metadata.literal.int.558, ptr %arg1), !dbg !915
  %v305 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.559, ptr @topal.region-instance.namespace-metadata.literal.int.560, ptr %arg1), !dbg !916
  %v306 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v302, i1 %v303, i1 %v304, i1 %v305), !dbg !917
    #dbg_value(i1 %v306, !918, !DIExpression(), !919)
  %v307 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.561, ptr @topal.region-instance.namespace-metadata.literal.int.562, ptr %arg1), !dbg !920
  %v308 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.563, ptr @topal.region-instance.namespace-metadata.literal.int.564, ptr %arg1), !dbg !921
  %v309 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.565, ptr @topal.region-instance.namespace-metadata.literal.int.566, ptr %arg1), !dbg !922
  %v310 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.567, ptr @topal.region-instance.namespace-metadata.literal.int.568, ptr %arg1), !dbg !923
  %v311 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v307, i1 %v308, i1 %v309, i1 %v310), !dbg !924
    #dbg_value(i1 %v311, !925, !DIExpression(), !926)
  %v312 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.569, ptr @topal.region-instance.namespace-metadata.literal.int.570, ptr %arg1), !dbg !927
  %v313 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.571, ptr @topal.region-instance.namespace-metadata.literal.int.572, ptr %arg1), !dbg !928
  %v314 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.573, ptr @topal.region-instance.namespace-metadata.literal.int.574, ptr %arg1), !dbg !929
  %v315 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.575, ptr @topal.region-instance.namespace-metadata.literal.int.576, ptr %arg1), !dbg !930
  %v316 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v312, i1 %v313, i1 %v314, i1 %v315), !dbg !931
    #dbg_value(i1 %v316, !932, !DIExpression(), !933)
  %v317 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.577, ptr @topal.region-instance.namespace-metadata.literal.int.578, ptr %arg1), !dbg !934
  %v318 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.579, ptr @topal.region-instance.namespace-metadata.literal.int.580, ptr %arg1), !dbg !935
  %v319 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.581, ptr @topal.region-instance.namespace-metadata.literal.int.582, ptr %arg1), !dbg !936
  %v320 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.583, ptr @topal.region-instance.namespace-metadata.literal.int.584, ptr %arg1), !dbg !937
  %v321 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v317, i1 %v318, i1 %v319, i1 %v320), !dbg !938
    #dbg_value(i1 %v321, !939, !DIExpression(), !940)
  %v322 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v6, i1 %v11, i1 %v16, i1 %v21), !dbg !941
    #dbg_value(i1 %v322, !942, !DIExpression(), !943)
  %v323 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v26, i1 %v31, i1 %v36, i1 %v41), !dbg !944
    #dbg_value(i1 %v323, !945, !DIExpression(), !946)
  %v324 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v46, i1 %v51, i1 %v56, i1 %v61), !dbg !947
    #dbg_value(i1 %v324, !948, !DIExpression(), !949)
  %v325 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v66, i1 %v71, i1 %v76, i1 %v81), !dbg !950
    #dbg_value(i1 %v325, !951, !DIExpression(), !952)
  %v326 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v86, i1 %v91, i1 %v96, i1 %v101), !dbg !953
    #dbg_value(i1 %v326, !954, !DIExpression(), !955)
  %v327 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v106, i1 %v111, i1 %v116, i1 %v121), !dbg !956
    #dbg_value(i1 %v327, !957, !DIExpression(), !958)
  %v328 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v126, i1 %v131, i1 %v136, i1 %v141), !dbg !959
    #dbg_value(i1 %v328, !960, !DIExpression(), !961)
  %v329 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v146, i1 %v151, i1 %v156, i1 %v161), !dbg !962
    #dbg_value(i1 %v329, !963, !DIExpression(), !964)
  %v330 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v166, i1 %v171, i1 %v176, i1 %v181), !dbg !965
    #dbg_value(i1 %v330, !966, !DIExpression(), !967)
  %v331 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v186, i1 %v191, i1 %v196, i1 %v201), !dbg !968
    #dbg_value(i1 %v331, !969, !DIExpression(), !970)
  %v332 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v206, i1 %v211, i1 %v216, i1 %v221), !dbg !971
    #dbg_value(i1 %v332, !972, !DIExpression(), !973)
  %v333 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v226, i1 %v231, i1 %v236, i1 %v241), !dbg !974
    #dbg_value(i1 %v333, !975, !DIExpression(), !976)
  %v334 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v246, i1 %v251, i1 %v256, i1 %v261), !dbg !977
    #dbg_value(i1 %v334, !978, !DIExpression(), !979)
  %v335 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v266, i1 %v271, i1 %v276, i1 %v281), !dbg !980
    #dbg_value(i1 %v335, !981, !DIExpression(), !982)
  %v336 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v286, i1 %v291, i1 %v296, i1 %v301), !dbg !983
    #dbg_value(i1 %v336, !984, !DIExpression(), !985)
  %v337 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v306, i1 %v311, i1 %v316, i1 %v321), !dbg !986
    #dbg_value(i1 %v337, !987, !DIExpression(), !988)
  %v338 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v322, i1 %v323, i1 %v324, i1 %v325), !dbg !989
    #dbg_value(i1 %v338, !990, !DIExpression(), !991)
  %v339 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v326, i1 %v327, i1 %v328, i1 %v329), !dbg !992
    #dbg_value(i1 %v339, !993, !DIExpression(), !994)
  %v340 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v330, i1 %v331, i1 %v332, i1 %v333), !dbg !995
    #dbg_value(i1 %v340, !996, !DIExpression(), !997)
  %v341 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v334, i1 %v335, i1 %v336, i1 %v337), !dbg !998
    #dbg_value(i1 %v341, !999, !DIExpression(), !1000)
  %v342 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v338, i1 %v339, i1 %v340, i1 %v341), !dbg !1001
  ret i1 %v342, !dbg !1001
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dnormal.1957(ptr %arg0, ptr %arg1) #1 !dbg !1002 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1003, !DIExpression(), !1004)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1005, !DIExpression(), !1006)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2enot_2ddot.335(ptr %arg0, ptr %arg1), !dbg !1007
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1007

decision.true.0:                                  ; preds = %entry
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dpayload.1956(ptr %arg0, ptr %arg1), !dbg !1008
  br label %decision.merge.2, !dbg !1008

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1009

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v4 = phi i1 [ %v3, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1007
  ret i1 %v4, !dbg !1007
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbounded.1958(ptr %arg0, ptr %arg1) #1 !dbg !1010 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1011, !DIExpression(), !1012)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1013, !DIExpression(), !1014)
  %v2 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.585), !dbg !1015
  %v3 = icmp sle i32 %v2, 0, !dbg !1015
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1015

decision.true.0:                                  ; preds = %entry
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dnormal.1957(ptr %arg0, ptr %arg1), !dbg !1016
  br label %decision.merge.2, !dbg !1016

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1017

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1015
  ret i1 %v5, !dbg !1015
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dinput.1959(ptr %arg0, ptr %arg1) #1 !dbg !1018 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1019, !DIExpression(), !1020)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1021, !DIExpression(), !1022)
  %v2 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.586), !dbg !1023
  %v3 = icmp sgt i32 %v2, 0, !dbg !1023
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1023

decision.true.0:                                  ; preds = %entry
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbounded.1958(ptr %arg0, ptr %arg1), !dbg !1024
  br label %decision.merge.2, !dbg !1024

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1025

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1023
  ret i1 %v5, !dbg !1023
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2einput_2dclean.1962(ptr %arg0, ptr %arg1) #1 !dbg !1026 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1027, !DIExpression(), !1028)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1029, !DIExpression(), !1030)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.587), !dbg !1031
    #dbg_value(i1 %v2, !1032, !DIExpression(), !1033)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.588), !dbg !1034
    #dbg_value(i1 %v3, !1035, !DIExpression(), !1036)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dinput.1959(ptr %arg0, ptr %arg1), !dbg !1037
    #dbg_value(i1 %v4, !1038, !DIExpression(), !1039)
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v2, i1 %v3), !dbg !1040
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v4, i1 %v5), !dbg !1041
  ret i1 %v6, !dbg !1041
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1042 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1043, !DIExpression(), !1044)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1045, !DIExpression(), !1046)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1047, !DIExpression(), !1048)
  %v3 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %arg2, i64 8, i1 false), !dbg !1049
  %v4 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v3), !dbg !1049
  br i1 %v4, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !1049

optional.decision.some.0:                         ; preds = %entry
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v3), !dbg !1050
    #dbg_value(ptr %v5, !1051, !DIExpression(), !1050)
  %v6 = call i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %arg0, ptr %arg1, ptr %v5, i64 8, i1 false), !dbg !1052
  br label %optional.decision.merge.2, !dbg !1052

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !1053

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v7 = phi i1 [ %v6, %optional.decision.some.0 ], [ false, %optional.decision.none.1 ], !dbg !1049
  ret i1 %v7, !dbg !1049
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1054 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1055, !DIExpression(), !1056)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1057, !DIExpression(), !1058)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1059, !DIExpression(), !1060)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1061
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1061

decision.true.0:                                  ; preds = %entry
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.589), !dbg !1062
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.590), !dbg !1063
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970(ptr %arg0, ptr %v4, ptr %v5), !dbg !1064
  br label %decision.merge.2, !dbg !1064

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1065

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1061
  ret i1 %v7, !dbg !1061
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1066 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1067, !DIExpression(), !1068)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1069, !DIExpression(), !1070)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1071, !DIExpression(), !1072)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1073
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1073

decision.true.0:                                  ; preds = %entry
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.591), !dbg !1074
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.592), !dbg !1075
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972(ptr %arg0, ptr %v4, ptr %v5), !dbg !1076
  br label %decision.merge.2, !dbg !1076

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1077

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1073
  ret i1 %v7, !dbg !1073
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1078 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1079, !DIExpression(), !1080)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1081, !DIExpression(), !1082)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1083, !DIExpression(), !1084)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1085
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1085

decision.true.0:                                  ; preds = %entry
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.593), !dbg !1086
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.594), !dbg !1087
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976(ptr %arg0, ptr %v4, ptr %v5), !dbg !1088
  br label %decision.merge.2, !dbg !1088

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1089

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1085
  ret i1 %v7, !dbg !1085
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1090 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1091, !DIExpression(), !1092)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1093, !DIExpression(), !1094)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1095, !DIExpression(), !1096)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1097
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1097

decision.true.0:                                  ; preds = %entry
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.595), !dbg !1098
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.596), !dbg !1099
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984(ptr %arg0, ptr %v4, ptr %v5), !dbg !1100
  br label %decision.merge.2, !dbg !1100

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1101

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1097
  ret i1 %v7, !dbg !1097
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1102 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1103, !DIExpression(), !1104)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1105, !DIExpression(), !1106)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1107, !DIExpression(), !1108)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1109
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1109

decision.true.0:                                  ; preds = %entry
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.597), !dbg !1110
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.598), !dbg !1111
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000(ptr %arg0, ptr %v4, ptr %v5), !dbg !1112
  br label %decision.merge.2, !dbg !1112

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1113

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1109
  ret i1 %v7, !dbg !1109
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1114 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1115, !DIExpression(), !1116)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1117, !DIExpression(), !1118)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1119, !DIExpression(), !1120)
  %v3 = call i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %arg0, ptr %arg1, ptr %arg2, i64 8, i1 false), !dbg !1121
  ret i1 %v3, !dbg !1121
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg1) #1 !dbg !1122 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1123, !DIExpression(), !1124)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1125, !DIExpression(), !1126)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.599, ptr %arg1), !dbg !1127
    #dbg_value(i1 %v2, !1128, !DIExpression(), !1129)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.600, ptr %arg1), !dbg !1130
    #dbg_value(i1 %v3, !1131, !DIExpression(), !1132)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v2, i1 %v3), !dbg !1133
  ret i1 %v4, !dbg !1133
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elink_2deffect.2048(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !1134 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1135, !DIExpression(), !1136)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1137
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1137
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1137
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1137
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1137
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1137
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1137
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1137
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1137
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1137
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1137
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1137
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1137
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1137
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1137
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1137
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1138, !DIExpression(), !1137)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1139, !DIExpression(), !1140)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !1141
    #dbg_value(ptr %v19, !1142, !DIExpression(), !1143)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !1144
    #dbg_value(ptr %v20, !1145, !DIExpression(), !1146)
  %v21 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v6), !dbg !1147
  %v22 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032(ptr %arg0, ptr %v21, ptr @topal.region-instance.namespace-metadata.literal.int.601), !dbg !1148
    #dbg_value(i1 %v22, !1149, !DIExpression(), !1150)
  %v23 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v20, ptr %v3), !dbg !1151
    #dbg_value(i1 %v23, !1152, !DIExpression(), !1153)
  %v24 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.602), !dbg !1154
  %v25 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v24, ptr %v1), !dbg !1155
    #dbg_value(i1 %v25, !1156, !DIExpression(), !1157)
  %v26 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.603), !dbg !1158
  %v27 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.604), !dbg !1159
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v26, ptr %v27), !dbg !1160
    #dbg_value(i1 %v28, !1161, !DIExpression(), !1162)
  %v29 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.605), !dbg !1163
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v29, ptr @topal.region-instance.namespace-metadata.literal.int.606), !dbg !1164
    #dbg_value(i1 %v30, !1165, !DIExpression(), !1166)
  %v31 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.607), !dbg !1167
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v31, ptr %arg2), !dbg !1168
    #dbg_value(i1 %v32, !1169, !DIExpression(), !1170)
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v30, i1 %v32), !dbg !1171
  %v34 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v28, i1 %v33), !dbg !1172
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v25, i1 %v34), !dbg !1173
  %v36 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v23, i1 %v35), !dbg !1174
  %v37 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v36), !dbg !1175
    #dbg_value(i1 %v37, !1176, !DIExpression(), !1177)
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !1178
    #dbg_value(i1 %v38, !1179, !DIExpression(), !1180)
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v37, i1 %v38), !dbg !1181
  ret i1 %v39, !dbg !1181
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2emove_2deffect.2124(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !1182 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1183, !DIExpression(), !1184)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1185
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1185
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1185
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1185
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1185
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1185
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1185
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1185
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1185
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1185
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1185
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1185
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1185
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1185
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1185
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1185
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1186, !DIExpression(), !1185)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1187, !DIExpression(), !1188)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v2), !dbg !1189
    #dbg_value(ptr %v19, !1190, !DIExpression(), !1191)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v2), !dbg !1192
  %v21 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032(ptr %arg0, ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.608), !dbg !1193
    #dbg_value(i1 %v21, !1194, !DIExpression(), !1195)
  %v22 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.609), !dbg !1196
  %v23 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v22, ptr %v1), !dbg !1197
    #dbg_value(i1 %v23, !1198, !DIExpression(), !1199)
  %v24 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !1200
  %v25 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v24, ptr @topal.region-instance.namespace-metadata.literal.int.610), !dbg !1200
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v25, ptr %arg2), !dbg !1201
    #dbg_value(i1 %v26, !1202, !DIExpression(), !1203)
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v23, i1 %v26), !dbg !1204
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v21, i1 %v27), !dbg !1205
    #dbg_value(i1 %v28, !1206, !DIExpression(), !1207)
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !1208
    #dbg_value(i1 %v29, !1209, !DIExpression(), !1210)
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v28, i1 %v29), !dbg !1211
  ret i1 %v30, !dbg !1211
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134(ptr %arg0, ptr %arg1) #1 !dbg !1212 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1213, !DIExpression(), !1214)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1215, !DIExpression(), !1216)
  %v2 = call i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.611, i64 8, i1 false), !dbg !1217
  ret i1 %v2, !dbg !1217
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136(ptr %arg0, ptr %arg1) #1 !dbg !1218 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1219, !DIExpression(), !1220)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1221, !DIExpression(), !1222)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134(ptr %arg0, ptr %arg1), !dbg !1223
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1223

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.612), !dbg !1224
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134(ptr %arg0, ptr %v3), !dbg !1225
  br label %decision.merge.2, !dbg !1225

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1226

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1223
  ret i1 %v5, !dbg !1223
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140(ptr %arg0, ptr %arg1) #1 !dbg !1227 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1228, !DIExpression(), !1229)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1230, !DIExpression(), !1231)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136(ptr %arg0, ptr %arg1), !dbg !1232
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1232

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.613), !dbg !1233
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136(ptr %arg0, ptr %v3), !dbg !1234
  br label %decision.merge.2, !dbg !1234

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1235

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1232
  ret i1 %v5, !dbg !1232
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148(ptr %arg0, ptr %arg1) #1 !dbg !1236 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1237, !DIExpression(), !1238)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1239, !DIExpression(), !1240)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140(ptr %arg0, ptr %arg1), !dbg !1241
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1241

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.614), !dbg !1242
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140(ptr %arg0, ptr %v3), !dbg !1243
  br label %decision.merge.2, !dbg !1243

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1244

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1241
  ret i1 %v5, !dbg !1241
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164(ptr %arg0, ptr %arg1) #1 !dbg !1245 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1246, !DIExpression(), !1247)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1248, !DIExpression(), !1249)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148(ptr %arg0, ptr %arg1), !dbg !1250
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1250

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.615), !dbg !1251
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148(ptr %arg0, ptr %v3), !dbg !1252
  br label %decision.merge.2, !dbg !1252

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1253

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1250
  ret i1 %v5, !dbg !1250
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dname.2196(ptr %arg0, ptr %arg1) #1 !dbg !1254 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1255, !DIExpression(), !1256)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1257, !DIExpression(), !1258)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164(ptr %arg0, ptr %arg1), !dbg !1259
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1259

decision.true.0:                                  ; preds = %entry
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.616), !dbg !1260
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164(ptr %arg0, ptr %v3), !dbg !1261
  br label %decision.merge.2, !dbg !1261

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1262

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v4, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1259
  ret i1 %v5, !dbg !1259
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ereplace_2deffect.2212(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !1263 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1264, !DIExpression(), !1265)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1266
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1266
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1266
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1266
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1266
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1266
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1266
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1266
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1266
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1266
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1266
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1266
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1266
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1266
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1266
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1266
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1267, !DIExpression(), !1266)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1268, !DIExpression(), !1269)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v2), !dbg !1270
    #dbg_value(ptr %v19, !1271, !DIExpression(), !1272)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v8), !dbg !1273
    #dbg_value(ptr %v20, !1274, !DIExpression(), !1275)
  %v21 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.617), !dbg !1276
  %v22 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v21), !dbg !1277
  %v23 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v22, ptr @topal.region-instance.namespace-metadata.literal.int.618), !dbg !1277
  %v24 = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %v23), !dbg !1278
    #dbg_value(ptr %v24, !1279, !DIExpression(), !1280)
  %v25 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !1281
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v25, ptr %v3), !dbg !1282
    #dbg_value(i1 %v26, !1283, !DIExpression(), !1284)
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.619), !dbg !1285
    #dbg_value(i1 %v27, !1286, !DIExpression(), !1287)
  %v28 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.620), !dbg !1288
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v28, ptr @topal.region-instance.namespace-metadata.literal.int.621), !dbg !1289
    #dbg_value(i1 %v29, !1290, !DIExpression(), !1291)
  %v30 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v2), !dbg !1292
  %v31 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dname.2196(ptr %arg0, ptr %v30), !dbg !1293
    #dbg_value(i1 %v31, !1294, !DIExpression(), !1295)
  %v32 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.622), !dbg !1296
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v32, ptr %v24), !dbg !1297
    #dbg_value(i1 %v33, !1298, !DIExpression(), !1299)
  %v34 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.623), !dbg !1300
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v34, ptr %arg2), !dbg !1301
    #dbg_value(i1 %v35, !1302, !DIExpression(), !1303)
  %v36 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !1304
  %v37 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v36, ptr @topal.region-instance.namespace-metadata.literal.int.624), !dbg !1304
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v37, ptr %arg2), !dbg !1305
    #dbg_value(i1 %v38, !1306, !DIExpression(), !1307)
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v35, i1 %v38), !dbg !1308
  %v40 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v33, i1 %v39), !dbg !1309
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v31, i1 %v40), !dbg !1310
  %v42 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v29, i1 %v41), !dbg !1311
  %v43 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v27, i1 %v42), !dbg !1312
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v26, i1 %v43), !dbg !1313
    #dbg_value(i1 %v44, !1314, !DIExpression(), !1315)
  %v45 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !1316
    #dbg_value(i1 %v45, !1317, !DIExpression(), !1318)
  %v46 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v44, i1 %v45), !dbg !1319
  ret i1 %v46, !dbg !1319
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eexchange_2deffect.2229(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) #1 !dbg !1320 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1321, !DIExpression(), !1322)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1323
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1323
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1323
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1323
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1323
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1323
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1323
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1323
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1323
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1323
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1323
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1323
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1323
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1323
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1323
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1323
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1324, !DIExpression(), !1323)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1325, !DIExpression(), !1326)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v2), !dbg !1327
    #dbg_value(ptr %v19, !1328, !DIExpression(), !1329)
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v19, ptr %v7), !dbg !1330
    #dbg_value(i1 %v20, !1331, !DIExpression(), !1332)
  %v21 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !1333
  %v22 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v21, ptr %v3), !dbg !1334
    #dbg_value(i1 %v22, !1335, !DIExpression(), !1336)
  %v23 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !1337
  %v24 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v23, ptr @topal.region-instance.namespace-metadata.literal.int.625), !dbg !1337
  %v25 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v24, ptr %arg2), !dbg !1338
    #dbg_value(i1 %v25, !1339, !DIExpression(), !1340)
  %v26 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v8), !dbg !1341
  %v27 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v26, ptr @topal.region-instance.namespace-metadata.literal.int.626), !dbg !1341
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v27, ptr %arg2), !dbg !1342
    #dbg_value(i1 %v28, !1343, !DIExpression(), !1344)
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v25, i1 %v28), !dbg !1345
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v29), !dbg !1346
  %v31 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v20, i1 %v30), !dbg !1347
    #dbg_value(i1 %v31, !1348, !DIExpression(), !1349)
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !1350
    #dbg_value(i1 %v32, !1351, !DIExpression(), !1352)
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v31, i1 %v32), !dbg !1353
  ret i1 %v33, !dbg !1353
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2dreplace_2dor_2dexchange.2230(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) #1 !dbg !1354 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1357, !DIExpression(), !1358)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1359
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1359
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1359
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1359
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1359
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1359
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1359
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1359
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1359
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1359
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1359
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1359
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1359
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1359
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1359
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1359
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1360, !DIExpression(), !1359)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1361, !DIExpression(), !1362)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !1363, !DIExpression(), !1364)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.627), !dbg !1365
  %v21 = icmp eq i32 %v20, 0, !dbg !1365
  %v22 = icmp eq i1 %v21, true, !dbg !1365
  br i1 %v22, label %decision.true.0, label %decision.false.1, !dbg !1365

decision.true.0:                                  ; preds = %entry
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1366
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v2, 1, !dbg !1366
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v3, 2, !dbg !1366
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v4, 3, !dbg !1366
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v5, 4, !dbg !1366
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v6, 5, !dbg !1366
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v7, 6, !dbg !1366
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 7, !dbg !1366
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v9, 8, !dbg !1366
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v10, 9, !dbg !1366
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v11, 10, !dbg !1366
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v12, 11, !dbg !1366
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v13, 12, !dbg !1366
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v14, 13, !dbg !1366
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v15, 14, !dbg !1366
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v16, 15, !dbg !1366
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ereplace_2deffect.2212(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, ptr %arg3), !dbg !1366
  br label %decision.merge.2, !dbg !1366

decision.false.1:                                 ; preds = %entry
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1367
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v2, 1, !dbg !1367
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v3, 2, !dbg !1367
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v4, 3, !dbg !1367
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v5, 4, !dbg !1367
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v6, 5, !dbg !1367
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v7, 6, !dbg !1367
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 7, !dbg !1367
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v9, 8, !dbg !1367
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v10, 9, !dbg !1367
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v11, 10, !dbg !1367
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v12, 11, !dbg !1367
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v13, 12, !dbg !1367
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v14, 13, !dbg !1367
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v15, 14, !dbg !1367
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v16, 15, !dbg !1367
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eexchange_2deffect.2229(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, ptr %arg3), !dbg !1367
  br label %decision.merge.2, !dbg !1367

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v57 = phi i1 [ %v39, %decision.true.0 ], [ %v56, %decision.false.1 ], !dbg !1365
  ret i1 %v57, !dbg !1365
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2drename.2231(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) #1 !dbg !1368 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1369, !DIExpression(), !1370)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1371
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1371
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1371
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1371
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1371
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1371
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1371
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1371
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1371
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1371
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1371
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1371
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1371
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1371
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1371
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1371
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1372, !DIExpression(), !1371)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1373, !DIExpression(), !1374)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !1375, !DIExpression(), !1376)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.628), !dbg !1377
  %v21 = icmp eq i32 %v20, 0, !dbg !1377
  %v22 = icmp eq i1 %v21, true, !dbg !1377
  br i1 %v22, label %decision.true.0, label %decision.false.1, !dbg !1377

decision.true.0:                                  ; preds = %entry
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1378
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v2, 1, !dbg !1378
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v3, 2, !dbg !1378
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v4, 3, !dbg !1378
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v5, 4, !dbg !1378
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v6, 5, !dbg !1378
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v7, 6, !dbg !1378
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 7, !dbg !1378
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v9, 8, !dbg !1378
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v10, 9, !dbg !1378
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v11, 10, !dbg !1378
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v12, 11, !dbg !1378
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v13, 12, !dbg !1378
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v14, 13, !dbg !1378
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v15, 14, !dbg !1378
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v16, 15, !dbg !1378
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2emove_2deffect.2124(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, ptr %arg3), !dbg !1378
  br label %decision.merge.2, !dbg !1378

decision.false.1:                                 ; preds = %entry
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1379
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v2, 1, !dbg !1379
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v3, 2, !dbg !1379
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v4, 3, !dbg !1379
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v5, 4, !dbg !1379
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v6, 5, !dbg !1379
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v7, 6, !dbg !1379
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 7, !dbg !1379
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v9, 8, !dbg !1379
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v10, 9, !dbg !1379
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v11, 10, !dbg !1379
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v12, 11, !dbg !1379
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v13, 12, !dbg !1379
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v14, 13, !dbg !1379
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v15, 14, !dbg !1379
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v16, 15, !dbg !1379
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2dreplace_2dor_2dexchange.2230(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, ptr %arg2, ptr %arg3), !dbg !1379
  br label %decision.merge.2, !dbg !1379

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v57 = phi i1 [ %v39, %decision.true.0 ], [ %v56, %decision.false.1 ], !dbg !1377
  ret i1 %v57, !dbg !1377
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect.2232(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) #1 !dbg !1380 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1381, !DIExpression(), !1382)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1383
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1383
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1383
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1383
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1383
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1383
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1383
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1383
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1383
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1383
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1383
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1383
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1383
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1383
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1383
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1383
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1384, !DIExpression(), !1383)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1385, !DIExpression(), !1386)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !1387, !DIExpression(), !1388)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.629), !dbg !1389
  %v21 = icmp eq i32 %v20, 0, !dbg !1389
  %v22 = icmp eq i1 %v21, true, !dbg !1389
  br i1 %v22, label %decision.true.0, label %decision.false.1, !dbg !1389

decision.true.0:                                  ; preds = %entry
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1390
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v2, 1, !dbg !1390
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v3, 2, !dbg !1390
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v4, 3, !dbg !1390
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v5, 4, !dbg !1390
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v6, 5, !dbg !1390
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v7, 6, !dbg !1390
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 7, !dbg !1390
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v9, 8, !dbg !1390
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v10, 9, !dbg !1390
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v11, 10, !dbg !1390
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v12, 11, !dbg !1390
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v13, 12, !dbg !1390
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v14, 13, !dbg !1390
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v15, 14, !dbg !1390
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v16, 15, !dbg !1390
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elink_2deffect.2048(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, ptr %arg3), !dbg !1390
  br label %decision.merge.2, !dbg !1390

decision.false.1:                                 ; preds = %entry
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1391
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v2, 1, !dbg !1391
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v3, 2, !dbg !1391
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v4, 3, !dbg !1391
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v5, 4, !dbg !1391
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v6, 5, !dbg !1391
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v7, 6, !dbg !1391
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 7, !dbg !1391
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v9, 8, !dbg !1391
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v10, 9, !dbg !1391
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v11, 10, !dbg !1391
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v12, 11, !dbg !1391
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v13, 12, !dbg !1391
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v14, 13, !dbg !1391
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v15, 14, !dbg !1391
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v16, 15, !dbg !1391
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2drename.2231(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, ptr %arg2, ptr %arg3), !dbg !1391
  br label %decision.merge.2, !dbg !1391

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v57 = phi i1 [ %v39, %decision.true.0 ], [ %v56, %decision.false.1 ], !dbg !1389
  ret i1 %v57, !dbg !1389
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2echecked.2233(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) #1 !dbg !1392 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1393, !DIExpression(), !1394)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1395
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1395
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1395
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1395
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1395
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1395
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1395
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1395
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1395
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1395
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1395
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1395
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1395
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1395
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1395
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1395
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1396, !DIExpression(), !1395)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1397, !DIExpression(), !1398)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !1399, !DIExpression(), !1400)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.630), !dbg !1401
  %v21 = icmp eq i32 %v20, 0, !dbg !1401
  %v22 = icmp ne i1 %v21, true, !dbg !1401
  %v23 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %v2), !dbg !1402
  %v24 = icmp eq i32 %v23, 0, !dbg !1402
  %v25 = icmp eq i1 %v24, true, !dbg !1402
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v25), !dbg !1403
  %v27 = xor i1 %v26, true, !dbg !1404
    #dbg_value(i1 %v27, !1405, !DIExpression(), !1406)
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1407
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v2, 1, !dbg !1407
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v3, 2, !dbg !1407
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, ptr %v4, 3, !dbg !1407
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, ptr %v5, 4, !dbg !1407
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, ptr %v6, 5, !dbg !1407
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, ptr %v7, 6, !dbg !1407
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, ptr %v8, 7, !dbg !1407
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v9, 8, !dbg !1407
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v10, 9, !dbg !1407
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v11, 10, !dbg !1407
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, i32 %v12, 11, !dbg !1407
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, i32 %v13, 12, !dbg !1407
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, i32 %v14, 13, !dbg !1407
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, i32 %v15, 14, !dbg !1407
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, i32 %v16, 15, !dbg !1407
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dvalid.98(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %arg2), !dbg !1407
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1408
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v2, 1, !dbg !1408
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v3, 2, !dbg !1408
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, ptr %v4, 3, !dbg !1408
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, ptr %v5, 4, !dbg !1408
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, ptr %v6, 5, !dbg !1408
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, ptr %v7, 6, !dbg !1408
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, ptr %v8, 7, !dbg !1408
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v9, 8, !dbg !1408
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v10, 9, !dbg !1408
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v11, 10, !dbg !1408
  %v56 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, i32 %v12, 11, !dbg !1408
  %v57 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v56, i32 %v13, 12, !dbg !1408
  %v58 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v57, i32 %v14, 13, !dbg !1408
  %v59 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v58, i32 %v15, 14, !dbg !1408
  %v60 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v59, i32 %v16, 15, !dbg !1408
  %v61 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dvalid.259(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v60, ptr %arg2), !dbg !1408
  %v62 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2einput_2dclean.1962(ptr %arg0, ptr %v1), !dbg !1409
  %v63 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v44, i1 %v61, i1 %v62, i1 %v27), !dbg !1410
    #dbg_value(i1 %v63, !1411, !DIExpression(), !1412)
  br i1 %v63, label %decision.true.0, label %decision.false.1, !dbg !1413

decision.true.0:                                  ; preds = %entry
  %v64 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !1414
  %v65 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v64, ptr %v2, 1, !dbg !1414
  %v66 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v65, ptr %v3, 2, !dbg !1414
  %v67 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v66, ptr %v4, 3, !dbg !1414
  %v68 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v67, ptr %v5, 4, !dbg !1414
  %v69 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v68, ptr %v6, 5, !dbg !1414
  %v70 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v69, ptr %v7, 6, !dbg !1414
  %v71 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v70, ptr %v8, 7, !dbg !1414
  %v72 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v71, i32 %v9, 8, !dbg !1414
  %v73 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v72, i32 %v10, 9, !dbg !1414
  %v74 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v73, i32 %v11, 10, !dbg !1414
  %v75 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v74, i32 %v12, 11, !dbg !1414
  %v76 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v75, i32 %v13, 12, !dbg !1414
  %v77 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v76, i32 %v14, 13, !dbg !1414
  %v78 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v77, i32 %v15, 14, !dbg !1414
  %v79 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v78, i32 %v16, 15, !dbg !1414
  %v80 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect.2232(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v79, ptr %arg2, ptr %arg3), !dbg !1414
  br label %decision.merge.2, !dbg !1414

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1415

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v81 = phi i1 [ %v80, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1413
  ret i1 %v81, !dbg !1413
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eread_2dinput.2234(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1416 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1417, !DIExpression(), !1418)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1419, !DIExpression(), !1420)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1421, !DIExpression(), !1422)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.631), !dbg !1423
  %v4 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.632), !dbg !1424
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.633), !dbg !1425
  %v6 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.634), !dbg !1426
  %v7 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.635), !dbg !1427
  %v8 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.636), !dbg !1428
  %v9 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.637), !dbg !1429
  %v10 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.638), !dbg !1430
  %v11 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v7, 0, !dbg !1431
  %v12 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v11, ptr %v4, 1, !dbg !1431
  %v13 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v12, ptr %v8, 2, !dbg !1431
  %v14 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v13, ptr %v10, 3, !dbg !1431
  %v15 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v14, ptr %v3, 4, !dbg !1431
  %v16 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v15, ptr %v6, 5, !dbg !1431
  %v17 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v16, ptr %v9, 6, !dbg !1431
  %v18 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v17, ptr %v5, 7, !dbg !1431
  %v19 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v18, i32 4, 8, !dbg !1431
  %v20 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v19, i32 1, 9, !dbg !1431
  %v21 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v20, i32 7, 10, !dbg !1431
  %v22 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v21, i32 5, 11, !dbg !1431
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v22, i32 0, 12, !dbg !1431
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, i32 2, 13, !dbg !1431
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, i32 6, 14, !dbg !1431
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, i32 3, 15, !dbg !1431
  %v27 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8, !dbg !1431
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v27, align 8, !dbg !1431
    #dbg_declare(ptr %v27, !1432, !DIExpression(), !1431)
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v7, 0, !dbg !1433
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v4, 1, !dbg !1433
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 2, !dbg !1433
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, ptr %v10, 3, !dbg !1433
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, ptr %v3, 4, !dbg !1433
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, ptr %v6, 5, !dbg !1433
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, ptr %v9, 6, !dbg !1433
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, ptr %v5, 7, !dbg !1433
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 4, 8, !dbg !1433
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 1, 9, !dbg !1433
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 7, 10, !dbg !1433
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, i32 5, 11, !dbg !1433
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, i32 0, 12, !dbg !1433
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, i32 2, 13, !dbg !1433
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, i32 6, 14, !dbg !1433
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, i32 3, 15, !dbg !1433
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eindex_2dshape.36({ ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %arg1), !dbg !1433
  br i1 %v44, label %decision.true.0, label %decision.false.1, !dbg !1433

decision.true.0:                                  ; preds = %entry
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v7, 0, !dbg !1434
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v4, 1, !dbg !1434
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 2, !dbg !1434
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, ptr %v10, 3, !dbg !1434
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, ptr %v3, 4, !dbg !1434
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, ptr %v6, 5, !dbg !1434
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, ptr %v9, 6, !dbg !1434
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, ptr %v5, 7, !dbg !1434
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 4, 8, !dbg !1434
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 1, 9, !dbg !1434
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 7, 10, !dbg !1434
  %v56 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, i32 5, 11, !dbg !1434
  %v57 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v56, i32 0, 12, !dbg !1434
  %v58 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v57, i32 2, 13, !dbg !1434
  %v59 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v58, i32 6, 14, !dbg !1434
  %v60 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v59, i32 3, 15, !dbg !1434
  %v61 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2echecked.2233(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v60, ptr %arg1, ptr %arg2), !dbg !1434
  br label %decision.merge.2, !dbg !1434

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1435

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v62 = phi i1 [ %v61, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1433
  ret i1 %v62, !dbg !1433
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eapply.2235(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1436 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1437, !DIExpression(), !1438)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1439, !DIExpression(), !1440)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1441, !DIExpression(), !1442)
  %v3 = call ptr @topal.region-instance.namespace-metadata.primitive.count(ptr %arg0), !dbg !1443
    #dbg_value(ptr %v3, !1444, !DIExpression(), !1445)
  %v4 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.639), !dbg !1446
  %v5 = icmp sge i32 %v4, 0, !dbg !1446
  %v6 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.640), !dbg !1447
  %v7 = icmp sle i32 %v6, 0, !dbg !1447
  %v8 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.641), !dbg !1448
  %v9 = icmp sle i32 %v8, 0, !dbg !1448
  %v10 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.642), !dbg !1449
  %v11 = icmp sle i32 %v10, 0, !dbg !1449
  %v12 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v5, i1 %v7, i1 %v9, i1 %v11), !dbg !1450
    #dbg_value(i1 %v12, !1451, !DIExpression(), !1452)
  br i1 %v12, label %decision.true.0, label %decision.false.1, !dbg !1453

decision.true.0:                                  ; preds = %entry
  %v13 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eread_2dinput.2234(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1454
  br label %decision.merge.2, !dbg !1454

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !1455

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v14 = phi i1 [ %v13, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !1453
  ret i1 %v14, !dbg !1453
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.apply.2236(ptr %arg0, ptr %arg1, ptr %arg2) #1 !dbg !1456 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1457, !DIExpression(), !1458)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1459, !DIExpression(), !1460)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1461, !DIExpression(), !1462)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eapply.2235(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1463
  ret i1 %v3, !dbg !1463
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define i64 @topal_kernel_region_frame_namespace_metadata_apply_v1(ptr %control, i64 %expected.owner, i64 %next.epoch, ptr %frame.words, i64 %frame.word.count) #1 {
entry:
  %frame.arity.valid = icmp eq i64 %frame.word.count, 2
  br i1 %frame.arity.valid, label %frame.control, label %invalid

frame.control:                                    ; preds = %entry
  %address = ptrtoint ptr %control to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %control.end = add i64 %address, 64
  %control.extent.valid = icmp uge i64 %control.end, %address
  %pointer.valid = and i1 %nonnull, %aligned
  %control.valid = and i1 %pointer.valid, %control.extent.valid
  br i1 %control.valid, label %fields, label %invalid

fields:                                           ; preds = %frame.control
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_namespace_metadata_apply_v1
  %owner.nonzero = icmp ne i64 %owner, 0
  %owner.matches = icmp eq i64 %owner, %expected.owner
  %owner.valid = and i1 %owner.nonzero, %owner.matches
  %epoch.bounded = icmp ne i64 %epoch, -1
  %successor = add i64 %epoch, 1
  %epoch.matches = icmp eq i64 %successor, %next.epoch
  %epoch.valid = and i1 %epoch.bounded, %epoch.matches
  %active.valid = icmp eq i64 %active, 0
  %issued.valid = icmp eq i64 %issued, 0
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %base.address = ptrtoint ptr %base to i64
  %base.valid = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %below.control = icmp ule i64 %end, %address
  %above.control = icmp uge i64 %base.address, %control.end
  %disjoint = or i1 %below.control, %above.control
  %a = and i1 %code.valid, %owner.valid
  %b = and i1 %epoch.valid, %active.valid
  %c = and i1 %issued.valid, %count.valid
  %d = and i1 %rights.valid, %base.valid
  %e = and i1 %end.valid, %disjoint
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %abcd = and i1 %ab, %cd
  %valid = and i1 %abcd, %e
  br i1 %valid, label %frame.bounds, label %invalid

frame.bounds:                                     ; preds = %fields
  %frame.address = ptrtoint ptr %frame.words to i64
  %frame.nonnull = icmp ne i64 %frame.address, 0
  %frame.alignment = and i64 %frame.address, 7
  %frame.aligned = icmp eq i64 %frame.alignment, 0
  %frame.end = add i64 %frame.address, 16
  %frame.extent.valid = icmp uge i64 %frame.end, %frame.address
  %frame.below.control = icmp ule i64 %frame.end, %address
  %frame.above.control = icmp uge i64 %frame.address, %control.end
  %frame.control.disjoint = or i1 %frame.below.control, %frame.above.control
  %frame.below.owner = icmp ule i64 %frame.end, %base.address
  %frame.above.owner = icmp uge i64 %frame.address, %end
  %frame.owner.disjoint = or i1 %frame.below.owner, %frame.above.owner
  %frame.pointer.valid = and i1 %frame.nonnull, %frame.aligned
  %frame.storage.valid = and i1 %frame.extent.valid, %frame.control.disjoint
  %frame.nonoverlapping = and i1 %frame.storage.valid, %frame.owner.disjoint
  %frame.valid = and i1 %frame.pointer.valid, %frame.nonoverlapping
  br i1 %frame.valid, label %prepare, label %invalid

prepare:                                          ; preds = %frame.bounds
  store i64 %next.epoch, ptr %epoch.pointer, align 8
  store i64 1, ptr %active.pointer, align 8
  store i64 1, ptr %issued.pointer, align 8
  %view = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 64)
  %v0 = insertvalue %topal.KernelRegionView zeroinitializer, ptr %control, 0
  %v1 = insertvalue %topal.KernelRegionView %v0, i64 %count, 2
  %v2 = insertvalue %topal.KernelRegionView %v1, i64 %rights, 3
  %v3 = insertvalue %topal.KernelRegionView %v2, i64 %next.epoch, 4
  %v4 = insertvalue %topal.KernelRegionView %v3, i64 %owner, 5
  %v5 = insertvalue %topal.KernelRegionView %v4, ptr @topal_kernel_region_frame_namespace_metadata_apply_v1, 6
  store %topal.KernelRegionView %v5, ptr %view, align 8
  %frame.word.pointer.0 = getelementptr i64, ptr %frame.words, i64 0
  %frame.word.0 = load i64, ptr %frame.word.pointer.0, align 8
  %frame.value.0 = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %frame.word.0)
  %frame.word.pointer.1 = getelementptr i64, ptr %frame.words, i64 1
  %frame.word.1 = load i64, ptr %frame.word.pointer.1, align 8
  %frame.value.1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %frame.word.1)
  %accepted = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.apply.2236(ptr %view, ptr %frame.value.0, ptr %frame.value.1)
  %final.view = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  store ptr null, ptr %control, align 8
  store i64 0, ptr %owner.pointer, align 8
  store i64 0, ptr %active.pointer, align 8
  store ptr null, ptr %base.pointer, align 8
  store i64 0, ptr %count.pointer, align 8
  store i64 0, ptr %rights.pointer, align 8
  store i64 0, ptr %issued.pointer, align 8
  %result = zext i1 %accepted to i64
  ret i64 %result

invalid:                                          ; preds = %frame.bounds, %fields, %frame.control, %entry
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}

attributes #0 = { noimplicitfloat noinline noredzone nounwind optnone "disable-tail-calls"="true" }
attributes #1 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #2 = { noreturn }
attributes #3 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "namespace-action.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "support.namespace-metadata.both", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0", scope: !7, file: !7, line: 14, type: !8, scopeLine: 14, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DIFile(filename: "namespace-metadata.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !10, !10}
!10 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!11 = !DILocalVariable(name: "first", arg: 1, scope: !6, file: !7, line: 14, type: !10)
!12 = !DILocation(line: 14, column: 14, scope: !6)
!13 = !DILocalVariable(name: "second", arg: 2, scope: !6, file: !7, line: 14, type: !10)
!14 = !DILocation(line: 14, column: 31, scope: !6)
!15 = !DILocation(line: 15, column: 3, scope: !6)
!16 = !DILocation(line: 16, column: 15, scope: !6)
!17 = !DILocation(line: 17, column: 16, scope: !6)
!18 = distinct !DISubprogram(name: "support.namespace-metadata.four", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3", scope: !7, file: !7, line: 19, type: !19, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !0)
!19 = !DISubroutineType(types: !20)
!20 = !{!10, !10, !10, !10, !10}
!21 = !DILocalVariable(name: "first", arg: 1, scope: !18, file: !7, line: 19, type: !10)
!22 = !DILocation(line: 19, column: 14, scope: !18)
!23 = !DILocalVariable(name: "second", arg: 2, scope: !18, file: !7, line: 19, type: !10)
!24 = !DILocation(line: 19, column: 31, scope: !18)
!25 = !DILocalVariable(name: "third", arg: 3, scope: !18, file: !7, line: 19, type: !10)
!26 = !DILocation(line: 19, column: 49, scope: !18)
!27 = !DILocalVariable(name: "fourth", arg: 4, scope: !18, file: !7, line: 19, type: !10)
!28 = !DILocation(line: 19, column: 66, scope: !18)
!29 = !DILocation(line: 20, column: 9, scope: !18)
!30 = !DILocation(line: 20, column: 31, scope: !18)
!31 = !DILocation(line: 20, column: 3, scope: !18)
!32 = distinct !DISubprogram(name: "support.namespace-bytes.word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4", scope: !33, file: !33, line: 3, type: !34, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !0)
!33 = !DIFile(filename: "namespace-bytes.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!34 = !DISubroutineType(types: !35)
!35 = !{!36, !43, !36}
!36 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !37)
!37 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 64, align: 64)
!38 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !39)
!39 = !{!40, !42}
!40 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !41, size: 64, align: 64)
!41 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !41, size: 64, align: 64, offset: 64)
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "KernelByteRegion", file: !1, baseType: !44)
!44 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64, align: 64)
!45 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalKernelRegionBorrow", flags: DIFlagFwdDecl)
!46 = !DILocalVariable(name: "region", arg: 1, scope: !32, file: !33, line: 3, type: !43)
!47 = !DILocation(line: 3, column: 18, scope: !32)
!48 = !DILocalVariable(name: "offset", arg: 2, scope: !32, file: !33, line: 3, type: !36)
!49 = !DILocation(line: 3, column: 45, scope: !32)
!50 = !DILocation(line: 4, column: 3, scope: !32)
!51 = !DILocation(line: 5, column: 10, scope: !32)
!52 = !DILocalVariable(name: "value", scope: !32, file: !33, line: 5, type: !36)
!53 = !DILocation(line: 5, column: 21, scope: !32)
!54 = !DILocation(line: 6, column: 15, scope: !32)
!55 = distinct !DISubprogram(name: "support.namespace-metadata.word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5", scope: !7, file: !7, line: 8, type: !34, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!56 = !DILocalVariable(name: "region", arg: 1, scope: !55, file: !7, line: 8, type: !43)
!57 = !DILocation(line: 8, column: 14, scope: !55)
!58 = !DILocalVariable(name: "offset", arg: 2, scope: !55, file: !7, line: 8, type: !36)
!59 = !DILocation(line: 8, column: 41, scope: !55)
!60 = !DILocation(line: 9, column: 3, scope: !55)
!61 = distinct !DISubprogram(name: "support.namespace-metadata.index-shape", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eindex_2dshape.36", scope: !7, file: !7, line: 89, type: !62, scopeLine: 89, spFlags: DISPFlagDefinition, unit: !0)
!62 = !DISubroutineType(types: !63)
!63 = !{!10, !64, !36}
!64 = !DICompositeType(tag: DW_TAG_structure_type, name: "(length : Nat, source-entry : Nat, source-identity : Nat, source-links : Nat, source-object : Nat, target-entry : Nat, target-identity : Nat, target-object : Nat)", file: !1, size: 768, align: 64, elements: !65)
!65 = !{!66, !67, !68, !69, !70, !71, !72, !73}
!66 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !36, size: 64, align: 64)
!67 = !DIDerivedType(tag: DW_TAG_member, name: "source-entry", file: !1, baseType: !36, size: 64, align: 64, offset: 64)
!68 = !DIDerivedType(tag: DW_TAG_member, name: "source-identity", file: !1, baseType: !36, size: 64, align: 64, offset: 128)
!69 = !DIDerivedType(tag: DW_TAG_member, name: "source-links", file: !1, baseType: !36, size: 64, align: 64, offset: 192)
!70 = !DIDerivedType(tag: DW_TAG_member, name: "source-object", file: !1, baseType: !36, size: 64, align: 64, offset: 256)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "target-entry", file: !1, baseType: !36, size: 64, align: 64, offset: 320)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "target-identity", file: !1, baseType: !36, size: 64, align: 64, offset: 384)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "target-object", file: !1, baseType: !36, size: 64, align: 64, offset: 448)
!74 = !DILocation(line: 89, column: 21, scope: !61)
!75 = !DILocalVariable(name: "facts", arg: 1, scope: !61, file: !7, line: 89, type: !64)
!76 = !DILocalVariable(name: "operation", arg: 2, scope: !61, file: !7, line: 89, type: !36)
!77 = !DILocation(line: 89, column: 200, scope: !61)
!78 = !DILocation(line: 90, column: 19, scope: !61)
!79 = !DILocation(line: 90, column: 42, scope: !61)
!80 = !DILocation(line: 90, column: 69, scope: !61)
!81 = !DILocation(line: 90, column: 35, scope: !61)
!82 = !DILocation(line: 90, column: 13, scope: !61)
!83 = !DILocalVariable(name: "absent", scope: !61, file: !7, line: 90, type: !10)
!84 = !DILocation(line: 90, column: 3, scope: !61)
!85 = !DILocation(line: 91, column: 23, scope: !61)
!86 = !DILocation(line: 91, column: 50, scope: !61)
!87 = !DILocation(line: 91, column: 98, scope: !61)
!88 = !DILocation(line: 91, column: 128, scope: !61)
!89 = !DILocation(line: 91, column: 16, scope: !61)
!90 = !DILocalVariable(name: "different", scope: !61, file: !7, line: 91, type: !10)
!91 = !DILocation(line: 91, column: 3, scope: !61)
!92 = !DILocation(line: 92, column: 20, scope: !61)
!93 = !DILocation(line: 92, column: 14, scope: !61)
!94 = !DILocalVariable(name: "present", scope: !61, file: !7, line: 92, type: !10)
!95 = !DILocation(line: 92, column: 3, scope: !61)
!96 = !DILocation(line: 93, column: 24, scope: !61)
!97 = !DILocation(line: 93, column: 36, scope: !61)
!98 = !DILocation(line: 93, column: 18, scope: !61)
!99 = !DILocation(line: 93, column: 13, scope: !61)
!100 = !DILocalVariable(name: "target", scope: !61, file: !7, line: 93, type: !10)
!101 = !DILocation(line: 93, column: 3, scope: !61)
!102 = !DILocation(line: 94, column: 20, scope: !61)
!103 = !DILocation(line: 94, column: 47, scope: !61)
!104 = !DILocation(line: 94, column: 74, scope: !61)
!105 = !DILocation(line: 94, column: 104, scope: !61)
!106 = !DILocation(line: 94, column: 13, scope: !61)
!107 = !DILocalVariable(name: "source", scope: !61, file: !7, line: 94, type: !10)
!108 = !DILocation(line: 94, column: 3, scope: !61)
!109 = !DILocation(line: 95, column: 26, scope: !61)
!110 = !DILocation(line: 95, column: 51, scope: !61)
!111 = !DILocation(line: 95, column: 3, scope: !61)
!112 = distinct !DISubprogram(name: "support.namespace-metadata.object-base", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38", scope: !7, file: !7, line: 22, type: !113, scopeLine: 22, spFlags: DISPFlagDefinition, unit: !0)
!113 = !DISubroutineType(types: !114)
!114 = !{!36, !36}
!115 = !DILocalVariable(name: "slot", arg: 1, scope: !112, file: !7, line: 22, type: !36)
!116 = !DILocation(line: 22, column: 20, scope: !112)
!117 = !DILocation(line: 23, column: 10, scope: !112)
!118 = !DILocation(line: 23, column: 3, scope: !112)
!119 = distinct !DISubprogram(name: "support.namespace-metadata.count-association", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43", scope: !7, file: !7, line: 31, type: !120, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !0)
!120 = !DISubroutineType(types: !121)
!121 = !{!36, !43, !36, !36}
!122 = !DILocalVariable(name: "region", arg: 1, scope: !119, file: !7, line: 31, type: !43)
!123 = !DILocation(line: 31, column: 27, scope: !119)
!124 = !DILocalVariable(name: "offset", arg: 2, scope: !119, file: !7, line: 31, type: !36)
!125 = !DILocation(line: 31, column: 54, scope: !119)
!126 = !DILocalVariable(name: "identity", arg: 3, scope: !119, file: !7, line: 31, type: !36)
!127 = !DILocation(line: 31, column: 68, scope: !119)
!128 = !DILocation(line: 32, column: 4, scope: !119)
!129 = !DILocation(line: 33, column: 15, scope: !119)
!130 = !DILocation(line: 34, column: 16, scope: !119)
!131 = distinct !DISubprogram(name: "support.namespace-metadata.links", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59", scope: !7, file: !7, line: 36, type: !34, scopeLine: 36, spFlags: DISPFlagDefinition, unit: !0)
!132 = !DILocalVariable(name: "region", arg: 1, scope: !131, file: !7, line: 36, type: !43)
!133 = !DILocation(line: 36, column: 15, scope: !131)
!134 = !DILocalVariable(name: "identity", arg: 2, scope: !131, file: !7, line: 36, type: !36)
!135 = !DILocation(line: 36, column: 42, scope: !131)
!136 = !DILocation(line: 37, column: 13, scope: !131)
!137 = !DILocalVariable(name: "seen-0", scope: !131, file: !7, line: 37, type: !36)
!138 = !DILocation(line: 37, column: 3, scope: !131)
!139 = !DILocation(line: 38, column: 13, scope: !131)
!140 = !DILocalVariable(name: "seen-1", scope: !131, file: !7, line: 38, type: !36)
!141 = !DILocation(line: 38, column: 3, scope: !131)
!142 = !DILocation(line: 39, column: 13, scope: !131)
!143 = !DILocalVariable(name: "seen-2", scope: !131, file: !7, line: 39, type: !36)
!144 = !DILocation(line: 39, column: 3, scope: !131)
!145 = !DILocation(line: 40, column: 13, scope: !131)
!146 = !DILocalVariable(name: "seen-3", scope: !131, file: !7, line: 40, type: !36)
!147 = !DILocation(line: 40, column: 3, scope: !131)
!148 = !DILocation(line: 41, column: 3, scope: !131)
!149 = distinct !DISubprogram(name: "support.namespace-metadata.regular", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78", scope: !7, file: !7, line: 43, type: !150, scopeLine: 43, spFlags: DISPFlagDefinition, unit: !0)
!150 = !DISubroutineType(types: !151)
!151 = !{!10, !43, !36, !36}
!152 = !DILocalVariable(name: "region", arg: 1, scope: !149, file: !7, line: 43, type: !43)
!153 = !DILocation(line: 43, column: 17, scope: !149)
!154 = !DILocalVariable(name: "base", arg: 2, scope: !149, file: !7, line: 43, type: !36)
!155 = !DILocation(line: 43, column: 44, scope: !149)
!156 = !DILocalVariable(name: "identity", arg: 3, scope: !149, file: !7, line: 43, type: !36)
!157 = !DILocation(line: 43, column: 56, scope: !149)
!158 = !DILocation(line: 44, column: 25, scope: !149)
!159 = !DILocation(line: 44, column: 11, scope: !149)
!160 = !DILocalVariable(name: "mode", scope: !149, file: !7, line: 44, type: !36)
!161 = !DILocation(line: 44, column: 3, scope: !149)
!162 = !DILocation(line: 45, column: 10, scope: !149)
!163 = !DILocation(line: 45, column: 51, scope: !149)
!164 = !DILocation(line: 45, column: 37, scope: !149)
!165 = !DILocation(line: 45, column: 74, scope: !149)
!166 = !DILocation(line: 45, column: 89, scope: !149)
!167 = !DILocation(line: 45, column: 3, scope: !149)
!168 = distinct !DISubprogram(name: "support.namespace-metadata.entry-base", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85", scope: !7, file: !7, line: 25, type: !113, scopeLine: 25, spFlags: DISPFlagDefinition, unit: !0)
!169 = !DILocalVariable(name: "slot", arg: 1, scope: !168, file: !7, line: 25, type: !36)
!170 = !DILocation(line: 25, column: 19, scope: !168)
!171 = !DILocation(line: 26, column: 9, scope: !168)
!172 = !DILocation(line: 26, column: 3, scope: !168)
!173 = distinct !DISubprogram(name: "support.namespace-metadata.entry-names", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94", scope: !7, file: !7, line: 47, type: !150, scopeLine: 47, spFlags: DISPFlagDefinition, unit: !0)
!174 = !DILocalVariable(name: "region", arg: 1, scope: !173, file: !7, line: 47, type: !43)
!175 = !DILocation(line: 47, column: 21, scope: !173)
!176 = !DILocalVariable(name: "slot", arg: 2, scope: !173, file: !7, line: 47, type: !36)
!177 = !DILocation(line: 47, column: 48, scope: !173)
!178 = !DILocalVariable(name: "identity", arg: 3, scope: !173, file: !7, line: 47, type: !36)
!179 = !DILocation(line: 47, column: 60, scope: !173)
!180 = !DILocation(line: 48, column: 11, scope: !173)
!181 = !DILocalVariable(name: "base", scope: !173, file: !7, line: 48, type: !36)
!182 = !DILocation(line: 48, column: 3, scope: !173)
!183 = !DILocation(line: 49, column: 27, scope: !173)
!184 = !DILocation(line: 49, column: 13, scope: !173)
!185 = !DILocalVariable(name: "length", scope: !173, file: !7, line: 49, type: !36)
!186 = !DILocation(line: 49, column: 3, scope: !173)
!187 = !DILocation(line: 50, column: 10, scope: !173)
!188 = !DILocation(line: 50, column: 43, scope: !173)
!189 = !DILocation(line: 50, column: 55, scope: !173)
!190 = !DILocation(line: 50, column: 70, scope: !173)
!191 = !DILocation(line: 50, column: 3, scope: !173)
!192 = distinct !DISubprogram(name: "support.namespace-metadata.source-entry-valid", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dentry_2dvalid.96", scope: !7, file: !7, line: 52, type: !193, scopeLine: 52, spFlags: DISPFlagDefinition, unit: !0)
!193 = !DISubroutineType(types: !194)
!194 = !{!10, !43, !64, !36}
!195 = !DILocalVariable(name: "region", arg: 1, scope: !192, file: !7, line: 52, type: !43)
!196 = !DILocation(line: 52, column: 28, scope: !192)
!197 = !DILocation(line: 52, column: 55, scope: !192)
!198 = !DILocalVariable(name: "facts", arg: 2, scope: !192, file: !7, line: 52, type: !64)
!199 = !DILocalVariable(name: "operation", arg: 3, scope: !192, file: !7, line: 52, type: !36)
!200 = !DILocation(line: 52, column: 234, scope: !192)
!201 = !DILocation(line: 53, column: 4, scope: !192)
!202 = !DILocation(line: 54, column: 15, scope: !192)
!203 = !DILocation(line: 55, column: 22, scope: !192)
!204 = !DILocation(line: 55, column: 38, scope: !192)
!205 = !DILocation(line: 55, column: 16, scope: !192)
!206 = distinct !DISubprogram(name: "support.namespace-metadata.source-valid", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dvalid.98", scope: !7, file: !7, line: 57, type: !193, scopeLine: 57, spFlags: DISPFlagDefinition, unit: !0)
!207 = !DILocalVariable(name: "region", arg: 1, scope: !206, file: !7, line: 57, type: !43)
!208 = !DILocation(line: 57, column: 22, scope: !206)
!209 = !DILocation(line: 57, column: 49, scope: !206)
!210 = !DILocalVariable(name: "facts", arg: 2, scope: !206, file: !7, line: 57, type: !64)
!211 = !DILocalVariable(name: "operation", arg: 3, scope: !206, file: !7, line: 57, type: !36)
!212 = !DILocation(line: 57, column: 228, scope: !206)
!213 = !DILocation(line: 58, column: 11, scope: !206)
!214 = !DILocalVariable(name: "base", scope: !206, file: !7, line: 58, type: !36)
!215 = !DILocation(line: 58, column: 3, scope: !206)
!216 = !DILocation(line: 59, column: 12, scope: !206)
!217 = !DILocalVariable(name: "count", scope: !206, file: !7, line: 59, type: !36)
!218 = !DILocation(line: 59, column: 3, scope: !206)
!219 = !DILocation(line: 60, column: 27, scope: !206)
!220 = !DILocation(line: 60, column: 13, scope: !206)
!221 = !DILocalVariable(name: "intent", scope: !206, file: !7, line: 60, type: !36)
!222 = !DILocation(line: 60, column: 3, scope: !206)
!223 = !DILocation(line: 61, column: 20, scope: !206)
!224 = !DILocation(line: 61, column: 31, scope: !206)
!225 = !DILocation(line: 61, column: 46, scope: !206)
!226 = !DILocation(line: 61, column: 59, scope: !206)
!227 = !DILocation(line: 61, column: 14, scope: !206)
!228 = !DILocalVariable(name: "initial", scope: !206, file: !7, line: 61, type: !10)
!229 = !DILocation(line: 61, column: 3, scope: !206)
!230 = !DILocation(line: 62, column: 19, scope: !206)
!231 = !DILocation(line: 62, column: 30, scope: !206)
!232 = !DILocation(line: 62, column: 13, scope: !206)
!233 = !DILocalVariable(name: "linked", scope: !206, file: !7, line: 62, type: !10)
!234 = !DILocation(line: 62, column: 3, scope: !206)
!235 = !DILocation(line: 63, column: 26, scope: !206)
!236 = !DILocation(line: 63, column: 39, scope: !206)
!237 = !DILocation(line: 63, column: 20, scope: !206)
!238 = !DILocation(line: 63, column: 15, scope: !206)
!239 = !DILocalVariable(name: "eligible", scope: !206, file: !7, line: 63, type: !10)
!240 = !DILocation(line: 63, column: 3, scope: !206)
!241 = !DILocation(line: 64, column: 21, scope: !206)
!242 = !DILocation(line: 64, column: 70, scope: !206)
!243 = !DILocation(line: 64, column: 115, scope: !206)
!244 = !DILocation(line: 64, column: 101, scope: !206)
!245 = !DILocation(line: 64, column: 15, scope: !206)
!246 = !DILocalVariable(name: "metadata", scope: !206, file: !7, line: 64, type: !10)
!247 = !DILocation(line: 64, column: 3, scope: !206)
!248 = !DILocation(line: 65, column: 19, scope: !206)
!249 = !DILocation(line: 65, column: 3, scope: !206)
!250 = distinct !DISubprogram(name: "support.namespace-metadata.name-base", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100", scope: !7, file: !7, line: 28, type: !113, scopeLine: 28, spFlags: DISPFlagDefinition, unit: !0)
!251 = !DILocalVariable(name: "slot", arg: 1, scope: !250, file: !7, line: 28, type: !36)
!252 = !DILocation(line: 28, column: 18, scope: !250)
!253 = !DILocation(line: 29, column: 11, scope: !250)
!254 = !DILocation(line: 29, column: 3, scope: !250)
!255 = distinct !DISubprogram(name: "support.namespace-bytes.zero-word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102", scope: !33, file: !33, line: 164, type: !256, scopeLine: 164, spFlags: DISPFlagDefinition, unit: !0)
!256 = !DISubroutineType(types: !257)
!257 = !{!10, !43, !36}
!258 = !DILocalVariable(name: "region", arg: 1, scope: !255, file: !33, line: 164, type: !43)
!259 = !DILocation(line: 164, column: 19, scope: !255)
!260 = !DILocalVariable(name: "offset", arg: 2, scope: !255, file: !33, line: 164, type: !36)
!261 = !DILocation(line: 164, column: 46, scope: !255)
!262 = !DILocation(line: 165, column: 12, scope: !255)
!263 = !DILocalVariable(name: "value", scope: !255, file: !33, line: 165, type: !36)
!264 = !DILocation(line: 165, column: 3, scope: !255)
!265 = !DILocation(line: 166, column: 3, scope: !255)
!266 = distinct !DISubprogram(name: "support.namespace-bytes.zero-pair", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105", scope: !33, file: !33, line: 178, type: !256, scopeLine: 178, spFlags: DISPFlagDefinition, unit: !0)
!267 = !DILocalVariable(name: "region", arg: 1, scope: !266, file: !33, line: 178, type: !43)
!268 = !DILocation(line: 178, column: 19, scope: !266)
!269 = !DILocalVariable(name: "offset", arg: 2, scope: !266, file: !33, line: 178, type: !36)
!270 = !DILocation(line: 178, column: 46, scope: !266)
!271 = !DILocation(line: 179, column: 3, scope: !266)
!272 = !DILocation(line: 180, column: 34, scope: !266)
!273 = !DILocation(line: 180, column: 15, scope: !266)
!274 = !DILocation(line: 181, column: 16, scope: !266)
!275 = distinct !DISubprogram(name: "support.namespace-bytes.zero-block", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111", scope: !33, file: !33, line: 193, type: !256, scopeLine: 193, spFlags: DISPFlagDefinition, unit: !0)
!276 = !DILocalVariable(name: "region", arg: 1, scope: !275, file: !33, line: 193, type: !43)
!277 = !DILocation(line: 193, column: 20, scope: !275)
!278 = !DILocalVariable(name: "offset", arg: 2, scope: !275, file: !33, line: 193, type: !36)
!279 = !DILocation(line: 193, column: 47, scope: !275)
!280 = !DILocation(line: 194, column: 3, scope: !275)
!281 = !DILocation(line: 195, column: 34, scope: !275)
!282 = !DILocation(line: 195, column: 15, scope: !275)
!283 = !DILocation(line: 196, column: 16, scope: !275)
!284 = distinct !DISubprogram(name: "support.namespace-bytes.zero-quarter", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123", scope: !33, file: !33, line: 208, type: !256, scopeLine: 208, spFlags: DISPFlagDefinition, unit: !0)
!285 = !DILocalVariable(name: "region", arg: 1, scope: !284, file: !33, line: 208, type: !43)
!286 = !DILocation(line: 208, column: 26, scope: !284)
!287 = !DILocalVariable(name: "offset", arg: 2, scope: !284, file: !33, line: 208, type: !36)
!288 = !DILocation(line: 208, column: 53, scope: !284)
!289 = !DILocation(line: 209, column: 3, scope: !284)
!290 = !DILocation(line: 210, column: 35, scope: !284)
!291 = !DILocation(line: 210, column: 15, scope: !284)
!292 = !DILocation(line: 211, column: 16, scope: !284)
!293 = distinct !DISubprogram(name: "support.namespace-bytes.zero-half", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147", scope: !33, file: !33, line: 223, type: !256, scopeLine: 223, spFlags: DISPFlagDefinition, unit: !0)
!294 = !DILocalVariable(name: "region", arg: 1, scope: !293, file: !33, line: 223, type: !43)
!295 = !DILocation(line: 223, column: 23, scope: !293)
!296 = !DILocalVariable(name: "offset", arg: 2, scope: !293, file: !33, line: 223, type: !36)
!297 = !DILocation(line: 223, column: 50, scope: !293)
!298 = !DILocation(line: 224, column: 3, scope: !293)
!299 = !DILocation(line: 225, column: 37, scope: !293)
!300 = !DILocation(line: 225, column: 15, scope: !293)
!301 = !DILocation(line: 226, column: 16, scope: !293)
!302 = distinct !DISubprogram(name: "support.namespace-bytes.zero-name", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dname.195", scope: !33, file: !33, line: 238, type: !256, scopeLine: 238, spFlags: DISPFlagDefinition, unit: !0)
!303 = !DILocalVariable(name: "region", arg: 1, scope: !302, file: !33, line: 238, type: !43)
!304 = !DILocation(line: 238, column: 23, scope: !302)
!305 = !DILocalVariable(name: "offset", arg: 2, scope: !302, file: !33, line: 238, type: !36)
!306 = !DILocation(line: 238, column: 50, scope: !302)
!307 = !DILocation(line: 239, column: 3, scope: !302)
!308 = !DILocation(line: 240, column: 34, scope: !302)
!309 = !DILocation(line: 240, column: 15, scope: !302)
!310 = !DILocation(line: 241, column: 16, scope: !302)
!311 = distinct !DISubprogram(name: "support.namespace-metadata.empty-target", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eempty_2dtarget.204", scope: !7, file: !7, line: 67, type: !312, scopeLine: 67, spFlags: DISPFlagDefinition, unit: !0)
!312 = !DISubroutineType(types: !313)
!313 = !{!10, !43, !64}
!314 = !DILocalVariable(name: "region", arg: 1, scope: !311, file: !7, line: 67, type: !43)
!315 = !DILocation(line: 67, column: 22, scope: !311)
!316 = !DILocation(line: 67, column: 49, scope: !311)
!317 = !DILocalVariable(name: "facts", arg: 2, scope: !311, file: !7, line: 67, type: !64)
!318 = !DILocation(line: 68, column: 11, scope: !311)
!319 = !DILocalVariable(name: "base", scope: !311, file: !7, line: 68, type: !36)
!320 = !DILocation(line: 68, column: 3, scope: !311)
!321 = !DILocation(line: 69, column: 55, scope: !311)
!322 = !DILocation(line: 69, column: 12, scope: !311)
!323 = !DILocalVariable(name: "clean", scope: !311, file: !7, line: 69, type: !10)
!324 = !DILocation(line: 69, column: 3, scope: !311)
!325 = !DILocation(line: 70, column: 10, scope: !311)
!326 = !DILocation(line: 70, column: 51, scope: !311)
!327 = !DILocation(line: 70, column: 37, scope: !311)
!328 = !DILocation(line: 70, column: 75, scope: !311)
!329 = !DILocation(line: 70, column: 3, scope: !311)
!330 = distinct !DISubprogram(name: "support.namespace-metadata.live-target", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elive_2dtarget.257", scope: !7, file: !7, line: 72, type: !312, scopeLine: 72, spFlags: DISPFlagDefinition, unit: !0)
!331 = !DILocalVariable(name: "region", arg: 1, scope: !330, file: !7, line: 72, type: !43)
!332 = !DILocation(line: 72, column: 21, scope: !330)
!333 = !DILocation(line: 72, column: 48, scope: !330)
!334 = !DILocalVariable(name: "facts", arg: 2, scope: !330, file: !7, line: 72, type: !64)
!335 = !DILocation(line: 73, column: 11, scope: !330)
!336 = !DILocalVariable(name: "base", scope: !330, file: !7, line: 73, type: !36)
!337 = !DILocation(line: 73, column: 3, scope: !330)
!338 = !DILocation(line: 74, column: 12, scope: !330)
!339 = !DILocalVariable(name: "count", scope: !330, file: !7, line: 74, type: !36)
!340 = !DILocation(line: 74, column: 3, scope: !330)
!341 = !DILocation(line: 75, column: 21, scope: !330)
!342 = !DILocation(line: 75, column: 70, scope: !330)
!343 = !DILocation(line: 75, column: 96, scope: !330)
!344 = !DILocation(line: 75, column: 82, scope: !330)
!345 = !DILocation(line: 75, column: 132, scope: !330)
!346 = !DILocation(line: 75, column: 118, scope: !330)
!347 = !DILocation(line: 75, column: 15, scope: !330)
!348 = !DILocalVariable(name: "metadata", scope: !330, file: !7, line: 75, type: !10)
!349 = !DILocation(line: 75, column: 3, scope: !330)
!350 = !DILocation(line: 76, column: 12, scope: !330)
!351 = !DILocalVariable(name: "entry", scope: !330, file: !7, line: 76, type: !10)
!352 = !DILocation(line: 76, column: 3, scope: !330)
!353 = !DILocation(line: 77, column: 3, scope: !330)
!354 = distinct !DISubprogram(name: "support.namespace-metadata.target-move-or-live", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dmove_2dor_2dlive.258", scope: !7, file: !7, line: 79, type: !193, scopeLine: 79, spFlags: DISPFlagDefinition, unit: !0)
!355 = !DILocalVariable(name: "region", arg: 1, scope: !354, file: !7, line: 79, type: !43)
!356 = !DILocation(line: 79, column: 29, scope: !354)
!357 = !DILocation(line: 79, column: 56, scope: !354)
!358 = !DILocalVariable(name: "facts", arg: 2, scope: !354, file: !7, line: 79, type: !64)
!359 = !DILocalVariable(name: "operation", arg: 3, scope: !354, file: !7, line: 79, type: !36)
!360 = !DILocation(line: 79, column: 235, scope: !354)
!361 = !DILocation(line: 80, column: 3, scope: !354)
!362 = !DILocation(line: 81, column: 16, scope: !354)
!363 = !DILocation(line: 82, column: 16, scope: !354)
!364 = distinct !DISubprogram(name: "support.namespace-metadata.target-valid", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dvalid.259", scope: !7, file: !7, line: 84, type: !193, scopeLine: 84, spFlags: DISPFlagDefinition, unit: !0)
!365 = !DILocalVariable(name: "region", arg: 1, scope: !364, file: !7, line: 84, type: !43)
!366 = !DILocation(line: 84, column: 22, scope: !364)
!367 = !DILocation(line: 84, column: 49, scope: !364)
!368 = !DILocalVariable(name: "facts", arg: 2, scope: !364, file: !7, line: 84, type: !64)
!369 = !DILocalVariable(name: "operation", arg: 3, scope: !364, file: !7, line: 84, type: !36)
!370 = !DILocation(line: 84, column: 228, scope: !364)
!371 = !DILocation(line: 85, column: 3, scope: !364)
!372 = !DILocation(line: 86, column: 15, scope: !364)
!373 = !DILocation(line: 87, column: 16, scope: !364)
!374 = distinct !DISubprogram(name: "support.namespace-bytes.input-byte", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330", scope: !33, file: !33, line: 8, type: !34, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !0)
!375 = !DILocalVariable(name: "region", arg: 1, scope: !374, file: !33, line: 8, type: !43)
!376 = !DILocation(line: 8, column: 20, scope: !374)
!377 = !DILocalVariable(name: "index", arg: 2, scope: !374, file: !33, line: 8, type: !36)
!378 = !DILocation(line: 8, column: 47, scope: !374)
!379 = !DILocation(line: 9, column: 13, scope: !374)
!380 = !DILocalVariable(name: "offset", scope: !374, file: !33, line: 9, type: !36)
!381 = !DILocation(line: 9, column: 3, scope: !374)
!382 = !DILocation(line: 10, column: 3, scope: !374)
!383 = !DILocation(line: 11, column: 10, scope: !374)
!384 = !DILocalVariable(name: "value", scope: !374, file: !33, line: 11, type: !36)
!385 = !DILocation(line: 11, column: 21, scope: !374)
!386 = !DILocation(line: 12, column: 15, scope: !374)
!387 = distinct !DISubprogram(name: "support.namespace-bytes.both", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332", scope: !33, file: !33, line: 15, type: !8, scopeLine: 15, spFlags: DISPFlagDefinition, unit: !0)
!388 = !DILocalVariable(name: "first", arg: 1, scope: !387, file: !33, line: 15, type: !10)
!389 = !DILocation(line: 15, column: 14, scope: !387)
!390 = !DILocalVariable(name: "second", arg: 2, scope: !387, file: !33, line: 15, type: !10)
!391 = !DILocation(line: 15, column: 31, scope: !387)
!392 = !DILocation(line: 16, column: 3, scope: !387)
!393 = !DILocation(line: 17, column: 15, scope: !387)
!394 = !DILocation(line: 18, column: 16, scope: !387)
!395 = distinct !DISubprogram(name: "support.namespace-bytes.not-dot", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2enot_2ddot.335", scope: !33, file: !33, line: 128, type: !256, scopeLine: 128, spFlags: DISPFlagDefinition, unit: !0)
!396 = !DILocalVariable(name: "region", arg: 1, scope: !395, file: !33, line: 128, type: !43)
!397 = !DILocation(line: 128, column: 17, scope: !395)
!398 = !DILocalVariable(name: "length", arg: 2, scope: !395, file: !33, line: 128, type: !36)
!399 = !DILocation(line: 128, column: 44, scope: !395)
!400 = !DILocation(line: 129, column: 12, scope: !395)
!401 = !DILocalVariable(name: "first", scope: !395, file: !33, line: 129, type: !36)
!402 = !DILocation(line: 129, column: 3, scope: !395)
!403 = !DILocation(line: 130, column: 13, scope: !395)
!404 = !DILocalVariable(name: "second", scope: !395, file: !33, line: 130, type: !36)
!405 = !DILocation(line: 130, column: 3, scope: !395)
!406 = !DILocation(line: 131, column: 10, scope: !395)
!407 = !DILocalVariable(name: "one", scope: !395, file: !33, line: 131, type: !10)
!408 = !DILocation(line: 131, column: 3, scope: !395)
!409 = !DILocation(line: 132, column: 10, scope: !395)
!410 = !DILocalVariable(name: "two", scope: !395, file: !33, line: 132, type: !10)
!411 = !DILocation(line: 132, column: 3, scope: !395)
!412 = !DILocation(line: 133, column: 16, scope: !395)
!413 = !DILocalVariable(name: "first-dot", scope: !395, file: !33, line: 133, type: !10)
!414 = !DILocation(line: 133, column: 3, scope: !395)
!415 = !DILocation(line: 134, column: 17, scope: !395)
!416 = !DILocalVariable(name: "second-dot", scope: !395, file: !33, line: 134, type: !10)
!417 = !DILocation(line: 134, column: 3, scope: !395)
!418 = !DILocation(line: 135, column: 17, scope: !395)
!419 = !DILocalVariable(name: "bad-single", scope: !395, file: !33, line: 135, type: !10)
!420 = !DILocation(line: 135, column: 3, scope: !395)
!421 = !DILocation(line: 136, column: 26, scope: !395)
!422 = !DILocation(line: 136, column: 15, scope: !395)
!423 = !DILocalVariable(name: "bad-pair", scope: !395, file: !33, line: 136, type: !10)
!424 = !DILocation(line: 136, column: 3, scope: !395)
!425 = !DILocation(line: 137, column: 3, scope: !395)
!426 = !DILocation(line: 138, column: 15, scope: !395)
!427 = !DILocation(line: 139, column: 16, scope: !395)
!428 = distinct !DISubprogram(name: "support.namespace-bytes.character", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2echaracter.338", scope: !33, file: !33, line: 20, type: !429, scopeLine: 20, spFlags: DISPFlagDefinition, unit: !0)
!429 = !DISubroutineType(types: !430)
!430 = !{!10, !36}
!431 = !DILocalVariable(name: "value", arg: 1, scope: !428, file: !33, line: 20, type: !36)
!432 = !DILocation(line: 20, column: 18, scope: !428)
!433 = !DILocation(line: 21, column: 15, scope: !428)
!434 = !DILocalVariable(name: "positive", scope: !428, file: !33, line: 21, type: !10)
!435 = !DILocation(line: 21, column: 3, scope: !428)
!436 = !DILocation(line: 22, column: 14, scope: !428)
!437 = !DILocalVariable(name: "bounded", scope: !428, file: !33, line: 22, type: !10)
!438 = !DILocation(line: 22, column: 3, scope: !428)
!439 = !DILocation(line: 23, column: 13, scope: !428)
!440 = !DILocalVariable(name: "normal", scope: !428, file: !33, line: 23, type: !10)
!441 = !DILocation(line: 23, column: 3, scope: !428)
!442 = !DILocation(line: 24, column: 19, scope: !428)
!443 = !DILocation(line: 24, column: 3, scope: !428)
!444 = distinct !DISubprogram(name: "support.namespace-bytes.valid-value", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dvalue.339", scope: !33, file: !33, line: 26, type: !445, scopeLine: 26, spFlags: DISPFlagDefinition, unit: !0)
!445 = !DISubroutineType(types: !446)
!446 = !{!10, !36, !36, !36}
!447 = !DILocalVariable(name: "value", arg: 1, scope: !444, file: !33, line: 26, type: !36)
!448 = !DILocation(line: 26, column: 21, scope: !444)
!449 = !DILocalVariable(name: "index", arg: 2, scope: !444, file: !33, line: 26, type: !36)
!450 = !DILocation(line: 26, column: 34, scope: !444)
!451 = !DILocalVariable(name: "length", arg: 3, scope: !444, file: !33, line: 26, type: !36)
!452 = !DILocation(line: 26, column: 47, scope: !444)
!453 = !DILocation(line: 27, column: 3, scope: !444)
!454 = !DILocation(line: 28, column: 15, scope: !444)
!455 = !DILocation(line: 29, column: 16, scope: !444)
!456 = distinct !DISubprogram(name: "support.namespace-bytes.valid-byte", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340", scope: !33, file: !33, line: 31, type: !457, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !0)
!457 = !DISubroutineType(types: !458)
!458 = !{!10, !43, !36, !36, !36}
!459 = !DILocalVariable(name: "region", arg: 1, scope: !456, file: !33, line: 31, type: !43)
!460 = !DILocation(line: 31, column: 20, scope: !456)
!461 = !DILocalVariable(name: "offset", arg: 2, scope: !456, file: !33, line: 31, type: !36)
!462 = !DILocation(line: 31, column: 47, scope: !456)
!463 = !DILocalVariable(name: "index", arg: 3, scope: !456, file: !33, line: 31, type: !36)
!464 = !DILocation(line: 31, column: 61, scope: !456)
!465 = !DILocalVariable(name: "length", arg: 4, scope: !456, file: !33, line: 31, type: !36)
!466 = !DILocation(line: 31, column: 74, scope: !456)
!467 = !DILocation(line: 32, column: 3, scope: !456)
!468 = !DILocation(line: 33, column: 10, scope: !456)
!469 = !DILocalVariable(name: "value", scope: !456, file: !33, line: 33, type: !36)
!470 = !DILocation(line: 33, column: 21, scope: !456)
!471 = !DILocation(line: 34, column: 15, scope: !456)
!472 = distinct !DISubprogram(name: "support.namespace-bytes.all-four", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359", scope: !33, file: !33, line: 36, type: !19, scopeLine: 36, spFlags: DISPFlagDefinition, unit: !0)
!473 = !DILocalVariable(name: "first", arg: 1, scope: !472, file: !33, line: 36, type: !10)
!474 = !DILocation(line: 36, column: 18, scope: !472)
!475 = !DILocalVariable(name: "second", arg: 2, scope: !472, file: !33, line: 36, type: !10)
!476 = !DILocation(line: 36, column: 35, scope: !472)
!477 = !DILocalVariable(name: "third", arg: 3, scope: !472, file: !33, line: 36, type: !10)
!478 = !DILocation(line: 36, column: 53, scope: !472)
!479 = !DILocalVariable(name: "fourth", arg: 4, scope: !472, file: !33, line: 36, type: !10)
!480 = !DILocation(line: 36, column: 70, scope: !472)
!481 = !DILocation(line: 37, column: 11, scope: !472)
!482 = !DILocalVariable(name: "left", scope: !472, file: !33, line: 37, type: !10)
!483 = !DILocation(line: 37, column: 3, scope: !472)
!484 = !DILocation(line: 38, column: 12, scope: !472)
!485 = !DILocalVariable(name: "right", scope: !472, file: !33, line: 38, type: !10)
!486 = !DILocation(line: 38, column: 3, scope: !472)
!487 = !DILocation(line: 39, column: 3, scope: !472)
!488 = distinct !DISubprogram(name: "support.namespace-bytes.valid-payload", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dpayload.1956", scope: !33, file: !33, line: 41, type: !256, scopeLine: 41, spFlags: DISPFlagDefinition, unit: !0)
!489 = !DILocalVariable(name: "region", arg: 1, scope: !488, file: !33, line: 41, type: !43)
!490 = !DILocation(line: 41, column: 23, scope: !488)
!491 = !DILocalVariable(name: "length", arg: 2, scope: !488, file: !33, line: 41, type: !36)
!492 = !DILocation(line: 41, column: 50, scope: !488)
!493 = !DILocation(line: 42, column: 23, scope: !488)
!494 = !DILocation(line: 42, column: 61, scope: !488)
!495 = !DILocation(line: 42, column: 99, scope: !488)
!496 = !DILocation(line: 42, column: 137, scope: !488)
!497 = !DILocation(line: 42, column: 13, scope: !488)
!498 = !DILocalVariable(name: "seen-0", scope: !488, file: !33, line: 42, type: !10)
!499 = !DILocation(line: 42, column: 3, scope: !488)
!500 = !DILocation(line: 43, column: 23, scope: !488)
!501 = !DILocation(line: 43, column: 61, scope: !488)
!502 = !DILocation(line: 43, column: 99, scope: !488)
!503 = !DILocation(line: 43, column: 137, scope: !488)
!504 = !DILocation(line: 43, column: 13, scope: !488)
!505 = !DILocalVariable(name: "seen-1", scope: !488, file: !33, line: 43, type: !10)
!506 = !DILocation(line: 43, column: 3, scope: !488)
!507 = !DILocation(line: 44, column: 23, scope: !488)
!508 = !DILocation(line: 44, column: 61, scope: !488)
!509 = !DILocation(line: 44, column: 99, scope: !488)
!510 = !DILocation(line: 44, column: 138, scope: !488)
!511 = !DILocation(line: 44, column: 13, scope: !488)
!512 = !DILocalVariable(name: "seen-2", scope: !488, file: !33, line: 44, type: !10)
!513 = !DILocation(line: 44, column: 3, scope: !488)
!514 = !DILocation(line: 45, column: 23, scope: !488)
!515 = !DILocation(line: 45, column: 62, scope: !488)
!516 = !DILocation(line: 45, column: 101, scope: !488)
!517 = !DILocation(line: 45, column: 140, scope: !488)
!518 = !DILocation(line: 45, column: 13, scope: !488)
!519 = !DILocalVariable(name: "seen-3", scope: !488, file: !33, line: 45, type: !10)
!520 = !DILocation(line: 45, column: 3, scope: !488)
!521 = !DILocation(line: 46, column: 23, scope: !488)
!522 = !DILocation(line: 46, column: 62, scope: !488)
!523 = !DILocation(line: 46, column: 101, scope: !488)
!524 = !DILocation(line: 46, column: 140, scope: !488)
!525 = !DILocation(line: 46, column: 13, scope: !488)
!526 = !DILocalVariable(name: "seen-4", scope: !488, file: !33, line: 46, type: !10)
!527 = !DILocation(line: 46, column: 3, scope: !488)
!528 = !DILocation(line: 47, column: 23, scope: !488)
!529 = !DILocation(line: 47, column: 62, scope: !488)
!530 = !DILocation(line: 47, column: 101, scope: !488)
!531 = !DILocation(line: 47, column: 140, scope: !488)
!532 = !DILocation(line: 47, column: 13, scope: !488)
!533 = !DILocalVariable(name: "seen-5", scope: !488, file: !33, line: 47, type: !10)
!534 = !DILocation(line: 47, column: 3, scope: !488)
!535 = !DILocation(line: 48, column: 23, scope: !488)
!536 = !DILocation(line: 48, column: 62, scope: !488)
!537 = !DILocation(line: 48, column: 101, scope: !488)
!538 = !DILocation(line: 48, column: 140, scope: !488)
!539 = !DILocation(line: 48, column: 13, scope: !488)
!540 = !DILocalVariable(name: "seen-6", scope: !488, file: !33, line: 48, type: !10)
!541 = !DILocation(line: 48, column: 3, scope: !488)
!542 = !DILocation(line: 49, column: 23, scope: !488)
!543 = !DILocation(line: 49, column: 62, scope: !488)
!544 = !DILocation(line: 49, column: 101, scope: !488)
!545 = !DILocation(line: 49, column: 140, scope: !488)
!546 = !DILocation(line: 49, column: 13, scope: !488)
!547 = !DILocalVariable(name: "seen-7", scope: !488, file: !33, line: 49, type: !10)
!548 = !DILocation(line: 49, column: 3, scope: !488)
!549 = !DILocation(line: 50, column: 23, scope: !488)
!550 = !DILocation(line: 50, column: 62, scope: !488)
!551 = !DILocation(line: 50, column: 101, scope: !488)
!552 = !DILocation(line: 50, column: 140, scope: !488)
!553 = !DILocation(line: 50, column: 13, scope: !488)
!554 = !DILocalVariable(name: "seen-8", scope: !488, file: !33, line: 50, type: !10)
!555 = !DILocation(line: 50, column: 3, scope: !488)
!556 = !DILocation(line: 51, column: 23, scope: !488)
!557 = !DILocation(line: 51, column: 62, scope: !488)
!558 = !DILocation(line: 51, column: 101, scope: !488)
!559 = !DILocation(line: 51, column: 140, scope: !488)
!560 = !DILocation(line: 51, column: 13, scope: !488)
!561 = !DILocalVariable(name: "seen-9", scope: !488, file: !33, line: 51, type: !10)
!562 = !DILocation(line: 51, column: 3, scope: !488)
!563 = !DILocation(line: 52, column: 24, scope: !488)
!564 = !DILocation(line: 52, column: 63, scope: !488)
!565 = !DILocation(line: 52, column: 102, scope: !488)
!566 = !DILocation(line: 52, column: 141, scope: !488)
!567 = !DILocation(line: 52, column: 14, scope: !488)
!568 = !DILocalVariable(name: "seen-10", scope: !488, file: !33, line: 52, type: !10)
!569 = !DILocation(line: 52, column: 3, scope: !488)
!570 = !DILocation(line: 53, column: 24, scope: !488)
!571 = !DILocation(line: 53, column: 63, scope: !488)
!572 = !DILocation(line: 53, column: 102, scope: !488)
!573 = !DILocation(line: 53, column: 141, scope: !488)
!574 = !DILocation(line: 53, column: 14, scope: !488)
!575 = !DILocalVariable(name: "seen-11", scope: !488, file: !33, line: 53, type: !10)
!576 = !DILocation(line: 53, column: 3, scope: !488)
!577 = !DILocation(line: 54, column: 24, scope: !488)
!578 = !DILocation(line: 54, column: 63, scope: !488)
!579 = !DILocation(line: 54, column: 102, scope: !488)
!580 = !DILocation(line: 54, column: 141, scope: !488)
!581 = !DILocation(line: 54, column: 14, scope: !488)
!582 = !DILocalVariable(name: "seen-12", scope: !488, file: !33, line: 54, type: !10)
!583 = !DILocation(line: 54, column: 3, scope: !488)
!584 = !DILocation(line: 55, column: 24, scope: !488)
!585 = !DILocation(line: 55, column: 63, scope: !488)
!586 = !DILocation(line: 55, column: 102, scope: !488)
!587 = !DILocation(line: 55, column: 141, scope: !488)
!588 = !DILocation(line: 55, column: 14, scope: !488)
!589 = !DILocalVariable(name: "seen-13", scope: !488, file: !33, line: 55, type: !10)
!590 = !DILocation(line: 55, column: 3, scope: !488)
!591 = !DILocation(line: 56, column: 24, scope: !488)
!592 = !DILocation(line: 56, column: 63, scope: !488)
!593 = !DILocation(line: 56, column: 102, scope: !488)
!594 = !DILocation(line: 56, column: 141, scope: !488)
!595 = !DILocation(line: 56, column: 14, scope: !488)
!596 = !DILocalVariable(name: "seen-14", scope: !488, file: !33, line: 56, type: !10)
!597 = !DILocation(line: 56, column: 3, scope: !488)
!598 = !DILocation(line: 57, column: 24, scope: !488)
!599 = !DILocation(line: 57, column: 63, scope: !488)
!600 = !DILocation(line: 57, column: 102, scope: !488)
!601 = !DILocation(line: 57, column: 141, scope: !488)
!602 = !DILocation(line: 57, column: 14, scope: !488)
!603 = !DILocalVariable(name: "seen-15", scope: !488, file: !33, line: 57, type: !10)
!604 = !DILocation(line: 57, column: 3, scope: !488)
!605 = !DILocation(line: 58, column: 24, scope: !488)
!606 = !DILocation(line: 58, column: 63, scope: !488)
!607 = !DILocation(line: 58, column: 102, scope: !488)
!608 = !DILocation(line: 58, column: 141, scope: !488)
!609 = !DILocation(line: 58, column: 14, scope: !488)
!610 = !DILocalVariable(name: "seen-16", scope: !488, file: !33, line: 58, type: !10)
!611 = !DILocation(line: 58, column: 3, scope: !488)
!612 = !DILocation(line: 59, column: 24, scope: !488)
!613 = !DILocation(line: 59, column: 63, scope: !488)
!614 = !DILocation(line: 59, column: 102, scope: !488)
!615 = !DILocation(line: 59, column: 141, scope: !488)
!616 = !DILocation(line: 59, column: 14, scope: !488)
!617 = !DILocalVariable(name: "seen-17", scope: !488, file: !33, line: 59, type: !10)
!618 = !DILocation(line: 59, column: 3, scope: !488)
!619 = !DILocation(line: 60, column: 24, scope: !488)
!620 = !DILocation(line: 60, column: 63, scope: !488)
!621 = !DILocation(line: 60, column: 102, scope: !488)
!622 = !DILocation(line: 60, column: 141, scope: !488)
!623 = !DILocation(line: 60, column: 14, scope: !488)
!624 = !DILocalVariable(name: "seen-18", scope: !488, file: !33, line: 60, type: !10)
!625 = !DILocation(line: 60, column: 3, scope: !488)
!626 = !DILocation(line: 61, column: 24, scope: !488)
!627 = !DILocation(line: 61, column: 63, scope: !488)
!628 = !DILocation(line: 61, column: 102, scope: !488)
!629 = !DILocation(line: 61, column: 141, scope: !488)
!630 = !DILocation(line: 61, column: 14, scope: !488)
!631 = !DILocalVariable(name: "seen-19", scope: !488, file: !33, line: 61, type: !10)
!632 = !DILocation(line: 61, column: 3, scope: !488)
!633 = !DILocation(line: 62, column: 24, scope: !488)
!634 = !DILocation(line: 62, column: 63, scope: !488)
!635 = !DILocation(line: 62, column: 102, scope: !488)
!636 = !DILocation(line: 62, column: 141, scope: !488)
!637 = !DILocation(line: 62, column: 14, scope: !488)
!638 = !DILocalVariable(name: "seen-20", scope: !488, file: !33, line: 62, type: !10)
!639 = !DILocation(line: 62, column: 3, scope: !488)
!640 = !DILocation(line: 63, column: 24, scope: !488)
!641 = !DILocation(line: 63, column: 63, scope: !488)
!642 = !DILocation(line: 63, column: 102, scope: !488)
!643 = !DILocation(line: 63, column: 141, scope: !488)
!644 = !DILocation(line: 63, column: 14, scope: !488)
!645 = !DILocalVariable(name: "seen-21", scope: !488, file: !33, line: 63, type: !10)
!646 = !DILocation(line: 63, column: 3, scope: !488)
!647 = !DILocation(line: 64, column: 24, scope: !488)
!648 = !DILocation(line: 64, column: 63, scope: !488)
!649 = !DILocation(line: 64, column: 102, scope: !488)
!650 = !DILocation(line: 64, column: 141, scope: !488)
!651 = !DILocation(line: 64, column: 14, scope: !488)
!652 = !DILocalVariable(name: "seen-22", scope: !488, file: !33, line: 64, type: !10)
!653 = !DILocation(line: 64, column: 3, scope: !488)
!654 = !DILocation(line: 65, column: 24, scope: !488)
!655 = !DILocation(line: 65, column: 63, scope: !488)
!656 = !DILocation(line: 65, column: 102, scope: !488)
!657 = !DILocation(line: 65, column: 141, scope: !488)
!658 = !DILocation(line: 65, column: 14, scope: !488)
!659 = !DILocalVariable(name: "seen-23", scope: !488, file: !33, line: 65, type: !10)
!660 = !DILocation(line: 65, column: 3, scope: !488)
!661 = !DILocation(line: 66, column: 24, scope: !488)
!662 = !DILocation(line: 66, column: 63, scope: !488)
!663 = !DILocation(line: 66, column: 102, scope: !488)
!664 = !DILocation(line: 66, column: 141, scope: !488)
!665 = !DILocation(line: 66, column: 14, scope: !488)
!666 = !DILocalVariable(name: "seen-24", scope: !488, file: !33, line: 66, type: !10)
!667 = !DILocation(line: 66, column: 3, scope: !488)
!668 = !DILocation(line: 67, column: 24, scope: !488)
!669 = !DILocation(line: 67, column: 64, scope: !488)
!670 = !DILocation(line: 67, column: 104, scope: !488)
!671 = !DILocation(line: 67, column: 144, scope: !488)
!672 = !DILocation(line: 67, column: 14, scope: !488)
!673 = !DILocalVariable(name: "seen-25", scope: !488, file: !33, line: 67, type: !10)
!674 = !DILocation(line: 67, column: 3, scope: !488)
!675 = !DILocation(line: 68, column: 24, scope: !488)
!676 = !DILocation(line: 68, column: 64, scope: !488)
!677 = !DILocation(line: 68, column: 104, scope: !488)
!678 = !DILocation(line: 68, column: 144, scope: !488)
!679 = !DILocation(line: 68, column: 14, scope: !488)
!680 = !DILocalVariable(name: "seen-26", scope: !488, file: !33, line: 68, type: !10)
!681 = !DILocation(line: 68, column: 3, scope: !488)
!682 = !DILocation(line: 69, column: 24, scope: !488)
!683 = !DILocation(line: 69, column: 64, scope: !488)
!684 = !DILocation(line: 69, column: 104, scope: !488)
!685 = !DILocation(line: 69, column: 144, scope: !488)
!686 = !DILocation(line: 69, column: 14, scope: !488)
!687 = !DILocalVariable(name: "seen-27", scope: !488, file: !33, line: 69, type: !10)
!688 = !DILocation(line: 69, column: 3, scope: !488)
!689 = !DILocation(line: 70, column: 24, scope: !488)
!690 = !DILocation(line: 70, column: 64, scope: !488)
!691 = !DILocation(line: 70, column: 104, scope: !488)
!692 = !DILocation(line: 70, column: 144, scope: !488)
!693 = !DILocation(line: 70, column: 14, scope: !488)
!694 = !DILocalVariable(name: "seen-28", scope: !488, file: !33, line: 70, type: !10)
!695 = !DILocation(line: 70, column: 3, scope: !488)
!696 = !DILocation(line: 71, column: 24, scope: !488)
!697 = !DILocation(line: 71, column: 64, scope: !488)
!698 = !DILocation(line: 71, column: 104, scope: !488)
!699 = !DILocation(line: 71, column: 144, scope: !488)
!700 = !DILocation(line: 71, column: 14, scope: !488)
!701 = !DILocalVariable(name: "seen-29", scope: !488, file: !33, line: 71, type: !10)
!702 = !DILocation(line: 71, column: 3, scope: !488)
!703 = !DILocation(line: 72, column: 24, scope: !488)
!704 = !DILocation(line: 72, column: 64, scope: !488)
!705 = !DILocation(line: 72, column: 104, scope: !488)
!706 = !DILocation(line: 72, column: 144, scope: !488)
!707 = !DILocation(line: 72, column: 14, scope: !488)
!708 = !DILocalVariable(name: "seen-30", scope: !488, file: !33, line: 72, type: !10)
!709 = !DILocation(line: 72, column: 3, scope: !488)
!710 = !DILocation(line: 73, column: 24, scope: !488)
!711 = !DILocation(line: 73, column: 64, scope: !488)
!712 = !DILocation(line: 73, column: 104, scope: !488)
!713 = !DILocation(line: 73, column: 144, scope: !488)
!714 = !DILocation(line: 73, column: 14, scope: !488)
!715 = !DILocalVariable(name: "seen-31", scope: !488, file: !33, line: 73, type: !10)
!716 = !DILocation(line: 73, column: 3, scope: !488)
!717 = !DILocation(line: 74, column: 24, scope: !488)
!718 = !DILocation(line: 74, column: 64, scope: !488)
!719 = !DILocation(line: 74, column: 104, scope: !488)
!720 = !DILocation(line: 74, column: 144, scope: !488)
!721 = !DILocation(line: 74, column: 14, scope: !488)
!722 = !DILocalVariable(name: "seen-32", scope: !488, file: !33, line: 74, type: !10)
!723 = !DILocation(line: 74, column: 3, scope: !488)
!724 = !DILocation(line: 75, column: 24, scope: !488)
!725 = !DILocation(line: 75, column: 64, scope: !488)
!726 = !DILocation(line: 75, column: 104, scope: !488)
!727 = !DILocation(line: 75, column: 144, scope: !488)
!728 = !DILocation(line: 75, column: 14, scope: !488)
!729 = !DILocalVariable(name: "seen-33", scope: !488, file: !33, line: 75, type: !10)
!730 = !DILocation(line: 75, column: 3, scope: !488)
!731 = !DILocation(line: 76, column: 24, scope: !488)
!732 = !DILocation(line: 76, column: 64, scope: !488)
!733 = !DILocation(line: 76, column: 104, scope: !488)
!734 = !DILocation(line: 76, column: 144, scope: !488)
!735 = !DILocation(line: 76, column: 14, scope: !488)
!736 = !DILocalVariable(name: "seen-34", scope: !488, file: !33, line: 76, type: !10)
!737 = !DILocation(line: 76, column: 3, scope: !488)
!738 = !DILocation(line: 77, column: 24, scope: !488)
!739 = !DILocation(line: 77, column: 64, scope: !488)
!740 = !DILocation(line: 77, column: 104, scope: !488)
!741 = !DILocation(line: 77, column: 144, scope: !488)
!742 = !DILocation(line: 77, column: 14, scope: !488)
!743 = !DILocalVariable(name: "seen-35", scope: !488, file: !33, line: 77, type: !10)
!744 = !DILocation(line: 77, column: 3, scope: !488)
!745 = !DILocation(line: 78, column: 24, scope: !488)
!746 = !DILocation(line: 78, column: 64, scope: !488)
!747 = !DILocation(line: 78, column: 104, scope: !488)
!748 = !DILocation(line: 78, column: 144, scope: !488)
!749 = !DILocation(line: 78, column: 14, scope: !488)
!750 = !DILocalVariable(name: "seen-36", scope: !488, file: !33, line: 78, type: !10)
!751 = !DILocation(line: 78, column: 3, scope: !488)
!752 = !DILocation(line: 79, column: 24, scope: !488)
!753 = !DILocation(line: 79, column: 64, scope: !488)
!754 = !DILocation(line: 79, column: 104, scope: !488)
!755 = !DILocation(line: 79, column: 144, scope: !488)
!756 = !DILocation(line: 79, column: 14, scope: !488)
!757 = !DILocalVariable(name: "seen-37", scope: !488, file: !33, line: 79, type: !10)
!758 = !DILocation(line: 79, column: 3, scope: !488)
!759 = !DILocation(line: 80, column: 24, scope: !488)
!760 = !DILocation(line: 80, column: 64, scope: !488)
!761 = !DILocation(line: 80, column: 104, scope: !488)
!762 = !DILocation(line: 80, column: 144, scope: !488)
!763 = !DILocation(line: 80, column: 14, scope: !488)
!764 = !DILocalVariable(name: "seen-38", scope: !488, file: !33, line: 80, type: !10)
!765 = !DILocation(line: 80, column: 3, scope: !488)
!766 = !DILocation(line: 81, column: 24, scope: !488)
!767 = !DILocation(line: 81, column: 64, scope: !488)
!768 = !DILocation(line: 81, column: 104, scope: !488)
!769 = !DILocation(line: 81, column: 144, scope: !488)
!770 = !DILocation(line: 81, column: 14, scope: !488)
!771 = !DILocalVariable(name: "seen-39", scope: !488, file: !33, line: 81, type: !10)
!772 = !DILocation(line: 81, column: 3, scope: !488)
!773 = !DILocation(line: 82, column: 24, scope: !488)
!774 = !DILocation(line: 82, column: 64, scope: !488)
!775 = !DILocation(line: 82, column: 104, scope: !488)
!776 = !DILocation(line: 82, column: 144, scope: !488)
!777 = !DILocation(line: 82, column: 14, scope: !488)
!778 = !DILocalVariable(name: "seen-40", scope: !488, file: !33, line: 82, type: !10)
!779 = !DILocation(line: 82, column: 3, scope: !488)
!780 = !DILocation(line: 83, column: 24, scope: !488)
!781 = !DILocation(line: 83, column: 64, scope: !488)
!782 = !DILocation(line: 83, column: 104, scope: !488)
!783 = !DILocation(line: 83, column: 144, scope: !488)
!784 = !DILocation(line: 83, column: 14, scope: !488)
!785 = !DILocalVariable(name: "seen-41", scope: !488, file: !33, line: 83, type: !10)
!786 = !DILocation(line: 83, column: 3, scope: !488)
!787 = !DILocation(line: 84, column: 24, scope: !488)
!788 = !DILocation(line: 84, column: 64, scope: !488)
!789 = !DILocation(line: 84, column: 104, scope: !488)
!790 = !DILocation(line: 84, column: 144, scope: !488)
!791 = !DILocation(line: 84, column: 14, scope: !488)
!792 = !DILocalVariable(name: "seen-42", scope: !488, file: !33, line: 84, type: !10)
!793 = !DILocation(line: 84, column: 3, scope: !488)
!794 = !DILocation(line: 85, column: 24, scope: !488)
!795 = !DILocation(line: 85, column: 64, scope: !488)
!796 = !DILocation(line: 85, column: 104, scope: !488)
!797 = !DILocation(line: 85, column: 144, scope: !488)
!798 = !DILocation(line: 85, column: 14, scope: !488)
!799 = !DILocalVariable(name: "seen-43", scope: !488, file: !33, line: 85, type: !10)
!800 = !DILocation(line: 85, column: 3, scope: !488)
!801 = !DILocation(line: 86, column: 24, scope: !488)
!802 = !DILocation(line: 86, column: 64, scope: !488)
!803 = !DILocation(line: 86, column: 104, scope: !488)
!804 = !DILocation(line: 86, column: 144, scope: !488)
!805 = !DILocation(line: 86, column: 14, scope: !488)
!806 = !DILocalVariable(name: "seen-44", scope: !488, file: !33, line: 86, type: !10)
!807 = !DILocation(line: 86, column: 3, scope: !488)
!808 = !DILocation(line: 87, column: 24, scope: !488)
!809 = !DILocation(line: 87, column: 64, scope: !488)
!810 = !DILocation(line: 87, column: 104, scope: !488)
!811 = !DILocation(line: 87, column: 144, scope: !488)
!812 = !DILocation(line: 87, column: 14, scope: !488)
!813 = !DILocalVariable(name: "seen-45", scope: !488, file: !33, line: 87, type: !10)
!814 = !DILocation(line: 87, column: 3, scope: !488)
!815 = !DILocation(line: 88, column: 24, scope: !488)
!816 = !DILocation(line: 88, column: 64, scope: !488)
!817 = !DILocation(line: 88, column: 104, scope: !488)
!818 = !DILocation(line: 88, column: 144, scope: !488)
!819 = !DILocation(line: 88, column: 14, scope: !488)
!820 = !DILocalVariable(name: "seen-46", scope: !488, file: !33, line: 88, type: !10)
!821 = !DILocation(line: 88, column: 3, scope: !488)
!822 = !DILocation(line: 89, column: 24, scope: !488)
!823 = !DILocation(line: 89, column: 64, scope: !488)
!824 = !DILocation(line: 89, column: 104, scope: !488)
!825 = !DILocation(line: 89, column: 144, scope: !488)
!826 = !DILocation(line: 89, column: 14, scope: !488)
!827 = !DILocalVariable(name: "seen-47", scope: !488, file: !33, line: 89, type: !10)
!828 = !DILocation(line: 89, column: 3, scope: !488)
!829 = !DILocation(line: 90, column: 24, scope: !488)
!830 = !DILocation(line: 90, column: 64, scope: !488)
!831 = !DILocation(line: 90, column: 104, scope: !488)
!832 = !DILocation(line: 90, column: 144, scope: !488)
!833 = !DILocation(line: 90, column: 14, scope: !488)
!834 = !DILocalVariable(name: "seen-48", scope: !488, file: !33, line: 90, type: !10)
!835 = !DILocation(line: 90, column: 3, scope: !488)
!836 = !DILocation(line: 91, column: 24, scope: !488)
!837 = !DILocation(line: 91, column: 64, scope: !488)
!838 = !DILocation(line: 91, column: 104, scope: !488)
!839 = !DILocation(line: 91, column: 144, scope: !488)
!840 = !DILocation(line: 91, column: 14, scope: !488)
!841 = !DILocalVariable(name: "seen-49", scope: !488, file: !33, line: 91, type: !10)
!842 = !DILocation(line: 91, column: 3, scope: !488)
!843 = !DILocation(line: 92, column: 24, scope: !488)
!844 = !DILocation(line: 92, column: 64, scope: !488)
!845 = !DILocation(line: 92, column: 104, scope: !488)
!846 = !DILocation(line: 92, column: 144, scope: !488)
!847 = !DILocation(line: 92, column: 14, scope: !488)
!848 = !DILocalVariable(name: "seen-50", scope: !488, file: !33, line: 92, type: !10)
!849 = !DILocation(line: 92, column: 3, scope: !488)
!850 = !DILocation(line: 93, column: 24, scope: !488)
!851 = !DILocation(line: 93, column: 64, scope: !488)
!852 = !DILocation(line: 93, column: 104, scope: !488)
!853 = !DILocation(line: 93, column: 144, scope: !488)
!854 = !DILocation(line: 93, column: 14, scope: !488)
!855 = !DILocalVariable(name: "seen-51", scope: !488, file: !33, line: 93, type: !10)
!856 = !DILocation(line: 93, column: 3, scope: !488)
!857 = !DILocation(line: 94, column: 24, scope: !488)
!858 = !DILocation(line: 94, column: 64, scope: !488)
!859 = !DILocation(line: 94, column: 104, scope: !488)
!860 = !DILocation(line: 94, column: 144, scope: !488)
!861 = !DILocation(line: 94, column: 14, scope: !488)
!862 = !DILocalVariable(name: "seen-52", scope: !488, file: !33, line: 94, type: !10)
!863 = !DILocation(line: 94, column: 3, scope: !488)
!864 = !DILocation(line: 95, column: 24, scope: !488)
!865 = !DILocation(line: 95, column: 64, scope: !488)
!866 = !DILocation(line: 95, column: 104, scope: !488)
!867 = !DILocation(line: 95, column: 144, scope: !488)
!868 = !DILocation(line: 95, column: 14, scope: !488)
!869 = !DILocalVariable(name: "seen-53", scope: !488, file: !33, line: 95, type: !10)
!870 = !DILocation(line: 95, column: 3, scope: !488)
!871 = !DILocation(line: 96, column: 24, scope: !488)
!872 = !DILocation(line: 96, column: 64, scope: !488)
!873 = !DILocation(line: 96, column: 104, scope: !488)
!874 = !DILocation(line: 96, column: 144, scope: !488)
!875 = !DILocation(line: 96, column: 14, scope: !488)
!876 = !DILocalVariable(name: "seen-54", scope: !488, file: !33, line: 96, type: !10)
!877 = !DILocation(line: 96, column: 3, scope: !488)
!878 = !DILocation(line: 97, column: 24, scope: !488)
!879 = !DILocation(line: 97, column: 64, scope: !488)
!880 = !DILocation(line: 97, column: 104, scope: !488)
!881 = !DILocation(line: 97, column: 144, scope: !488)
!882 = !DILocation(line: 97, column: 14, scope: !488)
!883 = !DILocalVariable(name: "seen-55", scope: !488, file: !33, line: 97, type: !10)
!884 = !DILocation(line: 97, column: 3, scope: !488)
!885 = !DILocation(line: 98, column: 24, scope: !488)
!886 = !DILocation(line: 98, column: 64, scope: !488)
!887 = !DILocation(line: 98, column: 104, scope: !488)
!888 = !DILocation(line: 98, column: 144, scope: !488)
!889 = !DILocation(line: 98, column: 14, scope: !488)
!890 = !DILocalVariable(name: "seen-56", scope: !488, file: !33, line: 98, type: !10)
!891 = !DILocation(line: 98, column: 3, scope: !488)
!892 = !DILocation(line: 99, column: 24, scope: !488)
!893 = !DILocation(line: 99, column: 64, scope: !488)
!894 = !DILocation(line: 99, column: 104, scope: !488)
!895 = !DILocation(line: 99, column: 144, scope: !488)
!896 = !DILocation(line: 99, column: 14, scope: !488)
!897 = !DILocalVariable(name: "seen-57", scope: !488, file: !33, line: 99, type: !10)
!898 = !DILocation(line: 99, column: 3, scope: !488)
!899 = !DILocation(line: 100, column: 24, scope: !488)
!900 = !DILocation(line: 100, column: 64, scope: !488)
!901 = !DILocation(line: 100, column: 104, scope: !488)
!902 = !DILocation(line: 100, column: 144, scope: !488)
!903 = !DILocation(line: 100, column: 14, scope: !488)
!904 = !DILocalVariable(name: "seen-58", scope: !488, file: !33, line: 100, type: !10)
!905 = !DILocation(line: 100, column: 3, scope: !488)
!906 = !DILocation(line: 101, column: 24, scope: !488)
!907 = !DILocation(line: 101, column: 64, scope: !488)
!908 = !DILocation(line: 101, column: 104, scope: !488)
!909 = !DILocation(line: 101, column: 144, scope: !488)
!910 = !DILocation(line: 101, column: 14, scope: !488)
!911 = !DILocalVariable(name: "seen-59", scope: !488, file: !33, line: 101, type: !10)
!912 = !DILocation(line: 101, column: 3, scope: !488)
!913 = !DILocation(line: 102, column: 24, scope: !488)
!914 = !DILocation(line: 102, column: 64, scope: !488)
!915 = !DILocation(line: 102, column: 104, scope: !488)
!916 = !DILocation(line: 102, column: 144, scope: !488)
!917 = !DILocation(line: 102, column: 14, scope: !488)
!918 = !DILocalVariable(name: "seen-60", scope: !488, file: !33, line: 102, type: !10)
!919 = !DILocation(line: 102, column: 3, scope: !488)
!920 = !DILocation(line: 103, column: 24, scope: !488)
!921 = !DILocation(line: 103, column: 64, scope: !488)
!922 = !DILocation(line: 103, column: 104, scope: !488)
!923 = !DILocation(line: 103, column: 144, scope: !488)
!924 = !DILocation(line: 103, column: 14, scope: !488)
!925 = !DILocalVariable(name: "seen-61", scope: !488, file: !33, line: 103, type: !10)
!926 = !DILocation(line: 103, column: 3, scope: !488)
!927 = !DILocation(line: 104, column: 24, scope: !488)
!928 = !DILocation(line: 104, column: 64, scope: !488)
!929 = !DILocation(line: 104, column: 104, scope: !488)
!930 = !DILocation(line: 104, column: 144, scope: !488)
!931 = !DILocation(line: 104, column: 14, scope: !488)
!932 = !DILocalVariable(name: "seen-62", scope: !488, file: !33, line: 104, type: !10)
!933 = !DILocation(line: 104, column: 3, scope: !488)
!934 = !DILocation(line: 105, column: 24, scope: !488)
!935 = !DILocation(line: 105, column: 64, scope: !488)
!936 = !DILocation(line: 105, column: 104, scope: !488)
!937 = !DILocation(line: 105, column: 144, scope: !488)
!938 = !DILocation(line: 105, column: 14, scope: !488)
!939 = !DILocalVariable(name: "seen-63", scope: !488, file: !33, line: 105, type: !10)
!940 = !DILocation(line: 105, column: 3, scope: !488)
!941 = !DILocation(line: 106, column: 16, scope: !488)
!942 = !DILocalVariable(name: "checked-0", scope: !488, file: !33, line: 106, type: !10)
!943 = !DILocation(line: 106, column: 3, scope: !488)
!944 = !DILocation(line: 107, column: 16, scope: !488)
!945 = !DILocalVariable(name: "checked-1", scope: !488, file: !33, line: 107, type: !10)
!946 = !DILocation(line: 107, column: 3, scope: !488)
!947 = !DILocation(line: 108, column: 16, scope: !488)
!948 = !DILocalVariable(name: "checked-2", scope: !488, file: !33, line: 108, type: !10)
!949 = !DILocation(line: 108, column: 3, scope: !488)
!950 = !DILocation(line: 109, column: 16, scope: !488)
!951 = !DILocalVariable(name: "checked-3", scope: !488, file: !33, line: 109, type: !10)
!952 = !DILocation(line: 109, column: 3, scope: !488)
!953 = !DILocation(line: 110, column: 16, scope: !488)
!954 = !DILocalVariable(name: "checked-4", scope: !488, file: !33, line: 110, type: !10)
!955 = !DILocation(line: 110, column: 3, scope: !488)
!956 = !DILocation(line: 111, column: 16, scope: !488)
!957 = !DILocalVariable(name: "checked-5", scope: !488, file: !33, line: 111, type: !10)
!958 = !DILocation(line: 111, column: 3, scope: !488)
!959 = !DILocation(line: 112, column: 16, scope: !488)
!960 = !DILocalVariable(name: "checked-6", scope: !488, file: !33, line: 112, type: !10)
!961 = !DILocation(line: 112, column: 3, scope: !488)
!962 = !DILocation(line: 113, column: 16, scope: !488)
!963 = !DILocalVariable(name: "checked-7", scope: !488, file: !33, line: 113, type: !10)
!964 = !DILocation(line: 113, column: 3, scope: !488)
!965 = !DILocation(line: 114, column: 16, scope: !488)
!966 = !DILocalVariable(name: "checked-8", scope: !488, file: !33, line: 114, type: !10)
!967 = !DILocation(line: 114, column: 3, scope: !488)
!968 = !DILocation(line: 115, column: 16, scope: !488)
!969 = !DILocalVariable(name: "checked-9", scope: !488, file: !33, line: 115, type: !10)
!970 = !DILocation(line: 115, column: 3, scope: !488)
!971 = !DILocation(line: 116, column: 17, scope: !488)
!972 = !DILocalVariable(name: "checked-10", scope: !488, file: !33, line: 116, type: !10)
!973 = !DILocation(line: 116, column: 3, scope: !488)
!974 = !DILocation(line: 117, column: 17, scope: !488)
!975 = !DILocalVariable(name: "checked-11", scope: !488, file: !33, line: 117, type: !10)
!976 = !DILocation(line: 117, column: 3, scope: !488)
!977 = !DILocation(line: 118, column: 17, scope: !488)
!978 = !DILocalVariable(name: "checked-12", scope: !488, file: !33, line: 118, type: !10)
!979 = !DILocation(line: 118, column: 3, scope: !488)
!980 = !DILocation(line: 119, column: 17, scope: !488)
!981 = !DILocalVariable(name: "checked-13", scope: !488, file: !33, line: 119, type: !10)
!982 = !DILocation(line: 119, column: 3, scope: !488)
!983 = !DILocation(line: 120, column: 17, scope: !488)
!984 = !DILocalVariable(name: "checked-14", scope: !488, file: !33, line: 120, type: !10)
!985 = !DILocation(line: 120, column: 3, scope: !488)
!986 = !DILocation(line: 121, column: 17, scope: !488)
!987 = !DILocalVariable(name: "checked-15", scope: !488, file: !33, line: 121, type: !10)
!988 = !DILocation(line: 121, column: 3, scope: !488)
!989 = !DILocation(line: 122, column: 14, scope: !488)
!990 = !DILocalVariable(name: "range-0", scope: !488, file: !33, line: 122, type: !10)
!991 = !DILocation(line: 122, column: 3, scope: !488)
!992 = !DILocation(line: 123, column: 14, scope: !488)
!993 = !DILocalVariable(name: "range-1", scope: !488, file: !33, line: 123, type: !10)
!994 = !DILocation(line: 123, column: 3, scope: !488)
!995 = !DILocation(line: 124, column: 14, scope: !488)
!996 = !DILocalVariable(name: "range-2", scope: !488, file: !33, line: 124, type: !10)
!997 = !DILocation(line: 124, column: 3, scope: !488)
!998 = !DILocation(line: 125, column: 14, scope: !488)
!999 = !DILocalVariable(name: "range-3", scope: !488, file: !33, line: 125, type: !10)
!1000 = !DILocation(line: 125, column: 3, scope: !488)
!1001 = !DILocation(line: 126, column: 3, scope: !488)
!1002 = distinct !DISubprogram(name: "support.namespace-bytes.valid-normal", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dnormal.1957", scope: !33, file: !33, line: 141, type: !256, scopeLine: 141, spFlags: DISPFlagDefinition, unit: !0)
!1003 = !DILocalVariable(name: "region", arg: 1, scope: !1002, file: !33, line: 141, type: !43)
!1004 = !DILocation(line: 141, column: 22, scope: !1002)
!1005 = !DILocalVariable(name: "length", arg: 2, scope: !1002, file: !33, line: 141, type: !36)
!1006 = !DILocation(line: 141, column: 49, scope: !1002)
!1007 = !DILocation(line: 142, column: 3, scope: !1002)
!1008 = !DILocation(line: 143, column: 15, scope: !1002)
!1009 = !DILocation(line: 144, column: 16, scope: !1002)
!1010 = distinct !DISubprogram(name: "support.namespace-bytes.valid-bounded", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbounded.1958", scope: !33, file: !33, line: 146, type: !256, scopeLine: 146, spFlags: DISPFlagDefinition, unit: !0)
!1011 = !DILocalVariable(name: "region", arg: 1, scope: !1010, file: !33, line: 146, type: !43)
!1012 = !DILocation(line: 146, column: 23, scope: !1010)
!1013 = !DILocalVariable(name: "length", arg: 2, scope: !1010, file: !33, line: 146, type: !36)
!1014 = !DILocation(line: 146, column: 50, scope: !1010)
!1015 = !DILocation(line: 147, column: 3, scope: !1010)
!1016 = !DILocation(line: 148, column: 15, scope: !1010)
!1017 = !DILocation(line: 149, column: 16, scope: !1010)
!1018 = distinct !DISubprogram(name: "support.namespace-bytes.valid-input", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dinput.1959", scope: !33, file: !33, line: 151, type: !256, scopeLine: 151, spFlags: DISPFlagDefinition, unit: !0)
!1019 = !DILocalVariable(name: "region", arg: 1, scope: !1018, file: !33, line: 151, type: !43)
!1020 = !DILocation(line: 151, column: 25, scope: !1018)
!1021 = !DILocalVariable(name: "length", arg: 2, scope: !1018, file: !33, line: 151, type: !36)
!1022 = !DILocation(line: 151, column: 52, scope: !1018)
!1023 = !DILocation(line: 152, column: 3, scope: !1018)
!1024 = !DILocation(line: 153, column: 15, scope: !1018)
!1025 = !DILocation(line: 154, column: 16, scope: !1018)
!1026 = distinct !DISubprogram(name: "support.namespace-metadata.input-clean", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2einput_2dclean.1962", scope: !7, file: !7, line: 97, type: !256, scopeLine: 97, spFlags: DISPFlagDefinition, unit: !0)
!1027 = !DILocalVariable(name: "region", arg: 1, scope: !1026, file: !7, line: 97, type: !43)
!1028 = !DILocation(line: 97, column: 21, scope: !1026)
!1029 = !DILocalVariable(name: "length", arg: 2, scope: !1026, file: !7, line: 97, type: !36)
!1030 = !DILocation(line: 97, column: 48, scope: !1026)
!1031 = !DILocation(line: 98, column: 13, scope: !1026)
!1032 = !DILocalVariable(name: "middle", scope: !1026, file: !7, line: 98, type: !10)
!1033 = !DILocation(line: 98, column: 3, scope: !1026)
!1034 = !DILocation(line: 99, column: 10, scope: !1026)
!1035 = !DILocalVariable(name: "end", scope: !1026, file: !7, line: 99, type: !10)
!1036 = !DILocation(line: 99, column: 3, scope: !1026)
!1037 = !DILocation(line: 100, column: 12, scope: !1026)
!1038 = !DILocalVariable(name: "valid", scope: !1026, file: !7, line: 100, type: !10)
!1039 = !DILocation(line: 100, column: 3, scope: !1026)
!1040 = !DILocation(line: 101, column: 16, scope: !1026)
!1041 = !DILocation(line: 101, column: 3, scope: !1026)
!1042 = distinct !DISubprogram(name: "support.namespace-bytes.copy-word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970", scope: !33, file: !33, line: 156, type: !150, scopeLine: 156, spFlags: DISPFlagDefinition, unit: !0)
!1043 = !DILocalVariable(name: "region", arg: 1, scope: !1042, file: !33, line: 156, type: !43)
!1044 = !DILocation(line: 156, column: 19, scope: !1042)
!1045 = !DILocalVariable(name: "destination", arg: 2, scope: !1042, file: !33, line: 156, type: !36)
!1046 = !DILocation(line: 156, column: 46, scope: !1042)
!1047 = !DILocalVariable(name: "source", arg: 3, scope: !1042, file: !33, line: 156, type: !36)
!1048 = !DILocation(line: 156, column: 65, scope: !1042)
!1049 = !DILocation(line: 157, column: 3, scope: !1042)
!1050 = !DILocation(line: 158, column: 10, scope: !1042)
!1051 = !DILocalVariable(name: "value", scope: !1042, file: !33, line: 158, type: !36)
!1052 = !DILocation(line: 158, column: 21, scope: !1042)
!1053 = !DILocation(line: 159, column: 15, scope: !1042)
!1054 = distinct !DISubprogram(name: "support.namespace-bytes.copy-pair", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972", scope: !33, file: !33, line: 168, type: !150, scopeLine: 168, spFlags: DISPFlagDefinition, unit: !0)
!1055 = !DILocalVariable(name: "region", arg: 1, scope: !1054, file: !33, line: 168, type: !43)
!1056 = !DILocation(line: 168, column: 19, scope: !1054)
!1057 = !DILocalVariable(name: "destination", arg: 2, scope: !1054, file: !33, line: 168, type: !36)
!1058 = !DILocation(line: 168, column: 46, scope: !1054)
!1059 = !DILocalVariable(name: "source", arg: 3, scope: !1054, file: !33, line: 168, type: !36)
!1060 = !DILocation(line: 168, column: 65, scope: !1054)
!1061 = !DILocation(line: 169, column: 3, scope: !1054)
!1062 = !DILocation(line: 170, column: 34, scope: !1054)
!1063 = !DILocation(line: 170, column: 51, scope: !1054)
!1064 = !DILocation(line: 170, column: 15, scope: !1054)
!1065 = !DILocation(line: 171, column: 16, scope: !1054)
!1066 = distinct !DISubprogram(name: "support.namespace-bytes.copy-block", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976", scope: !33, file: !33, line: 183, type: !150, scopeLine: 183, spFlags: DISPFlagDefinition, unit: !0)
!1067 = !DILocalVariable(name: "region", arg: 1, scope: !1066, file: !33, line: 183, type: !43)
!1068 = !DILocation(line: 183, column: 20, scope: !1066)
!1069 = !DILocalVariable(name: "destination", arg: 2, scope: !1066, file: !33, line: 183, type: !36)
!1070 = !DILocation(line: 183, column: 47, scope: !1066)
!1071 = !DILocalVariable(name: "source", arg: 3, scope: !1066, file: !33, line: 183, type: !36)
!1072 = !DILocation(line: 183, column: 66, scope: !1066)
!1073 = !DILocation(line: 184, column: 3, scope: !1066)
!1074 = !DILocation(line: 185, column: 34, scope: !1066)
!1075 = !DILocation(line: 185, column: 52, scope: !1066)
!1076 = !DILocation(line: 185, column: 15, scope: !1066)
!1077 = !DILocation(line: 186, column: 16, scope: !1066)
!1078 = distinct !DISubprogram(name: "support.namespace-bytes.copy-quarter", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984", scope: !33, file: !33, line: 198, type: !150, scopeLine: 198, spFlags: DISPFlagDefinition, unit: !0)
!1079 = !DILocalVariable(name: "region", arg: 1, scope: !1078, file: !33, line: 198, type: !43)
!1080 = !DILocation(line: 198, column: 22, scope: !1078)
!1081 = !DILocalVariable(name: "destination", arg: 2, scope: !1078, file: !33, line: 198, type: !36)
!1082 = !DILocation(line: 198, column: 49, scope: !1078)
!1083 = !DILocalVariable(name: "source", arg: 3, scope: !1078, file: !33, line: 198, type: !36)
!1084 = !DILocation(line: 198, column: 68, scope: !1078)
!1085 = !DILocation(line: 199, column: 3, scope: !1078)
!1086 = !DILocation(line: 200, column: 35, scope: !1078)
!1087 = !DILocation(line: 200, column: 53, scope: !1078)
!1088 = !DILocation(line: 200, column: 15, scope: !1078)
!1089 = !DILocation(line: 201, column: 16, scope: !1078)
!1090 = distinct !DISubprogram(name: "support.namespace-bytes.copy-half", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000", scope: !33, file: !33, line: 213, type: !150, scopeLine: 213, spFlags: DISPFlagDefinition, unit: !0)
!1091 = !DILocalVariable(name: "region", arg: 1, scope: !1090, file: !33, line: 213, type: !43)
!1092 = !DILocation(line: 213, column: 19, scope: !1090)
!1093 = !DILocalVariable(name: "destination", arg: 2, scope: !1090, file: !33, line: 213, type: !36)
!1094 = !DILocation(line: 213, column: 46, scope: !1090)
!1095 = !DILocalVariable(name: "source", arg: 3, scope: !1090, file: !33, line: 213, type: !36)
!1096 = !DILocation(line: 213, column: 65, scope: !1090)
!1097 = !DILocation(line: 214, column: 3, scope: !1090)
!1098 = !DILocation(line: 215, column: 37, scope: !1090)
!1099 = !DILocation(line: 215, column: 55, scope: !1090)
!1100 = !DILocation(line: 215, column: 15, scope: !1090)
!1101 = !DILocation(line: 216, column: 16, scope: !1090)
!1102 = distinct !DISubprogram(name: "support.namespace-bytes.copy-name", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032", scope: !33, file: !33, line: 228, type: !150, scopeLine: 228, spFlags: DISPFlagDefinition, unit: !0)
!1103 = !DILocalVariable(name: "region", arg: 1, scope: !1102, file: !33, line: 228, type: !43)
!1104 = !DILocation(line: 228, column: 23, scope: !1102)
!1105 = !DILocalVariable(name: "destination", arg: 2, scope: !1102, file: !33, line: 228, type: !36)
!1106 = !DILocation(line: 228, column: 50, scope: !1102)
!1107 = !DILocalVariable(name: "source", arg: 3, scope: !1102, file: !33, line: 228, type: !36)
!1108 = !DILocation(line: 228, column: 69, scope: !1102)
!1109 = !DILocation(line: 229, column: 3, scope: !1102)
!1110 = !DILocation(line: 230, column: 34, scope: !1102)
!1111 = !DILocation(line: 230, column: 53, scope: !1102)
!1112 = !DILocation(line: 230, column: 15, scope: !1102)
!1113 = !DILocation(line: 231, column: 16, scope: !1102)
!1114 = distinct !DISubprogram(name: "support.namespace-metadata.write", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033", scope: !7, file: !7, line: 11, type: !150, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !0)
!1115 = !DILocalVariable(name: "region", arg: 1, scope: !1114, file: !7, line: 11, type: !43)
!1116 = !DILocation(line: 11, column: 15, scope: !1114)
!1117 = !DILocalVariable(name: "offset", arg: 2, scope: !1114, file: !7, line: 11, type: !36)
!1118 = !DILocation(line: 11, column: 42, scope: !1114)
!1119 = !DILocalVariable(name: "value", arg: 3, scope: !1114, file: !7, line: 11, type: !36)
!1120 = !DILocation(line: 11, column: 56, scope: !1114)
!1121 = !DILocation(line: 12, column: 3, scope: !1114)
!1122 = distinct !DISubprogram(name: "support.namespace-metadata.parent-times", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046", scope: !7, file: !7, line: 103, type: !256, scopeLine: 103, spFlags: DISPFlagDefinition, unit: !0)
!1123 = !DILocalVariable(name: "region", arg: 1, scope: !1122, file: !7, line: 103, type: !43)
!1124 = !DILocation(line: 103, column: 22, scope: !1122)
!1125 = !DILocalVariable(name: "seconds", arg: 2, scope: !1122, file: !7, line: 103, type: !36)
!1126 = !DILocation(line: 103, column: 49, scope: !1122)
!1127 = !DILocation(line: 104, column: 15, scope: !1122)
!1128 = !DILocalVariable(name: "modified", scope: !1122, file: !7, line: 104, type: !10)
!1129 = !DILocation(line: 104, column: 3, scope: !1122)
!1130 = !DILocation(line: 105, column: 14, scope: !1122)
!1131 = !DILocalVariable(name: "changed", scope: !1122, file: !7, line: 105, type: !10)
!1132 = !DILocation(line: 105, column: 3, scope: !1122)
!1133 = !DILocation(line: 106, column: 3, scope: !1122)
!1134 = distinct !DISubprogram(name: "support.namespace-metadata.link-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elink_2deffect.2048", scope: !7, file: !7, line: 108, type: !193, scopeLine: 108, spFlags: DISPFlagDefinition, unit: !0)
!1135 = !DILocalVariable(name: "region", arg: 1, scope: !1134, file: !7, line: 108, type: !43)
!1136 = !DILocation(line: 108, column: 21, scope: !1134)
!1137 = !DILocation(line: 108, column: 48, scope: !1134)
!1138 = !DILocalVariable(name: "facts", arg: 2, scope: !1134, file: !7, line: 108, type: !64)
!1139 = !DILocalVariable(name: "seconds", arg: 3, scope: !1134, file: !7, line: 108, type: !36)
!1140 = !DILocation(line: 108, column: 227, scope: !1134)
!1141 = !DILocation(line: 109, column: 11, scope: !1134)
!1142 = !DILocalVariable(name: "base", scope: !1134, file: !7, line: 109, type: !36)
!1143 = !DILocation(line: 109, column: 3, scope: !1134)
!1144 = !DILocation(line: 110, column: 12, scope: !1134)
!1145 = !DILocalVariable(name: "entry", scope: !1134, file: !7, line: 110, type: !36)
!1146 = !DILocation(line: 110, column: 3, scope: !1134)
!1147 = !DILocation(line: 111, column: 58, scope: !1134)
!1148 = !DILocation(line: 111, column: 15, scope: !1134)
!1149 = !DILocalVariable(name: "effect-0", scope: !1134, file: !7, line: 111, type: !10)
!1150 = !DILocation(line: 111, column: 3, scope: !1134)
!1151 = !DILocation(line: 112, column: 15, scope: !1134)
!1152 = !DILocalVariable(name: "effect-1", scope: !1134, file: !7, line: 112, type: !10)
!1153 = !DILocation(line: 112, column: 3, scope: !1134)
!1154 = !DILocation(line: 113, column: 30, scope: !1134)
!1155 = !DILocation(line: 113, column: 15, scope: !1134)
!1156 = !DILocalVariable(name: "effect-2", scope: !1134, file: !7, line: 113, type: !10)
!1157 = !DILocation(line: 113, column: 3, scope: !1134)
!1158 = !DILocation(line: 114, column: 30, scope: !1134)
!1159 = !DILocation(line: 114, column: 42, scope: !1134)
!1160 = !DILocation(line: 114, column: 15, scope: !1134)
!1161 = !DILocalVariable(name: "effect-3", scope: !1134, file: !7, line: 114, type: !10)
!1162 = !DILocation(line: 114, column: 3, scope: !1134)
!1163 = !DILocation(line: 115, column: 30, scope: !1134)
!1164 = !DILocation(line: 115, column: 15, scope: !1134)
!1165 = !DILocalVariable(name: "effect-4", scope: !1134, file: !7, line: 115, type: !10)
!1166 = !DILocation(line: 115, column: 3, scope: !1134)
!1167 = !DILocation(line: 116, column: 30, scope: !1134)
!1168 = !DILocation(line: 116, column: 15, scope: !1134)
!1169 = !DILocalVariable(name: "effect-5", scope: !1134, file: !7, line: 116, type: !10)
!1170 = !DILocation(line: 116, column: 3, scope: !1134)
!1171 = !DILocation(line: 117, column: 86, scope: !1134)
!1172 = !DILocation(line: 117, column: 70, scope: !1134)
!1173 = !DILocation(line: 117, column: 54, scope: !1134)
!1174 = !DILocation(line: 117, column: 38, scope: !1134)
!1175 = !DILocation(line: 117, column: 22, scope: !1134)
!1176 = !DILocalVariable(name: "objects-changed", scope: !1134, file: !7, line: 117, type: !10)
!1177 = !DILocation(line: 117, column: 3, scope: !1134)
!1178 = !DILocation(line: 118, column: 21, scope: !1134)
!1179 = !DILocalVariable(name: "parent-changed", scope: !1134, file: !7, line: 118, type: !10)
!1180 = !DILocation(line: 118, column: 3, scope: !1134)
!1181 = !DILocation(line: 119, column: 3, scope: !1134)
!1182 = distinct !DISubprogram(name: "support.namespace-metadata.move-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2emove_2deffect.2124", scope: !7, file: !7, line: 121, type: !193, scopeLine: 121, spFlags: DISPFlagDefinition, unit: !0)
!1183 = !DILocalVariable(name: "region", arg: 1, scope: !1182, file: !7, line: 121, type: !43)
!1184 = !DILocation(line: 121, column: 21, scope: !1182)
!1185 = !DILocation(line: 121, column: 48, scope: !1182)
!1186 = !DILocalVariable(name: "facts", arg: 2, scope: !1182, file: !7, line: 121, type: !64)
!1187 = !DILocalVariable(name: "seconds", arg: 3, scope: !1182, file: !7, line: 121, type: !36)
!1188 = !DILocation(line: 121, column: 227, scope: !1182)
!1189 = !DILocation(line: 122, column: 12, scope: !1182)
!1190 = !DILocalVariable(name: "entry", scope: !1182, file: !7, line: 122, type: !36)
!1191 = !DILocation(line: 122, column: 3, scope: !1182)
!1192 = !DILocation(line: 123, column: 58, scope: !1182)
!1193 = !DILocation(line: 123, column: 15, scope: !1182)
!1194 = !DILocalVariable(name: "effect-0", scope: !1182, file: !7, line: 123, type: !10)
!1195 = !DILocation(line: 123, column: 3, scope: !1182)
!1196 = !DILocation(line: 124, column: 30, scope: !1182)
!1197 = !DILocation(line: 124, column: 15, scope: !1182)
!1198 = !DILocalVariable(name: "effect-1", scope: !1182, file: !7, line: 124, type: !10)
!1199 = !DILocation(line: 124, column: 3, scope: !1182)
!1200 = !DILocation(line: 125, column: 31, scope: !1182)
!1201 = !DILocation(line: 125, column: 15, scope: !1182)
!1202 = !DILocalVariable(name: "effect-2", scope: !1182, file: !7, line: 125, type: !10)
!1203 = !DILocation(line: 125, column: 3, scope: !1182)
!1204 = !DILocation(line: 126, column: 38, scope: !1182)
!1205 = !DILocation(line: 126, column: 22, scope: !1182)
!1206 = !DILocalVariable(name: "objects-changed", scope: !1182, file: !7, line: 126, type: !10)
!1207 = !DILocation(line: 126, column: 3, scope: !1182)
!1208 = !DILocation(line: 127, column: 21, scope: !1182)
!1209 = !DILocalVariable(name: "parent-changed", scope: !1182, file: !7, line: 127, type: !10)
!1210 = !DILocation(line: 127, column: 3, scope: !1182)
!1211 = !DILocation(line: 128, column: 3, scope: !1182)
!1212 = distinct !DISubprogram(name: "support.namespace-bytes.clear-word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134", scope: !33, file: !33, line: 161, type: !256, scopeLine: 161, spFlags: DISPFlagDefinition, unit: !0)
!1213 = !DILocalVariable(name: "region", arg: 1, scope: !1212, file: !33, line: 161, type: !43)
!1214 = !DILocation(line: 161, column: 20, scope: !1212)
!1215 = !DILocalVariable(name: "destination", arg: 2, scope: !1212, file: !33, line: 161, type: !36)
!1216 = !DILocation(line: 161, column: 47, scope: !1212)
!1217 = !DILocation(line: 162, column: 3, scope: !1212)
!1218 = distinct !DISubprogram(name: "support.namespace-bytes.clear-pair", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136", scope: !33, file: !33, line: 173, type: !256, scopeLine: 173, spFlags: DISPFlagDefinition, unit: !0)
!1219 = !DILocalVariable(name: "region", arg: 1, scope: !1218, file: !33, line: 173, type: !43)
!1220 = !DILocation(line: 173, column: 20, scope: !1218)
!1221 = !DILocalVariable(name: "destination", arg: 2, scope: !1218, file: !33, line: 173, type: !36)
!1222 = !DILocation(line: 173, column: 47, scope: !1218)
!1223 = !DILocation(line: 174, column: 3, scope: !1218)
!1224 = !DILocation(line: 175, column: 35, scope: !1218)
!1225 = !DILocation(line: 175, column: 15, scope: !1218)
!1226 = !DILocation(line: 176, column: 16, scope: !1218)
!1227 = distinct !DISubprogram(name: "support.namespace-bytes.clear-block", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140", scope: !33, file: !33, line: 188, type: !256, scopeLine: 188, spFlags: DISPFlagDefinition, unit: !0)
!1228 = !DILocalVariable(name: "region", arg: 1, scope: !1227, file: !33, line: 188, type: !43)
!1229 = !DILocation(line: 188, column: 21, scope: !1227)
!1230 = !DILocalVariable(name: "destination", arg: 2, scope: !1227, file: !33, line: 188, type: !36)
!1231 = !DILocation(line: 188, column: 48, scope: !1227)
!1232 = !DILocation(line: 189, column: 3, scope: !1227)
!1233 = !DILocation(line: 190, column: 35, scope: !1227)
!1234 = !DILocation(line: 190, column: 15, scope: !1227)
!1235 = !DILocation(line: 191, column: 16, scope: !1227)
!1236 = distinct !DISubprogram(name: "support.namespace-bytes.clear-quarter", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148", scope: !33, file: !33, line: 203, type: !256, scopeLine: 203, spFlags: DISPFlagDefinition, unit: !0)
!1237 = !DILocalVariable(name: "region", arg: 1, scope: !1236, file: !33, line: 203, type: !43)
!1238 = !DILocation(line: 203, column: 23, scope: !1236)
!1239 = !DILocalVariable(name: "destination", arg: 2, scope: !1236, file: !33, line: 203, type: !36)
!1240 = !DILocation(line: 203, column: 50, scope: !1236)
!1241 = !DILocation(line: 204, column: 3, scope: !1236)
!1242 = !DILocation(line: 205, column: 36, scope: !1236)
!1243 = !DILocation(line: 205, column: 15, scope: !1236)
!1244 = !DILocation(line: 206, column: 16, scope: !1236)
!1245 = distinct !DISubprogram(name: "support.namespace-bytes.clear-half", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164", scope: !33, file: !33, line: 218, type: !256, scopeLine: 218, spFlags: DISPFlagDefinition, unit: !0)
!1246 = !DILocalVariable(name: "region", arg: 1, scope: !1245, file: !33, line: 218, type: !43)
!1247 = !DILocation(line: 218, column: 20, scope: !1245)
!1248 = !DILocalVariable(name: "destination", arg: 2, scope: !1245, file: !33, line: 218, type: !36)
!1249 = !DILocation(line: 218, column: 47, scope: !1245)
!1250 = !DILocation(line: 219, column: 3, scope: !1245)
!1251 = !DILocation(line: 220, column: 38, scope: !1245)
!1252 = !DILocation(line: 220, column: 15, scope: !1245)
!1253 = !DILocation(line: 221, column: 16, scope: !1245)
!1254 = distinct !DISubprogram(name: "support.namespace-bytes.clear-name", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dname.2196", scope: !33, file: !33, line: 233, type: !256, scopeLine: 233, spFlags: DISPFlagDefinition, unit: !0)
!1255 = !DILocalVariable(name: "region", arg: 1, scope: !1254, file: !33, line: 233, type: !43)
!1256 = !DILocation(line: 233, column: 24, scope: !1254)
!1257 = !DILocalVariable(name: "destination", arg: 2, scope: !1254, file: !33, line: 233, type: !36)
!1258 = !DILocation(line: 233, column: 51, scope: !1254)
!1259 = !DILocation(line: 234, column: 3, scope: !1254)
!1260 = !DILocation(line: 235, column: 35, scope: !1254)
!1261 = !DILocation(line: 235, column: 15, scope: !1254)
!1262 = !DILocation(line: 236, column: 16, scope: !1254)
!1263 = distinct !DISubprogram(name: "support.namespace-metadata.replace-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ereplace_2deffect.2212", scope: !7, file: !7, line: 130, type: !193, scopeLine: 130, spFlags: DISPFlagDefinition, unit: !0)
!1264 = !DILocalVariable(name: "region", arg: 1, scope: !1263, file: !7, line: 130, type: !43)
!1265 = !DILocation(line: 130, column: 24, scope: !1263)
!1266 = !DILocation(line: 130, column: 51, scope: !1263)
!1267 = !DILocalVariable(name: "facts", arg: 2, scope: !1263, file: !7, line: 130, type: !64)
!1268 = !DILocalVariable(name: "seconds", arg: 3, scope: !1263, file: !7, line: 130, type: !36)
!1269 = !DILocation(line: 130, column: 230, scope: !1263)
!1270 = !DILocation(line: 131, column: 13, scope: !1263)
!1271 = !DILocalVariable(name: "source", scope: !1263, file: !7, line: 131, type: !36)
!1272 = !DILocation(line: 131, column: 3, scope: !1263)
!1273 = !DILocation(line: 132, column: 13, scope: !1263)
!1274 = !DILocalVariable(name: "victim", scope: !1263, file: !7, line: 132, type: !36)
!1275 = !DILocation(line: 132, column: 3, scope: !1263)
!1276 = !DILocation(line: 133, column: 47, scope: !1263)
!1277 = !DILocation(line: 133, column: 33, scope: !1263)
!1278 = !DILocation(line: 133, column: 22, scope: !1263)
!1279 = !DILocalVariable(name: "remaining", scope: !1263, file: !7, line: 133, type: !36)
!1280 = !DILocation(line: 133, column: 3, scope: !1263)
!1281 = !DILocation(line: 134, column: 30, scope: !1263)
!1282 = !DILocation(line: 134, column: 15, scope: !1263)
!1283 = !DILocalVariable(name: "effect-0", scope: !1263, file: !7, line: 134, type: !10)
!1284 = !DILocation(line: 134, column: 3, scope: !1263)
!1285 = !DILocation(line: 135, column: 15, scope: !1263)
!1286 = !DILocalVariable(name: "effect-1", scope: !1263, file: !7, line: 135, type: !10)
!1287 = !DILocation(line: 135, column: 3, scope: !1263)
!1288 = !DILocation(line: 136, column: 30, scope: !1263)
!1289 = !DILocation(line: 136, column: 15, scope: !1263)
!1290 = !DILocalVariable(name: "effect-2", scope: !1263, file: !7, line: 136, type: !10)
!1291 = !DILocation(line: 136, column: 3, scope: !1263)
!1292 = !DILocation(line: 137, column: 59, scope: !1263)
!1293 = !DILocation(line: 137, column: 15, scope: !1263)
!1294 = !DILocalVariable(name: "effect-3", scope: !1263, file: !7, line: 137, type: !10)
!1295 = !DILocation(line: 137, column: 3, scope: !1263)
!1296 = !DILocation(line: 138, column: 30, scope: !1263)
!1297 = !DILocation(line: 138, column: 15, scope: !1263)
!1298 = !DILocalVariable(name: "effect-4", scope: !1263, file: !7, line: 138, type: !10)
!1299 = !DILocation(line: 138, column: 3, scope: !1263)
!1300 = !DILocation(line: 139, column: 30, scope: !1263)
!1301 = !DILocation(line: 139, column: 15, scope: !1263)
!1302 = !DILocalVariable(name: "effect-5", scope: !1263, file: !7, line: 139, type: !10)
!1303 = !DILocation(line: 139, column: 3, scope: !1263)
!1304 = !DILocation(line: 140, column: 31, scope: !1263)
!1305 = !DILocation(line: 140, column: 15, scope: !1263)
!1306 = !DILocalVariable(name: "effect-6", scope: !1263, file: !7, line: 140, type: !10)
!1307 = !DILocation(line: 140, column: 3, scope: !1263)
!1308 = !DILocation(line: 141, column: 102, scope: !1263)
!1309 = !DILocation(line: 141, column: 86, scope: !1263)
!1310 = !DILocation(line: 141, column: 70, scope: !1263)
!1311 = !DILocation(line: 141, column: 54, scope: !1263)
!1312 = !DILocation(line: 141, column: 38, scope: !1263)
!1313 = !DILocation(line: 141, column: 22, scope: !1263)
!1314 = !DILocalVariable(name: "objects-changed", scope: !1263, file: !7, line: 141, type: !10)
!1315 = !DILocation(line: 141, column: 3, scope: !1263)
!1316 = !DILocation(line: 142, column: 21, scope: !1263)
!1317 = !DILocalVariable(name: "parent-changed", scope: !1263, file: !7, line: 142, type: !10)
!1318 = !DILocation(line: 142, column: 3, scope: !1263)
!1319 = !DILocation(line: 143, column: 3, scope: !1263)
!1320 = distinct !DISubprogram(name: "support.namespace-metadata.exchange-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eexchange_2deffect.2229", scope: !7, file: !7, line: 145, type: !193, scopeLine: 145, spFlags: DISPFlagDefinition, unit: !0)
!1321 = !DILocalVariable(name: "region", arg: 1, scope: !1320, file: !7, line: 145, type: !43)
!1322 = !DILocation(line: 145, column: 25, scope: !1320)
!1323 = !DILocation(line: 145, column: 52, scope: !1320)
!1324 = !DILocalVariable(name: "facts", arg: 2, scope: !1320, file: !7, line: 145, type: !64)
!1325 = !DILocalVariable(name: "seconds", arg: 3, scope: !1320, file: !7, line: 145, type: !36)
!1326 = !DILocation(line: 145, column: 231, scope: !1320)
!1327 = !DILocation(line: 146, column: 13, scope: !1320)
!1328 = !DILocalVariable(name: "source", scope: !1320, file: !7, line: 146, type: !36)
!1329 = !DILocation(line: 146, column: 3, scope: !1320)
!1330 = !DILocation(line: 147, column: 15, scope: !1320)
!1331 = !DILocalVariable(name: "effect-0", scope: !1320, file: !7, line: 147, type: !10)
!1332 = !DILocation(line: 147, column: 3, scope: !1320)
!1333 = !DILocation(line: 148, column: 30, scope: !1320)
!1334 = !DILocation(line: 148, column: 15, scope: !1320)
!1335 = !DILocalVariable(name: "effect-1", scope: !1320, file: !7, line: 148, type: !10)
!1336 = !DILocation(line: 148, column: 3, scope: !1320)
!1337 = !DILocation(line: 149, column: 31, scope: !1320)
!1338 = !DILocation(line: 149, column: 15, scope: !1320)
!1339 = !DILocalVariable(name: "effect-2", scope: !1320, file: !7, line: 149, type: !10)
!1340 = !DILocation(line: 149, column: 3, scope: !1320)
!1341 = !DILocation(line: 150, column: 31, scope: !1320)
!1342 = !DILocation(line: 150, column: 15, scope: !1320)
!1343 = !DILocalVariable(name: "effect-3", scope: !1320, file: !7, line: 150, type: !10)
!1344 = !DILocation(line: 150, column: 3, scope: !1320)
!1345 = !DILocation(line: 151, column: 54, scope: !1320)
!1346 = !DILocation(line: 151, column: 38, scope: !1320)
!1347 = !DILocation(line: 151, column: 22, scope: !1320)
!1348 = !DILocalVariable(name: "objects-changed", scope: !1320, file: !7, line: 151, type: !10)
!1349 = !DILocation(line: 151, column: 3, scope: !1320)
!1350 = !DILocation(line: 152, column: 21, scope: !1320)
!1351 = !DILocalVariable(name: "parent-changed", scope: !1320, file: !7, line: 152, type: !10)
!1352 = !DILocation(line: 152, column: 3, scope: !1320)
!1353 = !DILocation(line: 153, column: 3, scope: !1320)
!1354 = distinct !DISubprogram(name: "support.namespace-metadata.effect-replace-or-exchange", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2dreplace_2dor_2dexchange.2230", scope: !7, file: !7, line: 155, type: !1355, scopeLine: 155, spFlags: DISPFlagDefinition, unit: !0)
!1355 = !DISubroutineType(types: !1356)
!1356 = !{!10, !43, !64, !36, !36}
!1357 = !DILocalVariable(name: "region", arg: 1, scope: !1354, file: !7, line: 155, type: !43)
!1358 = !DILocation(line: 155, column: 36, scope: !1354)
!1359 = !DILocation(line: 155, column: 63, scope: !1354)
!1360 = !DILocalVariable(name: "facts", arg: 2, scope: !1354, file: !7, line: 155, type: !64)
!1361 = !DILocalVariable(name: "operation", arg: 3, scope: !1354, file: !7, line: 155, type: !36)
!1362 = !DILocation(line: 155, column: 242, scope: !1354)
!1363 = !DILocalVariable(name: "seconds", arg: 4, scope: !1354, file: !7, line: 155, type: !36)
!1364 = !DILocation(line: 155, column: 259, scope: !1354)
!1365 = !DILocation(line: 156, column: 3, scope: !1354)
!1366 = !DILocation(line: 157, column: 15, scope: !1354)
!1367 = !DILocation(line: 158, column: 16, scope: !1354)
!1368 = distinct !DISubprogram(name: "support.namespace-metadata.effect-rename", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2drename.2231", scope: !7, file: !7, line: 160, type: !1355, scopeLine: 160, spFlags: DISPFlagDefinition, unit: !0)
!1369 = !DILocalVariable(name: "region", arg: 1, scope: !1368, file: !7, line: 160, type: !43)
!1370 = !DILocation(line: 160, column: 23, scope: !1368)
!1371 = !DILocation(line: 160, column: 50, scope: !1368)
!1372 = !DILocalVariable(name: "facts", arg: 2, scope: !1368, file: !7, line: 160, type: !64)
!1373 = !DILocalVariable(name: "operation", arg: 3, scope: !1368, file: !7, line: 160, type: !36)
!1374 = !DILocation(line: 160, column: 229, scope: !1368)
!1375 = !DILocalVariable(name: "seconds", arg: 4, scope: !1368, file: !7, line: 160, type: !36)
!1376 = !DILocation(line: 160, column: 246, scope: !1368)
!1377 = !DILocation(line: 161, column: 3, scope: !1368)
!1378 = !DILocation(line: 162, column: 15, scope: !1368)
!1379 = !DILocation(line: 163, column: 16, scope: !1368)
!1380 = distinct !DISubprogram(name: "support.namespace-metadata.effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect.2232", scope: !7, file: !7, line: 165, type: !1355, scopeLine: 165, spFlags: DISPFlagDefinition, unit: !0)
!1381 = !DILocalVariable(name: "region", arg: 1, scope: !1380, file: !7, line: 165, type: !43)
!1382 = !DILocation(line: 165, column: 16, scope: !1380)
!1383 = !DILocation(line: 165, column: 43, scope: !1380)
!1384 = !DILocalVariable(name: "facts", arg: 2, scope: !1380, file: !7, line: 165, type: !64)
!1385 = !DILocalVariable(name: "operation", arg: 3, scope: !1380, file: !7, line: 165, type: !36)
!1386 = !DILocation(line: 165, column: 222, scope: !1380)
!1387 = !DILocalVariable(name: "seconds", arg: 4, scope: !1380, file: !7, line: 165, type: !36)
!1388 = !DILocation(line: 165, column: 239, scope: !1380)
!1389 = !DILocation(line: 166, column: 3, scope: !1380)
!1390 = !DILocation(line: 167, column: 15, scope: !1380)
!1391 = !DILocation(line: 168, column: 16, scope: !1380)
!1392 = distinct !DISubprogram(name: "support.namespace-metadata.checked", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2echecked.2233", scope: !7, file: !7, line: 171, type: !1355, scopeLine: 171, spFlags: DISPFlagDefinition, unit: !0)
!1393 = !DILocalVariable(name: "region", arg: 1, scope: !1392, file: !7, line: 171, type: !43)
!1394 = !DILocation(line: 171, column: 17, scope: !1392)
!1395 = !DILocation(line: 171, column: 44, scope: !1392)
!1396 = !DILocalVariable(name: "facts", arg: 2, scope: !1392, file: !7, line: 171, type: !64)
!1397 = !DILocalVariable(name: "operation", arg: 3, scope: !1392, file: !7, line: 171, type: !36)
!1398 = !DILocation(line: 171, column: 223, scope: !1392)
!1399 = !DILocalVariable(name: "seconds", arg: 4, scope: !1392, file: !7, line: 171, type: !36)
!1400 = !DILocation(line: 171, column: 240, scope: !1392)
!1401 = !DILocation(line: 172, column: 26, scope: !1392)
!1402 = !DILocation(line: 172, column: 43, scope: !1392)
!1403 = !DILocation(line: 172, column: 20, scope: !1392)
!1404 = !DILocation(line: 172, column: 15, scope: !1392)
!1405 = !DILocalVariable(name: "distinct", scope: !1392, file: !7, line: 172, type: !10)
!1406 = !DILocation(line: 172, column: 3, scope: !1392)
!1407 = !DILocation(line: 173, column: 18, scope: !1392)
!1408 = !DILocation(line: 173, column: 59, scope: !1392)
!1409 = !DILocation(line: 173, column: 100, scope: !1392)
!1410 = !DILocation(line: 173, column: 12, scope: !1392)
!1411 = !DILocalVariable(name: "valid", scope: !1392, file: !7, line: 173, type: !10)
!1412 = !DILocation(line: 173, column: 3, scope: !1392)
!1413 = !DILocation(line: 174, column: 3, scope: !1392)
!1414 = !DILocation(line: 175, column: 15, scope: !1392)
!1415 = !DILocation(line: 176, column: 16, scope: !1392)
!1416 = distinct !DISubprogram(name: "support.namespace-metadata.read-input", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eread_2dinput.2234", scope: !7, file: !7, line: 179, type: !150, scopeLine: 179, spFlags: DISPFlagDefinition, unit: !0)
!1417 = !DILocalVariable(name: "region", arg: 1, scope: !1416, file: !7, line: 179, type: !43)
!1418 = !DILocation(line: 179, column: 20, scope: !1416)
!1419 = !DILocalVariable(name: "operation", arg: 2, scope: !1416, file: !7, line: 179, type: !36)
!1420 = !DILocation(line: 179, column: 47, scope: !1416)
!1421 = !DILocalVariable(name: "seconds", arg: 3, scope: !1416, file: !7, line: 179, type: !36)
!1422 = !DILocation(line: 179, column: 64, scope: !1416)
!1423 = !DILocation(line: 180, column: 30, scope: !1416)
!1424 = !DILocation(line: 180, column: 67, scope: !1416)
!1425 = !DILocation(line: 180, column: 105, scope: !1416)
!1426 = !DILocation(line: 180, column: 142, scope: !1416)
!1427 = !DILocation(line: 180, column: 173, scope: !1416)
!1428 = !DILocation(line: 180, column: 213, scope: !1416)
!1429 = !DILocation(line: 180, column: 253, scope: !1416)
!1430 = !DILocation(line: 180, column: 290, scope: !1416)
!1431 = !DILocation(line: 180, column: 3, scope: !1416)
!1432 = !DILocalVariable(name: "facts", scope: !1416, file: !7, line: 180, type: !64)
!1433 = !DILocation(line: 181, column: 3, scope: !1416)
!1434 = !DILocation(line: 182, column: 15, scope: !1416)
!1435 = !DILocation(line: 183, column: 16, scope: !1416)
!1436 = distinct !DISubprogram(name: "support.namespace-metadata.apply", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eapply.2235", scope: !7, file: !7, line: 185, type: !150, scopeLine: 185, spFlags: DISPFlagDefinition, unit: !0)
!1437 = !DILocalVariable(name: "region", arg: 1, scope: !1436, file: !7, line: 185, type: !43)
!1438 = !DILocation(line: 185, column: 19, scope: !1436)
!1439 = !DILocalVariable(name: "operation", arg: 2, scope: !1436, file: !7, line: 185, type: !36)
!1440 = !DILocation(line: 185, column: 46, scope: !1436)
!1441 = !DILocalVariable(name: "seconds", arg: 3, scope: !1436, file: !7, line: 185, type: !36)
!1442 = !DILocation(line: 185, column: 63, scope: !1436)
!1443 = !DILocation(line: 186, column: 13, scope: !1436)
!1444 = !DILocalVariable(name: "extent", scope: !1436, file: !7, line: 186, type: !36)
!1445 = !DILocation(line: 186, column: 3, scope: !1436)
!1446 = !DILocation(line: 187, column: 21, scope: !1436)
!1447 = !DILocation(line: 187, column: 37, scope: !1436)
!1448 = !DILocation(line: 187, column: 53, scope: !1436)
!1449 = !DILocation(line: 187, column: 86, scope: !1436)
!1450 = !DILocation(line: 187, column: 15, scope: !1436)
!1451 = !DILocalVariable(name: "geometry", scope: !1436, file: !7, line: 187, type: !10)
!1452 = !DILocation(line: 187, column: 3, scope: !1436)
!1453 = !DILocation(line: 188, column: 3, scope: !1436)
!1454 = !DILocation(line: 189, column: 15, scope: !1436)
!1455 = !DILocation(line: 190, column: 16, scope: !1436)
!1456 = distinct !DISubprogram(name: "apply", linkageName: "topal.region-instance.namespace-metadata.topal.fn.apply.2236", scope: !1, file: !1, line: 4, type: !150, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !0)
!1457 = !DILocalVariable(name: "region", arg: 1, scope: !1456, file: !1, line: 4, type: !43)
!1458 = !DILocation(line: 4, column: 19, scope: !1456)
!1459 = !DILocalVariable(name: "operation", arg: 2, scope: !1456, file: !1, line: 4, type: !36)
!1460 = !DILocation(line: 4, column: 46, scope: !1456)
!1461 = !DILocalVariable(name: "seconds", arg: 3, scope: !1456, file: !1, line: 4, type: !36)
!1462 = !DILocation(line: 4, column: 63, scope: !1456)
!1463 = !DILocation(line: 5, column: 3, scope: !1456)
