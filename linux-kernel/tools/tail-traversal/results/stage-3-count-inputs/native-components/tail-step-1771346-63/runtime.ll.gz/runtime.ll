target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"
; TOPAL-SYSTEMS-TAIL-RUNTIME-001. Provider mechanisms, no subsystem policy.
%Root = type { i64, i64, i64, i64 }
@p.roots = private constant [4 x %Root] [%Root { i64 4, i64 0, i64 0, i64 0 }, %Root { i64 1, i64 0, i64 24, i64 64 }, %Root { i64 1, i64 24, i64 32, i64 65 }, %Root { i64 1, i64 56, i64 24, i64 64 }], align 8
@p.regions = private constant [4 x i8] [i8 0, i8 1, i8 1, i8 1], align 8
@p.calls = private constant [16 x i8] [i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 0, i8 1, i8 0, i8 0, i8 0, i8 0, i8 1, i8 0], align 8
@topal_x86_tail_boundary_active_v1 = external global ptr
declare void @topal_x86_tail_boundary_abort_v1() noreturn
declare i64 @topal_tail_readonly_bytes_v1(ptr)
declare i64 @topal_tail_step_component_v1(ptr)

define void @topal_tail_abort_v1() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_x86_tail_boundary_abort_v1()
  unreachable
}
define internal void @p.require(i1 %condition) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br i1 %condition, label %done, label %fail
fail:
  call void @topal_tail_abort_v1()
  unreachable
done:
  ret void
}
define internal i64 @p.word(ptr %base, i64 %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr i8, ptr %base, i64 %offset
  %value = load i64, ptr %pointer, align 8
  ret i64 %value
}
define internal void @p.put(ptr %base, i64 %offset, i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr i8, ptr %base, i64 %offset
  store i64 %value, ptr %pointer, align 8
  ret void
}
define internal i64 @p.add(i64 %a, i64 %b) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sum = add i64 %a, %b
  %valid = icmp uge i64 %sum, %a
  call void @p.require(i1 %valid)
  ret i64 %sum
}
define internal i1 @p.zero(ptr %base, i64 %bytes) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %read ]
  %end = icmp eq i64 %index, %bytes
  br i1 %end, label %yes, label %read
read:
  %pointer = getelementptr i8, ptr %base, i64 %index
  %byte = load volatile i8, ptr %pointer, align 1
  %is.zero = icmp eq i8 %byte, 0
  %next = add i64 %index, 1
  br i1 %is.zero, label %loop, label %no
yes:
  ret i1 true
no:
  ret i1 false
}
define internal void @p.erase(ptr %base, i64 %bytes) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %write ]
  %end = icmp eq i64 %index, %bytes
  br i1 %end, label %verify, label %write
write:
  %pointer = getelementptr i8, ptr %base, i64 %index
  store volatile i8 0, ptr %pointer, align 1
  %next = add i64 %index, 1
  br label %loop
verify:
  %zero = call i1 @p.zero(ptr %base, i64 %bytes)
  call void @p.require(i1 %zero)
  ret void
}
define internal void @p.copy(ptr %to, ptr %from, i64 %bytes) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %write ]
  %end = icmp eq i64 %index, %bytes
  br i1 %end, label %done, label %write
write:
  %source = getelementptr i8, ptr %from, i64 %index
  %destination = getelementptr i8, ptr %to, i64 %index
  %byte = load volatile i8, ptr %source, align 1
  store volatile i8 %byte, ptr %destination, align 1
  %next = add i64 %index, 1
  br label %loop
done:
  ret void
}
define internal ptr @p.context_role(ptr %provided, ptr %role) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %record = load ptr, ptr @topal_x86_tail_boundary_active_v1, align 8
  %active = icmp ne ptr %record, null
  call void @p.require(i1 %active)
  %expected = getelementptr i8, ptr %record, i64 64
  %same = icmp eq ptr %provided, %expected
  call void @p.require(i1 %same)
  %armed = call i64 @p.word(ptr %record, i64 8)
  %is.armed = icmp eq i64 %armed, 1
  call void @p.require(i1 %is.armed)
  %bound.context = call i64 @p.word(ptr %record, i64 24)
  %context.word = ptrtoint ptr %provided to i64
  %same.context = icmp eq i64 %bound.context, %context.word
  call void @p.require(i1 %same.context)
  %entry.word = ptrtoint ptr @topal_tail_step_component_v1 to i64
  %role.word = ptrtoint ptr %role to i64
  %bound.code = call i64 @p.word(ptr %record, i64 32)
  %same.bound.code = icmp eq i64 %bound.code, %role.word
  call void @p.require(i1 %same.bound.code)
  %history.word = call i64 @p.word(ptr %record, i64 40)
  %history.present = icmp ne i64 %history.word, 0
  call void @p.require(i1 %history.present)
  %actual.history = call i64 @p.word(ptr %provided, i64 328)
  %same.history = icmp eq i64 %actual.history, %history.word
  call void @p.require(i1 %same.history)
  %history = inttoptr i64 %history.word to ptr
  %history.active = call i64 @p.word(ptr %history, i64 24)
  %history.live = icmp eq i64 %history.active, 1
  call void @p.require(i1 %history.live)
  %poison = call i64 @p.word(ptr %history, i64 32)
  %not.poisoned = icmp eq i64 %poison, 0
  call void @p.require(i1 %not.poisoned)
  %generation = call i64 @p.word(ptr %history, i64 16)
  %has.generation = icmp ne i64 %generation, 0
  call void @p.require(i1 %has.generation)
  %control.code = call i64 @p.word(ptr %provided, i64 0)
  %code.valid = icmp eq i64 %control.code, %entry.word
  call void @p.require(i1 %code.valid)
  %owner = call i64 @p.word(ptr %provided, i64 8)
  %owner.valid = icmp eq i64 %owner, %history.word
  call void @p.require(i1 %owner.valid)
  %epoch = call i64 @p.word(ptr %provided, i64 16)
  %epoch.valid = icmp eq i64 %epoch, %generation
  call void @p.require(i1 %epoch.valid)
  %control.active = call i64 @p.word(ptr %provided, i64 24)
  %control.live = icmp eq i64 %control.active, 1
  call void @p.require(i1 %control.live)
  %windows = call i64 @p.word(ptr %provided, i64 56)
  %one.window = icmp eq i64 %windows, 1
  call void @p.require(i1 %one.window)
  %bank = call i64 @p.word(ptr %provided, i64 360)
  %bank.valid = icmp ule i64 %bank, 1
  call void @p.require(i1 %bank.valid)
  ret ptr %provided
}
define internal ptr @p.context(ptr %provided) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.context_role(ptr %provided, ptr @topal_tail_step_component_v1)
  ret ptr %context
}
define internal ptr @p.phase(ptr %provided, i64 %expected) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.context(ptr %provided)
  %phase = call i64 @p.word(ptr %context, i64 368)
  %valid = icmp eq i64 %phase, %expected
  call void @p.require(i1 %valid)
  ret ptr %context
}
define internal ptr @p.history(ptr %context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %word = call i64 @p.word(ptr %context, i64 328)
  %pointer = inttoptr i64 %word to ptr
  ret ptr %pointer
}
define internal ptr @p.current(ptr %context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %depth = call i64 @p.word(ptr %context, i64 352)
  %nonzero = icmp ugt i64 %depth, 0
  %bounded = icmp ule i64 %depth, 3
  %valid = and i1 %nonzero, %bounded
  call void @p.require(i1 %valid)
  %index = sub i64 %depth, 1
  %bytes = mul i64 %index, 88
  %offset = add i64 %bytes, 64
  %frame = getelementptr i8, ptr %context, i64 %offset
  ret ptr %frame
}
define internal i1 @p.has_region(i64 %function) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %nonzero = icmp ugt i64 %function, 0
  %bounded = icmp ult i64 %function, 4
  %valid = and i1 %nonzero, %bounded
  call void @p.require(i1 %valid)
  %pointer = getelementptr [4 x i8], ptr @p.regions, i64 0, i64 %function
  %flag = load i8, ptr %pointer, align 1
  %present = icmp eq i8 %flag, 1
  ret i1 %present
}
define internal ptr @p.root(i64 %parameter) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %valid = icmp ult i64 %parameter, 4
  call void @p.require(i1 %valid)
  %root = getelementptr [4 x %Root], ptr @p.roots, i64 0, i64 %parameter
  ret ptr %root
}
define internal ptr @p.bank(ptr %context, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %valid = icmp ule i64 %index, 1
  call void @p.require(i1 %valid)
  %relative = mul i64 %index, 80
  %offset = add i64 %relative, 432
  %bank = getelementptr i8, ptr %context, i64 %offset
  ret ptr %bank
}
define internal void @p.is_root(ptr %context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %depth = call i64 @p.word(ptr %context, i64 352)
  %valid = icmp eq i64 %depth, 1
  call void @p.require(i1 %valid)
  ret void
}
; Allocation and complete immutable numeric-root transfer.
define internal i1 @p.allocation_start(ptr %context, i64 %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %byte.index = udiv i64 %offset, 64
  %bit.word = udiv i64 %offset, 8
  %bit.index = urem i64 %bit.word, 8
  %offset.valid = icmp ult i64 %offset, 576
  call void @p.require(i1 %offset.valid)
  %starts = getelementptr i8, ptr %context, i64 1168
  %pointer = getelementptr i8, ptr %starts, i64 %byte.index
  %byte = load i8, ptr %pointer, align 1
  %shift = trunc i64 %bit.index to i8
  %mask = shl i8 1, %shift
  %bits = and i8 %byte, %mask
  %marked = icmp ne i8 %bits, 0
  ret i1 %marked
}
define ptr @topal_tail_allocate_v1(i64 %bytes) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %record = load ptr, ptr @topal_x86_tail_boundary_active_v1, align 8
  %active = icmp ne ptr %record, null
  call void @p.require(i1 %active)
  %provided = getelementptr i8, ptr %record, i64 64
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %positive = icmp ugt i64 %bytes, 0
  %bounded = icmp ule i64 %bytes, 576
  %valid = and i1 %positive, %bounded
  call void @p.require(i1 %valid)
  %rounded = add i64 %bytes, 7
  %aligned = and i64 %rounded, -8
  %used = call i64 @p.word(ptr %context, i64 384)
  %used.valid = icmp ule i64 %used, 576
  call void @p.require(i1 %used.valid)
  %remaining = sub i64 576, %used
  %fits = icmp ule i64 %aligned, %remaining
  call void @p.require(i1 %fits)
  %alignment = and i64 %used, 7
  %is.aligned = icmp eq i64 %alignment, 0
  call void @p.require(i1 %is.aligned)
  %byte.index = udiv i64 %used, 64
  %bit.word = udiv i64 %used, 8
  %bit.index = urem i64 %bit.word, 8
  %starts = getelementptr i8, ptr %context, i64 1168
  %mark = getelementptr i8, ptr %starts, i64 %byte.index
  %old = load i8, ptr %mark, align 1
  %shift = trunc i64 %bit.index to i8
  %mask = shl i8 1, %shift
  %new = or i8 %old, %mask
  store i8 %new, ptr %mark, align 1
  %next = add i64 %used, %aligned
  call void @p.put(ptr %context, i64 384, i64 %next)
  %work = getelementptr i8, ptr %context, i64 592
  %result = getelementptr i8, ptr %work, i64 %used
  call void @p.erase(ptr %result, i64 %aligned)
  ret ptr %result
}
define internal i64 @p.origin_bytes(ptr %context, ptr %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %address = ptrtoint ptr %source to i64
  %work = getelementptr i8, ptr %context, i64 592
  %work.address = ptrtoint ptr %work to i64
  %used = call i64 @p.word(ptr %context, i64 384)
  %used.valid = icmp ule i64 %used, 576
  call void @p.require(i1 %used.valid)
  %work.end = call i64 @p.add(i64 %work.address, i64 %used)
  %used.alignment = and i64 %used, 7
  %used.aligned = icmp eq i64 %used.alignment, 0
  call void @p.require(i1 %used.aligned)
  %after.start = icmp uge i64 %address, %work.address
  %before.end = icmp ult i64 %address, %work.end
  %in.work = and i1 %after.start, %before.end
  br i1 %in.work, label %work.root, label %banks
work.root:
  %offset = sub i64 %address, %work.address
  %misalignment = and i64 %offset, 7
  %aligned = icmp eq i64 %misalignment, 0
  call void @p.require(i1 %aligned)
  %issued = call i1 @p.allocation_start(ptr %context, i64 %offset)
  call void @p.require(i1 %issued)
  %first.end = add i64 %offset, 8
  br label %scan
scan:
  %end = phi i64 [ %first.end, %work.root ], [ %next.end, %advance ]
  %is.end = icmp eq i64 %end, %used
  br i1 %is.end, label %extent, label %test
test:
  %next.object = call i1 @p.allocation_start(ptr %context, i64 %end)
  br i1 %next.object, label %extent, label %advance
advance:
  %next.end = add i64 %end, 8
  br label %scan
extent:
  %length = sub i64 %end, %offset
  ret i64 %length
banks:
  %bank.index = call i64 @p.word(ptr %context, i64 360)
  %bank = call ptr @p.bank(ptr %context, i64 %bank.index)
  br label %root.loop
root.loop:
  %index = phi i64 [ 0, %banks ], [ %next.index, %root.next ]
  %roots.end = icmp eq i64 %index, 4
  br i1 %roots.end, label %readonly, label %root.test
root.test:
  %root = call ptr @p.root(i64 %index)
  %kind = call i64 @p.word(ptr %root, i64 0)
  %is.nat = icmp eq i64 %kind, 1
  %is.int = icmp eq i64 %kind, 2
  %numeric = or i1 %is.nat, %is.int
  %root.offset = call i64 @p.word(ptr %root, i64 8)
  %pointer = getelementptr i8, ptr %bank, i64 %root.offset
  %same = icmp eq ptr %pointer, %source
  %valid.root = and i1 %numeric, %same
  br i1 %valid.root, label %root.found, label %root.next
root.next:
  %next.index = add i64 %index, 1
  br label %root.loop
root.found:
  %root.bytes = call i64 @p.word(ptr %root, i64 16)
  ret i64 %root.bytes
readonly:
  %constant.bytes = call i64 @topal_tail_readonly_bytes_v1(ptr %source)
  %large.enough = icmp uge i64 %constant.bytes, 16
  %small.enough = icmp ule i64 %constant.bytes, 48
  %constant.valid = and i1 %large.enough, %small.enough
  call void @p.require(i1 %constant.valid)
  ret i64 %constant.bytes
}
define internal i64 @p.bits(ptr %number, i64 %extent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %address = ptrtoint ptr %number to i64
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %sufficient = icmp uge i64 %extent, 16
  %geometry = and i1 %aligned, %sufficient
  call void @p.require(i1 %geometry)
  %sign = call i64 @p.word(ptr %number, i64 0)
  %count = call i64 @p.word(ptr %number, i64 8)
  %sign.valid = icmp ule i64 %sign, 1
  %count.valid = icmp ule i64 %count, 8
  %header.valid = and i1 %sign.valid, %count.valid
  call void @p.require(i1 %header.valid)
  %limb.bytes = mul i64 %count, 4
  %total = add i64 %limb.bytes, 16
  %contained = icmp ule i64 %total, %extent
  call void @p.require(i1 %contained)
  %zero = icmp eq i64 %count, 0
  br i1 %zero, label %zero.value, label %nonzero
zero.value:
  %canonical.zero = icmp eq i64 %sign, 0
  call void @p.require(i1 %canonical.zero)
  ret i64 1
nonzero:
  %high.offset = add i64 %limb.bytes, 12
  %high.pointer = getelementptr i8, ptr %number, i64 %high.offset
  %high = load i32, ptr %high.pointer, align 4
  %canonical = icmp ne i32 %high, 0
  call void @p.require(i1 %canonical)
  %count.less.one = sub i64 %count, 1
  %low.bits = mul i64 %count.less.one, 32
  br label %bits
bits:
  %word = phi i32 [ %high, %nonzero ], [ %shifted, %next.bit ]
  %size = phi i64 [ %low.bits, %nonzero ], [ %incremented, %next.bit ]
  %finished = icmp eq i32 %word, 0
  br i1 %finished, label %done, label %next.bit
next.bit:
  %shifted = lshr i32 %word, 1
  %incremented = add i64 %size, 1
  br label %bits
done:
  ret i64 %size
}
define internal void @p.copy_number(ptr %context, ptr %destination, i64 %capacity, i64 %maximum.bits, i64 %kind, ptr %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %extent = call i64 @p.origin_bytes(ptr %context, ptr %source)
  %bits = call i64 @p.bits(ptr %source, i64 %extent)
  %sign = call i64 @p.word(ptr %source, i64 0)
  %length = call i64 @p.word(ptr %source, i64 8)
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %fits.bits = icmp ule i64 %bits, %maximum.bits
  %fits.bytes = icmp ule i64 %bytes, %capacity
  %fits = and i1 %fits.bits, %fits.bytes
  call void @p.require(i1 %fits)
  %nat = icmp eq i64 %kind, 1
  %positive = icmp eq i64 %sign, 0
  %not.nat = xor i1 %nat, true
  %classifier.valid = or i1 %not.nat, %positive
  call void @p.require(i1 %classifier.valid)
  %empty = call i1 @p.zero(ptr %destination, i64 %capacity)
  call void @p.require(i1 %empty)
  call void @p.copy(ptr %destination, ptr %source, i64 %bytes)
  ret void
}
; Scoped call/frame transport. No source view escapes or Window construction.
define internal void @p.frame_identity(ptr %context, ptr %frame) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %identity = call i64 @p.word(ptr %frame, i64 8)
  %history = call ptr @p.history(ptr %context)
  %next = call i64 @p.word(ptr %history, i64 0)
  %issued = icmp ult i64 %identity, %next
  %nonzero = icmp ugt i64 %identity, 0
  %valid = and i1 %issued, %nonzero
  call void @p.require(i1 %valid)
  ret void
}
define internal void @p.validate_current_view(ptr %context, ptr %view) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %frame = call ptr @p.current(ptr %context)
  call void @p.frame_identity(ptr %context, ptr %frame)
  %function = call i64 @p.word(ptr %frame, i64 0)
  %has.region = call i1 @p.has_region(i64 %function)
  call void @p.require(i1 %has.region)
  %expected = getelementptr i8, ptr %frame, i64 24
  %same = icmp eq ptr %view, %expected
  call void @p.require(i1 %same)
  %control = call i64 @p.word(ptr %view, i64 0)
  %control.word = ptrtoint ptr %context to i64
  %same.control = icmp eq i64 %control, %control.word
  call void @p.require(i1 %same.control)
  %offset = call i64 @p.word(ptr %view, i64 8)
  %whole = icmp eq i64 %offset, 0
  call void @p.require(i1 %whole)
  %count = call i64 @p.word(ptr %view, i64 16)
  %owner.count = call i64 @p.word(ptr %context, i64 40)
  %same.count = icmp eq i64 %count, %owner.count
  call void @p.require(i1 %same.count)
  %rights = call i64 @p.word(ptr %view, i64 24)
  %owner.rights = call i64 @p.word(ptr %context, i64 48)
  %rights.valid = icmp ule i64 %rights, 1
  %same.rights = icmp eq i64 %rights, %owner.rights
  %valid.rights = and i1 %rights.valid, %same.rights
  call void @p.require(i1 %valid.rights)
  %epoch = call i64 @p.word(ptr %view, i64 32)
  %generation = call i64 @p.word(ptr %context, i64 16)
  %same.epoch = icmp eq i64 %epoch, %generation
  call void @p.require(i1 %same.epoch)
  %owner = call i64 @p.word(ptr %view, i64 40)
  %control.owner = call i64 @p.word(ptr %context, i64 8)
  %same.owner = icmp eq i64 %owner, %control.owner
  call void @p.require(i1 %same.owner)
  %code = call i64 @p.word(ptr %view, i64 48)
  %control.code = call i64 @p.word(ptr %context, i64 0)
  %same.code = icmp eq i64 %code, %control.code
  call void @p.require(i1 %same.code)
  %zero = call i64 @p.word(ptr %view, i64 56)
  %reserved.zero = icmp eq i64 %zero, 0
  call void @p.require(i1 %reserved.zero)
  %history = call ptr @p.history(ptr %context)
  %loan = call i64 @p.word(ptr %frame, i64 16)
  %next.loan = call i64 @p.word(ptr %history, i64 8)
  %loan.nonzero = icmp ugt i64 %loan, 0
  %loan.issued = icmp ult i64 %loan, %next.loan
  %valid.loan = and i1 %loan.nonzero, %loan.issued
  call void @p.require(i1 %valid.loan)
  ret void
}
define void @topal_tail_validate_view_v1(ptr %provided, ptr %view) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  call void @p.validate_current_view(ptr %context, ptr %view)
  ret void
}
define ptr @topal_tail_input_view_v1(ptr %provided) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %frame = call ptr @p.current(ptr %context)
  %view = getelementptr i8, ptr %frame, i64 24
  call void @topal_tail_validate_view_v1(ptr %context, ptr %view)
  ret ptr %view
}
define ptr @topal_tail_helper_enter_v1(ptr %provided, i64 %function, ptr %view) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %parent = call ptr @p.current(ptr %context)
  call void @p.frame_identity(ptr %context, ptr %parent)
  %parent.function = call i64 @p.word(ptr %parent, i64 0)
  %parent.has.region = call i1 @p.has_region(i64 %parent.function)
  %has.region = call i1 @p.has_region(i64 %function)
  %row = mul i64 %parent.function, 4
  %index = add i64 %row, %function
  %edge.pointer = getelementptr [16 x i8], ptr @p.calls, i64 0, i64 %index
  %edge = load i8, ptr %edge.pointer, align 1
  %allowed = icmp eq i8 %edge, 1
  call void @p.require(i1 %allowed)
  %depth = call i64 @p.word(ptr %context, i64 352)
  %capacity = icmp ult i64 %depth, 3
  call void @p.require(i1 %capacity)
  %history = call ptr @p.history(ptr %context)
  %identity = call i64 @p.word(ptr %history, i64 0)
  %end = call i64 @p.word(ptr %context, i64 336)
  %step.end = call i64 @p.word(ptr %context, i64 408)
  %global.budget = icmp ult i64 %identity, %end
  %step.budget = icmp ult i64 %identity, %step.end
  %budget = and i1 %global.budget, %step.budget
  call void @p.require(i1 %budget)
  %next.identity = call i64 @p.add(i64 %identity, i64 1)
  br i1 %has.region, label %region, label %no.region
region:
  call void @topal_tail_validate_view_v1(ptr %context, ptr %view)
  %loan = call i64 @p.word(ptr %history, i64 8)
  %loan.end = call i64 @p.word(ptr %context, i64 344)
  %step.loan.end = call i64 @p.word(ptr %context, i64 416)
  %global.loan.budget = icmp ult i64 %loan, %loan.end
  %step.loan.budget = icmp ult i64 %loan, %step.loan.end
  %loan.budget = and i1 %global.loan.budget, %step.loan.budget
  call void @p.require(i1 %loan.budget)
  %next.loan = call i64 @p.add(i64 %loan, i64 1)
  br label %prepare
no.region:
  %no.view = icmp eq ptr %view, null
  call void @p.require(i1 %no.view)
  br label %prepare
prepare:
  %issued.loan = phi i64 [ %loan, %region ], [ 0, %no.region ]
  %loan.successor = phi i64 [ %next.loan, %region ], [ 0, %no.region ]
  %relative = mul i64 %depth, 88
  %offset = add i64 %relative, 64
  %frame = getelementptr i8, ptr %context, i64 %offset
  %empty = call i1 @p.zero(ptr %frame, i64 88)
  call void @p.require(i1 %empty)
  call void @p.put(ptr %frame, i64 0, i64 %function)
  call void @p.put(ptr %frame, i64 8, i64 %identity)
  call void @p.put(ptr %frame, i64 16, i64 %issued.loan)
  %new.view = getelementptr i8, ptr %frame, i64 24
  br i1 %has.region, label %copy.view, label %publish
copy.view:
  call void @p.copy(ptr %new.view, ptr %view, i64 64)
  call void @p.put(ptr %history, i64 8, i64 %loan.successor)
  br label %publish
publish:
  call void @p.put(ptr %history, i64 0, i64 %next.identity)
  %next.depth = add i64 %depth, 1
  call void @p.put(ptr %context, i64 352, i64 %next.depth)
  %result = select i1 %has.region, ptr %new.view, ptr null
  ret ptr %result
}
define void @topal_tail_helper_leave_v1(ptr %provided, i64 %function) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %depth = call i64 @p.word(ptr %context, i64 352)
  %nested = icmp ugt i64 %depth, 1
  call void @p.require(i1 %nested)
  %frame = call ptr @p.current(ptr %context)
  call void @p.frame_identity(ptr %context, ptr %frame)
  %actual = call i64 @p.word(ptr %frame, i64 0)
  %same = icmp eq i64 %actual, %function
  call void @p.require(i1 %same)
  call void @p.erase(ptr %frame, i64 88)
  %next = sub i64 %depth, 1
  call void @p.put(ptr %context, i64 352, i64 %next)
  ret void
}
; Source entry roots, successor staging and actual terminal-result transport.
define void @topal_tail_step_begin_v1(ptr %provided) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 0)
  call void @p.is_root(ptr %context)
  %frame = call ptr @p.current(ptr %context)
  call void @p.frame_identity(ptr %context, ptr %frame)
  %function = call i64 @p.word(ptr %frame, i64 0)
  %correct.entry = icmp eq i64 %function, 3
  call void @p.require(i1 %correct.entry)
  %result.kind = call i64 @p.word(ptr %context, i64 1232)
  %not.ended = icmp eq i64 %result.kind, 0
  call void @p.require(i1 %not.ended)
  %work = getelementptr i8, ptr %context, i64 592
  %work.zero = call i1 @p.zero(ptr %work, i64 576)
  call void @p.require(i1 %work.zero)
  %starts = getelementptr i8, ptr %context, i64 1168
  %starts.zero = call i1 @p.zero(ptr %starts, i64 9)
  call void @p.require(i1 %starts.zero)
  %bank.index = call i64 @p.word(ptr %context, i64 360)
  %other.index = xor i64 %bank.index, 1
  %other = call ptr @p.bank(ptr %context, i64 %other.index)
  %other.zero = call i1 @p.zero(ptr %other, i64 80)
  call void @p.require(i1 %other.zero)
  %steps = call i64 @p.word(ptr %context, i64 392)
  %limit = call i64 @p.word(ptr %context, i64 400)
  %remaining = icmp ult i64 %steps, %limit
  call void @p.require(i1 %remaining)
  %history = call ptr @p.history(ptr %context)
  %next.frame = call i64 @p.word(ptr %history, i64 0)
  %next.loan = call i64 @p.word(ptr %history, i64 8)
  %frames.valid = icmp uge i64 %next.frame, 2
  %loans.valid = icmp uge i64 %next.loan, 2
  %history.valid = and i1 %frames.valid, %loans.valid
  call void @p.require(i1 %history.valid)
  %frame.end = call i64 @p.add(i64 %next.frame, i64 3)
  %loan.end = call i64 @p.add(i64 %next.loan, i64 3)
  %admitted.frame.end = call i64 @p.word(ptr %context, i64 336)
  %admitted.loan.end = call i64 @p.word(ptr %context, i64 344)
  %frame.budget = icmp ule i64 %frame.end, %admitted.frame.end
  %loan.budget = icmp ule i64 %loan.end, %admitted.loan.end
  %within.budget = and i1 %frame.budget, %loan.budget
  call void @p.require(i1 %within.budget)
  call void @p.put(ptr %context, i64 408, i64 %frame.end)
  call void @p.put(ptr %context, i64 416, i64 %loan.end)
  %next.step = call i64 @p.add(i64 %steps, i64 1)
  call void @p.put(ptr %context, i64 392, i64 %next.step)
  call void @p.put(ptr %context, i64 376, i64 0)
  call void @p.put(ptr %context, i64 384, i64 0)
  call void @p.put(ptr %context, i64 368, i64 1)
  ret void
}
define ptr @topal_tail_input_number_v1(ptr %provided, i64 %parameter) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %root = call ptr @p.root(i64 %parameter)
  %kind = call i64 @p.word(ptr %root, i64 0)
  %nat = icmp eq i64 %kind, 1
  %integer = icmp eq i64 %kind, 2
  %numeric = or i1 %nat, %integer
  call void @p.require(i1 %numeric)
  %index = call i64 @p.word(ptr %context, i64 360)
  %bank = call ptr @p.bank(ptr %context, i64 %index)
  %offset = call i64 @p.word(ptr %root, i64 8)
  %number = getelementptr i8, ptr %bank, i64 %offset
  %extent = call i64 @p.word(ptr %root, i64 16)
  %maximum = call i64 @p.word(ptr %root, i64 24)
  %bits = call i64 @p.bits(ptr %number, i64 %extent)
  %bounded = icmp ule i64 %bits, %maximum
  call void @p.require(i1 %bounded)
  %sign = call i64 @p.word(ptr %number, i64 0)
  %nonnegative = icmp eq i64 %sign, 0
  %not.nat = xor i1 %nat, true
  %valid.nat = or i1 %not.nat, %nonnegative
  call void @p.require(i1 %valid.nat)
  ret ptr %number
}
define i64 @topal_tail_input_boolean_v1(ptr %provided, i64 %parameter) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %root = call ptr @p.root(i64 %parameter)
  %kind = call i64 @p.word(ptr %root, i64 0)
  %boolean = icmp eq i64 %kind, 3
  call void @p.require(i1 %boolean)
  %index = call i64 @p.word(ptr %context, i64 360)
  %bank = call ptr @p.bank(ptr %context, i64 %index)
  %offset = call i64 @p.word(ptr %root, i64 8)
  %value = call i64 @p.word(ptr %bank, i64 %offset)
  %valid = icmp ule i64 %value, 1
  call void @p.require(i1 %valid)
  ret i64 %value
}
define internal ptr @p.stage(ptr %provided, i64 %parameter, i64 %kind) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  call void @p.is_root(ptr %context)
  %root = call ptr @p.root(i64 %parameter)
  %actual = call i64 @p.word(ptr %root, i64 0)
  %same = icmp eq i64 %actual, %kind
  call void @p.require(i1 %same)
  %result = call i64 @p.word(ptr %context, i64 1232)
  %no.result = icmp eq i64 %result, 0
  call void @p.require(i1 %no.result)
  %mask = shl i64 1, %parameter
  %staged = call i64 @p.word(ptr %context, i64 376)
  %bits = and i64 %staged, %mask
  %new = icmp eq i64 %bits, 0
  call void @p.require(i1 %new)
  %updated = or i64 %staged, %mask
  call void @p.put(ptr %context, i64 376, i64 %updated)
  %index = call i64 @p.word(ptr %context, i64 360)
  %other = xor i64 %index, 1
  %bank = call ptr @p.bank(ptr %context, i64 %other)
  %offset = call i64 @p.word(ptr %root, i64 8)
  %destination = getelementptr i8, ptr %bank, i64 %offset
  ret ptr %destination
}
define void @topal_tail_stage_number_v1(ptr %provided, i64 %parameter, ptr %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %root = call ptr @p.root(i64 %parameter)
  %kind = call i64 @p.word(ptr %root, i64 0)
  %nat = icmp eq i64 %kind, 1
  %integer = icmp eq i64 %kind, 2
  %numeric = or i1 %nat, %integer
  call void @p.require(i1 %numeric)
  %destination = call ptr @p.stage(ptr %context, i64 %parameter, i64 %kind)
  %capacity = call i64 @p.word(ptr %root, i64 16)
  %bits = call i64 @p.word(ptr %root, i64 24)
  call void @p.copy_number(ptr %context, ptr %destination, i64 %capacity, i64 %bits, i64 %kind, ptr %source)
  ret void
}
define void @topal_tail_stage_boolean_v1(ptr %provided, i64 %parameter, i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %valid = icmp ule i64 %value, 1
  call void @p.require(i1 %valid)
  %destination = call ptr @p.stage(ptr %context, i64 %parameter, i64 3)
  %empty = call i1 @p.zero(ptr %destination, i64 8)
  call void @p.require(i1 %empty)
  call void @p.put(ptr %destination, i64 0, i64 %value)
  ret void
}
define internal ptr @p.result(ptr %provided, i64 %kind) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  call void @p.is_root(ptr %context)
  %expected = icmp eq i64 %kind, 3
  call void @p.require(i1 %expected)
  %staged = call i64 @p.word(ptr %context, i64 376)
  %no.staged = icmp eq i64 %staged, 0
  call void @p.require(i1 %no.staged)
  %old.kind = call i64 @p.word(ptr %context, i64 1232)
  %not.finished = icmp eq i64 %old.kind, 0
  call void @p.require(i1 %not.finished)
  %destination = getelementptr i8, ptr %context, i64 1184
  %empty = call i1 @p.zero(ptr %destination, i64 48)
  call void @p.require(i1 %empty)
  ret ptr %destination
}
define void @topal_tail_result_number_v1(ptr %provided, ptr %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %destination = call ptr @p.result(ptr %context, i64 2)
  call void @p.copy_number(ptr %context, ptr %destination, i64 48, i64 65, i64 2, ptr %source)
  call void @p.put(ptr %context, i64 1232, i64 2)
  ret void
}
define void @topal_tail_result_boolean_v1(ptr %provided, i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %valid = icmp ule i64 %value, 1
  call void @p.require(i1 %valid)
  %destination = call ptr @p.result(ptr %context, i64 3)
  call void @p.put(ptr %destination, i64 0, i64 %value)
  call void @p.put(ptr %context, i64 1232, i64 3)
  ret void
}
define void @topal_tail_result_unit_v1(ptr %provided) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.phase(ptr %provided, i64 1)
  %destination = call ptr @p.result(ptr %context, i64 4)
  call void @p.put(ptr %context, i64 1232, i64 4)
  ret void
}
; TOPAL-SYSTEMS-TAIL-CHECKPOINT-001. Runs after source return on the reused stack.
@p.decrements = private constant [1 x i64] [i64 1], align 8

define internal void @p.check_number(ptr %number, i64 %extent, i64 %maximum, i64 %kind) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bits = call i64 @p.bits(ptr %number, i64 %extent)
  %bounded = icmp ule i64 %bits, %maximum
  call void @p.require(i1 %bounded)
  %sign = call i64 @p.word(ptr %number, i64 0)
  %nat = icmp eq i64 %kind, 1
  %positive = icmp eq i64 %sign, 0
  %not.nat = xor i1 %nat, true
  %classifier = or i1 %not.nat, %positive
  call void @p.require(i1 %classifier)
  %length = call i64 @p.word(ptr %number, i64 8)
  %limbs = mul i64 %length, 4
  %bytes = add i64 %limbs, 16
  %padding.bytes = sub i64 %extent, %bytes
  %padding = getelementptr i8, ptr %number, i64 %bytes
  %clean = call i1 @p.zero(ptr %padding, i64 %padding.bytes)
  call void @p.require(i1 %clean)
  ret void
}
define internal void @p.check_bank(ptr %context, ptr %bank) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %end = icmp eq i64 %index, 4
  br i1 %end, label %done, label %root
root:
  %descriptor = call ptr @p.root(i64 %index)
  %kind = call i64 @p.word(ptr %descriptor, i64 0)
  %region = icmp eq i64 %kind, 4
  br i1 %region, label %advance, label %value
value:
  %offset = call i64 @p.word(ptr %descriptor, i64 8)
  %pointer = getelementptr i8, ptr %bank, i64 %offset
  %boolean = icmp eq i64 %kind, 3
  br i1 %boolean, label %bool, label %number
bool:
  %word = call i64 @p.word(ptr %pointer, i64 0)
  %valid.bool = icmp ule i64 %word, 1
  call void @p.require(i1 %valid.bool)
  br label %advance
number:
  %bytes = call i64 @p.word(ptr %descriptor, i64 16)
  %maximum = call i64 @p.word(ptr %descriptor, i64 24)
  call void @p.check_number(ptr %pointer, i64 %bytes, i64 %maximum, i64 %kind)
  br label %advance
advance:
  %next = add i64 %index, 1
  br label %loop
done:
  ret void
}
define internal i64 @p.measure(ptr %bank) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %descriptor = call ptr @p.root(i64 1)
  %offset = call i64 @p.word(ptr %descriptor, i64 8)
  %extent = call i64 @p.word(ptr %descriptor, i64 16)
  %number = getelementptr i8, ptr %bank, i64 %offset
  call void @p.check_number(ptr %number, i64 %extent, i64 64, i64 1)
  %length = call i64 @p.word(ptr %number, i64 8)
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %zero.value, label %low
zero.value:
  ret i64 0
low:
  %low.pointer = getelementptr i8, ptr %number, i64 16
  %low.limb = load i32, ptr %low.pointer, align 4
  %low.word = zext i32 %low.limb to i64
  %one = icmp eq i64 %length, 1
  br i1 %one, label %one.value, label %two
one.value:
  ret i64 %low.word
two:
  %high.pointer = getelementptr i8, ptr %number, i64 20
  %high.limb = load i32, ptr %high.pointer, align 4
  %high.word = zext i32 %high.limb to i64
  %shifted = shl i64 %high.word, 32
  %value = or i64 %shifted, %low.word
  ret i64 %value
}
define internal i1 @p.decrement(i64 %difference) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %end = icmp eq i64 %index, 1
  br i1 %end, label %no, label %test
test:
  %pointer = getelementptr [1 x i64], ptr @p.decrements, i64 0, i64 %index
  %value = load i64, ptr %pointer, align 8
  %same = icmp eq i64 %value, %difference
  br i1 %same, label %yes, label %advance
advance:
  %next = add i64 %index, 1
  br label %loop
yes:
  ret i1 true
no:
  ret i1 false
}
define i64 @topal_tail_checkpoint_body_v1(ptr %provided, i64 %outcome) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.context_role(ptr %provided, ptr @topal_tail_checkpoint_body_v1)
  %valid.outcome = icmp ule i64 %outcome, 1
  call void @p.require(i1 %valid.outcome)
  %phase = call i64 @p.word(ptr %context, i64 368)
  %returned = icmp eq i64 %phase, 1
  call void @p.require(i1 %returned)
  call void @p.is_root(ptr %context)
  %frame = call ptr @p.current(ptr %context)
  call void @p.frame_identity(ptr %context, ptr %frame)
  %function = call i64 @p.word(ptr %frame, i64 0)
  %entry.function = icmp eq i64 %function, 3
  call void @p.require(i1 %entry.function)
  %region = call i1 @p.has_region(i64 %function)
  br i1 %region, label %check.view, label %check.helpers
check.view:
  %view = getelementptr i8, ptr %frame, i64 24
  call void @p.validate_current_view(ptr %context, ptr %view)
  br label %check.helpers
check.helpers:
  %helpers = getelementptr i8, ptr %context, i64 152
  %helpers.zero = call i1 @p.zero(ptr %helpers, i64 176)
  call void @p.require(i1 %helpers.zero)
  %used = call i64 @p.word(ptr %context, i64 384)
  %used.bounded = icmp ule i64 %used, 576
  %used.alignment = and i64 %used, 7
  %used.aligned = icmp eq i64 %used.alignment, 0
  %used.valid = and i1 %used.bounded, %used.aligned
  call void @p.require(i1 %used.valid)
  %bank.index = call i64 @p.word(ptr %context, i64 360)
  %other.index = xor i64 %bank.index, 1
  %old.bank = call ptr @p.bank(ptr %context, i64 %bank.index)
  %new.bank = call ptr @p.bank(ptr %context, i64 %other.index)
  %staged = call i64 @p.word(ptr %context, i64 376)
  %result.kind = call i64 @p.word(ptr %context, i64 1232)
  %history = call ptr @p.history(ptr %context)
  %successor = icmp eq i64 %outcome, 1
  br i1 %successor, label %next.state, label %terminal
next.state:
  %complete = icmp eq i64 %staged, 14
  %no.result = icmp eq i64 %result.kind, 0
  %state.valid = and i1 %complete, %no.result
  call void @p.require(i1 %state.valid)
  call void @p.check_bank(ptr %context, ptr %new.bank)
  %old.measure = call i64 @p.measure(ptr %old.bank)
  %new.measure = call i64 @p.measure(ptr %new.bank)
  %above.base = icmp ugt i64 %old.measure, 0
  %decreases = icmp ult i64 %new.measure, %old.measure
  %natural.progress = and i1 %above.base, %decreases
  call void @p.require(i1 %natural.progress)
  %difference = sub i64 %old.measure, %new.measure
  %admitted.decrement = call i1 @p.decrement(i64 %difference)
  call void @p.require(i1 %admitted.decrement)
  %identity = call i64 @p.word(ptr %history, i64 0)
  %frame.end = call i64 @p.word(ptr %context, i64 336)
  %step.frame.end = call i64 @p.word(ptr %context, i64 408)
  %global.frame.budget = icmp ult i64 %identity, %frame.end
  %step.frame.budget = icmp ult i64 %identity, %step.frame.end
  %frame.budget = and i1 %global.frame.budget, %step.frame.budget
  call void @p.require(i1 %frame.budget)
  %next.identity = call i64 @p.add(i64 %identity, i64 1)
  br i1 %region, label %next.loan, label %no.loan
next.loan:
  %loan = call i64 @p.word(ptr %history, i64 8)
  %loan.end = call i64 @p.word(ptr %context, i64 344)
  %step.loan.end = call i64 @p.word(ptr %context, i64 416)
  %global.loan.budget = icmp ult i64 %loan, %loan.end
  %step.loan.budget = icmp ult i64 %loan, %step.loan.end
  %loan.budget = and i1 %global.loan.budget, %step.loan.budget
  call void @p.require(i1 %loan.budget)
  %next.loan.identity = call i64 @p.add(i64 %loan, i64 1)
  br label %retire
no.loan:
  br label %retire
terminal:
  %nothing.staged = icmp eq i64 %staged, 0
  %expected.result = icmp eq i64 %result.kind, 3
  %terminal.valid = and i1 %nothing.staged, %expected.result
  call void @p.require(i1 %terminal.valid)
  %empty.next = call i1 @p.zero(ptr %new.bank, i64 80)
  call void @p.require(i1 %empty.next)
  %result = getelementptr i8, ptr %context, i64 1184
  %numeric.result = icmp eq i64 %result.kind, 2
  br i1 %numeric.result, label %result.number, label %result.other
result.number:
  call void @p.check_number(ptr %result, i64 48, i64 65, i64 2)
  br label %retire
result.other:
  %boolean.result = icmp eq i64 %result.kind, 3
  br i1 %boolean.result, label %result.bool, label %result.unit
result.bool:
  %boolean = call i64 @p.word(ptr %result, i64 0)
  %boolean.valid = icmp ule i64 %boolean, 1
  call void @p.require(i1 %boolean.valid)
  %result.padding = getelementptr i8, ptr %result, i64 8
  %padding.zero = call i1 @p.zero(ptr %result.padding, i64 40)
  call void @p.require(i1 %padding.zero)
  br label %retire
result.unit:
  %unit.zero = call i1 @p.zero(ptr %result, i64 48)
  call void @p.require(i1 %unit.zero)
  br label %retire
retire:
  %fresh.frame = phi i64 [ %identity, %next.loan ], [ %identity, %no.loan ], [ 0, %result.number ], [ 0, %result.bool ], [ 0, %result.unit ]
  %fresh.next.frame = phi i64 [ %next.identity, %next.loan ], [ %next.identity, %no.loan ], [ 0, %result.number ], [ 0, %result.bool ], [ 0, %result.unit ]
  %fresh.loan = phi i64 [ %loan, %next.loan ], [ 0, %no.loan ], [ 0, %result.number ], [ 0, %result.bool ], [ 0, %result.unit ]
  %fresh.next.loan = phi i64 [ %next.loan.identity, %next.loan ], [ 0, %no.loan ], [ 0, %result.number ], [ 0, %result.bool ], [ 0, %result.unit ]
  %work = getelementptr i8, ptr %context, i64 592
  %starts = getelementptr i8, ptr %context, i64 1168
  call void @p.erase(ptr %work, i64 576)
  call void @p.erase(ptr %starts, i64 9)
  call void @p.erase(ptr %old.bank, i64 80)
  br i1 %successor, label %publish.frame, label %finish
publish.frame:
  call void @p.put(ptr %frame, i64 8, i64 %fresh.frame)
  call void @p.put(ptr %history, i64 0, i64 %fresh.next.frame)
  br i1 %region, label %publish.loan, label %finish
publish.loan:
  call void @p.put(ptr %frame, i64 16, i64 %fresh.loan)
  call void @p.put(ptr %history, i64 8, i64 %fresh.next.loan)
  br label %finish
finish:
  call void @p.put(ptr %context, i64 360, i64 %other.index)
  call void @p.put(ptr %context, i64 384, i64 0)
  call void @p.put(ptr %context, i64 376, i64 0)
  call void @p.put(ptr %context, i64 368, i64 0)
  ret i64 %outcome
}
; TOPAL-SYSTEMS-TAIL-COMPLETION-001. Exact result transfer before whole retirement.
define i64 @topal_tail_complete_body_v1(ptr %provided, ptr %output) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %context = call ptr @p.context_role(ptr %provided, ptr @topal_tail_complete_body_v1)
  %record = load ptr, ptr @topal_x86_tail_boundary_active_v1, align 8
  %bound.output = call i64 @p.word(ptr %record, i64 48)
  %output.word = ptrtoint ptr %output to i64
  %same.output = icmp eq i64 %bound.output, %output.word
  call void @p.require(i1 %same.output)
  %bound.bytes = call i64 @p.word(ptr %record, i64 56)
  %exact.bytes = icmp eq i64 %bound.bytes, 56
  call void @p.require(i1 %exact.bytes)
  %phase = call i64 @p.word(ptr %context, i64 368)
  %retired = icmp eq i64 %phase, 0
  call void @p.require(i1 %retired)
  call void @p.is_root(ptr %context)
  %frame = call ptr @p.current(ptr %context)
  call void @p.frame_identity(ptr %context, ptr %frame)
  %function = call i64 @p.word(ptr %frame, i64 0)
  %entry.function = icmp eq i64 %function, 3
  call void @p.require(i1 %entry.function)
  %region = call i1 @p.has_region(i64 %function)
  br i1 %region, label %view, label %domains
view:
  %root.view = getelementptr i8, ptr %frame, i64 24
  call void @p.validate_current_view(ptr %context, ptr %root.view)
  br label %domains
domains:
  %helpers = getelementptr i8, ptr %context, i64 152
  %helpers.zero = call i1 @p.zero(ptr %helpers, i64 176)
  call void @p.require(i1 %helpers.zero)
  %banks = getelementptr i8, ptr %context, i64 432
  %banks.zero = call i1 @p.zero(ptr %banks, i64 160)
  call void @p.require(i1 %banks.zero)
  %work = getelementptr i8, ptr %context, i64 592
  %work.zero = call i1 @p.zero(ptr %work, i64 576)
  call void @p.require(i1 %work.zero)
  %starts = getelementptr i8, ptr %context, i64 1168
  %starts.zero = call i1 @p.zero(ptr %starts, i64 9)
  call void @p.require(i1 %starts.zero)
  %used = call i64 @p.word(ptr %context, i64 384)
  %used.zero = icmp eq i64 %used, 0
  call void @p.require(i1 %used.zero)
  %staged = call i64 @p.word(ptr %context, i64 376)
  %staged.zero = icmp eq i64 %staged, 0
  call void @p.require(i1 %staged.zero)
  %steps = call i64 @p.word(ptr %context, i64 392)
  %limit = call i64 @p.word(ptr %context, i64 400)
  %entered = icmp ugt i64 %steps, 0
  %within.limit = icmp ule i64 %steps, %limit
  %valid.steps = and i1 %entered, %within.limit
  call void @p.require(i1 %valid.steps)
  %kind = call i64 @p.word(ptr %context, i64 1232)
  %expected = icmp eq i64 %kind, 3
  call void @p.require(i1 %expected)
  %result = getelementptr i8, ptr %context, i64 1184
  %numeric = icmp eq i64 %kind, 2
  br i1 %numeric, label %number, label %other
number:
  call void @p.check_number(ptr %result, i64 48, i64 65, i64 2)
  br label %copy
other:
  %boolean = icmp eq i64 %kind, 3
  br i1 %boolean, label %bool, label %unit
bool:
  %value = call i64 @p.word(ptr %result, i64 0)
  %valid.boolean = icmp ule i64 %value, 1
  call void @p.require(i1 %valid.boolean)
  %padding = getelementptr i8, ptr %result, i64 8
  %padding.zero = call i1 @p.zero(ptr %padding, i64 40)
  call void @p.require(i1 %padding.zero)
  br label %copy
unit:
  %unit.zero = call i1 @p.zero(ptr %result, i64 48)
  call void @p.require(i1 %unit.zero)
  br label %copy
copy:
  %output.zero = call i1 @p.zero(ptr %output, i64 56)
  call void @p.require(i1 %output.zero)
  call void @p.copy(ptr %output, ptr %result, i64 56)
  br label %readback
readback:
  %index = phi i64 [ 0, %copy ], [ %next, %read ]
  %end = icmp eq i64 %index, 56
  br i1 %end, label %done, label %read
read:
  %source = getelementptr i8, ptr %result, i64 %index
  %destination = getelementptr i8, ptr %output, i64 %index
  %expected.byte = load volatile i8, ptr %source, align 1
  %actual.byte = load volatile i8, ptr %destination, align 1
  %same.byte = icmp eq i8 %expected.byte, %actual.byte
  call void @p.require(i1 %same.byte)
  %next = add i64 %index, 1
  br label %readback
done:
  ret i64 0
}
