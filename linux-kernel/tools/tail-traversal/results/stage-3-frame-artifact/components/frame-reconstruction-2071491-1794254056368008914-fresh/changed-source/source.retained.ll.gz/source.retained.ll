; ModuleID = 'topal.frame-source.native'
source_filename = "frame-metadata.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

%topal.OptionalStorage = type { i64, ptr }
%topal.IntStorage = type { i64, i64, [0 x i32] }
%topal.IntDivmod = type { ptr, ptr }
%topal.KernelRegionControl = type { ptr, i64, i64, i64, ptr, i64, i64, i64 }
%topal.KernelRegionView = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }

@topal.tail.component.runtime.int.zero = private constant { i64, i64, [0 x i32] } zeroinitializer, align 8
@topal.tail.component.runtime.int.one = private constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.tail.component.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.tail.component.literal.int.0 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 -1] }, align 8
@topal.tail.component.literal.int.1 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 -1] }, align 8
@topal.tail.component.literal.int.2 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.3 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.4 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.tail.component.literal.int.5 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.6 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.7 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.8 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.9 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.tail.component.literal.int.10 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.tail.component.literal.int.11 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.12 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.13 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.14 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.15 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.16 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.17 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.18 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.19 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.20 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.tail.component.literal.int.21 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.22 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.tail.component.literal.int.23 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.24 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.25 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.26 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.27 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.28 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.29 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.30 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.31 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.32 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.tail.component.literal.int.33 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.34 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.35 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.36 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.tail.component.literal.int.37 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.38 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.39 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.40 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.tail.component.literal.int.41 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.42 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.43 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.tail.component.literal.int.44 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.45 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.46 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.47 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.48 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.tail.component.literal.int.49 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.50 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.51 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.52 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.53 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.54 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.55 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.56 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.57 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.58 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.59 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.60 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.61 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.62 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.tail.component.literal.int.63 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.64 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.65 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.66 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.67 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.68 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.69 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.70 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.71 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.72 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.73 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.74 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.tail.component.literal.int.75 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.76 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.77 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.78 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.79 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.80 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.81 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.tail.component.literal.int.82 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.83 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.84 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.85 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.86 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.87 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.88 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.89 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.90 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.91 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.92 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.93 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.tail.component.literal.int.94 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.95 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.96 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.97 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.98 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.99 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.100 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.101 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.102 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.103 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.104 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.105 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.106 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.tail.component.literal.int.107 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.tail.component.literal.int.108 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.tail.component.literal.int.109 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.110 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.111 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.112 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.tail.component.literal.int.113 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.114 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.115 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.116 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 -1] }, align 8
@topal.tail.component.literal.int.117 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.118 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.119 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 -1] }, align 8
@topal.tail.component.literal.int.120 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 -1, i32 -1] }, align 8
@topal.tail.component.literal.int.121 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.122 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] poison }, align 8
@topal.tail.component.literal.int.123 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #0

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.optional.some(ptr %payload) #1 {
entry:
  %optional = call ptr @topal.tail.component.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.optional.none() #1 {
entry:
  %optional = call ptr @topal.tail.component.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.tail.component.runtime.optional.is.some(ptr %optional) #1 {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid

checked:                                          ; preds = %entry
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some

invalid:                                          ; preds = %entry
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.optional.payload(ptr %optional) #1 {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative) #1 {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure

allocate:                                         ; preds = %entry
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.tail.component.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value

failure:                                          ; preds = %entry
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.from.u64(i64 %source) #1 {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero

zero:                                             ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.zero

nonzero:                                          ; preds = %entry
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done

store.high:                                       ; preds = %nonzero
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done

done:                                             ; preds = %store.high, %nonzero
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %value, i64 %index) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero

load:                                             ; preds = %entry
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended

zero:                                             ; preds = %entry
  ret i64 0
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.normalize(ptr %value) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim

trim:                                             ; preds = %leading.zero, %entry
  %candidate = phi i64 [ %length, %entry ], [ %next, %leading.zero ]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done

leading.zero:                                     ; preds = %trim
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim

zero:                                             ; preds = %leading.zero, %entry
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value

done:                                             ; preds = %trim
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 %negative) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate

zero:                                             ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.zero

allocate:                                         ; preds = %entry
  %copy = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %allocate
  %index = phi i64 [ 0, %allocate ], [ %next, %loop ]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  ret ptr %copy
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.negate(ptr %value) #1 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [
    i64 2, label %positive.infinity
    i64 3, label %negative.infinity
  ]

positive.infinity:                                ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.negative.infinity

negative.infinity:                                ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.positive.infinity

finite:                                           ; preds = %entry
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %copy

zero:                                             ; preds = %finite
  ret ptr @topal.tail.component.runtime.int.zero

copy:                                             ; preds = %finite
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %opposite = xor i64 %negative, 1
  %result = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 %opposite)
  ret ptr %result
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.absolute(ptr %value) #1 {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite

infinite:                                         ; preds = %entry
  ret ptr @topal.tail.component.runtime.int.positive.infinity

finite:                                           ; preds = %entry
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy

same:                                             ; preds = %finite
  ret ptr %value

copy:                                             ; preds = %finite
  %result = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer

check.longer:                                     ; preds = %entry
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty

check.empty:                                      ; preds = %check.longer
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs

limbs:                                            ; preds = %limbs.equal, %check.empty
  %position = phi i64 [ %left.length, %check.empty ], [ %index, %limbs.equal ]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater

check.limb.greater:                               ; preds = %limbs
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal

limbs.equal:                                      ; preds = %check.limb.greater
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal

less:                                             ; preds = %limbs, %entry
  ret i32 -1

equal:                                            ; preds = %limbs.equal, %check.empty
  ret i32 0

greater:                                          ; preds = %check.limb.greater, %check.longer
  ret i32 1
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i32 @topal.tail.component.runtime.int.compare(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity

left.positive:                                    ; preds = %entry
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result

check.left.negative.infinity:                     ; preds = %entry
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity

left.negative:                                    ; preds = %check.left.negative.infinity
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result

check.right.positive.infinity:                    ; preds = %check.left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity

check.right.negative.infinity:                    ; preds = %check.right.positive.infinity
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite

less:                                             ; preds = %check.right.positive.infinity
  ret i32 -1

greater:                                          ; preds = %check.right.negative.infinity
  ret i32 1

finite:                                           ; preds = %check.right.negative.infinity
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute

signed.result:                                    ; preds = %finite
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result

absolute:                                         ; preds = %finite
  %magnitude = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) #1 {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %left.limb = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish

finish:                                           ; preds = %loop, %entry
  %final.carry = phi i64 [ 0, %entry ], [ %next.carry, %loop ]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry

store.carry:                                      ; preds = %finish
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result

without.carry:                                    ; preds = %finish
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop

loop:                                             ; preds = %loop, %entry
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  %borrow = phi i64 [ 0, %entry ], [ %next.borrow, %loop ]
  %left = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done

done:                                             ; preds = %loop
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.add(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity

validate.left.infinity:                           ; preds = %entry
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity

indeterminate.infinity:                           ; preds = %validate.left.infinity
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable

return.left.infinity:                             ; preds = %validate.left.infinity
  ret ptr %left

check.right.infinity:                             ; preds = %entry
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite

return.right.infinity:                            ; preds = %check.right.infinity
  ret ptr %right

finite:                                           ; preds = %check.right.infinity
  %left.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right

return.right:                                     ; preds = %finite
  ret ptr %right

check.right:                                      ; preds = %finite
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero

return.left:                                      ; preds = %check.right
  ret ptr %left

nonzero:                                          ; preds = %check.right
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference

sum:                                              ; preds = %nonzero
  %sum.value = call ptr @topal.tail.component.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value

difference:                                       ; preds = %nonzero
  %ordering = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger

zero:                                             ; preds = %difference
  ret ptr @topal.tail.component.runtime.int.zero

select.larger:                                    ; preds = %difference
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference

left.difference:                                  ; preds = %select.larger
  %left.value = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value

right.difference:                                 ; preds = %select.larger
  %right.value = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.subtract(ptr %left, ptr %right) #1 {
entry:
  %opposite = call ptr @topal.tail.component.runtime.int.negate(ptr %right)
  %result = call ptr @topal.tail.component.runtime.int.add(ptr %left, ptr %opposite)
  ret ptr %result
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.multiply(ptr %left, ptr %right) #1 {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite

infinite:                                         ; preds = %entry
  %left.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity

indeterminate.infinity:                           ; preds = %infinite
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable

select.infinity:                                  ; preds = %infinite
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.tail.component.runtime.int.negative.infinity, ptr @topal.tail.component.runtime.int.positive.infinity
  ret ptr %infinity

finite:                                           ; preds = %entry
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length

zero:                                             ; preds = %finite
  ret ptr @topal.tail.component.runtime.int.zero

check.length:                                     ; preds = %finite
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate

failure:                                          ; preds = %check.length
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable

allocate:                                         ; preds = %check.length
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear

clear:                                            ; preds = %clear, %allocate
  %clear.index = phi i64 [ 0, %allocate ], [ %clear.next, %clear ]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry

outer.entry:                                      ; preds = %clear
  br label %outer

outer:                                            ; preds = %outer.done, %outer.entry
  %left.index = phi i64 [ 0, %outer.entry ], [ %left.next, %outer.done ]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner

inner:                                            ; preds = %inner, %outer
  %right.index = phi i64 [ 0, %outer ], [ %right.next, %inner ]
  %carry = phi i64 [ 0, %outer ], [ %next.carry, %inner ]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done

outer.done:                                       ; preds = %inner
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done

done:                                             ; preds = %outer.done
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.tail.component.runtime.int.is.zero(ptr %value) #1 {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.divmod.pair(ptr %quotient, ptr %remainder) #1 {
entry:
  %pair = call ptr @topal.tail.component.platform.allocate(i64 16)
  %quotient.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %remainder.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  store ptr %quotient, ptr %quotient.pointer, align 8
  store ptr %remainder, ptr %remainder.pointer, align 8
  ret ptr %pair
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.divmod.quotient(ptr %pair) #1 {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.divmod.remainder(ptr %pair) #1 {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i64 @topal.tail.component.runtime.int.bit.length(ptr %value) #1 {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check

zero:                                             ; preds = %entry
  ret i64 0

check:                                            ; preds = %entry
  %valid = icmp ule i64 %length, 576460752303423487
  br i1 %valid, label %calculate, label %failure

failure:                                          ; preds = %check
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable

calculate:                                        ; preds = %check
  %last = sub i64 %length, 1
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %last
  %limb = load i32, ptr %pointer, align 4
  %leading = call i32 @llvm.ctlz.i32(i32 %limb, i1 false)
  %top.bits.raw = sub i32 32, %leading
  %top.bits = zext i32 %top.bits.raw to i64
  %lower.bits = mul i64 %last, 32
  %bits = add i64 %lower.bits, %top.bits
  ret i64 %bits
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.tail.component.runtime.int.bit.at(ptr %value, i64 %index) #1 {
entry:
  %limb.index = lshr i64 %index, 5
  %offset.raw = and i64 %index, 31
  %offset = trunc i64 %offset.raw to i32
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %limb.index
  %limb = load i32, ptr %pointer, align 4
  %shifted = lshr i32 %limb, %offset
  %bit.raw = and i32 %shifted, 1
  %bit = icmp ne i32 %bit.raw, 0
  ret i1 %bit
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.divmod.absolute(ptr %dividend, ptr %divisor) #1 {
entry:
  %divisor.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %divisor)
  br i1 %divisor.zero, label %failure, label %check.dividend

failure:                                          ; preds = %entry
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable

check.dividend:                                   ; preds = %entry
  %dividend.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %dividend)
  br i1 %dividend.zero, label %zero, label %prepare

zero:                                             ; preds = %check.dividend
  %zero.pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr @topal.tail.component.runtime.int.zero, ptr @topal.tail.component.runtime.int.zero)
  ret ptr %zero.pair

prepare:                                          ; preds = %check.dividend
  %bits = call i64 @topal.tail.component.runtime.int.bit.length(ptr %dividend)
  br label %loop

loop:                                             ; preds = %merge, %prepare
  %position = phi i64 [ %bits, %prepare ], [ %next.position, %merge ]
  %quotient = phi ptr [ @topal.tail.component.runtime.int.zero, %prepare ], [ %next.quotient, %merge ]
  %remainder = phi ptr [ @topal.tail.component.runtime.int.zero, %prepare ], [ %next.remainder, %merge ]
  %bit.index = sub i64 %position, 1
  %bit = call i1 @topal.tail.component.runtime.int.bit.at(ptr %dividend, i64 %bit.index)
  %quotient.twice = call ptr @topal.tail.component.runtime.int.add(ptr %quotient, ptr %quotient)
  %remainder.twice = call ptr @topal.tail.component.runtime.int.add(ptr %remainder, ptr %remainder)
  br i1 %bit, label %append.bit, label %compare

append.bit:                                       ; preds = %loop
  %remainder.with.bit = call ptr @topal.tail.component.runtime.int.add(ptr %remainder.twice, ptr @topal.tail.component.runtime.int.one)
  br label %compare

compare:                                          ; preds = %append.bit, %loop
  %candidate = phi ptr [ %remainder.twice, %loop ], [ %remainder.with.bit, %append.bit ]
  %ordering = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %candidate, ptr %divisor)
  %subtract = icmp sge i32 %ordering, 0
  br i1 %subtract, label %subtract.divisor, label %retain

subtract.divisor:                                 ; preds = %compare
  %reduced = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %candidate, ptr %divisor, i64 0)
  %incremented = call ptr @topal.tail.component.runtime.int.add(ptr %quotient.twice, ptr @topal.tail.component.runtime.int.one)
  br label %merge

retain:                                           ; preds = %compare
  br label %merge

merge:                                            ; preds = %retain, %subtract.divisor
  %next.quotient = phi ptr [ %incremented, %subtract.divisor ], [ %quotient.twice, %retain ]
  %next.remainder = phi ptr [ %reduced, %subtract.divisor ], [ %candidate, %retain ]
  %next.position = sub i64 %position, 1
  %more = icmp ne i64 %next.position, 0
  br i1 %more, label %loop, label %done

done:                                             ; preds = %merge
  %pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr %next.quotient, ptr %next.remainder)
  ret ptr %pair
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.quotient.modulo(ptr %left, ptr %right) #1 {
entry:
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %divide

failure:                                          ; preds = %entry
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable

divide:                                           ; preds = %entry
  %left.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %right)
  %unsigned = call ptr @topal.tail.component.runtime.int.divmod.absolute(ptr %left.absolute, ptr %right.absolute)
  %quotient.absolute = call ptr @topal.tail.component.runtime.int.divmod.quotient(ptr %unsigned)
  %remainder.absolute = call ptr @topal.tail.component.runtime.int.divmod.remainder(ptr %unsigned)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.negative = icmp ne i64 %left.sign, 0
  %remainder.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %remainder.absolute)
  %remainder.present = xor i1 %remainder.zero, true
  %needs.adjustment = and i1 %left.negative, %remainder.present
  %quotient.sign = xor i64 %left.sign, %right.sign
  br i1 %needs.adjustment, label %adjust, label %direct

direct:                                           ; preds = %divide
  %direct.quotient = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %quotient.absolute, i64 %quotient.sign)
  %direct.pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr %direct.quotient, ptr %remainder.absolute)
  ret ptr %direct.pair

adjust:                                           ; preds = %divide
  %larger.quotient = call ptr @topal.tail.component.runtime.int.add(ptr %quotient.absolute, ptr @topal.tail.component.runtime.int.one)
  %adjusted.quotient = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %larger.quotient, i64 %quotient.sign)
  %adjusted.remainder = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %right.absolute, ptr %remainder.absolute, i64 0)
  %adjusted.pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr %adjusted.quotient, ptr %adjusted.remainder)
  ret ptr %adjusted.pair
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.runtime.int.modulo(ptr %left, ptr %right) #1 {
entry:
  %pair = call ptr @topal.tail.component.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %remainder = call ptr @topal.tail.component.runtime.int.divmod.remainder(ptr %pair)
  ret ptr %remainder
}

declare dso_local ptr @topal_tail_allocate_v1(i64)

; Function Attrs: noreturn
declare dso_local void @topal_tail_abort_v1() #2

declare dso_local void @topal_tail_step_begin_v1(ptr)

declare dso_local ptr @topal_tail_input_number_v1(ptr, i64)

declare dso_local ptr @topal_tail_input_view_v1(ptr)

declare dso_local ptr @topal_tail_helper_enter_v1(ptr, i64, ptr)

declare dso_local void @topal_tail_helper_leave_v1(ptr, i64)

declare dso_local void @topal_tail_validate_view_v1(ptr, ptr)

declare dso_local void @topal_tail_stage_number_v1(ptr, i64, ptr)

declare dso_local void @topal_tail_result_number_v1(ptr, ptr)

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.platform.allocate(i64 %length) #1 {
entry:
  %pointer = call ptr @topal_tail_allocate_v1(i64 %length)
  ret ptr %pointer
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.tail.component.platform.exit(i64 %status) #3 {
entry:
  call void @topal_tail_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone noreturn nounwind
define internal void @topal.tail.component.primitive.abort() #3 {
entry:
  call void @topal_tail_abort_v1()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.primitive.guard(ptr %view) #1 {
entry:
  %address = ptrtoint ptr %view to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %valid.pointer = and i1 %nonnull, %aligned
  br i1 %valid.pointer, label %view.fields, label %invalid

view.fields:                                      ; preds = %entry
  %control = load ptr, ptr %view, align 8
  %control.address = ptrtoint ptr %control to i64
  %control.nonnull = icmp ne i64 %control.address, 0
  %control.alignment = and i64 %control.address, 7
  %control.aligned = icmp eq i64 %control.alignment, 0
  %control.valid = and i1 %control.nonnull, %control.aligned
  br i1 %control.valid, label %control.fields, label %invalid

control.fields:                                   ; preds = %view.fields
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %view.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %view.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %view.epoch.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 4
  %view.owner.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 5
  %view.code.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 6
  %view.zero.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 7
  %offset = load i64, ptr %offset.pointer, align 8
  %view.count = load i64, ptr %view.count.pointer, align 8
  %view.rights = load i64, ptr %view.rights.pointer, align 8
  %view.epoch = load i64, ptr %view.epoch.pointer, align 8
  %view.owner = load i64, ptr %view.owner.pointer, align 8
  %view.code = load ptr, ptr %view.code.pointer, align 8
  %view.zero = load i64, ptr %view.zero.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_tail_step_component_v1
  %view.code.valid = icmp eq ptr %view.code, %code
  %owner.valid = icmp ne i64 %owner, 0
  %view.owner.valid = icmp eq i64 %view.owner, %owner
  %epoch.valid = icmp ne i64 %epoch, 0
  %view.epoch.valid = icmp eq i64 %view.epoch, %epoch
  %active.valid = icmp eq i64 %active, 1
  %count.valid = icmp ule i64 %count, -1
  %rights.valid = icmp ule i64 %rights, 1
  %view.rights.valid = icmp ule i64 %view.rights, %rights
  %zero.valid = icmp eq i64 %view.zero, 0
  %offset.valid = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %view.count.valid = icmp ule i64 %view.count, %remaining
  %base.address = ptrtoint ptr %base to i64
  %base.nonnull = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %issued.positive = icmp uge i64 %issued, 1
  %issued.bounded = icmp ule i64 %issued, 256
  %issued.valid = and i1 %issued.positive, %issued.bounded
  %a = and i1 %code.valid, %view.code.valid
  %b = and i1 %owner.valid, %view.owner.valid
  %c = and i1 %epoch.valid, %view.epoch.valid
  %d = and i1 %active.valid, %count.valid
  %e = and i1 %rights.valid, %view.rights.valid
  %f = and i1 %zero.valid, %offset.valid
  %g = and i1 %view.count.valid, %base.nonnull
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %ef = and i1 %e, %f
  %g.end = and i1 %g, %end.valid
  %abcd = and i1 %ab, %cd
  %efgh = and i1 %ef, %g.end
  %all.fields = and i1 %abcd, %efgh
  %valid = and i1 %all.fields, %issued.valid
  br i1 %valid, label %success, label %invalid

success:                                          ; preds = %control.fields
  %bytes = getelementptr i8, ptr %base, i64 %offset
  ret ptr %bytes

invalid:                                          ; preds = %control.fields, %view.fields, %entry
  call void @topal.tail.component.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal { i1, i64 } @topal.tail.component.primitive.index(ptr %number) #1 {
entry:
  %sign = load i64, ptr %number, align 8
  %nonnegative = icmp eq i64 %sign, 0
  br i1 %nonnegative, label %number.length, label %invalid

number.length:                                    ; preds = %entry
  %length.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %zero.result, label %bounded

zero.result:                                      ; preds = %number.length
  ret { i1, i64 } { i1 true, i64 0 }

bounded:                                          ; preds = %number.length
  %fits = icmp ule i64 %length, 2
  br i1 %fits, label %low, label %refuse

low:                                              ; preds = %bounded
  %low.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 0
  %low.word = load i32, ptr %low.pointer, align 4
  %low.value = zext i32 %low.word to i64
  %single = icmp eq i64 %length, 1
  br i1 %single, label %single.result, label %high

single.result:                                    ; preds = %low
  %one = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %low.value, 1
  ret { i1, i64 } %one

high:                                             ; preds = %low
  %high.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 1
  %high.word = load i32, ptr %high.pointer, align 4
  %high.value = zext i32 %high.word to i64
  %shifted = shl i64 %high.value, 32
  %value = or i64 %shifted, %low.value
  %two = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %value, 1
  ret { i1, i64 } %two

refuse:                                           ; preds = %bounded
  ret { i1, i64 } zeroinitializer

invalid:                                          ; preds = %entry
  call void @topal.tail.component.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.primitive.count(ptr %view) #1 {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %number = call ptr @topal.tail.component.runtime.int.from.u64(i64 %count)
  ret ptr %number
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal { i1, ptr } @topal.tail.component.primitive.unsigned.span(ptr %view, ptr %index, i64 %width) #1 {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %positive = icmp uge i64 %width, 1
  %bounded = icmp ule i64 %width, 8
  %format.valid = and i1 %positive, %bounded
  br i1 %format.valid, label %decode, label %invalid

decode:                                           ; preds = %entry
  %decoded = call { i1, i64 } @topal.tail.component.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %starts = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %ends = icmp ule i64 %width, %remaining
  %contained = and i1 %starts, %ends
  %valid = and i1 %fits, %contained
  br i1 %valid, label %success, label %refuse

success:                                          ; preds = %decode
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %result = insertvalue { i1, ptr } { i1 true, ptr null }, ptr %pointer, 1
  ret { i1, ptr } %result

refuse:                                           ; preds = %decode
  ret { i1, ptr } zeroinitializer

invalid:                                          ; preds = %entry
  call void @topal.tail.component.primitive.abort()
  unreachable
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal ptr @topal.tail.component.primitive.unsigned.load(ptr %view, ptr %index, i64 %width, i1 %big) #1 {
entry:
  %checked = call { i1, ptr } @topal.tail.component.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %valid, label %loop, label %refuse

loop:                                             ; preds = %loop, %entry
  %index.byte = phi i64 [ 0, %entry ], [ %next, %loop ]
  %value = phi i64 [ 0, %entry ], [ %merged, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  %byte = load i8, ptr %pointer, align 1
  %extended = zext i8 %byte to i64
  %part = shl i64 %extended, %shift
  %merged = or i64 %value, %part
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop

result:                                           ; preds = %loop
  %number = call ptr @topal.tail.component.runtime.int.from.u64(i64 %merged)
  %some = call ptr @topal.tail.component.runtime.optional.some(ptr %number)
  ret ptr %some

refuse:                                           ; preds = %entry
  %none = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal i1 @topal.tail.component.primitive.unsigned.store(ptr %view, ptr %index, ptr %number, i64 %width, i1 %big) #1 {
entry:
  %checked = call { i1, ptr } @topal.tail.component.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %span.valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %span.valid, label %value.check, label %refuse

value.check:                                      ; preds = %entry
  %decoded = call { i1, i64 } @topal.tail.component.primitive.index(ptr %number)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %value = extractvalue { i1, i64 } %decoded, 1
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %rights = load i64, ptr %rights.pointer, align 8
  %writable = icmp eq i64 %rights, 1
  %bits = mul i64 %width, 8
  %unused = sub i64 64, %bits
  %mask = lshr i64 -1, %unused
  %outside.mask = xor i64 %mask, -1
  %outside = and i64 %value, %outside.mask
  %value.valid = icmp eq i64 %outside, 0
  %range = and i1 %fits, %value.valid
  %valid = and i1 %range, %writable
  br i1 %valid, label %loop, label %refuse

loop:                                             ; preds = %loop, %value.check
  %index.byte = phi i64 [ 0, %value.check ], [ %next, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %part = lshr i64 %value, %shift
  %byte = trunc i64 %part to i8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  store i8 %byte, ptr %pointer, align 1
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop

result:                                           ; preds = %loop
  ret i1 true

refuse:                                           ; preds = %value.check, %entry
  ret i1 false
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !6 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 1, ptr %arg0), !dbg !19
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !20, !DIExpression(), !21)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !22, !DIExpression(), !23)
    #dbg_value(ptr @topal.tail.component.literal.int.0, !24, !DIExpression(), !25)
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %tail.helper.view), !dbg !26
  %v2 = call ptr @topal.tail.component.primitive.unsigned.load(ptr %tail.helper.view, ptr %arg1, i64 8, i1 false), !dbg !26
  %v3 = call i1 @topal.tail.component.runtime.optional.is.some(ptr %v2), !dbg !26
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !26

optional.decision.some.0:                         ; preds = %entry
  %v4 = call ptr @topal.tail.component.runtime.optional.payload(ptr %v2), !dbg !27
    #dbg_value(ptr %v4, !28, !DIExpression(), !27)
  br label %optional.decision.merge.2, !dbg !29

optional.decision.none.1:                         ; preds = %entry
  br label %optional.decision.merge.2, !dbg !30

optional.decision.merge.2:                        ; preds = %optional.decision.none.1, %optional.decision.some.0
  %v5 = phi ptr [ %v4, %optional.decision.some.0 ], [ @topal.tail.component.literal.int.0, %optional.decision.none.1 ], !dbg !26
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 1), !dbg !26
  ret ptr %v5, !dbg !26
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %arg0, i1 %arg1, ptr %tail.context) #1 !dbg !31 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 2, ptr null), !dbg !35
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !36, !DIExpression(), !37)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !38, !DIExpression(), !39)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !40

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !41

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !42

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v2 = phi i1 [ %arg1, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !40
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 2), !dbg !40
  ret i1 %v2, !dbg !40
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.tail.component.topal.fn.finish.4(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !43 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 3, ptr %arg0), !dbg !44
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !45, !DIExpression(), !46)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !47, !DIExpression(), !48)
    #dbg_value(ptr @topal.tail.component.literal.int.1, !49, !DIExpression(), !50)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.2), !dbg !51
  %v3 = icmp eq i32 %v2, 0, !dbg !51
  %v4 = icmp eq i1 %v3, true, !dbg !51
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.3, ptr %tail.context), !dbg !52
  %v6 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr @topal.tail.component.literal.int.4), !dbg !52
  %v7 = icmp eq i32 %v6, 0, !dbg !52
  %v8 = icmp eq i1 %v7, true, !dbg !52
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v4, i1 %v8, ptr %tail.context), !dbg !53
    #dbg_value(i1 %v9, !54, !DIExpression(), !55)
  br i1 %v9, label %decision.true.0, label %decision.false.1, !dbg !56

decision.true.0:                                  ; preds = %entry
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.5, ptr %tail.context), !dbg !57
  br label %decision.merge.2, !dbg !57

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !58

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v11 = phi ptr [ %v10, %decision.true.0 ], [ @topal.tail.component.literal.int.1, %decision.false.1 ], !dbg !56
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 3), !dbg !56
  ret ptr %v11, !dbg !56
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.tail.component.topal.fn.stop_2dlimit.11(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) #1 !dbg !59 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 4, ptr %arg0), !dbg !62
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !63, !DIExpression(), !64)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !65, !DIExpression(), !66)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !67, !DIExpression(), !68)
    #dbg_value(ptr @topal.tail.component.literal.int.6, !69, !DIExpression(), !70)
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg2, ptr @topal.tail.component.literal.int.7), !dbg !71
  %v4 = icmp eq i32 %v3, 0, !dbg !71
  %v5 = icmp eq i1 %v4, true, !dbg !71
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.8, ptr %tail.context), !dbg !72
  %v7 = call i32 @topal.tail.component.runtime.int.compare(ptr %v6, ptr @topal.tail.component.literal.int.9), !dbg !72
  %v8 = icmp eq i32 %v7, 0, !dbg !72
  %v9 = icmp eq i1 %v8, true, !dbg !72
  %v10 = xor i1 %v9, true, !dbg !73
  %v11 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v10, ptr %tail.context), !dbg !74
    #dbg_value(i1 %v11, !75, !DIExpression(), !76)
  br i1 %v11, label %decision.true.0, label %decision.false.1, !dbg !77

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !78

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !79

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v12 = phi ptr [ @topal.tail.component.literal.int.6, %decision.true.0 ], [ %arg1, %decision.false.1 ], !dbg !77
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 4), !dbg !77
  ret ptr %v12, !dbg !77
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.tail.component.topal.fn.cell.21(ptr %arg0, ptr %tail.context) #1 !dbg !80 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 5, ptr null), !dbg !83
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !84, !DIExpression(), !85)
  %v1 = call ptr @topal.tail.component.runtime.int.multiply(ptr %arg0, ptr @topal.tail.component.literal.int.11), !dbg !86
  %v2 = call ptr @topal.tail.component.runtime.int.add(ptr @topal.tail.component.literal.int.10, ptr %v1), !dbg !87
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 5), !dbg !87
  ret ptr %v2, !dbg !87
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) #1 !dbg !88 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 6, ptr %arg0), !dbg !91
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !92, !DIExpression(), !93)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !94, !DIExpression(), !95)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !96, !DIExpression(), !97)
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %tail.helper.view), !dbg !98
  %v3 = call i1 @topal.tail.component.primitive.unsigned.store(ptr %tail.helper.view, ptr %arg1, ptr %arg2, i64 8, i1 false), !dbg !98
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 6), !dbg !98
  ret i1 %v3, !dbg !98
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.select_2dspan.49(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !99 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 7, ptr %arg0), !dbg !102
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !103, !DIExpression(), !104)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !105, !DIExpression(), !106)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.12, ptr %arg1, ptr %tail.context), !dbg !107
    #dbg_value(i1 %v2, !108, !DIExpression(), !109)
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.13, ptr @topal.tail.component.literal.int.14, ptr %tail.context), !dbg !110
    #dbg_value(i1 %v3, !111, !DIExpression(), !112)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.16), !dbg !113
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.15, ptr %v4, ptr %tail.context), !dbg !114
    #dbg_value(i1 %v5, !115, !DIExpression(), !116)
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.17, ptr @topal.tail.component.literal.int.18, ptr %tail.context), !dbg !117
    #dbg_value(i1 %v6, !118, !DIExpression(), !119)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v3, ptr %tail.context), !dbg !120
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v6, ptr %tail.context), !dbg !121
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v8, ptr %tail.context), !dbg !122
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 7), !dbg !122
  ret i1 %v9, !dbg !122
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.maybe_2dselect.50(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) #1 !dbg !123 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 8, ptr %arg0), !dbg !124
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !125, !DIExpression(), !126)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !127, !DIExpression(), !128)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !129, !DIExpression(), !130)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.19, ptr %tail.context), !dbg !131
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg2, ptr %v3), !dbg !132
  %v5 = icmp sge i32 %v4, 0, !dbg !132
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !132

decision.true.0:                                  ; preds = %entry
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.select_2dspan.49(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !133
  br label %decision.merge.2, !dbg !133

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !134

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ true, %decision.false.1 ], !dbg !132
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 8), !dbg !132
  ret i1 %v7, !dbg !132
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.extend_2dspan.51(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3, ptr %arg4, ptr %arg5, ptr %tail.context) #1 !dbg !135 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 9, ptr %arg0), !dbg !138
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !139, !DIExpression(), !140)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !141, !DIExpression(), !142)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !143, !DIExpression(), !144)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !145, !DIExpression(), !146)
  %v4 = alloca ptr, align 8
  store ptr %arg4, ptr %v4, align 8
    #dbg_declare(ptr %v4, !147, !DIExpression(), !148)
  %v5 = alloca ptr, align 8
  store ptr %arg5, ptr %v5, align 8
    #dbg_declare(ptr %v5, !149, !DIExpression(), !150)
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.20, ptr %arg2, ptr %tail.context), !dbg !151
    #dbg_value(i1 %v6, !152, !DIExpression(), !153)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.21, ptr %arg3, ptr %tail.context), !dbg !154
    #dbg_value(i1 %v7, !155, !DIExpression(), !156)
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.22, ptr %arg4, ptr %tail.context), !dbg !157
    #dbg_value(i1 %v8, !158, !DIExpression(), !159)
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.23, ptr %arg5, ptr %tail.context), !dbg !160
    #dbg_value(i1 %v9, !161, !DIExpression(), !162)
  %v10 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.25), !dbg !163
  %v11 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.24, ptr %v10, ptr %tail.context), !dbg !164
    #dbg_value(i1 %v11, !165, !DIExpression(), !166)
  %v12 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v6, i1 %v7, ptr %tail.context), !dbg !167
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v9, i1 %v11, ptr %tail.context), !dbg !168
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v8, i1 %v13, ptr %tail.context), !dbg !169
  %v15 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v12, i1 %v14, ptr %tail.context), !dbg !170
    #dbg_value(i1 %v15, !171, !DIExpression(), !172)
  br i1 %v15, label %decision.true.0, label %decision.false.1, !dbg !173

decision.true.0:                                  ; preds = %entry
  %v16 = call fastcc i1 @topal.tail.component.topal.fn.maybe_2dselect.50(ptr %tail.helper.view, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !174
  br label %decision.merge.2, !dbg !174

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !175

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v17 = phi i1 [ %v16, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !173
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 9), !dbg !173
  ret i1 %v17, !dbg !173
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.aligned.53(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !176 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 10, ptr null), !dbg !179
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !180, !DIExpression(), !181)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !182, !DIExpression(), !183)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.26), !dbg !184
  %v3 = icmp eq i32 %v2, 0, !dbg !184
  %v4 = icmp eq i1 %v3, true, !dbg !184
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !184

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !185

decision.false.1:                                 ; preds = %entry
  %v5 = call ptr @topal.tail.component.runtime.int.modulo(ptr %arg0, ptr %arg1), !dbg !186
  %v6 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr @topal.tail.component.literal.int.27), !dbg !186
  %v7 = icmp eq i32 %v6, 0, !dbg !186
  %v8 = icmp eq i1 %v7, true, !dbg !186
  br label %decision.merge.2, !dbg !186

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v9 = phi i1 [ false, %decision.true.0 ], [ %v8, %decision.false.1 ], !dbg !184
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 10), !dbg !184
  ret i1 %v9, !dbg !184
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.skip.77(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !187 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 11, ptr %arg0), !dbg !188
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !189, !DIExpression(), !190)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !191, !DIExpression(), !192)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.28, ptr @topal.tail.component.literal.int.29, ptr %tail.context), !dbg !193
    #dbg_value(i1 %v2, !194, !DIExpression(), !195)
  %v3 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.31), !dbg !196
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.30, ptr %v3, ptr %tail.context), !dbg !197
    #dbg_value(i1 %v4, !198, !DIExpression(), !199)
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v4, ptr %tail.context), !dbg !200
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 11), !dbg !200
  ret i1 %v5, !dbg !200
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.start_2dspan.78(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3, ptr %tail.context) #1 !dbg !201 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 12, ptr %arg0), !dbg !204
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !205, !DIExpression(), !206)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !207, !DIExpression(), !208)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !209, !DIExpression(), !210)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !211, !DIExpression(), !212)
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.32, ptr %tail.context), !dbg !213
  %v5 = call ptr @topal.tail.component.runtime.int.add(ptr %v4, ptr @topal.tail.component.literal.int.33), !dbg !213
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.aligned.53(ptr %arg3, ptr %v5, ptr %tail.context), !dbg !214
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !214

decision.true.0:                                  ; preds = %entry
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.extend_2dspan.51(ptr %tail.helper.view, ptr %arg1, ptr %arg1, ptr @topal.tail.component.literal.int.34, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !215
  br label %decision.merge.2, !dbg !215

decision.false.1:                                 ; preds = %entry
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.skip.77(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !216
  br label %decision.merge.2, !dbg !216

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v9 = phi i1 [ %v7, %decision.true.0 ], [ %v8, %decision.false.1 ], !dbg !214
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 12), !dbg !214
  ret i1 %v9, !dbg !214
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.free_2dcell.79(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3, ptr %tail.context) #1 !dbg !217 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 13, ptr %arg0), !dbg !218
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !219, !DIExpression(), !220)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !221, !DIExpression(), !222)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !223, !DIExpression(), !224)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !225, !DIExpression(), !226)
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.35, ptr %tail.context), !dbg !227
    #dbg_value(ptr %v4, !228, !DIExpression(), !229)
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.36, ptr %tail.context), !dbg !230
  %v6 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg2, ptr %v5), !dbg !231
  %v7 = icmp eq i32 %v6, 0, !dbg !231
  %v8 = icmp eq i1 %v7, true, !dbg !231
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.37, ptr %tail.context), !dbg !232
  %v10 = call ptr @topal.tail.component.runtime.int.add(ptr %v9, ptr @topal.tail.component.literal.int.38), !dbg !232
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg3, ptr %v10), !dbg !233
  %v12 = icmp eq i32 %v11, 0, !dbg !233
  %v13 = icmp eq i1 %v12, true, !dbg !233
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v8, i1 %v13, ptr %tail.context), !dbg !234
    #dbg_value(i1 %v14, !235, !DIExpression(), !236)
  %v15 = call i32 @topal.tail.component.runtime.int.compare(ptr %v4, ptr @topal.tail.component.literal.int.39), !dbg !237
  %v16 = icmp sgt i32 %v15, 0, !dbg !237
  %v17 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v16, i1 %v14, ptr %tail.context), !dbg !238
  br i1 %v17, label %decision.true.0, label %decision.false.1, !dbg !238

decision.true.0:                                  ; preds = %entry
  %v18 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.40, ptr %tail.context), !dbg !239
  %v19 = call ptr @topal.tail.component.runtime.int.add(ptr %v4, ptr @topal.tail.component.literal.int.41), !dbg !240
  %v20 = call fastcc i1 @topal.tail.component.topal.fn.extend_2dspan.51(ptr %tail.helper.view, ptr %arg1, ptr %v18, ptr %v19, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !241
  br label %decision.merge.2, !dbg !241

decision.false.1:                                 ; preds = %entry
  %v21 = call fastcc i1 @topal.tail.component.topal.fn.start_2dspan.78(ptr %tail.helper.view, ptr %arg1, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !242
  br label %decision.merge.2, !dbg !242

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v22 = phi i1 [ %v20, %decision.true.0 ], [ %v21, %decision.false.1 ], !dbg !238
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 13), !dbg !238
  ret i1 %v22, !dbg !238
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.search_2dcell.84(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !243 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 14, ptr %arg0), !dbg !244
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !245, !DIExpression(), !246)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !247, !DIExpression(), !248)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.21(ptr %arg1, ptr %tail.context), !dbg !249
    #dbg_value(ptr %v2, !250, !DIExpression(), !251)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !252
    #dbg_value(ptr %v3, !253, !DIExpression(), !254)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.42), !dbg !255
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v4, ptr %tail.context), !dbg !256
    #dbg_value(ptr %v5, !257, !DIExpression(), !258)
  %v6 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.43), !dbg !259
  %v7 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v6, ptr %tail.context), !dbg !260
    #dbg_value(ptr %v7, !261, !DIExpression(), !262)
  %v8 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr @topal.tail.component.literal.int.44), !dbg !263
  %v9 = icmp eq i32 %v8, 0, !dbg !263
  %v10 = icmp eq i1 %v9, true, !dbg !263
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr @topal.tail.component.literal.int.45), !dbg !264
  %v12 = icmp sgt i32 %v11, 0, !dbg !264
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v10, i1 %v12, ptr %tail.context), !dbg !265
  br i1 %v13, label %decision.true.0, label %decision.false.1, !dbg !265

decision.true.0:                                  ; preds = %entry
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.free_2dcell.79(ptr %tail.helper.view, ptr %arg1, ptr %v5, ptr %v7, ptr %tail.context), !dbg !266
  br label %decision.merge.2, !dbg !266

decision.false.1:                                 ; preds = %entry
  %v15 = call fastcc i1 @topal.tail.component.topal.fn.skip.77(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !267
  br label %decision.merge.2, !dbg !267

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v16 = phi i1 [ %v14, %decision.true.0 ], [ %v15, %decision.false.1 ], !dbg !265
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 14), !dbg !265
  ret i1 %v16, !dbg !265
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.complete.88(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !268 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 15, ptr %arg0), !dbg !269
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !270, !DIExpression(), !271)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !272, !DIExpression(), !273)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.46, ptr %arg1, ptr %tail.context), !dbg !274
    #dbg_value(i1 %v2, !275, !DIExpression(), !276)
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.47, ptr @topal.tail.component.literal.int.48, ptr %tail.context), !dbg !277
    #dbg_value(i1 %v3, !278, !DIExpression(), !279)
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v3, ptr %tail.context), !dbg !280
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 15), !dbg !280
  ret i1 %v4, !dbg !280
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.search.89(ptr %arg0, ptr %tail.context) #1 !dbg !281 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 16, ptr %arg0), !dbg !284
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !285, !DIExpression(), !286)
  %v1 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.49, ptr %tail.context), !dbg !287
    #dbg_value(ptr %v1, !288, !DIExpression(), !289)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.50, ptr %tail.context), !dbg !290
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr %v2), !dbg !291
  %v4 = icmp slt i32 %v3, 0, !dbg !291
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !291

decision.true.0:                                  ; preds = %entry
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.search_2dcell.84(ptr %tail.helper.view, ptr %v1, ptr %tail.context), !dbg !292
  br label %decision.merge.2, !dbg !292

decision.false.1:                                 ; preds = %entry
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.complete.88(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.51, ptr %tail.context), !dbg !293
  br label %decision.merge.2, !dbg !293

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v5, %decision.true.0 ], [ %v6, %decision.false.1 ], !dbg !291
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 16), !dbg !291
  ret i1 %v7, !dbg !291
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.maybe_2dcomplete.113(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !294 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 17, ptr %arg0), !dbg !295
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !296, !DIExpression(), !297)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !298, !DIExpression(), !299)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.52, ptr %tail.context), !dbg !300
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr %v2), !dbg !301
  %v4 = icmp eq i32 %v3, 0, !dbg !301
  %v5 = icmp eq i1 %v4, true, !dbg !301
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !301

decision.true.0:                                  ; preds = %entry
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.53, ptr %tail.context), !dbg !302
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.complete.88(ptr %tail.helper.view, ptr %v6, ptr %tail.context), !dbg !303
  br label %decision.merge.2, !dbg !303

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !304

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v8 = phi i1 [ %v7, %decision.true.0 ], [ true, %decision.false.1 ], !dbg !301
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 17), !dbg !301
  ret i1 %v8, !dbg !301
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.advance_2dcommit.114(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) #1 !dbg !305 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 18, ptr %arg0), !dbg !306
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !307, !DIExpression(), !308)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !309, !DIExpression(), !310)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !311, !DIExpression(), !312)
  %v3 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.55), !dbg !313
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.54, ptr %v3, ptr %tail.context), !dbg !314
    #dbg_value(i1 %v4, !315, !DIExpression(), !316)
  %v5 = call ptr @topal.tail.component.runtime.int.add(ptr %arg2, ptr @topal.tail.component.literal.int.57), !dbg !317
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.56, ptr %v5, ptr %tail.context), !dbg !318
    #dbg_value(i1 %v6, !319, !DIExpression(), !320)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v4, i1 %v6, ptr %tail.context), !dbg !321
  br i1 %v7, label %decision.true.0, label %decision.false.1, !dbg !321

decision.true.0:                                  ; preds = %entry
  %v8 = call ptr @topal.tail.component.runtime.int.add(ptr %arg2, ptr @topal.tail.component.literal.int.58), !dbg !322
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.maybe_2dcomplete.113(ptr %tail.helper.view, ptr %v8, ptr %tail.context), !dbg !323
  br label %decision.merge.2, !dbg !323

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !324

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v10 = phi i1 [ %v9, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !321
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 18), !dbg !321
  ret i1 %v10, !dbg !321
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.commit_2dcell.115(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) #1 !dbg !325 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 19, ptr %arg0), !dbg !326
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !327, !DIExpression(), !328)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !329, !DIExpression(), !330)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !331, !DIExpression(), !332)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.cell.21(ptr %arg1, ptr %tail.context), !dbg !333
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr %v3, ptr %arg2, ptr %tail.context), !dbg !334
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !334

decision.true.0:                                  ; preds = %entry
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.59, ptr %tail.context), !dbg !335
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.advance_2dcommit.114(ptr %tail.helper.view, ptr %arg1, ptr %v5, ptr %tail.context), !dbg !336
  br label %decision.merge.2, !dbg !336

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !337

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !334
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 19), !dbg !334
  ret i1 %v7, !dbg !334
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.allocate_2dcell.116(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !338 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 20, ptr %arg0), !dbg !339
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !340, !DIExpression(), !341)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !342, !DIExpression(), !343)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.21(ptr %arg1, ptr %tail.context), !dbg !344
    #dbg_value(ptr %v2, !345, !DIExpression(), !346)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !347
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr @topal.tail.component.literal.int.60), !dbg !347
  %v5 = icmp eq i32 %v4, 0, !dbg !347
  %v6 = icmp eq i1 %v5, true, !dbg !347
    #dbg_value(i1 %v6, !348, !DIExpression(), !349)
  %v7 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.61), !dbg !350
  %v8 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v7, ptr %tail.context), !dbg !351
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.62, ptr %tail.context), !dbg !352
  %v10 = call i32 @topal.tail.component.runtime.int.compare(ptr %v8, ptr %v9), !dbg !351
  %v11 = icmp eq i32 %v10, 0, !dbg !351
  %v12 = icmp eq i1 %v11, true, !dbg !351
    #dbg_value(i1 %v12, !353, !DIExpression(), !354)
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v6, i1 %v12, ptr %tail.context), !dbg !355
  br i1 %v13, label %decision.true.0, label %decision.false.1, !dbg !355

decision.true.0:                                  ; preds = %entry
  %v14 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.63, ptr %tail.context), !dbg !356
  %v15 = call fastcc i1 @topal.tail.component.topal.fn.commit_2dcell.115(ptr %tail.helper.view, ptr %arg1, ptr %v14, ptr %tail.context), !dbg !357
  br label %decision.merge.2, !dbg !357

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !358

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v16 = phi i1 [ %v15, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !355
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 20), !dbg !355
  ret i1 %v16, !dbg !355
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.release_2dcell.140(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !359 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 21, ptr %arg0), !dbg !360
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !361, !DIExpression(), !362)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !363, !DIExpression(), !364)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.21(ptr %arg1, ptr %tail.context), !dbg !365
    #dbg_value(ptr %v2, !366, !DIExpression(), !367)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !368
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.64, ptr %tail.context), !dbg !369
  %v5 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr %v4), !dbg !368
  %v6 = icmp eq i32 %v5, 0, !dbg !368
  %v7 = icmp eq i1 %v6, true, !dbg !368
    #dbg_value(i1 %v7, !370, !DIExpression(), !371)
  %v8 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.65), !dbg !372
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v8, ptr %tail.context), !dbg !373
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.66, ptr %tail.context), !dbg !374
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v9, ptr %v10), !dbg !373
  %v12 = icmp eq i32 %v11, 0, !dbg !373
  %v13 = icmp eq i1 %v12, true, !dbg !373
  %v14 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.67, ptr %tail.context), !dbg !375
  %v15 = call i32 @topal.tail.component.runtime.int.compare(ptr %v14, ptr @topal.tail.component.literal.int.68), !dbg !375
  %v16 = icmp sgt i32 %v15, 0, !dbg !375
  %v17 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v13, i1 %v16, ptr %tail.context), !dbg !376
    #dbg_value(i1 %v17, !377, !DIExpression(), !378)
  %v18 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v17, ptr %tail.context), !dbg !379
  br i1 %v18, label %decision.true.0, label %decision.false.1, !dbg !379

decision.true.0:                                  ; preds = %entry
  %v19 = call fastcc i1 @topal.tail.component.topal.fn.commit_2dcell.115(ptr %tail.helper.view, ptr %arg1, ptr @topal.tail.component.literal.int.69, ptr %tail.context), !dbg !380
  br label %decision.merge.2, !dbg !380

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !381

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v20 = phi i1 [ %v19, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !379
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 21), !dbg !379
  ret i1 %v20, !dbg !379
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.commit_2dselected.141(ptr %arg0, ptr %arg1, i1 %arg2, ptr %tail.context) #1 !dbg !382 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 22, ptr %arg0), !dbg !385
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !386, !DIExpression(), !387)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !388, !DIExpression(), !389)
  %v2 = alloca i1, align 1
  store i1 %arg2, ptr %v2, align 1
    #dbg_declare(ptr %v2, !390, !DIExpression(), !391)
  br i1 %arg2, label %decision.true.0, label %decision.false.1, !dbg !392

decision.true.0:                                  ; preds = %entry
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.allocate_2dcell.116(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !393
  br label %decision.merge.2, !dbg !393

decision.false.1:                                 ; preds = %entry
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.release_2dcell.140(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !394
  br label %decision.merge.2, !dbg !394

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v5 = phi i1 [ %v3, %decision.true.0 ], [ %v4, %decision.false.1 ], !dbg !392
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 22), !dbg !392
  ret i1 %v5, !dbg !392
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.commit.142(ptr %arg0, i1 %arg1, ptr %tail.context) #1 !dbg !395 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 23, ptr %arg0), !dbg !398
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !399, !DIExpression(), !400)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !401, !DIExpression(), !402)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.70, ptr %tail.context), !dbg !403
    #dbg_value(ptr %v2, !404, !DIExpression(), !405)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.71, ptr %tail.context), !dbg !406
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %v2, ptr %v3), !dbg !407
  %v5 = icmp slt i32 %v4, 0, !dbg !407
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.72, ptr %tail.context), !dbg !408
  %v7 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.73, ptr %tail.context), !dbg !409
  %v8 = call i32 @topal.tail.component.runtime.int.compare(ptr %v6, ptr %v7), !dbg !408
  %v9 = icmp slt i32 %v8, 0, !dbg !408
  %v10 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v9, ptr %tail.context), !dbg !410
    #dbg_value(i1 %v10, !411, !DIExpression(), !412)
  br i1 %v10, label %decision.true.0, label %decision.false.1, !dbg !413

decision.true.0:                                  ; preds = %entry
  %v11 = call fastcc i1 @topal.tail.component.topal.fn.commit_2dselected.141(ptr %tail.helper.view, ptr %v2, i1 %arg1, ptr %tail.context), !dbg !414
  br label %decision.merge.2, !dbg !414

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !415

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v12 = phi i1 [ %v11, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !413
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 23), !dbg !413
  ret i1 %v12, !dbg !413
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.begin_2drelease.176(ptr %arg0, ptr %tail.context) #1 !dbg !416 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 24, ptr %arg0), !dbg !417
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !418, !DIExpression(), !419)
  %v1 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.74, ptr %tail.context), !dbg !420
    #dbg_value(ptr %v1, !421, !DIExpression(), !422)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.75, ptr %v1, ptr %tail.context), !dbg !423
    #dbg_value(i1 %v2, !424, !DIExpression(), !425)
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.76, ptr @topal.tail.component.literal.int.77, ptr %tail.context), !dbg !426
    #dbg_value(i1 %v3, !427, !DIExpression(), !428)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %v1, ptr @topal.tail.component.literal.int.79), !dbg !429
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.78, ptr %v4, ptr %tail.context), !dbg !430
    #dbg_value(i1 %v5, !431, !DIExpression(), !432)
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.80, ptr @topal.tail.component.literal.int.81, ptr %tail.context), !dbg !433
    #dbg_value(i1 %v6, !434, !DIExpression(), !435)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v3, ptr %tail.context), !dbg !436
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v6, ptr %tail.context), !dbg !437
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v8, ptr %tail.context), !dbg !438
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 24), !dbg !438
  ret i1 %v9, !dbg !438
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.maybe_2dbegin_2drelease.177(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !439 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 25, ptr %arg0), !dbg !440
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !441, !DIExpression(), !442)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !443, !DIExpression(), !444)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.82, ptr %tail.context), !dbg !445
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr %v2), !dbg !446
  %v4 = icmp eq i32 %v3, 0, !dbg !446
  %v5 = icmp eq i1 %v4, true, !dbg !446
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !446

decision.true.0:                                  ; preds = %entry
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.begin_2drelease.176(ptr %tail.helper.view, ptr %tail.context), !dbg !447
  br label %decision.merge.2, !dbg !447

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !448

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v7 = phi i1 [ %v6, %decision.true.0 ], [ true, %decision.false.1 ], !dbg !446
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 25), !dbg !446
  ret i1 %v7, !dbg !446
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.validated_2dcell.178(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) #1 !dbg !449 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 26, ptr %arg0), !dbg !450
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !451, !DIExpression(), !452)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !453, !DIExpression(), !454)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !455, !DIExpression(), !456)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.83, ptr %tail.context), !dbg !457
    #dbg_value(ptr %v3, !458, !DIExpression(), !459)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.85), !dbg !460
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.84, ptr %v4, ptr %tail.context), !dbg !461
    #dbg_value(i1 %v5, !462, !DIExpression(), !463)
  %v6 = call ptr @topal.tail.component.runtime.int.add(ptr %v3, ptr @topal.tail.component.literal.int.87), !dbg !464
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.86, ptr %v6, ptr %tail.context), !dbg !465
    #dbg_value(i1 %v7, !466, !DIExpression(), !467)
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.write.32(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.88, ptr %arg2, ptr %tail.context), !dbg !468
    #dbg_value(i1 %v8, !469, !DIExpression(), !470)
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v8, ptr %tail.context), !dbg !471
  %v10 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v9, ptr %tail.context), !dbg !472
  br i1 %v10, label %decision.true.0, label %decision.false.1, !dbg !472

decision.true.0:                                  ; preds = %entry
  %v11 = call ptr @topal.tail.component.runtime.int.add(ptr %v3, ptr @topal.tail.component.literal.int.89), !dbg !473
  %v12 = call fastcc i1 @topal.tail.component.topal.fn.maybe_2dbegin_2drelease.177(ptr %tail.helper.view, ptr %v11, ptr %tail.context), !dbg !474
  br label %decision.merge.2, !dbg !474

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !475

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v13 = phi i1 [ %v12, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !472
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 26), !dbg !472
  ret i1 %v13, !dbg !472
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.validate_2dcell.179(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !476 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 27, ptr %arg0), !dbg !477
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !478, !DIExpression(), !479)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !480, !DIExpression(), !481)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.21(ptr %arg1, ptr %tail.context), !dbg !482
    #dbg_value(ptr %v2, !483, !DIExpression(), !484)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !485
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.90, ptr %tail.context), !dbg !486
  %v5 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr %v4), !dbg !485
  %v6 = icmp eq i32 %v5, 0, !dbg !485
  %v7 = icmp eq i1 %v6, true, !dbg !485
    #dbg_value(i1 %v7, !487, !DIExpression(), !488)
  %v8 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.91), !dbg !489
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v8, ptr %tail.context), !dbg !490
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.92, ptr %tail.context), !dbg !491
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v9, ptr %v10), !dbg !490
  %v12 = icmp eq i32 %v11, 0, !dbg !490
  %v13 = icmp eq i1 %v12, true, !dbg !490
    #dbg_value(i1 %v13, !492, !DIExpression(), !493)
  %v14 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.93), !dbg !494
  %v15 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v14, ptr %tail.context), !dbg !495
    #dbg_value(ptr %v15, !496, !DIExpression(), !497)
  %v16 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.94, ptr %tail.context), !dbg !498
  %v17 = call i32 @topal.tail.component.runtime.int.compare(ptr %v16, ptr @topal.tail.component.literal.int.95), !dbg !498
  %v18 = icmp eq i32 %v17, 0, !dbg !498
  %v19 = icmp eq i1 %v18, true, !dbg !498
    #dbg_value(i1 %v19, !499, !DIExpression(), !500)
  %v20 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.96, ptr %tail.context), !dbg !501
  %v21 = call ptr @topal.tail.component.runtime.int.add(ptr %v20, ptr @topal.tail.component.literal.int.97), !dbg !501
  %v22 = call i32 @topal.tail.component.runtime.int.compare(ptr %v15, ptr %v21), !dbg !502
  %v23 = icmp eq i32 %v22, 0, !dbg !502
  %v24 = icmp eq i1 %v23, true, !dbg !502
    #dbg_value(i1 %v24, !503, !DIExpression(), !504)
  %v25 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v13, ptr %tail.context), !dbg !505
  %v26 = xor i1 %v19, true, !dbg !506
  %v27 = xor i1 %v24, true, !dbg !507
  %v28 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v26, i1 %v27, ptr %tail.context), !dbg !508
  %v29 = xor i1 %v28, true, !dbg !509
  %v30 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v25, i1 %v29, ptr %tail.context), !dbg !510
    #dbg_value(i1 %v30, !511, !DIExpression(), !512)
  br i1 %v30, label %decision.true.0, label %decision.false.1, !dbg !513

decision.true.0:                                  ; preds = %entry
  %v31 = call fastcc i1 @topal.tail.component.topal.fn.validated_2dcell.178(ptr %tail.helper.view, ptr %arg1, ptr %v15, ptr %tail.context), !dbg !514
  br label %decision.merge.2, !dbg !514

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !515

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v32 = phi i1 [ %v31, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !513
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 27), !dbg !513
  ret i1 %v32, !dbg !513
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.validate_2drelease.180(ptr %arg0, ptr %tail.context) #1 !dbg !516 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 28, ptr %arg0), !dbg !517
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !518, !DIExpression(), !519)
  %v1 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.98, ptr %tail.context), !dbg !520
    #dbg_value(ptr %v1, !521, !DIExpression(), !522)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.99, ptr %tail.context), !dbg !523
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr %v2), !dbg !524
  %v4 = icmp slt i32 %v3, 0, !dbg !524
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.100, ptr %tail.context), !dbg !525
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.101, ptr %tail.context), !dbg !526
  %v7 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr %v6), !dbg !525
  %v8 = icmp slt i32 %v7, 0, !dbg !525
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v4, i1 %v8, ptr %tail.context), !dbg !527
    #dbg_value(i1 %v9, !528, !DIExpression(), !529)
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.102, ptr %tail.context), !dbg !530
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v10, ptr @topal.tail.component.literal.int.103), !dbg !530
  %v12 = icmp sgt i32 %v11, 0, !dbg !530
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v9, i1 %v12, ptr %tail.context), !dbg !531
    #dbg_value(i1 %v13, !532, !DIExpression(), !533)
  br i1 %v13, label %decision.true.0, label %decision.false.1, !dbg !534

decision.true.0:                                  ; preds = %entry
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.validate_2dcell.179(ptr %tail.helper.view, ptr %v1, ptr %tail.context), !dbg !535
  br label %decision.merge.2, !dbg !535

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !536

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v15 = phi i1 [ %v14, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !534
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 28), !dbg !534
  ret i1 %v15, !dbg !534
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.phase_2dstep.234(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !537 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 29, ptr %arg0), !dbg !538
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !539, !DIExpression(), !540)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !541, !DIExpression(), !542)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.104), !dbg !543
  %v3 = icmp sle i32 %v2, 0, !dbg !543
  br i1 %v3, label %comparison.decision.action.1, label %comparison.decision.next.2, !dbg !543

comparison.decision.action.1:                     ; preds = %entry
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.search.89(ptr %tail.helper.view, ptr %tail.context), !dbg !544
  br label %comparison.decision.merge.0, !dbg !543

comparison.decision.next.2:                       ; preds = %entry
  %v5 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.105), !dbg !545
  %v6 = icmp sle i32 %v5, 0, !dbg !545
  br i1 %v6, label %comparison.decision.action.3, label %comparison.decision.next.4, !dbg !545

comparison.decision.action.3:                     ; preds = %comparison.decision.next.2
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.commit.142(ptr %tail.helper.view, i1 true, ptr %tail.context), !dbg !546
  br label %comparison.decision.merge.0, !dbg !545

comparison.decision.next.4:                       ; preds = %comparison.decision.next.2
  %v8 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.106), !dbg !547
  %v9 = icmp sle i32 %v8, 0, !dbg !547
  br i1 %v9, label %comparison.decision.action.5, label %comparison.decision.next.6, !dbg !547

comparison.decision.action.5:                     ; preds = %comparison.decision.next.4
  %v10 = call fastcc i1 @topal.tail.component.topal.fn.validate_2drelease.180(ptr %tail.helper.view, ptr %tail.context), !dbg !548
  br label %comparison.decision.merge.0, !dbg !547

comparison.decision.next.6:                       ; preds = %comparison.decision.next.4
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.107), !dbg !549
  %v12 = icmp sle i32 %v11, 0, !dbg !549
  br i1 %v12, label %comparison.decision.action.7, label %comparison.decision.next.8, !dbg !549

comparison.decision.action.7:                     ; preds = %comparison.decision.next.6
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.commit.142(ptr %tail.helper.view, i1 false, ptr %tail.context), !dbg !550
  br label %comparison.decision.merge.0, !dbg !549

comparison.decision.next.8:                       ; preds = %comparison.decision.next.6
  %v14 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.108), !dbg !551
  %v15 = icmp sle i32 %v14, 0, !dbg !551
  br i1 %v15, label %comparison.decision.action.9, label %comparison.decision.next.10, !dbg !551

comparison.decision.action.9:                     ; preds = %comparison.decision.next.8
  br label %comparison.decision.merge.0, !dbg !551

comparison.decision.next.10:                      ; preds = %comparison.decision.next.8
  br label %comparison.decision.merge.0, !dbg !552

comparison.decision.merge.0:                      ; preds = %comparison.decision.next.10, %comparison.decision.action.9, %comparison.decision.action.7, %comparison.decision.action.5, %comparison.decision.action.3, %comparison.decision.action.1
  %v16 = phi i1 [ %v4, %comparison.decision.action.1 ], [ %v7, %comparison.decision.action.3 ], [ %v10, %comparison.decision.action.5 ], [ %v13, %comparison.decision.action.7 ], [ true, %comparison.decision.action.9 ], [ false, %comparison.decision.next.10 ], !dbg !553
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 29), !dbg !553
  ret i1 %v16, !dbg !553
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc i1 @topal.tail.component.topal.fn.step.235(ptr %arg0, ptr %tail.context) #1 !dbg !554 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 30, ptr %arg0), !dbg !555
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !556, !DIExpression(), !557)
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %tail.helper.view), !dbg !558
  %v1 = call ptr @topal.tail.component.primitive.count(ptr %tail.helper.view), !dbg !558
    #dbg_value(ptr %v1, !559, !DIExpression(), !560)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.109, ptr %tail.context), !dbg !561
    #dbg_value(ptr %v2, !562, !DIExpression(), !563)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.110, ptr %tail.context), !dbg !564
    #dbg_value(ptr %v3, !565, !DIExpression(), !566)
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.111, ptr %tail.context), !dbg !567
    #dbg_value(ptr %v4, !568, !DIExpression(), !569)
  %v5 = call ptr @topal.tail.component.runtime.int.multiply(ptr %v2, ptr @topal.tail.component.literal.int.113), !dbg !570
  %v6 = call ptr @topal.tail.component.runtime.int.add(ptr @topal.tail.component.literal.int.112, ptr %v5), !dbg !571
  %v7 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr %v6), !dbg !572
  %v8 = icmp sge i32 %v7, 0, !dbg !572
  %v9 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr @topal.tail.component.literal.int.114), !dbg !573
  %v10 = icmp sgt i32 %v9, 0, !dbg !573
  %v11 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v8, i1 %v10, ptr %tail.context), !dbg !574
    #dbg_value(i1 %v11, !575, !DIExpression(), !576)
  %v12 = call i32 @topal.tail.component.runtime.int.compare(ptr %v4, ptr @topal.tail.component.literal.int.115), !dbg !577
  %v13 = icmp sgt i32 %v12, 0, !dbg !577
  %v14 = call i32 @topal.tail.component.runtime.int.compare(ptr %v4, ptr @topal.tail.component.literal.int.116), !dbg !578
  %v15 = icmp slt i32 %v14, 0, !dbg !578
  %v16 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v13, i1 %v15, ptr %tail.context), !dbg !579
    #dbg_value(i1 %v16, !580, !DIExpression(), !581)
  %v17 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v11, i1 %v16, ptr %tail.context), !dbg !582
  br i1 %v17, label %decision.true.0, label %decision.false.1, !dbg !582

decision.true.0:                                  ; preds = %entry
  %v18 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.117, ptr %tail.context), !dbg !583
  %v19 = call fastcc i1 @topal.tail.component.topal.fn.phase_2dstep.234(ptr %tail.helper.view, ptr %v18, ptr %tail.context), !dbg !584
  br label %decision.merge.2, !dbg !584

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !585

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v20 = phi i1 [ %v19, %decision.true.0 ], [ false, %decision.false.1 ], !dbg !582
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 30), !dbg !582
  ret i1 %v20, !dbg !582
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.tail.component.topal.fn.step_2dstatus.460(ptr %arg0, ptr %tail.context) #1 !dbg !586 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 31, ptr %arg0), !dbg !589
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !590, !DIExpression(), !591)
    #dbg_value(ptr @topal.tail.component.literal.int.118, !592, !DIExpression(), !593)
    #dbg_value(ptr @topal.tail.component.literal.int.119, !594, !DIExpression(), !595)
  %v1 = call fastcc i1 @topal.tail.component.topal.fn.step.235(ptr %tail.helper.view, ptr %tail.context), !dbg !596
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !596

decision.true.0:                                  ; preds = %entry
  br label %decision.merge.2, !dbg !597

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !598

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v2 = phi ptr [ @topal.tail.component.literal.int.118, %decision.true.0 ], [ @topal.tail.component.literal.int.119, %decision.false.1 ], !dbg !596
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 31), !dbg !596
  ret ptr %v2, !dbg !596
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define internal fastcc ptr @topal.tail.component.topal.fn.next_2dstatus.461(ptr %arg0, ptr %arg1, ptr %tail.context) #1 !dbg !599 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 32, ptr %arg0), !dbg !600
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !601, !DIExpression(), !602)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !603, !DIExpression(), !604)
    #dbg_value(ptr @topal.tail.component.literal.int.120, !605, !DIExpression(), !606)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.121), !dbg !607
  %v3 = icmp eq i32 %v2, 0, !dbg !607
  %v4 = icmp eq i1 %v3, true, !dbg !607
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !607

decision.true.0:                                  ; preds = %entry
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.step_2dstatus.460(ptr %tail.helper.view, ptr %tail.context), !dbg !608
  br label %decision.merge.2, !dbg !608

decision.false.1:                                 ; preds = %entry
  br label %decision.merge.2, !dbg !609

decision.merge.2:                                 ; preds = %decision.false.1, %decision.true.0
  %v6 = phi ptr [ %v5, %decision.true.0 ], [ @topal.tail.component.literal.int.120, %decision.false.1 ], !dbg !607
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 32), !dbg !607
  ret ptr %v6, !dbg !607
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define dso_local i64 @topal_tail_step_component_v1(ptr %tail.context) #1 !dbg !610 {
entry:
  call void @topal_tail_step_begin_v1(ptr %tail.context), !dbg !613
  %v0 = call ptr @topal_tail_input_view_v1(ptr %tail.context), !dbg !614
    #dbg_value(ptr %v0, !615, !DIExpression(), !614)
  %v1 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 1), !dbg !616
    #dbg_value(ptr %v1, !617, !DIExpression(), !616)
  %v2 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 2), !dbg !618
    #dbg_value(ptr %v2, !619, !DIExpression(), !618)
  %v3 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 3), !dbg !620
    #dbg_value(ptr %v3, !621, !DIExpression(), !620)
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr @topal.tail.component.literal.int.122), !dbg !622
  %v5 = icmp sle i32 %v4, 0, !dbg !622
  br i1 %v5, label %tail.compare.action.0, label %tail.compare.next.1, !dbg !622

tail.compare.action.0:                            ; preds = %entry
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.finish.4(ptr %v0, ptr %v3, ptr %tail.context), !dbg !623
  call void @topal_tail_result_number_v1(ptr %tail.context, ptr %v6), !dbg !623
  ret i64 0, !dbg !623

tail.compare.next.1:                              ; preds = %entry
  %v7 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr %v2), !dbg !624
  %v8 = icmp sle i32 %v7, 0, !dbg !624
  br i1 %v8, label %tail.compare.action.2, label %tail.compare.next.3, !dbg !624

tail.compare.action.2:                            ; preds = %tail.compare.next.1
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.finish.4(ptr %v0, ptr %v3, ptr %tail.context), !dbg !625
  call void @topal_tail_result_number_v1(ptr %tail.context, ptr %v9), !dbg !625
  ret i64 0, !dbg !625

tail.compare.next.3:                              ; preds = %tail.compare.next.1
  %v10 = call ptr @topal.tail.component.runtime.int.subtract(ptr %v1, ptr @topal.tail.component.literal.int.123), !dbg !626
  %v11 = call fastcc ptr @topal.tail.component.topal.fn.stop_2dlimit.11(ptr %v0, ptr %v1, ptr %v3, ptr %tail.context), !dbg !627
  %v12 = call fastcc ptr @topal.tail.component.topal.fn.next_2dstatus.461(ptr %v0, ptr %v3, ptr %tail.context), !dbg !628
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %v0), !dbg !629
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 1, ptr %v10), !dbg !629
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 2, ptr %v11), !dbg !629
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 3, ptr %v12), !dbg !629
  ret i64 1, !dbg !629
}

; Function Attrs: noimplicitfloat noinline noredzone nounwind
define dso_local i64 @topal_tail_readonly_bytes_v1(ptr %root) #1 {
entry:
  %match0 = icmp eq ptr %root, @topal.tail.component.literal.int.0
  %size0 = select i1 %match0, i64 24, i64 0
  %match1 = icmp eq ptr %root, @topal.tail.component.literal.int.1
  %size1 = select i1 %match1, i64 24, i64 %size0
  %match2 = icmp eq ptr %root, @topal.tail.component.literal.int.10
  %size2 = select i1 %match2, i64 20, i64 %size1
  %match3 = icmp eq ptr %root, @topal.tail.component.literal.int.100
  %size3 = select i1 %match3, i64 20, i64 %size2
  %match4 = icmp eq ptr %root, @topal.tail.component.literal.int.101
  %size4 = select i1 %match4, i64 20, i64 %size3
  %match5 = icmp eq ptr %root, @topal.tail.component.literal.int.102
  %size5 = select i1 %match5, i64 20, i64 %size4
  %match6 = icmp eq ptr %root, @topal.tail.component.literal.int.103
  %size6 = select i1 %match6, i64 16, i64 %size5
  %match7 = icmp eq ptr %root, @topal.tail.component.literal.int.104
  %size7 = select i1 %match7, i64 16, i64 %size6
  %match8 = icmp eq ptr %root, @topal.tail.component.literal.int.105
  %size8 = select i1 %match8, i64 20, i64 %size7
  %match9 = icmp eq ptr %root, @topal.tail.component.literal.int.106
  %size9 = select i1 %match9, i64 20, i64 %size8
  %match10 = icmp eq ptr %root, @topal.tail.component.literal.int.107
  %size10 = select i1 %match10, i64 20, i64 %size9
  %match11 = icmp eq ptr %root, @topal.tail.component.literal.int.108
  %size11 = select i1 %match11, i64 20, i64 %size10
  %match12 = icmp eq ptr %root, @topal.tail.component.literal.int.109
  %size12 = select i1 %match12, i64 16, i64 %size11
  %match13 = icmp eq ptr %root, @topal.tail.component.literal.int.11
  %size13 = select i1 %match13, i64 20, i64 %size12
  %match14 = icmp eq ptr %root, @topal.tail.component.literal.int.110
  %size14 = select i1 %match14, i64 20, i64 %size13
  %match15 = icmp eq ptr %root, @topal.tail.component.literal.int.111
  %size15 = select i1 %match15, i64 20, i64 %size14
  %match16 = icmp eq ptr %root, @topal.tail.component.literal.int.112
  %size16 = select i1 %match16, i64 20, i64 %size15
  %match17 = icmp eq ptr %root, @topal.tail.component.literal.int.113
  %size17 = select i1 %match17, i64 20, i64 %size16
  %match18 = icmp eq ptr %root, @topal.tail.component.literal.int.114
  %size18 = select i1 %match18, i64 16, i64 %size17
  %match19 = icmp eq ptr %root, @topal.tail.component.literal.int.115
  %size19 = select i1 %match19, i64 16, i64 %size18
  %match20 = icmp eq ptr %root, @topal.tail.component.literal.int.116
  %size20 = select i1 %match20, i64 24, i64 %size19
  %match21 = icmp eq ptr %root, @topal.tail.component.literal.int.117
  %size21 = select i1 %match21, i64 20, i64 %size20
  %match22 = icmp eq ptr %root, @topal.tail.component.literal.int.118
  %size22 = select i1 %match22, i64 16, i64 %size21
  %match23 = icmp eq ptr %root, @topal.tail.component.literal.int.119
  %size23 = select i1 %match23, i64 24, i64 %size22
  %match24 = icmp eq ptr %root, @topal.tail.component.literal.int.12
  %size24 = select i1 %match24, i64 20, i64 %size23
  %match25 = icmp eq ptr %root, @topal.tail.component.literal.int.120
  %size25 = select i1 %match25, i64 24, i64 %size24
  %match26 = icmp eq ptr %root, @topal.tail.component.literal.int.121
  %size26 = select i1 %match26, i64 16, i64 %size25
  %match27 = icmp eq ptr %root, @topal.tail.component.literal.int.122
  %size27 = select i1 %match27, i64 16, i64 %size26
  %match28 = icmp eq ptr %root, @topal.tail.component.literal.int.123
  %size28 = select i1 %match28, i64 20, i64 %size27
  %match29 = icmp eq ptr %root, @topal.tail.component.literal.int.13
  %size29 = select i1 %match29, i64 20, i64 %size28
  %match30 = icmp eq ptr %root, @topal.tail.component.literal.int.14
  %size30 = select i1 %match30, i64 16, i64 %size29
  %match31 = icmp eq ptr %root, @topal.tail.component.literal.int.15
  %size31 = select i1 %match31, i64 20, i64 %size30
  %match32 = icmp eq ptr %root, @topal.tail.component.literal.int.16
  %size32 = select i1 %match32, i64 20, i64 %size31
  %match33 = icmp eq ptr %root, @topal.tail.component.literal.int.17
  %size33 = select i1 %match33, i64 20, i64 %size32
  %match34 = icmp eq ptr %root, @topal.tail.component.literal.int.18
  %size34 = select i1 %match34, i64 20, i64 %size33
  %match35 = icmp eq ptr %root, @topal.tail.component.literal.int.19
  %size35 = select i1 %match35, i64 20, i64 %size34
  %match36 = icmp eq ptr %root, @topal.tail.component.literal.int.2
  %size36 = select i1 %match36, i64 16, i64 %size35
  %match37 = icmp eq ptr %root, @topal.tail.component.literal.int.20
  %size37 = select i1 %match37, i64 20, i64 %size36
  %match38 = icmp eq ptr %root, @topal.tail.component.literal.int.21
  %size38 = select i1 %match38, i64 20, i64 %size37
  %match39 = icmp eq ptr %root, @topal.tail.component.literal.int.22
  %size39 = select i1 %match39, i64 20, i64 %size38
  %match40 = icmp eq ptr %root, @topal.tail.component.literal.int.23
  %size40 = select i1 %match40, i64 20, i64 %size39
  %match41 = icmp eq ptr %root, @topal.tail.component.literal.int.24
  %size41 = select i1 %match41, i64 20, i64 %size40
  %match42 = icmp eq ptr %root, @topal.tail.component.literal.int.25
  %size42 = select i1 %match42, i64 20, i64 %size41
  %match43 = icmp eq ptr %root, @topal.tail.component.literal.int.26
  %size43 = select i1 %match43, i64 16, i64 %size42
  %match44 = icmp eq ptr %root, @topal.tail.component.literal.int.27
  %size44 = select i1 %match44, i64 16, i64 %size43
  %match45 = icmp eq ptr %root, @topal.tail.component.literal.int.28
  %size45 = select i1 %match45, i64 20, i64 %size44
  %match46 = icmp eq ptr %root, @topal.tail.component.literal.int.29
  %size46 = select i1 %match46, i64 16, i64 %size45
  %match47 = icmp eq ptr %root, @topal.tail.component.literal.int.3
  %size47 = select i1 %match47, i64 20, i64 %size46
  %match48 = icmp eq ptr %root, @topal.tail.component.literal.int.30
  %size48 = select i1 %match48, i64 20, i64 %size47
  %match49 = icmp eq ptr %root, @topal.tail.component.literal.int.31
  %size49 = select i1 %match49, i64 20, i64 %size48
  %match50 = icmp eq ptr %root, @topal.tail.component.literal.int.32
  %size50 = select i1 %match50, i64 20, i64 %size49
  %match51 = icmp eq ptr %root, @topal.tail.component.literal.int.33
  %size51 = select i1 %match51, i64 20, i64 %size50
  %match52 = icmp eq ptr %root, @topal.tail.component.literal.int.34
  %size52 = select i1 %match52, i64 20, i64 %size51
  %match53 = icmp eq ptr %root, @topal.tail.component.literal.int.35
  %size53 = select i1 %match53, i64 20, i64 %size52
  %match54 = icmp eq ptr %root, @topal.tail.component.literal.int.36
  %size54 = select i1 %match54, i64 20, i64 %size53
  %match55 = icmp eq ptr %root, @topal.tail.component.literal.int.37
  %size55 = select i1 %match55, i64 20, i64 %size54
  %match56 = icmp eq ptr %root, @topal.tail.component.literal.int.38
  %size56 = select i1 %match56, i64 20, i64 %size55
  %match57 = icmp eq ptr %root, @topal.tail.component.literal.int.39
  %size57 = select i1 %match57, i64 16, i64 %size56
  %match58 = icmp eq ptr %root, @topal.tail.component.literal.int.4
  %size58 = select i1 %match58, i64 20, i64 %size57
  %match59 = icmp eq ptr %root, @topal.tail.component.literal.int.40
  %size59 = select i1 %match59, i64 20, i64 %size58
  %match60 = icmp eq ptr %root, @topal.tail.component.literal.int.41
  %size60 = select i1 %match60, i64 20, i64 %size59
  %match61 = icmp eq ptr %root, @topal.tail.component.literal.int.42
  %size61 = select i1 %match61, i64 20, i64 %size60
  %match62 = icmp eq ptr %root, @topal.tail.component.literal.int.43
  %size62 = select i1 %match62, i64 20, i64 %size61
  %match63 = icmp eq ptr %root, @topal.tail.component.literal.int.44
  %size63 = select i1 %match63, i64 16, i64 %size62
  %match64 = icmp eq ptr %root, @topal.tail.component.literal.int.45
  %size64 = select i1 %match64, i64 16, i64 %size63
  %match65 = icmp eq ptr %root, @topal.tail.component.literal.int.46
  %size65 = select i1 %match65, i64 20, i64 %size64
  %match66 = icmp eq ptr %root, @topal.tail.component.literal.int.47
  %size66 = select i1 %match66, i64 20, i64 %size65
  %match67 = icmp eq ptr %root, @topal.tail.component.literal.int.48
  %size67 = select i1 %match67, i64 20, i64 %size66
  %match68 = icmp eq ptr %root, @topal.tail.component.literal.int.49
  %size68 = select i1 %match68, i64 20, i64 %size67
  %match69 = icmp eq ptr %root, @topal.tail.component.literal.int.5
  %size69 = select i1 %match69, i64 20, i64 %size68
  %match70 = icmp eq ptr %root, @topal.tail.component.literal.int.50
  %size70 = select i1 %match70, i64 16, i64 %size69
  %match71 = icmp eq ptr %root, @topal.tail.component.literal.int.51
  %size71 = select i1 %match71, i64 16, i64 %size70
  %match72 = icmp eq ptr %root, @topal.tail.component.literal.int.52
  %size72 = select i1 %match72, i64 20, i64 %size71
  %match73 = icmp eq ptr %root, @topal.tail.component.literal.int.53
  %size73 = select i1 %match73, i64 20, i64 %size72
  %match74 = icmp eq ptr %root, @topal.tail.component.literal.int.54
  %size74 = select i1 %match74, i64 20, i64 %size73
  %match75 = icmp eq ptr %root, @topal.tail.component.literal.int.55
  %size75 = select i1 %match75, i64 20, i64 %size74
  %match76 = icmp eq ptr %root, @topal.tail.component.literal.int.56
  %size76 = select i1 %match76, i64 20, i64 %size75
  %match77 = icmp eq ptr %root, @topal.tail.component.literal.int.57
  %size77 = select i1 %match77, i64 20, i64 %size76
  %match78 = icmp eq ptr %root, @topal.tail.component.literal.int.58
  %size78 = select i1 %match78, i64 20, i64 %size77
  %match79 = icmp eq ptr %root, @topal.tail.component.literal.int.59
  %size79 = select i1 %match79, i64 20, i64 %size78
  %match80 = icmp eq ptr %root, @topal.tail.component.literal.int.6
  %size80 = select i1 %match80, i64 16, i64 %size79
  %match81 = icmp eq ptr %root, @topal.tail.component.literal.int.60
  %size81 = select i1 %match81, i64 16, i64 %size80
  %match82 = icmp eq ptr %root, @topal.tail.component.literal.int.61
  %size82 = select i1 %match82, i64 20, i64 %size81
  %match83 = icmp eq ptr %root, @topal.tail.component.literal.int.62
  %size83 = select i1 %match83, i64 20, i64 %size82
  %match84 = icmp eq ptr %root, @topal.tail.component.literal.int.63
  %size84 = select i1 %match84, i64 20, i64 %size83
  %match85 = icmp eq ptr %root, @topal.tail.component.literal.int.64
  %size85 = select i1 %match85, i64 20, i64 %size84
  %match86 = icmp eq ptr %root, @topal.tail.component.literal.int.65
  %size86 = select i1 %match86, i64 20, i64 %size85
  %match87 = icmp eq ptr %root, @topal.tail.component.literal.int.66
  %size87 = select i1 %match87, i64 20, i64 %size86
  %match88 = icmp eq ptr %root, @topal.tail.component.literal.int.67
  %size88 = select i1 %match88, i64 20, i64 %size87
  %match89 = icmp eq ptr %root, @topal.tail.component.literal.int.68
  %size89 = select i1 %match89, i64 16, i64 %size88
  %match90 = icmp eq ptr %root, @topal.tail.component.literal.int.69
  %size90 = select i1 %match90, i64 16, i64 %size89
  %match91 = icmp eq ptr %root, @topal.tail.component.literal.int.7
  %size91 = select i1 %match91, i64 16, i64 %size90
  %match92 = icmp eq ptr %root, @topal.tail.component.literal.int.70
  %size92 = select i1 %match92, i64 20, i64 %size91
  %match93 = icmp eq ptr %root, @topal.tail.component.literal.int.71
  %size93 = select i1 %match93, i64 16, i64 %size92
  %match94 = icmp eq ptr %root, @topal.tail.component.literal.int.72
  %size94 = select i1 %match94, i64 20, i64 %size93
  %match95 = icmp eq ptr %root, @topal.tail.component.literal.int.73
  %size95 = select i1 %match95, i64 20, i64 %size94
  %match96 = icmp eq ptr %root, @topal.tail.component.literal.int.74
  %size96 = select i1 %match96, i64 20, i64 %size95
  %match97 = icmp eq ptr %root, @topal.tail.component.literal.int.75
  %size97 = select i1 %match97, i64 20, i64 %size96
  %match98 = icmp eq ptr %root, @topal.tail.component.literal.int.76
  %size98 = select i1 %match98, i64 20, i64 %size97
  %match99 = icmp eq ptr %root, @topal.tail.component.literal.int.77
  %size99 = select i1 %match99, i64 16, i64 %size98
  %match100 = icmp eq ptr %root, @topal.tail.component.literal.int.78
  %size100 = select i1 %match100, i64 20, i64 %size99
  %match101 = icmp eq ptr %root, @topal.tail.component.literal.int.79
  %size101 = select i1 %match101, i64 20, i64 %size100
  %match102 = icmp eq ptr %root, @topal.tail.component.literal.int.8
  %size102 = select i1 %match102, i64 20, i64 %size101
  %match103 = icmp eq ptr %root, @topal.tail.component.literal.int.80
  %size103 = select i1 %match103, i64 20, i64 %size102
  %match104 = icmp eq ptr %root, @topal.tail.component.literal.int.81
  %size104 = select i1 %match104, i64 20, i64 %size103
  %match105 = icmp eq ptr %root, @topal.tail.component.literal.int.82
  %size105 = select i1 %match105, i64 20, i64 %size104
  %match106 = icmp eq ptr %root, @topal.tail.component.literal.int.83
  %size106 = select i1 %match106, i64 20, i64 %size105
  %match107 = icmp eq ptr %root, @topal.tail.component.literal.int.84
  %size107 = select i1 %match107, i64 20, i64 %size106
  %match108 = icmp eq ptr %root, @topal.tail.component.literal.int.85
  %size108 = select i1 %match108, i64 20, i64 %size107
  %match109 = icmp eq ptr %root, @topal.tail.component.literal.int.86
  %size109 = select i1 %match109, i64 20, i64 %size108
  %match110 = icmp eq ptr %root, @topal.tail.component.literal.int.87
  %size110 = select i1 %match110, i64 20, i64 %size109
  %match111 = icmp eq ptr %root, @topal.tail.component.literal.int.88
  %size111 = select i1 %match111, i64 20, i64 %size110
  %match112 = icmp eq ptr %root, @topal.tail.component.literal.int.89
  %size112 = select i1 %match112, i64 20, i64 %size111
  %match113 = icmp eq ptr %root, @topal.tail.component.literal.int.9
  %size113 = select i1 %match113, i64 20, i64 %size112
  %match114 = icmp eq ptr %root, @topal.tail.component.literal.int.90
  %size114 = select i1 %match114, i64 20, i64 %size113
  %match115 = icmp eq ptr %root, @topal.tail.component.literal.int.91
  %size115 = select i1 %match115, i64 20, i64 %size114
  %match116 = icmp eq ptr %root, @topal.tail.component.literal.int.92
  %size116 = select i1 %match116, i64 20, i64 %size115
  %match117 = icmp eq ptr %root, @topal.tail.component.literal.int.93
  %size117 = select i1 %match117, i64 20, i64 %size116
  %match118 = icmp eq ptr %root, @topal.tail.component.literal.int.94
  %size118 = select i1 %match118, i64 20, i64 %size117
  %match119 = icmp eq ptr %root, @topal.tail.component.literal.int.95
  %size119 = select i1 %match119, i64 16, i64 %size118
  %match120 = icmp eq ptr %root, @topal.tail.component.literal.int.96
  %size120 = select i1 %match120, i64 20, i64 %size119
  %match121 = icmp eq ptr %root, @topal.tail.component.literal.int.97
  %size121 = select i1 %match121, i64 20, i64 %size120
  %match122 = icmp eq ptr %root, @topal.tail.component.literal.int.98
  %size122 = select i1 %match122, i64 20, i64 %size121
  %match123 = icmp eq ptr %root, @topal.tail.component.literal.int.99
  %size123 = select i1 %match123, i64 16, i64 %size122
  %match124 = icmp eq ptr %root, @topal.tail.component.runtime.int.one
  %size124 = select i1 %match124, i64 20, i64 %size123
  %match125 = icmp eq ptr %root, @topal.tail.component.runtime.int.zero
  %size125 = select i1 %match125, i64 16, i64 %size124
  ret i64 %size125
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { noimplicitfloat noinline noredzone nounwind "disable-tail-calls"="true" }
attributes #2 = { noreturn }
attributes #3 = { noimplicitfloat noinline noredzone noreturn nounwind "disable-tail-calls"="true" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!3, !4}
!llvm.ident = !{!5}

!0 = distinct !DICompileUnit(language: DW_LANG_C11, file: !1, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !2, retainedTypes: !2)
!1 = !DIFile(filename: "frame-metadata.t", directory: "memory")
!2 = !{}
!3 = !{i32 2, !"Dwarf Version", i32 5}
!4 = !{i32 2, !"Debug Info Version", i32 3}
!5 = !{!"topalc 0.1.0"}
!6 = distinct !DISubprogram(name: "word", linkageName: "topal.tail.component.topal.fn.word.1", scope: !1, file: !1, line: 5, type: !7, scopeLine: 5, spFlags: DISPFlagDefinition, unit: !0)
!7 = !DISubroutineType(types: !8)
!8 = !{!9, !16, !9}
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !1, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64, align: 64)
!11 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !1, size: 128, align: 64, elements: !12)
!12 = !{!13, !15}
!13 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !1, baseType: !14, size: 64, align: 64)
!14 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!15 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !1, baseType: !14, size: 64, align: 64, offset: 64)
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "KernelByteRegion", file: !1, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64, align: 64)
!18 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalKernelRegionBorrow", flags: DIFlagFwdDecl)
!19 = !DILocation(line: 5, column: 1, scope: !6)
!20 = !DILocalVariable(name: "region", arg: 1, scope: !6, file: !1, line: 5, type: !16)
!21 = !DILocation(line: 5, column: 14, scope: !6)
!22 = !DILocalVariable(name: "offset", arg: 2, scope: !6, file: !1, line: 5, type: !9)
!23 = !DILocation(line: 5, column: 41, scope: !6)
!24 = !DILocalVariable(name: "invalid", scope: !6, file: !1, line: 6, type: !9)
!25 = !DILocation(line: 6, column: 3, scope: !6)
!26 = !DILocation(line: 7, column: 3, scope: !6)
!27 = !DILocation(line: 8, column: 10, scope: !6)
!28 = !DILocalVariable(name: "value", scope: !6, file: !1, line: 8, type: !9)
!29 = !DILocation(line: 8, column: 21, scope: !6)
!30 = !DILocation(line: 9, column: 15, scope: !6)
!31 = distinct !DISubprogram(name: "both", linkageName: "topal.tail.component.topal.fn.both.2", scope: !1, file: !1, line: 14, type: !32, scopeLine: 14, spFlags: DISPFlagDefinition, unit: !0)
!32 = !DISubroutineType(types: !33)
!33 = !{!34, !34, !34}
!34 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!35 = !DILocation(line: 14, column: 1, scope: !31)
!36 = !DILocalVariable(name: "first", arg: 1, scope: !31, file: !1, line: 14, type: !34)
!37 = !DILocation(line: 14, column: 14, scope: !31)
!38 = !DILocalVariable(name: "second", arg: 2, scope: !31, file: !1, line: 14, type: !34)
!39 = !DILocation(line: 14, column: 31, scope: !31)
!40 = !DILocation(line: 15, column: 3, scope: !31)
!41 = !DILocation(line: 16, column: 15, scope: !31)
!42 = !DILocation(line: 17, column: 16, scope: !31)
!43 = distinct !DISubprogram(name: "finish", linkageName: "topal.tail.component.topal.fn.finish.4", scope: !1, file: !1, line: 207, type: !7, scopeLine: 207, spFlags: DISPFlagDefinition, unit: !0)
!44 = !DILocation(line: 207, column: 1, scope: !43)
!45 = !DILocalVariable(name: "region", arg: 1, scope: !43, file: !1, line: 207, type: !16)
!46 = !DILocation(line: 207, column: 16, scope: !43)
!47 = !DILocalVariable(name: "status", arg: 2, scope: !43, file: !1, line: 207, type: !9)
!48 = !DILocation(line: 207, column: 43, scope: !43)
!49 = !DILocalVariable(name: "invalid", scope: !43, file: !1, line: 208, type: !9)
!50 = !DILocation(line: 208, column: 3, scope: !43)
!51 = !DILocation(line: 209, column: 18, scope: !43)
!52 = !DILocation(line: 209, column: 31, scope: !43)
!53 = !DILocation(line: 209, column: 12, scope: !43)
!54 = !DILocalVariable(name: "ready", scope: !43, file: !1, line: 209, type: !34)
!55 = !DILocation(line: 209, column: 3, scope: !43)
!56 = !DILocation(line: 210, column: 3, scope: !43)
!57 = !DILocation(line: 211, column: 15, scope: !43)
!58 = !DILocation(line: 212, column: 16, scope: !43)
!59 = distinct !DISubprogram(name: "stop-limit", linkageName: "topal.tail.component.topal.fn.stop_2dlimit.11", scope: !1, file: !1, line: 214, type: !60, scopeLine: 214, spFlags: DISPFlagDefinition, unit: !0)
!60 = !DISubroutineType(types: !61)
!61 = !{!9, !16, !9, !9}
!62 = !DILocation(line: 214, column: 1, scope: !59)
!63 = !DILocalVariable(name: "region", arg: 1, scope: !59, file: !1, line: 214, type: !16)
!64 = !DILocation(line: 214, column: 20, scope: !59)
!65 = !DILocalVariable(name: "remaining", arg: 2, scope: !59, file: !1, line: 214, type: !9)
!66 = !DILocation(line: 214, column: 47, scope: !59)
!67 = !DILocalVariable(name: "status", arg: 3, scope: !59, file: !1, line: 214, type: !9)
!68 = !DILocation(line: 214, column: 64, scope: !59)
!69 = !DILocalVariable(name: "zero", scope: !59, file: !1, line: 215, type: !9)
!70 = !DILocation(line: 215, column: 3, scope: !59)
!71 = !DILocation(line: 216, column: 20, scope: !59)
!72 = !DILocation(line: 216, column: 38, scope: !59)
!73 = !DILocation(line: 216, column: 32, scope: !59)
!74 = !DILocation(line: 216, column: 14, scope: !59)
!75 = !DILocalVariable(name: "running", scope: !59, file: !1, line: 216, type: !34)
!76 = !DILocation(line: 216, column: 3, scope: !59)
!77 = !DILocation(line: 217, column: 3, scope: !59)
!78 = !DILocation(line: 218, column: 15, scope: !59)
!79 = !DILocation(line: 219, column: 16, scope: !59)
!80 = distinct !DISubprogram(name: "cell", linkageName: "topal.tail.component.topal.fn.cell.21", scope: !1, file: !1, line: 19, type: !81, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !0)
!81 = !DISubroutineType(types: !82)
!82 = !{!9, !9}
!83 = !DILocation(line: 19, column: 1, scope: !80)
!84 = !DILocalVariable(name: "index", arg: 1, scope: !80, file: !1, line: 19, type: !9)
!85 = !DILocation(line: 19, column: 13, scope: !80)
!86 = !DILocation(line: 20, column: 10, scope: !80)
!87 = !DILocation(line: 20, column: 3, scope: !80)
!88 = distinct !DISubprogram(name: "write", linkageName: "topal.tail.component.topal.fn.write.32", scope: !1, file: !1, line: 11, type: !89, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !0)
!89 = !DISubroutineType(types: !90)
!90 = !{!34, !16, !9, !9}
!91 = !DILocation(line: 11, column: 1, scope: !88)
!92 = !DILocalVariable(name: "region", arg: 1, scope: !88, file: !1, line: 11, type: !16)
!93 = !DILocation(line: 11, column: 15, scope: !88)
!94 = !DILocalVariable(name: "offset", arg: 2, scope: !88, file: !1, line: 11, type: !9)
!95 = !DILocation(line: 11, column: 42, scope: !88)
!96 = !DILocalVariable(name: "value", arg: 3, scope: !88, file: !1, line: 11, type: !9)
!97 = !DILocation(line: 11, column: 56, scope: !88)
!98 = !DILocation(line: 12, column: 3, scope: !88)
!99 = distinct !DISubprogram(name: "select-span", linkageName: "topal.tail.component.topal.fn.select_2dspan.49", scope: !1, file: !1, line: 32, type: !100, scopeLine: 32, spFlags: DISPFlagDefinition, unit: !0)
!100 = !DISubroutineType(types: !101)
!101 = !{!34, !16, !9}
!102 = !DILocation(line: 32, column: 1, scope: !99)
!103 = !DILocalVariable(name: "region", arg: 1, scope: !99, file: !1, line: 32, type: !16)
!104 = !DILocation(line: 32, column: 21, scope: !99)
!105 = !DILocalVariable(name: "start", arg: 2, scope: !99, file: !1, line: 32, type: !9)
!106 = !DILocation(line: 32, column: 48, scope: !99)
!107 = !DILocation(line: 33, column: 13, scope: !99)
!108 = !DILocalVariable(name: "cursor", scope: !99, file: !1, line: 33, type: !34)
!109 = !DILocation(line: 33, column: 3, scope: !99)
!110 = !DILocation(line: 34, column: 13, scope: !99)
!111 = !DILocalVariable(name: "length", scope: !99, file: !1, line: 34, type: !34)
!112 = !DILocation(line: 34, column: 3, scope: !99)
!113 = !DILocation(line: 35, column: 32, scope: !99)
!114 = !DILocation(line: 35, column: 13, scope: !99)
!115 = !DILocalVariable(name: "result", scope: !99, file: !1, line: 35, type: !34)
!116 = !DILocation(line: 35, column: 3, scope: !99)
!117 = !DILocation(line: 36, column: 12, scope: !99)
!118 = !DILocalVariable(name: "phase", scope: !99, file: !1, line: 36, type: !34)
!119 = !DILocation(line: 36, column: 3, scope: !99)
!120 = !DILocation(line: 37, column: 9, scope: !99)
!121 = !DILocation(line: 37, column: 32, scope: !99)
!122 = !DILocation(line: 37, column: 3, scope: !99)
!123 = distinct !DISubprogram(name: "maybe-select", linkageName: "topal.tail.component.topal.fn.maybe_2dselect.50", scope: !1, file: !1, line: 39, type: !89, scopeLine: 39, spFlags: DISPFlagDefinition, unit: !0)
!124 = !DILocation(line: 39, column: 1, scope: !123)
!125 = !DILocalVariable(name: "region", arg: 1, scope: !123, file: !1, line: 39, type: !16)
!126 = !DILocation(line: 39, column: 22, scope: !123)
!127 = !DILocalVariable(name: "start", arg: 2, scope: !123, file: !1, line: 39, type: !9)
!128 = !DILocation(line: 39, column: 49, scope: !123)
!129 = !DILocalVariable(name: "length", arg: 3, scope: !123, file: !1, line: 39, type: !9)
!130 = !DILocation(line: 39, column: 62, scope: !123)
!131 = !DILocation(line: 40, column: 14, scope: !123)
!132 = !DILocation(line: 40, column: 3, scope: !123)
!133 = !DILocation(line: 41, column: 15, scope: !123)
!134 = !DILocation(line: 42, column: 16, scope: !123)
!135 = distinct !DISubprogram(name: "extend-span", linkageName: "topal.tail.component.topal.fn.extend_2dspan.51", scope: !1, file: !1, line: 44, type: !136, scopeLine: 44, spFlags: DISPFlagDefinition, unit: !0)
!136 = !DISubroutineType(types: !137)
!137 = !{!34, !16, !9, !9, !9, !9, !9}
!138 = !DILocation(line: 44, column: 1, scope: !135)
!139 = !DILocalVariable(name: "region", arg: 1, scope: !135, file: !1, line: 44, type: !16)
!140 = !DILocation(line: 44, column: 21, scope: !135)
!141 = !DILocalVariable(name: "cursor", arg: 2, scope: !135, file: !1, line: 44, type: !9)
!142 = !DILocation(line: 44, column: 48, scope: !135)
!143 = !DILocalVariable(name: "start", arg: 3, scope: !135, file: !1, line: 44, type: !9)
!144 = !DILocation(line: 44, column: 62, scope: !135)
!145 = !DILocalVariable(name: "length", arg: 4, scope: !135, file: !1, line: 44, type: !9)
!146 = !DILocation(line: 44, column: 75, scope: !135)
!147 = !DILocalVariable(name: "provenance", arg: 5, scope: !135, file: !1, line: 44, type: !9)
!148 = !DILocation(line: 44, column: 89, scope: !135)
!149 = !DILocalVariable(name: "physical", arg: 6, scope: !135, file: !1, line: 44, type: !9)
!150 = !DILocation(line: 44, column: 107, scope: !135)
!151 = !DILocation(line: 45, column: 8, scope: !135)
!152 = !DILocalVariable(name: "a", scope: !135, file: !1, line: 45, type: !34)
!153 = !DILocation(line: 45, column: 3, scope: !135)
!154 = !DILocation(line: 46, column: 8, scope: !135)
!155 = !DILocalVariable(name: "b", scope: !135, file: !1, line: 46, type: !34)
!156 = !DILocation(line: 46, column: 3, scope: !135)
!157 = !DILocation(line: 47, column: 8, scope: !135)
!158 = !DILocalVariable(name: "c", scope: !135, file: !1, line: 47, type: !34)
!159 = !DILocation(line: 47, column: 3, scope: !135)
!160 = !DILocation(line: 48, column: 8, scope: !135)
!161 = !DILocalVariable(name: "d", scope: !135, file: !1, line: 48, type: !34)
!162 = !DILocation(line: 48, column: 3, scope: !135)
!163 = !DILocation(line: 49, column: 27, scope: !135)
!164 = !DILocation(line: 49, column: 8, scope: !135)
!165 = !DILocalVariable(name: "e", scope: !135, file: !1, line: 49, type: !34)
!166 = !DILocation(line: 49, column: 3, scope: !135)
!167 = !DILocation(line: 50, column: 19, scope: !135)
!168 = !DILocation(line: 50, column: 41, scope: !135)
!169 = !DILocation(line: 50, column: 32, scope: !135)
!170 = !DILocation(line: 50, column: 13, scope: !135)
!171 = !DILocalVariable(name: "stored", scope: !135, file: !1, line: 50, type: !34)
!172 = !DILocation(line: 50, column: 3, scope: !135)
!173 = !DILocation(line: 51, column: 3, scope: !135)
!174 = !DILocation(line: 52, column: 15, scope: !135)
!175 = !DILocation(line: 53, column: 16, scope: !135)
!176 = distinct !DISubprogram(name: "aligned", linkageName: "topal.tail.component.topal.fn.aligned.53", scope: !1, file: !1, line: 55, type: !177, scopeLine: 55, spFlags: DISPFlagDefinition, unit: !0)
!177 = !DISubroutineType(types: !178)
!178 = !{!34, !9, !9}
!179 = !DILocation(line: 55, column: 1, scope: !176)
!180 = !DILocalVariable(name: "physical", arg: 1, scope: !176, file: !1, line: 55, type: !9)
!181 = !DILocation(line: 55, column: 17, scope: !176)
!182 = !DILocalVariable(name: "alignment", arg: 2, scope: !176, file: !1, line: 55, type: !9)
!183 = !DILocation(line: 55, column: 33, scope: !176)
!184 = !DILocation(line: 56, column: 3, scope: !176)
!185 = !DILocation(line: 57, column: 15, scope: !176)
!186 = !DILocation(line: 58, column: 17, scope: !176)
!187 = distinct !DISubprogram(name: "skip", linkageName: "topal.tail.component.topal.fn.skip.77", scope: !1, file: !1, line: 27, type: !100, scopeLine: 27, spFlags: DISPFlagDefinition, unit: !0)
!188 = !DILocation(line: 27, column: 1, scope: !187)
!189 = !DILocalVariable(name: "region", arg: 1, scope: !187, file: !1, line: 27, type: !16)
!190 = !DILocation(line: 27, column: 14, scope: !187)
!191 = !DILocalVariable(name: "cursor", arg: 2, scope: !187, file: !1, line: 27, type: !9)
!192 = !DILocation(line: 27, column: 41, scope: !187)
!193 = !DILocation(line: 28, column: 10, scope: !187)
!194 = !DILocalVariable(name: "run", scope: !187, file: !1, line: 28, type: !34)
!195 = !DILocation(line: 28, column: 3, scope: !187)
!196 = !DILocation(line: 29, column: 30, scope: !187)
!197 = !DILocation(line: 29, column: 11, scope: !187)
!198 = !DILocalVariable(name: "next", scope: !187, file: !1, line: 29, type: !34)
!199 = !DILocation(line: 29, column: 3, scope: !187)
!200 = !DILocation(line: 30, column: 3, scope: !187)
!201 = distinct !DISubprogram(name: "start-span", linkageName: "topal.tail.component.topal.fn.start_2dspan.78", scope: !1, file: !1, line: 60, type: !202, scopeLine: 60, spFlags: DISPFlagDefinition, unit: !0)
!202 = !DISubroutineType(types: !203)
!203 = !{!34, !16, !9, !9, !9}
!204 = !DILocation(line: 60, column: 1, scope: !201)
!205 = !DILocalVariable(name: "region", arg: 1, scope: !201, file: !1, line: 60, type: !16)
!206 = !DILocation(line: 60, column: 20, scope: !201)
!207 = !DILocalVariable(name: "cursor", arg: 2, scope: !201, file: !1, line: 60, type: !9)
!208 = !DILocation(line: 60, column: 47, scope: !201)
!209 = !DILocalVariable(name: "provenance", arg: 3, scope: !201, file: !1, line: 60, type: !9)
!210 = !DILocation(line: 60, column: 61, scope: !201)
!211 = !DILocalVariable(name: "physical", arg: 4, scope: !201, file: !1, line: 60, type: !9)
!212 = !DILocation(line: 60, column: 79, scope: !201)
!213 = !DILocation(line: 61, column: 23, scope: !201)
!214 = !DILocation(line: 61, column: 3, scope: !201)
!215 = !DILocation(line: 62, column: 15, scope: !201)
!216 = !DILocation(line: 63, column: 16, scope: !201)
!217 = distinct !DISubprogram(name: "free-cell", linkageName: "topal.tail.component.topal.fn.free_2dcell.79", scope: !1, file: !1, line: 65, type: !202, scopeLine: 65, spFlags: DISPFlagDefinition, unit: !0)
!218 = !DILocation(line: 65, column: 1, scope: !217)
!219 = !DILocalVariable(name: "region", arg: 1, scope: !217, file: !1, line: 65, type: !16)
!220 = !DILocation(line: 65, column: 19, scope: !217)
!221 = !DILocalVariable(name: "cursor", arg: 2, scope: !217, file: !1, line: 65, type: !9)
!222 = !DILocation(line: 65, column: 46, scope: !217)
!223 = !DILocalVariable(name: "provenance", arg: 3, scope: !217, file: !1, line: 65, type: !9)
!224 = !DILocation(line: 65, column: 60, scope: !217)
!225 = !DILocalVariable(name: "physical", arg: 4, scope: !217, file: !1, line: 65, type: !9)
!226 = !DILocation(line: 65, column: 78, scope: !217)
!227 = !DILocation(line: 66, column: 13, scope: !217)
!228 = !DILocalVariable(name: "length", scope: !217, file: !1, line: 66, type: !9)
!229 = !DILocation(line: 66, column: 3, scope: !217)
!230 = !DILocation(line: 67, column: 31, scope: !217)
!231 = !DILocation(line: 67, column: 17, scope: !217)
!232 = !DILocation(line: 67, column: 64, scope: !217)
!233 = !DILocation(line: 67, column: 51, scope: !217)
!234 = !DILocation(line: 67, column: 11, scope: !217)
!235 = !DILocalVariable(name: "same", scope: !217, file: !1, line: 67, type: !34)
!236 = !DILocation(line: 67, column: 3, scope: !217)
!237 = !DILocation(line: 68, column: 9, scope: !217)
!238 = !DILocation(line: 68, column: 3, scope: !217)
!239 = !DILocation(line: 69, column: 44, scope: !217)
!240 = !DILocation(line: 69, column: 63, scope: !217)
!241 = !DILocation(line: 69, column: 15, scope: !217)
!242 = !DILocation(line: 70, column: 16, scope: !217)
!243 = distinct !DISubprogram(name: "search-cell", linkageName: "topal.tail.component.topal.fn.search_2dcell.84", scope: !1, file: !1, line: 72, type: !100, scopeLine: 72, spFlags: DISPFlagDefinition, unit: !0)
!244 = !DILocation(line: 72, column: 1, scope: !243)
!245 = !DILocalVariable(name: "region", arg: 1, scope: !243, file: !1, line: 72, type: !16)
!246 = !DILocation(line: 72, column: 21, scope: !243)
!247 = !DILocalVariable(name: "cursor", arg: 2, scope: !243, file: !1, line: 72, type: !9)
!248 = !DILocation(line: 72, column: 48, scope: !243)
!249 = !DILocation(line: 73, column: 11, scope: !243)
!250 = !DILocalVariable(name: "base", scope: !243, file: !1, line: 73, type: !9)
!251 = !DILocation(line: 73, column: 3, scope: !243)
!252 = !DILocation(line: 74, column: 15, scope: !243)
!253 = !DILocalVariable(name: "identity", scope: !243, file: !1, line: 74, type: !9)
!254 = !DILocation(line: 74, column: 3, scope: !243)
!255 = !DILocation(line: 75, column: 31, scope: !243)
!256 = !DILocation(line: 75, column: 17, scope: !243)
!257 = !DILocalVariable(name: "provenance", scope: !243, file: !1, line: 75, type: !9)
!258 = !DILocation(line: 75, column: 3, scope: !243)
!259 = !DILocation(line: 76, column: 29, scope: !243)
!260 = !DILocation(line: 76, column: 15, scope: !243)
!261 = !DILocalVariable(name: "physical", scope: !243, file: !1, line: 76, type: !9)
!262 = !DILocation(line: 76, column: 3, scope: !243)
!263 = !DILocation(line: 77, column: 9, scope: !243)
!264 = !DILocation(line: 77, column: 23, scope: !243)
!265 = !DILocation(line: 77, column: 3, scope: !243)
!266 = !DILocation(line: 78, column: 15, scope: !243)
!267 = !DILocation(line: 79, column: 16, scope: !243)
!268 = distinct !DISubprogram(name: "complete", linkageName: "topal.tail.component.topal.fn.complete.88", scope: !1, file: !1, line: 22, type: !100, scopeLine: 22, spFlags: DISPFlagDefinition, unit: !0)
!269 = !DILocation(line: 22, column: 1, scope: !268)
!270 = !DILocalVariable(name: "region", arg: 1, scope: !268, file: !1, line: 22, type: !16)
!271 = !DILocation(line: 22, column: 18, scope: !268)
!272 = !DILocalVariable(name: "result", arg: 2, scope: !268, file: !1, line: 22, type: !9)
!273 = !DILocation(line: 22, column: 45, scope: !268)
!274 = !DILocation(line: 23, column: 12, scope: !268)
!275 = !DILocalVariable(name: "value", scope: !268, file: !1, line: 23, type: !34)
!276 = !DILocation(line: 23, column: 3, scope: !268)
!277 = !DILocation(line: 24, column: 12, scope: !268)
!278 = !DILocalVariable(name: "phase", scope: !268, file: !1, line: 24, type: !34)
!279 = !DILocation(line: 24, column: 3, scope: !268)
!280 = !DILocation(line: 25, column: 3, scope: !268)
!281 = distinct !DISubprogram(name: "search", linkageName: "topal.tail.component.topal.fn.search.89", scope: !1, file: !1, line: 81, type: !282, scopeLine: 81, spFlags: DISPFlagDefinition, unit: !0)
!282 = !DISubroutineType(types: !283)
!283 = !{!34, !16}
!284 = !DILocation(line: 81, column: 1, scope: !281)
!285 = !DILocalVariable(name: "region", arg: 1, scope: !281, file: !1, line: 81, type: !16)
!286 = !DILocation(line: 81, column: 15, scope: !281)
!287 = !DILocation(line: 82, column: 13, scope: !281)
!288 = !DILocalVariable(name: "cursor", scope: !281, file: !1, line: 82, type: !9)
!289 = !DILocation(line: 82, column: 3, scope: !281)
!290 = !DILocation(line: 83, column: 13, scope: !281)
!291 = !DILocation(line: 83, column: 3, scope: !281)
!292 = !DILocation(line: 84, column: 15, scope: !281)
!293 = !DILocation(line: 85, column: 16, scope: !281)
!294 = distinct !DISubprogram(name: "maybe-complete", linkageName: "topal.tail.component.topal.fn.maybe_2dcomplete.113", scope: !1, file: !1, line: 87, type: !100, scopeLine: 87, spFlags: DISPFlagDefinition, unit: !0)
!295 = !DILocation(line: 87, column: 1, scope: !294)
!296 = !DILocalVariable(name: "region", arg: 1, scope: !294, file: !1, line: 87, type: !16)
!297 = !DILocation(line: 87, column: 24, scope: !294)
!298 = !DILocalVariable(name: "processed", arg: 2, scope: !294, file: !1, line: 87, type: !9)
!299 = !DILocation(line: 87, column: 51, scope: !294)
!300 = !DILocation(line: 88, column: 16, scope: !294)
!301 = !DILocation(line: 88, column: 3, scope: !294)
!302 = !DILocation(line: 89, column: 33, scope: !294)
!303 = !DILocation(line: 89, column: 15, scope: !294)
!304 = !DILocation(line: 90, column: 16, scope: !294)
!305 = distinct !DISubprogram(name: "advance-commit", linkageName: "topal.tail.component.topal.fn.advance_2dcommit.114", scope: !1, file: !1, line: 92, type: !89, scopeLine: 92, spFlags: DISPFlagDefinition, unit: !0)
!306 = !DILocation(line: 92, column: 1, scope: !305)
!307 = !DILocalVariable(name: "region", arg: 1, scope: !305, file: !1, line: 92, type: !16)
!308 = !DILocation(line: 92, column: 24, scope: !305)
!309 = !DILocalVariable(name: "cursor", arg: 2, scope: !305, file: !1, line: 92, type: !9)
!310 = !DILocation(line: 92, column: 51, scope: !305)
!311 = !DILocalVariable(name: "processed", arg: 3, scope: !305, file: !1, line: 92, type: !9)
!312 = !DILocation(line: 92, column: 65, scope: !305)
!313 = !DILocation(line: 93, column: 30, scope: !305)
!314 = !DILocation(line: 93, column: 11, scope: !305)
!315 = !DILocalVariable(name: "next", scope: !305, file: !1, line: 93, type: !34)
!316 = !DILocation(line: 93, column: 3, scope: !305)
!317 = !DILocation(line: 94, column: 32, scope: !305)
!318 = !DILocation(line: 94, column: 13, scope: !305)
!319 = !DILocalVariable(name: "length", scope: !305, file: !1, line: 94, type: !34)
!320 = !DILocation(line: 94, column: 3, scope: !305)
!321 = !DILocation(line: 95, column: 3, scope: !305)
!322 = !DILocation(line: 96, column: 39, scope: !305)
!323 = !DILocation(line: 96, column: 15, scope: !305)
!324 = !DILocation(line: 97, column: 16, scope: !305)
!325 = distinct !DISubprogram(name: "commit-cell", linkageName: "topal.tail.component.topal.fn.commit_2dcell.115", scope: !1, file: !1, line: 99, type: !89, scopeLine: 99, spFlags: DISPFlagDefinition, unit: !0)
!326 = !DILocation(line: 99, column: 1, scope: !325)
!327 = !DILocalVariable(name: "region", arg: 1, scope: !325, file: !1, line: 99, type: !16)
!328 = !DILocation(line: 99, column: 21, scope: !325)
!329 = !DILocalVariable(name: "cursor", arg: 2, scope: !325, file: !1, line: 99, type: !9)
!330 = !DILocation(line: 99, column: 48, scope: !325)
!331 = !DILocalVariable(name: "identity", arg: 3, scope: !325, file: !1, line: 99, type: !9)
!332 = !DILocation(line: 99, column: 62, scope: !325)
!333 = !DILocation(line: 100, column: 18, scope: !325)
!334 = !DILocation(line: 100, column: 3, scope: !325)
!335 = !DILocation(line: 101, column: 47, scope: !325)
!336 = !DILocation(line: 101, column: 15, scope: !325)
!337 = !DILocation(line: 102, column: 16, scope: !325)
!338 = distinct !DISubprogram(name: "allocate-cell", linkageName: "topal.tail.component.topal.fn.allocate_2dcell.116", scope: !1, file: !1, line: 104, type: !100, scopeLine: 104, spFlags: DISPFlagDefinition, unit: !0)
!339 = !DILocation(line: 104, column: 1, scope: !338)
!340 = !DILocalVariable(name: "region", arg: 1, scope: !338, file: !1, line: 104, type: !16)
!341 = !DILocation(line: 104, column: 23, scope: !338)
!342 = !DILocalVariable(name: "cursor", arg: 2, scope: !338, file: !1, line: 104, type: !9)
!343 = !DILocation(line: 104, column: 50, scope: !338)
!344 = !DILocation(line: 105, column: 11, scope: !338)
!345 = !DILocalVariable(name: "base", scope: !338, file: !1, line: 105, type: !9)
!346 = !DILocation(line: 105, column: 3, scope: !338)
!347 = !DILocation(line: 106, column: 12, scope: !338)
!348 = !DILocalVariable(name: "free", scope: !338, file: !1, line: 106, type: !34)
!349 = !DILocation(line: 106, column: 3, scope: !338)
!350 = !DILocation(line: 107, column: 26, scope: !338)
!351 = !DILocation(line: 107, column: 12, scope: !338)
!352 = !DILocation(line: 107, column: 40, scope: !338)
!353 = !DILocalVariable(name: "same", scope: !338, file: !1, line: 107, type: !34)
!354 = !DILocation(line: 107, column: 3, scope: !338)
!355 = !DILocation(line: 108, column: 3, scope: !338)
!356 = !DILocation(line: 109, column: 44, scope: !338)
!357 = !DILocation(line: 109, column: 15, scope: !338)
!358 = !DILocation(line: 110, column: 16, scope: !338)
!359 = distinct !DISubprogram(name: "release-cell", linkageName: "topal.tail.component.topal.fn.release_2dcell.140", scope: !1, file: !1, line: 112, type: !100, scopeLine: 112, spFlags: DISPFlagDefinition, unit: !0)
!360 = !DILocation(line: 112, column: 1, scope: !359)
!361 = !DILocalVariable(name: "region", arg: 1, scope: !359, file: !1, line: 112, type: !16)
!362 = !DILocation(line: 112, column: 22, scope: !359)
!363 = !DILocalVariable(name: "cursor", arg: 2, scope: !359, file: !1, line: 112, type: !9)
!364 = !DILocation(line: 112, column: 49, scope: !359)
!365 = !DILocation(line: 113, column: 11, scope: !359)
!366 = !DILocalVariable(name: "base", scope: !359, file: !1, line: 113, type: !9)
!367 = !DILocation(line: 113, column: 3, scope: !359)
!368 = !DILocation(line: 114, column: 11, scope: !359)
!369 = !DILocation(line: 114, column: 35, scope: !359)
!370 = !DILocalVariable(name: "own", scope: !359, file: !1, line: 114, type: !34)
!371 = !DILocation(line: 114, column: 3, scope: !359)
!372 = !DILocation(line: 115, column: 32, scope: !359)
!373 = !DILocation(line: 115, column: 18, scope: !359)
!374 = !DILocation(line: 115, column: 46, scope: !359)
!375 = !DILocation(line: 115, column: 67, scope: !359)
!376 = !DILocation(line: 115, column: 11, scope: !359)
!377 = !DILocalVariable(name: "same", scope: !359, file: !1, line: 115, type: !34)
!378 = !DILocation(line: 115, column: 3, scope: !359)
!379 = !DILocation(line: 116, column: 3, scope: !359)
!380 = !DILocation(line: 117, column: 15, scope: !359)
!381 = !DILocation(line: 118, column: 16, scope: !359)
!382 = distinct !DISubprogram(name: "commit-selected", linkageName: "topal.tail.component.topal.fn.commit_2dselected.141", scope: !1, file: !1, line: 120, type: !383, scopeLine: 120, spFlags: DISPFlagDefinition, unit: !0)
!383 = !DISubroutineType(types: !384)
!384 = !{!34, !16, !9, !34}
!385 = !DILocation(line: 120, column: 1, scope: !382)
!386 = !DILocalVariable(name: "region", arg: 1, scope: !382, file: !1, line: 120, type: !16)
!387 = !DILocation(line: 120, column: 25, scope: !382)
!388 = !DILocalVariable(name: "cursor", arg: 2, scope: !382, file: !1, line: 120, type: !9)
!389 = !DILocation(line: 120, column: 52, scope: !382)
!390 = !DILocalVariable(name: "allocating", arg: 3, scope: !382, file: !1, line: 120, type: !34)
!391 = !DILocation(line: 120, column: 66, scope: !382)
!392 = !DILocation(line: 121, column: 3, scope: !382)
!393 = !DILocation(line: 122, column: 15, scope: !382)
!394 = !DILocation(line: 123, column: 16, scope: !382)
!395 = distinct !DISubprogram(name: "commit", linkageName: "topal.tail.component.topal.fn.commit.142", scope: !1, file: !1, line: 125, type: !396, scopeLine: 125, spFlags: DISPFlagDefinition, unit: !0)
!396 = !DISubroutineType(types: !397)
!397 = !{!34, !16, !34}
!398 = !DILocation(line: 125, column: 1, scope: !395)
!399 = !DILocalVariable(name: "region", arg: 1, scope: !395, file: !1, line: 125, type: !16)
!400 = !DILocation(line: 125, column: 16, scope: !395)
!401 = !DILocalVariable(name: "allocating", arg: 2, scope: !395, file: !1, line: 125, type: !34)
!402 = !DILocation(line: 125, column: 43, scope: !395)
!403 = !DILocation(line: 126, column: 13, scope: !395)
!404 = !DILocalVariable(name: "cursor", scope: !395, file: !1, line: 126, type: !9)
!405 = !DILocation(line: 126, column: 3, scope: !395)
!406 = !DILocation(line: 127, column: 28, scope: !395)
!407 = !DILocation(line: 127, column: 18, scope: !395)
!408 = !DILocation(line: 127, column: 48, scope: !395)
!409 = !DILocation(line: 127, column: 70, scope: !395)
!410 = !DILocation(line: 127, column: 12, scope: !395)
!411 = !DILocalVariable(name: "valid", scope: !395, file: !1, line: 127, type: !34)
!412 = !DILocation(line: 127, column: 3, scope: !395)
!413 = !DILocation(line: 128, column: 3, scope: !395)
!414 = !DILocation(line: 129, column: 15, scope: !395)
!415 = !DILocation(line: 130, column: 16, scope: !395)
!416 = distinct !DISubprogram(name: "begin-release", linkageName: "topal.tail.component.topal.fn.begin_2drelease.176", scope: !1, file: !1, line: 132, type: !282, scopeLine: 132, spFlags: DISPFlagDefinition, unit: !0)
!417 = !DILocation(line: 132, column: 1, scope: !416)
!418 = !DILocalVariable(name: "region", arg: 1, scope: !416, file: !1, line: 132, type: !16)
!419 = !DILocation(line: 132, column: 22, scope: !416)
!420 = !DILocation(line: 133, column: 12, scope: !416)
!421 = !DILocalVariable(name: "start", scope: !416, file: !1, line: 133, type: !9)
!422 = !DILocation(line: 133, column: 3, scope: !416)
!423 = !DILocation(line: 134, column: 13, scope: !416)
!424 = !DILocalVariable(name: "cursor", scope: !416, file: !1, line: 134, type: !34)
!425 = !DILocation(line: 134, column: 3, scope: !416)
!426 = !DILocation(line: 135, column: 13, scope: !416)
!427 = !DILocalVariable(name: "length", scope: !416, file: !1, line: 135, type: !34)
!428 = !DILocation(line: 135, column: 3, scope: !416)
!429 = !DILocation(line: 136, column: 32, scope: !416)
!430 = !DILocation(line: 136, column: 13, scope: !416)
!431 = !DILocalVariable(name: "result", scope: !416, file: !1, line: 136, type: !34)
!432 = !DILocation(line: 136, column: 3, scope: !416)
!433 = !DILocation(line: 137, column: 12, scope: !416)
!434 = !DILocalVariable(name: "phase", scope: !416, file: !1, line: 137, type: !34)
!435 = !DILocation(line: 137, column: 3, scope: !416)
!436 = !DILocation(line: 138, column: 9, scope: !416)
!437 = !DILocation(line: 138, column: 32, scope: !416)
!438 = !DILocation(line: 138, column: 3, scope: !416)
!439 = distinct !DISubprogram(name: "maybe-begin-release", linkageName: "topal.tail.component.topal.fn.maybe_2dbegin_2drelease.177", scope: !1, file: !1, line: 140, type: !100, scopeLine: 140, spFlags: DISPFlagDefinition, unit: !0)
!440 = !DILocation(line: 140, column: 1, scope: !439)
!441 = !DILocalVariable(name: "region", arg: 1, scope: !439, file: !1, line: 140, type: !16)
!442 = !DILocation(line: 140, column: 29, scope: !439)
!443 = !DILocalVariable(name: "processed", arg: 2, scope: !439, file: !1, line: 140, type: !9)
!444 = !DILocation(line: 140, column: 56, scope: !439)
!445 = !DILocation(line: 141, column: 16, scope: !439)
!446 = !DILocation(line: 141, column: 3, scope: !439)
!447 = !DILocation(line: 142, column: 15, scope: !439)
!448 = !DILocation(line: 143, column: 16, scope: !439)
!449 = distinct !DISubprogram(name: "validated-cell", linkageName: "topal.tail.component.topal.fn.validated_2dcell.178", scope: !1, file: !1, line: 145, type: !89, scopeLine: 145, spFlags: DISPFlagDefinition, unit: !0)
!450 = !DILocation(line: 145, column: 1, scope: !449)
!451 = !DILocalVariable(name: "region", arg: 1, scope: !449, file: !1, line: 145, type: !16)
!452 = !DILocation(line: 145, column: 24, scope: !449)
!453 = !DILocalVariable(name: "cursor", arg: 2, scope: !449, file: !1, line: 145, type: !9)
!454 = !DILocation(line: 145, column: 51, scope: !449)
!455 = !DILocalVariable(name: "physical", arg: 3, scope: !449, file: !1, line: 145, type: !9)
!456 = !DILocation(line: 145, column: 65, scope: !449)
!457 = !DILocation(line: 146, column: 16, scope: !449)
!458 = !DILocalVariable(name: "processed", scope: !449, file: !1, line: 146, type: !9)
!459 = !DILocation(line: 146, column: 3, scope: !449)
!460 = !DILocation(line: 147, column: 27, scope: !449)
!461 = !DILocation(line: 147, column: 8, scope: !449)
!462 = !DILocalVariable(name: "a", scope: !449, file: !1, line: 147, type: !34)
!463 = !DILocation(line: 147, column: 3, scope: !449)
!464 = !DILocation(line: 148, column: 27, scope: !449)
!465 = !DILocation(line: 148, column: 8, scope: !449)
!466 = !DILocalVariable(name: "b", scope: !449, file: !1, line: 148, type: !34)
!467 = !DILocation(line: 148, column: 3, scope: !449)
!468 = !DILocation(line: 149, column: 8, scope: !449)
!469 = !DILocalVariable(name: "c", scope: !449, file: !1, line: 149, type: !34)
!470 = !DILocation(line: 149, column: 3, scope: !449)
!471 = !DILocation(line: 150, column: 12, scope: !449)
!472 = !DILocation(line: 150, column: 3, scope: !449)
!473 = !DILocation(line: 151, column: 44, scope: !449)
!474 = !DILocation(line: 151, column: 15, scope: !449)
!475 = !DILocation(line: 152, column: 16, scope: !449)
!476 = distinct !DISubprogram(name: "validate-cell", linkageName: "topal.tail.component.topal.fn.validate_2dcell.179", scope: !1, file: !1, line: 154, type: !100, scopeLine: 154, spFlags: DISPFlagDefinition, unit: !0)
!477 = !DILocation(line: 154, column: 1, scope: !476)
!478 = !DILocalVariable(name: "region", arg: 1, scope: !476, file: !1, line: 154, type: !16)
!479 = !DILocation(line: 154, column: 23, scope: !476)
!480 = !DILocalVariable(name: "cursor", arg: 2, scope: !476, file: !1, line: 154, type: !9)
!481 = !DILocation(line: 154, column: 50, scope: !476)
!482 = !DILocation(line: 155, column: 11, scope: !476)
!483 = !DILocalVariable(name: "base", scope: !476, file: !1, line: 155, type: !9)
!484 = !DILocation(line: 155, column: 3, scope: !476)
!485 = !DILocation(line: 156, column: 11, scope: !476)
!486 = !DILocation(line: 156, column: 35, scope: !476)
!487 = !DILocalVariable(name: "own", scope: !476, file: !1, line: 156, type: !34)
!488 = !DILocation(line: 156, column: 3, scope: !476)
!489 = !DILocation(line: 157, column: 26, scope: !476)
!490 = !DILocation(line: 157, column: 12, scope: !476)
!491 = !DILocation(line: 157, column: 40, scope: !476)
!492 = !DILocalVariable(name: "same", scope: !476, file: !1, line: 157, type: !34)
!493 = !DILocation(line: 157, column: 3, scope: !476)
!494 = !DILocation(line: 158, column: 29, scope: !476)
!495 = !DILocation(line: 158, column: 15, scope: !476)
!496 = !DILocalVariable(name: "physical", scope: !476, file: !1, line: 158, type: !9)
!497 = !DILocation(line: 158, column: 3, scope: !476)
!498 = !DILocation(line: 159, column: 13, scope: !476)
!499 = !DILocalVariable(name: "first", scope: !476, file: !1, line: 159, type: !34)
!500 = !DILocation(line: 159, column: 3, scope: !476)
!501 = !DILocation(line: 160, column: 30, scope: !476)
!502 = !DILocation(line: 160, column: 17, scope: !476)
!503 = !DILocalVariable(name: "contiguous", scope: !476, file: !1, line: 160, type: !34)
!504 = !DILocation(line: 160, column: 3, scope: !476)
!505 = !DILocation(line: 161, column: 18, scope: !476)
!506 = !DILocation(line: 161, column: 47, scope: !476)
!507 = !DILocation(line: 161, column: 58, scope: !476)
!508 = !DILocation(line: 161, column: 41, scope: !476)
!509 = !DILocation(line: 161, column: 36, scope: !476)
!510 = !DILocation(line: 161, column: 12, scope: !476)
!511 = !DILocalVariable(name: "valid", scope: !476, file: !1, line: 161, type: !34)
!512 = !DILocation(line: 161, column: 3, scope: !476)
!513 = !DILocation(line: 162, column: 3, scope: !476)
!514 = !DILocation(line: 163, column: 15, scope: !476)
!515 = !DILocation(line: 164, column: 16, scope: !476)
!516 = distinct !DISubprogram(name: "validate-release", linkageName: "topal.tail.component.topal.fn.validate_2drelease.180", scope: !1, file: !1, line: 166, type: !282, scopeLine: 166, spFlags: DISPFlagDefinition, unit: !0)
!517 = !DILocation(line: 166, column: 1, scope: !516)
!518 = !DILocalVariable(name: "region", arg: 1, scope: !516, file: !1, line: 166, type: !16)
!519 = !DILocation(line: 166, column: 25, scope: !516)
!520 = !DILocation(line: 167, column: 13, scope: !516)
!521 = !DILocalVariable(name: "cursor", scope: !516, file: !1, line: 167, type: !9)
!522 = !DILocation(line: 167, column: 3, scope: !516)
!523 = !DILocation(line: 168, column: 31, scope: !516)
!524 = !DILocation(line: 168, column: 21, scope: !516)
!525 = !DILocation(line: 168, column: 51, scope: !516)
!526 = !DILocation(line: 168, column: 73, scope: !516)
!527 = !DILocation(line: 168, column: 15, scope: !516)
!528 = !DILocalVariable(name: "interval", scope: !516, file: !1, line: 168, type: !34)
!529 = !DILocation(line: 168, column: 3, scope: !516)
!530 = !DILocation(line: 169, column: 29, scope: !516)
!531 = !DILocation(line: 169, column: 12, scope: !516)
!532 = !DILocalVariable(name: "valid", scope: !516, file: !1, line: 169, type: !34)
!533 = !DILocation(line: 169, column: 3, scope: !516)
!534 = !DILocation(line: 170, column: 3, scope: !516)
!535 = !DILocation(line: 171, column: 15, scope: !516)
!536 = !DILocation(line: 172, column: 16, scope: !516)
!537 = distinct !DISubprogram(name: "phase-step", linkageName: "topal.tail.component.topal.fn.phase_2dstep.234", scope: !1, file: !1, line: 174, type: !100, scopeLine: 174, spFlags: DISPFlagDefinition, unit: !0)
!538 = !DILocation(line: 174, column: 1, scope: !537)
!539 = !DILocalVariable(name: "region", arg: 1, scope: !537, file: !1, line: 174, type: !16)
!540 = !DILocation(line: 174, column: 20, scope: !537)
!541 = !DILocalVariable(name: "phase", arg: 2, scope: !537, file: !1, line: 174, type: !9)
!542 = !DILocation(line: 174, column: 47, scope: !537)
!543 = !DILocation(line: 176, column: 5, scope: !537)
!544 = !DILocation(line: 176, column: 15, scope: !537)
!545 = !DILocation(line: 177, column: 5, scope: !537)
!546 = !DILocation(line: 177, column: 15, scope: !537)
!547 = !DILocation(line: 178, column: 5, scope: !537)
!548 = !DILocation(line: 178, column: 15, scope: !537)
!549 = !DILocation(line: 179, column: 5, scope: !537)
!550 = !DILocation(line: 179, column: 15, scope: !537)
!551 = !DILocation(line: 180, column: 5, scope: !537)
!552 = !DILocation(line: 181, column: 15, scope: !537)
!553 = !DILocation(line: 175, column: 3, scope: !537)
!554 = distinct !DISubprogram(name: "step", linkageName: "topal.tail.component.topal.fn.step.235", scope: !1, file: !1, line: 183, type: !282, scopeLine: 183, spFlags: DISPFlagDefinition, unit: !0)
!555 = !DILocation(line: 183, column: 1, scope: !554)
!556 = !DILocalVariable(name: "region", arg: 1, scope: !554, file: !1, line: 183, type: !16)
!557 = !DILocation(line: 183, column: 13, scope: !554)
!558 = !DILocation(line: 184, column: 11, scope: !554)
!559 = !DILocalVariable(name: "size", scope: !554, file: !1, line: 184, type: !9)
!560 = !DILocation(line: 184, column: 3, scope: !554)
!561 = !DILocation(line: 185, column: 12, scope: !554)
!562 = !DILocalVariable(name: "cells", scope: !554, file: !1, line: 185, type: !9)
!563 = !DILocation(line: 185, column: 3, scope: !554)
!564 = !DILocation(line: 186, column: 12, scope: !554)
!565 = !DILocalVariable(name: "count", scope: !554, file: !1, line: 186, type: !9)
!566 = !DILocation(line: 186, column: 3, scope: !554)
!567 = !DILocation(line: 187, column: 15, scope: !554)
!568 = !DILocalVariable(name: "identity", scope: !554, file: !1, line: 187, type: !9)
!569 = !DILocation(line: 187, column: 3, scope: !554)
!570 = !DILocation(line: 188, column: 37, scope: !554)
!571 = !DILocation(line: 188, column: 30, scope: !554)
!572 = !DILocation(line: 188, column: 21, scope: !554)
!573 = !DILocation(line: 188, column: 51, scope: !554)
!574 = !DILocation(line: 188, column: 15, scope: !554)
!575 = !DILocalVariable(name: "geometry", scope: !554, file: !1, line: 188, type: !34)
!576 = !DILocation(line: 188, column: 3, scope: !554)
!577 = !DILocation(line: 189, column: 21, scope: !554)
!578 = !DILocation(line: 189, column: 35, scope: !554)
!579 = !DILocation(line: 189, column: 15, scope: !554)
!580 = !DILocalVariable(name: "issuance", scope: !554, file: !1, line: 189, type: !34)
!581 = !DILocation(line: 189, column: 3, scope: !554)
!582 = !DILocation(line: 190, column: 3, scope: !554)
!583 = !DILocation(line: 191, column: 35, scope: !554)
!584 = !DILocation(line: 191, column: 15, scope: !554)
!585 = !DILocation(line: 192, column: 16, scope: !554)
!586 = distinct !DISubprogram(name: "step-status", linkageName: "topal.tail.component.topal.fn.step_2dstatus.460", scope: !1, file: !1, line: 194, type: !587, scopeLine: 194, spFlags: DISPFlagDefinition, unit: !0)
!587 = !DISubroutineType(types: !588)
!588 = !{!9, !16}
!589 = !DILocation(line: 194, column: 1, scope: !586)
!590 = !DILocalVariable(name: "region", arg: 1, scope: !586, file: !1, line: 194, type: !16)
!591 = !DILocation(line: 194, column: 20, scope: !586)
!592 = !DILocalVariable(name: "zero", scope: !586, file: !1, line: 195, type: !9)
!593 = !DILocation(line: 195, column: 3, scope: !586)
!594 = !DILocalVariable(name: "invalid", scope: !586, file: !1, line: 196, type: !9)
!595 = !DILocation(line: 196, column: 3, scope: !586)
!596 = !DILocation(line: 197, column: 3, scope: !586)
!597 = !DILocation(line: 198, column: 15, scope: !586)
!598 = !DILocation(line: 199, column: 16, scope: !586)
!599 = distinct !DISubprogram(name: "next-status", linkageName: "topal.tail.component.topal.fn.next_2dstatus.461", scope: !1, file: !1, line: 201, type: !7, scopeLine: 201, spFlags: DISPFlagDefinition, unit: !0)
!600 = !DILocation(line: 201, column: 1, scope: !599)
!601 = !DILocalVariable(name: "region", arg: 1, scope: !599, file: !1, line: 201, type: !16)
!602 = !DILocation(line: 201, column: 21, scope: !599)
!603 = !DILocalVariable(name: "status", arg: 2, scope: !599, file: !1, line: 201, type: !9)
!604 = !DILocation(line: 201, column: 48, scope: !599)
!605 = !DILocalVariable(name: "invalid", scope: !599, file: !1, line: 202, type: !9)
!606 = !DILocation(line: 202, column: 3, scope: !599)
!607 = !DILocation(line: 203, column: 3, scope: !599)
!608 = !DILocation(line: 204, column: 15, scope: !599)
!609 = !DILocation(line: 205, column: 16, scope: !599)
!610 = distinct !DISubprogram(name: "frame-policy [tail step]", linkageName: "topal_tail_step_component_v1", scope: !1, file: !1, line: 221, type: !611, scopeLine: 221, spFlags: DISPFlagDefinition, unit: !0)
!611 = !DISubroutineType(types: !612)
!612 = !{null, !16, !9, !9, !9}
!613 = !DILocation(line: 221, column: 5, scope: !610)
!614 = !DILocation(line: 221, column: 26, scope: !610)
!615 = !DILocalVariable(name: "region", arg: 1, scope: !610, file: !1, line: 221, type: !16)
!616 = !DILocation(line: 221, column: 53, scope: !610)
!617 = !DILocalVariable(name: "remaining", arg: 2, scope: !610, file: !1, line: 221, type: !9)
!618 = !DILocation(line: 221, column: 70, scope: !610)
!619 = !DILocalVariable(name: "stop", arg: 3, scope: !610, file: !1, line: 221, type: !9)
!620 = !DILocation(line: 221, column: 82, scope: !610)
!621 = !DILocalVariable(name: "status", arg: 4, scope: !610, file: !1, line: 221, type: !9)
!622 = !DILocation(line: 223, column: 5, scope: !610)
!623 = !DILocation(line: 223, column: 15, scope: !610)
!624 = !DILocation(line: 224, column: 5, scope: !610)
!625 = !DILocation(line: 224, column: 18, scope: !610)
!626 = !DILocation(line: 225, column: 37, scope: !610)
!627 = !DILocation(line: 225, column: 52, scope: !610)
!628 = !DILocation(line: 225, column: 92, scope: !610)
!629 = !DILocation(line: 225, column: 15, scope: !610)
