; checked Topal numeric kernel library
source_filename = "structured-process-identity.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

@llvm.used = appending global [1 x ptr] [ptr @topal.pid.memset], section "llvm.metadata"
; Shared private topal-native/6 value algorithms.
; Platform allocation, write and termination hooks are supplied separately.
; Int values are immutable sign-and-magnitude objects with little-endian
; base-2^32 limbs. A zero has sign = 0 and length = 0. Root-local exact
; infinities use executable-private sign tags 2 (+) and 3 (-) with no limbs;
; Rational infinities wrap one sentinel over denominator one at run time. Those
; values are not admitted at a native function or library boundary.

%topal.StringStorage = type { ptr, i64, ptr, i64 }
%topal.IntStorage = type { i64, i64, [0 x i32] }

define internal ptr @topal.pid.runtime.character.ascii.decimal.digit(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %single.byte = icmp eq i64 %length, 1
  br i1 %single.byte, label %load, label %none
load:
  %data.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 0
  %data = load ptr, ptr %data.pointer, align 8
  %byte = load i8, ptr %data, align 1
  %at.least.zero = icmp uge i8 %byte, 48
  %at.most.nine = icmp ule i8 %byte, 57
  %is.digit = and i1 %at.least.zero, %at.most.nine
  br i1 %is.digit, label %some, label %none
some:
  %digit.byte = sub i8 %byte, 48
  %digit = zext i8 %digit.byte to i64
  %value = call ptr @topal.pid.runtime.int.from.u64(i64 %digit)
  %present = call ptr @topal.pid.runtime.optional.some(ptr %value)
  ret ptr %present
none:
  %absent = call ptr @topal.pid.runtime.optional.none()
  ret ptr %absent
}

define internal i1 @topal.pid.runtime.character.unicode.whitespace(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.pid.runtime.string.unicode.scalar.value(ptr %character)
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp eq i64 %length, 1
  br i1 %present, label %load, label %not.whitespace
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %scalar = load i32, ptr %limb.pointer, align 4
  %ascii.lower = icmp uge i32 %scalar, 9
  %ascii.upper = icmp ule i32 %scalar, 13
  %ascii.control = and i1 %ascii.lower, %ascii.upper
  %space = icmp eq i32 %scalar, 32
  %next.line = icmp eq i32 %scalar, 133
  %no.break = icmp eq i32 %scalar, 160
  %ogham = icmp eq i32 %scalar, 5760
  %quad.lower = icmp uge i32 %scalar, 8192
  %quad.upper = icmp ule i32 %scalar, 8202
  %quad = and i1 %quad.lower, %quad.upper
  %line.separator = icmp eq i32 %scalar, 8232
  %paragraph.separator = icmp eq i32 %scalar, 8233
  %narrow.no.break = icmp eq i32 %scalar, 8239
  %medium.math = icmp eq i32 %scalar, 8287
  %ideographic = icmp eq i32 %scalar, 12288
  %match.0 = or i1 %ascii.control, %space
  %match.1 = or i1 %match.0, %next.line
  %match.2 = or i1 %match.1, %no.break
  %match.3 = or i1 %match.2, %ogham
  %match.4 = or i1 %match.3, %quad
  %match.5 = or i1 %match.4, %line.separator
  %match.6 = or i1 %match.5, %paragraph.separator
  %match.7 = or i1 %match.6, %narrow.no.break
  %match.8 = or i1 %match.7, %medium.math
  %match.9 = or i1 %match.8, %ideographic
  ret i1 %match.9
not.whitespace:
  ret i1 false
}
%topal.IntDivmod = type { ptr, ptr }
%topal.RationalStorage = type { ptr, ptr }
%topal.RangeStorage = type { ptr, ptr, i64, i64 }
%topal.ResultStorage = type { i64, ptr }
%topal.OptionalStorage = type { i64, ptr }
%topal.ErrorStorage = type { ptr, i32, i32, ptr, ptr, ptr, i64, i64 }
%topal.SourceLocationStorage = type { ptr, ptr }
%topal.SerializationStreamStorage = type { ptr, i64 }
%topal.TaskStorage = type { i64, i64, ptr }
%topal.LocationStorage = type { ptr, ptr, i64, ptr }

@topal.pid.runtime.int.zero = private constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.pid.runtime.int.one = private constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.pid.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.pid.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.pid.runtime.byte.zero = private constant [1 x i8] c"0", align 1
@topal.pid.runtime.byte.minus = private constant [1 x i8] c"-", align 1
@topal.pid.runtime.int.positive.infinity.text = private constant [9 x i8] c"+Infinity", align 1
@topal.pid.runtime.int.negative.infinity.text = private constant [9 x i8] c"-Infinity", align 1
@topal.pid.runtime.byte.quote = private constant [1 x i8] c"\22", align 1
@topal.pid.runtime.byte.underscore = private constant [1 x i8] c"_", align 1
@topal.pid.runtime.string.tag.text = private constant [4 x i8] c"text", align 1
@topal.pid.runtime.rational.prefix = private constant [11 x i8] c"Rational ( ", align 1
@topal.pid.runtime.rational.separator = private constant [2 x i8] c", ", align 1
@topal.pid.runtime.rational.suffix = private constant [2 x i8] c" )", align 1
@topal.pid.runtime.range.closed.open = private constant [4 x i8] c" .. ", align 1
@topal.pid.runtime.range.open.open = private constant [5 x i8] c" <.. ", align 1
@topal.pid.runtime.range.closed.closed = private constant [5 x i8] c" ..= ", align 1
@topal.pid.runtime.range.open.closed = private constant [6 x i8] c" <..= ", align 1
@topal.pid.runtime.error.prefix = private constant [18 x i8] c"Error ( domain is ", align 1
@topal.pid.runtime.error.code.separator = private constant [10 x i8] c", code is ", align 1
@topal.pid.runtime.error.suffix = private constant [2 x i8] c" )", align 1
@topal.pid.runtime.error.code.out.of.range = private constant [12 x i8] c"out-of-range", align 1
@topal.pid.runtime.error.code.not.representable = private constant [17 x i8] c"not-representable", align 1
@topal.pid.runtime.error.code.division.by.zero = private constant [16 x i8] c"division-by-zero", align 1
@topal.pid.runtime.error.code.indeterminate = private constant [13 x i8] c"indeterminate", align 1
@topal.pid.runtime.pattern.identity.diagnostic = private constant [68 x i8] c"error[E-ANONYMOUS-PATTERN-IDENTITY]: repeated pattern values differ\0A", align 1
@topal.pid.runtime.c.int32.range.diagnostic = private constant [71 x i8] c"error[E-C-ABI-RANGE]: Topal Int is not representable as a C signed int\0A", align 1
@topal.pid.runtime.task.next.identity = private global i64 1, align 8

declare i32 @llvm.ctlz.i32(i32, i1 immarg)
declare void @llvm.memcpy.inline.p0.p0.i64(ptr, ptr, i64, i1 immarg)

; Optimized freestanding code can lower a recognized fill loop to the standard
; LLVM memset libcall. Supply that ABI locally so no C runtime is introduced.
define internal ptr @topal.pid.memset(ptr %destination, i32 %value, i64 %length) nounwind noinline optnone noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill
fill:
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill
complete:
  ret ptr %destination
}



define internal void @topal.pid.runtime.pattern.identity.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.pid.platform.write(i64 2, ptr @topal.pid.runtime.pattern.identity.diagnostic, i64 68)
  call void @topal.pid.platform.exit(i64 65)
  unreachable
}

define internal void @topal.pid.runtime.c.int32.range.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.pid.platform.write(i64 2, ptr @topal.pid.runtime.c.int32.range.diagnostic, i64 71)
  call void @topal.pid.platform.exit(i64 65)
  unreachable
}


; Closed direct tasks run on the deterministic root scheduler. Each instance
; still owns distinct identity, lifecycle state, and private semantic state.
define internal ptr @topal.pid.runtime.task.make(ptr %initial) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %task = call ptr @topal.pid.platform.allocate(i64 24)
  %identity = load i64, ptr @topal.pid.runtime.task.next.identity, align 8
  %next.identity = add i64 %identity, 1
  store i64 %next.identity, ptr @topal.pid.runtime.task.next.identity, align 8
  %identity.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 0
  %terminated.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 1
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store i64 %identity, ptr %identity.pointer, align 8
  store i64 0, ptr %terminated.pointer, align 8
  store ptr %initial, ptr %state.pointer, align 8
  ret ptr %task
}

define internal ptr @topal.pid.runtime.task.state.load(ptr %task) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  %state = load ptr, ptr %state.pointer, align 8
  ret ptr %state
}

define internal void @topal.pid.runtime.task.state.replace(ptr %task, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store ptr %value, ptr %state.pointer, align 8
  ret void
}

; A source-only location without a granted device adapter is backed by private
; Topal storage. The semantic range start and offset remain available for
; debugging, while every read and write remains an ordered runtime call.
define internal ptr @topal.pid.runtime.location.make(ptr %range.start, ptr %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %location = call ptr @topal.pid.platform.allocate(i64 32)
  %range.start.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 0
  %offset.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 1
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %range.start, ptr %range.start.pointer, align 8
  store ptr %offset, ptr %offset.pointer, align 8
  store i64 0, ptr %initialized.pointer, align 8
  store ptr null, ptr %value.pointer, align 8
  ret ptr %location
}

define internal void @topal.pid.runtime.location.write(ptr %location, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %value, ptr %value.pointer, align 8
  store i64 1, ptr %initialized.pointer, align 8
  ret void
}

define internal ptr @topal.pid.runtime.location.read(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %initialized = load i64, ptr %initialized.pointer, align 8
  %valid = icmp eq i64 %initialized, 1
  br i1 %valid, label %load, label %failure
load:
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  %value = load ptr, ptr %value.pointer, align 8
  %non.null = icmp ne ptr %value, null
  br i1 %non.null, label %success, label %failure
success:
  ret ptr %value
failure:
  call void @topal.pid.platform.exit(i64 74)
  unreachable
}

define internal ptr @topal.pid.runtime.serialization.make(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream = call ptr @topal.pid.platform.allocate(i64 16)
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %publish.empty, label %copy.start
copy.start:
  %copy = call ptr @topal.pid.platform.allocate(i64 %length)
  br label %copy.loop
copy.loop:
  %index = phi i64 [ 0, %copy.start ], [ %next, %copy.loop ]
  %source.pointer = getelementptr i8, ptr %data, i64 %index
  %target.pointer = getelementptr i8, ptr %copy, i64 %index
  %byte = load i8, ptr %source.pointer, align 1
  store i8 %byte, ptr %target.pointer, align 1
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %publish.copy, label %copy.loop
publish.copy:
  store ptr %copy, ptr %data.pointer, align 8
  br label %publish.length
publish.empty:
  store ptr null, ptr %data.pointer, align 8
  br label %publish.length
publish.length:
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %stream
}

define internal void @topal.pid.runtime.serialization.verify(ptr %stream, ptr %expected, i64 %expected.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream.valid = icmp ne ptr %stream, null
  br i1 %stream.valid, label %load, label %failure
load:
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %length.matches = icmp eq i64 %length, %expected.length
  br i1 %length.matches, label %check.empty, label %failure
check.empty:
  %empty = icmp eq i64 %expected.length, 0
  br i1 %empty, label %done, label %check.pointers
check.pointers:
  %data.valid = icmp ne ptr %data, null
  %expected.valid = icmp ne ptr %expected, null
  %pointers.valid = and i1 %data.valid, %expected.valid
  br i1 %pointers.valid, label %loop, label %failure
loop:
  %index = phi i64 [ 0, %check.pointers ], [ %next, %advance ]
  %actual.pointer = getelementptr i8, ptr %data, i64 %index
  %expected.pointer = getelementptr i8, ptr %expected, i64 %index
  %actual.byte = load i8, ptr %actual.pointer, align 1
  %expected.byte = load i8, ptr %expected.pointer, align 1
  %matches = icmp eq i8 %actual.byte, %expected.byte
  br i1 %matches, label %advance, label %failure
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %expected.length
  br i1 %complete, label %done, label %loop
failure:
  call void @topal.pid.platform.exit(i64 70)
  unreachable
done:
  ret void
}

define internal void @topal.pid.platform.write_all(ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %done, label %loop
loop:
  %offset = phi i64 [0, %entry], [%next, %progress], [%offset, %retry]
  %remaining = sub i64 %length, %offset
  %cursor = getelementptr i8, ptr %buffer, i64 %offset
  %written = call i64 @topal.pid.platform.write(i64 1, ptr %cursor, i64 %remaining)
  %positive = icmp sgt i64 %written, 0
  br i1 %positive, label %progress, label %error
progress:
  %next = add i64 %offset, %written
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %done, label %loop
error:
  %interrupted = icmp eq i64 %written, -4
  br i1 %interrupted, label %retry, label %failure
retry:
  br label %loop
failure:
  call void @topal.pid.platform.exit(i64 74)
  unreachable
done:
  ret void
}

define internal void @topal.pid.runtime.u64.print(i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %buffer = alloca [20 x i8], align 1
  %zero = icmp eq i64 %value, 0
  br i1 %zero, label %write.zero, label %convert
write.zero:
  %zero.pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 19
  store i8 48, ptr %zero.pointer, align 1
  call void @topal.pid.platform.write_all(ptr %zero.pointer, i64 1)
  ret void
convert:
  %remaining = phi i64 [ %value, %entry ], [ %quotient, %convert ]
  %position = phi i64 [ 20, %entry ], [ %next.position, %convert ]
  %digit = urem i64 %remaining, 10
  %quotient = udiv i64 %remaining, 10
  %next.position = sub i64 %position, 1
  %pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 %next.position
  %digit.byte = trunc i64 %digit to i8
  %ascii = add i8 %digit.byte, 48
  store i8 %ascii, ptr %pointer, align 1
  %complete = icmp eq i64 %quotient, 0
  br i1 %complete, label %write, label %convert
write:
  %length = sub i64 20, %next.position
  call void @topal.pid.platform.write_all(ptr %pointer, i64 %length)
  ret void
}

define internal ptr @topal.pid.runtime.string.make(ptr %data, i64 %length, ptr %display, i64 %display.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %string = call ptr @topal.pid.platform.allocate(i64 32)
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  store ptr %data, ptr %data.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  store ptr %display, ptr %display.pointer, align 8
  store i64 %display.length, ptr %display.length.pointer, align 8
  ret ptr %string
}

define internal void @topal.pid.runtime.string.raw.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  call void @topal.pid.platform.write_all(ptr %data, i64 %length)
  ret void
}

define internal void @topal.pid.runtime.string.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  %display = load ptr, ptr %display.pointer, align 8
  %display.length = load i64, ptr %display.length.pointer, align 8
  %cached = icmp ne ptr %display, null
  br i1 %cached, label %write.cached, label %write.dynamic
write.cached:
  call void @topal.pid.platform.write_all(ptr %display, i64 %display.length)
  ret void
write.dynamic:
  call void @topal.pid.runtime.string.dynamic.print(ptr %string)
  ret void
}

define internal i1 @topal.pid.runtime.string.contains.quote(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %not.found, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %pointer = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %pointer, align 1
  %quote = icmp eq i8 %byte, 34
  br i1 %quote, label %found, label %advance
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %not.found, label %loop
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal i1 @topal.pid.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %minimum = add i64 %underscores, 5
  %possible = icmp ule i64 %minimum, %length
  br i1 %possible, label %search, label %not.found
search:
  %position = phi i64 [ 0, %entry ], [ %next.position, %advance ]
  %remaining = sub i64 %length, %position
  %enough = icmp uge i64 %remaining, %minimum
  br i1 %enough, label %check.base, label %not.found
check.base:
  %quote.pointer = getelementptr i8, ptr %data, i64 %position
  %quote = load i8, ptr %quote.pointer, align 1
  %offset.t0 = add i64 %position, 1
  %offset.e = add i64 %position, 2
  %offset.x = add i64 %position, 3
  %offset.t1 = add i64 %position, 4
  %pointer.t0 = getelementptr i8, ptr %data, i64 %offset.t0
  %pointer.e = getelementptr i8, ptr %data, i64 %offset.e
  %pointer.x = getelementptr i8, ptr %data, i64 %offset.x
  %pointer.t1 = getelementptr i8, ptr %data, i64 %offset.t1
  %byte.t0 = load i8, ptr %pointer.t0, align 1
  %byte.e = load i8, ptr %pointer.e, align 1
  %byte.x = load i8, ptr %pointer.x, align 1
  %byte.t1 = load i8, ptr %pointer.t1, align 1
  %match.quote = icmp eq i8 %quote, 34
  %match.t0 = icmp eq i8 %byte.t0, 116
  %match.e = icmp eq i8 %byte.e, 101
  %match.x = icmp eq i8 %byte.x, 120
  %match.t1 = icmp eq i8 %byte.t1, 116
  %match.0 = and i1 %match.quote, %match.t0
  %match.1 = and i1 %match.0, %match.e
  %match.2 = and i1 %match.1, %match.x
  %match.base = and i1 %match.2, %match.t1
  br i1 %match.base, label %check.underscores, label %advance
check.underscores:
  %underscore.index = phi i64 [ 0, %check.base ], [ %next.underscore, %underscore.advance ]
  %underscores.complete = icmp eq i64 %underscore.index, %underscores
  br i1 %underscores.complete, label %found, label %check.underscore
check.underscore:
  %underscore.offset.base = add i64 %position, 5
  %underscore.offset = add i64 %underscore.offset.base, %underscore.index
  %underscore.pointer = getelementptr i8, ptr %data, i64 %underscore.offset
  %underscore.byte = load i8, ptr %underscore.pointer, align 1
  %match.underscore = icmp eq i8 %underscore.byte, 95
  br i1 %match.underscore, label %underscore.advance, label %advance
underscore.advance:
  %next.underscore = add i64 %underscore.index, 1
  br label %check.underscores
advance:
  %next.position = add i64 %position, 1
  br label %search
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal void @topal.pid.runtime.string.write.underscores(i64 %count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %done, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.byte.underscore, i64 1)
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %count
  br i1 %complete, label %done, label %loop
done:
  ret void
}

define internal void @topal.pid.runtime.string.dynamic.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %contains.quote = call i1 @topal.pid.runtime.string.contains.quote(ptr %data, i64 %length)
  br i1 %contains.quote, label %select.tag, label %plain
plain:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.byte.quote, i64 1)
  call void @topal.pid.platform.write_all(ptr %data, i64 %length)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.byte.quote, i64 1)
  ret void
select.tag:
  %underscores = phi i64 [ 0, %entry ], [ %next.underscores, %collision ]
  %collides = call i1 @topal.pid.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores)
  br i1 %collides, label %collision, label %tagged
collision:
  %next.underscores = add i64 %underscores, 1
  br label %select.tag
tagged:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.string.tag.text, i64 4)
  call void @topal.pid.runtime.string.write.underscores(i64 %underscores)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.byte.quote, i64 1)
  call void @topal.pid.platform.write_all(ptr %data, i64 %length)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.byte.quote, i64 1)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.string.tag.text, i64 4)
  call void @topal.pid.runtime.string.write.underscores(i64 %underscores)
  ret void
}

define internal ptr @topal.pid.runtime.string.concat(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %length = add i64 %left.length, %right.length
  %valid = icmp uge i64 %length, %left.length
  br i1 %valid, label %allocate, label %failure
failure:
  call void @topal.pid.platform.exit(i64 71)
  unreachable
allocate:
  %empty = icmp eq i64 %length, 0
  %allocation.length = select i1 %empty, i64 1, i64 %length
  %data = call ptr @topal.pid.platform.allocate(i64 %allocation.length)
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %data, ptr %left.data, i64 %left.length, i1 false)
  %right.destination = getelementptr i8, ptr %data, i64 %left.length
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %right.destination, ptr %right.data, i64 %right.length, i1 false)
  %result = call ptr @topal.pid.runtime.string.make(ptr %data, i64 %length, ptr null, i64 0)
  ret ptr %result
}

define internal i1 @topal.pid.runtime.string.is.empty(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  ret i1 %empty
}

define internal ptr @topal.pid.runtime.string.utf8.byte.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %count = call ptr @topal.pid.runtime.int.from.u64(i64 %length)
  ret ptr %count
}

define internal ptr @topal.pid.runtime.string.unicode.scalar.value(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  switch i64 %length, label %invalid [
    i64 1, label %one
    i64 2, label %two
    i64 3, label %three
    i64 4, label %four
  ]
one:
  %one.byte = load i8, ptr %data, align 1
  %one.ascii = icmp ult i8 %one.byte, -128
  br i1 %one.ascii, label %one.valid, label %invalid
one.valid:
  %one.value = zext i8 %one.byte to i64
  br label %complete
two:
  %two.byte.0 = load i8, ptr %data, align 1
  %two.pointer.1 = getelementptr i8, ptr %data, i64 1
  %two.byte.1 = load i8, ptr %two.pointer.1, align 1
  %two.lead = and i8 %two.byte.0, -32
  %two.lead.valid = icmp eq i8 %two.lead, -64
  %two.continuation = and i8 %two.byte.1, -64
  %two.continuation.valid = icmp eq i8 %two.continuation, -128
  %two.valid = and i1 %two.lead.valid, %two.continuation.valid
  br i1 %two.valid, label %two.decode, label %invalid
two.decode:
  %two.head.masked = and i8 %two.byte.0, 31
  %two.tail.masked = and i8 %two.byte.1, 63
  %two.head = zext i8 %two.head.masked to i64
  %two.tail = zext i8 %two.tail.masked to i64
  %two.shifted = shl i64 %two.head, 6
  %two.value = or i64 %two.shifted, %two.tail
  br label %complete
three:
  %three.byte.0 = load i8, ptr %data, align 1
  %three.pointer.1 = getelementptr i8, ptr %data, i64 1
  %three.pointer.2 = getelementptr i8, ptr %data, i64 2
  %three.byte.1 = load i8, ptr %three.pointer.1, align 1
  %three.byte.2 = load i8, ptr %three.pointer.2, align 1
  %three.head.masked = and i8 %three.byte.0, 15
  %three.middle.masked = and i8 %three.byte.1, 63
  %three.tail.masked = and i8 %three.byte.2, 63
  %three.head = zext i8 %three.head.masked to i64
  %three.middle = zext i8 %three.middle.masked to i64
  %three.tail = zext i8 %three.tail.masked to i64
  %three.head.shifted = shl i64 %three.head, 12
  %three.middle.shifted = shl i64 %three.middle, 6
  %three.partial = or i64 %three.head.shifted, %three.middle.shifted
  %three.value = or i64 %three.partial, %three.tail
  br label %complete
four:
  %four.byte.0 = load i8, ptr %data, align 1
  %four.pointer.1 = getelementptr i8, ptr %data, i64 1
  %four.pointer.2 = getelementptr i8, ptr %data, i64 2
  %four.pointer.3 = getelementptr i8, ptr %data, i64 3
  %four.byte.1 = load i8, ptr %four.pointer.1, align 1
  %four.byte.2 = load i8, ptr %four.pointer.2, align 1
  %four.byte.3 = load i8, ptr %four.pointer.3, align 1
  %four.head.masked = and i8 %four.byte.0, 7
  %four.second.masked = and i8 %four.byte.1, 63
  %four.third.masked = and i8 %four.byte.2, 63
  %four.tail.masked = and i8 %four.byte.3, 63
  %four.head = zext i8 %four.head.masked to i64
  %four.second = zext i8 %four.second.masked to i64
  %four.third = zext i8 %four.third.masked to i64
  %four.tail = zext i8 %four.tail.masked to i64
  %four.head.shifted = shl i64 %four.head, 18
  %four.second.shifted = shl i64 %four.second, 12
  %four.third.shifted = shl i64 %four.third, 6
  %four.partial.0 = or i64 %four.head.shifted, %four.second.shifted
  %four.partial.1 = or i64 %four.partial.0, %four.third.shifted
  %four.value = or i64 %four.partial.1, %four.tail
  br label %complete
complete:
  %value = phi i64 [ %one.value, %one.valid ], [ %two.value, %two.decode ], [ %three.value, %three ], [ %four.value, %four ]
  %result = call ptr @topal.pid.runtime.int.from.u64(i64 %value)
  ret ptr %result
invalid:
  call void @topal.pid.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.pid.runtime.string.unicode.scalar.characters(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  br label %loop
loop:
  %offset = phi i64 [ 0, %entry ], [ %next.offset, %append ]
  %head = phi ptr [ null, %entry ], [ %next.head, %append ]
  %tail = phi ptr [ null, %entry ], [ %node, %append ]
  %complete = icmp eq i64 %offset, %length
  br i1 %complete, label %done, label %decode
decode:
  %byte.pointer = getelementptr i8, ptr %data, i64 %offset
  %byte = load i8, ptr %byte.pointer, align 1
  %ascii = icmp ult i8 %byte, -128
  %two.mask = and i8 %byte, -32
  %two = icmp eq i8 %two.mask, -64
  %three.mask = and i8 %byte, -16
  %three = icmp eq i8 %three.mask, -32
  %non.ascii.width = select i1 %two, i64 2, i64 4
  %multi.width = select i1 %three, i64 3, i64 %non.ascii.width
  %width = select i1 %ascii, i64 1, i64 %multi.width
  %next.offset = add i64 %offset, %width
  %valid = icmp ule i64 %next.offset, %length
  br i1 %valid, label %make, label %invalid
make:
  %character.data = getelementptr i8, ptr %data, i64 %offset
  %character = call ptr @topal.pid.runtime.string.make(ptr %character.data, i64 %width, ptr null, i64 0)
  %node = call ptr @topal.pid.platform.allocate(i64 16)
  store ptr %character, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %append, label %link
link:
  %tail.next = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next, align 8
  br label %append
append:
  %next.head = select i1 %empty, ptr %node, ptr %head
  br label %loop
done:
  ret ptr %head
invalid:
  call void @topal.pid.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.pid.runtime.string.select.index.range(ptr %string, ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.pid.runtime.string.unicode.scalar.characters(ptr %string)
  %empty.data = call ptr @topal.pid.platform.allocate(i64 1)
  %empty = call ptr @topal.pid.runtime.string.make(ptr %empty.data, i64 0, ptr null, i64 0)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %index = phi i64 [ 0, %entry ], [ %next.index, %advance ]
  %selected = phi ptr [ %empty, %entry ], [ %next.selected, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %visit
visit:
  %index.value = call ptr @topal.pid.runtime.int.from.u64(i64 %index)
  %present = call i1 @topal.pid.runtime.range.int.contains(ptr %range, ptr %index.value)
  %character = load ptr, ptr %current, align 8
  br i1 %present, label %append, label %skip
append:
  %appended = call ptr @topal.pid.runtime.string.concat(ptr %selected, ptr %character)
  br label %advance
skip:
  br label %advance
advance:
  %next.selected = phi ptr [ %appended, %append ], [ %selected, %skip ]
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.index = add i64 %index, 1
  br label %loop
done:
  ret ptr %selected
}

define internal ptr @topal.pid.runtime.string.character.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.pid.runtime.string.unicode.scalar.characters(ptr %string)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %count = phi i64 [ 0, %entry ], [ %next.count, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.count = add i64 %count, 1
  br label %loop
done:
  %value = call ptr @topal.pid.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.pid.runtime.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %same.length = icmp eq i64 %left.length, %right.length
  br i1 %same.length, label %loop, label %not.equal
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %complete = icmp eq i64 %index, %left.length
  br i1 %complete, label %equal, label %compare
compare:
  %left.pointer = getelementptr i8, ptr %left.data, i64 %index
  %right.pointer = getelementptr i8, ptr %right.data, i64 %index
  %left.byte = load i8, ptr %left.pointer, align 1
  %right.byte = load i8, ptr %right.pointer, align 1
  %same.byte = icmp eq i8 %left.byte, %right.byte
  br i1 %same.byte, label %advance, label %not.equal
advance:
  %next = add i64 %index, 1
  br label %loop
equal:
  ret i1 true
not.equal:
  ret i1 false
}

define internal ptr @topal.pid.runtime.result.success(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.pid.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal ptr @topal.pid.runtime.result.error(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.pid.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal i1 @topal.pid.runtime.result.is.error(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %is.error = icmp eq i64 %tag, 1
  ret i1 %is.error
}

define internal ptr @topal.pid.runtime.result.payload(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.pid.runtime.optional.some(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.pid.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal ptr @topal.pid.runtime.optional.none() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.pid.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal i1 @topal.pid.runtime.optional.is.some(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid
checked:
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some
invalid:
  call void @topal.pid.platform.exit(i64 70)
  unreachable
}

define internal ptr @topal.pid.runtime.optional.payload(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.pid.runtime.optional.from.nullable(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %present = icmp ne ptr %payload, null
  br i1 %present, label %some, label %none
some:
  %some.value = call ptr @topal.pid.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.pid.runtime.optional.none()
  ret ptr %none.value
}

define internal i1 @topal.pid.runtime.optional.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.pid.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.pid.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.pid.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.pid.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.pid.runtime.int.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.pid.runtime.optional.rational.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.pid.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.pid.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.pid.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.pid.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.pid.runtime.rational.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.pid.runtime.optional.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.pid.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.pid.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.pid.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.pid.runtime.optional.payload(ptr %right)
  %payloads.equal = call i1 @topal.pid.runtime.string.equal(ptr %left.payload, ptr %right.payload)
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal ptr @topal.pid.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.pid.platform.allocate(i64 56)
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %reserved.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 2
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  store ptr %domain, ptr %domain.pointer, align 8
  store i32 %code, ptr %code.pointer, align 4
  store i32 0, ptr %reserved.pointer, align 4
  store ptr null, ptr %detail.pointer, align 8
  store ptr null, ptr %cause.pointer, align 8
  store ptr %source, ptr %source.pointer, align 8
  store i64 %line, ptr %line.pointer, align 8
  store i64 %column, ptr %column.pointer, align 8
  ret ptr %error
}

define internal i32 @topal.pid.runtime.error.code(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %code = load i32, ptr %code.pointer, align 4
  ret i32 %code
}

define internal ptr @topal.pid.runtime.error.domain(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %domain = load ptr, ptr %domain.pointer, align 8
  ret ptr %domain
}

define internal ptr @topal.pid.runtime.error.detail(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %detail = load ptr, ptr %detail.pointer, align 8
  %optional = call ptr @topal.pid.runtime.optional.from.nullable(ptr %detail)
  ret ptr %optional
}

define internal ptr @topal.pid.runtime.error.cause(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %cause = load ptr, ptr %cause.pointer, align 8
  %optional = call ptr @topal.pid.runtime.optional.from.nullable(ptr %cause)
  ret ptr %optional
}

define internal ptr @topal.pid.runtime.error.source(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %source = load ptr, ptr %source.pointer, align 8
  %present = icmp ne ptr %source, null
  br i1 %present, label %some, label %none
some:
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  %line.number = load i64, ptr %line.pointer, align 8
  %column.number = load i64, ptr %column.pointer, align 8
  %line = call ptr @topal.pid.runtime.int.from.u64(i64 %line.number)
  %column = call ptr @topal.pid.runtime.int.from.u64(i64 %column.number)
  %location = call ptr @topal.pid.platform.allocate(i64 16)
  %location.line = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %location.column = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  store ptr %line, ptr %location.line, align 8
  store ptr %column, ptr %location.column, align 8
  %some.value = call ptr @topal.pid.runtime.optional.some(ptr %location)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.pid.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.pid.runtime.source.location.line(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %line.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %line = load ptr, ptr %line.pointer, align 8
  ret ptr %line
}

define internal ptr @topal.pid.runtime.source.location.column(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %column.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  %column = load ptr, ptr %column.pointer, align 8
  ret ptr %column
}

define internal ptr @topal.pid.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.pid.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  %result = call ptr @topal.pid.runtime.result.error(ptr %error)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.int.try.to.nat(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %success
failure:
  %failed = call ptr @topal.pid.runtime.result.failure(i32 0, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %result = call ptr @topal.pid.runtime.result.success(ptr %value)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.try.to.int(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %value)
  %ordering = call i32 @topal.pid.runtime.int.compare(ptr %denominator, ptr @topal.pid.runtime.int.one)
  %exact = icmp eq i32 %ordering, 0
  br i1 %exact, label %success, label %failure
failure:
  %failed = call ptr @topal.pid.runtime.result.failure(i32 1, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %value)
  %result = call ptr @topal.pid.runtime.result.success(ptr %numerator)
  ret ptr %result
}

define internal void @topal.pid.runtime.error.print(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %domain = load ptr, ptr %domain.pointer, align 8
  %code = load i32, ptr %code.pointer, align 4
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.error.prefix, i64 18)
  call void @topal.pid.runtime.string.raw.print(ptr %domain)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.error.code.separator, i64 10)
  call void @topal.pid.runtime.error.code.print(i32 %code)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.error.suffix, i64 2)
  ret void
}

define internal void @topal.pid.runtime.error.code.print(i32 %code) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  switch i32 %code, label %indeterminate [ i32 0, label %out.of.range i32 1, label %not.representable i32 2, label %division.by.zero ]
out.of.range:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.error.code.out.of.range, i64 12)
  br label %done
not.representable:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.error.code.not.representable, i64 17)
  br label %done
division.by.zero:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.error.code.division.by.zero, i64 16)
  br label %done
indeterminate:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.error.code.indeterminate, i64 13)
  br label %done
done:
  ret void
}

define internal ptr @topal.pid.runtime.int.allocate(i64 %length, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure
allocate:
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.pid.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value
failure:
  call void @topal.pid.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.pid.runtime.int.from.u64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero
zero:
  ret ptr @topal.pid.runtime.int.zero
nonzero:
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.pid.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done
store.high:
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done
done:
  ret ptr %value
}

define internal ptr @topal.pid.runtime.int.from.i64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = icmp slt i64 %source, 0
  %negated = sub i64 0, %source
  %magnitude = select i1 %negative, i64 %negated, i64 %source
  %value = call ptr @topal.pid.runtime.int.from.u64(i64 %magnitude)
  br i1 %negative, label %signed, label %done
signed:
  %negative.value = call ptr @topal.pid.runtime.int.copy.with.sign(ptr %value, i64 1)
  ret ptr %negative.value
done:
  ret ptr %value
}

define internal i32 @topal.pid.runtime.int.to.c.i32(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %sign = load i64, ptr %sign.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %return.zero, label %nonzero
return.zero:
  ret i32 0
nonzero:
  %one.limb = icmp eq i64 %length, 1
  %finite.sign = icmp ule i64 %sign, 1
  %shape.valid = and i1 %one.limb, %finite.sign
  br i1 %shape.valid, label %load, label %failure
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %limb = load i32, ptr %limb.pointer, align 4
  %negative = icmp eq i64 %sign, 1
  %positive.valid = icmp ule i32 %limb, 2147483647
  %negative.valid = icmp ule i32 %limb, 2147483648
  %range.valid = select i1 %negative, i1 %negative.valid, i1 %positive.valid
  br i1 %range.valid, label %convert, label %failure
convert:
  %negated = sub i32 0, %limb
  %result = select i1 %negative, i32 %negated, i32 %limb
  ret i32 %result
failure:
  call void @topal.pid.runtime.c.int32.range.fail()
  unreachable
}

define internal i64 @topal.pid.runtime.int.limb.or.zero(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended
zero:
  ret i64 0
}

define internal ptr @topal.pid.runtime.int.normalize(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim
trim:
  %candidate = phi i64 [%length, %entry], [%next, %leading.zero]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done
leading.zero:
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim
zero:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value
done:
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.pid.runtime.int.copy.with.sign(ptr %value, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate
zero:
  ret ptr @topal.pid.runtime.int.zero
allocate:
  %copy = call ptr @topal.pid.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %allocate], [%next, %loop]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  ret ptr %copy
}

define internal ptr @topal.pid.runtime.int.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  ret ptr @topal.pid.runtime.int.negative.infinity
negative.infinity:
  ret ptr @topal.pid.runtime.int.positive.infinity
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %copy
zero:
  ret ptr @topal.pid.runtime.int.zero
copy:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %opposite = xor i64 %negative, 1
  %result = call ptr @topal.pid.runtime.int.copy.with.sign(ptr %value, i64 %opposite)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.int.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite
infinite:
  ret ptr @topal.pid.runtime.int.positive.infinity
finite:
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy
same:
  ret ptr %value
copy:
  %result = call ptr @topal.pid.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

define internal i32 @topal.pid.runtime.int.compare.absolute(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer
check.longer:
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty
check.empty:
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs
limbs:
  %position = phi i64 [%left.length, %check.empty], [%index, %limbs.equal]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater
check.limb.greater:
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal
limbs.equal:
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal
less:
  ret i32 -1
equal:
  ret i32 0
greater:
  ret i32 1
}

define internal i32 @topal.pid.runtime.int.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity
left.positive:
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result
check.left.negative.infinity:
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity
left.negative:
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result
check.right.positive.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity
check.right.negative.infinity:
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite
less:
  ret i32 -1
greater:
  ret i32 1
finite:
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute
signed.result:
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result
absolute:
  %magnitude = call i32 @topal.pid.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

define internal ptr @topal.pid.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.pid.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %carry = phi i64 [0, %entry], [%next.carry, %loop]
  %left.limb = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish
finish:
  %final.carry = phi i64 [0, %entry], [%next.carry, %loop]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry
store.carry:
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result
without.carry:
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.pid.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.pid.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.pid.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %borrow = phi i64 [0, %entry], [%next.borrow, %loop]
  %left = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.pid.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  %normalized = call ptr @topal.pid.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.pid.runtime.int.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity
validate.left.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity
indeterminate.infinity:
  call void @topal.pid.platform.exit(i64 70)
  unreachable
return.left.infinity:
  ret ptr %left
check.right.infinity:
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite
return.right.infinity:
  ret ptr %right
finite:
  %left.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right
return.right:
  ret ptr %right
check.right:
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero
return.left:
  ret ptr %left
nonzero:
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference
sum:
  %sum.value = call ptr @topal.pid.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value
difference:
  %ordering = call i32 @topal.pid.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger
zero:
  ret ptr @topal.pid.runtime.int.zero
select.larger:
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference
left.difference:
  %left.value = call ptr @topal.pid.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value
right.difference:
  %right.value = call ptr @topal.pid.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

define internal ptr @topal.pid.runtime.int.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %opposite = call ptr @topal.pid.runtime.int.negate(ptr %right)
  %result = call ptr @topal.pid.runtime.int.add(ptr %left, ptr %opposite)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.int.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %left.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity
indeterminate.infinity:
  call void @topal.pid.platform.exit(i64 70)
  unreachable
select.infinity:
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.pid.runtime.int.negative.infinity, ptr @topal.pid.runtime.int.positive.infinity
  ret ptr %infinity
finite:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length
zero:
  ret ptr @topal.pid.runtime.int.zero
check.length:
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate
failure:
  call void @topal.pid.platform.exit(i64 71)
  unreachable
allocate:
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.pid.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear
clear:
  %clear.index = phi i64 [0, %allocate], [%clear.next, %clear]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry
outer.entry:
  br label %outer
outer:
  %left.index = phi i64 [0, %outer.entry], [%left.next, %outer.done]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner
inner:
  %right.index = phi i64 [0, %outer], [%right.next, %inner]
  %carry = phi i64 [0, %outer], [%next.carry, %inner]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done
outer.done:
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done
done:
  %normalized = call ptr @topal.pid.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal void @topal.pid.runtime.int.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.int.positive.infinity.text, i64 9)
  ret void
negative.infinity:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.int.negative.infinity.text, i64 9)
  ret void
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check.sign
zero:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.byte.zero, i64 1)
  ret void
check.sign:
  %is.negative = icmp ne i64 %sign, 0
  br i1 %is.negative, label %write.sign, label %prepare
write.sign:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.byte.minus, i64 1)
  br label %prepare
prepare:
  %capacity.valid = icmp ule i64 %length, 922337203685477580
  br i1 %capacity.valid, label %allocate, label %failure
failure:
  call void @topal.pid.platform.exit(i64 71)
  unreachable
allocate:
  %scratch.bytes = mul i64 %length, 4
  %capacity = mul i64 %length, 10
  %scratch = call ptr @topal.pid.platform.allocate(i64 %scratch.bytes)
  %buffer = call ptr @topal.pid.platform.allocate(i64 %capacity)
  br label %copy
copy:
  %copy.index = phi i64 [0, %allocate], [%copy.next, %copy]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %copy.index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr i32, ptr %scratch, i64 %copy.index
  store i32 %limb, ptr %destination, align 4
  %copy.next = add i64 %copy.index, 1
  %copy.more = icmp ult i64 %copy.next, %length
  br i1 %copy.more, label %copy, label %digits
digits:
  %work.length = phi i64 [%length, %copy], [%next.length, %division.finish]
  %position = phi i64 [%capacity, %copy], [%next.position, %division.finish]
  br label %divide
divide:
  %division.position = phi i64 [%work.length, %digits], [%division.index, %divide.step]
  %remainder = phi i64 [0, %digits], [%next.remainder, %divide.step]
  %division.index = sub i64 %division.position, 1
  %work.pointer = getelementptr i32, ptr %scratch, i64 %division.index
  %work.raw = load i32, ptr %work.pointer, align 4
  %work = zext i32 %work.raw to i64
  %high = shl i64 %remainder, 32
  %current = or i64 %high, %work
  %quotient = udiv i64 %current, 10
  %next.remainder = urem i64 %current, 10
  %quotient.limb = trunc i64 %quotient to i32
  store i32 %quotient.limb, ptr %work.pointer, align 4
  %division.more = icmp ne i64 %division.index, 0
  br i1 %division.more, label %divide.step, label %division.done
divide.step:
  br label %divide
division.done:
  %next.position = sub i64 %position, 1
  %digit = trunc i64 %next.remainder to i8
  %ascii = add i8 %digit, 48
  %digit.pointer = getelementptr i8, ptr %buffer, i64 %next.position
  store i8 %ascii, ptr %digit.pointer, align 1
  br label %trim
trim:
  %candidate = phi i64 [%work.length, %division.done], [%trim.next, %trim.zero]
  %trim.index = sub i64 %candidate, 1
  %trim.pointer = getelementptr i32, ptr %scratch, i64 %trim.index
  %trim.limb = load i32, ptr %trim.pointer, align 4
  %leading.zero = icmp eq i32 %trim.limb, 0
  br i1 %leading.zero, label %trim.zero, label %trim.done
trim.zero:
  %trim.next = sub i64 %candidate, 1
  %trim.empty = icmp eq i64 %trim.next, 0
  br i1 %trim.empty, label %trim.empty.done, label %trim
trim.empty.done:
  br label %division.finish
trim.done:
  br label %division.finish
division.finish:
  %next.length = phi i64 [0, %trim.empty.done], [%candidate, %trim.done]
  %more.digits = icmp ne i64 %next.length, 0
  br i1 %more.digits, label %digits, label %emit
emit:
  %count = sub i64 %capacity, %next.position
  %first = getelementptr i8, ptr %buffer, i64 %next.position
  call void @topal.pid.platform.write_all(ptr %first, i64 %count)
  ret void
}

define internal i1 @topal.pid.runtime.int.is.zero(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

define internal ptr @topal.pid.runtime.int.divmod.pair(ptr %quotient, ptr %remainder) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.pid.platform.allocate(i64 16)
  %quotient.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %remainder.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  store ptr %quotient, ptr %quotient.pointer, align 8
  store ptr %remainder, ptr %remainder.pointer, align 8
  ret ptr %pair
}

define internal ptr @topal.pid.runtime.int.divmod.quotient(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.pid.runtime.int.divmod.remainder(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i64 @topal.pid.runtime.int.bit.length(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check
zero:
  ret i64 0
check:
  %valid = icmp ule i64 %length, 576460752303423487
  br i1 %valid, label %calculate, label %failure
failure:
  call void @topal.pid.platform.exit(i64 71)
  unreachable
calculate:
  %last = sub i64 %length, 1
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %last
  %limb = load i32, ptr %pointer, align 4
  %leading = call i32 @llvm.ctlz.i32(i32 %limb, i1 false)
  %top.bits.raw = sub i32 32, %leading
  %top.bits = zext i32 %top.bits.raw to i64
  %lower.bits = mul i64 %last, 32
  %bits = add i64 %lower.bits, %top.bits
  ret i64 %bits
}

define internal i1 @topal.pid.runtime.int.bit.at(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %limb.index = lshr i64 %index, 5
  %offset.raw = and i64 %index, 31
  %offset = trunc i64 %offset.raw to i32
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %limb.index
  %limb = load i32, ptr %pointer, align 4
  %shifted = lshr i32 %limb, %offset
  %bit.raw = and i32 %shifted, 1
  %bit = icmp ne i32 %bit.raw, 0
  ret i1 %bit
}

define internal ptr @topal.pid.runtime.int.divmod.absolute(ptr %dividend, ptr %divisor) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %divisor.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %divisor)
  br i1 %divisor.zero, label %failure, label %check.dividend
failure:
  call void @topal.pid.platform.exit(i64 65)
  unreachable
check.dividend:
  %dividend.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %dividend)
  br i1 %dividend.zero, label %zero, label %prepare
zero:
  %zero.pair = call ptr @topal.pid.runtime.int.divmod.pair(ptr @topal.pid.runtime.int.zero, ptr @topal.pid.runtime.int.zero)
  ret ptr %zero.pair
prepare:
  %bits = call i64 @topal.pid.runtime.int.bit.length(ptr %dividend)
  br label %loop
loop:
  %position = phi i64 [%bits, %prepare], [%next.position, %merge]
  %quotient = phi ptr [@topal.pid.runtime.int.zero, %prepare], [%next.quotient, %merge]
  %remainder = phi ptr [@topal.pid.runtime.int.zero, %prepare], [%next.remainder, %merge]
  %bit.index = sub i64 %position, 1
  %bit = call i1 @topal.pid.runtime.int.bit.at(ptr %dividend, i64 %bit.index)
  %quotient.twice = call ptr @topal.pid.runtime.int.add(ptr %quotient, ptr %quotient)
  %remainder.twice = call ptr @topal.pid.runtime.int.add(ptr %remainder, ptr %remainder)
  br i1 %bit, label %append.bit, label %compare
append.bit:
  %remainder.with.bit = call ptr @topal.pid.runtime.int.add(ptr %remainder.twice, ptr @topal.pid.runtime.int.one)
  br label %compare
compare:
  %candidate = phi ptr [%remainder.twice, %loop], [%remainder.with.bit, %append.bit]
  %ordering = call i32 @topal.pid.runtime.int.compare.absolute(ptr %candidate, ptr %divisor)
  %subtract = icmp sge i32 %ordering, 0
  br i1 %subtract, label %subtract.divisor, label %retain
subtract.divisor:
  %reduced = call ptr @topal.pid.runtime.int.subtract.absolute(ptr %candidate, ptr %divisor, i64 0)
  %incremented = call ptr @topal.pid.runtime.int.add(ptr %quotient.twice, ptr @topal.pid.runtime.int.one)
  br label %merge
retain:
  br label %merge
merge:
  %next.quotient = phi ptr [%incremented, %subtract.divisor], [%quotient.twice, %retain]
  %next.remainder = phi ptr [%reduced, %subtract.divisor], [%candidate, %retain]
  %next.position = sub i64 %position, 1
  %more = icmp ne i64 %next.position, 0
  br i1 %more, label %loop, label %done
done:
  %pair = call ptr @topal.pid.runtime.int.divmod.pair(ptr %next.quotient, ptr %next.remainder)
  ret ptr %pair
}

define internal ptr @topal.pid.runtime.int.quotient.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %divide
failure:
  call void @topal.pid.platform.exit(i64 65)
  unreachable
divide:
  %left.absolute = call ptr @topal.pid.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.pid.runtime.int.absolute(ptr %right)
  %unsigned = call ptr @topal.pid.runtime.int.divmod.absolute(ptr %left.absolute, ptr %right.absolute)
  %quotient.absolute = call ptr @topal.pid.runtime.int.divmod.quotient(ptr %unsigned)
  %remainder.absolute = call ptr @topal.pid.runtime.int.divmod.remainder(ptr %unsigned)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.negative = icmp ne i64 %left.sign, 0
  %remainder.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %remainder.absolute)
  %remainder.present = xor i1 %remainder.zero, true
  %needs.adjustment = and i1 %left.negative, %remainder.present
  %quotient.sign = xor i64 %left.sign, %right.sign
  br i1 %needs.adjustment, label %adjust, label %direct
direct:
  %direct.quotient = call ptr @topal.pid.runtime.int.copy.with.sign(ptr %quotient.absolute, i64 %quotient.sign)
  %direct.pair = call ptr @topal.pid.runtime.int.divmod.pair(ptr %direct.quotient, ptr %remainder.absolute)
  ret ptr %direct.pair
adjust:
  %larger.quotient = call ptr @topal.pid.runtime.int.add(ptr %quotient.absolute, ptr @topal.pid.runtime.int.one)
  %adjusted.quotient = call ptr @topal.pid.runtime.int.copy.with.sign(ptr %larger.quotient, i64 %quotient.sign)
  %adjusted.remainder = call ptr @topal.pid.runtime.int.subtract.absolute(ptr %right.absolute, ptr %remainder.absolute, i64 0)
  %adjusted.pair = call ptr @topal.pid.runtime.int.divmod.pair(ptr %adjusted.quotient, ptr %adjusted.remainder)
  ret ptr %adjusted.pair
}

define internal ptr @topal.pid.runtime.int.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.pid.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %remainder = call ptr @topal.pid.runtime.int.divmod.remainder(ptr %pair)
  ret ptr %remainder
}

define internal ptr @topal.pid.runtime.int.try.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.pid.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %remainder = call ptr @topal.pid.runtime.int.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.pid.runtime.result.success(ptr %remainder)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.int.try.quotient.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.pid.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %pair = call ptr @topal.pid.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.pid.runtime.result.success(ptr %pair)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.int.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %prepare
failure:
  call void @topal.pid.platform.exit(i64 65)
  unreachable
prepare:
  %bits = call i64 @topal.pid.runtime.int.bit.length(ptr %exponent)
  %empty = icmp eq i64 %bits, 0
  br i1 %empty, label %one, label %loop
one:
  ret ptr @topal.pid.runtime.int.one
loop:
  %position = phi i64 [0, %prepare], [%next.position, %square]
  %result = phi ptr [@topal.pid.runtime.int.one, %prepare], [%next.result, %square]
  %factor = phi ptr [%base, %prepare], [%next.factor, %square]
  %bit = call i1 @topal.pid.runtime.int.bit.at(ptr %exponent, i64 %position)
  br i1 %bit, label %multiply, label %retain
multiply:
  %product = call ptr @topal.pid.runtime.int.multiply(ptr %result, ptr %factor)
  br label %advance
retain:
  br label %advance
advance:
  %next.result = phi ptr [%product, %multiply], [%result, %retain]
  %next.position = add i64 %position, 1
  %complete = icmp eq i64 %next.position, %bits
  br i1 %complete, label %done, label %square
square:
  %next.factor = call ptr @topal.pid.runtime.int.multiply(ptr %factor, ptr %factor)
  br label %loop
done:
  ret ptr %next.result
}

define internal ptr @topal.pid.runtime.int.greatest.common.divisor(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.absolute = call ptr @topal.pid.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.pid.runtime.int.absolute(ptr %right)
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right.absolute)
  br i1 %right.zero, label %initial.done, label %loop
initial.done:
  ret ptr %left.absolute
loop:
  %current.left = phi ptr [%left.absolute, %entry], [%current.right, %again]
  %current.right = phi ptr [%right.absolute, %entry], [%remainder, %again]
  %division = call ptr @topal.pid.runtime.int.divmod.absolute(ptr %current.left, ptr %current.right)
  %remainder = call ptr @topal.pid.runtime.int.divmod.remainder(ptr %division)
  %done = call i1 @topal.pid.runtime.int.is.zero(ptr %remainder)
  br i1 %done, label %result, label %again
again:
  br label %loop
result:
  ret ptr %current.right
}

define internal ptr @topal.pid.runtime.rational.raw(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.pid.platform.allocate(i64 16)
  %numerator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %denominator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  store ptr %numerator, ptr %numerator.pointer, align 8
  store ptr %denominator, ptr %denominator.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.pid.runtime.rational.numerator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %numerator = load ptr, ptr %pointer, align 8
  ret ptr %numerator
}

define internal ptr @topal.pid.runtime.rational.denominator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  %denominator = load ptr, ptr %pointer, align 8
  ret ptr %denominator
}

define internal ptr @topal.pid.runtime.rational.make(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %numerator.sign = load i64, ptr %numerator.sign.pointer, align 8
  %positive.infinity = icmp eq i64 %numerator.sign, 2
  %negative.infinity = icmp eq i64 %numerator.sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %make.infinity, label %finite
make.infinity:
  %infinite.value = call ptr @topal.pid.runtime.rational.raw(ptr %numerator, ptr @topal.pid.runtime.int.one)
  ret ptr %infinite.value
finite:
  %denominator.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %check.numerator
failure:
  call void @topal.pid.platform.exit(i64 65)
  unreachable
check.numerator:
  %numerator.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %numerator)
  br i1 %numerator.zero, label %zero, label %normalize
zero:
  %zero.value = call ptr @topal.pid.runtime.rational.raw(ptr @topal.pid.runtime.int.zero, ptr @topal.pid.runtime.int.one)
  ret ptr %zero.value
normalize:
  %numerator.absolute = call ptr @topal.pid.runtime.int.absolute(ptr %numerator)
  %denominator.absolute = call ptr @topal.pid.runtime.int.absolute(ptr %denominator)
  %divisor = call ptr @topal.pid.runtime.int.greatest.common.divisor(ptr %numerator.absolute, ptr %denominator.absolute)
  %numerator.division = call ptr @topal.pid.runtime.int.divmod.absolute(ptr %numerator.absolute, ptr %divisor)
  %denominator.division = call ptr @topal.pid.runtime.int.divmod.absolute(ptr %denominator.absolute, ptr %divisor)
  %reduced.numerator.absolute = call ptr @topal.pid.runtime.int.divmod.quotient(ptr %numerator.division)
  %reduced.denominator = call ptr @topal.pid.runtime.int.divmod.quotient(ptr %denominator.division)
  %finite.numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %finite.denominator.sign.pointer = getelementptr %topal.IntStorage, ptr %denominator, i32 0, i32 0
  %finite.numerator.sign = load i64, ptr %finite.numerator.sign.pointer, align 8
  %finite.denominator.sign = load i64, ptr %finite.denominator.sign.pointer, align 8
  %sign = xor i64 %finite.numerator.sign, %finite.denominator.sign
  %reduced.numerator = call ptr @topal.pid.runtime.int.copy.with.sign(ptr %reduced.numerator.absolute, i64 %sign)
  %result = call ptr @topal.pid.runtime.rational.raw(ptr %reduced.numerator, ptr %reduced.denominator)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.from.int(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.pid.runtime.rational.raw(ptr %value, ptr @topal.pid.runtime.int.one)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %value)
  %negative = call ptr @topal.pid.runtime.int.negate(ptr %numerator)
  %result = call ptr @topal.pid.runtime.rational.raw(ptr %negative, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %value)
  %absolute = call ptr @topal.pid.runtime.int.absolute(ptr %numerator)
  %result = call ptr @topal.pid.runtime.rational.raw(ptr %absolute, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %right)
  %left.scaled = call ptr @topal.pid.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.pid.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %numerator = call ptr @topal.pid.runtime.int.add(ptr %left.scaled, ptr %right.scaled)
  %denominator = call ptr @topal.pid.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.pid.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = call ptr @topal.pid.runtime.rational.negate(ptr %right)
  %result = call ptr @topal.pid.runtime.rational.add(ptr %left, ptr %negative)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %right)
  %numerator = call ptr @topal.pid.runtime.int.multiply(ptr %left.numerator, ptr %right.numerator)
  %denominator = call ptr @topal.pid.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.pid.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.divide(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %right)
  %zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right.numerator)
  br i1 %zero, label %failure, label %calculate
failure:
  call void @topal.pid.platform.exit(i64 65)
  unreachable
calculate:
  %numerator = call ptr @topal.pid.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %denominator = call ptr @topal.pid.runtime.int.multiply(ptr %left.denominator, ptr %right.numerator)
  %result = call ptr @topal.pid.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal i32 @topal.pid.runtime.rational.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %right)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left.numerator, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right.numerator, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %infinite.result = call i32 @topal.pid.runtime.int.compare(ptr %left.numerator, ptr %right.numerator)
  ret i32 %infinite.result
finite:
  %left.scaled = call ptr @topal.pid.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.pid.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %result = call i32 @topal.pid.runtime.int.compare(ptr %left.scaled, ptr %right.scaled)
  ret i32 %result
}

define internal ptr @topal.pid.runtime.rational.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %base)
  %denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %base)
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  %absolute.exponent = call ptr @topal.pid.runtime.int.absolute(ptr %exponent)
  %powered.numerator = call ptr @topal.pid.runtime.int.power(ptr %numerator, ptr %absolute.exponent)
  %powered.denominator = call ptr @topal.pid.runtime.int.power(ptr %denominator, ptr %absolute.exponent)
  br i1 %negative, label %reciprocal, label %direct
direct:
  %direct.result = call ptr @topal.pid.runtime.rational.raw(ptr %powered.numerator, ptr %powered.denominator)
  ret ptr %direct.result
reciprocal:
  %zero = call i1 @topal.pid.runtime.int.is.zero(ptr %powered.numerator)
  br i1 %zero, label %failure, label %invert
failure:
  call void @topal.pid.platform.exit(i64 65)
  unreachable
invert:
  %result = call ptr @topal.pid.runtime.rational.make(ptr %powered.denominator, ptr %powered.numerator)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.try.make(ptr %numerator, ptr %denominator, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %success
failure:
  %numerator.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %numerator)
  %code = select i1 %numerator.zero, i32 3, i32 2
  %failed = call ptr @topal.pid.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.pid.runtime.rational.make(ptr %numerator, ptr %denominator)
  %result = call ptr @topal.pid.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.try.divide(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %right)
  %right.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %right.numerator)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.pid.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.pid.runtime.rational.divide(ptr %left, ptr %right)
  %result = call ptr @topal.pid.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.rational.try.power(ptr %base, ptr %exponent, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  br i1 %negative, label %check.base, label %success
check.base:
  %numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %base)
  %base.zero = call i1 @topal.pid.runtime.int.is.zero(ptr %numerator)
  br i1 %base.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.pid.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.pid.runtime.rational.power(ptr %base, ptr %exponent)
  %result = call ptr @topal.pid.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal void @topal.pid.runtime.rational.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.pid.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.pid.runtime.rational.denominator(ptr %value)
  %sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %positive.infinity = icmp eq i64 %sign, 2
  %negative.infinity = icmp eq i64 %sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %print.infinity, label %print.finite
print.infinity:
  call void @topal.pid.runtime.int.print(ptr %numerator)
  ret void
print.finite:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.rational.prefix, i64 11)
  call void @topal.pid.runtime.int.print(ptr %numerator)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.rational.separator, i64 2)
  call void @topal.pid.runtime.int.print(ptr %denominator)
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.rational.suffix, i64 2)
  ret void
}

define internal ptr @topal.pid.runtime.range.make(ptr %lower, ptr %upper, i64 %lower.inclusive, i64 %upper.inclusive) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.pid.platform.allocate(i64 32)
  %lower.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 0
  %upper.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 1
  %lower.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 2
  %upper.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 3
  store ptr %lower, ptr %lower.pointer, align 8
  store ptr %upper, ptr %upper.pointer, align 8
  store i64 %lower.inclusive, ptr %lower.inclusive.pointer, align 8
  store i64 %upper.inclusive, ptr %upper.inclusive.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.pid.runtime.range.lower(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.pid.runtime.range.upper(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i1 @topal.pid.runtime.range.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.pid.runtime.range.lower(ptr %left)
  %right.lower = call ptr @topal.pid.runtime.range.lower(ptr %right)
  %lower.ordering = call i32 @topal.pid.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.upper = call ptr @topal.pid.runtime.range.upper(ptr %left)
  %right.upper = call ptr @topal.pid.runtime.range.upper(ptr %right)
  %upper.ordering = call i32 @topal.pid.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %bounds.equal = and i1 %lower.equal, %upper.equal
  %left.lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %right)
  %lower.inclusive.equal = icmp eq i1 %left.lower.inclusive, %right.lower.inclusive
  %left.upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %left)
  %right.upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %right)
  %upper.inclusive.equal = icmp eq i1 %left.upper.inclusive, %right.upper.inclusive
  %inclusivity.equal = and i1 %lower.inclusive.equal, %upper.inclusive.equal
  %equal = and i1 %bounds.equal, %inclusivity.equal
  ret i1 %equal
}

define internal i1 @topal.pid.runtime.range.lower.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 2
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.pid.runtime.range.upper.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 3
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.pid.runtime.range.empty.from.comparison(ptr %range, i32 %ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %reversed = icmp sgt i32 %ordering, 0
  %equal = icmp eq i32 %ordering, 0
  %lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %range)
  %both.inclusive = and i1 %lower.inclusive, %upper.inclusive
  %open.equal = xor i1 %both.inclusive, true
  %empty.equal = and i1 %equal, %open.equal
  %empty = or i1 %reversed, %empty.equal
  ret i1 %empty
}

define internal i1 @topal.pid.runtime.range.int.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.pid.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.pid.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.pid.runtime.int.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.pid.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.pid.runtime.range.rational.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.pid.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.pid.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.pid.runtime.rational.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.pid.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.pid.runtime.range.int.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.pid.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.pid.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.pid.runtime.int.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.pid.runtime.int.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal i1 @topal.pid.runtime.range.rational.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.pid.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.pid.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.pid.runtime.rational.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.pid.runtime.rational.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal ptr @topal.pid.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.pid.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.pid.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.pid.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.pid.runtime.range.upper(ptr %right)
  %left.lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %left)
  %left.upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %right)
  %right.upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %right)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.lower.stricter = icmp sgt i32 %lower.ordering, 0
  %selected.lower = select i1 %left.lower.stricter, ptr %left.lower, ptr %right.lower
  %selected.lower.inclusive = select i1 %left.lower.stricter, i1 %left.lower.inclusive, i1 %right.lower.inclusive
  %equal.lower.inclusive = and i1 %left.lower.inclusive, %right.lower.inclusive
  %lower.inclusive = select i1 %lower.equal, i1 %equal.lower.inclusive, i1 %selected.lower.inclusive
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %left.upper.stricter = icmp slt i32 %upper.ordering, 0
  %selected.upper = select i1 %left.upper.stricter, ptr %left.upper, ptr %right.upper
  %selected.upper.inclusive = select i1 %left.upper.stricter, i1 %left.upper.inclusive, i1 %right.upper.inclusive
  %equal.upper.inclusive = and i1 %left.upper.inclusive, %right.upper.inclusive
  %upper.inclusive = select i1 %upper.equal, i1 %equal.upper.inclusive, i1 %selected.upper.inclusive
  %lower.inclusive.raw = zext i1 %lower.inclusive to i64
  %upper.inclusive.raw = zext i1 %upper.inclusive to i64
  %result = call ptr @topal.pid.runtime.range.make(ptr %selected.lower, ptr %selected.upper, i64 %lower.inclusive.raw, i64 %upper.inclusive.raw)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.range.int.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.pid.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.pid.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.pid.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.pid.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.pid.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.pid.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.pid.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal ptr @topal.pid.runtime.range.rational.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.pid.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.pid.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.pid.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.pid.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.pid.runtime.rational.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.pid.runtime.rational.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.pid.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal void @topal.pid.runtime.range.print.symbol(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower.inclusive = call i1 @topal.pid.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.pid.runtime.range.upper.inclusive(ptr %range)
  br i1 %lower.inclusive, label %lower.closed, label %lower.open
lower.closed:
  br i1 %upper.inclusive, label %closed.closed, label %closed.open
lower.open:
  br i1 %upper.inclusive, label %open.closed, label %open.open
closed.closed:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.range.closed.closed, i64 5)
  ret void
closed.open:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.range.closed.open, i64 4)
  ret void
open.closed:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.range.open.closed, i64 6)
  ret void
open.open:
  call void @topal.pid.platform.write_all(ptr @topal.pid.runtime.range.open.open, i64 5)
  ret void
}

define internal void @topal.pid.runtime.range.int.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.pid.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.pid.runtime.range.upper(ptr %range)
  call void @topal.pid.runtime.int.print(ptr %lower)
  call void @topal.pid.runtime.range.print.symbol(ptr %range)
  call void @topal.pid.runtime.int.print(ptr %upper)
  ret void
}

define internal void @topal.pid.runtime.range.rational.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.pid.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.pid.runtime.range.upper(ptr %range)
  call void @topal.pid.runtime.rational.print(ptr %lower)
  call void @topal.pid.runtime.range.print.symbol(ptr %range)
  call void @topal.pid.runtime.rational.print(ptr %upper)
  ret void
}
; Compiler-selected List Int layout for private topal-native/6 operations.

%topal.ListStorage = type { ptr, ptr }
; Compiler-private fundamental homogeneous containers. Construction may mutate
; unpublished result nodes; published Array, Set, Bag, and Map values are immutable.

%topal.ContainerSequenceHeader = type { i64, ptr }
%topal.ContainerBagHeader = type { i64, i64, ptr }
%topal.ContainerBagNode = type { ptr, i64, ptr }
%topal.ContainerMapNode = type { ptr, ptr, ptr }

define internal i64 @topal.pid.runtime.container.list.count(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop
done:
  ret i64 %count
}

define internal ptr @topal.pid.runtime.container.array.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.pid.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.pid.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal ptr @topal.pid.runtime.container.array.function.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.pid.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.pid.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal i1 @topal.pid.runtime.container.int.list.contains(ptr %list, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.pid.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret i1 true
absent:
  ret i1 false
}

define internal ptr @topal.pid.runtime.container.set.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %duplicate = call i1 @topal.pid.runtime.container.int.list.contains(ptr %head, ptr %value)
  br i1 %duplicate, label %skip, label %add
add:
  %node = call ptr @topal.pid.platform.allocate(i64 16)
  store ptr %value, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
skip:
  br label %advance
advance:
  %head.next = phi ptr [%head, %skip], [%added.head, %added]
  %tail.next = phi ptr [%tail, %skip], [%node, %added]
  %count.next = phi i64 [%count, %skip], [%added.count, %added]
  br label %loop
done:
  %set = call ptr @topal.pid.platform.allocate(i64 16)
  %set.count = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 0
  %set.entries = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  store i64 %count, ptr %set.count, align 8
  store ptr %head, ptr %set.entries, align 8
  ret ptr %set
}

define internal ptr @topal.pid.runtime.container.bag.int.find(ptr %entries, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.pid.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerBagNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.pid.runtime.container.bag.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %total = phi i64 [0, %entry], [%total.next, %advance]
  %distinct = phi i64 [0, %entry], [%distinct.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.pid.runtime.container.bag.int.find(ptr %head, ptr %value)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %increment, label %add
increment:
  %existing.count.pointer = getelementptr %topal.ContainerBagNode, ptr %existing, i32 0, i32 1
  %existing.count = load i64, ptr %existing.count.pointer, align 8
  %incremented = add i64 %existing.count, 1
  store i64 %incremented, ptr %existing.count.pointer, align 8
  br label %advance
add:
  %node = call ptr @topal.pid.platform.allocate(i64 24)
  %node.value = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 0
  %node.count = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 2
  store ptr %value, ptr %node.value, align 8
  store i64 1, ptr %node.count, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerBagNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.distinct = add i64 %distinct, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %increment], [%added.head, %added]
  %tail.next = phi ptr [%tail, %increment], [%node, %added]
  %distinct.next = phi i64 [%distinct, %increment], [%added.distinct, %added]
  %total.next = add i64 %total, 1
  br label %loop
done:
  %bag = call ptr @topal.pid.platform.allocate(i64 24)
  %bag.total = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 0
  %bag.distinct = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 1
  %bag.entries = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  store i64 %total, ptr %bag.total, align 8
  store i64 %distinct, ptr %bag.distinct, align 8
  store ptr %head, ptr %bag.entries, align 8
  ret ptr %bag
}

define internal ptr @topal.pid.runtime.container.map.string-int.find(ptr %entries, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %equal = call i1 @topal.pid.runtime.string.equal(ptr %candidate, ptr %key)
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerMapNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.pid.runtime.container.map.string-int.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load ptr, ptr %source.value.pointer, align 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.pid.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store ptr %value, ptr %existing.value, align 8
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.pid.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store ptr %value, ptr %node.value, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.pid.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.pid.runtime.container.map.string-function.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load i32, ptr %source.value.pointer, align 4
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.pid.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store i32 %value, ptr %existing.value, align 4
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.pid.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store i32 %value, ptr %node.value, align 4
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.pid.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.pid.runtime.container.entry.count(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %value = call ptr @topal.pid.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.pid.runtime.container.empty(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %empty = icmp eq i64 %count, 0
  ret i1 %empty
}

define internal ptr @topal.pid.runtime.container.array.int.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load ptr, ptr %current, align 8
  %some = call ptr @topal.pid.runtime.optional.some(ptr %value)
  ret ptr %some
absent:
  %none = call ptr @topal.pid.runtime.optional.none()
  ret ptr %none
}

define internal ptr @topal.pid.runtime.container.array.function.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load i32, ptr %current, align 4
  %payload = call ptr @topal.pid.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some = call ptr @topal.pid.runtime.optional.some(ptr %payload)
  ret ptr %some
absent:
  %none = call ptr @topal.pid.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.pid.runtime.container.set.int.contains(ptr %set, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %present = call i1 @topal.pid.runtime.container.int.list.contains(ptr %entries, ptr %value)
  ret i1 %present
}

define internal ptr @topal.pid.runtime.container.bag.int.multiplicity(ptr %bag, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.pid.runtime.container.bag.int.find(ptr %entries, ptr %value)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %zero, label %present
zero:
  %zero.value = call ptr @topal.pid.runtime.int.from.u64(i64 0)
  ret ptr %zero.value
present:
  %count.pointer = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %count = load i64, ptr %count.pointer, align 8
  %count.value = call ptr @topal.pid.runtime.int.from.u64(i64 %count)
  ret ptr %count.value
}

define internal ptr @topal.pid.runtime.container.map.string-int.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.pid.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load ptr, ptr %value.pointer, align 8
  %some.value = call ptr @topal.pid.runtime.optional.some(ptr %value)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.pid.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.pid.runtime.container.map.string-function.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.pid.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load i32, ptr %value.pointer, align 4
  %payload = call ptr @topal.pid.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some.value = call ptr @topal.pid.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.pid.runtime.optional.none()
  ret ptr %none.value
}
; Qualified hooks for the owned pure numeric kernel invocation.
; No context, address or allocator function is exposed to Topal source.
declare ptr @topal_kernel_numeric_allocate_v1(i64)
declare void @topal_kernel_numeric_abort_v1() noreturn

define internal ptr @topal.pid.platform.allocate(i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = call ptr @topal_kernel_numeric_allocate_v1(i64 %length)
  ret ptr %pointer
}

define internal void @topal.pid.platform.exit(i64 %status) noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

define internal i64 @topal.pid.platform.write(i64 %fd, ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}
@.topal.int.0 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.1 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.2 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.3 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.4 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2147483647] }, align 8
@.topal.int.5 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2147483647] }, align 8
@.topal.int.6 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
define internal fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2eselected.0(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !77 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !78, !DIExpression(), !79)
    #dbg_value(ptr @.topal.int.0, !80, !DIExpression(), !81)
  %v1 = call i32 @topal.pid.runtime.int.compare(ptr %arg0, ptr @.topal.int.1), !dbg !82
  %v2 = icmp eq i32 %v1, 0, !dbg !83
  %v3 = icmp eq i1 %v2, true, !dbg !84
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !85
decision.true.0:
  br label %decision.merge.2, !dbg !86
decision.false.1:
  br label %decision.merge.2, !dbg !87
decision.merge.2:
  %v4 = phi ptr [@.topal.int.0, %decision.true.0], [%arg0, %decision.false.1], !dbg !88
  ret ptr %v4, !dbg !89
}

define internal fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2efollowing.1(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !92 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !93, !DIExpression(), !94)
    #dbg_value(ptr @.topal.int.2, !95, !DIExpression(), !96)
    #dbg_value(ptr @.topal.int.3, !97, !DIExpression(), !98)
  %v1 = call i32 @topal.pid.runtime.int.compare(ptr %arg0, ptr @.topal.int.4), !dbg !99
  %v2 = icmp eq i32 %v1, 0, !dbg !100
  %v3 = icmp eq i1 %v2, true, !dbg !101
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !102
decision.true.0:
  br label %decision.merge.2, !dbg !103
decision.false.1:
  %v4 = call ptr @topal.pid.runtime.int.add(ptr %arg0, ptr @.topal.int.2), !dbg !104
  br label %decision.merge.2, !dbg !105
decision.merge.2:
  %v5 = phi ptr [@.topal.int.3, %decision.true.0], [%v4, %decision.false.1], !dbg !106
  ret ptr %v5, !dbg !107
}

define internal fastcc i1 @topal.identity.topal.fn.support_2eidentity_2dhistory_2eretain_2dwrap.2(i1 %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !110 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !111, !DIExpression(), !112)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !113, !DIExpression(), !114)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !115
decision.true.0:
  br label %decision.merge.2, !dbg !116
decision.false.1:
  %v2 = call i32 @topal.pid.runtime.int.compare(ptr %arg1, ptr @.topal.int.5), !dbg !117
  %v3 = icmp eq i32 %v2, 0, !dbg !118
  %v4 = icmp eq i1 %v3, true, !dbg !119
  br label %decision.merge.2, !dbg !120
decision.merge.2:
  %v5 = phi i1 [true, %decision.true.0], [%v4, %decision.false.1], !dbg !121
  ret i1 %v5, !dbg !122
}

define internal fastcc { ptr, i1, i32, i32 } @topal.identity.topal.fn.support_2eidentity_2dhistory_2efollowing.3({ ptr, i1, i32, i32 } %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !129 {
entry:
  %v0 = extractvalue { ptr, i1, i32, i32 } %arg0, 0, !dbg !130
  %v1 = extractvalue { ptr, i1, i32, i32 } %arg0, 1, !dbg !131
  %v2 = extractvalue { ptr, i1, i32, i32 } %arg0, 2, !dbg !132
  %v3 = extractvalue { ptr, i1, i32, i32 } %arg0, 3, !dbg !133
  %v4 = alloca { ptr, i1, i32, i32 }, align 8
  store { ptr, i1, i32, i32 } %arg0, ptr %v4, align 8
    #dbg_declare(ptr %v4, !134, !DIExpression(), !135)
  %v5 = alloca ptr, align 8
  store ptr %arg1, ptr %v5, align 8
    #dbg_declare(ptr %v5, !136, !DIExpression(), !137)
    #dbg_value(ptr @.topal.int.6, !138, !DIExpression(), !139)
  %v6 = call ptr @topal.pid.runtime.int.add(ptr %v0, ptr @.topal.int.6), !dbg !140
    #dbg_value(ptr %v6, !141, !DIExpression(), !142)
    #dbg_value(i1 %v1, !143, !DIExpression(), !144)
  %v7 = call fastcc i1 @topal.identity.topal.fn.support_2eidentity_2dhistory_2eretain_2dwrap.2(i1 %v1, ptr %arg1), !dbg !145
    #dbg_value(i1 %v7, !146, !DIExpression(), !147)
  %v8 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v6, 0, !dbg !149
  %v9 = insertvalue { ptr, i1, i32, i32 } %v8, i1 %v7, 1, !dbg !150
  %v10 = insertvalue { ptr, i1, i32, i32 } %v9, i32 0, 2, !dbg !151
  %v11 = insertvalue { ptr, i1, i32, i32 } %v10, i32 1, 3, !dbg !152
  ret { ptr, i1, i32, i32 } %v11, !dbg !148
}

define internal fastcc { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } @topal.identity.topal.fn.process_2didentity.4({ { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !163 {
entry:
  %v0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 0, !dbg !164
  %v1 = extractvalue { ptr, i1, i32, i32 } %v0, 0, !dbg !165
  %v2 = extractvalue { ptr, i1, i32, i32 } %v0, 1, !dbg !166
  %v3 = extractvalue { ptr, i1, i32, i32 } %v0, 2, !dbg !167
  %v4 = extractvalue { ptr, i1, i32, i32 } %v0, 3, !dbg !168
  %v5 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 1, !dbg !169
  %v6 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 2, !dbg !170
  %v7 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, 3, !dbg !171
  %v8 = alloca { { ptr, i1, i32, i32 }, ptr, i32, i32 }, align 8
  store { { ptr, i1, i32, i32 }, ptr, i32, i32 } %arg0, ptr %v8, align 8
    #dbg_declare(ptr %v8, !172, !DIExpression(), !173)
  %v9 = call fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2eselected.0(ptr %v5), !dbg !174
    #dbg_value(ptr %v9, !175, !DIExpression(), !176)
  %v10 = call fastcc ptr @topal.identity.topal.fn.support_2eprocess_2didentity_2efollowing.1(ptr %v9), !dbg !177
    #dbg_value(ptr %v10, !178, !DIExpression(), !179)
  %v11 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v1, 0, !dbg !180
  %v12 = insertvalue { ptr, i1, i32, i32 } %v11, i1 %v2, 1, !dbg !181
  %v13 = insertvalue { ptr, i1, i32, i32 } %v12, i32 %v3, 2, !dbg !182
  %v14 = insertvalue { ptr, i1, i32, i32 } %v13, i32 %v4, 3, !dbg !183
  %v15 = call fastcc { ptr, i1, i32, i32 } @topal.identity.topal.fn.support_2eidentity_2dhistory_2efollowing.3({ ptr, i1, i32, i32 } %v14, ptr %v9), !dbg !184
  %v16 = extractvalue { ptr, i1, i32, i32 } %v15, 0, !dbg !185
  %v17 = extractvalue { ptr, i1, i32, i32 } %v15, 1, !dbg !186
  %v18 = extractvalue { ptr, i1, i32, i32 } %v15, 2, !dbg !187
  %v19 = extractvalue { ptr, i1, i32, i32 } %v15, 3, !dbg !188
  %v20 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v16, 0, !dbg !189
  %v21 = insertvalue { ptr, i1, i32, i32 } %v20, i1 %v17, 1, !dbg !190
  %v22 = insertvalue { ptr, i1, i32, i32 } %v21, i32 %v18, 2, !dbg !191
  %v23 = insertvalue { ptr, i1, i32, i32 } %v22, i32 %v19, 3, !dbg !192
  %v24 = alloca { ptr, i1, i32, i32 }, align 8, !dbg !195
  store { ptr, i1, i32, i32 } %v23, ptr %v24, align 8, !dbg !196
    #dbg_declare(ptr %v24, !193, !DIExpression(), !194)
  %v25 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } poison, ptr %v9, 0, !dbg !198
  %v26 = insertvalue { ptr, i1, i32, i32 } poison, ptr %v16, 0, !dbg !199
  %v27 = insertvalue { ptr, i1, i32, i32 } %v26, i1 %v17, 1, !dbg !200
  %v28 = insertvalue { ptr, i1, i32, i32 } %v27, i32 %v18, 2, !dbg !201
  %v29 = insertvalue { ptr, i1, i32, i32 } %v28, i32 %v19, 3, !dbg !202
  %v30 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } poison, { ptr, i1, i32, i32 } %v29, 0, !dbg !203
  %v31 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v30, ptr %v10, 1, !dbg !204
  %v32 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v31, i32 1, 2, !dbg !205
  %v33 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v32, i32 0, 3, !dbg !206
  %v34 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v25, { { ptr, i1, i32, i32 }, ptr, i32, i32 } %v33, 1, !dbg !207
  %v35 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v34, i32 0, 2, !dbg !208
  %v36 = insertvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v35, i32 1, 3, !dbg !209
  ret { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %v36, !dbg !197
}

define { i64, i64 } @topal_kernel_structured_process_identity_policy_v1(i64 %cursor, ptr %store, i64 %owner, i64 %code) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %cursor.zero = icmp eq i64 %cursor, 0
  %cursor.minimum = icmp uge i64 %cursor, 2
  %cursor.maximum = icmp ule i64 %cursor, 2147483647
  %cursor.range = and i1 %cursor.minimum, %cursor.maximum
  %cursor.valid = or i1 %cursor.zero, %cursor.range
  %store.address = ptrtoint ptr %store to i64
  %store.end = add i64 %store.address, 4096
  %store.nonnull = icmp ne ptr %store, null
  %store.nonwrapping = icmp ugt i64 %store.end, %store.address
  %store.alignment = and i64 %store.address, 4095
  %store.aligned = icmp eq i64 %store.alignment, 0
  %owner.nonzero = icmp ne i64 %owner, 0
  %code.nonzero = icmp ne i64 %code, 0
  %entry.a = and i1 %cursor.valid, %store.nonnull
  %entry.b = and i1 %store.nonwrapping, %store.aligned
  %entry.c = and i1 %owner.nonzero, %code.nonzero
  %entry.d = and i1 %entry.a, %entry.b
  %entry.valid = and i1 %entry.d, %entry.c
  br i1 %entry.valid, label %header, label %invalid
header:
  %stored.owner.address = getelementptr i8, ptr %store, i64 0
  %stored.owner = load i64, ptr %stored.owner.address, align 8
  %stored.code.address = getelementptr i8, ptr %store, i64 8
  %stored.code = load i64, ptr %stored.code.address, align 8
  %stored.initialized.address = getelementptr i8, ptr %store, i64 16
  %stored.initialized = load i64, ptr %stored.initialized.address, align 8
  %stored.bank.address = getelementptr i8, ptr %store, i64 24
  %stored.bank = load i64, ptr %stored.bank.address, align 8
  %stored.epoch.address = getelementptr i8, ptr %store, i64 32
  %stored.epoch = load i64, ptr %stored.epoch.address, align 8
  %stored.prepared.address = getelementptr i8, ptr %store, i64 40
  %stored.prepared = load i64, ptr %stored.prepared.address, align 8
  %stored.prepared_bank.address = getelementptr i8, ptr %store, i64 48
  %stored.prepared_bank = load i64, ptr %stored.prepared_bank.address, align 8
  %stored.prepared_next.address = getelementptr i8, ptr %store, i64 56
  %stored.prepared_next = load i64, ptr %stored.prepared_next.address, align 8
  %owner.matches = icmp eq i64 %stored.owner, %owner
  %code.matches = icmp eq i64 %stored.code, %code
  %initialized.valid = icmp ule i64 %stored.initialized, 1
  %bank.valid = icmp ule i64 %stored.bank, 1
  %epoch.available = icmp ult i64 %stored.epoch, 18446744073709551615
  %prepared.clear = icmp eq i64 %stored.prepared, 0
  %prepared.bank.clear = icmp eq i64 %stored.prepared_bank, 0
  %prepared.next.clear = icmp eq i64 %stored.prepared_next, 0
  %header.valid.0 = and i1 %owner.matches, %code.matches
  %header.valid.1 = and i1 %header.valid.0, %initialized.valid
  %header.valid.2 = and i1 %header.valid.1, %bank.valid
  %header.valid.3 = and i1 %header.valid.2, %epoch.available
  %header.valid.4 = and i1 %header.valid.3, %prepared.clear
  %header.valid.5 = and i1 %header.valid.4, %prepared.bank.clear
  %header.valid.6 = and i1 %header.valid.5, %prepared.next.clear
  br i1 %header.valid.6, label %banks, label %invalid
banks:
  %bank.zero = icmp eq i64 %stored.bank, 0
  %bank.first = getelementptr i8, ptr %store, i64 64
  %bank.second = getelementptr i8, ptr %store, i64 2080
  %published.bank = select i1 %bank.zero, ptr %bank.first, ptr %bank.second
  %prepared.bank = select i1 %bank.zero, ptr %bank.second, ptr %bank.first
  %prepared.index = xor i64 %stored.bank, 1
  br label %inactive.scan
inactive.scan:
  %inactive.index = phi i64 [ 0, %banks ], [ %inactive.next, %inactive.advance ]
  %inactive.scaled = mul i64 %inactive.index, 8
  %inactive.offset = add i64 %inactive.scaled, 0
  %inactive.address = getelementptr i8, ptr %prepared.bank, i64 %inactive.offset
  %inactive.word = load i64, ptr %inactive.address, align 8
  %inactive.zero = icmp eq i64 %inactive.word, 0
  br i1 %inactive.zero, label %inactive.advance, label %invalid
inactive.advance:
  %inactive.next = add i64 %inactive.index, 1
  %inactive.more = icmp ult i64 %inactive.next, 252
  br i1 %inactive.more, label %inactive.scan, label %inactive.clean
inactive.clean:
  %uninitialized = icmp eq i64 %stored.initialized, 0
  br i1 %uninitialized, label %initial.guard, label %published.guard
initial.guard:
  %epoch.zero = icmp eq i64 %stored.epoch, 0
  %initial.a = and i1 %epoch.zero, %bank.zero
  %initial.valid = and i1 %initial.a, %cursor.zero
  br i1 %initial.valid, label %initial.bank, label %invalid
initial.bank:
  br label %initial.scan
initial.scan:
  %initial.index = phi i64 [ 0, %initial.bank ], [ %initial.next, %initial.advance ]
  %initial.scaled = mul i64 %initial.index, 8
  %initial.offset = add i64 %initial.scaled, 0
  %initial.address = getelementptr i8, ptr %published.bank, i64 %initial.offset
  %initial.word = load i64, ptr %initial.address, align 8
  %initial.zero = icmp eq i64 %initial.word, 0
  br i1 %initial.zero, label %initial.advance, label %invalid
initial.advance:
  %initial.next = add i64 %initial.index, 1
  %initial.more = icmp ult i64 %initial.next, 252
  br i1 %initial.more, label %initial.scan, label %initial.view
initial.view:
  %initial.number.0 = call ptr @topal.pid.runtime.int.from.u64(i64 0)
  %initial.number.1 = call ptr @topal.pid.runtime.int.from.u64(i64 0)
  %initial.field.0 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } undef, ptr %initial.number.0, 0, 0
  %initial.field.1 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.0, ptr %initial.number.1, 1
  %initial.field.2 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.1, i1 false, 0, 1
  %initial.field.3 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.2, i32 0, 2
  %initial.field.4 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.3, i32 1, 3
  %initial.field.5 = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.4, i32 0, 0, 2
  %initial.state = insertvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %initial.field.5, i32 1, 0, 3
  br label %invoke
published.guard:
  %epoch.nonzero = icmp ne i64 %stored.epoch, 0
  %published.valid = and i1 %epoch.nonzero, %cursor.range
  br i1 %published.valid, label %published.graph, label %invalid
published.graph:
  %published.word.0.address = getelementptr i8, ptr %published.bank, i64 0
  %published.word.0 = load i64, ptr %published.word.0.address, align 8
  %published.word.1.address = getelementptr i8, ptr %published.bank, i64 8
  %published.word.1 = load i64, ptr %published.word.1.address, align 8
  %published.word.2.address = getelementptr i8, ptr %published.bank, i64 16
  %published.word.2 = load i64, ptr %published.word.2.address, align 8
  %published.word.3.address = getelementptr i8, ptr %published.bank, i64 24
  %published.word.3 = load i64, ptr %published.word.3.address, align 8
  %published.word.4.address = getelementptr i8, ptr %published.bank, i64 32
  %published.word.4 = load i64, ptr %published.word.4.address, align 8
  %published.word.5.address = getelementptr i8, ptr %published.bank, i64 40
  %published.word.5 = load i64, ptr %published.word.5.address, align 8
  %published.word.6.address = getelementptr i8, ptr %published.bank, i64 48
  %published.word.6 = load i64, ptr %published.word.6.address, align 8
  %published.word.7.address = getelementptr i8, ptr %published.bank, i64 56
  %published.word.7 = load i64, ptr %published.word.7.address, align 8
  %published.word.8.address = getelementptr i8, ptr %published.bank, i64 64
  %published.word.8 = load i64, ptr %published.word.8.address, align 8
  %published.word.9.address = getelementptr i8, ptr %published.bank, i64 72
  %published.word.9 = load i64, ptr %published.word.9.address, align 8
  %published.word.10.address = getelementptr i8, ptr %published.bank, i64 80
  %published.word.10 = load i64, ptr %published.word.10.address, align 8
  %input.number.0.node = getelementptr i8, ptr %published.bank, i64 40
  %input.number.0.address = ptrtoint ptr %input.number.0.node to i64
  %input.number.0.pointer = icmp eq i64 %published.word.0, %input.number.0.address
  %input.number.0.sign = icmp eq i64 %published.word.5, 0
  %input.number.0.one = icmp eq i64 %published.word.6, 1
  %input.number.0.two = icmp eq i64 %published.word.6, 2
  %input.number.0.low = icmp ule i64 %published.word.7, 4294967295
  %input.number.0.high = icmp ugt i64 %published.word.7, 4294967295
  %input.number.0.single = and i1 %input.number.0.one, %input.number.0.low
  %input.number.0.double = and i1 %input.number.0.two, %input.number.0.high
  %input.number.0.normal = or i1 %input.number.0.single, %input.number.0.double
  %input.number.0.minimum = icmp uge i64 %published.word.7, 1
  %input.number.0.maximum = icmp ule i64 %published.word.7, 18446744073709551614
  %input.number.1.node = getelementptr i8, ptr %published.bank, i64 64
  %input.number.1.address = ptrtoint ptr %input.number.1.node to i64
  %input.number.1.pointer = icmp eq i64 %published.word.3, %input.number.1.address
  %input.number.1.sign = icmp eq i64 %published.word.8, 0
  %input.number.1.one = icmp eq i64 %published.word.9, 1
  %input.number.1.two = icmp eq i64 %published.word.9, 2
  %input.number.1.low = icmp ule i64 %published.word.10, 4294967295
  %input.number.1.high = icmp ugt i64 %published.word.10, 4294967295
  %input.number.1.single = and i1 %input.number.1.one, %input.number.1.low
  %input.number.1.double = and i1 %input.number.1.two, %input.number.1.high
  %input.number.1.normal = or i1 %input.number.1.single, %input.number.1.double
  %input.number.1.minimum = icmp uge i64 %published.word.10, 2
  %input.number.1.maximum = icmp ule i64 %published.word.10, 2147483647
  %input.cursor.matches = icmp eq i64 %published.word.10, %cursor
  %input.padding.0.bits = and i64 %published.word.1, 4294967294
  %input.padding.0.clean = icmp eq i64 %input.padding.0.bits, 0
  %input.padding.1.bits = and i64 %published.word.2, 18446744069414584320
  %input.padding.1.clean = icmp eq i64 %input.padding.1.bits, 0
  %input.order.0.0 = trunc i64 %published.word.4 to i32
  %input.order.0.1.shifted = lshr i64 %published.word.4, 32
  %input.order.0.1 = trunc i64 %input.order.0.1.shifted to i32
  %input.order.0.range.0 = icmp ult i32 %input.order.0.0, 2
  %input.order.0.range.1 = icmp ult i32 %input.order.0.1, 2
  %input.order.0.distinct.1.0 = icmp ne i32 %input.order.0.1, %input.order.0.0
  %input.order.1.0.shifted = lshr i64 %published.word.1, 32
  %input.order.1.0 = trunc i64 %input.order.1.0.shifted to i32
  %input.order.1.1 = trunc i64 %published.word.2 to i32
  %input.order.1.range.0 = icmp ult i32 %input.order.1.0, 2
  %input.order.1.range.1 = icmp ult i32 %input.order.1.1, 2
  %input.order.1.distinct.1.0 = icmp ne i32 %input.order.1.1, %input.order.1.0
  %input.graph.combined.1 = and i1 %input.number.0.pointer, %input.number.0.sign
  %input.graph.combined.2 = and i1 %input.graph.combined.1, %input.number.0.normal
  %input.graph.combined.3 = and i1 %input.graph.combined.2, %input.number.0.minimum
  %input.graph.combined.4 = and i1 %input.graph.combined.3, %input.number.0.maximum
  %input.graph.combined.5 = and i1 %input.graph.combined.4, %input.number.1.pointer
  %input.graph.combined.6 = and i1 %input.graph.combined.5, %input.number.1.sign
  %input.graph.combined.7 = and i1 %input.graph.combined.6, %input.number.1.normal
  %input.graph.combined.8 = and i1 %input.graph.combined.7, %input.number.1.minimum
  %input.graph.combined.9 = and i1 %input.graph.combined.8, %input.number.1.maximum
  %input.graph.combined.10 = and i1 %input.graph.combined.9, %input.cursor.matches
  %input.graph.combined.11 = and i1 %input.graph.combined.10, %input.padding.0.clean
  %input.graph.combined.12 = and i1 %input.graph.combined.11, %input.padding.1.clean
  %input.graph.combined.13 = and i1 %input.graph.combined.12, %input.order.0.range.0
  %input.graph.combined.14 = and i1 %input.graph.combined.13, %input.order.0.range.1
  %input.graph.combined.15 = and i1 %input.graph.combined.14, %input.order.0.distinct.1.0
  %input.graph.combined.16 = and i1 %input.graph.combined.15, %input.order.1.range.0
  %input.graph.combined.17 = and i1 %input.graph.combined.16, %input.order.1.range.1
  %input.graph.combined.18 = and i1 %input.graph.combined.17, %input.order.1.distinct.1.0
  br i1 %input.graph.combined.18, label %published.tail, label %invalid
published.tail:
  br label %tail.scan
tail.scan:
  %tail.index = phi i64 [ 0, %published.tail ], [ %tail.next, %tail.advance ]
  %tail.scaled = mul i64 %tail.index, 8
  %tail.offset = add i64 %tail.scaled, 88
  %tail.address = getelementptr i8, ptr %published.bank, i64 %tail.offset
  %tail.word = load i64, ptr %tail.address, align 8
  %tail.zero = icmp eq i64 %tail.word, 0
  br i1 %tail.zero, label %tail.advance, label %invalid
tail.advance:
  %tail.next = add i64 %tail.index, 1
  %tail.more = icmp ult i64 %tail.next, 241
  br i1 %tail.more, label %tail.scan, label %published.view
published.view:
  %published.state = load { { ptr, i1, i32, i32 }, ptr, i32, i32 }, ptr %published.bank, align 8
  br label %invoke
invoke:
  %state = phi { { ptr, i1, i32, i32 }, ptr, i32, i32 } [ %initial.state, %initial.view ], [ %published.state, %published.view ]
  %result = call fastcc { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } @topal.identity.topal.fn.process_2didentity.4({ { ptr, i1, i32, i32 }, ptr, i32, i32 } %state)
  %source.state = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 1
  %source.result.order.0 = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 2
  %source.result.order.1 = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 3
  %source.outer.range.0 = icmp ult i32 %source.result.order.0, 2
  %source.outer.range.1 = icmp ult i32 %source.result.order.1, 2
  %source.outer.distinct.1.0 = icmp ne i32 %source.result.order.1, %source.result.order.0
  %source.state.order.0.0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 2
  %source.state.order.0.1 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 3
  %source.state.order.0.range.0 = icmp ult i32 %source.state.order.0.0, 2
  %source.state.order.0.range.1 = icmp ult i32 %source.state.order.0.1, 2
  %source.state.order.0.distinct.1.0 = icmp ne i32 %source.state.order.0.1, %source.state.order.0.0
  %source.state.order.1.0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 2
  %source.state.order.1.1 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 3
  %source.state.order.1.range.0 = icmp ult i32 %source.state.order.1.0, 2
  %source.state.order.1.range.1 = icmp ult i32 %source.state.order.1.1, 2
  %source.state.order.1.distinct.1.0 = icmp ne i32 %source.state.order.1.1, %source.state.order.1.0
  %source.order.combined.1 = and i1 %source.outer.range.0, %source.outer.range.1
  %source.order.combined.2 = and i1 %source.order.combined.1, %source.outer.distinct.1.0
  %source.order.combined.3 = and i1 %source.order.combined.2, %source.state.order.0.range.0
  %source.order.combined.4 = and i1 %source.order.combined.3, %source.state.order.0.range.1
  %source.order.combined.5 = and i1 %source.order.combined.4, %source.state.order.0.distinct.1.0
  %source.order.combined.6 = and i1 %source.order.combined.5, %source.state.order.1.range.0
  %source.order.combined.7 = and i1 %source.order.combined.6, %source.state.order.1.range.1
  %source.order.combined.8 = and i1 %source.order.combined.7, %source.state.order.1.distinct.1.0
  br i1 %source.order.combined.8, label %source.numbers, label %invalid
source.numbers:
  %allocated.object = extractvalue { ptr, { { ptr, i1, i32, i32 }, ptr, i32, i32 }, i32, i32 } %result, 0
  %allocated.sign.address = getelementptr i8, ptr %allocated.object, i64 0
  %allocated.length.address = getelementptr i8, ptr %allocated.object, i64 8
  %allocated.sign = load i64, ptr %allocated.sign.address, align 8
  %allocated.length = load i64, ptr %allocated.length.address, align 8
  %allocated.positive = icmp eq i64 %allocated.sign, 0
  %allocated.nonempty = icmp uge i64 %allocated.length, 1
  %allocated.bounded = icmp ule i64 %allocated.length, 1
  %allocated.shape.a = and i1 %allocated.positive, %allocated.nonempty
  %allocated.shape = and i1 %allocated.shape.a, %allocated.bounded
  br i1 %allocated.shape, label %allocated.low, label %invalid
allocated.low:
  %allocated.low.address = getelementptr i8, ptr %allocated.object, i64 16
  %allocated.low.word = load i32, ptr %allocated.low.address, align 4
  %allocated.low.value = zext i32 %allocated.low.word to i64
  %allocated.single = icmp eq i64 %allocated.length, 1
  br i1 %allocated.single, label %allocated.check, label %allocated.high
allocated.high:
  %allocated.high.address = getelementptr i8, ptr %allocated.object, i64 20
  %allocated.high.word = load i32, ptr %allocated.high.address, align 4
  %allocated.high.nonzero = icmp ne i32 %allocated.high.word, 0
  br i1 %allocated.high.nonzero, label %allocated.high.valid, label %invalid
allocated.high.valid:
  %allocated.high.value = zext i32 %allocated.high.word to i64
  %allocated.shifted = shl i64 %allocated.high.value, 32
  %allocated.combined = or i64 %allocated.low.value, %allocated.shifted
  br label %allocated.check
allocated.check:
  %allocated.value = phi i64 [ %allocated.low.value, %allocated.low ], [ %allocated.combined, %allocated.high.valid ]
  %allocated.minimum = icmp uge i64 %allocated.value, 2
  %allocated.maximum = icmp ule i64 %allocated.value, 2147483647
  %allocated.range = and i1 %allocated.minimum, %allocated.maximum
  br i1 %allocated.range, label %allocated.ready, label %invalid
allocated.ready:
  %creations.object = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 0
  %creations.sign.address = getelementptr i8, ptr %creations.object, i64 0
  %creations.length.address = getelementptr i8, ptr %creations.object, i64 8
  %creations.sign = load i64, ptr %creations.sign.address, align 8
  %creations.length = load i64, ptr %creations.length.address, align 8
  %creations.positive = icmp eq i64 %creations.sign, 0
  %creations.nonempty = icmp uge i64 %creations.length, 1
  %creations.bounded = icmp ule i64 %creations.length, 2
  %creations.shape.a = and i1 %creations.positive, %creations.nonempty
  %creations.shape = and i1 %creations.shape.a, %creations.bounded
  br i1 %creations.shape, label %creations.low, label %invalid
creations.low:
  %creations.low.address = getelementptr i8, ptr %creations.object, i64 16
  %creations.low.word = load i32, ptr %creations.low.address, align 4
  %creations.low.value = zext i32 %creations.low.word to i64
  %creations.single = icmp eq i64 %creations.length, 1
  br i1 %creations.single, label %creations.check, label %creations.high
creations.high:
  %creations.high.address = getelementptr i8, ptr %creations.object, i64 20
  %creations.high.word = load i32, ptr %creations.high.address, align 4
  %creations.high.nonzero = icmp ne i32 %creations.high.word, 0
  br i1 %creations.high.nonzero, label %creations.high.valid, label %invalid
creations.high.valid:
  %creations.high.value = zext i32 %creations.high.word to i64
  %creations.shifted = shl i64 %creations.high.value, 32
  %creations.combined = or i64 %creations.low.value, %creations.shifted
  br label %creations.check
creations.check:
  %creations.value = phi i64 [ %creations.low.value, %creations.low ], [ %creations.combined, %creations.high.valid ]
  %creations.minimum = icmp uge i64 %creations.value, 1
  %creations.maximum = icmp ule i64 %creations.value, 18446744073709551615
  %creations.range = and i1 %creations.minimum, %creations.maximum
  br i1 %creations.range, label %creations.ready, label %invalid
creations.ready:
  %next.object = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 1
  %next.sign.address = getelementptr i8, ptr %next.object, i64 0
  %next.length.address = getelementptr i8, ptr %next.object, i64 8
  %next.sign = load i64, ptr %next.sign.address, align 8
  %next.length = load i64, ptr %next.length.address, align 8
  %next.positive = icmp eq i64 %next.sign, 0
  %next.nonempty = icmp uge i64 %next.length, 1
  %next.bounded = icmp ule i64 %next.length, 1
  %next.shape.a = and i1 %next.positive, %next.nonempty
  %next.shape = and i1 %next.shape.a, %next.bounded
  br i1 %next.shape, label %next.low, label %invalid
next.low:
  %next.low.address = getelementptr i8, ptr %next.object, i64 16
  %next.low.word = load i32, ptr %next.low.address, align 4
  %next.low.value = zext i32 %next.low.word to i64
  %next.single = icmp eq i64 %next.length, 1
  br i1 %next.single, label %next.check, label %next.high
next.high:
  %next.high.address = getelementptr i8, ptr %next.object, i64 20
  %next.high.word = load i32, ptr %next.high.address, align 4
  %next.high.nonzero = icmp ne i32 %next.high.word, 0
  br i1 %next.high.nonzero, label %next.high.valid, label %invalid
next.high.valid:
  %next.high.value = zext i32 %next.high.word to i64
  %next.shifted = shl i64 %next.high.value, 32
  %next.combined = or i64 %next.low.value, %next.shifted
  br label %next.check
next.check:
  %next.value = phi i64 [ %next.low.value, %next.low ], [ %next.combined, %next.high.valid ]
  %next.minimum = icmp uge i64 %next.value, 2
  %next.maximum = icmp ule i64 %next.value, 2147483647
  %next.range = and i1 %next.minimum, %next.maximum
  br i1 %next.range, label %next.ready, label %invalid
next.ready:
  %source.boolean.0 = extractvalue { { ptr, i1, i32, i32 }, ptr, i32, i32 } %source.state, 0, 1
  %source.boolean.byte.0 = zext i1 %source.boolean.0 to i8
  %prepared.number.0.node = getelementptr i8, ptr %prepared.bank, i64 40
  %prepared.number.0.field = getelementptr i8, ptr %prepared.bank, i64 0
  store ptr %prepared.number.0.node, ptr %prepared.number.0.field, align 8
  store i64 0, ptr %prepared.number.0.node, align 8
  %prepared.number.0.length = getelementptr i8, ptr %prepared.number.0.node, i64 8
  store i64 %creations.length, ptr %prepared.number.0.length, align 8
  %prepared.number.0.data = getelementptr i8, ptr %prepared.number.0.node, i64 16
  store i64 %creations.value, ptr %prepared.number.0.data, align 8
  %prepared.number.1.node = getelementptr i8, ptr %prepared.bank, i64 64
  %prepared.number.1.field = getelementptr i8, ptr %prepared.bank, i64 24
  store ptr %prepared.number.1.node, ptr %prepared.number.1.field, align 8
  store i64 0, ptr %prepared.number.1.node, align 8
  %prepared.number.1.length = getelementptr i8, ptr %prepared.number.1.node, i64 8
  store i64 %next.length, ptr %prepared.number.1.length, align 8
  %prepared.number.1.data = getelementptr i8, ptr %prepared.number.1.node, i64 16
  store i64 %next.value, ptr %prepared.number.1.data, align 8
  %prepared.boolean.0 = getelementptr i8, ptr %prepared.bank, i64 8
  store i8 %source.boolean.byte.0, ptr %prepared.boolean.0, align 1
  %prepared.order.0.0 = getelementptr i8, ptr %prepared.bank, i64 32
  store i32 %source.state.order.0.0, ptr %prepared.order.0.0, align 4
  %prepared.order.0.1 = getelementptr i8, ptr %prepared.bank, i64 36
  store i32 %source.state.order.0.1, ptr %prepared.order.0.1, align 4
  %prepared.order.1.0 = getelementptr i8, ptr %prepared.bank, i64 12
  store i32 %source.state.order.1.0, ptr %prepared.order.1.0, align 4
  %prepared.order.1.1 = getelementptr i8, ptr %prepared.bank, i64 16
  store i32 %source.state.order.1.1, ptr %prepared.order.1.1, align 4
  store i64 %prepared.index, ptr %stored.prepared_bank.address, align 8
  store i64 %next.value, ptr %stored.prepared_next.address, align 8
  store i64 1, ptr %stored.prepared.address, align 8
  %first = insertvalue { i64, i64 } undef, i64 %allocated.value, 0
  %both = insertvalue { i64, i64 } %first, i64 %next.value, 1
  ret { i64, i64 } %both
invalid:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!210, !211}
!llvm.ident = !{!212}
!0 = !DIFile(filename: "structured-process-identity.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!1 = !{}
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !0, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !1, retainedTypes: !1)
!3 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!4 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!5 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!6 = !{!4, !5}
!7 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !0, size: 128, align: 64, elements: !6)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64, align: 64)
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !0, baseType: !8)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !0, baseType: !8)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "major", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "minor", file: !0, baseType: !10, size: 64, align: 64, offset: 64)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "patch", file: !0, baseType: !10, size: 64, align: 64, offset: 128)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "build", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!15 = !{!11, !12, !13, !14}
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalVersionHeader", file: !0, size: 256, align: 64, elements: !15)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "Version", file: !0, baseType: !17)
!19 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !20, size: 64, align: 64, offset: 0)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "byte_count", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!23 = !{!21, !22}
!24 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSerializationStreamHeader", file: !0, size: 128, align: 64, elements: !23)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64, align: 64)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "SerializationStream", file: !0, baseType: !25)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "numerator", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "denominator", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!29 = !{!27, !28}
!30 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRationalHeader", file: !0, size: 128, align: 64, elements: !29)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !30, size: 64, align: 64)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "Rational", file: !0, baseType: !31)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!37 = !{!33, !34, !35, !36}
!38 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeIntHeader", file: !0, size: 256, align: 64, elements: !37)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 64, align: 64)
!40 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Int", file: !0, baseType: !39)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !32, size: 64, align: 64, offset: 0)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !32, size: 64, align: 64, offset: 64)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!45 = !{!41, !42, !43, !44}
!46 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeRationalHeader", file: !0, size: 256, align: 64, elements: !45)
!47 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !46, size: 64, align: 64)
!48 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Rational", file: !0, baseType: !47)
!49 = !DIDerivedType(tag: DW_TAG_member, name: "is_error", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !50, size: 64, align: 64, offset: 64)
!52 = !{!49, !51}
!53 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalResultHeader", file: !0, size: 128, align: 64, elements: !52)
!54 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !53, size: 64, align: 64)
!55 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Int, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!56 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Nat, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Rational, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!58 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (String, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!59 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result ((Int, Int), lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!60 = !DIEnumerator(name: "Less", value: -1)
!61 = !DIEnumerator(name: "Equal", value: 0)
!62 = !DIEnumerator(name: "Greater", value: 1)
!63 = !{!60, !61, !62}
!64 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Comparison", file: !0, size: 32, align: 32, elements: !63)
!65 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!66 = !DIBasicType(name: "Unit", size: 8, encoding: DW_ATE_unsigned)
!67 = !DIEnumerator(name: "Completed", value: 0)
!68 = !{!67}
!69 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Completed", file: !0, size: 8, align: 8, elements: !68)
!70 = !DIEnumerator(name: "empty", value: 0)
!71 = !{!70}
!72 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Effect", file: !0, size: 8, align: 8, elements: !71)
!73 = !DIFile(filename: "identity-history.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!74 = !DIFile(filename: "process-identity.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!75 = !{!10, !10}
!76 = !DISubroutineType(types: !75)
!77 = distinct !DISubprogram(name: "support.process-identity.selected", linkageName: "topal.identity.topal.fn.support_2eprocess_2didentity_2eselected.0", scope: !74, file: !74, line: 3, type: !76, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!78 = !DILocalVariable(name: "cursor", arg: 1, scope: !77, file: !74, line: 3, type: !10)
!79 = !DILocation(line: 3, column: 21, scope: !77)
!80 = !DILocalVariable(name: "initial", scope: !77, file: !74, line: 4, type: !10)
!81 = !DILocation(line: 4, column: 3, scope: !77)
!82 = !DILocation(line: 5, column: 3, scope: !77)
!83 = !DILocation(line: 5, column: 3, scope: !77)
!84 = !DILocation(line: 5, column: 3, scope: !77)
!85 = !DILocation(line: 5, column: 3, scope: !77)
!86 = !DILocation(line: 6, column: 15, scope: !77)
!87 = !DILocation(line: 7, column: 16, scope: !77)
!88 = !DILocation(line: 5, column: 3, scope: !77)
!89 = !DILocation(line: 5, column: 3, scope: !77)
!90 = !{!10, !10}
!91 = !DISubroutineType(types: !90)
!92 = distinct !DISubprogram(name: "support.process-identity.following", linkageName: "topal.identity.topal.fn.support_2eprocess_2didentity_2efollowing.1", scope: !74, file: !74, line: 9, type: !91, scopeLine: 9, spFlags: DISPFlagDefinition, unit: !2)
!93 = !DILocalVariable(name: "allocated", arg: 1, scope: !92, file: !74, line: 9, type: !10)
!94 = !DILocation(line: 9, column: 22, scope: !92)
!95 = !DILocalVariable(name: "one", scope: !92, file: !74, line: 10, type: !10)
!96 = !DILocation(line: 10, column: 3, scope: !92)
!97 = !DILocalVariable(name: "initial", scope: !92, file: !74, line: 11, type: !10)
!98 = !DILocation(line: 11, column: 3, scope: !92)
!99 = !DILocation(line: 12, column: 3, scope: !92)
!100 = !DILocation(line: 12, column: 3, scope: !92)
!101 = !DILocation(line: 12, column: 3, scope: !92)
!102 = !DILocation(line: 12, column: 3, scope: !92)
!103 = !DILocation(line: 13, column: 15, scope: !92)
!104 = !DILocation(line: 14, column: 16, scope: !92)
!105 = !DILocation(line: 14, column: 16, scope: !92)
!106 = !DILocation(line: 12, column: 3, scope: !92)
!107 = !DILocation(line: 12, column: 3, scope: !92)
!108 = !{!65, !65, !10}
!109 = !DISubroutineType(types: !108)
!110 = distinct !DISubprogram(name: "support.identity-history.retain-wrap", linkageName: "topal.identity.topal.fn.support_2eidentity_2dhistory_2eretain_2dwrap.2", scope: !73, file: !73, line: 3, type: !109, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!111 = !DILocalVariable(name: "previous", arg: 1, scope: !110, file: !73, line: 3, type: !65)
!112 = !DILocation(line: 3, column: 20, scope: !110)
!113 = !DILocalVariable(name: "allocated", arg: 2, scope: !110, file: !73, line: 3, type: !10)
!114 = !DILocation(line: 3, column: 40, scope: !110)
!115 = !DILocation(line: 4, column: 3, scope: !110)
!116 = !DILocation(line: 5, column: 15, scope: !110)
!117 = !DILocation(line: 6, column: 16, scope: !110)
!118 = !DILocation(line: 6, column: 16, scope: !110)
!119 = !DILocation(line: 6, column: 16, scope: !110)
!120 = !DILocation(line: 6, column: 16, scope: !110)
!121 = !DILocation(line: 4, column: 3, scope: !110)
!122 = !DILocation(line: 4, column: 3, scope: !110)
!123 = !DIDerivedType(tag: DW_TAG_member, name: "creations", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!124 = !DIDerivedType(tag: DW_TAG_member, name: "wrapped", file: !0, baseType: !65, size: 8, align: 8, offset: 64)
!125 = !{!123, !124}
!126 = !DICompositeType(tag: DW_TAG_structure_type, name: "(creations : Nat, wrapped : Boolean)", file: !0, size: 192, align: 64, elements: !125)
!127 = !{!126, !126, !10}
!128 = !DISubroutineType(types: !127)
!129 = distinct !DISubprogram(name: "support.identity-history.following", linkageName: "topal.identity.topal.fn.support_2eidentity_2dhistory_2efollowing.3", scope: !73, file: !73, line: 8, type: !128, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !2)
!130 = !DILocation(line: 9, column: 3, scope: !129)
!131 = !DILocation(line: 9, column: 3, scope: !129)
!132 = !DILocation(line: 9, column: 3, scope: !129)
!133 = !DILocation(line: 9, column: 3, scope: !129)
!134 = !DILocalVariable(name: "current", arg: 1, scope: !129, file: !73, line: 9, type: !126)
!135 = !DILocation(line: 9, column: 3, scope: !129)
!136 = !DILocalVariable(name: "allocated", arg: 2, scope: !129, file: !73, line: 10, type: !10)
!137 = !DILocation(line: 10, column: 3, scope: !129)
!138 = !DILocalVariable(name: "one", scope: !129, file: !73, line: 12, type: !10)
!139 = !DILocation(line: 12, column: 3, scope: !129)
!140 = !DILocation(line: 13, column: 17, scope: !129)
!141 = !DILocalVariable(name: "creations", scope: !129, file: !73, line: 13, type: !10)
!142 = !DILocation(line: 13, column: 3, scope: !129)
!143 = !DILocalVariable(name: "previous", scope: !129, file: !73, line: 14, type: !65)
!144 = !DILocation(line: 14, column: 3, scope: !129)
!145 = !DILocation(line: 15, column: 14, scope: !129)
!146 = !DILocalVariable(name: "wrapped", scope: !129, file: !73, line: 15, type: !65)
!147 = !DILocation(line: 15, column: 3, scope: !129)
!148 = !DILocation(line: 16, column: 3, scope: !129)
!149 = !DILocation(line: 16, column: 3, scope: !129)
!150 = !DILocation(line: 16, column: 3, scope: !129)
!151 = !DILocation(line: 16, column: 3, scope: !129)
!152 = !DILocation(line: 16, column: 3, scope: !129)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "allocated", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "history", file: !0, baseType: !126, size: 192, align: 64, offset: 0)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "next", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!156 = !{!154, !155}
!157 = !DICompositeType(tag: DW_TAG_structure_type, name: "(history : (creations : Nat, wrapped : Boolean), next : Nat)", file: !0, size: 320, align: 64, elements: !156)
!158 = !DIDerivedType(tag: DW_TAG_member, name: "state", file: !0, baseType: !157, size: 320, align: 64, offset: 64)
!159 = !{!153, !158}
!160 = !DICompositeType(tag: DW_TAG_structure_type, name: "(allocated : Nat, state : (history : (creations : Nat, wrapped : Boolean), next : Nat))", file: !0, size: 448, align: 64, elements: !159)
!161 = !{!160, !157}
!162 = !DISubroutineType(types: !161)
!163 = distinct !DISubprogram(name: "process-identity", linkageName: "topal.identity.topal.fn.process_2didentity.4", scope: !0, file: !0, line: 4, type: !162, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !2)
!164 = !DILocation(line: 5, column: 3, scope: !163)
!165 = !DILocation(line: 5, column: 3, scope: !163)
!166 = !DILocation(line: 5, column: 3, scope: !163)
!167 = !DILocation(line: 5, column: 3, scope: !163)
!168 = !DILocation(line: 5, column: 3, scope: !163)
!169 = !DILocation(line: 5, column: 3, scope: !163)
!170 = !DILocation(line: 5, column: 3, scope: !163)
!171 = !DILocation(line: 5, column: 3, scope: !163)
!172 = !DILocalVariable(name: "state", arg: 1, scope: !163, file: !0, line: 5, type: !157)
!173 = !DILocation(line: 5, column: 3, scope: !163)
!174 = !DILocation(line: 7, column: 16, scope: !163)
!175 = !DILocalVariable(name: "allocated", scope: !163, file: !0, line: 7, type: !10)
!176 = !DILocation(line: 7, column: 3, scope: !163)
!177 = !DILocation(line: 8, column: 16, scope: !163)
!178 = !DILocalVariable(name: "following", scope: !163, file: !0, line: 8, type: !10)
!179 = !DILocation(line: 8, column: 3, scope: !163)
!180 = !DILocation(line: 9, column: 14, scope: !163)
!181 = !DILocation(line: 9, column: 14, scope: !163)
!182 = !DILocation(line: 9, column: 14, scope: !163)
!183 = !DILocation(line: 9, column: 14, scope: !163)
!184 = !DILocation(line: 9, column: 14, scope: !163)
!185 = !DILocation(line: 9, column: 14, scope: !163)
!186 = !DILocation(line: 9, column: 14, scope: !163)
!187 = !DILocation(line: 9, column: 14, scope: !163)
!188 = !DILocation(line: 9, column: 14, scope: !163)
!189 = !DILocation(line: 9, column: 3, scope: !163)
!190 = !DILocation(line: 9, column: 3, scope: !163)
!191 = !DILocation(line: 9, column: 3, scope: !163)
!192 = !DILocation(line: 9, column: 3, scope: !163)
!193 = !DILocalVariable(name: "history", scope: !163, file: !0, line: 9, type: !126)
!194 = !DILocation(line: 9, column: 3, scope: !163)
!195 = !DILocation(line: 9, column: 3, scope: !163)
!196 = !DILocation(line: 9, column: 3, scope: !163)
!197 = !DILocation(line: 10, column: 3, scope: !163)
!198 = !DILocation(line: 10, column: 3, scope: !163)
!199 = !DILocation(line: 10, column: 3, scope: !163)
!200 = !DILocation(line: 10, column: 3, scope: !163)
!201 = !DILocation(line: 10, column: 3, scope: !163)
!202 = !DILocation(line: 10, column: 3, scope: !163)
!203 = !DILocation(line: 10, column: 3, scope: !163)
!204 = !DILocation(line: 10, column: 3, scope: !163)
!205 = !DILocation(line: 10, column: 3, scope: !163)
!206 = !DILocation(line: 10, column: 3, scope: !163)
!207 = !DILocation(line: 10, column: 3, scope: !163)
!208 = !DILocation(line: 10, column: 3, scope: !163)
!209 = !DILocation(line: 10, column: 3, scope: !163)
!210 = !{i32 2, !"Dwarf Version", i32 5}
!211 = !{i32 2, !"Debug Info Version", i32 3}
!212 = !{!"topalc 0.1.0"}
