; checked Topal numeric kernel library
source_filename = "static-linux-dispatch-v6.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

@llvm.used = appending global [1 x ptr] [ptr @topal.syscall.memset], section "llvm.metadata"
; Shared private topal-native/6 value algorithms.
; Platform allocation, write and termination hooks are supplied separately.
; Int values are immutable sign-and-magnitude objects with little-endian
; base-2^32 limbs. A zero has sign = 0 and length = 0. Root-local exact
; infinities use executable-private sign tags 2 (+) and 3 (-) with no limbs;
; Rational infinities wrap one sentinel over denominator one at run time. Those
; values are not admitted at a native function or library boundary.

%topal.StringStorage = type { ptr, i64, ptr, i64 }
%topal.IntStorage = type { i64, i64, [0 x i32] }

define internal ptr @topal.syscall.runtime.character.ascii.decimal.digit(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %single.byte = icmp eq i64 %length, 1
  br i1 %single.byte, label %load, label %none
load:
  %data.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 0
  %data = load ptr, ptr %data.pointer, align 8
  %byte = load i8, ptr %data, align 1
  %at.least.zero = icmp uge i8 %byte, 48
  %at.most.nine = icmp ule i8 %byte, 57
  %is.digit = and i1 %at.least.zero, %at.most.nine
  br i1 %is.digit, label %some, label %none
some:
  %digit.byte = sub i8 %byte, 48
  %digit = zext i8 %digit.byte to i64
  %value = call ptr @topal.syscall.runtime.int.from.u64(i64 %digit)
  %present = call ptr @topal.syscall.runtime.optional.some(ptr %value)
  ret ptr %present
none:
  %absent = call ptr @topal.syscall.runtime.optional.none()
  ret ptr %absent
}

define internal i1 @topal.syscall.runtime.character.unicode.whitespace(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.syscall.runtime.string.unicode.scalar.value(ptr %character)
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp eq i64 %length, 1
  br i1 %present, label %load, label %not.whitespace
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %scalar = load i32, ptr %limb.pointer, align 4
  %ascii.lower = icmp uge i32 %scalar, 9
  %ascii.upper = icmp ule i32 %scalar, 13
  %ascii.control = and i1 %ascii.lower, %ascii.upper
  %space = icmp eq i32 %scalar, 32
  %next.line = icmp eq i32 %scalar, 133
  %no.break = icmp eq i32 %scalar, 160
  %ogham = icmp eq i32 %scalar, 5760
  %quad.lower = icmp uge i32 %scalar, 8192
  %quad.upper = icmp ule i32 %scalar, 8202
  %quad = and i1 %quad.lower, %quad.upper
  %line.separator = icmp eq i32 %scalar, 8232
  %paragraph.separator = icmp eq i32 %scalar, 8233
  %narrow.no.break = icmp eq i32 %scalar, 8239
  %medium.math = icmp eq i32 %scalar, 8287
  %ideographic = icmp eq i32 %scalar, 12288
  %match.0 = or i1 %ascii.control, %space
  %match.1 = or i1 %match.0, %next.line
  %match.2 = or i1 %match.1, %no.break
  %match.3 = or i1 %match.2, %ogham
  %match.4 = or i1 %match.3, %quad
  %match.5 = or i1 %match.4, %line.separator
  %match.6 = or i1 %match.5, %paragraph.separator
  %match.7 = or i1 %match.6, %narrow.no.break
  %match.8 = or i1 %match.7, %medium.math
  %match.9 = or i1 %match.8, %ideographic
  ret i1 %match.9
not.whitespace:
  ret i1 false
}
%topal.IntDivmod = type { ptr, ptr }
%topal.RationalStorage = type { ptr, ptr }
%topal.RangeStorage = type { ptr, ptr, i64, i64 }
%topal.ResultStorage = type { i64, ptr }
%topal.OptionalStorage = type { i64, ptr }
%topal.ErrorStorage = type { ptr, i32, i32, ptr, ptr, ptr, i64, i64 }
%topal.SourceLocationStorage = type { ptr, ptr }
%topal.SerializationStreamStorage = type { ptr, i64 }
%topal.TaskStorage = type { i64, i64, ptr }
%topal.LocationStorage = type { ptr, ptr, i64, ptr }

@topal.syscall.runtime.int.zero = private constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.syscall.runtime.int.one = private constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.syscall.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.syscall.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.syscall.runtime.byte.zero = private constant [1 x i8] c"0", align 1
@topal.syscall.runtime.byte.minus = private constant [1 x i8] c"-", align 1
@topal.syscall.runtime.int.positive.infinity.text = private constant [9 x i8] c"+Infinity", align 1
@topal.syscall.runtime.int.negative.infinity.text = private constant [9 x i8] c"-Infinity", align 1
@topal.syscall.runtime.byte.quote = private constant [1 x i8] c"\22", align 1
@topal.syscall.runtime.byte.underscore = private constant [1 x i8] c"_", align 1
@topal.syscall.runtime.string.tag.text = private constant [4 x i8] c"text", align 1
@topal.syscall.runtime.rational.prefix = private constant [11 x i8] c"Rational ( ", align 1
@topal.syscall.runtime.rational.separator = private constant [2 x i8] c", ", align 1
@topal.syscall.runtime.rational.suffix = private constant [2 x i8] c" )", align 1
@topal.syscall.runtime.range.closed.open = private constant [4 x i8] c" .. ", align 1
@topal.syscall.runtime.range.open.open = private constant [5 x i8] c" <.. ", align 1
@topal.syscall.runtime.range.closed.closed = private constant [5 x i8] c" ..= ", align 1
@topal.syscall.runtime.range.open.closed = private constant [6 x i8] c" <..= ", align 1
@topal.syscall.runtime.error.prefix = private constant [18 x i8] c"Error ( domain is ", align 1
@topal.syscall.runtime.error.code.separator = private constant [10 x i8] c", code is ", align 1
@topal.syscall.runtime.error.suffix = private constant [2 x i8] c" )", align 1
@topal.syscall.runtime.error.code.out.of.range = private constant [12 x i8] c"out-of-range", align 1
@topal.syscall.runtime.error.code.not.representable = private constant [17 x i8] c"not-representable", align 1
@topal.syscall.runtime.error.code.division.by.zero = private constant [16 x i8] c"division-by-zero", align 1
@topal.syscall.runtime.error.code.indeterminate = private constant [13 x i8] c"indeterminate", align 1
@topal.syscall.runtime.pattern.identity.diagnostic = private constant [68 x i8] c"error[E-ANONYMOUS-PATTERN-IDENTITY]: repeated pattern values differ\0A", align 1
@topal.syscall.runtime.c.int32.range.diagnostic = private constant [71 x i8] c"error[E-C-ABI-RANGE]: Topal Int is not representable as a C signed int\0A", align 1
@topal.syscall.runtime.task.next.identity = private global i64 1, align 8

declare i32 @llvm.ctlz.i32(i32, i1 immarg)
declare void @llvm.memcpy.inline.p0.p0.i64(ptr, ptr, i64, i1 immarg)

; Optimized freestanding code can lower a recognized fill loop to the standard
; LLVM memset libcall. Supply that ABI locally so no C runtime is introduced.
define internal ptr @topal.syscall.memset(ptr %destination, i32 %value, i64 %length) nounwind noinline optnone noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill
fill:
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill
complete:
  ret ptr %destination
}



define internal void @topal.syscall.runtime.pattern.identity.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.syscall.platform.write(i64 2, ptr @topal.syscall.runtime.pattern.identity.diagnostic, i64 68)
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
}

define internal void @topal.syscall.runtime.c.int32.range.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.syscall.platform.write(i64 2, ptr @topal.syscall.runtime.c.int32.range.diagnostic, i64 71)
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
}


; Closed direct tasks run on the deterministic root scheduler. Each instance
; still owns distinct identity, lifecycle state, and private semantic state.
define internal ptr @topal.syscall.runtime.task.make(ptr %initial) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %task = call ptr @topal.syscall.platform.allocate(i64 24)
  %identity = load i64, ptr @topal.syscall.runtime.task.next.identity, align 8
  %next.identity = add i64 %identity, 1
  store i64 %next.identity, ptr @topal.syscall.runtime.task.next.identity, align 8
  %identity.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 0
  %terminated.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 1
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store i64 %identity, ptr %identity.pointer, align 8
  store i64 0, ptr %terminated.pointer, align 8
  store ptr %initial, ptr %state.pointer, align 8
  ret ptr %task
}

define internal ptr @topal.syscall.runtime.task.state.load(ptr %task) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  %state = load ptr, ptr %state.pointer, align 8
  ret ptr %state
}

define internal void @topal.syscall.runtime.task.state.replace(ptr %task, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store ptr %value, ptr %state.pointer, align 8
  ret void
}

; A source-only location without a granted device adapter is backed by private
; Topal storage. The semantic range start and offset remain available for
; debugging, while every read and write remains an ordered runtime call.
define internal ptr @topal.syscall.runtime.location.make(ptr %range.start, ptr %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %location = call ptr @topal.syscall.platform.allocate(i64 32)
  %range.start.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 0
  %offset.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 1
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %range.start, ptr %range.start.pointer, align 8
  store ptr %offset, ptr %offset.pointer, align 8
  store i64 0, ptr %initialized.pointer, align 8
  store ptr null, ptr %value.pointer, align 8
  ret ptr %location
}

define internal void @topal.syscall.runtime.location.write(ptr %location, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %value, ptr %value.pointer, align 8
  store i64 1, ptr %initialized.pointer, align 8
  ret void
}

define internal ptr @topal.syscall.runtime.location.read(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %initialized = load i64, ptr %initialized.pointer, align 8
  %valid = icmp eq i64 %initialized, 1
  br i1 %valid, label %load, label %failure
load:
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  %value = load ptr, ptr %value.pointer, align 8
  %non.null = icmp ne ptr %value, null
  br i1 %non.null, label %success, label %failure
success:
  ret ptr %value
failure:
  call void @topal.syscall.platform.exit(i64 74)
  unreachable
}

define internal ptr @topal.syscall.runtime.serialization.make(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream = call ptr @topal.syscall.platform.allocate(i64 16)
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %publish.empty, label %copy.start
copy.start:
  %copy = call ptr @topal.syscall.platform.allocate(i64 %length)
  br label %copy.loop
copy.loop:
  %index = phi i64 [ 0, %copy.start ], [ %next, %copy.loop ]
  %source.pointer = getelementptr i8, ptr %data, i64 %index
  %target.pointer = getelementptr i8, ptr %copy, i64 %index
  %byte = load i8, ptr %source.pointer, align 1
  store i8 %byte, ptr %target.pointer, align 1
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %publish.copy, label %copy.loop
publish.copy:
  store ptr %copy, ptr %data.pointer, align 8
  br label %publish.length
publish.empty:
  store ptr null, ptr %data.pointer, align 8
  br label %publish.length
publish.length:
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %stream
}

define internal void @topal.syscall.runtime.serialization.verify(ptr %stream, ptr %expected, i64 %expected.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream.valid = icmp ne ptr %stream, null
  br i1 %stream.valid, label %load, label %failure
load:
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %length.matches = icmp eq i64 %length, %expected.length
  br i1 %length.matches, label %check.empty, label %failure
check.empty:
  %empty = icmp eq i64 %expected.length, 0
  br i1 %empty, label %done, label %check.pointers
check.pointers:
  %data.valid = icmp ne ptr %data, null
  %expected.valid = icmp ne ptr %expected, null
  %pointers.valid = and i1 %data.valid, %expected.valid
  br i1 %pointers.valid, label %loop, label %failure
loop:
  %index = phi i64 [ 0, %check.pointers ], [ %next, %advance ]
  %actual.pointer = getelementptr i8, ptr %data, i64 %index
  %expected.pointer = getelementptr i8, ptr %expected, i64 %index
  %actual.byte = load i8, ptr %actual.pointer, align 1
  %expected.byte = load i8, ptr %expected.pointer, align 1
  %matches = icmp eq i8 %actual.byte, %expected.byte
  br i1 %matches, label %advance, label %failure
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %expected.length
  br i1 %complete, label %done, label %loop
failure:
  call void @topal.syscall.platform.exit(i64 70)
  unreachable
done:
  ret void
}

define internal void @topal.syscall.platform.write_all(ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %done, label %loop
loop:
  %offset = phi i64 [0, %entry], [%next, %progress], [%offset, %retry]
  %remaining = sub i64 %length, %offset
  %cursor = getelementptr i8, ptr %buffer, i64 %offset
  %written = call i64 @topal.syscall.platform.write(i64 1, ptr %cursor, i64 %remaining)
  %positive = icmp sgt i64 %written, 0
  br i1 %positive, label %progress, label %error
progress:
  %next = add i64 %offset, %written
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %done, label %loop
error:
  %interrupted = icmp eq i64 %written, -4
  br i1 %interrupted, label %retry, label %failure
retry:
  br label %loop
failure:
  call void @topal.syscall.platform.exit(i64 74)
  unreachable
done:
  ret void
}

define internal void @topal.syscall.runtime.u64.print(i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %buffer = alloca [20 x i8], align 1
  %zero = icmp eq i64 %value, 0
  br i1 %zero, label %write.zero, label %convert
write.zero:
  %zero.pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 19
  store i8 48, ptr %zero.pointer, align 1
  call void @topal.syscall.platform.write_all(ptr %zero.pointer, i64 1)
  ret void
convert:
  %remaining = phi i64 [ %value, %entry ], [ %quotient, %convert ]
  %position = phi i64 [ 20, %entry ], [ %next.position, %convert ]
  %digit = urem i64 %remaining, 10
  %quotient = udiv i64 %remaining, 10
  %next.position = sub i64 %position, 1
  %pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 %next.position
  %digit.byte = trunc i64 %digit to i8
  %ascii = add i8 %digit.byte, 48
  store i8 %ascii, ptr %pointer, align 1
  %complete = icmp eq i64 %quotient, 0
  br i1 %complete, label %write, label %convert
write:
  %length = sub i64 20, %next.position
  call void @topal.syscall.platform.write_all(ptr %pointer, i64 %length)
  ret void
}

define internal ptr @topal.syscall.runtime.string.make(ptr %data, i64 %length, ptr %display, i64 %display.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %string = call ptr @topal.syscall.platform.allocate(i64 32)
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  store ptr %data, ptr %data.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  store ptr %display, ptr %display.pointer, align 8
  store i64 %display.length, ptr %display.length.pointer, align 8
  ret ptr %string
}

define internal void @topal.syscall.runtime.string.raw.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  call void @topal.syscall.platform.write_all(ptr %data, i64 %length)
  ret void
}

define internal void @topal.syscall.runtime.string.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  %display = load ptr, ptr %display.pointer, align 8
  %display.length = load i64, ptr %display.length.pointer, align 8
  %cached = icmp ne ptr %display, null
  br i1 %cached, label %write.cached, label %write.dynamic
write.cached:
  call void @topal.syscall.platform.write_all(ptr %display, i64 %display.length)
  ret void
write.dynamic:
  call void @topal.syscall.runtime.string.dynamic.print(ptr %string)
  ret void
}

define internal i1 @topal.syscall.runtime.string.contains.quote(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %not.found, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %pointer = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %pointer, align 1
  %quote = icmp eq i8 %byte, 34
  br i1 %quote, label %found, label %advance
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %not.found, label %loop
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal i1 @topal.syscall.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %minimum = add i64 %underscores, 5
  %possible = icmp ule i64 %minimum, %length
  br i1 %possible, label %search, label %not.found
search:
  %position = phi i64 [ 0, %entry ], [ %next.position, %advance ]
  %remaining = sub i64 %length, %position
  %enough = icmp uge i64 %remaining, %minimum
  br i1 %enough, label %check.base, label %not.found
check.base:
  %quote.pointer = getelementptr i8, ptr %data, i64 %position
  %quote = load i8, ptr %quote.pointer, align 1
  %offset.t0 = add i64 %position, 1
  %offset.e = add i64 %position, 2
  %offset.x = add i64 %position, 3
  %offset.t1 = add i64 %position, 4
  %pointer.t0 = getelementptr i8, ptr %data, i64 %offset.t0
  %pointer.e = getelementptr i8, ptr %data, i64 %offset.e
  %pointer.x = getelementptr i8, ptr %data, i64 %offset.x
  %pointer.t1 = getelementptr i8, ptr %data, i64 %offset.t1
  %byte.t0 = load i8, ptr %pointer.t0, align 1
  %byte.e = load i8, ptr %pointer.e, align 1
  %byte.x = load i8, ptr %pointer.x, align 1
  %byte.t1 = load i8, ptr %pointer.t1, align 1
  %match.quote = icmp eq i8 %quote, 34
  %match.t0 = icmp eq i8 %byte.t0, 116
  %match.e = icmp eq i8 %byte.e, 101
  %match.x = icmp eq i8 %byte.x, 120
  %match.t1 = icmp eq i8 %byte.t1, 116
  %match.0 = and i1 %match.quote, %match.t0
  %match.1 = and i1 %match.0, %match.e
  %match.2 = and i1 %match.1, %match.x
  %match.base = and i1 %match.2, %match.t1
  br i1 %match.base, label %check.underscores, label %advance
check.underscores:
  %underscore.index = phi i64 [ 0, %check.base ], [ %next.underscore, %underscore.advance ]
  %underscores.complete = icmp eq i64 %underscore.index, %underscores
  br i1 %underscores.complete, label %found, label %check.underscore
check.underscore:
  %underscore.offset.base = add i64 %position, 5
  %underscore.offset = add i64 %underscore.offset.base, %underscore.index
  %underscore.pointer = getelementptr i8, ptr %data, i64 %underscore.offset
  %underscore.byte = load i8, ptr %underscore.pointer, align 1
  %match.underscore = icmp eq i8 %underscore.byte, 95
  br i1 %match.underscore, label %underscore.advance, label %advance
underscore.advance:
  %next.underscore = add i64 %underscore.index, 1
  br label %check.underscores
advance:
  %next.position = add i64 %position, 1
  br label %search
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal void @topal.syscall.runtime.string.write.underscores(i64 %count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %done, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.byte.underscore, i64 1)
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %count
  br i1 %complete, label %done, label %loop
done:
  ret void
}

define internal void @topal.syscall.runtime.string.dynamic.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %contains.quote = call i1 @topal.syscall.runtime.string.contains.quote(ptr %data, i64 %length)
  br i1 %contains.quote, label %select.tag, label %plain
plain:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.byte.quote, i64 1)
  call void @topal.syscall.platform.write_all(ptr %data, i64 %length)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.byte.quote, i64 1)
  ret void
select.tag:
  %underscores = phi i64 [ 0, %entry ], [ %next.underscores, %collision ]
  %collides = call i1 @topal.syscall.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores)
  br i1 %collides, label %collision, label %tagged
collision:
  %next.underscores = add i64 %underscores, 1
  br label %select.tag
tagged:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.string.tag.text, i64 4)
  call void @topal.syscall.runtime.string.write.underscores(i64 %underscores)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.byte.quote, i64 1)
  call void @topal.syscall.platform.write_all(ptr %data, i64 %length)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.byte.quote, i64 1)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.string.tag.text, i64 4)
  call void @topal.syscall.runtime.string.write.underscores(i64 %underscores)
  ret void
}

define internal ptr @topal.syscall.runtime.string.concat(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %length = add i64 %left.length, %right.length
  %valid = icmp uge i64 %length, %left.length
  br i1 %valid, label %allocate, label %failure
failure:
  call void @topal.syscall.platform.exit(i64 71)
  unreachable
allocate:
  %empty = icmp eq i64 %length, 0
  %allocation.length = select i1 %empty, i64 1, i64 %length
  %data = call ptr @topal.syscall.platform.allocate(i64 %allocation.length)
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %data, ptr %left.data, i64 %left.length, i1 false)
  %right.destination = getelementptr i8, ptr %data, i64 %left.length
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %right.destination, ptr %right.data, i64 %right.length, i1 false)
  %result = call ptr @topal.syscall.runtime.string.make(ptr %data, i64 %length, ptr null, i64 0)
  ret ptr %result
}

define internal i1 @topal.syscall.runtime.string.is.empty(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  ret i1 %empty
}

define internal ptr @topal.syscall.runtime.string.utf8.byte.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %count = call ptr @topal.syscall.runtime.int.from.u64(i64 %length)
  ret ptr %count
}

define internal ptr @topal.syscall.runtime.string.unicode.scalar.value(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  switch i64 %length, label %invalid [
    i64 1, label %one
    i64 2, label %two
    i64 3, label %three
    i64 4, label %four
  ]
one:
  %one.byte = load i8, ptr %data, align 1
  %one.ascii = icmp ult i8 %one.byte, -128
  br i1 %one.ascii, label %one.valid, label %invalid
one.valid:
  %one.value = zext i8 %one.byte to i64
  br label %complete
two:
  %two.byte.0 = load i8, ptr %data, align 1
  %two.pointer.1 = getelementptr i8, ptr %data, i64 1
  %two.byte.1 = load i8, ptr %two.pointer.1, align 1
  %two.lead = and i8 %two.byte.0, -32
  %two.lead.valid = icmp eq i8 %two.lead, -64
  %two.continuation = and i8 %two.byte.1, -64
  %two.continuation.valid = icmp eq i8 %two.continuation, -128
  %two.valid = and i1 %two.lead.valid, %two.continuation.valid
  br i1 %two.valid, label %two.decode, label %invalid
two.decode:
  %two.head.masked = and i8 %two.byte.0, 31
  %two.tail.masked = and i8 %two.byte.1, 63
  %two.head = zext i8 %two.head.masked to i64
  %two.tail = zext i8 %two.tail.masked to i64
  %two.shifted = shl i64 %two.head, 6
  %two.value = or i64 %two.shifted, %two.tail
  br label %complete
three:
  %three.byte.0 = load i8, ptr %data, align 1
  %three.pointer.1 = getelementptr i8, ptr %data, i64 1
  %three.pointer.2 = getelementptr i8, ptr %data, i64 2
  %three.byte.1 = load i8, ptr %three.pointer.1, align 1
  %three.byte.2 = load i8, ptr %three.pointer.2, align 1
  %three.head.masked = and i8 %three.byte.0, 15
  %three.middle.masked = and i8 %three.byte.1, 63
  %three.tail.masked = and i8 %three.byte.2, 63
  %three.head = zext i8 %three.head.masked to i64
  %three.middle = zext i8 %three.middle.masked to i64
  %three.tail = zext i8 %three.tail.masked to i64
  %three.head.shifted = shl i64 %three.head, 12
  %three.middle.shifted = shl i64 %three.middle, 6
  %three.partial = or i64 %three.head.shifted, %three.middle.shifted
  %three.value = or i64 %three.partial, %three.tail
  br label %complete
four:
  %four.byte.0 = load i8, ptr %data, align 1
  %four.pointer.1 = getelementptr i8, ptr %data, i64 1
  %four.pointer.2 = getelementptr i8, ptr %data, i64 2
  %four.pointer.3 = getelementptr i8, ptr %data, i64 3
  %four.byte.1 = load i8, ptr %four.pointer.1, align 1
  %four.byte.2 = load i8, ptr %four.pointer.2, align 1
  %four.byte.3 = load i8, ptr %four.pointer.3, align 1
  %four.head.masked = and i8 %four.byte.0, 7
  %four.second.masked = and i8 %four.byte.1, 63
  %four.third.masked = and i8 %four.byte.2, 63
  %four.tail.masked = and i8 %four.byte.3, 63
  %four.head = zext i8 %four.head.masked to i64
  %four.second = zext i8 %four.second.masked to i64
  %four.third = zext i8 %four.third.masked to i64
  %four.tail = zext i8 %four.tail.masked to i64
  %four.head.shifted = shl i64 %four.head, 18
  %four.second.shifted = shl i64 %four.second, 12
  %four.third.shifted = shl i64 %four.third, 6
  %four.partial.0 = or i64 %four.head.shifted, %four.second.shifted
  %four.partial.1 = or i64 %four.partial.0, %four.third.shifted
  %four.value = or i64 %four.partial.1, %four.tail
  br label %complete
complete:
  %value = phi i64 [ %one.value, %one.valid ], [ %two.value, %two.decode ], [ %three.value, %three ], [ %four.value, %four ]
  %result = call ptr @topal.syscall.runtime.int.from.u64(i64 %value)
  ret ptr %result
invalid:
  call void @topal.syscall.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.syscall.runtime.string.unicode.scalar.characters(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  br label %loop
loop:
  %offset = phi i64 [ 0, %entry ], [ %next.offset, %append ]
  %head = phi ptr [ null, %entry ], [ %next.head, %append ]
  %tail = phi ptr [ null, %entry ], [ %node, %append ]
  %complete = icmp eq i64 %offset, %length
  br i1 %complete, label %done, label %decode
decode:
  %byte.pointer = getelementptr i8, ptr %data, i64 %offset
  %byte = load i8, ptr %byte.pointer, align 1
  %ascii = icmp ult i8 %byte, -128
  %two.mask = and i8 %byte, -32
  %two = icmp eq i8 %two.mask, -64
  %three.mask = and i8 %byte, -16
  %three = icmp eq i8 %three.mask, -32
  %non.ascii.width = select i1 %two, i64 2, i64 4
  %multi.width = select i1 %three, i64 3, i64 %non.ascii.width
  %width = select i1 %ascii, i64 1, i64 %multi.width
  %next.offset = add i64 %offset, %width
  %valid = icmp ule i64 %next.offset, %length
  br i1 %valid, label %make, label %invalid
make:
  %character.data = getelementptr i8, ptr %data, i64 %offset
  %character = call ptr @topal.syscall.runtime.string.make(ptr %character.data, i64 %width, ptr null, i64 0)
  %node = call ptr @topal.syscall.platform.allocate(i64 16)
  store ptr %character, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %append, label %link
link:
  %tail.next = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next, align 8
  br label %append
append:
  %next.head = select i1 %empty, ptr %node, ptr %head
  br label %loop
done:
  ret ptr %head
invalid:
  call void @topal.syscall.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.syscall.runtime.string.select.index.range(ptr %string, ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.syscall.runtime.string.unicode.scalar.characters(ptr %string)
  %empty.data = call ptr @topal.syscall.platform.allocate(i64 1)
  %empty = call ptr @topal.syscall.runtime.string.make(ptr %empty.data, i64 0, ptr null, i64 0)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %index = phi i64 [ 0, %entry ], [ %next.index, %advance ]
  %selected = phi ptr [ %empty, %entry ], [ %next.selected, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %visit
visit:
  %index.value = call ptr @topal.syscall.runtime.int.from.u64(i64 %index)
  %present = call i1 @topal.syscall.runtime.range.int.contains(ptr %range, ptr %index.value)
  %character = load ptr, ptr %current, align 8
  br i1 %present, label %append, label %skip
append:
  %appended = call ptr @topal.syscall.runtime.string.concat(ptr %selected, ptr %character)
  br label %advance
skip:
  br label %advance
advance:
  %next.selected = phi ptr [ %appended, %append ], [ %selected, %skip ]
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.index = add i64 %index, 1
  br label %loop
done:
  ret ptr %selected
}

define internal ptr @topal.syscall.runtime.string.character.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.syscall.runtime.string.unicode.scalar.characters(ptr %string)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %count = phi i64 [ 0, %entry ], [ %next.count, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.count = add i64 %count, 1
  br label %loop
done:
  %value = call ptr @topal.syscall.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.syscall.runtime.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %same.length = icmp eq i64 %left.length, %right.length
  br i1 %same.length, label %loop, label %not.equal
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %complete = icmp eq i64 %index, %left.length
  br i1 %complete, label %equal, label %compare
compare:
  %left.pointer = getelementptr i8, ptr %left.data, i64 %index
  %right.pointer = getelementptr i8, ptr %right.data, i64 %index
  %left.byte = load i8, ptr %left.pointer, align 1
  %right.byte = load i8, ptr %right.pointer, align 1
  %same.byte = icmp eq i8 %left.byte, %right.byte
  br i1 %same.byte, label %advance, label %not.equal
advance:
  %next = add i64 %index, 1
  br label %loop
equal:
  ret i1 true
not.equal:
  ret i1 false
}

define internal ptr @topal.syscall.runtime.result.success(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.syscall.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.result.error(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.syscall.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal i1 @topal.syscall.runtime.result.is.error(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %is.error = icmp eq i64 %tag, 1
  ret i1 %is.error
}

define internal ptr @topal.syscall.runtime.result.payload(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.syscall.runtime.optional.some(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.syscall.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal ptr @topal.syscall.runtime.optional.none() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.syscall.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal i1 @topal.syscall.runtime.optional.is.some(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid
checked:
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some
invalid:
  call void @topal.syscall.platform.exit(i64 70)
  unreachable
}

define internal ptr @topal.syscall.runtime.optional.payload(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.syscall.runtime.optional.from.nullable(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %present = icmp ne ptr %payload, null
  br i1 %present, label %some, label %none
some:
  %some.value = call ptr @topal.syscall.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.syscall.runtime.optional.none()
  ret ptr %none.value
}

define internal i1 @topal.syscall.runtime.optional.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.syscall.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.syscall.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.syscall.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.syscall.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.syscall.runtime.int.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.syscall.runtime.optional.rational.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.syscall.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.syscall.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.syscall.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.syscall.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.syscall.runtime.rational.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.syscall.runtime.optional.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.syscall.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.syscall.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.syscall.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.syscall.runtime.optional.payload(ptr %right)
  %payloads.equal = call i1 @topal.syscall.runtime.string.equal(ptr %left.payload, ptr %right.payload)
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal ptr @topal.syscall.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.syscall.platform.allocate(i64 56)
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %reserved.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 2
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  store ptr %domain, ptr %domain.pointer, align 8
  store i32 %code, ptr %code.pointer, align 4
  store i32 0, ptr %reserved.pointer, align 4
  store ptr null, ptr %detail.pointer, align 8
  store ptr null, ptr %cause.pointer, align 8
  store ptr %source, ptr %source.pointer, align 8
  store i64 %line, ptr %line.pointer, align 8
  store i64 %column, ptr %column.pointer, align 8
  ret ptr %error
}

define internal i32 @topal.syscall.runtime.error.code(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %code = load i32, ptr %code.pointer, align 4
  ret i32 %code
}

define internal ptr @topal.syscall.runtime.error.domain(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %domain = load ptr, ptr %domain.pointer, align 8
  ret ptr %domain
}

define internal ptr @topal.syscall.runtime.error.detail(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %detail = load ptr, ptr %detail.pointer, align 8
  %optional = call ptr @topal.syscall.runtime.optional.from.nullable(ptr %detail)
  ret ptr %optional
}

define internal ptr @topal.syscall.runtime.error.cause(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %cause = load ptr, ptr %cause.pointer, align 8
  %optional = call ptr @topal.syscall.runtime.optional.from.nullable(ptr %cause)
  ret ptr %optional
}

define internal ptr @topal.syscall.runtime.error.source(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %source = load ptr, ptr %source.pointer, align 8
  %present = icmp ne ptr %source, null
  br i1 %present, label %some, label %none
some:
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  %line.number = load i64, ptr %line.pointer, align 8
  %column.number = load i64, ptr %column.pointer, align 8
  %line = call ptr @topal.syscall.runtime.int.from.u64(i64 %line.number)
  %column = call ptr @topal.syscall.runtime.int.from.u64(i64 %column.number)
  %location = call ptr @topal.syscall.platform.allocate(i64 16)
  %location.line = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %location.column = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  store ptr %line, ptr %location.line, align 8
  store ptr %column, ptr %location.column, align 8
  %some.value = call ptr @topal.syscall.runtime.optional.some(ptr %location)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.syscall.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.syscall.runtime.source.location.line(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %line.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %line = load ptr, ptr %line.pointer, align 8
  ret ptr %line
}

define internal ptr @topal.syscall.runtime.source.location.column(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %column.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  %column = load ptr, ptr %column.pointer, align 8
  ret ptr %column
}

define internal ptr @topal.syscall.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.syscall.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  %result = call ptr @topal.syscall.runtime.result.error(ptr %error)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.int.try.to.nat(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %success
failure:
  %failed = call ptr @topal.syscall.runtime.result.failure(i32 0, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %result = call ptr @topal.syscall.runtime.result.success(ptr %value)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.try.to.int(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %value)
  %ordering = call i32 @topal.syscall.runtime.int.compare(ptr %denominator, ptr @topal.syscall.runtime.int.one)
  %exact = icmp eq i32 %ordering, 0
  br i1 %exact, label %success, label %failure
failure:
  %failed = call ptr @topal.syscall.runtime.result.failure(i32 1, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %value)
  %result = call ptr @topal.syscall.runtime.result.success(ptr %numerator)
  ret ptr %result
}

define internal void @topal.syscall.runtime.error.print(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %domain = load ptr, ptr %domain.pointer, align 8
  %code = load i32, ptr %code.pointer, align 4
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.error.prefix, i64 18)
  call void @topal.syscall.runtime.string.raw.print(ptr %domain)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.error.code.separator, i64 10)
  call void @topal.syscall.runtime.error.code.print(i32 %code)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.error.suffix, i64 2)
  ret void
}

define internal void @topal.syscall.runtime.error.code.print(i32 %code) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  switch i32 %code, label %indeterminate [ i32 0, label %out.of.range i32 1, label %not.representable i32 2, label %division.by.zero ]
out.of.range:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.error.code.out.of.range, i64 12)
  br label %done
not.representable:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.error.code.not.representable, i64 17)
  br label %done
division.by.zero:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.error.code.division.by.zero, i64 16)
  br label %done
indeterminate:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.error.code.indeterminate, i64 13)
  br label %done
done:
  ret void
}

define internal ptr @topal.syscall.runtime.int.allocate(i64 %length, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure
allocate:
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.syscall.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value
failure:
  call void @topal.syscall.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.syscall.runtime.int.from.u64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero
zero:
  ret ptr @topal.syscall.runtime.int.zero
nonzero:
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.syscall.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done
store.high:
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done
done:
  ret ptr %value
}

define internal ptr @topal.syscall.runtime.int.from.i64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = icmp slt i64 %source, 0
  %negated = sub i64 0, %source
  %magnitude = select i1 %negative, i64 %negated, i64 %source
  %value = call ptr @topal.syscall.runtime.int.from.u64(i64 %magnitude)
  br i1 %negative, label %signed, label %done
signed:
  %negative.value = call ptr @topal.syscall.runtime.int.copy.with.sign(ptr %value, i64 1)
  ret ptr %negative.value
done:
  ret ptr %value
}

define internal i32 @topal.syscall.runtime.int.to.c.i32(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %sign = load i64, ptr %sign.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %return.zero, label %nonzero
return.zero:
  ret i32 0
nonzero:
  %one.limb = icmp eq i64 %length, 1
  %finite.sign = icmp ule i64 %sign, 1
  %shape.valid = and i1 %one.limb, %finite.sign
  br i1 %shape.valid, label %load, label %failure
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %limb = load i32, ptr %limb.pointer, align 4
  %negative = icmp eq i64 %sign, 1
  %positive.valid = icmp ule i32 %limb, 2147483647
  %negative.valid = icmp ule i32 %limb, 2147483648
  %range.valid = select i1 %negative, i1 %negative.valid, i1 %positive.valid
  br i1 %range.valid, label %convert, label %failure
convert:
  %negated = sub i32 0, %limb
  %result = select i1 %negative, i32 %negated, i32 %limb
  ret i32 %result
failure:
  call void @topal.syscall.runtime.c.int32.range.fail()
  unreachable
}

define internal i64 @topal.syscall.runtime.int.limb.or.zero(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended
zero:
  ret i64 0
}

define internal ptr @topal.syscall.runtime.int.normalize(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim
trim:
  %candidate = phi i64 [%length, %entry], [%next, %leading.zero]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done
leading.zero:
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim
zero:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value
done:
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.syscall.runtime.int.copy.with.sign(ptr %value, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate
zero:
  ret ptr @topal.syscall.runtime.int.zero
allocate:
  %copy = call ptr @topal.syscall.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %allocate], [%next, %loop]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  ret ptr %copy
}

define internal ptr @topal.syscall.runtime.int.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  ret ptr @topal.syscall.runtime.int.negative.infinity
negative.infinity:
  ret ptr @topal.syscall.runtime.int.positive.infinity
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %copy
zero:
  ret ptr @topal.syscall.runtime.int.zero
copy:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %opposite = xor i64 %negative, 1
  %result = call ptr @topal.syscall.runtime.int.copy.with.sign(ptr %value, i64 %opposite)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.int.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite
infinite:
  ret ptr @topal.syscall.runtime.int.positive.infinity
finite:
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy
same:
  ret ptr %value
copy:
  %result = call ptr @topal.syscall.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

define internal i32 @topal.syscall.runtime.int.compare.absolute(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer
check.longer:
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty
check.empty:
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs
limbs:
  %position = phi i64 [%left.length, %check.empty], [%index, %limbs.equal]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater
check.limb.greater:
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal
limbs.equal:
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal
less:
  ret i32 -1
equal:
  ret i32 0
greater:
  ret i32 1
}

define internal i32 @topal.syscall.runtime.int.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity
left.positive:
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result
check.left.negative.infinity:
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity
left.negative:
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result
check.right.positive.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity
check.right.negative.infinity:
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite
less:
  ret i32 -1
greater:
  ret i32 1
finite:
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute
signed.result:
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result
absolute:
  %magnitude = call i32 @topal.syscall.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

define internal ptr @topal.syscall.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.syscall.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %carry = phi i64 [0, %entry], [%next.carry, %loop]
  %left.limb = call i64 @topal.syscall.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.syscall.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish
finish:
  %final.carry = phi i64 [0, %entry], [%next.carry, %loop]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry
store.carry:
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result
without.carry:
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.syscall.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.syscall.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.syscall.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %borrow = phi i64 [0, %entry], [%next.borrow, %loop]
  %left = call i64 @topal.syscall.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.syscall.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  %normalized = call ptr @topal.syscall.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.syscall.runtime.int.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity
validate.left.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity
indeterminate.infinity:
  call void @topal.syscall.platform.exit(i64 70)
  unreachable
return.left.infinity:
  ret ptr %left
check.right.infinity:
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite
return.right.infinity:
  ret ptr %right
finite:
  %left.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right
return.right:
  ret ptr %right
check.right:
  %right.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero
return.left:
  ret ptr %left
nonzero:
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference
sum:
  %sum.value = call ptr @topal.syscall.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value
difference:
  %ordering = call i32 @topal.syscall.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger
zero:
  ret ptr @topal.syscall.runtime.int.zero
select.larger:
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference
left.difference:
  %left.value = call ptr @topal.syscall.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value
right.difference:
  %right.value = call ptr @topal.syscall.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

define internal ptr @topal.syscall.runtime.int.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %opposite = call ptr @topal.syscall.runtime.int.negate(ptr %right)
  %result = call ptr @topal.syscall.runtime.int.add(ptr %left, ptr %opposite)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.int.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %left.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity
indeterminate.infinity:
  call void @topal.syscall.platform.exit(i64 70)
  unreachable
select.infinity:
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.syscall.runtime.int.negative.infinity, ptr @topal.syscall.runtime.int.positive.infinity
  ret ptr %infinity
finite:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length
zero:
  ret ptr @topal.syscall.runtime.int.zero
check.length:
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate
failure:
  call void @topal.syscall.platform.exit(i64 71)
  unreachable
allocate:
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.syscall.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear
clear:
  %clear.index = phi i64 [0, %allocate], [%clear.next, %clear]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry
outer.entry:
  br label %outer
outer:
  %left.index = phi i64 [0, %outer.entry], [%left.next, %outer.done]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner
inner:
  %right.index = phi i64 [0, %outer], [%right.next, %inner]
  %carry = phi i64 [0, %outer], [%next.carry, %inner]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done
outer.done:
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done
done:
  %normalized = call ptr @topal.syscall.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal void @topal.syscall.runtime.int.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.int.positive.infinity.text, i64 9)
  ret void
negative.infinity:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.int.negative.infinity.text, i64 9)
  ret void
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check.sign
zero:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.byte.zero, i64 1)
  ret void
check.sign:
  %is.negative = icmp ne i64 %sign, 0
  br i1 %is.negative, label %write.sign, label %prepare
write.sign:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.byte.minus, i64 1)
  br label %prepare
prepare:
  %capacity.valid = icmp ule i64 %length, 922337203685477580
  br i1 %capacity.valid, label %allocate, label %failure
failure:
  call void @topal.syscall.platform.exit(i64 71)
  unreachable
allocate:
  %scratch.bytes = mul i64 %length, 4
  %capacity = mul i64 %length, 10
  %scratch = call ptr @topal.syscall.platform.allocate(i64 %scratch.bytes)
  %buffer = call ptr @topal.syscall.platform.allocate(i64 %capacity)
  br label %copy
copy:
  %copy.index = phi i64 [0, %allocate], [%copy.next, %copy]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %copy.index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr i32, ptr %scratch, i64 %copy.index
  store i32 %limb, ptr %destination, align 4
  %copy.next = add i64 %copy.index, 1
  %copy.more = icmp ult i64 %copy.next, %length
  br i1 %copy.more, label %copy, label %digits
digits:
  %work.length = phi i64 [%length, %copy], [%next.length, %division.finish]
  %position = phi i64 [%capacity, %copy], [%next.position, %division.finish]
  br label %divide
divide:
  %division.position = phi i64 [%work.length, %digits], [%division.index, %divide.step]
  %remainder = phi i64 [0, %digits], [%next.remainder, %divide.step]
  %division.index = sub i64 %division.position, 1
  %work.pointer = getelementptr i32, ptr %scratch, i64 %division.index
  %work.raw = load i32, ptr %work.pointer, align 4
  %work = zext i32 %work.raw to i64
  %high = shl i64 %remainder, 32
  %current = or i64 %high, %work
  %quotient = udiv i64 %current, 10
  %next.remainder = urem i64 %current, 10
  %quotient.limb = trunc i64 %quotient to i32
  store i32 %quotient.limb, ptr %work.pointer, align 4
  %division.more = icmp ne i64 %division.index, 0
  br i1 %division.more, label %divide.step, label %division.done
divide.step:
  br label %divide
division.done:
  %next.position = sub i64 %position, 1
  %digit = trunc i64 %next.remainder to i8
  %ascii = add i8 %digit, 48
  %digit.pointer = getelementptr i8, ptr %buffer, i64 %next.position
  store i8 %ascii, ptr %digit.pointer, align 1
  br label %trim
trim:
  %candidate = phi i64 [%work.length, %division.done], [%trim.next, %trim.zero]
  %trim.index = sub i64 %candidate, 1
  %trim.pointer = getelementptr i32, ptr %scratch, i64 %trim.index
  %trim.limb = load i32, ptr %trim.pointer, align 4
  %leading.zero = icmp eq i32 %trim.limb, 0
  br i1 %leading.zero, label %trim.zero, label %trim.done
trim.zero:
  %trim.next = sub i64 %candidate, 1
  %trim.empty = icmp eq i64 %trim.next, 0
  br i1 %trim.empty, label %trim.empty.done, label %trim
trim.empty.done:
  br label %division.finish
trim.done:
  br label %division.finish
division.finish:
  %next.length = phi i64 [0, %trim.empty.done], [%candidate, %trim.done]
  %more.digits = icmp ne i64 %next.length, 0
  br i1 %more.digits, label %digits, label %emit
emit:
  %count = sub i64 %capacity, %next.position
  %first = getelementptr i8, ptr %buffer, i64 %next.position
  call void @topal.syscall.platform.write_all(ptr %first, i64 %count)
  ret void
}

define internal i1 @topal.syscall.runtime.int.is.zero(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

define internal ptr @topal.syscall.runtime.int.divmod.pair(ptr %quotient, ptr %remainder) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.syscall.platform.allocate(i64 16)
  %quotient.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %remainder.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  store ptr %quotient, ptr %quotient.pointer, align 8
  store ptr %remainder, ptr %remainder.pointer, align 8
  ret ptr %pair
}

define internal ptr @topal.syscall.runtime.int.divmod.quotient(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.syscall.runtime.int.divmod.remainder(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i64 @topal.syscall.runtime.int.bit.length(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check
zero:
  ret i64 0
check:
  %valid = icmp ule i64 %length, 576460752303423487
  br i1 %valid, label %calculate, label %failure
failure:
  call void @topal.syscall.platform.exit(i64 71)
  unreachable
calculate:
  %last = sub i64 %length, 1
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %last
  %limb = load i32, ptr %pointer, align 4
  %leading = call i32 @llvm.ctlz.i32(i32 %limb, i1 false)
  %top.bits.raw = sub i32 32, %leading
  %top.bits = zext i32 %top.bits.raw to i64
  %lower.bits = mul i64 %last, 32
  %bits = add i64 %lower.bits, %top.bits
  ret i64 %bits
}

define internal i1 @topal.syscall.runtime.int.bit.at(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %limb.index = lshr i64 %index, 5
  %offset.raw = and i64 %index, 31
  %offset = trunc i64 %offset.raw to i32
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %limb.index
  %limb = load i32, ptr %pointer, align 4
  %shifted = lshr i32 %limb, %offset
  %bit.raw = and i32 %shifted, 1
  %bit = icmp ne i32 %bit.raw, 0
  ret i1 %bit
}

define internal ptr @topal.syscall.runtime.int.divmod.absolute(ptr %dividend, ptr %divisor) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %divisor.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %divisor)
  br i1 %divisor.zero, label %failure, label %check.dividend
failure:
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
check.dividend:
  %dividend.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %dividend)
  br i1 %dividend.zero, label %zero, label %prepare
zero:
  %zero.pair = call ptr @topal.syscall.runtime.int.divmod.pair(ptr @topal.syscall.runtime.int.zero, ptr @topal.syscall.runtime.int.zero)
  ret ptr %zero.pair
prepare:
  %bits = call i64 @topal.syscall.runtime.int.bit.length(ptr %dividend)
  br label %loop
loop:
  %position = phi i64 [%bits, %prepare], [%next.position, %merge]
  %quotient = phi ptr [@topal.syscall.runtime.int.zero, %prepare], [%next.quotient, %merge]
  %remainder = phi ptr [@topal.syscall.runtime.int.zero, %prepare], [%next.remainder, %merge]
  %bit.index = sub i64 %position, 1
  %bit = call i1 @topal.syscall.runtime.int.bit.at(ptr %dividend, i64 %bit.index)
  %quotient.twice = call ptr @topal.syscall.runtime.int.add(ptr %quotient, ptr %quotient)
  %remainder.twice = call ptr @topal.syscall.runtime.int.add(ptr %remainder, ptr %remainder)
  br i1 %bit, label %append.bit, label %compare
append.bit:
  %remainder.with.bit = call ptr @topal.syscall.runtime.int.add(ptr %remainder.twice, ptr @topal.syscall.runtime.int.one)
  br label %compare
compare:
  %candidate = phi ptr [%remainder.twice, %loop], [%remainder.with.bit, %append.bit]
  %ordering = call i32 @topal.syscall.runtime.int.compare.absolute(ptr %candidate, ptr %divisor)
  %subtract = icmp sge i32 %ordering, 0
  br i1 %subtract, label %subtract.divisor, label %retain
subtract.divisor:
  %reduced = call ptr @topal.syscall.runtime.int.subtract.absolute(ptr %candidate, ptr %divisor, i64 0)
  %incremented = call ptr @topal.syscall.runtime.int.add(ptr %quotient.twice, ptr @topal.syscall.runtime.int.one)
  br label %merge
retain:
  br label %merge
merge:
  %next.quotient = phi ptr [%incremented, %subtract.divisor], [%quotient.twice, %retain]
  %next.remainder = phi ptr [%reduced, %subtract.divisor], [%candidate, %retain]
  %next.position = sub i64 %position, 1
  %more = icmp ne i64 %next.position, 0
  br i1 %more, label %loop, label %done
done:
  %pair = call ptr @topal.syscall.runtime.int.divmod.pair(ptr %next.quotient, ptr %next.remainder)
  ret ptr %pair
}

define internal ptr @topal.syscall.runtime.int.quotient.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %divide
failure:
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
divide:
  %left.absolute = call ptr @topal.syscall.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.syscall.runtime.int.absolute(ptr %right)
  %unsigned = call ptr @topal.syscall.runtime.int.divmod.absolute(ptr %left.absolute, ptr %right.absolute)
  %quotient.absolute = call ptr @topal.syscall.runtime.int.divmod.quotient(ptr %unsigned)
  %remainder.absolute = call ptr @topal.syscall.runtime.int.divmod.remainder(ptr %unsigned)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.negative = icmp ne i64 %left.sign, 0
  %remainder.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %remainder.absolute)
  %remainder.present = xor i1 %remainder.zero, true
  %needs.adjustment = and i1 %left.negative, %remainder.present
  %quotient.sign = xor i64 %left.sign, %right.sign
  br i1 %needs.adjustment, label %adjust, label %direct
direct:
  %direct.quotient = call ptr @topal.syscall.runtime.int.copy.with.sign(ptr %quotient.absolute, i64 %quotient.sign)
  %direct.pair = call ptr @topal.syscall.runtime.int.divmod.pair(ptr %direct.quotient, ptr %remainder.absolute)
  ret ptr %direct.pair
adjust:
  %larger.quotient = call ptr @topal.syscall.runtime.int.add(ptr %quotient.absolute, ptr @topal.syscall.runtime.int.one)
  %adjusted.quotient = call ptr @topal.syscall.runtime.int.copy.with.sign(ptr %larger.quotient, i64 %quotient.sign)
  %adjusted.remainder = call ptr @topal.syscall.runtime.int.subtract.absolute(ptr %right.absolute, ptr %remainder.absolute, i64 0)
  %adjusted.pair = call ptr @topal.syscall.runtime.int.divmod.pair(ptr %adjusted.quotient, ptr %adjusted.remainder)
  ret ptr %adjusted.pair
}

define internal ptr @topal.syscall.runtime.int.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.syscall.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %remainder = call ptr @topal.syscall.runtime.int.divmod.remainder(ptr %pair)
  ret ptr %remainder
}

define internal ptr @topal.syscall.runtime.int.try.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.syscall.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %remainder = call ptr @topal.syscall.runtime.int.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.syscall.runtime.result.success(ptr %remainder)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.int.try.quotient.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.syscall.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %pair = call ptr @topal.syscall.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.syscall.runtime.result.success(ptr %pair)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.int.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %prepare
failure:
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
prepare:
  %bits = call i64 @topal.syscall.runtime.int.bit.length(ptr %exponent)
  %empty = icmp eq i64 %bits, 0
  br i1 %empty, label %one, label %loop
one:
  ret ptr @topal.syscall.runtime.int.one
loop:
  %position = phi i64 [0, %prepare], [%next.position, %square]
  %result = phi ptr [@topal.syscall.runtime.int.one, %prepare], [%next.result, %square]
  %factor = phi ptr [%base, %prepare], [%next.factor, %square]
  %bit = call i1 @topal.syscall.runtime.int.bit.at(ptr %exponent, i64 %position)
  br i1 %bit, label %multiply, label %retain
multiply:
  %product = call ptr @topal.syscall.runtime.int.multiply(ptr %result, ptr %factor)
  br label %advance
retain:
  br label %advance
advance:
  %next.result = phi ptr [%product, %multiply], [%result, %retain]
  %next.position = add i64 %position, 1
  %complete = icmp eq i64 %next.position, %bits
  br i1 %complete, label %done, label %square
square:
  %next.factor = call ptr @topal.syscall.runtime.int.multiply(ptr %factor, ptr %factor)
  br label %loop
done:
  ret ptr %next.result
}

define internal ptr @topal.syscall.runtime.int.greatest.common.divisor(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.absolute = call ptr @topal.syscall.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.syscall.runtime.int.absolute(ptr %right)
  %right.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right.absolute)
  br i1 %right.zero, label %initial.done, label %loop
initial.done:
  ret ptr %left.absolute
loop:
  %current.left = phi ptr [%left.absolute, %entry], [%current.right, %again]
  %current.right = phi ptr [%right.absolute, %entry], [%remainder, %again]
  %division = call ptr @topal.syscall.runtime.int.divmod.absolute(ptr %current.left, ptr %current.right)
  %remainder = call ptr @topal.syscall.runtime.int.divmod.remainder(ptr %division)
  %done = call i1 @topal.syscall.runtime.int.is.zero(ptr %remainder)
  br i1 %done, label %result, label %again
again:
  br label %loop
result:
  ret ptr %current.right
}

define internal ptr @topal.syscall.runtime.rational.raw(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.syscall.platform.allocate(i64 16)
  %numerator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %denominator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  store ptr %numerator, ptr %numerator.pointer, align 8
  store ptr %denominator, ptr %denominator.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.syscall.runtime.rational.numerator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %numerator = load ptr, ptr %pointer, align 8
  ret ptr %numerator
}

define internal ptr @topal.syscall.runtime.rational.denominator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  %denominator = load ptr, ptr %pointer, align 8
  ret ptr %denominator
}

define internal ptr @topal.syscall.runtime.rational.make(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %numerator.sign = load i64, ptr %numerator.sign.pointer, align 8
  %positive.infinity = icmp eq i64 %numerator.sign, 2
  %negative.infinity = icmp eq i64 %numerator.sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %make.infinity, label %finite
make.infinity:
  %infinite.value = call ptr @topal.syscall.runtime.rational.raw(ptr %numerator, ptr @topal.syscall.runtime.int.one)
  ret ptr %infinite.value
finite:
  %denominator.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %check.numerator
failure:
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
check.numerator:
  %numerator.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %numerator)
  br i1 %numerator.zero, label %zero, label %normalize
zero:
  %zero.value = call ptr @topal.syscall.runtime.rational.raw(ptr @topal.syscall.runtime.int.zero, ptr @topal.syscall.runtime.int.one)
  ret ptr %zero.value
normalize:
  %numerator.absolute = call ptr @topal.syscall.runtime.int.absolute(ptr %numerator)
  %denominator.absolute = call ptr @topal.syscall.runtime.int.absolute(ptr %denominator)
  %divisor = call ptr @topal.syscall.runtime.int.greatest.common.divisor(ptr %numerator.absolute, ptr %denominator.absolute)
  %numerator.division = call ptr @topal.syscall.runtime.int.divmod.absolute(ptr %numerator.absolute, ptr %divisor)
  %denominator.division = call ptr @topal.syscall.runtime.int.divmod.absolute(ptr %denominator.absolute, ptr %divisor)
  %reduced.numerator.absolute = call ptr @topal.syscall.runtime.int.divmod.quotient(ptr %numerator.division)
  %reduced.denominator = call ptr @topal.syscall.runtime.int.divmod.quotient(ptr %denominator.division)
  %finite.numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %finite.denominator.sign.pointer = getelementptr %topal.IntStorage, ptr %denominator, i32 0, i32 0
  %finite.numerator.sign = load i64, ptr %finite.numerator.sign.pointer, align 8
  %finite.denominator.sign = load i64, ptr %finite.denominator.sign.pointer, align 8
  %sign = xor i64 %finite.numerator.sign, %finite.denominator.sign
  %reduced.numerator = call ptr @topal.syscall.runtime.int.copy.with.sign(ptr %reduced.numerator.absolute, i64 %sign)
  %result = call ptr @topal.syscall.runtime.rational.raw(ptr %reduced.numerator, ptr %reduced.denominator)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.from.int(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.syscall.runtime.rational.raw(ptr %value, ptr @topal.syscall.runtime.int.one)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %value)
  %negative = call ptr @topal.syscall.runtime.int.negate(ptr %numerator)
  %result = call ptr @topal.syscall.runtime.rational.raw(ptr %negative, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %value)
  %absolute = call ptr @topal.syscall.runtime.int.absolute(ptr %numerator)
  %result = call ptr @topal.syscall.runtime.rational.raw(ptr %absolute, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %right)
  %left.scaled = call ptr @topal.syscall.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.syscall.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %numerator = call ptr @topal.syscall.runtime.int.add(ptr %left.scaled, ptr %right.scaled)
  %denominator = call ptr @topal.syscall.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.syscall.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = call ptr @topal.syscall.runtime.rational.negate(ptr %right)
  %result = call ptr @topal.syscall.runtime.rational.add(ptr %left, ptr %negative)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %right)
  %numerator = call ptr @topal.syscall.runtime.int.multiply(ptr %left.numerator, ptr %right.numerator)
  %denominator = call ptr @topal.syscall.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.syscall.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.divide(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %right)
  %zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right.numerator)
  br i1 %zero, label %failure, label %calculate
failure:
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
calculate:
  %numerator = call ptr @topal.syscall.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %denominator = call ptr @topal.syscall.runtime.int.multiply(ptr %left.denominator, ptr %right.numerator)
  %result = call ptr @topal.syscall.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal i32 @topal.syscall.runtime.rational.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %right)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left.numerator, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right.numerator, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %infinite.result = call i32 @topal.syscall.runtime.int.compare(ptr %left.numerator, ptr %right.numerator)
  ret i32 %infinite.result
finite:
  %left.scaled = call ptr @topal.syscall.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.syscall.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %result = call i32 @topal.syscall.runtime.int.compare(ptr %left.scaled, ptr %right.scaled)
  ret i32 %result
}

define internal ptr @topal.syscall.runtime.rational.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %base)
  %denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %base)
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  %absolute.exponent = call ptr @topal.syscall.runtime.int.absolute(ptr %exponent)
  %powered.numerator = call ptr @topal.syscall.runtime.int.power(ptr %numerator, ptr %absolute.exponent)
  %powered.denominator = call ptr @topal.syscall.runtime.int.power(ptr %denominator, ptr %absolute.exponent)
  br i1 %negative, label %reciprocal, label %direct
direct:
  %direct.result = call ptr @topal.syscall.runtime.rational.raw(ptr %powered.numerator, ptr %powered.denominator)
  ret ptr %direct.result
reciprocal:
  %zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %powered.numerator)
  br i1 %zero, label %failure, label %invert
failure:
  call void @topal.syscall.platform.exit(i64 65)
  unreachable
invert:
  %result = call ptr @topal.syscall.runtime.rational.make(ptr %powered.denominator, ptr %powered.numerator)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.try.make(ptr %numerator, ptr %denominator, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %success
failure:
  %numerator.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %numerator)
  %code = select i1 %numerator.zero, i32 3, i32 2
  %failed = call ptr @topal.syscall.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.syscall.runtime.rational.make(ptr %numerator, ptr %denominator)
  %result = call ptr @topal.syscall.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.try.divide(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %right)
  %right.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %right.numerator)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.syscall.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.syscall.runtime.rational.divide(ptr %left, ptr %right)
  %result = call ptr @topal.syscall.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.rational.try.power(ptr %base, ptr %exponent, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  br i1 %negative, label %check.base, label %success
check.base:
  %numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %base)
  %base.zero = call i1 @topal.syscall.runtime.int.is.zero(ptr %numerator)
  br i1 %base.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.syscall.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.syscall.runtime.rational.power(ptr %base, ptr %exponent)
  %result = call ptr @topal.syscall.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal void @topal.syscall.runtime.rational.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.syscall.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.syscall.runtime.rational.denominator(ptr %value)
  %sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %positive.infinity = icmp eq i64 %sign, 2
  %negative.infinity = icmp eq i64 %sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %print.infinity, label %print.finite
print.infinity:
  call void @topal.syscall.runtime.int.print(ptr %numerator)
  ret void
print.finite:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.rational.prefix, i64 11)
  call void @topal.syscall.runtime.int.print(ptr %numerator)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.rational.separator, i64 2)
  call void @topal.syscall.runtime.int.print(ptr %denominator)
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.rational.suffix, i64 2)
  ret void
}

define internal ptr @topal.syscall.runtime.range.make(ptr %lower, ptr %upper, i64 %lower.inclusive, i64 %upper.inclusive) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.syscall.platform.allocate(i64 32)
  %lower.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 0
  %upper.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 1
  %lower.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 2
  %upper.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 3
  store ptr %lower, ptr %lower.pointer, align 8
  store ptr %upper, ptr %upper.pointer, align 8
  store i64 %lower.inclusive, ptr %lower.inclusive.pointer, align 8
  store i64 %upper.inclusive, ptr %upper.inclusive.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.syscall.runtime.range.lower(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.syscall.runtime.range.upper(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i1 @topal.syscall.runtime.range.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.syscall.runtime.range.lower(ptr %left)
  %right.lower = call ptr @topal.syscall.runtime.range.lower(ptr %right)
  %lower.ordering = call i32 @topal.syscall.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.upper = call ptr @topal.syscall.runtime.range.upper(ptr %left)
  %right.upper = call ptr @topal.syscall.runtime.range.upper(ptr %right)
  %upper.ordering = call i32 @topal.syscall.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %bounds.equal = and i1 %lower.equal, %upper.equal
  %left.lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %right)
  %lower.inclusive.equal = icmp eq i1 %left.lower.inclusive, %right.lower.inclusive
  %left.upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %left)
  %right.upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %right)
  %upper.inclusive.equal = icmp eq i1 %left.upper.inclusive, %right.upper.inclusive
  %inclusivity.equal = and i1 %lower.inclusive.equal, %upper.inclusive.equal
  %equal = and i1 %bounds.equal, %inclusivity.equal
  ret i1 %equal
}

define internal i1 @topal.syscall.runtime.range.lower.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 2
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.syscall.runtime.range.upper.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 3
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.syscall.runtime.range.empty.from.comparison(ptr %range, i32 %ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %reversed = icmp sgt i32 %ordering, 0
  %equal = icmp eq i32 %ordering, 0
  %lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %range)
  %both.inclusive = and i1 %lower.inclusive, %upper.inclusive
  %open.equal = xor i1 %both.inclusive, true
  %empty.equal = and i1 %equal, %open.equal
  %empty = or i1 %reversed, %empty.equal
  ret i1 %empty
}

define internal i1 @topal.syscall.runtime.range.int.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.syscall.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.syscall.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.syscall.runtime.int.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.syscall.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.syscall.runtime.range.rational.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.syscall.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.syscall.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.syscall.runtime.rational.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.syscall.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.syscall.runtime.range.int.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.syscall.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.syscall.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.syscall.runtime.int.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.syscall.runtime.int.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal i1 @topal.syscall.runtime.range.rational.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.syscall.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.syscall.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.syscall.runtime.rational.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.syscall.runtime.rational.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal ptr @topal.syscall.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.syscall.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.syscall.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.syscall.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.syscall.runtime.range.upper(ptr %right)
  %left.lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %left)
  %left.upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %right)
  %right.upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %right)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.lower.stricter = icmp sgt i32 %lower.ordering, 0
  %selected.lower = select i1 %left.lower.stricter, ptr %left.lower, ptr %right.lower
  %selected.lower.inclusive = select i1 %left.lower.stricter, i1 %left.lower.inclusive, i1 %right.lower.inclusive
  %equal.lower.inclusive = and i1 %left.lower.inclusive, %right.lower.inclusive
  %lower.inclusive = select i1 %lower.equal, i1 %equal.lower.inclusive, i1 %selected.lower.inclusive
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %left.upper.stricter = icmp slt i32 %upper.ordering, 0
  %selected.upper = select i1 %left.upper.stricter, ptr %left.upper, ptr %right.upper
  %selected.upper.inclusive = select i1 %left.upper.stricter, i1 %left.upper.inclusive, i1 %right.upper.inclusive
  %equal.upper.inclusive = and i1 %left.upper.inclusive, %right.upper.inclusive
  %upper.inclusive = select i1 %upper.equal, i1 %equal.upper.inclusive, i1 %selected.upper.inclusive
  %lower.inclusive.raw = zext i1 %lower.inclusive to i64
  %upper.inclusive.raw = zext i1 %upper.inclusive to i64
  %result = call ptr @topal.syscall.runtime.range.make(ptr %selected.lower, ptr %selected.upper, i64 %lower.inclusive.raw, i64 %upper.inclusive.raw)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.range.int.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.syscall.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.syscall.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.syscall.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.syscall.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.syscall.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.syscall.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.syscall.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal ptr @topal.syscall.runtime.range.rational.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.syscall.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.syscall.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.syscall.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.syscall.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.syscall.runtime.rational.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.syscall.runtime.rational.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.syscall.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal void @topal.syscall.runtime.range.print.symbol(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower.inclusive = call i1 @topal.syscall.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.syscall.runtime.range.upper.inclusive(ptr %range)
  br i1 %lower.inclusive, label %lower.closed, label %lower.open
lower.closed:
  br i1 %upper.inclusive, label %closed.closed, label %closed.open
lower.open:
  br i1 %upper.inclusive, label %open.closed, label %open.open
closed.closed:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.range.closed.closed, i64 5)
  ret void
closed.open:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.range.closed.open, i64 4)
  ret void
open.closed:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.range.open.closed, i64 6)
  ret void
open.open:
  call void @topal.syscall.platform.write_all(ptr @topal.syscall.runtime.range.open.open, i64 5)
  ret void
}

define internal void @topal.syscall.runtime.range.int.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.syscall.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.syscall.runtime.range.upper(ptr %range)
  call void @topal.syscall.runtime.int.print(ptr %lower)
  call void @topal.syscall.runtime.range.print.symbol(ptr %range)
  call void @topal.syscall.runtime.int.print(ptr %upper)
  ret void
}

define internal void @topal.syscall.runtime.range.rational.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.syscall.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.syscall.runtime.range.upper(ptr %range)
  call void @topal.syscall.runtime.rational.print(ptr %lower)
  call void @topal.syscall.runtime.range.print.symbol(ptr %range)
  call void @topal.syscall.runtime.rational.print(ptr %upper)
  ret void
}
; Compiler-selected List Int layout for private topal-native/6 operations.

%topal.ListStorage = type { ptr, ptr }
; Compiler-private fundamental homogeneous containers. Construction may mutate
; unpublished result nodes; published Array, Set, Bag, and Map values are immutable.

%topal.ContainerSequenceHeader = type { i64, ptr }
%topal.ContainerBagHeader = type { i64, i64, ptr }
%topal.ContainerBagNode = type { ptr, i64, ptr }
%topal.ContainerMapNode = type { ptr, ptr, ptr }

define internal i64 @topal.syscall.runtime.container.list.count(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop
done:
  ret i64 %count
}

define internal ptr @topal.syscall.runtime.container.array.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.syscall.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.syscall.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal ptr @topal.syscall.runtime.container.array.function.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.syscall.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.syscall.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal i1 @topal.syscall.runtime.container.int.list.contains(ptr %list, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.syscall.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret i1 true
absent:
  ret i1 false
}

define internal ptr @topal.syscall.runtime.container.set.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %duplicate = call i1 @topal.syscall.runtime.container.int.list.contains(ptr %head, ptr %value)
  br i1 %duplicate, label %skip, label %add
add:
  %node = call ptr @topal.syscall.platform.allocate(i64 16)
  store ptr %value, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
skip:
  br label %advance
advance:
  %head.next = phi ptr [%head, %skip], [%added.head, %added]
  %tail.next = phi ptr [%tail, %skip], [%node, %added]
  %count.next = phi i64 [%count, %skip], [%added.count, %added]
  br label %loop
done:
  %set = call ptr @topal.syscall.platform.allocate(i64 16)
  %set.count = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 0
  %set.entries = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  store i64 %count, ptr %set.count, align 8
  store ptr %head, ptr %set.entries, align 8
  ret ptr %set
}

define internal ptr @topal.syscall.runtime.container.bag.int.find(ptr %entries, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.syscall.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerBagNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.syscall.runtime.container.bag.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %total = phi i64 [0, %entry], [%total.next, %advance]
  %distinct = phi i64 [0, %entry], [%distinct.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.syscall.runtime.container.bag.int.find(ptr %head, ptr %value)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %increment, label %add
increment:
  %existing.count.pointer = getelementptr %topal.ContainerBagNode, ptr %existing, i32 0, i32 1
  %existing.count = load i64, ptr %existing.count.pointer, align 8
  %incremented = add i64 %existing.count, 1
  store i64 %incremented, ptr %existing.count.pointer, align 8
  br label %advance
add:
  %node = call ptr @topal.syscall.platform.allocate(i64 24)
  %node.value = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 0
  %node.count = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 2
  store ptr %value, ptr %node.value, align 8
  store i64 1, ptr %node.count, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerBagNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.distinct = add i64 %distinct, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %increment], [%added.head, %added]
  %tail.next = phi ptr [%tail, %increment], [%node, %added]
  %distinct.next = phi i64 [%distinct, %increment], [%added.distinct, %added]
  %total.next = add i64 %total, 1
  br label %loop
done:
  %bag = call ptr @topal.syscall.platform.allocate(i64 24)
  %bag.total = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 0
  %bag.distinct = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 1
  %bag.entries = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  store i64 %total, ptr %bag.total, align 8
  store i64 %distinct, ptr %bag.distinct, align 8
  store ptr %head, ptr %bag.entries, align 8
  ret ptr %bag
}

define internal ptr @topal.syscall.runtime.container.map.string-int.find(ptr %entries, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %equal = call i1 @topal.syscall.runtime.string.equal(ptr %candidate, ptr %key)
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerMapNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.syscall.runtime.container.map.string-int.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load ptr, ptr %source.value.pointer, align 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.syscall.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store ptr %value, ptr %existing.value, align 8
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.syscall.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store ptr %value, ptr %node.value, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.syscall.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.syscall.runtime.container.map.string-function.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load i32, ptr %source.value.pointer, align 4
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.syscall.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store i32 %value, ptr %existing.value, align 4
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.syscall.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store i32 %value, ptr %node.value, align 4
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.syscall.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.syscall.runtime.container.entry.count(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %value = call ptr @topal.syscall.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.syscall.runtime.container.empty(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %empty = icmp eq i64 %count, 0
  ret i1 %empty
}

define internal ptr @topal.syscall.runtime.container.array.int.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load ptr, ptr %current, align 8
  %some = call ptr @topal.syscall.runtime.optional.some(ptr %value)
  ret ptr %some
absent:
  %none = call ptr @topal.syscall.runtime.optional.none()
  ret ptr %none
}

define internal ptr @topal.syscall.runtime.container.array.function.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load i32, ptr %current, align 4
  %payload = call ptr @topal.syscall.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some = call ptr @topal.syscall.runtime.optional.some(ptr %payload)
  ret ptr %some
absent:
  %none = call ptr @topal.syscall.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.syscall.runtime.container.set.int.contains(ptr %set, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %present = call i1 @topal.syscall.runtime.container.int.list.contains(ptr %entries, ptr %value)
  ret i1 %present
}

define internal ptr @topal.syscall.runtime.container.bag.int.multiplicity(ptr %bag, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.syscall.runtime.container.bag.int.find(ptr %entries, ptr %value)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %zero, label %present
zero:
  %zero.value = call ptr @topal.syscall.runtime.int.from.u64(i64 0)
  ret ptr %zero.value
present:
  %count.pointer = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %count = load i64, ptr %count.pointer, align 8
  %count.value = call ptr @topal.syscall.runtime.int.from.u64(i64 %count)
  ret ptr %count.value
}

define internal ptr @topal.syscall.runtime.container.map.string-int.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.syscall.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load ptr, ptr %value.pointer, align 8
  %some.value = call ptr @topal.syscall.runtime.optional.some(ptr %value)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.syscall.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.syscall.runtime.container.map.string-function.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.syscall.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load i32, ptr %value.pointer, align 4
  %payload = call ptr @topal.syscall.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some.value = call ptr @topal.syscall.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.syscall.runtime.optional.none()
  ret ptr %none.value
}
; Qualified hooks for the owned pure numeric kernel invocation.
; No context, address or allocator function is exposed to Topal source.
declare ptr @topal_kernel_numeric_allocate_v1(i64)
declare void @topal_kernel_numeric_abort_v1() noreturn

define internal ptr @topal.syscall.platform.allocate(i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = call ptr @topal_kernel_numeric_allocate_v1(i64 %length)
  ret ptr %pointer
}

define internal void @topal.syscall.platform.exit(i64 %status) noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

define internal i64 @topal.syscall.platform.write(i64 %fd, ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}
@.topal.int.0 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@.topal.int.1 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.2 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@.topal.int.3 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.4 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@.topal.int.5 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@.topal.int.6 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@.topal.int.7 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 5] }, align 8
@.topal.int.8 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@.topal.int.9 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@.topal.int.10 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@.topal.int.11 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 10] }, align 8
@.topal.int.12 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 10] }, align 8
@.topal.int.13 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@.topal.int.14 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 5] }, align 8
@.topal.int.15 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 12] }, align 8
@.topal.int.16 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 13] }, align 8
@.topal.int.17 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 13] }, align 8
@.topal.int.18 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 14] }, align 8
@.topal.int.19 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@.topal.int.20 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@.topal.int.21 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 14] }, align 8
@.topal.int.22 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 17] }, align 8
@.topal.int.23 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 18] }, align 8
@.topal.int.24 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 18] }, align 8
@.topal.int.25 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 22] }, align 8
@.topal.int.26 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@.topal.int.27 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@.topal.int.28 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@.topal.int.29 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@.topal.int.30 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 22] }, align 8
@.topal.int.31 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 17] }, align 8
@.topal.int.32 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 12] }, align 8
@.topal.int.33 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 33] }, align 8
@.topal.int.34 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 35] }, align 8
@.topal.int.35 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 35] }, align 8
@.topal.int.36 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 39] }, align 8
@.topal.int.37 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@.topal.int.38 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@.topal.int.39 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 39] }, align 8
@.topal.int.40 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 57] }, align 8
@.topal.int.41 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 59] }, align 8
@.topal.int.42 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 59] }, align 8
@.topal.int.43 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 60] }, align 8
@.topal.int.44 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 61] }, align 8
@.topal.int.45 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 63] }, align 8
@.topal.int.46 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 63] }, align 8
@.topal.int.47 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 61] }, align 8
@.topal.int.48 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 60] }, align 8
@.topal.int.49 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 57] }, align 8
@.topal.int.50 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@.topal.int.51 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 77] }, align 8
@.topal.int.52 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 77] }, align 8
@.topal.int.53 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 79] }, align 8
@.topal.int.54 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@.topal.int.55 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@.topal.int.56 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 79] }, align 8
@.topal.int.57 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 81] }, align 8
@.topal.int.58 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 82] }, align 8
@.topal.int.59 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 82] }, align 8
@.topal.int.60 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 86] }, align 8
@.topal.int.61 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 87] }, align 8
@.topal.int.62 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 90] }, align 8
@.topal.int.63 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 90] }, align 8
@.topal.int.64 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 87] }, align 8
@.topal.int.65 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 86] }, align 8
@.topal.int.66 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 81] }, align 8
@.topal.int.67 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@.topal.int.68 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 33] }, align 8
@.topal.int.69 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 91] }, align 8
@.topal.int.70 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 95] }, align 8
@.topal.int.71 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 95] }, align 8
@.topal.int.72 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 97] }, align 8
@.topal.int.73 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 102] }, align 8
@.topal.int.74 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 102] }, align 8
@.topal.int.75 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 97] }, align 8
@.topal.int.76 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 104] }, align 8
@.topal.int.77 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 105] }, align 8
@.topal.int.78 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 105] }, align 8
@.topal.int.79 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 106] }, align 8
@.topal.int.80 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 107] }, align 8
@.topal.int.81 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 107] }, align 8
@.topal.int.82 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 106] }, align 8
@.topal.int.83 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 104] }, align 8
@.topal.int.84 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 108] }, align 8
@.topal.int.85 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 110] }, align 8
@.topal.int.86 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 110] }, align 8
@.topal.int.87 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 157] }, align 8
@.topal.int.88 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 158] }, align 8
@.topal.int.89 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 158] }, align 8
@.topal.int.90 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 157] }, align 8
@.topal.int.91 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 186] }, align 8
@.topal.int.92 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 201] }, align 8
@.topal.int.93 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 201] }, align 8
@.topal.int.94 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 217] }, align 8
@.topal.int.95 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 218] }, align 8
@.topal.int.96 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 228] }, align 8
@.topal.int.97 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 228] }, align 8
@.topal.int.98 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 218] }, align 8
@.topal.int.99 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 217] }, align 8
@.topal.int.100 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 186] }, align 8
@.topal.int.101 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 108] }, align 8
@.topal.int.102 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 229] }, align 8
@.topal.int.103 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 230] }, align 8
@.topal.int.104 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 230] }, align 8
@.topal.int.105 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 231] }, align 8
@.topal.int.106 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 257] }, align 8
@.topal.int.107 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 257] }, align 8
@.topal.int.108 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 231] }, align 8
@.topal.int.109 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 262] }, align 8
@.topal.int.110 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 263] }, align 8
@.topal.int.111 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 263] }, align 8
@.topal.int.112 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 264] }, align 8
@.topal.int.113 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 265] }, align 8
@.topal.int.114 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 267] }, align 8
@.topal.int.115 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 267] }, align 8
@.topal.int.116 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 265] }, align 8
@.topal.int.117 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 264] }, align 8
@.topal.int.118 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 262] }, align 8
@.topal.int.119 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 268] }, align 8
@.topal.int.120 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 273] }, align 8
@.topal.int.121 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 273] }, align 8
@.topal.int.122 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 292] }, align 8
@.topal.int.123 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 293] }, align 8
@.topal.int.124 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 293] }, align 8
@.topal.int.125 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 292] }, align 8
@.topal.int.126 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 302] }, align 8
@.topal.int.127 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 316] }, align 8
@.topal.int.128 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 316] }, align 8
@.topal.int.129 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 318] }, align 8
@.topal.int.130 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 334] }, align 8
@.topal.int.131 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 452] }, align 8
@.topal.int.132 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 452] }, align 8
@.topal.int.133 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 334] }, align 8
@.topal.int.134 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 318] }, align 8
@.topal.int.135 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 302] }, align 8
@.topal.int.136 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 268] }, align 8
@.topal.int.137 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 229] }, align 8
@.topal.int.138 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 91] }, align 8
define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.0(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !76 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !77, !DIExpression(), !78)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !79, !DIExpression(), !80)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !81
  %v3 = icmp eq i32 %v2, 0, !dbg !82
  %v4 = icmp eq i1 %v3, true, !dbg !83
  ret i1 %v4, !dbg !84
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d0.1(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !160 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !161, !DIExpression(), !162)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.0(ptr %arg0, ptr @.topal.int.0), !dbg !163
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !164
decision.true.0:
  br label %decision.merge.2, !dbg !165
decision.false.1:
  br label %decision.merge.2, !dbg !166
decision.merge.2:
  %v2 = phi i32 [42, %decision.true.0], [64, %decision.false.1], !dbg !167
  ret i32 %v2, !dbg !168
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.2(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !171 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !172, !DIExpression(), !173)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !174, !DIExpression(), !175)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !176
  %v3 = icmp eq i32 %v2, 0, !dbg !177
  %v4 = icmp eq i1 %v3, true, !dbg !178
  ret i1 %v4, !dbg !179
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d1_2d1.3(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !182 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !183, !DIExpression(), !184)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.2(ptr %arg0, ptr @.topal.int.1), !dbg !185
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !186
decision.true.0:
  br label %decision.merge.2, !dbg !187
decision.false.1:
  br label %decision.merge.2, !dbg !188
decision.merge.2:
  %v2 = phi i32 [68, %decision.true.0], [64, %decision.false.1], !dbg !189
  ret i32 %v2, !dbg !190
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d1.4(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !193 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !194, !DIExpression(), !195)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.2), !dbg !196
  %v2 = icmp slt i32 %v1, 0, !dbg !197
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !198
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d0.1(ptr %arg0), !dbg !199
  br label %decision.merge.2, !dbg !200
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d1_2d1.3(ptr %arg0), !dbg !201
  br label %decision.merge.2, !dbg !202
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !203
  ret i32 %v5, !dbg !204
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.5(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !207 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !208, !DIExpression(), !209)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !210, !DIExpression(), !211)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !212
  %v3 = icmp eq i32 %v2, 0, !dbg !213
  %v4 = icmp eq i1 %v3, true, !dbg !214
  ret i1 %v4, !dbg !215
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d2_2d2.6(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !218 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !219, !DIExpression(), !220)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.5(ptr %arg0, ptr @.topal.int.3), !dbg !221
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !222
decision.true.0:
  br label %decision.merge.2, !dbg !223
decision.false.1:
  br label %decision.merge.2, !dbg !224
decision.merge.2:
  %v2 = phi i32 [31, %decision.true.0], [64, %decision.false.1], !dbg !225
  ret i32 %v2, !dbg !226
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.7(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !229 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !230, !DIExpression(), !231)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !232, !DIExpression(), !233)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !234
  %v3 = icmp eq i32 %v2, 0, !dbg !235
  %v4 = icmp eq i1 %v3, true, !dbg !236
  ret i1 %v4, !dbg !237
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d3_2d3.8(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !240 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !241, !DIExpression(), !242)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.7(ptr %arg0, ptr @.topal.int.4), !dbg !243
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !244
decision.true.0:
  br label %decision.merge.2, !dbg !245
decision.false.1:
  br label %decision.merge.2, !dbg !246
decision.merge.2:
  %v2 = phi i32 [10, %decision.true.0], [64, %decision.false.1], !dbg !247
  ret i32 %v2, !dbg !248
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d2_2d3.9(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !251 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !252, !DIExpression(), !253)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.5), !dbg !254
  %v2 = icmp slt i32 %v1, 0, !dbg !255
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !256
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d2_2d2.6(ptr %arg0), !dbg !257
  br label %decision.merge.2, !dbg !258
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d3_2d3.8(ptr %arg0), !dbg !259
  br label %decision.merge.2, !dbg !260
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !261
  ret i32 %v5, !dbg !262
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d3.10(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !265 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !266, !DIExpression(), !267)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.6), !dbg !268
  %v2 = icmp slt i32 %v1, 0, !dbg !269
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !270
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d1.4(ptr %arg0), !dbg !271
  br label %decision.merge.2, !dbg !272
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d2_2d3.9(ptr %arg0), !dbg !273
  br label %decision.merge.2, !dbg !274
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !275
  ret i32 %v5, !dbg !276
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.11(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !279 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !280, !DIExpression(), !281)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !282, !DIExpression(), !283)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !284
  %v3 = icmp eq i32 %v2, 0, !dbg !285
  %v4 = icmp eq i1 %v3, true, !dbg !286
  ret i1 %v4, !dbg !287
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d5_2d5.12(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !290 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !291, !DIExpression(), !292)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.11(ptr %arg0, ptr @.topal.int.7), !dbg !293
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !294
decision.true.0:
  br label %decision.merge.2, !dbg !295
decision.false.1:
  br label %decision.merge.2, !dbg !296
decision.merge.2:
  %v2 = phi i32 [22, %decision.true.0], [64, %decision.false.1], !dbg !297
  ret i32 %v2, !dbg !298
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.13(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !301 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !302, !DIExpression(), !303)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !304, !DIExpression(), !305)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !306
  %v3 = icmp eq i32 %v2, 0, !dbg !307
  %v4 = icmp eq i1 %v3, true, !dbg !308
  ret i1 %v4, !dbg !309
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d7_2d7.14(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !312 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !313, !DIExpression(), !314)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.13(ptr %arg0, ptr @.topal.int.8), !dbg !315
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !316
decision.true.0:
  br label %decision.merge.2, !dbg !317
decision.false.1:
  br label %decision.merge.2, !dbg !318
decision.merge.2:
  %v2 = phi i32 [36, %decision.true.0], [64, %decision.false.1], !dbg !319
  ret i32 %v2, !dbg !320
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d5_2d7.15(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !323 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !324, !DIExpression(), !325)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.9), !dbg !326
  %v2 = icmp slt i32 %v1, 0, !dbg !327
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !328
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d5_2d5.12(ptr %arg0), !dbg !329
  br label %decision.merge.2, !dbg !330
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d7_2d7.14(ptr %arg0), !dbg !331
  br label %decision.merge.2, !dbg !332
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !333
  ret i32 %v5, !dbg !334
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.16(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !337 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !338, !DIExpression(), !339)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !340, !DIExpression(), !341)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !342
  %v3 = icmp eq i32 %v2, 0, !dbg !343
  %v4 = icmp eq i1 %v3, true, !dbg !344
  ret i1 %v4, !dbg !345
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d8_2d8.17(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !348 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !349, !DIExpression(), !350)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.16(ptr %arg0, ptr @.topal.int.10), !dbg !351
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !352
decision.true.0:
  br label %decision.merge.2, !dbg !353
decision.false.1:
  br label %decision.merge.2, !dbg !354
decision.merge.2:
  %v2 = phi i32 [54, %decision.true.0], [64, %decision.false.1], !dbg !355
  ret i32 %v2, !dbg !356
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.18(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !359 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !360, !DIExpression(), !361)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !362, !DIExpression(), !363)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !364
  %v3 = icmp eq i32 %v2, 0, !dbg !365
  %v4 = icmp eq i1 %v3, true, !dbg !366
  ret i1 %v4, !dbg !367
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d10_2d10.19(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !370 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !371, !DIExpression(), !372)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.18(ptr %arg0, ptr @.topal.int.11), !dbg !373
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !374
decision.true.0:
  br label %decision.merge.2, !dbg !375
decision.false.1:
  br label %decision.merge.2, !dbg !376
decision.merge.2:
  %v2 = phi i32 [40, %decision.true.0], [64, %decision.false.1], !dbg !377
  ret i32 %v2, !dbg !378
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d8_2d10.20(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !381 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !382, !DIExpression(), !383)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.12), !dbg !384
  %v2 = icmp slt i32 %v1, 0, !dbg !385
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !386
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d8_2d8.17(ptr %arg0), !dbg !387
  br label %decision.merge.2, !dbg !388
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d10_2d10.19(ptr %arg0), !dbg !389
  br label %decision.merge.2, !dbg !390
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !391
  ret i32 %v5, !dbg !392
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d5_2d10.21(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !395 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !396, !DIExpression(), !397)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.13), !dbg !398
  %v2 = icmp slt i32 %v1, 0, !dbg !399
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !400
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d5_2d7.15(ptr %arg0), !dbg !401
  br label %decision.merge.2, !dbg !402
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d8_2d10.20(ptr %arg0), !dbg !403
  br label %decision.merge.2, !dbg !404
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !405
  ret i32 %v5, !dbg !406
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d10.22(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !409 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !410, !DIExpression(), !411)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.14), !dbg !412
  %v2 = icmp slt i32 %v1, 0, !dbg !413
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !414
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d3.10(ptr %arg0), !dbg !415
  br label %decision.merge.2, !dbg !416
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d5_2d10.21(ptr %arg0), !dbg !417
  br label %decision.merge.2, !dbg !418
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !419
  ret i32 %v5, !dbg !420
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.23(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !423 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !424, !DIExpression(), !425)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !426, !DIExpression(), !427)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !428
  %v3 = icmp eq i32 %v2, 0, !dbg !429
  %v4 = icmp eq i1 %v3, true, !dbg !430
  ret i1 %v4, !dbg !431
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d12.24(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !434 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !435, !DIExpression(), !436)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.23(ptr %arg0, ptr @.topal.int.15), !dbg !437
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !438
decision.true.0:
  br label %decision.merge.2, !dbg !439
decision.false.1:
  br label %decision.merge.2, !dbg !440
decision.merge.2:
  %v2 = phi i32 [39, %decision.true.0], [64, %decision.false.1], !dbg !441
  ret i32 %v2, !dbg !442
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.25(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !445 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !446, !DIExpression(), !447)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !448, !DIExpression(), !449)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !450
  %v3 = icmp eq i32 %v2, 0, !dbg !451
  %v4 = icmp eq i1 %v3, true, !dbg !452
  ret i1 %v4, !dbg !453
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d13_2d13.26(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !456 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !457, !DIExpression(), !458)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.25(ptr %arg0, ptr @.topal.int.16), !dbg !459
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !460
decision.true.0:
  br label %decision.merge.2, !dbg !461
decision.false.1:
  br label %decision.merge.2, !dbg !462
decision.merge.2:
  %v2 = phi i32 [57, %decision.true.0], [64, %decision.false.1], !dbg !463
  ret i32 %v2, !dbg !464
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d13.27(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !467 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !468, !DIExpression(), !469)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.17), !dbg !470
  %v2 = icmp slt i32 %v1, 0, !dbg !471
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !472
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d12.24(ptr %arg0), !dbg !473
  br label %decision.merge.2, !dbg !474
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d13_2d13.26(ptr %arg0), !dbg !475
  br label %decision.merge.2, !dbg !476
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !477
  ret i32 %v5, !dbg !478
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.28(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !481 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !482, !DIExpression(), !483)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !484, !DIExpression(), !485)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !486
  %v3 = icmp eq i32 %v2, 0, !dbg !487
  %v4 = icmp eq i1 %v3, true, !dbg !488
  ret i1 %v4, !dbg !489
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d14_2d14.29(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !492 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !493, !DIExpression(), !494)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.28(ptr %arg0, ptr @.topal.int.18), !dbg !495
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !496
decision.true.0:
  br label %decision.merge.2, !dbg !497
decision.false.1:
  br label %decision.merge.2, !dbg !498
decision.merge.2:
  %v2 = phi i32 [58, %decision.true.0], [64, %decision.false.1], !dbg !499
  ret i32 %v2, !dbg !500
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.30(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !503 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !504, !DIExpression(), !505)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !506, !DIExpression(), !507)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !508
  %v3 = icmp eq i32 %v2, 0, !dbg !509
  %v4 = icmp eq i1 %v3, true, !dbg !510
  ret i1 %v4, !dbg !511
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d16_2d16.31(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !514 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !515, !DIExpression(), !516)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.30(ptr %arg0, ptr @.topal.int.19), !dbg !517
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !518
decision.true.0:
  br label %decision.merge.2, !dbg !519
decision.false.1:
  br label %decision.merge.2, !dbg !520
decision.merge.2:
  %v2 = phi i32 [26, %decision.true.0], [64, %decision.false.1], !dbg !521
  ret i32 %v2, !dbg !522
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d14_2d16.32(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !525 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !526, !DIExpression(), !527)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.20), !dbg !528
  %v2 = icmp slt i32 %v1, 0, !dbg !529
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !530
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d14_2d14.29(ptr %arg0), !dbg !531
  br label %decision.merge.2, !dbg !532
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d16_2d16.31(ptr %arg0), !dbg !533
  br label %decision.merge.2, !dbg !534
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !535
  ret i32 %v5, !dbg !536
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d16.33(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !539 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !540, !DIExpression(), !541)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.21), !dbg !542
  %v2 = icmp slt i32 %v1, 0, !dbg !543
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !544
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d13.27(ptr %arg0), !dbg !545
  br label %decision.merge.2, !dbg !546
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d14_2d16.32(ptr %arg0), !dbg !547
  br label %decision.merge.2, !dbg !548
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !549
  ret i32 %v5, !dbg !550
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.34(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !553 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !554, !DIExpression(), !555)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !556, !DIExpression(), !557)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !558
  %v3 = icmp eq i32 %v2, 0, !dbg !559
  %v4 = icmp eq i1 %v3, true, !dbg !560
  ret i1 %v4, !dbg !561
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d17_2d17.35(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !564 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !565, !DIExpression(), !566)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.34(ptr %arg0, ptr @.topal.int.22), !dbg !567
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !568
decision.true.0:
  br label %decision.merge.2, !dbg !569
decision.false.1:
  br label %decision.merge.2, !dbg !570
decision.merge.2:
  %v2 = phi i32 [43, %decision.true.0], [64, %decision.false.1], !dbg !571
  ret i32 %v2, !dbg !572
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.36(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !575 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !576, !DIExpression(), !577)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !578, !DIExpression(), !579)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !580
  %v3 = icmp eq i32 %v2, 0, !dbg !581
  %v4 = icmp eq i1 %v3, true, !dbg !582
  ret i1 %v4, !dbg !583
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d18_2d18.37(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !586 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !587, !DIExpression(), !588)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.36(ptr %arg0, ptr @.topal.int.23), !dbg !589
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !590
decision.true.0:
  br label %decision.merge.2, !dbg !591
decision.false.1:
  br label %decision.merge.2, !dbg !592
decision.merge.2:
  %v2 = phi i32 [69, %decision.true.0], [64, %decision.false.1], !dbg !593
  ret i32 %v2, !dbg !594
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d17_2d18.38(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !597 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !598, !DIExpression(), !599)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.24), !dbg !600
  %v2 = icmp slt i32 %v1, 0, !dbg !601
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !602
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d17_2d17.35(ptr %arg0), !dbg !603
  br label %decision.merge.2, !dbg !604
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d18_2d18.37(ptr %arg0), !dbg !605
  br label %decision.merge.2, !dbg !606
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !607
  ret i32 %v5, !dbg !608
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.39(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !611 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !612, !DIExpression(), !613)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !614, !DIExpression(), !615)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !616
  %v3 = icmp eq i32 %v2, 0, !dbg !617
  %v4 = icmp eq i1 %v3, true, !dbg !618
  ret i1 %v4, !dbg !619
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d22_2d22.40(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !622 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !623, !DIExpression(), !624)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.39(ptr %arg0, ptr @.topal.int.25), !dbg !625
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !626
decision.true.0:
  br label %decision.merge.2, !dbg !627
decision.false.1:
  br label %decision.merge.2, !dbg !628
decision.merge.2:
  %v2 = phi i32 [34, %decision.true.0], [64, %decision.false.1], !dbg !629
  ret i32 %v2, !dbg !630
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.41(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !633 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !634, !DIExpression(), !635)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !636, !DIExpression(), !637)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !638
  %v3 = icmp eq i32 %v2, 0, !dbg !639
  %v4 = icmp eq i1 %v3, true, !dbg !640
  ret i1 %v4, !dbg !641
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d24_2d24.42(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !644 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !645, !DIExpression(), !646)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.41(ptr %arg0, ptr @.topal.int.26), !dbg !647
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !648
decision.true.0:
  br label %decision.merge.2, !dbg !649
decision.false.1:
  br label %decision.merge.2, !dbg !650
decision.merge.2:
  %v2 = phi i32 [70, %decision.true.0], [64, %decision.false.1], !dbg !651
  ret i32 %v2, !dbg !652
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.43(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !655 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !656, !DIExpression(), !657)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !658, !DIExpression(), !659)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !660
  %v3 = icmp eq i32 %v2, 0, !dbg !661
  %v4 = icmp eq i1 %v3, true, !dbg !662
  ret i1 %v4, !dbg !663
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d32_2d32.44(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !666 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !667, !DIExpression(), !668)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.43(ptr %arg0, ptr @.topal.int.27), !dbg !669
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !670
decision.true.0:
  br label %decision.merge.2, !dbg !671
decision.false.1:
  br label %decision.merge.2, !dbg !672
decision.merge.2:
  %v2 = phi i32 [12, %decision.true.0], [64, %decision.false.1], !dbg !673
  ret i32 %v2, !dbg !674
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d24_2d32.45(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !677 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !678, !DIExpression(), !679)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.28), !dbg !680
  %v2 = icmp slt i32 %v1, 0, !dbg !681
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !682
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d24_2d24.42(ptr %arg0), !dbg !683
  br label %decision.merge.2, !dbg !684
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d32_2d32.44(ptr %arg0), !dbg !685
  br label %decision.merge.2, !dbg !686
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !687
  ret i32 %v5, !dbg !688
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d22_2d32.46(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !691 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !692, !DIExpression(), !693)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.29), !dbg !694
  %v2 = icmp slt i32 %v1, 0, !dbg !695
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !696
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d22_2d22.40(ptr %arg0), !dbg !697
  br label %decision.merge.2, !dbg !698
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d24_2d32.45(ptr %arg0), !dbg !699
  br label %decision.merge.2, !dbg !700
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !701
  ret i32 %v5, !dbg !702
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d17_2d32.47(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !705 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !706, !DIExpression(), !707)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.30), !dbg !708
  %v2 = icmp slt i32 %v1, 0, !dbg !709
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !710
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d17_2d18.38(ptr %arg0), !dbg !711
  br label %decision.merge.2, !dbg !712
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d22_2d32.46(ptr %arg0), !dbg !713
  br label %decision.merge.2, !dbg !714
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !715
  ret i32 %v5, !dbg !716
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d32.48(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !719 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !720, !DIExpression(), !721)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.31), !dbg !722
  %v2 = icmp slt i32 %v1, 0, !dbg !723
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !724
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d16.33(ptr %arg0), !dbg !725
  br label %decision.merge.2, !dbg !726
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d17_2d32.47(ptr %arg0), !dbg !727
  br label %decision.merge.2, !dbg !728
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !729
  ret i32 %v5, !dbg !730
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d32.49(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !733 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !734, !DIExpression(), !735)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.32), !dbg !736
  %v2 = icmp slt i32 %v1, 0, !dbg !737
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !738
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d10.22(ptr %arg0), !dbg !739
  br label %decision.merge.2, !dbg !740
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d12_2d32.48(ptr %arg0), !dbg !741
  br label %decision.merge.2, !dbg !742
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !743
  ret i32 %v5, !dbg !744
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.50(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !747 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !748, !DIExpression(), !749)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !750, !DIExpression(), !751)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !752
  %v3 = icmp eq i32 %v2, 0, !dbg !753
  %v4 = icmp eq i1 %v3, true, !dbg !754
  ret i1 %v4, !dbg !755
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d33.51(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !758 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !759, !DIExpression(), !760)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.50(ptr %arg0, ptr @.topal.int.33), !dbg !761
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !762
decision.true.0:
  br label %decision.merge.2, !dbg !763
decision.false.1:
  br label %decision.merge.2, !dbg !764
decision.merge.2:
  %v2 = phi i32 [13, %decision.true.0], [64, %decision.false.1], !dbg !765
  ret i32 %v2, !dbg !766
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.52(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !769 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !770, !DIExpression(), !771)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !772, !DIExpression(), !773)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !774
  %v3 = icmp eq i32 %v2, 0, !dbg !775
  %v4 = icmp eq i1 %v3, true, !dbg !776
  ret i1 %v4, !dbg !777
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d35_2d35.53(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !780 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !781, !DIExpression(), !782)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.52(ptr %arg0, ptr @.topal.int.34), !dbg !783
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !784
decision.true.0:
  br label %decision.merge.2, !dbg !785
decision.false.1:
  br label %decision.merge.2, !dbg !786
decision.merge.2:
  %v2 = phi i32 [30, %decision.true.0], [64, %decision.false.1], !dbg !787
  ret i32 %v2, !dbg !788
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d35.54(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !791 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !792, !DIExpression(), !793)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.35), !dbg !794
  %v2 = icmp slt i32 %v1, 0, !dbg !795
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !796
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d33.51(ptr %arg0), !dbg !797
  br label %decision.merge.2, !dbg !798
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d35_2d35.53(ptr %arg0), !dbg !799
  br label %decision.merge.2, !dbg !800
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !801
  ret i32 %v5, !dbg !802
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.55(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !805 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !806, !DIExpression(), !807)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !808, !DIExpression(), !809)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !810
  %v3 = icmp eq i32 %v2, 0, !dbg !811
  %v4 = icmp eq i1 %v3, true, !dbg !812
  ret i1 %v4, !dbg !813
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d39_2d39.56(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !816 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !817, !DIExpression(), !818)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.55(ptr %arg0, ptr @.topal.int.36), !dbg !819
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !820
decision.true.0:
  br label %decision.merge.2, !dbg !821
decision.false.1:
  br label %decision.merge.2, !dbg !822
decision.merge.2:
  %v2 = phi i32 [38, %decision.true.0], [64, %decision.false.1], !dbg !823
  ret i32 %v2, !dbg !824
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.57(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !827 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !828, !DIExpression(), !829)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !830, !DIExpression(), !831)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !832
  %v3 = icmp eq i32 %v2, 0, !dbg !833
  %v4 = icmp eq i1 %v3, true, !dbg !834
  ret i1 %v4, !dbg !835
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d56_2d56.58(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !838 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !839, !DIExpression(), !840)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.57(ptr %arg0, ptr @.topal.int.37), !dbg !841
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !842
decision.true.0:
  br label %decision.merge.2, !dbg !843
decision.false.1:
  br label %decision.merge.2, !dbg !844
decision.merge.2:
  %v2 = phi i32 [9, %decision.true.0], [64, %decision.false.1], !dbg !845
  ret i32 %v2, !dbg !846
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d39_2d56.59(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !849 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !850, !DIExpression(), !851)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.38), !dbg !852
  %v2 = icmp slt i32 %v1, 0, !dbg !853
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !854
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d39_2d39.56(ptr %arg0), !dbg !855
  br label %decision.merge.2, !dbg !856
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d56_2d56.58(ptr %arg0), !dbg !857
  br label %decision.merge.2, !dbg !858
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !859
  ret i32 %v5, !dbg !860
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d56.60(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !863 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !864, !DIExpression(), !865)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.39), !dbg !866
  %v2 = icmp slt i32 %v1, 0, !dbg !867
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !868
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d35.54(ptr %arg0), !dbg !869
  br label %decision.merge.2, !dbg !870
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d39_2d56.59(ptr %arg0), !dbg !871
  br label %decision.merge.2, !dbg !872
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !873
  ret i32 %v5, !dbg !874
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.61(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !877 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !878, !DIExpression(), !879)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !880, !DIExpression(), !881)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !882
  %v3 = icmp eq i32 %v2, 0, !dbg !883
  %v4 = icmp eq i1 %v3, true, !dbg !884
  ret i1 %v4, !dbg !885
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d57_2d57.62(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !888 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !889, !DIExpression(), !890)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.61(ptr %arg0, ptr @.topal.int.40), !dbg !891
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !892
decision.true.0:
  br label %decision.merge.2, !dbg !893
decision.false.1:
  br label %decision.merge.2, !dbg !894
decision.merge.2:
  %v2 = phi i32 [24, %decision.true.0], [64, %decision.false.1], !dbg !895
  ret i32 %v2, !dbg !896
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.63(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !899 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !900, !DIExpression(), !901)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !902, !DIExpression(), !903)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !904
  %v3 = icmp eq i32 %v2, 0, !dbg !905
  %v4 = icmp eq i1 %v3, true, !dbg !906
  ret i1 %v4, !dbg !907
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d59_2d59.64(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !910 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !911, !DIExpression(), !912)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.63(ptr %arg0, ptr @.topal.int.41), !dbg !913
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !914
decision.true.0:
  br label %decision.merge.2, !dbg !915
decision.false.1:
  br label %decision.merge.2, !dbg !916
decision.merge.2:
  %v2 = phi i32 [17, %decision.true.0], [64, %decision.false.1], !dbg !917
  ret i32 %v2, !dbg !918
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d57_2d59.65(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !921 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !922, !DIExpression(), !923)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.42), !dbg !924
  %v2 = icmp slt i32 %v1, 0, !dbg !925
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !926
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d57_2d57.62(ptr %arg0), !dbg !927
  br label %decision.merge.2, !dbg !928
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d59_2d59.64(ptr %arg0), !dbg !929
  br label %decision.merge.2, !dbg !930
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !931
  ret i32 %v5, !dbg !932
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.66(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !935 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !936, !DIExpression(), !937)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !938, !DIExpression(), !939)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !940
  %v3 = icmp eq i32 %v2, 0, !dbg !941
  %v4 = icmp eq i1 %v3, true, !dbg !942
  ret i1 %v4, !dbg !943
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d60_2d60.67(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !946 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !947, !DIExpression(), !948)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.66(ptr %arg0, ptr @.topal.int.43), !dbg !949
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !950
decision.true.0:
  br label %decision.merge.2, !dbg !951
decision.false.1:
  br label %decision.merge.2, !dbg !952
decision.merge.2:
  %v2 = phi i32 [18, %decision.true.0], [64, %decision.false.1], !dbg !953
  ret i32 %v2, !dbg !954
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.68(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !957 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !958, !DIExpression(), !959)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !960, !DIExpression(), !961)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !962
  %v3 = icmp eq i32 %v2, 0, !dbg !963
  %v4 = icmp eq i1 %v3, true, !dbg !964
  ret i1 %v4, !dbg !965
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d61_2d61.69(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !968 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !969, !DIExpression(), !970)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.68(ptr %arg0, ptr @.topal.int.44), !dbg !971
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !972
decision.true.0:
  br label %decision.merge.2, !dbg !973
decision.false.1:
  br label %decision.merge.2, !dbg !974
decision.merge.2:
  %v2 = phi i32 [66, %decision.true.0], [64, %decision.false.1], !dbg !975
  ret i32 %v2, !dbg !976
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.70(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !979 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !980, !DIExpression(), !981)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !982, !DIExpression(), !983)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !984
  %v3 = icmp eq i32 %v2, 0, !dbg !985
  %v4 = icmp eq i1 %v3, true, !dbg !986
  ret i1 %v4, !dbg !987
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d63_2d63.71(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !990 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !991, !DIExpression(), !992)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.70(ptr %arg0, ptr @.topal.int.45), !dbg !993
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !994
decision.true.0:
  br label %decision.merge.2, !dbg !995
decision.false.1:
  br label %decision.merge.2, !dbg !996
decision.merge.2:
  %v2 = phi i32 [27, %decision.true.0], [64, %decision.false.1], !dbg !997
  ret i32 %v2, !dbg !998
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d61_2d63.72(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1001 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1002, !DIExpression(), !1003)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.46), !dbg !1004
  %v2 = icmp slt i32 %v1, 0, !dbg !1005
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1006
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d61_2d61.69(ptr %arg0), !dbg !1007
  br label %decision.merge.2, !dbg !1008
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d63_2d63.71(ptr %arg0), !dbg !1009
  br label %decision.merge.2, !dbg !1010
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1011
  ret i32 %v5, !dbg !1012
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d60_2d63.73(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1015 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1016, !DIExpression(), !1017)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.47), !dbg !1018
  %v2 = icmp slt i32 %v1, 0, !dbg !1019
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1020
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d60_2d60.67(ptr %arg0), !dbg !1021
  br label %decision.merge.2, !dbg !1022
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d61_2d63.72(ptr %arg0), !dbg !1023
  br label %decision.merge.2, !dbg !1024
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1025
  ret i32 %v5, !dbg !1026
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d57_2d63.74(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1029 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1030, !DIExpression(), !1031)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.48), !dbg !1032
  %v2 = icmp slt i32 %v1, 0, !dbg !1033
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1034
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d57_2d59.65(ptr %arg0), !dbg !1035
  br label %decision.merge.2, !dbg !1036
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d60_2d63.73(ptr %arg0), !dbg !1037
  br label %decision.merge.2, !dbg !1038
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1039
  ret i32 %v5, !dbg !1040
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d63.75(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1043 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1044, !DIExpression(), !1045)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.49), !dbg !1046
  %v2 = icmp slt i32 %v1, 0, !dbg !1047
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1048
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d56.60(ptr %arg0), !dbg !1049
  br label %decision.merge.2, !dbg !1050
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d57_2d63.74(ptr %arg0), !dbg !1051
  br label %decision.merge.2, !dbg !1052
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1053
  ret i32 %v5, !dbg !1054
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.76(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1057 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1058, !DIExpression(), !1059)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1060, !DIExpression(), !1061)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1062
  %v3 = icmp eq i32 %v2, 0, !dbg !1063
  %v4 = icmp eq i1 %v3, true, !dbg !1064
  ret i1 %v4, !dbg !1065
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d72.77(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1068 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1069, !DIExpression(), !1070)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.76(ptr %arg0, ptr @.topal.int.50), !dbg !1071
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1072
decision.true.0:
  br label %decision.merge.2, !dbg !1073
decision.false.1:
  br label %decision.merge.2, !dbg !1074
decision.merge.2:
  %v2 = phi i32 [20, %decision.true.0], [64, %decision.false.1], !dbg !1075
  ret i32 %v2, !dbg !1076
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.78(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1079 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1080, !DIExpression(), !1081)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1082, !DIExpression(), !1083)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1084
  %v3 = icmp eq i32 %v2, 0, !dbg !1085
  %v4 = icmp eq i1 %v3, true, !dbg !1086
  ret i1 %v4, !dbg !1087
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d77_2d77.79(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1090 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1091, !DIExpression(), !1092)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.78(ptr %arg0, ptr @.topal.int.51), !dbg !1093
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1094
decision.true.0:
  br label %decision.merge.2, !dbg !1095
decision.false.1:
  br label %decision.merge.2, !dbg !1096
decision.merge.2:
  %v2 = phi i32 [61, %decision.true.0], [64, %decision.false.1], !dbg !1097
  ret i32 %v2, !dbg !1098
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d77.80(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1101 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1102, !DIExpression(), !1103)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.52), !dbg !1104
  %v2 = icmp slt i32 %v1, 0, !dbg !1105
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1106
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d72.77(ptr %arg0), !dbg !1107
  br label %decision.merge.2, !dbg !1108
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d77_2d77.79(ptr %arg0), !dbg !1109
  br label %decision.merge.2, !dbg !1110
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1111
  ret i32 %v5, !dbg !1112
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.81(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1115 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1116, !DIExpression(), !1117)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1118, !DIExpression(), !1119)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1120
  %v3 = icmp eq i32 %v2, 0, !dbg !1121
  %v4 = icmp eq i1 %v3, true, !dbg !1122
  ret i1 %v4, !dbg !1123
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d79_2d79.82(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1126 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1127, !DIExpression(), !1128)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.81(ptr %arg0, ptr @.topal.int.53), !dbg !1129
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1130
decision.true.0:
  br label %decision.merge.2, !dbg !1131
decision.false.1:
  br label %decision.merge.2, !dbg !1132
decision.merge.2:
  %v2 = phi i32 [67, %decision.true.0], [64, %decision.false.1], !dbg !1133
  ret i32 %v2, !dbg !1134
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.83(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1137 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1138, !DIExpression(), !1139)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1140, !DIExpression(), !1141)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1142
  %v3 = icmp eq i32 %v2, 0, !dbg !1143
  %v4 = icmp eq i1 %v3, true, !dbg !1144
  ret i1 %v4, !dbg !1145
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d80_2d80.84(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1148 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1149, !DIExpression(), !1150)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.83(ptr %arg0, ptr @.topal.int.54), !dbg !1151
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1152
decision.true.0:
  br label %decision.merge.2, !dbg !1153
decision.false.1:
  br label %decision.merge.2, !dbg !1154
decision.merge.2:
  %v2 = phi i32 [0, %decision.true.0], [64, %decision.false.1], !dbg !1155
  ret i32 %v2, !dbg !1156
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d79_2d80.85(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1159 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1160, !DIExpression(), !1161)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.55), !dbg !1162
  %v2 = icmp slt i32 %v1, 0, !dbg !1163
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1164
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d79_2d79.82(ptr %arg0), !dbg !1165
  br label %decision.merge.2, !dbg !1166
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d80_2d80.84(ptr %arg0), !dbg !1167
  br label %decision.merge.2, !dbg !1168
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1169
  ret i32 %v5, !dbg !1170
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d80.86(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1173 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1174, !DIExpression(), !1175)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.56), !dbg !1176
  %v2 = icmp slt i32 %v1, 0, !dbg !1177
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1178
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d77.80(ptr %arg0), !dbg !1179
  br label %decision.merge.2, !dbg !1180
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d79_2d80.85(ptr %arg0), !dbg !1181
  br label %decision.merge.2, !dbg !1182
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1183
  ret i32 %v5, !dbg !1184
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.87(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1187 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1188, !DIExpression(), !1189)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1190, !DIExpression(), !1191)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1192
  %v3 = icmp eq i32 %v2, 0, !dbg !1193
  %v4 = icmp eq i1 %v3, true, !dbg !1194
  ret i1 %v4, !dbg !1195
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d81_2d81.88(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1198 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1199, !DIExpression(), !1200)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.87(ptr %arg0, ptr @.topal.int.57), !dbg !1201
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1202
decision.true.0:
  br label %decision.merge.2, !dbg !1203
decision.false.1:
  br label %decision.merge.2, !dbg !1204
decision.merge.2:
  %v2 = phi i32 [1, %decision.true.0], [64, %decision.false.1], !dbg !1205
  ret i32 %v2, !dbg !1206
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.89(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1209 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1210, !DIExpression(), !1211)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1212, !DIExpression(), !1213)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1214
  %v3 = icmp eq i32 %v2, 0, !dbg !1215
  %v4 = icmp eq i1 %v3, true, !dbg !1216
  ret i1 %v4, !dbg !1217
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d82_2d82.90(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1220 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1221, !DIExpression(), !1222)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.89(ptr %arg0, ptr @.topal.int.58), !dbg !1223
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1224
decision.true.0:
  br label %decision.merge.2, !dbg !1225
decision.false.1:
  br label %decision.merge.2, !dbg !1226
decision.merge.2:
  %v2 = phi i32 [48, %decision.true.0], [64, %decision.false.1], !dbg !1227
  ret i32 %v2, !dbg !1228
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d81_2d82.91(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1231 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1232, !DIExpression(), !1233)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.59), !dbg !1234
  %v2 = icmp slt i32 %v1, 0, !dbg !1235
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1236
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d81_2d81.88(ptr %arg0), !dbg !1237
  br label %decision.merge.2, !dbg !1238
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d82_2d82.90(ptr %arg0), !dbg !1239
  br label %decision.merge.2, !dbg !1240
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1241
  ret i32 %v5, !dbg !1242
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.92(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1245 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1246, !DIExpression(), !1247)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1248, !DIExpression(), !1249)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1250
  %v3 = icmp eq i32 %v2, 0, !dbg !1251
  %v4 = icmp eq i1 %v3, true, !dbg !1252
  ret i1 %v4, !dbg !1253
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d86_2d86.93(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1256 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1257, !DIExpression(), !1258)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.92(ptr %arg0, ptr @.topal.int.60), !dbg !1259
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1260
decision.true.0:
  br label %decision.merge.2, !dbg !1261
decision.false.1:
  br label %decision.merge.2, !dbg !1262
decision.merge.2:
  %v2 = phi i32 [28, %decision.true.0], [64, %decision.false.1], !dbg !1263
  ret i32 %v2, !dbg !1264
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.94(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1267 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1268, !DIExpression(), !1269)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1270, !DIExpression(), !1271)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1272
  %v3 = icmp eq i32 %v2, 0, !dbg !1273
  %v4 = icmp eq i1 %v3, true, !dbg !1274
  ret i1 %v4, !dbg !1275
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d87_2d87.95(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1278 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1279, !DIExpression(), !1280)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.94(ptr %arg0, ptr @.topal.int.61), !dbg !1281
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1282
decision.true.0:
  br label %decision.merge.2, !dbg !1283
decision.false.1:
  br label %decision.merge.2, !dbg !1284
decision.merge.2:
  %v2 = phi i32 [62, %decision.true.0], [64, %decision.false.1], !dbg !1285
  ret i32 %v2, !dbg !1286
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.96(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1289 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1290, !DIExpression(), !1291)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1292, !DIExpression(), !1293)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1294
  %v3 = icmp eq i32 %v2, 0, !dbg !1295
  %v4 = icmp eq i1 %v3, true, !dbg !1296
  ret i1 %v4, !dbg !1297
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d90_2d90.97(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1300 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1301, !DIExpression(), !1302)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.96(ptr %arg0, ptr @.topal.int.62), !dbg !1303
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1304
decision.true.0:
  br label %decision.merge.2, !dbg !1305
decision.false.1:
  br label %decision.merge.2, !dbg !1306
decision.merge.2:
  %v2 = phi i32 [2, %decision.true.0], [64, %decision.false.1], !dbg !1307
  ret i32 %v2, !dbg !1308
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d87_2d90.98(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1311 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1312, !DIExpression(), !1313)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.63), !dbg !1314
  %v2 = icmp slt i32 %v1, 0, !dbg !1315
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1316
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d87_2d87.95(ptr %arg0), !dbg !1317
  br label %decision.merge.2, !dbg !1318
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d90_2d90.97(ptr %arg0), !dbg !1319
  br label %decision.merge.2, !dbg !1320
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1321
  ret i32 %v5, !dbg !1322
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d86_2d90.99(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1325 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1326, !DIExpression(), !1327)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.64), !dbg !1328
  %v2 = icmp slt i32 %v1, 0, !dbg !1329
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1330
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d86_2d86.93(ptr %arg0), !dbg !1331
  br label %decision.merge.2, !dbg !1332
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d87_2d90.98(ptr %arg0), !dbg !1333
  br label %decision.merge.2, !dbg !1334
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1335
  ret i32 %v5, !dbg !1336
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d81_2d90.100(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1339 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1340, !DIExpression(), !1341)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.65), !dbg !1342
  %v2 = icmp slt i32 %v1, 0, !dbg !1343
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1344
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d81_2d82.91(ptr %arg0), !dbg !1345
  br label %decision.merge.2, !dbg !1346
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d86_2d90.99(ptr %arg0), !dbg !1347
  br label %decision.merge.2, !dbg !1348
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1349
  ret i32 %v5, !dbg !1350
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d90.101(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1353 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1354, !DIExpression(), !1355)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.66), !dbg !1356
  %v2 = icmp slt i32 %v1, 0, !dbg !1357
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1358
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d80.86(ptr %arg0), !dbg !1359
  br label %decision.merge.2, !dbg !1360
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d81_2d90.100(ptr %arg0), !dbg !1361
  br label %decision.merge.2, !dbg !1362
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1363
  ret i32 %v5, !dbg !1364
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d90.102(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1367 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1368, !DIExpression(), !1369)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.67), !dbg !1370
  %v2 = icmp slt i32 %v1, 0, !dbg !1371
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1372
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d63.75(ptr %arg0), !dbg !1373
  br label %decision.merge.2, !dbg !1374
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d72_2d90.101(ptr %arg0), !dbg !1375
  br label %decision.merge.2, !dbg !1376
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1377
  ret i32 %v5, !dbg !1378
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d90.103(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1381 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1382, !DIExpression(), !1383)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.68), !dbg !1384
  %v2 = icmp slt i32 %v1, 0, !dbg !1385
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1386
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d32.49(ptr %arg0), !dbg !1387
  br label %decision.merge.2, !dbg !1388
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d33_2d90.102(ptr %arg0), !dbg !1389
  br label %decision.merge.2, !dbg !1390
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1391
  ret i32 %v5, !dbg !1392
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.104(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1395 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1396, !DIExpression(), !1397)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1398, !DIExpression(), !1399)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1400
  %v3 = icmp eq i32 %v2, 0, !dbg !1401
  %v4 = icmp eq i1 %v3, true, !dbg !1402
  ret i1 %v4, !dbg !1403
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d91.105(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1406 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1407, !DIExpression(), !1408)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.104(ptr %arg0, ptr @.topal.int.69), !dbg !1409
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1410
decision.true.0:
  br label %decision.merge.2, !dbg !1411
decision.false.1:
  br label %decision.merge.2, !dbg !1412
decision.merge.2:
  %v2 = phi i32 [5, %decision.true.0], [64, %decision.false.1], !dbg !1413
  ret i32 %v2, !dbg !1414
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.106(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1417 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1418, !DIExpression(), !1419)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1420, !DIExpression(), !1421)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1422
  %v3 = icmp eq i32 %v2, 0, !dbg !1423
  %v4 = icmp eq i1 %v3, true, !dbg !1424
  ret i1 %v4, !dbg !1425
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d95_2d95.107(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1428 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1429, !DIExpression(), !1430)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.106(ptr %arg0, ptr @.topal.int.70), !dbg !1431
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1432
decision.true.0:
  br label %decision.merge.2, !dbg !1433
decision.false.1:
  br label %decision.merge.2, !dbg !1434
decision.merge.2:
  %v2 = phi i32 [21, %decision.true.0], [64, %decision.false.1], !dbg !1435
  ret i32 %v2, !dbg !1436
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d95.108(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1439 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1440, !DIExpression(), !1441)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.71), !dbg !1442
  %v2 = icmp slt i32 %v1, 0, !dbg !1443
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1444
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d91.105(ptr %arg0), !dbg !1445
  br label %decision.merge.2, !dbg !1446
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d95_2d95.107(ptr %arg0), !dbg !1447
  br label %decision.merge.2, !dbg !1448
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1449
  ret i32 %v5, !dbg !1450
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.109(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1453 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1454, !DIExpression(), !1455)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1456, !DIExpression(), !1457)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1458
  %v3 = icmp eq i32 %v2, 0, !dbg !1459
  %v4 = icmp eq i1 %v3, true, !dbg !1460
  ret i1 %v4, !dbg !1461
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d97_2d97.110(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1464 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1465, !DIExpression(), !1466)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.109(ptr %arg0, ptr @.topal.int.72), !dbg !1467
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1468
decision.true.0:
  br label %decision.merge.2, !dbg !1469
decision.false.1:
  br label %decision.merge.2, !dbg !1470
decision.merge.2:
  %v2 = phi i32 [51, %decision.true.0], [64, %decision.false.1], !dbg !1471
  ret i32 %v2, !dbg !1472
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.111(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1475 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1476, !DIExpression(), !1477)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1478, !DIExpression(), !1479)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1480
  %v3 = icmp eq i32 %v2, 0, !dbg !1481
  %v4 = icmp eq i1 %v3, true, !dbg !1482
  ret i1 %v4, !dbg !1483
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d102_2d102.112(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1486 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1487, !DIExpression(), !1488)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.111(ptr %arg0, ptr @.topal.int.73), !dbg !1489
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1490
decision.true.0:
  br label %decision.merge.2, !dbg !1491
decision.false.1:
  br label %decision.merge.2, !dbg !1492
decision.merge.2:
  %v2 = phi i32 [65, %decision.true.0], [64, %decision.false.1], !dbg !1493
  ret i32 %v2, !dbg !1494
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d97_2d102.113(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1497 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1498, !DIExpression(), !1499)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.74), !dbg !1500
  %v2 = icmp slt i32 %v1, 0, !dbg !1501
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1502
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d97_2d97.110(ptr %arg0), !dbg !1503
  br label %decision.merge.2, !dbg !1504
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d102_2d102.112(ptr %arg0), !dbg !1505
  br label %decision.merge.2, !dbg !1506
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1507
  ret i32 %v5, !dbg !1508
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d102.114(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1511 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1512, !DIExpression(), !1513)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.75), !dbg !1514
  %v2 = icmp slt i32 %v1, 0, !dbg !1515
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1516
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d95.108(ptr %arg0), !dbg !1517
  br label %decision.merge.2, !dbg !1518
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d97_2d102.113(ptr %arg0), !dbg !1519
  br label %decision.merge.2, !dbg !1520
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1521
  ret i32 %v5, !dbg !1522
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.115(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1525 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1526, !DIExpression(), !1527)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1528, !DIExpression(), !1529)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1530
  %v3 = icmp eq i32 %v2, 0, !dbg !1531
  %v4 = icmp eq i1 %v3, true, !dbg !1532
  ret i1 %v4, !dbg !1533
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d104_2d104.116(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1536 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1537, !DIExpression(), !1538)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.115(ptr %arg0, ptr @.topal.int.76), !dbg !1539
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1540
decision.true.0:
  br label %decision.merge.2, !dbg !1541
decision.false.1:
  br label %decision.merge.2, !dbg !1542
decision.merge.2:
  %v2 = phi i32 [25, %decision.true.0], [64, %decision.false.1], !dbg !1543
  ret i32 %v2, !dbg !1544
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.117(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1547 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1548, !DIExpression(), !1549)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1550, !DIExpression(), !1551)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1552
  %v3 = icmp eq i32 %v2, 0, !dbg !1553
  %v4 = icmp eq i1 %v3, true, !dbg !1554
  ret i1 %v4, !dbg !1555
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d105_2d105.118(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1558 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1559, !DIExpression(), !1560)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.117(ptr %arg0, ptr @.topal.int.77), !dbg !1561
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1562
decision.true.0:
  br label %decision.merge.2, !dbg !1563
decision.false.1:
  br label %decision.merge.2, !dbg !1564
decision.merge.2:
  %v2 = phi i32 [56, %decision.true.0], [64, %decision.false.1], !dbg !1565
  ret i32 %v2, !dbg !1566
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d104_2d105.119(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1569 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1570, !DIExpression(), !1571)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.78), !dbg !1572
  %v2 = icmp slt i32 %v1, 0, !dbg !1573
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1574
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d104_2d104.116(ptr %arg0), !dbg !1575
  br label %decision.merge.2, !dbg !1576
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d105_2d105.118(ptr %arg0), !dbg !1577
  br label %decision.merge.2, !dbg !1578
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1579
  ret i32 %v5, !dbg !1580
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.120(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1583 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1584, !DIExpression(), !1585)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1586, !DIExpression(), !1587)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1588
  %v3 = icmp eq i32 %v2, 0, !dbg !1589
  %v4 = icmp eq i1 %v3, true, !dbg !1590
  ret i1 %v4, !dbg !1591
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d106_2d106.121(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1594 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1595, !DIExpression(), !1596)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.120(ptr %arg0, ptr @.topal.int.79), !dbg !1597
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1598
decision.true.0:
  br label %decision.merge.2, !dbg !1599
decision.false.1:
  br label %decision.merge.2, !dbg !1600
decision.merge.2:
  %v2 = phi i32 [55, %decision.true.0], [64, %decision.false.1], !dbg !1601
  ret i32 %v2, !dbg !1602
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.122(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1605 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1606, !DIExpression(), !1607)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1608, !DIExpression(), !1609)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1610
  %v3 = icmp eq i32 %v2, 0, !dbg !1611
  %v4 = icmp eq i1 %v3, true, !dbg !1612
  ret i1 %v4, !dbg !1613
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d107_2d107.123(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1616 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1617, !DIExpression(), !1618)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.122(ptr %arg0, ptr @.topal.int.80), !dbg !1619
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1620
decision.true.0:
  br label %decision.merge.2, !dbg !1621
decision.false.1:
  br label %decision.merge.2, !dbg !1622
decision.merge.2:
  %v2 = phi i32 [16, %decision.true.0], [64, %decision.false.1], !dbg !1623
  ret i32 %v2, !dbg !1624
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d106_2d107.124(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1627 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1628, !DIExpression(), !1629)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.81), !dbg !1630
  %v2 = icmp slt i32 %v1, 0, !dbg !1631
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1632
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d106_2d106.121(ptr %arg0), !dbg !1633
  br label %decision.merge.2, !dbg !1634
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d107_2d107.123(ptr %arg0), !dbg !1635
  br label %decision.merge.2, !dbg !1636
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1637
  ret i32 %v5, !dbg !1638
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d104_2d107.125(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1641 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1642, !DIExpression(), !1643)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.82), !dbg !1644
  %v2 = icmp slt i32 %v1, 0, !dbg !1645
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1646
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d104_2d105.119(ptr %arg0), !dbg !1647
  br label %decision.merge.2, !dbg !1648
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d106_2d107.124(ptr %arg0), !dbg !1649
  br label %decision.merge.2, !dbg !1650
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1651
  ret i32 %v5, !dbg !1652
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d107.126(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1655 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1656, !DIExpression(), !1657)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.83), !dbg !1658
  %v2 = icmp slt i32 %v1, 0, !dbg !1659
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1660
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d102.114(ptr %arg0), !dbg !1661
  br label %decision.merge.2, !dbg !1662
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d104_2d107.125(ptr %arg0), !dbg !1663
  br label %decision.merge.2, !dbg !1664
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1665
  ret i32 %v5, !dbg !1666
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.127(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1669 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1670, !DIExpression(), !1671)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1672, !DIExpression(), !1673)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1674
  %v3 = icmp eq i32 %v2, 0, !dbg !1675
  %v4 = icmp eq i1 %v3, true, !dbg !1676
  ret i1 %v4, !dbg !1677
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d108.128(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1680 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1681, !DIExpression(), !1682)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.127(ptr %arg0, ptr @.topal.int.84), !dbg !1683
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1684
decision.true.0:
  br label %decision.merge.2, !dbg !1685
decision.false.1:
  br label %decision.merge.2, !dbg !1686
decision.merge.2:
  %v2 = phi i32 [15, %decision.true.0], [64, %decision.false.1], !dbg !1687
  ret i32 %v2, !dbg !1688
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.129(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1691 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1692, !DIExpression(), !1693)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1694, !DIExpression(), !1695)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1696
  %v3 = icmp eq i32 %v2, 0, !dbg !1697
  %v4 = icmp eq i1 %v3, true, !dbg !1698
  ret i1 %v4, !dbg !1699
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d110_2d110.130(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1702 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1703, !DIExpression(), !1704)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.129(ptr %arg0, ptr @.topal.int.85), !dbg !1705
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1706
decision.true.0:
  br label %decision.merge.2, !dbg !1707
decision.false.1:
  br label %decision.merge.2, !dbg !1708
decision.merge.2:
  %v2 = phi i32 [33, %decision.true.0], [64, %decision.false.1], !dbg !1709
  ret i32 %v2, !dbg !1710
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d110.131(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1713 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1714, !DIExpression(), !1715)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.86), !dbg !1716
  %v2 = icmp slt i32 %v1, 0, !dbg !1717
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1718
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d108.128(ptr %arg0), !dbg !1719
  br label %decision.merge.2, !dbg !1720
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d110_2d110.130(ptr %arg0), !dbg !1721
  br label %decision.merge.2, !dbg !1722
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1723
  ret i32 %v5, !dbg !1724
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.132(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1727 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1728, !DIExpression(), !1729)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1730, !DIExpression(), !1731)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1732
  %v3 = icmp eq i32 %v2, 0, !dbg !1733
  %v4 = icmp eq i1 %v3, true, !dbg !1734
  ret i1 %v4, !dbg !1735
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d157_2d157.133(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1738 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1739, !DIExpression(), !1740)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.132(ptr %arg0, ptr @.topal.int.87), !dbg !1741
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1742
decision.true.0:
  br label %decision.merge.2, !dbg !1743
decision.false.1:
  br label %decision.merge.2, !dbg !1744
decision.merge.2:
  %v2 = phi i32 [37, %decision.true.0], [64, %decision.false.1], !dbg !1745
  ret i32 %v2, !dbg !1746
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.134(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1749 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1750, !DIExpression(), !1751)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1752, !DIExpression(), !1753)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1754
  %v3 = icmp eq i32 %v2, 0, !dbg !1755
  %v4 = icmp eq i1 %v3, true, !dbg !1756
  ret i1 %v4, !dbg !1757
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d158_2d158.135(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1760 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1761, !DIExpression(), !1762)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.134(ptr %arg0, ptr @.topal.int.88), !dbg !1763
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1764
decision.true.0:
  br label %decision.merge.2, !dbg !1765
decision.false.1:
  br label %decision.merge.2, !dbg !1766
decision.merge.2:
  %v2 = phi i32 [60, %decision.true.0], [64, %decision.false.1], !dbg !1767
  ret i32 %v2, !dbg !1768
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d157_2d158.136(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1771 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1772, !DIExpression(), !1773)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.89), !dbg !1774
  %v2 = icmp slt i32 %v1, 0, !dbg !1775
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1776
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d157_2d157.133(ptr %arg0), !dbg !1777
  br label %decision.merge.2, !dbg !1778
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d158_2d158.135(ptr %arg0), !dbg !1779
  br label %decision.merge.2, !dbg !1780
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1781
  ret i32 %v5, !dbg !1782
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d158.137(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1785 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1786, !DIExpression(), !1787)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.90), !dbg !1788
  %v2 = icmp slt i32 %v1, 0, !dbg !1789
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1790
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d110.131(ptr %arg0), !dbg !1791
  br label %decision.merge.2, !dbg !1792
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d157_2d158.136(ptr %arg0), !dbg !1793
  br label %decision.merge.2, !dbg !1794
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1795
  ret i32 %v5, !dbg !1796
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.138(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1799 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1800, !DIExpression(), !1801)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1802, !DIExpression(), !1803)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1804
  %v3 = icmp eq i32 %v2, 0, !dbg !1805
  %v4 = icmp eq i1 %v3, true, !dbg !1806
  ret i1 %v4, !dbg !1807
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d186_2d186.139(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1810 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1811, !DIExpression(), !1812)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.138(ptr %arg0, ptr @.topal.int.91), !dbg !1813
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1814
decision.true.0:
  br label %decision.merge.2, !dbg !1815
decision.false.1:
  br label %decision.merge.2, !dbg !1816
decision.merge.2:
  %v2 = phi i32 [59, %decision.true.0], [64, %decision.false.1], !dbg !1817
  ret i32 %v2, !dbg !1818
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.140(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1821 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1822, !DIExpression(), !1823)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1824, !DIExpression(), !1825)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1826
  %v3 = icmp eq i32 %v2, 0, !dbg !1827
  %v4 = icmp eq i1 %v3, true, !dbg !1828
  ret i1 %v4, !dbg !1829
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d201_2d201.141(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1832 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1833, !DIExpression(), !1834)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.140(ptr %arg0, ptr @.topal.int.92), !dbg !1835
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1836
decision.true.0:
  br label %decision.merge.2, !dbg !1837
decision.false.1:
  br label %decision.merge.2, !dbg !1838
decision.merge.2:
  %v2 = phi i32 [45, %decision.true.0], [64, %decision.false.1], !dbg !1839
  ret i32 %v2, !dbg !1840
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d186_2d201.142(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1843 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1844, !DIExpression(), !1845)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.93), !dbg !1846
  %v2 = icmp slt i32 %v1, 0, !dbg !1847
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1848
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d186_2d186.139(ptr %arg0), !dbg !1849
  br label %decision.merge.2, !dbg !1850
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d201_2d201.141(ptr %arg0), !dbg !1851
  br label %decision.merge.2, !dbg !1852
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1853
  ret i32 %v5, !dbg !1854
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.143(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1857 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1858, !DIExpression(), !1859)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1860, !DIExpression(), !1861)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1862
  %v3 = icmp eq i32 %v2, 0, !dbg !1863
  %v4 = icmp eq i1 %v3, true, !dbg !1864
  ret i1 %v4, !dbg !1865
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d217_2d217.144(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1868 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1869, !DIExpression(), !1870)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.143(ptr %arg0, ptr @.topal.int.94), !dbg !1871
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1872
decision.true.0:
  br label %decision.merge.2, !dbg !1873
decision.false.1:
  br label %decision.merge.2, !dbg !1874
decision.merge.2:
  %v2 = phi i32 [11, %decision.true.0], [64, %decision.false.1], !dbg !1875
  ret i32 %v2, !dbg !1876
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.145(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1879 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1880, !DIExpression(), !1881)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1882, !DIExpression(), !1883)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1884
  %v3 = icmp eq i32 %v2, 0, !dbg !1885
  %v4 = icmp eq i1 %v3, true, !dbg !1886
  ret i1 %v4, !dbg !1887
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d218_2d218.146(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1890 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1891, !DIExpression(), !1892)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.145(ptr %arg0, ptr @.topal.int.95), !dbg !1893
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1894
decision.true.0:
  br label %decision.merge.2, !dbg !1895
decision.false.1:
  br label %decision.merge.2, !dbg !1896
decision.merge.2:
  %v2 = phi i32 [47, %decision.true.0], [64, %decision.false.1], !dbg !1897
  ret i32 %v2, !dbg !1898
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.147(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1901 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1902, !DIExpression(), !1903)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1904, !DIExpression(), !1905)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1906
  %v3 = icmp eq i32 %v2, 0, !dbg !1907
  %v4 = icmp eq i1 %v3, true, !dbg !1908
  ret i1 %v4, !dbg !1909
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d228_2d228.148(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1912 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1913, !DIExpression(), !1914)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.147(ptr %arg0, ptr @.topal.int.96), !dbg !1915
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !1916
decision.true.0:
  br label %decision.merge.2, !dbg !1917
decision.false.1:
  br label %decision.merge.2, !dbg !1918
decision.merge.2:
  %v2 = phi i32 [8, %decision.true.0], [64, %decision.false.1], !dbg !1919
  ret i32 %v2, !dbg !1920
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d218_2d228.149(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1923 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1924, !DIExpression(), !1925)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.97), !dbg !1926
  %v2 = icmp slt i32 %v1, 0, !dbg !1927
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1928
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d218_2d218.146(ptr %arg0), !dbg !1929
  br label %decision.merge.2, !dbg !1930
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d228_2d228.148(ptr %arg0), !dbg !1931
  br label %decision.merge.2, !dbg !1932
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1933
  ret i32 %v5, !dbg !1934
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d217_2d228.150(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1937 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1938, !DIExpression(), !1939)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.98), !dbg !1940
  %v2 = icmp slt i32 %v1, 0, !dbg !1941
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1942
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d217_2d217.144(ptr %arg0), !dbg !1943
  br label %decision.merge.2, !dbg !1944
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d218_2d228.149(ptr %arg0), !dbg !1945
  br label %decision.merge.2, !dbg !1946
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1947
  ret i32 %v5, !dbg !1948
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d186_2d228.151(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1951 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1952, !DIExpression(), !1953)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.99), !dbg !1954
  %v2 = icmp slt i32 %v1, 0, !dbg !1955
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1956
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d186_2d201.142(ptr %arg0), !dbg !1957
  br label %decision.merge.2, !dbg !1958
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d217_2d228.150(ptr %arg0), !dbg !1959
  br label %decision.merge.2, !dbg !1960
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1961
  ret i32 %v5, !dbg !1962
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d228.152(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1965 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1966, !DIExpression(), !1967)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.100), !dbg !1968
  %v2 = icmp slt i32 %v1, 0, !dbg !1969
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1970
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d158.137(ptr %arg0), !dbg !1971
  br label %decision.merge.2, !dbg !1972
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d186_2d228.151(ptr %arg0), !dbg !1973
  br label %decision.merge.2, !dbg !1974
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1975
  ret i32 %v5, !dbg !1976
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d228.153(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1979 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1980, !DIExpression(), !1981)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.101), !dbg !1982
  %v2 = icmp slt i32 %v1, 0, !dbg !1983
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1984
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d107.126(ptr %arg0), !dbg !1985
  br label %decision.merge.2, !dbg !1986
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d108_2d228.152(ptr %arg0), !dbg !1987
  br label %decision.merge.2, !dbg !1988
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !1989
  ret i32 %v5, !dbg !1990
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.154(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1993 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1994, !DIExpression(), !1995)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1996, !DIExpression(), !1997)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !1998
  %v3 = icmp eq i32 %v2, 0, !dbg !1999
  %v4 = icmp eq i1 %v3, true, !dbg !2000
  ret i1 %v4, !dbg !2001
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d229.155(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2004 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2005, !DIExpression(), !2006)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.154(ptr %arg0, ptr @.topal.int.102), !dbg !2007
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2008
decision.true.0:
  br label %decision.merge.2, !dbg !2009
decision.false.1:
  br label %decision.merge.2, !dbg !2010
decision.merge.2:
  %v2 = phi i32 [6, %decision.true.0], [64, %decision.false.1], !dbg !2011
  ret i32 %v2, !dbg !2012
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.156(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2015 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2016, !DIExpression(), !2017)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2018, !DIExpression(), !2019)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2020
  %v3 = icmp eq i32 %v2, 0, !dbg !2021
  %v4 = icmp eq i1 %v3, true, !dbg !2022
  ret i1 %v4, !dbg !2023
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d230_2d230.157(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2026 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2027, !DIExpression(), !2028)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.156(ptr %arg0, ptr @.topal.int.103), !dbg !2029
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2030
decision.true.0:
  br label %decision.merge.2, !dbg !2031
decision.false.1:
  br label %decision.merge.2, !dbg !2032
decision.merge.2:
  %v2 = phi i32 [7, %decision.true.0], [64, %decision.false.1], !dbg !2033
  ret i32 %v2, !dbg !2034
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d230.158(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2037 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2038, !DIExpression(), !2039)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.104), !dbg !2040
  %v2 = icmp slt i32 %v1, 0, !dbg !2041
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2042
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d229.155(ptr %arg0), !dbg !2043
  br label %decision.merge.2, !dbg !2044
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d230_2d230.157(ptr %arg0), !dbg !2045
  br label %decision.merge.2, !dbg !2046
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2047
  ret i32 %v5, !dbg !2048
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.159(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2051 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2052, !DIExpression(), !2053)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2054, !DIExpression(), !2055)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2056
  %v3 = icmp eq i32 %v2, 0, !dbg !2057
  %v4 = icmp eq i1 %v3, true, !dbg !2058
  ret i1 %v4, !dbg !2059
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d231_2d231.160(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2062 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2063, !DIExpression(), !2064)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.159(ptr %arg0, ptr @.topal.int.105), !dbg !2065
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2066
decision.true.0:
  br label %decision.merge.2, !dbg !2067
decision.false.1:
  br label %decision.merge.2, !dbg !2068
decision.merge.2:
  %v2 = phi i32 [19, %decision.true.0], [64, %decision.false.1], !dbg !2069
  ret i32 %v2, !dbg !2070
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.161(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2073 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2074, !DIExpression(), !2075)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2076, !DIExpression(), !2077)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2078
  %v3 = icmp eq i32 %v2, 0, !dbg !2079
  %v4 = icmp eq i1 %v3, true, !dbg !2080
  ret i1 %v4, !dbg !2081
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d257_2d257.162(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2084 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2085, !DIExpression(), !2086)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.161(ptr %arg0, ptr @.topal.int.106), !dbg !2087
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2088
decision.true.0:
  br label %decision.merge.2, !dbg !2089
decision.false.1:
  br label %decision.merge.2, !dbg !2090
decision.merge.2:
  %v2 = phi i32 [32, %decision.true.0], [64, %decision.false.1], !dbg !2091
  ret i32 %v2, !dbg !2092
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d231_2d257.163(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2095 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2096, !DIExpression(), !2097)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.107), !dbg !2098
  %v2 = icmp slt i32 %v1, 0, !dbg !2099
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2100
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d231_2d231.160(ptr %arg0), !dbg !2101
  br label %decision.merge.2, !dbg !2102
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d257_2d257.162(ptr %arg0), !dbg !2103
  br label %decision.merge.2, !dbg !2104
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2105
  ret i32 %v5, !dbg !2106
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d257.164(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2109 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2110, !DIExpression(), !2111)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.108), !dbg !2112
  %v2 = icmp slt i32 %v1, 0, !dbg !2113
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2114
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d230.158(ptr %arg0), !dbg !2115
  br label %decision.merge.2, !dbg !2116
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d231_2d257.163(ptr %arg0), !dbg !2117
  br label %decision.merge.2, !dbg !2118
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2119
  ret i32 %v5, !dbg !2120
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.165(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2123 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2124, !DIExpression(), !2125)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2126, !DIExpression(), !2127)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2128
  %v3 = icmp eq i32 %v2, 0, !dbg !2129
  %v4 = icmp eq i1 %v3, true, !dbg !2130
  ret i1 %v4, !dbg !2131
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d262_2d262.166(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2134 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2135, !DIExpression(), !2136)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.165(ptr %arg0, ptr @.topal.int.109), !dbg !2137
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2138
decision.true.0:
  br label %decision.merge.2, !dbg !2139
decision.false.1:
  br label %decision.merge.2, !dbg !2140
decision.merge.2:
  %v2 = phi i32 [23, %decision.true.0], [64, %decision.false.1], !dbg !2141
  ret i32 %v2, !dbg !2142
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.167(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2145 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2146, !DIExpression(), !2147)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2148, !DIExpression(), !2149)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2150
  %v3 = icmp eq i32 %v2, 0, !dbg !2151
  %v4 = icmp eq i1 %v3, true, !dbg !2152
  ret i1 %v4, !dbg !2153
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d263_2d263.168(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2156 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2157, !DIExpression(), !2158)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.167(ptr %arg0, ptr @.topal.int.110), !dbg !2159
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2160
decision.true.0:
  br label %decision.merge.2, !dbg !2161
decision.false.1:
  br label %decision.merge.2, !dbg !2162
decision.merge.2:
  %v2 = phi i32 [63, %decision.true.0], [64, %decision.false.1], !dbg !2163
  ret i32 %v2, !dbg !2164
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d262_2d263.169(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2167 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2168, !DIExpression(), !2169)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.111), !dbg !2170
  %v2 = icmp slt i32 %v1, 0, !dbg !2171
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2172
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d262_2d262.166(ptr %arg0), !dbg !2173
  br label %decision.merge.2, !dbg !2174
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d263_2d263.168(ptr %arg0), !dbg !2175
  br label %decision.merge.2, !dbg !2176
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2177
  ret i32 %v5, !dbg !2178
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.170(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2181 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2182, !DIExpression(), !2183)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2184, !DIExpression(), !2185)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2186
  %v3 = icmp eq i32 %v2, 0, !dbg !2187
  %v4 = icmp eq i1 %v3, true, !dbg !2188
  ret i1 %v4, !dbg !2189
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d264_2d264.171(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2192 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2193, !DIExpression(), !2194)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.170(ptr %arg0, ptr @.topal.int.112), !dbg !2195
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2196
decision.true.0:
  br label %decision.merge.2, !dbg !2197
decision.false.1:
  br label %decision.merge.2, !dbg !2198
decision.merge.2:
  %v2 = phi i32 [49, %decision.true.0], [64, %decision.false.1], !dbg !2199
  ret i32 %v2, !dbg !2200
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.172(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2203 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2204, !DIExpression(), !2205)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2206, !DIExpression(), !2207)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2208
  %v3 = icmp eq i32 %v2, 0, !dbg !2209
  %v4 = icmp eq i1 %v3, true, !dbg !2210
  ret i1 %v4, !dbg !2211
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d265_2d265.173(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2214 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2215, !DIExpression(), !2216)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.172(ptr %arg0, ptr @.topal.int.113), !dbg !2217
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2218
decision.true.0:
  br label %decision.merge.2, !dbg !2219
decision.false.1:
  br label %decision.merge.2, !dbg !2220
decision.merge.2:
  %v2 = phi i32 [29, %decision.true.0], [64, %decision.false.1], !dbg !2221
  ret i32 %v2, !dbg !2222
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.174(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2225 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2226, !DIExpression(), !2227)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2228, !DIExpression(), !2229)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2230
  %v3 = icmp eq i32 %v2, 0, !dbg !2231
  %v4 = icmp eq i1 %v3, true, !dbg !2232
  ret i1 %v4, !dbg !2233
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d267_2d267.175(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2236 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2237, !DIExpression(), !2238)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.174(ptr %arg0, ptr @.topal.int.114), !dbg !2239
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2240
decision.true.0:
  br label %decision.merge.2, !dbg !2241
decision.false.1:
  br label %decision.merge.2, !dbg !2242
decision.merge.2:
  %v2 = phi i32 [44, %decision.true.0], [64, %decision.false.1], !dbg !2243
  ret i32 %v2, !dbg !2244
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d265_2d267.176(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2247 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2248, !DIExpression(), !2249)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.115), !dbg !2250
  %v2 = icmp slt i32 %v1, 0, !dbg !2251
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2252
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d265_2d265.173(ptr %arg0), !dbg !2253
  br label %decision.merge.2, !dbg !2254
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d267_2d267.175(ptr %arg0), !dbg !2255
  br label %decision.merge.2, !dbg !2256
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2257
  ret i32 %v5, !dbg !2258
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d264_2d267.177(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2261 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2262, !DIExpression(), !2263)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.116), !dbg !2264
  %v2 = icmp slt i32 %v1, 0, !dbg !2265
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2266
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d264_2d264.171(ptr %arg0), !dbg !2267
  br label %decision.merge.2, !dbg !2268
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d265_2d267.176(ptr %arg0), !dbg !2269
  br label %decision.merge.2, !dbg !2270
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2271
  ret i32 %v5, !dbg !2272
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d262_2d267.178(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2275 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2276, !DIExpression(), !2277)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.117), !dbg !2278
  %v2 = icmp slt i32 %v1, 0, !dbg !2279
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2280
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d262_2d263.169(ptr %arg0), !dbg !2281
  br label %decision.merge.2, !dbg !2282
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d264_2d267.177(ptr %arg0), !dbg !2283
  br label %decision.merge.2, !dbg !2284
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2285
  ret i32 %v5, !dbg !2286
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d267.179(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2289 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2290, !DIExpression(), !2291)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.118), !dbg !2292
  %v2 = icmp slt i32 %v1, 0, !dbg !2293
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2294
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d257.164(ptr %arg0), !dbg !2295
  br label %decision.merge.2, !dbg !2296
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d262_2d267.178(ptr %arg0), !dbg !2297
  br label %decision.merge.2, !dbg !2298
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2299
  ret i32 %v5, !dbg !2300
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.180(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2303 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2304, !DIExpression(), !2305)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2306, !DIExpression(), !2307)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2308
  %v3 = icmp eq i32 %v2, 0, !dbg !2309
  %v4 = icmp eq i1 %v3, true, !dbg !2310
  ret i1 %v4, !dbg !2311
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d268.181(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2314 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2315, !DIExpression(), !2316)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.180(ptr %arg0, ptr @.topal.int.119), !dbg !2317
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2318
decision.true.0:
  br label %decision.merge.2, !dbg !2319
decision.false.1:
  br label %decision.merge.2, !dbg !2320
decision.merge.2:
  %v2 = phi i32 [3, %decision.true.0], [64, %decision.false.1], !dbg !2321
  ret i32 %v2, !dbg !2322
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.182(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2325 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2326, !DIExpression(), !2327)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2328, !DIExpression(), !2329)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2330
  %v3 = icmp eq i32 %v2, 0, !dbg !2331
  %v4 = icmp eq i1 %v3, true, !dbg !2332
  ret i1 %v4, !dbg !2333
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d273_2d273.183(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2336 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2337, !DIExpression(), !2338)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.182(ptr %arg0, ptr @.topal.int.120), !dbg !2339
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2340
decision.true.0:
  br label %decision.merge.2, !dbg !2341
decision.false.1:
  br label %decision.merge.2, !dbg !2342
decision.merge.2:
  %v2 = phi i32 [46, %decision.true.0], [64, %decision.false.1], !dbg !2343
  ret i32 %v2, !dbg !2344
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d273.184(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2347 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2348, !DIExpression(), !2349)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.121), !dbg !2350
  %v2 = icmp slt i32 %v1, 0, !dbg !2351
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2352
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d268.181(ptr %arg0), !dbg !2353
  br label %decision.merge.2, !dbg !2354
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d273_2d273.183(ptr %arg0), !dbg !2355
  br label %decision.merge.2, !dbg !2356
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2357
  ret i32 %v5, !dbg !2358
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.185(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2361 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2362, !DIExpression(), !2363)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2364, !DIExpression(), !2365)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2366
  %v3 = icmp eq i32 %v2, 0, !dbg !2367
  %v4 = icmp eq i1 %v3, true, !dbg !2368
  ret i1 %v4, !dbg !2369
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d292_2d292.186(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2372 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2373, !DIExpression(), !2374)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.185(ptr %arg0, ptr @.topal.int.122), !dbg !2375
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2376
decision.true.0:
  br label %decision.merge.2, !dbg !2377
decision.false.1:
  br label %decision.merge.2, !dbg !2378
decision.merge.2:
  %v2 = phi i32 [14, %decision.true.0], [64, %decision.false.1], !dbg !2379
  ret i32 %v2, !dbg !2380
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.187(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2383 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2384, !DIExpression(), !2385)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2386, !DIExpression(), !2387)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2388
  %v3 = icmp eq i32 %v2, 0, !dbg !2389
  %v4 = icmp eq i1 %v3, true, !dbg !2390
  ret i1 %v4, !dbg !2391
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d293_2d293.188(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2394 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2395, !DIExpression(), !2396)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.187(ptr %arg0, ptr @.topal.int.123), !dbg !2397
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2398
decision.true.0:
  br label %decision.merge.2, !dbg !2399
decision.false.1:
  br label %decision.merge.2, !dbg !2400
decision.merge.2:
  %v2 = phi i32 [35, %decision.true.0], [64, %decision.false.1], !dbg !2401
  ret i32 %v2, !dbg !2402
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d292_2d293.189(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2405 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2406, !DIExpression(), !2407)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.124), !dbg !2408
  %v2 = icmp slt i32 %v1, 0, !dbg !2409
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2410
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d292_2d292.186(ptr %arg0), !dbg !2411
  br label %decision.merge.2, !dbg !2412
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d293_2d293.188(ptr %arg0), !dbg !2413
  br label %decision.merge.2, !dbg !2414
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2415
  ret i32 %v5, !dbg !2416
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d293.190(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2419 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2420, !DIExpression(), !2421)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.125), !dbg !2422
  %v2 = icmp slt i32 %v1, 0, !dbg !2423
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2424
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d273.184(ptr %arg0), !dbg !2425
  br label %decision.merge.2, !dbg !2426
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d292_2d293.189(ptr %arg0), !dbg !2427
  br label %decision.merge.2, !dbg !2428
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2429
  ret i32 %v5, !dbg !2430
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.191(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2433 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2434, !DIExpression(), !2435)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2436, !DIExpression(), !2437)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2438
  %v3 = icmp eq i32 %v2, 0, !dbg !2439
  %v4 = icmp eq i1 %v3, true, !dbg !2440
  ret i1 %v4, !dbg !2441
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d302_2d302.192(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2444 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2445, !DIExpression(), !2446)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.191(ptr %arg0, ptr @.topal.int.126), !dbg !2447
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2448
decision.true.0:
  br label %decision.merge.2, !dbg !2449
decision.false.1:
  br label %decision.merge.2, !dbg !2450
decision.merge.2:
  %v2 = phi i32 [52, %decision.true.0], [64, %decision.false.1], !dbg !2451
  ret i32 %v2, !dbg !2452
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.193(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2455 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2456, !DIExpression(), !2457)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2458, !DIExpression(), !2459)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2460
  %v3 = icmp eq i32 %v2, 0, !dbg !2461
  %v4 = icmp eq i1 %v3, true, !dbg !2462
  ret i1 %v4, !dbg !2463
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d316_2d316.194(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2466 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2467, !DIExpression(), !2468)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.193(ptr %arg0, ptr @.topal.int.127), !dbg !2469
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2470
decision.true.0:
  br label %decision.merge.2, !dbg !2471
decision.false.1:
  br label %decision.merge.2, !dbg !2472
decision.merge.2:
  %v2 = phi i32 [50, %decision.true.0], [64, %decision.false.1], !dbg !2473
  ret i32 %v2, !dbg !2474
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d302_2d316.195(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2477 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2478, !DIExpression(), !2479)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.128), !dbg !2480
  %v2 = icmp slt i32 %v1, 0, !dbg !2481
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2482
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d302_2d302.192(ptr %arg0), !dbg !2483
  br label %decision.merge.2, !dbg !2484
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d316_2d316.194(ptr %arg0), !dbg !2485
  br label %decision.merge.2, !dbg !2486
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2487
  ret i32 %v5, !dbg !2488
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.196(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2491 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2492, !DIExpression(), !2493)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2494, !DIExpression(), !2495)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2496
  %v3 = icmp eq i32 %v2, 0, !dbg !2497
  %v4 = icmp eq i1 %v3, true, !dbg !2498
  ret i1 %v4, !dbg !2499
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d318_2d318.197(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2502 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2503, !DIExpression(), !2504)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.196(ptr %arg0, ptr @.topal.int.129), !dbg !2505
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2506
decision.true.0:
  br label %decision.merge.2, !dbg !2507
decision.false.1:
  br label %decision.merge.2, !dbg !2508
decision.merge.2:
  %v2 = phi i32 [41, %decision.true.0], [64, %decision.false.1], !dbg !2509
  ret i32 %v2, !dbg !2510
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.198(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2513 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2514, !DIExpression(), !2515)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2516, !DIExpression(), !2517)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2518
  %v3 = icmp eq i32 %v2, 0, !dbg !2519
  %v4 = icmp eq i1 %v3, true, !dbg !2520
  ret i1 %v4, !dbg !2521
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d334_2d334.199(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2524 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2525, !DIExpression(), !2526)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.198(ptr %arg0, ptr @.topal.int.130), !dbg !2527
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2528
decision.true.0:
  br label %decision.merge.2, !dbg !2529
decision.false.1:
  br label %decision.merge.2, !dbg !2530
decision.merge.2:
  %v2 = phi i32 [53, %decision.true.0], [64, %decision.false.1], !dbg !2531
  ret i32 %v2, !dbg !2532
}

define internal fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.200(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2535 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2536, !DIExpression(), !2537)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2538, !DIExpression(), !2539)
  %v2 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr %arg1), !dbg !2540
  %v3 = icmp eq i32 %v2, 0, !dbg !2541
  %v4 = icmp eq i1 %v3, true, !dbg !2542
  ret i1 %v4, !dbg !2543
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d452_2d452.201(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2546 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2547, !DIExpression(), !2548)
  %v1 = call fastcc i1 @topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.200(ptr %arg0, ptr @.topal.int.131), !dbg !2549
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !2550
decision.true.0:
  br label %decision.merge.2, !dbg !2551
decision.false.1:
  br label %decision.merge.2, !dbg !2552
decision.merge.2:
  %v2 = phi i32 [4, %decision.true.0], [64, %decision.false.1], !dbg !2553
  ret i32 %v2, !dbg !2554
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d334_2d452.202(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2557 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2558, !DIExpression(), !2559)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.132), !dbg !2560
  %v2 = icmp slt i32 %v1, 0, !dbg !2561
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2562
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d334_2d334.199(ptr %arg0), !dbg !2563
  br label %decision.merge.2, !dbg !2564
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d452_2d452.201(ptr %arg0), !dbg !2565
  br label %decision.merge.2, !dbg !2566
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2567
  ret i32 %v5, !dbg !2568
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d318_2d452.203(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2571 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2572, !DIExpression(), !2573)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.133), !dbg !2574
  %v2 = icmp slt i32 %v1, 0, !dbg !2575
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2576
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d318_2d318.197(ptr %arg0), !dbg !2577
  br label %decision.merge.2, !dbg !2578
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d334_2d452.202(ptr %arg0), !dbg !2579
  br label %decision.merge.2, !dbg !2580
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2581
  ret i32 %v5, !dbg !2582
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d302_2d452.204(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2585 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2586, !DIExpression(), !2587)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.134), !dbg !2588
  %v2 = icmp slt i32 %v1, 0, !dbg !2589
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2590
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d302_2d316.195(ptr %arg0), !dbg !2591
  br label %decision.merge.2, !dbg !2592
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d318_2d452.203(ptr %arg0), !dbg !2593
  br label %decision.merge.2, !dbg !2594
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2595
  ret i32 %v5, !dbg !2596
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d452.205(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2599 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2600, !DIExpression(), !2601)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.135), !dbg !2602
  %v2 = icmp slt i32 %v1, 0, !dbg !2603
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2604
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d293.190(ptr %arg0), !dbg !2605
  br label %decision.merge.2, !dbg !2606
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d302_2d452.204(ptr %arg0), !dbg !2607
  br label %decision.merge.2, !dbg !2608
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2609
  ret i32 %v5, !dbg !2610
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d452.206(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2613 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2614, !DIExpression(), !2615)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.136), !dbg !2616
  %v2 = icmp slt i32 %v1, 0, !dbg !2617
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2618
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d267.179(ptr %arg0), !dbg !2619
  br label %decision.merge.2, !dbg !2620
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d268_2d452.205(ptr %arg0), !dbg !2621
  br label %decision.merge.2, !dbg !2622
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2623
  ret i32 %v5, !dbg !2624
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d452.207(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2627 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2628, !DIExpression(), !2629)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.137), !dbg !2630
  %v2 = icmp slt i32 %v1, 0, !dbg !2631
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2632
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d228.153(ptr %arg0), !dbg !2633
  br label %decision.merge.2, !dbg !2634
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d229_2d452.206(ptr %arg0), !dbg !2635
  br label %decision.merge.2, !dbg !2636
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2637
  ret i32 %v5, !dbg !2638
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d452.208(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2641 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2642, !DIExpression(), !2643)
  %v1 = call i32 @topal.syscall.runtime.int.compare(ptr %arg0, ptr @.topal.int.138), !dbg !2644
  %v2 = icmp slt i32 %v1, 0, !dbg !2645
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !2646
decision.true.0:
  %v3 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d90.103(ptr %arg0), !dbg !2647
  br label %decision.merge.2, !dbg !2648
decision.false.1:
  %v4 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d91_2d452.207(ptr %arg0), !dbg !2649
  br label %decision.merge.2, !dbg !2650
decision.merge.2:
  %v5 = phi i32 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !2651
  ret i32 %v5, !dbg !2652
}

define internal fastcc i32 @topal.dispatch.topal.fn.select_2doperation.209(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2655 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2656, !DIExpression(), !2657)
  %v1 = call fastcc i32 @topal.dispatch.topal.fn.select_2drange_2d0_2d452.208(ptr %arg0), !dbg !2658
  ret i32 %v1, !dbg !2659
}

define i64 @topal_kernel_static_linux_dispatch_policy_v6(i64 %selector) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.syscall.runtime.int.from.u64(i64 %selector)
  %selection = call fastcc i32 @topal.dispatch.topal.fn.select_2doperation.209(ptr %value)
  switch i32 %selection, label %invalid [
    i32 42, label %operation.0
    i32 68, label %operation.1
    i32 31, label %operation.2
    i32 10, label %operation.3
    i32 22, label %operation.4
    i32 36, label %operation.5
    i32 54, label %operation.6
    i32 40, label %operation.7
    i32 39, label %operation.8
    i32 57, label %operation.9
    i32 58, label %operation.10
    i32 26, label %operation.11
    i32 43, label %operation.12
    i32 69, label %operation.13
    i32 34, label %operation.14
    i32 70, label %operation.15
    i32 12, label %operation.16
    i32 13, label %operation.17
    i32 30, label %operation.18
    i32 38, label %operation.19
    i32 9, label %operation.20
    i32 24, label %operation.21
    i32 17, label %operation.22
    i32 18, label %operation.23
    i32 66, label %operation.24
    i32 27, label %operation.25
    i32 20, label %operation.26
    i32 61, label %operation.27
    i32 67, label %operation.28
    i32 0, label %operation.29
    i32 1, label %operation.30
    i32 48, label %operation.31
    i32 28, label %operation.32
    i32 62, label %operation.33
    i32 2, label %operation.34
    i32 5, label %operation.35
    i32 21, label %operation.36
    i32 51, label %operation.37
    i32 65, label %operation.38
    i32 25, label %operation.39
    i32 56, label %operation.40
    i32 55, label %operation.41
    i32 16, label %operation.42
    i32 15, label %operation.43
    i32 33, label %operation.44
    i32 37, label %operation.45
    i32 60, label %operation.46
    i32 59, label %operation.47
    i32 45, label %operation.48
    i32 11, label %operation.49
    i32 47, label %operation.50
    i32 8, label %operation.51
    i32 6, label %operation.52
    i32 7, label %operation.53
    i32 19, label %operation.54
    i32 32, label %operation.55
    i32 23, label %operation.56
    i32 63, label %operation.57
    i32 49, label %operation.58
    i32 29, label %operation.59
    i32 44, label %operation.60
    i32 3, label %operation.61
    i32 46, label %operation.62
    i32 14, label %operation.63
    i32 35, label %operation.64
    i32 52, label %operation.65
    i32 50, label %operation.66
    i32 41, label %operation.67
    i32 53, label %operation.68
    i32 4, label %operation.69
    i32 64, label %operation.70
  ]
operation.0:
  ret i64 0
operation.1:
  ret i64 1
operation.2:
  ret i64 2
operation.3:
  ret i64 3
operation.4:
  ret i64 5
operation.5:
  ret i64 7
operation.6:
  ret i64 8
operation.7:
  ret i64 10
operation.8:
  ret i64 12
operation.9:
  ret i64 13
operation.10:
  ret i64 14
operation.11:
  ret i64 16
operation.12:
  ret i64 17
operation.13:
  ret i64 18
operation.14:
  ret i64 22
operation.15:
  ret i64 24
operation.16:
  ret i64 32
operation.17:
  ret i64 33
operation.18:
  ret i64 35
operation.19:
  ret i64 39
operation.20:
  ret i64 56
operation.21:
  ret i64 57
operation.22:
  ret i64 59
operation.23:
  ret i64 60
operation.24:
  ret i64 61
operation.25:
  ret i64 63
operation.26:
  ret i64 72
operation.27:
  ret i64 77
operation.28:
  ret i64 79
operation.29:
  ret i64 80
operation.30:
  ret i64 81
operation.31:
  ret i64 82
operation.32:
  ret i64 86
operation.33:
  ret i64 87
operation.34:
  ret i64 90
operation.35:
  ret i64 91
operation.36:
  ret i64 95
operation.37:
  ret i64 97
operation.38:
  ret i64 102
operation.39:
  ret i64 104
operation.40:
  ret i64 105
operation.41:
  ret i64 106
operation.42:
  ret i64 107
operation.43:
  ret i64 108
operation.44:
  ret i64 110
operation.45:
  ret i64 157
operation.46:
  ret i64 158
operation.47:
  ret i64 186
operation.48:
  ret i64 201
operation.49:
  ret i64 217
operation.50:
  ret i64 218
operation.51:
  ret i64 228
operation.52:
  ret i64 229
operation.53:
  ret i64 230
operation.54:
  ret i64 231
operation.55:
  ret i64 257
operation.56:
  ret i64 262
operation.57:
  ret i64 263
operation.58:
  ret i64 264
operation.59:
  ret i64 265
operation.60:
  ret i64 267
operation.61:
  ret i64 268
operation.62:
  ret i64 273
operation.63:
  ret i64 292
operation.64:
  ret i64 293
operation.65:
  ret i64 302
operation.66:
  ret i64 316
operation.67:
  ret i64 318
operation.68:
  ret i64 334
operation.69:
  ret i64 452
operation.70:
  ret i64 18446744073709551615
invalid:
  call void @topal_kernel_numeric_abort_v1()
  unreachable
}

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!2660, !2661}
!llvm.ident = !{!2662}
!0 = !DIFile(filename: "static-linux-dispatch-v6.t", directory: "/home/mats/git/topal/linux-kernel/kernel/arch/x86_64/policy")
!1 = !{}
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !0, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !1, retainedTypes: !1)
!3 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!4 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!5 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!6 = !{!4, !5}
!7 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !0, size: 128, align: 64, elements: !6)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64, align: 64)
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !0, baseType: !8)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !0, baseType: !8)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "major", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "minor", file: !0, baseType: !10, size: 64, align: 64, offset: 64)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "patch", file: !0, baseType: !10, size: 64, align: 64, offset: 128)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "build", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!15 = !{!11, !12, !13, !14}
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalVersionHeader", file: !0, size: 256, align: 64, elements: !15)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "Version", file: !0, baseType: !17)
!19 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !20, size: 64, align: 64, offset: 0)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "byte_count", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!23 = !{!21, !22}
!24 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSerializationStreamHeader", file: !0, size: 128, align: 64, elements: !23)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64, align: 64)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "SerializationStream", file: !0, baseType: !25)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "numerator", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "denominator", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!29 = !{!27, !28}
!30 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRationalHeader", file: !0, size: 128, align: 64, elements: !29)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !30, size: 64, align: 64)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "Rational", file: !0, baseType: !31)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!37 = !{!33, !34, !35, !36}
!38 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeIntHeader", file: !0, size: 256, align: 64, elements: !37)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 64, align: 64)
!40 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Int", file: !0, baseType: !39)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !32, size: 64, align: 64, offset: 0)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !32, size: 64, align: 64, offset: 64)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!44 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!45 = !{!41, !42, !43, !44}
!46 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeRationalHeader", file: !0, size: 256, align: 64, elements: !45)
!47 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !46, size: 64, align: 64)
!48 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Rational", file: !0, baseType: !47)
!49 = !DIDerivedType(tag: DW_TAG_member, name: "is_error", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!51 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !50, size: 64, align: 64, offset: 64)
!52 = !{!49, !51}
!53 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalResultHeader", file: !0, size: 128, align: 64, elements: !52)
!54 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !53, size: 64, align: 64)
!55 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Int, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!56 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Nat, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Rational, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!58 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (String, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!59 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result ((Int, Int), lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !54)
!60 = !DIEnumerator(name: "Less", value: -1)
!61 = !DIEnumerator(name: "Equal", value: 0)
!62 = !DIEnumerator(name: "Greater", value: 1)
!63 = !{!60, !61, !62}
!64 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Comparison", file: !0, size: 32, align: 32, elements: !63)
!65 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!66 = !DIBasicType(name: "Unit", size: 8, encoding: DW_ATE_unsigned)
!67 = !DIEnumerator(name: "Completed", value: 0)
!68 = !{!67}
!69 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Completed", file: !0, size: 8, align: 8, elements: !68)
!70 = !DIEnumerator(name: "empty", value: 0)
!71 = !{!70}
!72 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Effect", file: !0, size: 8, align: 8, elements: !71)
!73 = !DIFile(filename: "syscall.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!74 = !{!65, !10, !10}
!75 = !DISubroutineType(types: !74)
!76 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.0", scope: !73, file: !73, line: 3, type: !75, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!77 = !DILocalVariable(name: "number", arg: 1, scope: !76, file: !73, line: 3, type: !10)
!78 = !DILocation(line: 3, column: 31, scope: !76)
!79 = !DILocalVariable(name: "expected", arg: 2, scope: !76, file: !73, line: 3, type: !10)
!80 = !DILocation(line: 3, column: 45, scope: !76)
!81 = !DILocation(line: 4, column: 3, scope: !76)
!82 = !DILocation(line: 4, column: 3, scope: !76)
!83 = !DILocation(line: 4, column: 3, scope: !76)
!84 = !DILocation(line: 4, column: 3, scope: !76)
!85 = !DIEnumerator(name: "ChangeDirectory", value: 0)
!86 = !DIEnumerator(name: "ChangeDirectoryByFile", value: 1)
!87 = !DIEnumerator(name: "ChangeMode", value: 2)
!88 = !DIEnumerator(name: "ChangeModeAt", value: 3)
!89 = !DIEnumerator(name: "ChangeModeAtFlags", value: 4)
!90 = !DIEnumerator(name: "ChangeModeByFile", value: 5)
!91 = !DIEnumerator(name: "ClockResolution", value: 6)
!92 = !DIEnumerator(name: "ClockSleep", value: 7)
!93 = !DIEnumerator(name: "ClockTime", value: 8)
!94 = !DIEnumerator(name: "Clone", value: 9)
!95 = !DIEnumerator(name: "Close", value: 10)
!96 = !DIEnumerator(name: "DirectoryEntries", value: 11)
!97 = !DIEnumerator(name: "Duplicate", value: 12)
!98 = !DIEnumerator(name: "DuplicateTo", value: 13)
!99 = !DIEnumerator(name: "DuplicateToFlags", value: 14)
!100 = !DIEnumerator(name: "EffectiveGroupId", value: 15)
!101 = !DIEnumerator(name: "EffectiveUserId", value: 16)
!102 = !DIEnumerator(name: "Execute", value: 17)
!103 = !DIEnumerator(name: "Exit", value: 18)
!104 = !DIEnumerator(name: "ExitGroup", value: 19)
!105 = !DIEnumerator(name: "FileControl", value: 20)
!106 = !DIEnumerator(name: "FileCreationMask", value: 21)
!107 = !DIEnumerator(name: "FileStatus", value: 22)
!108 = !DIEnumerator(name: "FileStatusAt", value: 23)
!109 = !DIEnumerator(name: "Fork", value: 24)
!110 = !DIEnumerator(name: "GroupId", value: 25)
!111 = !DIEnumerator(name: "IoControl", value: 26)
!112 = !DIEnumerator(name: "KernelIdentity", value: 27)
!113 = !DIEnumerator(name: "Link", value: 28)
!114 = !DIEnumerator(name: "LinkAt", value: 29)
!115 = !DIEnumerator(name: "NanoSleep", value: 30)
!116 = !DIEnumerator(name: "Open", value: 31)
!117 = !DIEnumerator(name: "OpenAt", value: 32)
!118 = !DIEnumerator(name: "ParentId", value: 33)
!119 = !DIEnumerator(name: "Pipe", value: 34)
!120 = !DIEnumerator(name: "PipeFlags", value: 35)
!121 = !DIEnumerator(name: "Poll", value: 36)
!122 = !DIEnumerator(name: "ProcessControl", value: 37)
!123 = !DIEnumerator(name: "ProcessId", value: 38)
!124 = !DIEnumerator(name: "ProgramBreak", value: 39)
!125 = !DIEnumerator(name: "ProtectMemory", value: 40)
!126 = !DIEnumerator(name: "RandomBytes", value: 41)
!127 = !DIEnumerator(name: "Read", value: 42)
!128 = !DIEnumerator(name: "ReadAt", value: 43)
!129 = !DIEnumerator(name: "ReadLinkAt", value: 44)
!130 = !DIEnumerator(name: "RealtimeSeconds", value: 45)
!131 = !DIEnumerator(name: "RegisterRobustList", value: 46)
!132 = !DIEnumerator(name: "RegisterThreadId", value: 47)
!133 = !DIEnumerator(name: "Rename", value: 48)
!134 = !DIEnumerator(name: "RenameAt", value: 49)
!135 = !DIEnumerator(name: "RenameAtFlags", value: 50)
!136 = !DIEnumerator(name: "ResourceLimit", value: 51)
!137 = !DIEnumerator(name: "ResourceLimits", value: 52)
!138 = !DIEnumerator(name: "RestartableSequences", value: 53)
!139 = !DIEnumerator(name: "Seek", value: 54)
!140 = !DIEnumerator(name: "SetGroupId", value: 55)
!141 = !DIEnumerator(name: "SetUserId", value: 56)
!142 = !DIEnumerator(name: "SignalAction", value: 57)
!143 = !DIEnumerator(name: "SignalMask", value: 58)
!144 = !DIEnumerator(name: "ThreadId", value: 59)
!145 = !DIEnumerator(name: "ThreadLocal", value: 60)
!146 = !DIEnumerator(name: "TruncateFile", value: 61)
!147 = !DIEnumerator(name: "Unlink", value: 62)
!148 = !DIEnumerator(name: "UnlinkAt", value: 63)
!149 = !DIEnumerator(name: "Unsupported", value: 64)
!150 = !DIEnumerator(name: "UserId", value: 65)
!151 = !DIEnumerator(name: "Wait", value: 66)
!152 = !DIEnumerator(name: "WorkingDirectory", value: 67)
!153 = !DIEnumerator(name: "Write", value: 68)
!154 = !DIEnumerator(name: "WriteAt", value: 69)
!155 = !DIEnumerator(name: "Yield", value: 70)
!156 = !{!85, !86, !87, !88, !89, !90, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108, !109, !110, !111, !112, !113, !114, !115, !116, !117, !118, !119, !120, !121, !122, !123, !124, !125, !126, !127, !128, !129, !130, !131, !132, !133, !134, !135, !136, !137, !138, !139, !140, !141, !142, !143, !144, !145, !146, !147, !148, !149, !150, !151, !152, !153, !154, !155}
!157 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "StaticLinuxOperation", file: !0, size: 32, align: 32, elements: !156)
!158 = !{!157, !10}
!159 = !DISubroutineType(types: !158)
!160 = distinct !DISubprogram(name: "select-range-0-0", linkageName: "topal.dispatch.topal.fn.select_2drange_2d0_2d0.1", scope: !0, file: !0, line: 6, type: !159, scopeLine: 6, spFlags: DISPFlagDefinition, unit: !2)
!161 = !DILocalVariable(name: "number", arg: 1, scope: !160, file: !0, line: 6, type: !10)
!162 = !DILocation(line: 6, column: 25, scope: !160)
!163 = !DILocation(line: 7, column: 3, scope: !160)
!164 = !DILocation(line: 7, column: 3, scope: !160)
!165 = !DILocation(line: 8, column: 15, scope: !160)
!166 = !DILocation(line: 9, column: 16, scope: !160)
!167 = !DILocation(line: 7, column: 3, scope: !160)
!168 = !DILocation(line: 7, column: 3, scope: !160)
!169 = !{!65, !10, !10}
!170 = !DISubroutineType(types: !169)
!171 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.2", scope: !73, file: !73, line: 3, type: !170, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!172 = !DILocalVariable(name: "number", arg: 1, scope: !171, file: !73, line: 3, type: !10)
!173 = !DILocation(line: 3, column: 31, scope: !171)
!174 = !DILocalVariable(name: "expected", arg: 2, scope: !171, file: !73, line: 3, type: !10)
!175 = !DILocation(line: 3, column: 45, scope: !171)
!176 = !DILocation(line: 4, column: 3, scope: !171)
!177 = !DILocation(line: 4, column: 3, scope: !171)
!178 = !DILocation(line: 4, column: 3, scope: !171)
!179 = !DILocation(line: 4, column: 3, scope: !171)
!180 = !{!157, !10}
!181 = !DISubroutineType(types: !180)
!182 = distinct !DISubprogram(name: "select-range-1-1", linkageName: "topal.dispatch.topal.fn.select_2drange_2d1_2d1.3", scope: !0, file: !0, line: 11, type: !181, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2)
!183 = !DILocalVariable(name: "number", arg: 1, scope: !182, file: !0, line: 11, type: !10)
!184 = !DILocation(line: 11, column: 25, scope: !182)
!185 = !DILocation(line: 12, column: 3, scope: !182)
!186 = !DILocation(line: 12, column: 3, scope: !182)
!187 = !DILocation(line: 13, column: 15, scope: !182)
!188 = !DILocation(line: 14, column: 16, scope: !182)
!189 = !DILocation(line: 12, column: 3, scope: !182)
!190 = !DILocation(line: 12, column: 3, scope: !182)
!191 = !{!157, !10}
!192 = !DISubroutineType(types: !191)
!193 = distinct !DISubprogram(name: "select-range-0-1", linkageName: "topal.dispatch.topal.fn.select_2drange_2d0_2d1.4", scope: !0, file: !0, line: 16, type: !192, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !2)
!194 = !DILocalVariable(name: "number", arg: 1, scope: !193, file: !0, line: 16, type: !10)
!195 = !DILocation(line: 16, column: 25, scope: !193)
!196 = !DILocation(line: 17, column: 3, scope: !193)
!197 = !DILocation(line: 17, column: 3, scope: !193)
!198 = !DILocation(line: 17, column: 3, scope: !193)
!199 = !DILocation(line: 18, column: 15, scope: !193)
!200 = !DILocation(line: 18, column: 15, scope: !193)
!201 = !DILocation(line: 19, column: 16, scope: !193)
!202 = !DILocation(line: 19, column: 16, scope: !193)
!203 = !DILocation(line: 17, column: 3, scope: !193)
!204 = !DILocation(line: 17, column: 3, scope: !193)
!205 = !{!65, !10, !10}
!206 = !DISubroutineType(types: !205)
!207 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.5", scope: !73, file: !73, line: 3, type: !206, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!208 = !DILocalVariable(name: "number", arg: 1, scope: !207, file: !73, line: 3, type: !10)
!209 = !DILocation(line: 3, column: 31, scope: !207)
!210 = !DILocalVariable(name: "expected", arg: 2, scope: !207, file: !73, line: 3, type: !10)
!211 = !DILocation(line: 3, column: 45, scope: !207)
!212 = !DILocation(line: 4, column: 3, scope: !207)
!213 = !DILocation(line: 4, column: 3, scope: !207)
!214 = !DILocation(line: 4, column: 3, scope: !207)
!215 = !DILocation(line: 4, column: 3, scope: !207)
!216 = !{!157, !10}
!217 = !DISubroutineType(types: !216)
!218 = distinct !DISubprogram(name: "select-range-2-2", linkageName: "topal.dispatch.topal.fn.select_2drange_2d2_2d2.6", scope: !0, file: !0, line: 21, type: !217, scopeLine: 21, spFlags: DISPFlagDefinition, unit: !2)
!219 = !DILocalVariable(name: "number", arg: 1, scope: !218, file: !0, line: 21, type: !10)
!220 = !DILocation(line: 21, column: 25, scope: !218)
!221 = !DILocation(line: 22, column: 3, scope: !218)
!222 = !DILocation(line: 22, column: 3, scope: !218)
!223 = !DILocation(line: 23, column: 15, scope: !218)
!224 = !DILocation(line: 24, column: 16, scope: !218)
!225 = !DILocation(line: 22, column: 3, scope: !218)
!226 = !DILocation(line: 22, column: 3, scope: !218)
!227 = !{!65, !10, !10}
!228 = !DISubroutineType(types: !227)
!229 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.7", scope: !73, file: !73, line: 3, type: !228, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!230 = !DILocalVariable(name: "number", arg: 1, scope: !229, file: !73, line: 3, type: !10)
!231 = !DILocation(line: 3, column: 31, scope: !229)
!232 = !DILocalVariable(name: "expected", arg: 2, scope: !229, file: !73, line: 3, type: !10)
!233 = !DILocation(line: 3, column: 45, scope: !229)
!234 = !DILocation(line: 4, column: 3, scope: !229)
!235 = !DILocation(line: 4, column: 3, scope: !229)
!236 = !DILocation(line: 4, column: 3, scope: !229)
!237 = !DILocation(line: 4, column: 3, scope: !229)
!238 = !{!157, !10}
!239 = !DISubroutineType(types: !238)
!240 = distinct !DISubprogram(name: "select-range-3-3", linkageName: "topal.dispatch.topal.fn.select_2drange_2d3_2d3.8", scope: !0, file: !0, line: 26, type: !239, scopeLine: 26, spFlags: DISPFlagDefinition, unit: !2)
!241 = !DILocalVariable(name: "number", arg: 1, scope: !240, file: !0, line: 26, type: !10)
!242 = !DILocation(line: 26, column: 25, scope: !240)
!243 = !DILocation(line: 27, column: 3, scope: !240)
!244 = !DILocation(line: 27, column: 3, scope: !240)
!245 = !DILocation(line: 28, column: 15, scope: !240)
!246 = !DILocation(line: 29, column: 16, scope: !240)
!247 = !DILocation(line: 27, column: 3, scope: !240)
!248 = !DILocation(line: 27, column: 3, scope: !240)
!249 = !{!157, !10}
!250 = !DISubroutineType(types: !249)
!251 = distinct !DISubprogram(name: "select-range-2-3", linkageName: "topal.dispatch.topal.fn.select_2drange_2d2_2d3.9", scope: !0, file: !0, line: 31, type: !250, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !2)
!252 = !DILocalVariable(name: "number", arg: 1, scope: !251, file: !0, line: 31, type: !10)
!253 = !DILocation(line: 31, column: 25, scope: !251)
!254 = !DILocation(line: 32, column: 3, scope: !251)
!255 = !DILocation(line: 32, column: 3, scope: !251)
!256 = !DILocation(line: 32, column: 3, scope: !251)
!257 = !DILocation(line: 33, column: 15, scope: !251)
!258 = !DILocation(line: 33, column: 15, scope: !251)
!259 = !DILocation(line: 34, column: 16, scope: !251)
!260 = !DILocation(line: 34, column: 16, scope: !251)
!261 = !DILocation(line: 32, column: 3, scope: !251)
!262 = !DILocation(line: 32, column: 3, scope: !251)
!263 = !{!157, !10}
!264 = !DISubroutineType(types: !263)
!265 = distinct !DISubprogram(name: "select-range-0-3", linkageName: "topal.dispatch.topal.fn.select_2drange_2d0_2d3.10", scope: !0, file: !0, line: 36, type: !264, scopeLine: 36, spFlags: DISPFlagDefinition, unit: !2)
!266 = !DILocalVariable(name: "number", arg: 1, scope: !265, file: !0, line: 36, type: !10)
!267 = !DILocation(line: 36, column: 25, scope: !265)
!268 = !DILocation(line: 37, column: 3, scope: !265)
!269 = !DILocation(line: 37, column: 3, scope: !265)
!270 = !DILocation(line: 37, column: 3, scope: !265)
!271 = !DILocation(line: 38, column: 15, scope: !265)
!272 = !DILocation(line: 38, column: 15, scope: !265)
!273 = !DILocation(line: 39, column: 16, scope: !265)
!274 = !DILocation(line: 39, column: 16, scope: !265)
!275 = !DILocation(line: 37, column: 3, scope: !265)
!276 = !DILocation(line: 37, column: 3, scope: !265)
!277 = !{!65, !10, !10}
!278 = !DISubroutineType(types: !277)
!279 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.11", scope: !73, file: !73, line: 3, type: !278, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!280 = !DILocalVariable(name: "number", arg: 1, scope: !279, file: !73, line: 3, type: !10)
!281 = !DILocation(line: 3, column: 31, scope: !279)
!282 = !DILocalVariable(name: "expected", arg: 2, scope: !279, file: !73, line: 3, type: !10)
!283 = !DILocation(line: 3, column: 45, scope: !279)
!284 = !DILocation(line: 4, column: 3, scope: !279)
!285 = !DILocation(line: 4, column: 3, scope: !279)
!286 = !DILocation(line: 4, column: 3, scope: !279)
!287 = !DILocation(line: 4, column: 3, scope: !279)
!288 = !{!157, !10}
!289 = !DISubroutineType(types: !288)
!290 = distinct !DISubprogram(name: "select-range-5-5", linkageName: "topal.dispatch.topal.fn.select_2drange_2d5_2d5.12", scope: !0, file: !0, line: 41, type: !289, scopeLine: 41, spFlags: DISPFlagDefinition, unit: !2)
!291 = !DILocalVariable(name: "number", arg: 1, scope: !290, file: !0, line: 41, type: !10)
!292 = !DILocation(line: 41, column: 25, scope: !290)
!293 = !DILocation(line: 42, column: 3, scope: !290)
!294 = !DILocation(line: 42, column: 3, scope: !290)
!295 = !DILocation(line: 43, column: 15, scope: !290)
!296 = !DILocation(line: 44, column: 16, scope: !290)
!297 = !DILocation(line: 42, column: 3, scope: !290)
!298 = !DILocation(line: 42, column: 3, scope: !290)
!299 = !{!65, !10, !10}
!300 = !DISubroutineType(types: !299)
!301 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.13", scope: !73, file: !73, line: 3, type: !300, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!302 = !DILocalVariable(name: "number", arg: 1, scope: !301, file: !73, line: 3, type: !10)
!303 = !DILocation(line: 3, column: 31, scope: !301)
!304 = !DILocalVariable(name: "expected", arg: 2, scope: !301, file: !73, line: 3, type: !10)
!305 = !DILocation(line: 3, column: 45, scope: !301)
!306 = !DILocation(line: 4, column: 3, scope: !301)
!307 = !DILocation(line: 4, column: 3, scope: !301)
!308 = !DILocation(line: 4, column: 3, scope: !301)
!309 = !DILocation(line: 4, column: 3, scope: !301)
!310 = !{!157, !10}
!311 = !DISubroutineType(types: !310)
!312 = distinct !DISubprogram(name: "select-range-7-7", linkageName: "topal.dispatch.topal.fn.select_2drange_2d7_2d7.14", scope: !0, file: !0, line: 46, type: !311, scopeLine: 46, spFlags: DISPFlagDefinition, unit: !2)
!313 = !DILocalVariable(name: "number", arg: 1, scope: !312, file: !0, line: 46, type: !10)
!314 = !DILocation(line: 46, column: 25, scope: !312)
!315 = !DILocation(line: 47, column: 3, scope: !312)
!316 = !DILocation(line: 47, column: 3, scope: !312)
!317 = !DILocation(line: 48, column: 15, scope: !312)
!318 = !DILocation(line: 49, column: 16, scope: !312)
!319 = !DILocation(line: 47, column: 3, scope: !312)
!320 = !DILocation(line: 47, column: 3, scope: !312)
!321 = !{!157, !10}
!322 = !DISubroutineType(types: !321)
!323 = distinct !DISubprogram(name: "select-range-5-7", linkageName: "topal.dispatch.topal.fn.select_2drange_2d5_2d7.15", scope: !0, file: !0, line: 51, type: !322, scopeLine: 51, spFlags: DISPFlagDefinition, unit: !2)
!324 = !DILocalVariable(name: "number", arg: 1, scope: !323, file: !0, line: 51, type: !10)
!325 = !DILocation(line: 51, column: 25, scope: !323)
!326 = !DILocation(line: 52, column: 3, scope: !323)
!327 = !DILocation(line: 52, column: 3, scope: !323)
!328 = !DILocation(line: 52, column: 3, scope: !323)
!329 = !DILocation(line: 53, column: 15, scope: !323)
!330 = !DILocation(line: 53, column: 15, scope: !323)
!331 = !DILocation(line: 54, column: 16, scope: !323)
!332 = !DILocation(line: 54, column: 16, scope: !323)
!333 = !DILocation(line: 52, column: 3, scope: !323)
!334 = !DILocation(line: 52, column: 3, scope: !323)
!335 = !{!65, !10, !10}
!336 = !DISubroutineType(types: !335)
!337 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.16", scope: !73, file: !73, line: 3, type: !336, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!338 = !DILocalVariable(name: "number", arg: 1, scope: !337, file: !73, line: 3, type: !10)
!339 = !DILocation(line: 3, column: 31, scope: !337)
!340 = !DILocalVariable(name: "expected", arg: 2, scope: !337, file: !73, line: 3, type: !10)
!341 = !DILocation(line: 3, column: 45, scope: !337)
!342 = !DILocation(line: 4, column: 3, scope: !337)
!343 = !DILocation(line: 4, column: 3, scope: !337)
!344 = !DILocation(line: 4, column: 3, scope: !337)
!345 = !DILocation(line: 4, column: 3, scope: !337)
!346 = !{!157, !10}
!347 = !DISubroutineType(types: !346)
!348 = distinct !DISubprogram(name: "select-range-8-8", linkageName: "topal.dispatch.topal.fn.select_2drange_2d8_2d8.17", scope: !0, file: !0, line: 56, type: !347, scopeLine: 56, spFlags: DISPFlagDefinition, unit: !2)
!349 = !DILocalVariable(name: "number", arg: 1, scope: !348, file: !0, line: 56, type: !10)
!350 = !DILocation(line: 56, column: 25, scope: !348)
!351 = !DILocation(line: 57, column: 3, scope: !348)
!352 = !DILocation(line: 57, column: 3, scope: !348)
!353 = !DILocation(line: 58, column: 15, scope: !348)
!354 = !DILocation(line: 59, column: 16, scope: !348)
!355 = !DILocation(line: 57, column: 3, scope: !348)
!356 = !DILocation(line: 57, column: 3, scope: !348)
!357 = !{!65, !10, !10}
!358 = !DISubroutineType(types: !357)
!359 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.18", scope: !73, file: !73, line: 3, type: !358, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!360 = !DILocalVariable(name: "number", arg: 1, scope: !359, file: !73, line: 3, type: !10)
!361 = !DILocation(line: 3, column: 31, scope: !359)
!362 = !DILocalVariable(name: "expected", arg: 2, scope: !359, file: !73, line: 3, type: !10)
!363 = !DILocation(line: 3, column: 45, scope: !359)
!364 = !DILocation(line: 4, column: 3, scope: !359)
!365 = !DILocation(line: 4, column: 3, scope: !359)
!366 = !DILocation(line: 4, column: 3, scope: !359)
!367 = !DILocation(line: 4, column: 3, scope: !359)
!368 = !{!157, !10}
!369 = !DISubroutineType(types: !368)
!370 = distinct !DISubprogram(name: "select-range-10-10", linkageName: "topal.dispatch.topal.fn.select_2drange_2d10_2d10.19", scope: !0, file: !0, line: 61, type: !369, scopeLine: 61, spFlags: DISPFlagDefinition, unit: !2)
!371 = !DILocalVariable(name: "number", arg: 1, scope: !370, file: !0, line: 61, type: !10)
!372 = !DILocation(line: 61, column: 27, scope: !370)
!373 = !DILocation(line: 62, column: 3, scope: !370)
!374 = !DILocation(line: 62, column: 3, scope: !370)
!375 = !DILocation(line: 63, column: 15, scope: !370)
!376 = !DILocation(line: 64, column: 16, scope: !370)
!377 = !DILocation(line: 62, column: 3, scope: !370)
!378 = !DILocation(line: 62, column: 3, scope: !370)
!379 = !{!157, !10}
!380 = !DISubroutineType(types: !379)
!381 = distinct !DISubprogram(name: "select-range-8-10", linkageName: "topal.dispatch.topal.fn.select_2drange_2d8_2d10.20", scope: !0, file: !0, line: 66, type: !380, scopeLine: 66, spFlags: DISPFlagDefinition, unit: !2)
!382 = !DILocalVariable(name: "number", arg: 1, scope: !381, file: !0, line: 66, type: !10)
!383 = !DILocation(line: 66, column: 26, scope: !381)
!384 = !DILocation(line: 67, column: 3, scope: !381)
!385 = !DILocation(line: 67, column: 3, scope: !381)
!386 = !DILocation(line: 67, column: 3, scope: !381)
!387 = !DILocation(line: 68, column: 15, scope: !381)
!388 = !DILocation(line: 68, column: 15, scope: !381)
!389 = !DILocation(line: 69, column: 16, scope: !381)
!390 = !DILocation(line: 69, column: 16, scope: !381)
!391 = !DILocation(line: 67, column: 3, scope: !381)
!392 = !DILocation(line: 67, column: 3, scope: !381)
!393 = !{!157, !10}
!394 = !DISubroutineType(types: !393)
!395 = distinct !DISubprogram(name: "select-range-5-10", linkageName: "topal.dispatch.topal.fn.select_2drange_2d5_2d10.21", scope: !0, file: !0, line: 71, type: !394, scopeLine: 71, spFlags: DISPFlagDefinition, unit: !2)
!396 = !DILocalVariable(name: "number", arg: 1, scope: !395, file: !0, line: 71, type: !10)
!397 = !DILocation(line: 71, column: 26, scope: !395)
!398 = !DILocation(line: 72, column: 3, scope: !395)
!399 = !DILocation(line: 72, column: 3, scope: !395)
!400 = !DILocation(line: 72, column: 3, scope: !395)
!401 = !DILocation(line: 73, column: 15, scope: !395)
!402 = !DILocation(line: 73, column: 15, scope: !395)
!403 = !DILocation(line: 74, column: 16, scope: !395)
!404 = !DILocation(line: 74, column: 16, scope: !395)
!405 = !DILocation(line: 72, column: 3, scope: !395)
!406 = !DILocation(line: 72, column: 3, scope: !395)
!407 = !{!157, !10}
!408 = !DISubroutineType(types: !407)
!409 = distinct !DISubprogram(name: "select-range-0-10", linkageName: "topal.dispatch.topal.fn.select_2drange_2d0_2d10.22", scope: !0, file: !0, line: 76, type: !408, scopeLine: 76, spFlags: DISPFlagDefinition, unit: !2)
!410 = !DILocalVariable(name: "number", arg: 1, scope: !409, file: !0, line: 76, type: !10)
!411 = !DILocation(line: 76, column: 26, scope: !409)
!412 = !DILocation(line: 77, column: 3, scope: !409)
!413 = !DILocation(line: 77, column: 3, scope: !409)
!414 = !DILocation(line: 77, column: 3, scope: !409)
!415 = !DILocation(line: 78, column: 15, scope: !409)
!416 = !DILocation(line: 78, column: 15, scope: !409)
!417 = !DILocation(line: 79, column: 16, scope: !409)
!418 = !DILocation(line: 79, column: 16, scope: !409)
!419 = !DILocation(line: 77, column: 3, scope: !409)
!420 = !DILocation(line: 77, column: 3, scope: !409)
!421 = !{!65, !10, !10}
!422 = !DISubroutineType(types: !421)
!423 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.23", scope: !73, file: !73, line: 3, type: !422, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!424 = !DILocalVariable(name: "number", arg: 1, scope: !423, file: !73, line: 3, type: !10)
!425 = !DILocation(line: 3, column: 31, scope: !423)
!426 = !DILocalVariable(name: "expected", arg: 2, scope: !423, file: !73, line: 3, type: !10)
!427 = !DILocation(line: 3, column: 45, scope: !423)
!428 = !DILocation(line: 4, column: 3, scope: !423)
!429 = !DILocation(line: 4, column: 3, scope: !423)
!430 = !DILocation(line: 4, column: 3, scope: !423)
!431 = !DILocation(line: 4, column: 3, scope: !423)
!432 = !{!157, !10}
!433 = !DISubroutineType(types: !432)
!434 = distinct !DISubprogram(name: "select-range-12-12", linkageName: "topal.dispatch.topal.fn.select_2drange_2d12_2d12.24", scope: !0, file: !0, line: 81, type: !433, scopeLine: 81, spFlags: DISPFlagDefinition, unit: !2)
!435 = !DILocalVariable(name: "number", arg: 1, scope: !434, file: !0, line: 81, type: !10)
!436 = !DILocation(line: 81, column: 27, scope: !434)
!437 = !DILocation(line: 82, column: 3, scope: !434)
!438 = !DILocation(line: 82, column: 3, scope: !434)
!439 = !DILocation(line: 83, column: 15, scope: !434)
!440 = !DILocation(line: 84, column: 16, scope: !434)
!441 = !DILocation(line: 82, column: 3, scope: !434)
!442 = !DILocation(line: 82, column: 3, scope: !434)
!443 = !{!65, !10, !10}
!444 = !DISubroutineType(types: !443)
!445 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.25", scope: !73, file: !73, line: 3, type: !444, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!446 = !DILocalVariable(name: "number", arg: 1, scope: !445, file: !73, line: 3, type: !10)
!447 = !DILocation(line: 3, column: 31, scope: !445)
!448 = !DILocalVariable(name: "expected", arg: 2, scope: !445, file: !73, line: 3, type: !10)
!449 = !DILocation(line: 3, column: 45, scope: !445)
!450 = !DILocation(line: 4, column: 3, scope: !445)
!451 = !DILocation(line: 4, column: 3, scope: !445)
!452 = !DILocation(line: 4, column: 3, scope: !445)
!453 = !DILocation(line: 4, column: 3, scope: !445)
!454 = !{!157, !10}
!455 = !DISubroutineType(types: !454)
!456 = distinct !DISubprogram(name: "select-range-13-13", linkageName: "topal.dispatch.topal.fn.select_2drange_2d13_2d13.26", scope: !0, file: !0, line: 86, type: !455, scopeLine: 86, spFlags: DISPFlagDefinition, unit: !2)
!457 = !DILocalVariable(name: "number", arg: 1, scope: !456, file: !0, line: 86, type: !10)
!458 = !DILocation(line: 86, column: 27, scope: !456)
!459 = !DILocation(line: 87, column: 3, scope: !456)
!460 = !DILocation(line: 87, column: 3, scope: !456)
!461 = !DILocation(line: 88, column: 15, scope: !456)
!462 = !DILocation(line: 89, column: 16, scope: !456)
!463 = !DILocation(line: 87, column: 3, scope: !456)
!464 = !DILocation(line: 87, column: 3, scope: !456)
!465 = !{!157, !10}
!466 = !DISubroutineType(types: !465)
!467 = distinct !DISubprogram(name: "select-range-12-13", linkageName: "topal.dispatch.topal.fn.select_2drange_2d12_2d13.27", scope: !0, file: !0, line: 91, type: !466, scopeLine: 91, spFlags: DISPFlagDefinition, unit: !2)
!468 = !DILocalVariable(name: "number", arg: 1, scope: !467, file: !0, line: 91, type: !10)
!469 = !DILocation(line: 91, column: 27, scope: !467)
!470 = !DILocation(line: 92, column: 3, scope: !467)
!471 = !DILocation(line: 92, column: 3, scope: !467)
!472 = !DILocation(line: 92, column: 3, scope: !467)
!473 = !DILocation(line: 93, column: 15, scope: !467)
!474 = !DILocation(line: 93, column: 15, scope: !467)
!475 = !DILocation(line: 94, column: 16, scope: !467)
!476 = !DILocation(line: 94, column: 16, scope: !467)
!477 = !DILocation(line: 92, column: 3, scope: !467)
!478 = !DILocation(line: 92, column: 3, scope: !467)
!479 = !{!65, !10, !10}
!480 = !DISubroutineType(types: !479)
!481 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.28", scope: !73, file: !73, line: 3, type: !480, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!482 = !DILocalVariable(name: "number", arg: 1, scope: !481, file: !73, line: 3, type: !10)
!483 = !DILocation(line: 3, column: 31, scope: !481)
!484 = !DILocalVariable(name: "expected", arg: 2, scope: !481, file: !73, line: 3, type: !10)
!485 = !DILocation(line: 3, column: 45, scope: !481)
!486 = !DILocation(line: 4, column: 3, scope: !481)
!487 = !DILocation(line: 4, column: 3, scope: !481)
!488 = !DILocation(line: 4, column: 3, scope: !481)
!489 = !DILocation(line: 4, column: 3, scope: !481)
!490 = !{!157, !10}
!491 = !DISubroutineType(types: !490)
!492 = distinct !DISubprogram(name: "select-range-14-14", linkageName: "topal.dispatch.topal.fn.select_2drange_2d14_2d14.29", scope: !0, file: !0, line: 96, type: !491, scopeLine: 96, spFlags: DISPFlagDefinition, unit: !2)
!493 = !DILocalVariable(name: "number", arg: 1, scope: !492, file: !0, line: 96, type: !10)
!494 = !DILocation(line: 96, column: 27, scope: !492)
!495 = !DILocation(line: 97, column: 3, scope: !492)
!496 = !DILocation(line: 97, column: 3, scope: !492)
!497 = !DILocation(line: 98, column: 15, scope: !492)
!498 = !DILocation(line: 99, column: 16, scope: !492)
!499 = !DILocation(line: 97, column: 3, scope: !492)
!500 = !DILocation(line: 97, column: 3, scope: !492)
!501 = !{!65, !10, !10}
!502 = !DISubroutineType(types: !501)
!503 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.30", scope: !73, file: !73, line: 3, type: !502, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!504 = !DILocalVariable(name: "number", arg: 1, scope: !503, file: !73, line: 3, type: !10)
!505 = !DILocation(line: 3, column: 31, scope: !503)
!506 = !DILocalVariable(name: "expected", arg: 2, scope: !503, file: !73, line: 3, type: !10)
!507 = !DILocation(line: 3, column: 45, scope: !503)
!508 = !DILocation(line: 4, column: 3, scope: !503)
!509 = !DILocation(line: 4, column: 3, scope: !503)
!510 = !DILocation(line: 4, column: 3, scope: !503)
!511 = !DILocation(line: 4, column: 3, scope: !503)
!512 = !{!157, !10}
!513 = !DISubroutineType(types: !512)
!514 = distinct !DISubprogram(name: "select-range-16-16", linkageName: "topal.dispatch.topal.fn.select_2drange_2d16_2d16.31", scope: !0, file: !0, line: 101, type: !513, scopeLine: 101, spFlags: DISPFlagDefinition, unit: !2)
!515 = !DILocalVariable(name: "number", arg: 1, scope: !514, file: !0, line: 101, type: !10)
!516 = !DILocation(line: 101, column: 27, scope: !514)
!517 = !DILocation(line: 102, column: 3, scope: !514)
!518 = !DILocation(line: 102, column: 3, scope: !514)
!519 = !DILocation(line: 103, column: 15, scope: !514)
!520 = !DILocation(line: 104, column: 16, scope: !514)
!521 = !DILocation(line: 102, column: 3, scope: !514)
!522 = !DILocation(line: 102, column: 3, scope: !514)
!523 = !{!157, !10}
!524 = !DISubroutineType(types: !523)
!525 = distinct !DISubprogram(name: "select-range-14-16", linkageName: "topal.dispatch.topal.fn.select_2drange_2d14_2d16.32", scope: !0, file: !0, line: 106, type: !524, scopeLine: 106, spFlags: DISPFlagDefinition, unit: !2)
!526 = !DILocalVariable(name: "number", arg: 1, scope: !525, file: !0, line: 106, type: !10)
!527 = !DILocation(line: 106, column: 27, scope: !525)
!528 = !DILocation(line: 107, column: 3, scope: !525)
!529 = !DILocation(line: 107, column: 3, scope: !525)
!530 = !DILocation(line: 107, column: 3, scope: !525)
!531 = !DILocation(line: 108, column: 15, scope: !525)
!532 = !DILocation(line: 108, column: 15, scope: !525)
!533 = !DILocation(line: 109, column: 16, scope: !525)
!534 = !DILocation(line: 109, column: 16, scope: !525)
!535 = !DILocation(line: 107, column: 3, scope: !525)
!536 = !DILocation(line: 107, column: 3, scope: !525)
!537 = !{!157, !10}
!538 = !DISubroutineType(types: !537)
!539 = distinct !DISubprogram(name: "select-range-12-16", linkageName: "topal.dispatch.topal.fn.select_2drange_2d12_2d16.33", scope: !0, file: !0, line: 111, type: !538, scopeLine: 111, spFlags: DISPFlagDefinition, unit: !2)
!540 = !DILocalVariable(name: "number", arg: 1, scope: !539, file: !0, line: 111, type: !10)
!541 = !DILocation(line: 111, column: 27, scope: !539)
!542 = !DILocation(line: 112, column: 3, scope: !539)
!543 = !DILocation(line: 112, column: 3, scope: !539)
!544 = !DILocation(line: 112, column: 3, scope: !539)
!545 = !DILocation(line: 113, column: 15, scope: !539)
!546 = !DILocation(line: 113, column: 15, scope: !539)
!547 = !DILocation(line: 114, column: 16, scope: !539)
!548 = !DILocation(line: 114, column: 16, scope: !539)
!549 = !DILocation(line: 112, column: 3, scope: !539)
!550 = !DILocation(line: 112, column: 3, scope: !539)
!551 = !{!65, !10, !10}
!552 = !DISubroutineType(types: !551)
!553 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.34", scope: !73, file: !73, line: 3, type: !552, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!554 = !DILocalVariable(name: "number", arg: 1, scope: !553, file: !73, line: 3, type: !10)
!555 = !DILocation(line: 3, column: 31, scope: !553)
!556 = !DILocalVariable(name: "expected", arg: 2, scope: !553, file: !73, line: 3, type: !10)
!557 = !DILocation(line: 3, column: 45, scope: !553)
!558 = !DILocation(line: 4, column: 3, scope: !553)
!559 = !DILocation(line: 4, column: 3, scope: !553)
!560 = !DILocation(line: 4, column: 3, scope: !553)
!561 = !DILocation(line: 4, column: 3, scope: !553)
!562 = !{!157, !10}
!563 = !DISubroutineType(types: !562)
!564 = distinct !DISubprogram(name: "select-range-17-17", linkageName: "topal.dispatch.topal.fn.select_2drange_2d17_2d17.35", scope: !0, file: !0, line: 116, type: !563, scopeLine: 116, spFlags: DISPFlagDefinition, unit: !2)
!565 = !DILocalVariable(name: "number", arg: 1, scope: !564, file: !0, line: 116, type: !10)
!566 = !DILocation(line: 116, column: 27, scope: !564)
!567 = !DILocation(line: 117, column: 3, scope: !564)
!568 = !DILocation(line: 117, column: 3, scope: !564)
!569 = !DILocation(line: 118, column: 15, scope: !564)
!570 = !DILocation(line: 119, column: 16, scope: !564)
!571 = !DILocation(line: 117, column: 3, scope: !564)
!572 = !DILocation(line: 117, column: 3, scope: !564)
!573 = !{!65, !10, !10}
!574 = !DISubroutineType(types: !573)
!575 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.36", scope: !73, file: !73, line: 3, type: !574, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!576 = !DILocalVariable(name: "number", arg: 1, scope: !575, file: !73, line: 3, type: !10)
!577 = !DILocation(line: 3, column: 31, scope: !575)
!578 = !DILocalVariable(name: "expected", arg: 2, scope: !575, file: !73, line: 3, type: !10)
!579 = !DILocation(line: 3, column: 45, scope: !575)
!580 = !DILocation(line: 4, column: 3, scope: !575)
!581 = !DILocation(line: 4, column: 3, scope: !575)
!582 = !DILocation(line: 4, column: 3, scope: !575)
!583 = !DILocation(line: 4, column: 3, scope: !575)
!584 = !{!157, !10}
!585 = !DISubroutineType(types: !584)
!586 = distinct !DISubprogram(name: "select-range-18-18", linkageName: "topal.dispatch.topal.fn.select_2drange_2d18_2d18.37", scope: !0, file: !0, line: 121, type: !585, scopeLine: 121, spFlags: DISPFlagDefinition, unit: !2)
!587 = !DILocalVariable(name: "number", arg: 1, scope: !586, file: !0, line: 121, type: !10)
!588 = !DILocation(line: 121, column: 27, scope: !586)
!589 = !DILocation(line: 122, column: 3, scope: !586)
!590 = !DILocation(line: 122, column: 3, scope: !586)
!591 = !DILocation(line: 123, column: 15, scope: !586)
!592 = !DILocation(line: 124, column: 16, scope: !586)
!593 = !DILocation(line: 122, column: 3, scope: !586)
!594 = !DILocation(line: 122, column: 3, scope: !586)
!595 = !{!157, !10}
!596 = !DISubroutineType(types: !595)
!597 = distinct !DISubprogram(name: "select-range-17-18", linkageName: "topal.dispatch.topal.fn.select_2drange_2d17_2d18.38", scope: !0, file: !0, line: 126, type: !596, scopeLine: 126, spFlags: DISPFlagDefinition, unit: !2)
!598 = !DILocalVariable(name: "number", arg: 1, scope: !597, file: !0, line: 126, type: !10)
!599 = !DILocation(line: 126, column: 27, scope: !597)
!600 = !DILocation(line: 127, column: 3, scope: !597)
!601 = !DILocation(line: 127, column: 3, scope: !597)
!602 = !DILocation(line: 127, column: 3, scope: !597)
!603 = !DILocation(line: 128, column: 15, scope: !597)
!604 = !DILocation(line: 128, column: 15, scope: !597)
!605 = !DILocation(line: 129, column: 16, scope: !597)
!606 = !DILocation(line: 129, column: 16, scope: !597)
!607 = !DILocation(line: 127, column: 3, scope: !597)
!608 = !DILocation(line: 127, column: 3, scope: !597)
!609 = !{!65, !10, !10}
!610 = !DISubroutineType(types: !609)
!611 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.39", scope: !73, file: !73, line: 3, type: !610, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!612 = !DILocalVariable(name: "number", arg: 1, scope: !611, file: !73, line: 3, type: !10)
!613 = !DILocation(line: 3, column: 31, scope: !611)
!614 = !DILocalVariable(name: "expected", arg: 2, scope: !611, file: !73, line: 3, type: !10)
!615 = !DILocation(line: 3, column: 45, scope: !611)
!616 = !DILocation(line: 4, column: 3, scope: !611)
!617 = !DILocation(line: 4, column: 3, scope: !611)
!618 = !DILocation(line: 4, column: 3, scope: !611)
!619 = !DILocation(line: 4, column: 3, scope: !611)
!620 = !{!157, !10}
!621 = !DISubroutineType(types: !620)
!622 = distinct !DISubprogram(name: "select-range-22-22", linkageName: "topal.dispatch.topal.fn.select_2drange_2d22_2d22.40", scope: !0, file: !0, line: 131, type: !621, scopeLine: 131, spFlags: DISPFlagDefinition, unit: !2)
!623 = !DILocalVariable(name: "number", arg: 1, scope: !622, file: !0, line: 131, type: !10)
!624 = !DILocation(line: 131, column: 27, scope: !622)
!625 = !DILocation(line: 132, column: 3, scope: !622)
!626 = !DILocation(line: 132, column: 3, scope: !622)
!627 = !DILocation(line: 133, column: 15, scope: !622)
!628 = !DILocation(line: 134, column: 16, scope: !622)
!629 = !DILocation(line: 132, column: 3, scope: !622)
!630 = !DILocation(line: 132, column: 3, scope: !622)
!631 = !{!65, !10, !10}
!632 = !DISubroutineType(types: !631)
!633 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.41", scope: !73, file: !73, line: 3, type: !632, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!634 = !DILocalVariable(name: "number", arg: 1, scope: !633, file: !73, line: 3, type: !10)
!635 = !DILocation(line: 3, column: 31, scope: !633)
!636 = !DILocalVariable(name: "expected", arg: 2, scope: !633, file: !73, line: 3, type: !10)
!637 = !DILocation(line: 3, column: 45, scope: !633)
!638 = !DILocation(line: 4, column: 3, scope: !633)
!639 = !DILocation(line: 4, column: 3, scope: !633)
!640 = !DILocation(line: 4, column: 3, scope: !633)
!641 = !DILocation(line: 4, column: 3, scope: !633)
!642 = !{!157, !10}
!643 = !DISubroutineType(types: !642)
!644 = distinct !DISubprogram(name: "select-range-24-24", linkageName: "topal.dispatch.topal.fn.select_2drange_2d24_2d24.42", scope: !0, file: !0, line: 136, type: !643, scopeLine: 136, spFlags: DISPFlagDefinition, unit: !2)
!645 = !DILocalVariable(name: "number", arg: 1, scope: !644, file: !0, line: 136, type: !10)
!646 = !DILocation(line: 136, column: 27, scope: !644)
!647 = !DILocation(line: 137, column: 3, scope: !644)
!648 = !DILocation(line: 137, column: 3, scope: !644)
!649 = !DILocation(line: 138, column: 15, scope: !644)
!650 = !DILocation(line: 139, column: 16, scope: !644)
!651 = !DILocation(line: 137, column: 3, scope: !644)
!652 = !DILocation(line: 137, column: 3, scope: !644)
!653 = !{!65, !10, !10}
!654 = !DISubroutineType(types: !653)
!655 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.43", scope: !73, file: !73, line: 3, type: !654, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!656 = !DILocalVariable(name: "number", arg: 1, scope: !655, file: !73, line: 3, type: !10)
!657 = !DILocation(line: 3, column: 31, scope: !655)
!658 = !DILocalVariable(name: "expected", arg: 2, scope: !655, file: !73, line: 3, type: !10)
!659 = !DILocation(line: 3, column: 45, scope: !655)
!660 = !DILocation(line: 4, column: 3, scope: !655)
!661 = !DILocation(line: 4, column: 3, scope: !655)
!662 = !DILocation(line: 4, column: 3, scope: !655)
!663 = !DILocation(line: 4, column: 3, scope: !655)
!664 = !{!157, !10}
!665 = !DISubroutineType(types: !664)
!666 = distinct !DISubprogram(name: "select-range-32-32", linkageName: "topal.dispatch.topal.fn.select_2drange_2d32_2d32.44", scope: !0, file: !0, line: 141, type: !665, scopeLine: 141, spFlags: DISPFlagDefinition, unit: !2)
!667 = !DILocalVariable(name: "number", arg: 1, scope: !666, file: !0, line: 141, type: !10)
!668 = !DILocation(line: 141, column: 27, scope: !666)
!669 = !DILocation(line: 142, column: 3, scope: !666)
!670 = !DILocation(line: 142, column: 3, scope: !666)
!671 = !DILocation(line: 143, column: 15, scope: !666)
!672 = !DILocation(line: 144, column: 16, scope: !666)
!673 = !DILocation(line: 142, column: 3, scope: !666)
!674 = !DILocation(line: 142, column: 3, scope: !666)
!675 = !{!157, !10}
!676 = !DISubroutineType(types: !675)
!677 = distinct !DISubprogram(name: "select-range-24-32", linkageName: "topal.dispatch.topal.fn.select_2drange_2d24_2d32.45", scope: !0, file: !0, line: 146, type: !676, scopeLine: 146, spFlags: DISPFlagDefinition, unit: !2)
!678 = !DILocalVariable(name: "number", arg: 1, scope: !677, file: !0, line: 146, type: !10)
!679 = !DILocation(line: 146, column: 27, scope: !677)
!680 = !DILocation(line: 147, column: 3, scope: !677)
!681 = !DILocation(line: 147, column: 3, scope: !677)
!682 = !DILocation(line: 147, column: 3, scope: !677)
!683 = !DILocation(line: 148, column: 15, scope: !677)
!684 = !DILocation(line: 148, column: 15, scope: !677)
!685 = !DILocation(line: 149, column: 16, scope: !677)
!686 = !DILocation(line: 149, column: 16, scope: !677)
!687 = !DILocation(line: 147, column: 3, scope: !677)
!688 = !DILocation(line: 147, column: 3, scope: !677)
!689 = !{!157, !10}
!690 = !DISubroutineType(types: !689)
!691 = distinct !DISubprogram(name: "select-range-22-32", linkageName: "topal.dispatch.topal.fn.select_2drange_2d22_2d32.46", scope: !0, file: !0, line: 151, type: !690, scopeLine: 151, spFlags: DISPFlagDefinition, unit: !2)
!692 = !DILocalVariable(name: "number", arg: 1, scope: !691, file: !0, line: 151, type: !10)
!693 = !DILocation(line: 151, column: 27, scope: !691)
!694 = !DILocation(line: 152, column: 3, scope: !691)
!695 = !DILocation(line: 152, column: 3, scope: !691)
!696 = !DILocation(line: 152, column: 3, scope: !691)
!697 = !DILocation(line: 153, column: 15, scope: !691)
!698 = !DILocation(line: 153, column: 15, scope: !691)
!699 = !DILocation(line: 154, column: 16, scope: !691)
!700 = !DILocation(line: 154, column: 16, scope: !691)
!701 = !DILocation(line: 152, column: 3, scope: !691)
!702 = !DILocation(line: 152, column: 3, scope: !691)
!703 = !{!157, !10}
!704 = !DISubroutineType(types: !703)
!705 = distinct !DISubprogram(name: "select-range-17-32", linkageName: "topal.dispatch.topal.fn.select_2drange_2d17_2d32.47", scope: !0, file: !0, line: 156, type: !704, scopeLine: 156, spFlags: DISPFlagDefinition, unit: !2)
!706 = !DILocalVariable(name: "number", arg: 1, scope: !705, file: !0, line: 156, type: !10)
!707 = !DILocation(line: 156, column: 27, scope: !705)
!708 = !DILocation(line: 157, column: 3, scope: !705)
!709 = !DILocation(line: 157, column: 3, scope: !705)
!710 = !DILocation(line: 157, column: 3, scope: !705)
!711 = !DILocation(line: 158, column: 15, scope: !705)
!712 = !DILocation(line: 158, column: 15, scope: !705)
!713 = !DILocation(line: 159, column: 16, scope: !705)
!714 = !DILocation(line: 159, column: 16, scope: !705)
!715 = !DILocation(line: 157, column: 3, scope: !705)
!716 = !DILocation(line: 157, column: 3, scope: !705)
!717 = !{!157, !10}
!718 = !DISubroutineType(types: !717)
!719 = distinct !DISubprogram(name: "select-range-12-32", linkageName: "topal.dispatch.topal.fn.select_2drange_2d12_2d32.48", scope: !0, file: !0, line: 161, type: !718, scopeLine: 161, spFlags: DISPFlagDefinition, unit: !2)
!720 = !DILocalVariable(name: "number", arg: 1, scope: !719, file: !0, line: 161, type: !10)
!721 = !DILocation(line: 161, column: 27, scope: !719)
!722 = !DILocation(line: 162, column: 3, scope: !719)
!723 = !DILocation(line: 162, column: 3, scope: !719)
!724 = !DILocation(line: 162, column: 3, scope: !719)
!725 = !DILocation(line: 163, column: 15, scope: !719)
!726 = !DILocation(line: 163, column: 15, scope: !719)
!727 = !DILocation(line: 164, column: 16, scope: !719)
!728 = !DILocation(line: 164, column: 16, scope: !719)
!729 = !DILocation(line: 162, column: 3, scope: !719)
!730 = !DILocation(line: 162, column: 3, scope: !719)
!731 = !{!157, !10}
!732 = !DISubroutineType(types: !731)
!733 = distinct !DISubprogram(name: "select-range-0-32", linkageName: "topal.dispatch.topal.fn.select_2drange_2d0_2d32.49", scope: !0, file: !0, line: 166, type: !732, scopeLine: 166, spFlags: DISPFlagDefinition, unit: !2)
!734 = !DILocalVariable(name: "number", arg: 1, scope: !733, file: !0, line: 166, type: !10)
!735 = !DILocation(line: 166, column: 26, scope: !733)
!736 = !DILocation(line: 167, column: 3, scope: !733)
!737 = !DILocation(line: 167, column: 3, scope: !733)
!738 = !DILocation(line: 167, column: 3, scope: !733)
!739 = !DILocation(line: 168, column: 15, scope: !733)
!740 = !DILocation(line: 168, column: 15, scope: !733)
!741 = !DILocation(line: 169, column: 16, scope: !733)
!742 = !DILocation(line: 169, column: 16, scope: !733)
!743 = !DILocation(line: 167, column: 3, scope: !733)
!744 = !DILocation(line: 167, column: 3, scope: !733)
!745 = !{!65, !10, !10}
!746 = !DISubroutineType(types: !745)
!747 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.50", scope: !73, file: !73, line: 3, type: !746, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!748 = !DILocalVariable(name: "number", arg: 1, scope: !747, file: !73, line: 3, type: !10)
!749 = !DILocation(line: 3, column: 31, scope: !747)
!750 = !DILocalVariable(name: "expected", arg: 2, scope: !747, file: !73, line: 3, type: !10)
!751 = !DILocation(line: 3, column: 45, scope: !747)
!752 = !DILocation(line: 4, column: 3, scope: !747)
!753 = !DILocation(line: 4, column: 3, scope: !747)
!754 = !DILocation(line: 4, column: 3, scope: !747)
!755 = !DILocation(line: 4, column: 3, scope: !747)
!756 = !{!157, !10}
!757 = !DISubroutineType(types: !756)
!758 = distinct !DISubprogram(name: "select-range-33-33", linkageName: "topal.dispatch.topal.fn.select_2drange_2d33_2d33.51", scope: !0, file: !0, line: 171, type: !757, scopeLine: 171, spFlags: DISPFlagDefinition, unit: !2)
!759 = !DILocalVariable(name: "number", arg: 1, scope: !758, file: !0, line: 171, type: !10)
!760 = !DILocation(line: 171, column: 27, scope: !758)
!761 = !DILocation(line: 172, column: 3, scope: !758)
!762 = !DILocation(line: 172, column: 3, scope: !758)
!763 = !DILocation(line: 173, column: 15, scope: !758)
!764 = !DILocation(line: 174, column: 16, scope: !758)
!765 = !DILocation(line: 172, column: 3, scope: !758)
!766 = !DILocation(line: 172, column: 3, scope: !758)
!767 = !{!65, !10, !10}
!768 = !DISubroutineType(types: !767)
!769 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.52", scope: !73, file: !73, line: 3, type: !768, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!770 = !DILocalVariable(name: "number", arg: 1, scope: !769, file: !73, line: 3, type: !10)
!771 = !DILocation(line: 3, column: 31, scope: !769)
!772 = !DILocalVariable(name: "expected", arg: 2, scope: !769, file: !73, line: 3, type: !10)
!773 = !DILocation(line: 3, column: 45, scope: !769)
!774 = !DILocation(line: 4, column: 3, scope: !769)
!775 = !DILocation(line: 4, column: 3, scope: !769)
!776 = !DILocation(line: 4, column: 3, scope: !769)
!777 = !DILocation(line: 4, column: 3, scope: !769)
!778 = !{!157, !10}
!779 = !DISubroutineType(types: !778)
!780 = distinct !DISubprogram(name: "select-range-35-35", linkageName: "topal.dispatch.topal.fn.select_2drange_2d35_2d35.53", scope: !0, file: !0, line: 176, type: !779, scopeLine: 176, spFlags: DISPFlagDefinition, unit: !2)
!781 = !DILocalVariable(name: "number", arg: 1, scope: !780, file: !0, line: 176, type: !10)
!782 = !DILocation(line: 176, column: 27, scope: !780)
!783 = !DILocation(line: 177, column: 3, scope: !780)
!784 = !DILocation(line: 177, column: 3, scope: !780)
!785 = !DILocation(line: 178, column: 15, scope: !780)
!786 = !DILocation(line: 179, column: 16, scope: !780)
!787 = !DILocation(line: 177, column: 3, scope: !780)
!788 = !DILocation(line: 177, column: 3, scope: !780)
!789 = !{!157, !10}
!790 = !DISubroutineType(types: !789)
!791 = distinct !DISubprogram(name: "select-range-33-35", linkageName: "topal.dispatch.topal.fn.select_2drange_2d33_2d35.54", scope: !0, file: !0, line: 181, type: !790, scopeLine: 181, spFlags: DISPFlagDefinition, unit: !2)
!792 = !DILocalVariable(name: "number", arg: 1, scope: !791, file: !0, line: 181, type: !10)
!793 = !DILocation(line: 181, column: 27, scope: !791)
!794 = !DILocation(line: 182, column: 3, scope: !791)
!795 = !DILocation(line: 182, column: 3, scope: !791)
!796 = !DILocation(line: 182, column: 3, scope: !791)
!797 = !DILocation(line: 183, column: 15, scope: !791)
!798 = !DILocation(line: 183, column: 15, scope: !791)
!799 = !DILocation(line: 184, column: 16, scope: !791)
!800 = !DILocation(line: 184, column: 16, scope: !791)
!801 = !DILocation(line: 182, column: 3, scope: !791)
!802 = !DILocation(line: 182, column: 3, scope: !791)
!803 = !{!65, !10, !10}
!804 = !DISubroutineType(types: !803)
!805 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.55", scope: !73, file: !73, line: 3, type: !804, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!806 = !DILocalVariable(name: "number", arg: 1, scope: !805, file: !73, line: 3, type: !10)
!807 = !DILocation(line: 3, column: 31, scope: !805)
!808 = !DILocalVariable(name: "expected", arg: 2, scope: !805, file: !73, line: 3, type: !10)
!809 = !DILocation(line: 3, column: 45, scope: !805)
!810 = !DILocation(line: 4, column: 3, scope: !805)
!811 = !DILocation(line: 4, column: 3, scope: !805)
!812 = !DILocation(line: 4, column: 3, scope: !805)
!813 = !DILocation(line: 4, column: 3, scope: !805)
!814 = !{!157, !10}
!815 = !DISubroutineType(types: !814)
!816 = distinct !DISubprogram(name: "select-range-39-39", linkageName: "topal.dispatch.topal.fn.select_2drange_2d39_2d39.56", scope: !0, file: !0, line: 186, type: !815, scopeLine: 186, spFlags: DISPFlagDefinition, unit: !2)
!817 = !DILocalVariable(name: "number", arg: 1, scope: !816, file: !0, line: 186, type: !10)
!818 = !DILocation(line: 186, column: 27, scope: !816)
!819 = !DILocation(line: 187, column: 3, scope: !816)
!820 = !DILocation(line: 187, column: 3, scope: !816)
!821 = !DILocation(line: 188, column: 15, scope: !816)
!822 = !DILocation(line: 189, column: 16, scope: !816)
!823 = !DILocation(line: 187, column: 3, scope: !816)
!824 = !DILocation(line: 187, column: 3, scope: !816)
!825 = !{!65, !10, !10}
!826 = !DISubroutineType(types: !825)
!827 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.57", scope: !73, file: !73, line: 3, type: !826, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!828 = !DILocalVariable(name: "number", arg: 1, scope: !827, file: !73, line: 3, type: !10)
!829 = !DILocation(line: 3, column: 31, scope: !827)
!830 = !DILocalVariable(name: "expected", arg: 2, scope: !827, file: !73, line: 3, type: !10)
!831 = !DILocation(line: 3, column: 45, scope: !827)
!832 = !DILocation(line: 4, column: 3, scope: !827)
!833 = !DILocation(line: 4, column: 3, scope: !827)
!834 = !DILocation(line: 4, column: 3, scope: !827)
!835 = !DILocation(line: 4, column: 3, scope: !827)
!836 = !{!157, !10}
!837 = !DISubroutineType(types: !836)
!838 = distinct !DISubprogram(name: "select-range-56-56", linkageName: "topal.dispatch.topal.fn.select_2drange_2d56_2d56.58", scope: !0, file: !0, line: 191, type: !837, scopeLine: 191, spFlags: DISPFlagDefinition, unit: !2)
!839 = !DILocalVariable(name: "number", arg: 1, scope: !838, file: !0, line: 191, type: !10)
!840 = !DILocation(line: 191, column: 27, scope: !838)
!841 = !DILocation(line: 192, column: 3, scope: !838)
!842 = !DILocation(line: 192, column: 3, scope: !838)
!843 = !DILocation(line: 193, column: 15, scope: !838)
!844 = !DILocation(line: 194, column: 16, scope: !838)
!845 = !DILocation(line: 192, column: 3, scope: !838)
!846 = !DILocation(line: 192, column: 3, scope: !838)
!847 = !{!157, !10}
!848 = !DISubroutineType(types: !847)
!849 = distinct !DISubprogram(name: "select-range-39-56", linkageName: "topal.dispatch.topal.fn.select_2drange_2d39_2d56.59", scope: !0, file: !0, line: 196, type: !848, scopeLine: 196, spFlags: DISPFlagDefinition, unit: !2)
!850 = !DILocalVariable(name: "number", arg: 1, scope: !849, file: !0, line: 196, type: !10)
!851 = !DILocation(line: 196, column: 27, scope: !849)
!852 = !DILocation(line: 197, column: 3, scope: !849)
!853 = !DILocation(line: 197, column: 3, scope: !849)
!854 = !DILocation(line: 197, column: 3, scope: !849)
!855 = !DILocation(line: 198, column: 15, scope: !849)
!856 = !DILocation(line: 198, column: 15, scope: !849)
!857 = !DILocation(line: 199, column: 16, scope: !849)
!858 = !DILocation(line: 199, column: 16, scope: !849)
!859 = !DILocation(line: 197, column: 3, scope: !849)
!860 = !DILocation(line: 197, column: 3, scope: !849)
!861 = !{!157, !10}
!862 = !DISubroutineType(types: !861)
!863 = distinct !DISubprogram(name: "select-range-33-56", linkageName: "topal.dispatch.topal.fn.select_2drange_2d33_2d56.60", scope: !0, file: !0, line: 201, type: !862, scopeLine: 201, spFlags: DISPFlagDefinition, unit: !2)
!864 = !DILocalVariable(name: "number", arg: 1, scope: !863, file: !0, line: 201, type: !10)
!865 = !DILocation(line: 201, column: 27, scope: !863)
!866 = !DILocation(line: 202, column: 3, scope: !863)
!867 = !DILocation(line: 202, column: 3, scope: !863)
!868 = !DILocation(line: 202, column: 3, scope: !863)
!869 = !DILocation(line: 203, column: 15, scope: !863)
!870 = !DILocation(line: 203, column: 15, scope: !863)
!871 = !DILocation(line: 204, column: 16, scope: !863)
!872 = !DILocation(line: 204, column: 16, scope: !863)
!873 = !DILocation(line: 202, column: 3, scope: !863)
!874 = !DILocation(line: 202, column: 3, scope: !863)
!875 = !{!65, !10, !10}
!876 = !DISubroutineType(types: !875)
!877 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.61", scope: !73, file: !73, line: 3, type: !876, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!878 = !DILocalVariable(name: "number", arg: 1, scope: !877, file: !73, line: 3, type: !10)
!879 = !DILocation(line: 3, column: 31, scope: !877)
!880 = !DILocalVariable(name: "expected", arg: 2, scope: !877, file: !73, line: 3, type: !10)
!881 = !DILocation(line: 3, column: 45, scope: !877)
!882 = !DILocation(line: 4, column: 3, scope: !877)
!883 = !DILocation(line: 4, column: 3, scope: !877)
!884 = !DILocation(line: 4, column: 3, scope: !877)
!885 = !DILocation(line: 4, column: 3, scope: !877)
!886 = !{!157, !10}
!887 = !DISubroutineType(types: !886)
!888 = distinct !DISubprogram(name: "select-range-57-57", linkageName: "topal.dispatch.topal.fn.select_2drange_2d57_2d57.62", scope: !0, file: !0, line: 206, type: !887, scopeLine: 206, spFlags: DISPFlagDefinition, unit: !2)
!889 = !DILocalVariable(name: "number", arg: 1, scope: !888, file: !0, line: 206, type: !10)
!890 = !DILocation(line: 206, column: 27, scope: !888)
!891 = !DILocation(line: 207, column: 3, scope: !888)
!892 = !DILocation(line: 207, column: 3, scope: !888)
!893 = !DILocation(line: 208, column: 15, scope: !888)
!894 = !DILocation(line: 209, column: 16, scope: !888)
!895 = !DILocation(line: 207, column: 3, scope: !888)
!896 = !DILocation(line: 207, column: 3, scope: !888)
!897 = !{!65, !10, !10}
!898 = !DISubroutineType(types: !897)
!899 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.63", scope: !73, file: !73, line: 3, type: !898, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!900 = !DILocalVariable(name: "number", arg: 1, scope: !899, file: !73, line: 3, type: !10)
!901 = !DILocation(line: 3, column: 31, scope: !899)
!902 = !DILocalVariable(name: "expected", arg: 2, scope: !899, file: !73, line: 3, type: !10)
!903 = !DILocation(line: 3, column: 45, scope: !899)
!904 = !DILocation(line: 4, column: 3, scope: !899)
!905 = !DILocation(line: 4, column: 3, scope: !899)
!906 = !DILocation(line: 4, column: 3, scope: !899)
!907 = !DILocation(line: 4, column: 3, scope: !899)
!908 = !{!157, !10}
!909 = !DISubroutineType(types: !908)
!910 = distinct !DISubprogram(name: "select-range-59-59", linkageName: "topal.dispatch.topal.fn.select_2drange_2d59_2d59.64", scope: !0, file: !0, line: 211, type: !909, scopeLine: 211, spFlags: DISPFlagDefinition, unit: !2)
!911 = !DILocalVariable(name: "number", arg: 1, scope: !910, file: !0, line: 211, type: !10)
!912 = !DILocation(line: 211, column: 27, scope: !910)
!913 = !DILocation(line: 212, column: 3, scope: !910)
!914 = !DILocation(line: 212, column: 3, scope: !910)
!915 = !DILocation(line: 213, column: 15, scope: !910)
!916 = !DILocation(line: 214, column: 16, scope: !910)
!917 = !DILocation(line: 212, column: 3, scope: !910)
!918 = !DILocation(line: 212, column: 3, scope: !910)
!919 = !{!157, !10}
!920 = !DISubroutineType(types: !919)
!921 = distinct !DISubprogram(name: "select-range-57-59", linkageName: "topal.dispatch.topal.fn.select_2drange_2d57_2d59.65", scope: !0, file: !0, line: 216, type: !920, scopeLine: 216, spFlags: DISPFlagDefinition, unit: !2)
!922 = !DILocalVariable(name: "number", arg: 1, scope: !921, file: !0, line: 216, type: !10)
!923 = !DILocation(line: 216, column: 27, scope: !921)
!924 = !DILocation(line: 217, column: 3, scope: !921)
!925 = !DILocation(line: 217, column: 3, scope: !921)
!926 = !DILocation(line: 217, column: 3, scope: !921)
!927 = !DILocation(line: 218, column: 15, scope: !921)
!928 = !DILocation(line: 218, column: 15, scope: !921)
!929 = !DILocation(line: 219, column: 16, scope: !921)
!930 = !DILocation(line: 219, column: 16, scope: !921)
!931 = !DILocation(line: 217, column: 3, scope: !921)
!932 = !DILocation(line: 217, column: 3, scope: !921)
!933 = !{!65, !10, !10}
!934 = !DISubroutineType(types: !933)
!935 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.66", scope: !73, file: !73, line: 3, type: !934, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!936 = !DILocalVariable(name: "number", arg: 1, scope: !935, file: !73, line: 3, type: !10)
!937 = !DILocation(line: 3, column: 31, scope: !935)
!938 = !DILocalVariable(name: "expected", arg: 2, scope: !935, file: !73, line: 3, type: !10)
!939 = !DILocation(line: 3, column: 45, scope: !935)
!940 = !DILocation(line: 4, column: 3, scope: !935)
!941 = !DILocation(line: 4, column: 3, scope: !935)
!942 = !DILocation(line: 4, column: 3, scope: !935)
!943 = !DILocation(line: 4, column: 3, scope: !935)
!944 = !{!157, !10}
!945 = !DISubroutineType(types: !944)
!946 = distinct !DISubprogram(name: "select-range-60-60", linkageName: "topal.dispatch.topal.fn.select_2drange_2d60_2d60.67", scope: !0, file: !0, line: 221, type: !945, scopeLine: 221, spFlags: DISPFlagDefinition, unit: !2)
!947 = !DILocalVariable(name: "number", arg: 1, scope: !946, file: !0, line: 221, type: !10)
!948 = !DILocation(line: 221, column: 27, scope: !946)
!949 = !DILocation(line: 222, column: 3, scope: !946)
!950 = !DILocation(line: 222, column: 3, scope: !946)
!951 = !DILocation(line: 223, column: 15, scope: !946)
!952 = !DILocation(line: 224, column: 16, scope: !946)
!953 = !DILocation(line: 222, column: 3, scope: !946)
!954 = !DILocation(line: 222, column: 3, scope: !946)
!955 = !{!65, !10, !10}
!956 = !DISubroutineType(types: !955)
!957 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.68", scope: !73, file: !73, line: 3, type: !956, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!958 = !DILocalVariable(name: "number", arg: 1, scope: !957, file: !73, line: 3, type: !10)
!959 = !DILocation(line: 3, column: 31, scope: !957)
!960 = !DILocalVariable(name: "expected", arg: 2, scope: !957, file: !73, line: 3, type: !10)
!961 = !DILocation(line: 3, column: 45, scope: !957)
!962 = !DILocation(line: 4, column: 3, scope: !957)
!963 = !DILocation(line: 4, column: 3, scope: !957)
!964 = !DILocation(line: 4, column: 3, scope: !957)
!965 = !DILocation(line: 4, column: 3, scope: !957)
!966 = !{!157, !10}
!967 = !DISubroutineType(types: !966)
!968 = distinct !DISubprogram(name: "select-range-61-61", linkageName: "topal.dispatch.topal.fn.select_2drange_2d61_2d61.69", scope: !0, file: !0, line: 226, type: !967, scopeLine: 226, spFlags: DISPFlagDefinition, unit: !2)
!969 = !DILocalVariable(name: "number", arg: 1, scope: !968, file: !0, line: 226, type: !10)
!970 = !DILocation(line: 226, column: 27, scope: !968)
!971 = !DILocation(line: 227, column: 3, scope: !968)
!972 = !DILocation(line: 227, column: 3, scope: !968)
!973 = !DILocation(line: 228, column: 15, scope: !968)
!974 = !DILocation(line: 229, column: 16, scope: !968)
!975 = !DILocation(line: 227, column: 3, scope: !968)
!976 = !DILocation(line: 227, column: 3, scope: !968)
!977 = !{!65, !10, !10}
!978 = !DISubroutineType(types: !977)
!979 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.70", scope: !73, file: !73, line: 3, type: !978, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!980 = !DILocalVariable(name: "number", arg: 1, scope: !979, file: !73, line: 3, type: !10)
!981 = !DILocation(line: 3, column: 31, scope: !979)
!982 = !DILocalVariable(name: "expected", arg: 2, scope: !979, file: !73, line: 3, type: !10)
!983 = !DILocation(line: 3, column: 45, scope: !979)
!984 = !DILocation(line: 4, column: 3, scope: !979)
!985 = !DILocation(line: 4, column: 3, scope: !979)
!986 = !DILocation(line: 4, column: 3, scope: !979)
!987 = !DILocation(line: 4, column: 3, scope: !979)
!988 = !{!157, !10}
!989 = !DISubroutineType(types: !988)
!990 = distinct !DISubprogram(name: "select-range-63-63", linkageName: "topal.dispatch.topal.fn.select_2drange_2d63_2d63.71", scope: !0, file: !0, line: 231, type: !989, scopeLine: 231, spFlags: DISPFlagDefinition, unit: !2)
!991 = !DILocalVariable(name: "number", arg: 1, scope: !990, file: !0, line: 231, type: !10)
!992 = !DILocation(line: 231, column: 27, scope: !990)
!993 = !DILocation(line: 232, column: 3, scope: !990)
!994 = !DILocation(line: 232, column: 3, scope: !990)
!995 = !DILocation(line: 233, column: 15, scope: !990)
!996 = !DILocation(line: 234, column: 16, scope: !990)
!997 = !DILocation(line: 232, column: 3, scope: !990)
!998 = !DILocation(line: 232, column: 3, scope: !990)
!999 = !{!157, !10}
!1000 = !DISubroutineType(types: !999)
!1001 = distinct !DISubprogram(name: "select-range-61-63", linkageName: "topal.dispatch.topal.fn.select_2drange_2d61_2d63.72", scope: !0, file: !0, line: 236, type: !1000, scopeLine: 236, spFlags: DISPFlagDefinition, unit: !2)
!1002 = !DILocalVariable(name: "number", arg: 1, scope: !1001, file: !0, line: 236, type: !10)
!1003 = !DILocation(line: 236, column: 27, scope: !1001)
!1004 = !DILocation(line: 237, column: 3, scope: !1001)
!1005 = !DILocation(line: 237, column: 3, scope: !1001)
!1006 = !DILocation(line: 237, column: 3, scope: !1001)
!1007 = !DILocation(line: 238, column: 15, scope: !1001)
!1008 = !DILocation(line: 238, column: 15, scope: !1001)
!1009 = !DILocation(line: 239, column: 16, scope: !1001)
!1010 = !DILocation(line: 239, column: 16, scope: !1001)
!1011 = !DILocation(line: 237, column: 3, scope: !1001)
!1012 = !DILocation(line: 237, column: 3, scope: !1001)
!1013 = !{!157, !10}
!1014 = !DISubroutineType(types: !1013)
!1015 = distinct !DISubprogram(name: "select-range-60-63", linkageName: "topal.dispatch.topal.fn.select_2drange_2d60_2d63.73", scope: !0, file: !0, line: 241, type: !1014, scopeLine: 241, spFlags: DISPFlagDefinition, unit: !2)
!1016 = !DILocalVariable(name: "number", arg: 1, scope: !1015, file: !0, line: 241, type: !10)
!1017 = !DILocation(line: 241, column: 27, scope: !1015)
!1018 = !DILocation(line: 242, column: 3, scope: !1015)
!1019 = !DILocation(line: 242, column: 3, scope: !1015)
!1020 = !DILocation(line: 242, column: 3, scope: !1015)
!1021 = !DILocation(line: 243, column: 15, scope: !1015)
!1022 = !DILocation(line: 243, column: 15, scope: !1015)
!1023 = !DILocation(line: 244, column: 16, scope: !1015)
!1024 = !DILocation(line: 244, column: 16, scope: !1015)
!1025 = !DILocation(line: 242, column: 3, scope: !1015)
!1026 = !DILocation(line: 242, column: 3, scope: !1015)
!1027 = !{!157, !10}
!1028 = !DISubroutineType(types: !1027)
!1029 = distinct !DISubprogram(name: "select-range-57-63", linkageName: "topal.dispatch.topal.fn.select_2drange_2d57_2d63.74", scope: !0, file: !0, line: 246, type: !1028, scopeLine: 246, spFlags: DISPFlagDefinition, unit: !2)
!1030 = !DILocalVariable(name: "number", arg: 1, scope: !1029, file: !0, line: 246, type: !10)
!1031 = !DILocation(line: 246, column: 27, scope: !1029)
!1032 = !DILocation(line: 247, column: 3, scope: !1029)
!1033 = !DILocation(line: 247, column: 3, scope: !1029)
!1034 = !DILocation(line: 247, column: 3, scope: !1029)
!1035 = !DILocation(line: 248, column: 15, scope: !1029)
!1036 = !DILocation(line: 248, column: 15, scope: !1029)
!1037 = !DILocation(line: 249, column: 16, scope: !1029)
!1038 = !DILocation(line: 249, column: 16, scope: !1029)
!1039 = !DILocation(line: 247, column: 3, scope: !1029)
!1040 = !DILocation(line: 247, column: 3, scope: !1029)
!1041 = !{!157, !10}
!1042 = !DISubroutineType(types: !1041)
!1043 = distinct !DISubprogram(name: "select-range-33-63", linkageName: "topal.dispatch.topal.fn.select_2drange_2d33_2d63.75", scope: !0, file: !0, line: 251, type: !1042, scopeLine: 251, spFlags: DISPFlagDefinition, unit: !2)
!1044 = !DILocalVariable(name: "number", arg: 1, scope: !1043, file: !0, line: 251, type: !10)
!1045 = !DILocation(line: 251, column: 27, scope: !1043)
!1046 = !DILocation(line: 252, column: 3, scope: !1043)
!1047 = !DILocation(line: 252, column: 3, scope: !1043)
!1048 = !DILocation(line: 252, column: 3, scope: !1043)
!1049 = !DILocation(line: 253, column: 15, scope: !1043)
!1050 = !DILocation(line: 253, column: 15, scope: !1043)
!1051 = !DILocation(line: 254, column: 16, scope: !1043)
!1052 = !DILocation(line: 254, column: 16, scope: !1043)
!1053 = !DILocation(line: 252, column: 3, scope: !1043)
!1054 = !DILocation(line: 252, column: 3, scope: !1043)
!1055 = !{!65, !10, !10}
!1056 = !DISubroutineType(types: !1055)
!1057 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.76", scope: !73, file: !73, line: 3, type: !1056, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1058 = !DILocalVariable(name: "number", arg: 1, scope: !1057, file: !73, line: 3, type: !10)
!1059 = !DILocation(line: 3, column: 31, scope: !1057)
!1060 = !DILocalVariable(name: "expected", arg: 2, scope: !1057, file: !73, line: 3, type: !10)
!1061 = !DILocation(line: 3, column: 45, scope: !1057)
!1062 = !DILocation(line: 4, column: 3, scope: !1057)
!1063 = !DILocation(line: 4, column: 3, scope: !1057)
!1064 = !DILocation(line: 4, column: 3, scope: !1057)
!1065 = !DILocation(line: 4, column: 3, scope: !1057)
!1066 = !{!157, !10}
!1067 = !DISubroutineType(types: !1066)
!1068 = distinct !DISubprogram(name: "select-range-72-72", linkageName: "topal.dispatch.topal.fn.select_2drange_2d72_2d72.77", scope: !0, file: !0, line: 256, type: !1067, scopeLine: 256, spFlags: DISPFlagDefinition, unit: !2)
!1069 = !DILocalVariable(name: "number", arg: 1, scope: !1068, file: !0, line: 256, type: !10)
!1070 = !DILocation(line: 256, column: 27, scope: !1068)
!1071 = !DILocation(line: 257, column: 3, scope: !1068)
!1072 = !DILocation(line: 257, column: 3, scope: !1068)
!1073 = !DILocation(line: 258, column: 15, scope: !1068)
!1074 = !DILocation(line: 259, column: 16, scope: !1068)
!1075 = !DILocation(line: 257, column: 3, scope: !1068)
!1076 = !DILocation(line: 257, column: 3, scope: !1068)
!1077 = !{!65, !10, !10}
!1078 = !DISubroutineType(types: !1077)
!1079 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.78", scope: !73, file: !73, line: 3, type: !1078, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1080 = !DILocalVariable(name: "number", arg: 1, scope: !1079, file: !73, line: 3, type: !10)
!1081 = !DILocation(line: 3, column: 31, scope: !1079)
!1082 = !DILocalVariable(name: "expected", arg: 2, scope: !1079, file: !73, line: 3, type: !10)
!1083 = !DILocation(line: 3, column: 45, scope: !1079)
!1084 = !DILocation(line: 4, column: 3, scope: !1079)
!1085 = !DILocation(line: 4, column: 3, scope: !1079)
!1086 = !DILocation(line: 4, column: 3, scope: !1079)
!1087 = !DILocation(line: 4, column: 3, scope: !1079)
!1088 = !{!157, !10}
!1089 = !DISubroutineType(types: !1088)
!1090 = distinct !DISubprogram(name: "select-range-77-77", linkageName: "topal.dispatch.topal.fn.select_2drange_2d77_2d77.79", scope: !0, file: !0, line: 261, type: !1089, scopeLine: 261, spFlags: DISPFlagDefinition, unit: !2)
!1091 = !DILocalVariable(name: "number", arg: 1, scope: !1090, file: !0, line: 261, type: !10)
!1092 = !DILocation(line: 261, column: 27, scope: !1090)
!1093 = !DILocation(line: 262, column: 3, scope: !1090)
!1094 = !DILocation(line: 262, column: 3, scope: !1090)
!1095 = !DILocation(line: 263, column: 15, scope: !1090)
!1096 = !DILocation(line: 264, column: 16, scope: !1090)
!1097 = !DILocation(line: 262, column: 3, scope: !1090)
!1098 = !DILocation(line: 262, column: 3, scope: !1090)
!1099 = !{!157, !10}
!1100 = !DISubroutineType(types: !1099)
!1101 = distinct !DISubprogram(name: "select-range-72-77", linkageName: "topal.dispatch.topal.fn.select_2drange_2d72_2d77.80", scope: !0, file: !0, line: 266, type: !1100, scopeLine: 266, spFlags: DISPFlagDefinition, unit: !2)
!1102 = !DILocalVariable(name: "number", arg: 1, scope: !1101, file: !0, line: 266, type: !10)
!1103 = !DILocation(line: 266, column: 27, scope: !1101)
!1104 = !DILocation(line: 267, column: 3, scope: !1101)
!1105 = !DILocation(line: 267, column: 3, scope: !1101)
!1106 = !DILocation(line: 267, column: 3, scope: !1101)
!1107 = !DILocation(line: 268, column: 15, scope: !1101)
!1108 = !DILocation(line: 268, column: 15, scope: !1101)
!1109 = !DILocation(line: 269, column: 16, scope: !1101)
!1110 = !DILocation(line: 269, column: 16, scope: !1101)
!1111 = !DILocation(line: 267, column: 3, scope: !1101)
!1112 = !DILocation(line: 267, column: 3, scope: !1101)
!1113 = !{!65, !10, !10}
!1114 = !DISubroutineType(types: !1113)
!1115 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.81", scope: !73, file: !73, line: 3, type: !1114, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1116 = !DILocalVariable(name: "number", arg: 1, scope: !1115, file: !73, line: 3, type: !10)
!1117 = !DILocation(line: 3, column: 31, scope: !1115)
!1118 = !DILocalVariable(name: "expected", arg: 2, scope: !1115, file: !73, line: 3, type: !10)
!1119 = !DILocation(line: 3, column: 45, scope: !1115)
!1120 = !DILocation(line: 4, column: 3, scope: !1115)
!1121 = !DILocation(line: 4, column: 3, scope: !1115)
!1122 = !DILocation(line: 4, column: 3, scope: !1115)
!1123 = !DILocation(line: 4, column: 3, scope: !1115)
!1124 = !{!157, !10}
!1125 = !DISubroutineType(types: !1124)
!1126 = distinct !DISubprogram(name: "select-range-79-79", linkageName: "topal.dispatch.topal.fn.select_2drange_2d79_2d79.82", scope: !0, file: !0, line: 271, type: !1125, scopeLine: 271, spFlags: DISPFlagDefinition, unit: !2)
!1127 = !DILocalVariable(name: "number", arg: 1, scope: !1126, file: !0, line: 271, type: !10)
!1128 = !DILocation(line: 271, column: 27, scope: !1126)
!1129 = !DILocation(line: 272, column: 3, scope: !1126)
!1130 = !DILocation(line: 272, column: 3, scope: !1126)
!1131 = !DILocation(line: 273, column: 15, scope: !1126)
!1132 = !DILocation(line: 274, column: 16, scope: !1126)
!1133 = !DILocation(line: 272, column: 3, scope: !1126)
!1134 = !DILocation(line: 272, column: 3, scope: !1126)
!1135 = !{!65, !10, !10}
!1136 = !DISubroutineType(types: !1135)
!1137 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.83", scope: !73, file: !73, line: 3, type: !1136, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1138 = !DILocalVariable(name: "number", arg: 1, scope: !1137, file: !73, line: 3, type: !10)
!1139 = !DILocation(line: 3, column: 31, scope: !1137)
!1140 = !DILocalVariable(name: "expected", arg: 2, scope: !1137, file: !73, line: 3, type: !10)
!1141 = !DILocation(line: 3, column: 45, scope: !1137)
!1142 = !DILocation(line: 4, column: 3, scope: !1137)
!1143 = !DILocation(line: 4, column: 3, scope: !1137)
!1144 = !DILocation(line: 4, column: 3, scope: !1137)
!1145 = !DILocation(line: 4, column: 3, scope: !1137)
!1146 = !{!157, !10}
!1147 = !DISubroutineType(types: !1146)
!1148 = distinct !DISubprogram(name: "select-range-80-80", linkageName: "topal.dispatch.topal.fn.select_2drange_2d80_2d80.84", scope: !0, file: !0, line: 276, type: !1147, scopeLine: 276, spFlags: DISPFlagDefinition, unit: !2)
!1149 = !DILocalVariable(name: "number", arg: 1, scope: !1148, file: !0, line: 276, type: !10)
!1150 = !DILocation(line: 276, column: 27, scope: !1148)
!1151 = !DILocation(line: 277, column: 3, scope: !1148)
!1152 = !DILocation(line: 277, column: 3, scope: !1148)
!1153 = !DILocation(line: 278, column: 15, scope: !1148)
!1154 = !DILocation(line: 279, column: 16, scope: !1148)
!1155 = !DILocation(line: 277, column: 3, scope: !1148)
!1156 = !DILocation(line: 277, column: 3, scope: !1148)
!1157 = !{!157, !10}
!1158 = !DISubroutineType(types: !1157)
!1159 = distinct !DISubprogram(name: "select-range-79-80", linkageName: "topal.dispatch.topal.fn.select_2drange_2d79_2d80.85", scope: !0, file: !0, line: 281, type: !1158, scopeLine: 281, spFlags: DISPFlagDefinition, unit: !2)
!1160 = !DILocalVariable(name: "number", arg: 1, scope: !1159, file: !0, line: 281, type: !10)
!1161 = !DILocation(line: 281, column: 27, scope: !1159)
!1162 = !DILocation(line: 282, column: 3, scope: !1159)
!1163 = !DILocation(line: 282, column: 3, scope: !1159)
!1164 = !DILocation(line: 282, column: 3, scope: !1159)
!1165 = !DILocation(line: 283, column: 15, scope: !1159)
!1166 = !DILocation(line: 283, column: 15, scope: !1159)
!1167 = !DILocation(line: 284, column: 16, scope: !1159)
!1168 = !DILocation(line: 284, column: 16, scope: !1159)
!1169 = !DILocation(line: 282, column: 3, scope: !1159)
!1170 = !DILocation(line: 282, column: 3, scope: !1159)
!1171 = !{!157, !10}
!1172 = !DISubroutineType(types: !1171)
!1173 = distinct !DISubprogram(name: "select-range-72-80", linkageName: "topal.dispatch.topal.fn.select_2drange_2d72_2d80.86", scope: !0, file: !0, line: 286, type: !1172, scopeLine: 286, spFlags: DISPFlagDefinition, unit: !2)
!1174 = !DILocalVariable(name: "number", arg: 1, scope: !1173, file: !0, line: 286, type: !10)
!1175 = !DILocation(line: 286, column: 27, scope: !1173)
!1176 = !DILocation(line: 287, column: 3, scope: !1173)
!1177 = !DILocation(line: 287, column: 3, scope: !1173)
!1178 = !DILocation(line: 287, column: 3, scope: !1173)
!1179 = !DILocation(line: 288, column: 15, scope: !1173)
!1180 = !DILocation(line: 288, column: 15, scope: !1173)
!1181 = !DILocation(line: 289, column: 16, scope: !1173)
!1182 = !DILocation(line: 289, column: 16, scope: !1173)
!1183 = !DILocation(line: 287, column: 3, scope: !1173)
!1184 = !DILocation(line: 287, column: 3, scope: !1173)
!1185 = !{!65, !10, !10}
!1186 = !DISubroutineType(types: !1185)
!1187 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.87", scope: !73, file: !73, line: 3, type: !1186, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1188 = !DILocalVariable(name: "number", arg: 1, scope: !1187, file: !73, line: 3, type: !10)
!1189 = !DILocation(line: 3, column: 31, scope: !1187)
!1190 = !DILocalVariable(name: "expected", arg: 2, scope: !1187, file: !73, line: 3, type: !10)
!1191 = !DILocation(line: 3, column: 45, scope: !1187)
!1192 = !DILocation(line: 4, column: 3, scope: !1187)
!1193 = !DILocation(line: 4, column: 3, scope: !1187)
!1194 = !DILocation(line: 4, column: 3, scope: !1187)
!1195 = !DILocation(line: 4, column: 3, scope: !1187)
!1196 = !{!157, !10}
!1197 = !DISubroutineType(types: !1196)
!1198 = distinct !DISubprogram(name: "select-range-81-81", linkageName: "topal.dispatch.topal.fn.select_2drange_2d81_2d81.88", scope: !0, file: !0, line: 291, type: !1197, scopeLine: 291, spFlags: DISPFlagDefinition, unit: !2)
!1199 = !DILocalVariable(name: "number", arg: 1, scope: !1198, file: !0, line: 291, type: !10)
!1200 = !DILocation(line: 291, column: 27, scope: !1198)
!1201 = !DILocation(line: 292, column: 3, scope: !1198)
!1202 = !DILocation(line: 292, column: 3, scope: !1198)
!1203 = !DILocation(line: 293, column: 15, scope: !1198)
!1204 = !DILocation(line: 294, column: 16, scope: !1198)
!1205 = !DILocation(line: 292, column: 3, scope: !1198)
!1206 = !DILocation(line: 292, column: 3, scope: !1198)
!1207 = !{!65, !10, !10}
!1208 = !DISubroutineType(types: !1207)
!1209 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.89", scope: !73, file: !73, line: 3, type: !1208, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1210 = !DILocalVariable(name: "number", arg: 1, scope: !1209, file: !73, line: 3, type: !10)
!1211 = !DILocation(line: 3, column: 31, scope: !1209)
!1212 = !DILocalVariable(name: "expected", arg: 2, scope: !1209, file: !73, line: 3, type: !10)
!1213 = !DILocation(line: 3, column: 45, scope: !1209)
!1214 = !DILocation(line: 4, column: 3, scope: !1209)
!1215 = !DILocation(line: 4, column: 3, scope: !1209)
!1216 = !DILocation(line: 4, column: 3, scope: !1209)
!1217 = !DILocation(line: 4, column: 3, scope: !1209)
!1218 = !{!157, !10}
!1219 = !DISubroutineType(types: !1218)
!1220 = distinct !DISubprogram(name: "select-range-82-82", linkageName: "topal.dispatch.topal.fn.select_2drange_2d82_2d82.90", scope: !0, file: !0, line: 296, type: !1219, scopeLine: 296, spFlags: DISPFlagDefinition, unit: !2)
!1221 = !DILocalVariable(name: "number", arg: 1, scope: !1220, file: !0, line: 296, type: !10)
!1222 = !DILocation(line: 296, column: 27, scope: !1220)
!1223 = !DILocation(line: 297, column: 3, scope: !1220)
!1224 = !DILocation(line: 297, column: 3, scope: !1220)
!1225 = !DILocation(line: 298, column: 15, scope: !1220)
!1226 = !DILocation(line: 299, column: 16, scope: !1220)
!1227 = !DILocation(line: 297, column: 3, scope: !1220)
!1228 = !DILocation(line: 297, column: 3, scope: !1220)
!1229 = !{!157, !10}
!1230 = !DISubroutineType(types: !1229)
!1231 = distinct !DISubprogram(name: "select-range-81-82", linkageName: "topal.dispatch.topal.fn.select_2drange_2d81_2d82.91", scope: !0, file: !0, line: 301, type: !1230, scopeLine: 301, spFlags: DISPFlagDefinition, unit: !2)
!1232 = !DILocalVariable(name: "number", arg: 1, scope: !1231, file: !0, line: 301, type: !10)
!1233 = !DILocation(line: 301, column: 27, scope: !1231)
!1234 = !DILocation(line: 302, column: 3, scope: !1231)
!1235 = !DILocation(line: 302, column: 3, scope: !1231)
!1236 = !DILocation(line: 302, column: 3, scope: !1231)
!1237 = !DILocation(line: 303, column: 15, scope: !1231)
!1238 = !DILocation(line: 303, column: 15, scope: !1231)
!1239 = !DILocation(line: 304, column: 16, scope: !1231)
!1240 = !DILocation(line: 304, column: 16, scope: !1231)
!1241 = !DILocation(line: 302, column: 3, scope: !1231)
!1242 = !DILocation(line: 302, column: 3, scope: !1231)
!1243 = !{!65, !10, !10}
!1244 = !DISubroutineType(types: !1243)
!1245 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.92", scope: !73, file: !73, line: 3, type: !1244, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1246 = !DILocalVariable(name: "number", arg: 1, scope: !1245, file: !73, line: 3, type: !10)
!1247 = !DILocation(line: 3, column: 31, scope: !1245)
!1248 = !DILocalVariable(name: "expected", arg: 2, scope: !1245, file: !73, line: 3, type: !10)
!1249 = !DILocation(line: 3, column: 45, scope: !1245)
!1250 = !DILocation(line: 4, column: 3, scope: !1245)
!1251 = !DILocation(line: 4, column: 3, scope: !1245)
!1252 = !DILocation(line: 4, column: 3, scope: !1245)
!1253 = !DILocation(line: 4, column: 3, scope: !1245)
!1254 = !{!157, !10}
!1255 = !DISubroutineType(types: !1254)
!1256 = distinct !DISubprogram(name: "select-range-86-86", linkageName: "topal.dispatch.topal.fn.select_2drange_2d86_2d86.93", scope: !0, file: !0, line: 306, type: !1255, scopeLine: 306, spFlags: DISPFlagDefinition, unit: !2)
!1257 = !DILocalVariable(name: "number", arg: 1, scope: !1256, file: !0, line: 306, type: !10)
!1258 = !DILocation(line: 306, column: 27, scope: !1256)
!1259 = !DILocation(line: 307, column: 3, scope: !1256)
!1260 = !DILocation(line: 307, column: 3, scope: !1256)
!1261 = !DILocation(line: 308, column: 15, scope: !1256)
!1262 = !DILocation(line: 309, column: 16, scope: !1256)
!1263 = !DILocation(line: 307, column: 3, scope: !1256)
!1264 = !DILocation(line: 307, column: 3, scope: !1256)
!1265 = !{!65, !10, !10}
!1266 = !DISubroutineType(types: !1265)
!1267 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.94", scope: !73, file: !73, line: 3, type: !1266, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1268 = !DILocalVariable(name: "number", arg: 1, scope: !1267, file: !73, line: 3, type: !10)
!1269 = !DILocation(line: 3, column: 31, scope: !1267)
!1270 = !DILocalVariable(name: "expected", arg: 2, scope: !1267, file: !73, line: 3, type: !10)
!1271 = !DILocation(line: 3, column: 45, scope: !1267)
!1272 = !DILocation(line: 4, column: 3, scope: !1267)
!1273 = !DILocation(line: 4, column: 3, scope: !1267)
!1274 = !DILocation(line: 4, column: 3, scope: !1267)
!1275 = !DILocation(line: 4, column: 3, scope: !1267)
!1276 = !{!157, !10}
!1277 = !DISubroutineType(types: !1276)
!1278 = distinct !DISubprogram(name: "select-range-87-87", linkageName: "topal.dispatch.topal.fn.select_2drange_2d87_2d87.95", scope: !0, file: !0, line: 311, type: !1277, scopeLine: 311, spFlags: DISPFlagDefinition, unit: !2)
!1279 = !DILocalVariable(name: "number", arg: 1, scope: !1278, file: !0, line: 311, type: !10)
!1280 = !DILocation(line: 311, column: 27, scope: !1278)
!1281 = !DILocation(line: 312, column: 3, scope: !1278)
!1282 = !DILocation(line: 312, column: 3, scope: !1278)
!1283 = !DILocation(line: 313, column: 15, scope: !1278)
!1284 = !DILocation(line: 314, column: 16, scope: !1278)
!1285 = !DILocation(line: 312, column: 3, scope: !1278)
!1286 = !DILocation(line: 312, column: 3, scope: !1278)
!1287 = !{!65, !10, !10}
!1288 = !DISubroutineType(types: !1287)
!1289 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.96", scope: !73, file: !73, line: 3, type: !1288, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1290 = !DILocalVariable(name: "number", arg: 1, scope: !1289, file: !73, line: 3, type: !10)
!1291 = !DILocation(line: 3, column: 31, scope: !1289)
!1292 = !DILocalVariable(name: "expected", arg: 2, scope: !1289, file: !73, line: 3, type: !10)
!1293 = !DILocation(line: 3, column: 45, scope: !1289)
!1294 = !DILocation(line: 4, column: 3, scope: !1289)
!1295 = !DILocation(line: 4, column: 3, scope: !1289)
!1296 = !DILocation(line: 4, column: 3, scope: !1289)
!1297 = !DILocation(line: 4, column: 3, scope: !1289)
!1298 = !{!157, !10}
!1299 = !DISubroutineType(types: !1298)
!1300 = distinct !DISubprogram(name: "select-range-90-90", linkageName: "topal.dispatch.topal.fn.select_2drange_2d90_2d90.97", scope: !0, file: !0, line: 316, type: !1299, scopeLine: 316, spFlags: DISPFlagDefinition, unit: !2)
!1301 = !DILocalVariable(name: "number", arg: 1, scope: !1300, file: !0, line: 316, type: !10)
!1302 = !DILocation(line: 316, column: 27, scope: !1300)
!1303 = !DILocation(line: 317, column: 3, scope: !1300)
!1304 = !DILocation(line: 317, column: 3, scope: !1300)
!1305 = !DILocation(line: 318, column: 15, scope: !1300)
!1306 = !DILocation(line: 319, column: 16, scope: !1300)
!1307 = !DILocation(line: 317, column: 3, scope: !1300)
!1308 = !DILocation(line: 317, column: 3, scope: !1300)
!1309 = !{!157, !10}
!1310 = !DISubroutineType(types: !1309)
!1311 = distinct !DISubprogram(name: "select-range-87-90", linkageName: "topal.dispatch.topal.fn.select_2drange_2d87_2d90.98", scope: !0, file: !0, line: 321, type: !1310, scopeLine: 321, spFlags: DISPFlagDefinition, unit: !2)
!1312 = !DILocalVariable(name: "number", arg: 1, scope: !1311, file: !0, line: 321, type: !10)
!1313 = !DILocation(line: 321, column: 27, scope: !1311)
!1314 = !DILocation(line: 322, column: 3, scope: !1311)
!1315 = !DILocation(line: 322, column: 3, scope: !1311)
!1316 = !DILocation(line: 322, column: 3, scope: !1311)
!1317 = !DILocation(line: 323, column: 15, scope: !1311)
!1318 = !DILocation(line: 323, column: 15, scope: !1311)
!1319 = !DILocation(line: 324, column: 16, scope: !1311)
!1320 = !DILocation(line: 324, column: 16, scope: !1311)
!1321 = !DILocation(line: 322, column: 3, scope: !1311)
!1322 = !DILocation(line: 322, column: 3, scope: !1311)
!1323 = !{!157, !10}
!1324 = !DISubroutineType(types: !1323)
!1325 = distinct !DISubprogram(name: "select-range-86-90", linkageName: "topal.dispatch.topal.fn.select_2drange_2d86_2d90.99", scope: !0, file: !0, line: 326, type: !1324, scopeLine: 326, spFlags: DISPFlagDefinition, unit: !2)
!1326 = !DILocalVariable(name: "number", arg: 1, scope: !1325, file: !0, line: 326, type: !10)
!1327 = !DILocation(line: 326, column: 27, scope: !1325)
!1328 = !DILocation(line: 327, column: 3, scope: !1325)
!1329 = !DILocation(line: 327, column: 3, scope: !1325)
!1330 = !DILocation(line: 327, column: 3, scope: !1325)
!1331 = !DILocation(line: 328, column: 15, scope: !1325)
!1332 = !DILocation(line: 328, column: 15, scope: !1325)
!1333 = !DILocation(line: 329, column: 16, scope: !1325)
!1334 = !DILocation(line: 329, column: 16, scope: !1325)
!1335 = !DILocation(line: 327, column: 3, scope: !1325)
!1336 = !DILocation(line: 327, column: 3, scope: !1325)
!1337 = !{!157, !10}
!1338 = !DISubroutineType(types: !1337)
!1339 = distinct !DISubprogram(name: "select-range-81-90", linkageName: "topal.dispatch.topal.fn.select_2drange_2d81_2d90.100", scope: !0, file: !0, line: 331, type: !1338, scopeLine: 331, spFlags: DISPFlagDefinition, unit: !2)
!1340 = !DILocalVariable(name: "number", arg: 1, scope: !1339, file: !0, line: 331, type: !10)
!1341 = !DILocation(line: 331, column: 27, scope: !1339)
!1342 = !DILocation(line: 332, column: 3, scope: !1339)
!1343 = !DILocation(line: 332, column: 3, scope: !1339)
!1344 = !DILocation(line: 332, column: 3, scope: !1339)
!1345 = !DILocation(line: 333, column: 15, scope: !1339)
!1346 = !DILocation(line: 333, column: 15, scope: !1339)
!1347 = !DILocation(line: 334, column: 16, scope: !1339)
!1348 = !DILocation(line: 334, column: 16, scope: !1339)
!1349 = !DILocation(line: 332, column: 3, scope: !1339)
!1350 = !DILocation(line: 332, column: 3, scope: !1339)
!1351 = !{!157, !10}
!1352 = !DISubroutineType(types: !1351)
!1353 = distinct !DISubprogram(name: "select-range-72-90", linkageName: "topal.dispatch.topal.fn.select_2drange_2d72_2d90.101", scope: !0, file: !0, line: 336, type: !1352, scopeLine: 336, spFlags: DISPFlagDefinition, unit: !2)
!1354 = !DILocalVariable(name: "number", arg: 1, scope: !1353, file: !0, line: 336, type: !10)
!1355 = !DILocation(line: 336, column: 27, scope: !1353)
!1356 = !DILocation(line: 337, column: 3, scope: !1353)
!1357 = !DILocation(line: 337, column: 3, scope: !1353)
!1358 = !DILocation(line: 337, column: 3, scope: !1353)
!1359 = !DILocation(line: 338, column: 15, scope: !1353)
!1360 = !DILocation(line: 338, column: 15, scope: !1353)
!1361 = !DILocation(line: 339, column: 16, scope: !1353)
!1362 = !DILocation(line: 339, column: 16, scope: !1353)
!1363 = !DILocation(line: 337, column: 3, scope: !1353)
!1364 = !DILocation(line: 337, column: 3, scope: !1353)
!1365 = !{!157, !10}
!1366 = !DISubroutineType(types: !1365)
!1367 = distinct !DISubprogram(name: "select-range-33-90", linkageName: "topal.dispatch.topal.fn.select_2drange_2d33_2d90.102", scope: !0, file: !0, line: 341, type: !1366, scopeLine: 341, spFlags: DISPFlagDefinition, unit: !2)
!1368 = !DILocalVariable(name: "number", arg: 1, scope: !1367, file: !0, line: 341, type: !10)
!1369 = !DILocation(line: 341, column: 27, scope: !1367)
!1370 = !DILocation(line: 342, column: 3, scope: !1367)
!1371 = !DILocation(line: 342, column: 3, scope: !1367)
!1372 = !DILocation(line: 342, column: 3, scope: !1367)
!1373 = !DILocation(line: 343, column: 15, scope: !1367)
!1374 = !DILocation(line: 343, column: 15, scope: !1367)
!1375 = !DILocation(line: 344, column: 16, scope: !1367)
!1376 = !DILocation(line: 344, column: 16, scope: !1367)
!1377 = !DILocation(line: 342, column: 3, scope: !1367)
!1378 = !DILocation(line: 342, column: 3, scope: !1367)
!1379 = !{!157, !10}
!1380 = !DISubroutineType(types: !1379)
!1381 = distinct !DISubprogram(name: "select-range-0-90", linkageName: "topal.dispatch.topal.fn.select_2drange_2d0_2d90.103", scope: !0, file: !0, line: 346, type: !1380, scopeLine: 346, spFlags: DISPFlagDefinition, unit: !2)
!1382 = !DILocalVariable(name: "number", arg: 1, scope: !1381, file: !0, line: 346, type: !10)
!1383 = !DILocation(line: 346, column: 26, scope: !1381)
!1384 = !DILocation(line: 347, column: 3, scope: !1381)
!1385 = !DILocation(line: 347, column: 3, scope: !1381)
!1386 = !DILocation(line: 347, column: 3, scope: !1381)
!1387 = !DILocation(line: 348, column: 15, scope: !1381)
!1388 = !DILocation(line: 348, column: 15, scope: !1381)
!1389 = !DILocation(line: 349, column: 16, scope: !1381)
!1390 = !DILocation(line: 349, column: 16, scope: !1381)
!1391 = !DILocation(line: 347, column: 3, scope: !1381)
!1392 = !DILocation(line: 347, column: 3, scope: !1381)
!1393 = !{!65, !10, !10}
!1394 = !DISubroutineType(types: !1393)
!1395 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.104", scope: !73, file: !73, line: 3, type: !1394, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1396 = !DILocalVariable(name: "number", arg: 1, scope: !1395, file: !73, line: 3, type: !10)
!1397 = !DILocation(line: 3, column: 31, scope: !1395)
!1398 = !DILocalVariable(name: "expected", arg: 2, scope: !1395, file: !73, line: 3, type: !10)
!1399 = !DILocation(line: 3, column: 45, scope: !1395)
!1400 = !DILocation(line: 4, column: 3, scope: !1395)
!1401 = !DILocation(line: 4, column: 3, scope: !1395)
!1402 = !DILocation(line: 4, column: 3, scope: !1395)
!1403 = !DILocation(line: 4, column: 3, scope: !1395)
!1404 = !{!157, !10}
!1405 = !DISubroutineType(types: !1404)
!1406 = distinct !DISubprogram(name: "select-range-91-91", linkageName: "topal.dispatch.topal.fn.select_2drange_2d91_2d91.105", scope: !0, file: !0, line: 351, type: !1405, scopeLine: 351, spFlags: DISPFlagDefinition, unit: !2)
!1407 = !DILocalVariable(name: "number", arg: 1, scope: !1406, file: !0, line: 351, type: !10)
!1408 = !DILocation(line: 351, column: 27, scope: !1406)
!1409 = !DILocation(line: 352, column: 3, scope: !1406)
!1410 = !DILocation(line: 352, column: 3, scope: !1406)
!1411 = !DILocation(line: 353, column: 15, scope: !1406)
!1412 = !DILocation(line: 354, column: 16, scope: !1406)
!1413 = !DILocation(line: 352, column: 3, scope: !1406)
!1414 = !DILocation(line: 352, column: 3, scope: !1406)
!1415 = !{!65, !10, !10}
!1416 = !DISubroutineType(types: !1415)
!1417 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.106", scope: !73, file: !73, line: 3, type: !1416, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1418 = !DILocalVariable(name: "number", arg: 1, scope: !1417, file: !73, line: 3, type: !10)
!1419 = !DILocation(line: 3, column: 31, scope: !1417)
!1420 = !DILocalVariable(name: "expected", arg: 2, scope: !1417, file: !73, line: 3, type: !10)
!1421 = !DILocation(line: 3, column: 45, scope: !1417)
!1422 = !DILocation(line: 4, column: 3, scope: !1417)
!1423 = !DILocation(line: 4, column: 3, scope: !1417)
!1424 = !DILocation(line: 4, column: 3, scope: !1417)
!1425 = !DILocation(line: 4, column: 3, scope: !1417)
!1426 = !{!157, !10}
!1427 = !DISubroutineType(types: !1426)
!1428 = distinct !DISubprogram(name: "select-range-95-95", linkageName: "topal.dispatch.topal.fn.select_2drange_2d95_2d95.107", scope: !0, file: !0, line: 356, type: !1427, scopeLine: 356, spFlags: DISPFlagDefinition, unit: !2)
!1429 = !DILocalVariable(name: "number", arg: 1, scope: !1428, file: !0, line: 356, type: !10)
!1430 = !DILocation(line: 356, column: 27, scope: !1428)
!1431 = !DILocation(line: 357, column: 3, scope: !1428)
!1432 = !DILocation(line: 357, column: 3, scope: !1428)
!1433 = !DILocation(line: 358, column: 15, scope: !1428)
!1434 = !DILocation(line: 359, column: 16, scope: !1428)
!1435 = !DILocation(line: 357, column: 3, scope: !1428)
!1436 = !DILocation(line: 357, column: 3, scope: !1428)
!1437 = !{!157, !10}
!1438 = !DISubroutineType(types: !1437)
!1439 = distinct !DISubprogram(name: "select-range-91-95", linkageName: "topal.dispatch.topal.fn.select_2drange_2d91_2d95.108", scope: !0, file: !0, line: 361, type: !1438, scopeLine: 361, spFlags: DISPFlagDefinition, unit: !2)
!1440 = !DILocalVariable(name: "number", arg: 1, scope: !1439, file: !0, line: 361, type: !10)
!1441 = !DILocation(line: 361, column: 27, scope: !1439)
!1442 = !DILocation(line: 362, column: 3, scope: !1439)
!1443 = !DILocation(line: 362, column: 3, scope: !1439)
!1444 = !DILocation(line: 362, column: 3, scope: !1439)
!1445 = !DILocation(line: 363, column: 15, scope: !1439)
!1446 = !DILocation(line: 363, column: 15, scope: !1439)
!1447 = !DILocation(line: 364, column: 16, scope: !1439)
!1448 = !DILocation(line: 364, column: 16, scope: !1439)
!1449 = !DILocation(line: 362, column: 3, scope: !1439)
!1450 = !DILocation(line: 362, column: 3, scope: !1439)
!1451 = !{!65, !10, !10}
!1452 = !DISubroutineType(types: !1451)
!1453 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.109", scope: !73, file: !73, line: 3, type: !1452, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1454 = !DILocalVariable(name: "number", arg: 1, scope: !1453, file: !73, line: 3, type: !10)
!1455 = !DILocation(line: 3, column: 31, scope: !1453)
!1456 = !DILocalVariable(name: "expected", arg: 2, scope: !1453, file: !73, line: 3, type: !10)
!1457 = !DILocation(line: 3, column: 45, scope: !1453)
!1458 = !DILocation(line: 4, column: 3, scope: !1453)
!1459 = !DILocation(line: 4, column: 3, scope: !1453)
!1460 = !DILocation(line: 4, column: 3, scope: !1453)
!1461 = !DILocation(line: 4, column: 3, scope: !1453)
!1462 = !{!157, !10}
!1463 = !DISubroutineType(types: !1462)
!1464 = distinct !DISubprogram(name: "select-range-97-97", linkageName: "topal.dispatch.topal.fn.select_2drange_2d97_2d97.110", scope: !0, file: !0, line: 366, type: !1463, scopeLine: 366, spFlags: DISPFlagDefinition, unit: !2)
!1465 = !DILocalVariable(name: "number", arg: 1, scope: !1464, file: !0, line: 366, type: !10)
!1466 = !DILocation(line: 366, column: 27, scope: !1464)
!1467 = !DILocation(line: 367, column: 3, scope: !1464)
!1468 = !DILocation(line: 367, column: 3, scope: !1464)
!1469 = !DILocation(line: 368, column: 15, scope: !1464)
!1470 = !DILocation(line: 369, column: 16, scope: !1464)
!1471 = !DILocation(line: 367, column: 3, scope: !1464)
!1472 = !DILocation(line: 367, column: 3, scope: !1464)
!1473 = !{!65, !10, !10}
!1474 = !DISubroutineType(types: !1473)
!1475 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.111", scope: !73, file: !73, line: 3, type: !1474, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1476 = !DILocalVariable(name: "number", arg: 1, scope: !1475, file: !73, line: 3, type: !10)
!1477 = !DILocation(line: 3, column: 31, scope: !1475)
!1478 = !DILocalVariable(name: "expected", arg: 2, scope: !1475, file: !73, line: 3, type: !10)
!1479 = !DILocation(line: 3, column: 45, scope: !1475)
!1480 = !DILocation(line: 4, column: 3, scope: !1475)
!1481 = !DILocation(line: 4, column: 3, scope: !1475)
!1482 = !DILocation(line: 4, column: 3, scope: !1475)
!1483 = !DILocation(line: 4, column: 3, scope: !1475)
!1484 = !{!157, !10}
!1485 = !DISubroutineType(types: !1484)
!1486 = distinct !DISubprogram(name: "select-range-102-102", linkageName: "topal.dispatch.topal.fn.select_2drange_2d102_2d102.112", scope: !0, file: !0, line: 371, type: !1485, scopeLine: 371, spFlags: DISPFlagDefinition, unit: !2)
!1487 = !DILocalVariable(name: "number", arg: 1, scope: !1486, file: !0, line: 371, type: !10)
!1488 = !DILocation(line: 371, column: 29, scope: !1486)
!1489 = !DILocation(line: 372, column: 3, scope: !1486)
!1490 = !DILocation(line: 372, column: 3, scope: !1486)
!1491 = !DILocation(line: 373, column: 15, scope: !1486)
!1492 = !DILocation(line: 374, column: 16, scope: !1486)
!1493 = !DILocation(line: 372, column: 3, scope: !1486)
!1494 = !DILocation(line: 372, column: 3, scope: !1486)
!1495 = !{!157, !10}
!1496 = !DISubroutineType(types: !1495)
!1497 = distinct !DISubprogram(name: "select-range-97-102", linkageName: "topal.dispatch.topal.fn.select_2drange_2d97_2d102.113", scope: !0, file: !0, line: 376, type: !1496, scopeLine: 376, spFlags: DISPFlagDefinition, unit: !2)
!1498 = !DILocalVariable(name: "number", arg: 1, scope: !1497, file: !0, line: 376, type: !10)
!1499 = !DILocation(line: 376, column: 28, scope: !1497)
!1500 = !DILocation(line: 377, column: 3, scope: !1497)
!1501 = !DILocation(line: 377, column: 3, scope: !1497)
!1502 = !DILocation(line: 377, column: 3, scope: !1497)
!1503 = !DILocation(line: 378, column: 15, scope: !1497)
!1504 = !DILocation(line: 378, column: 15, scope: !1497)
!1505 = !DILocation(line: 379, column: 16, scope: !1497)
!1506 = !DILocation(line: 379, column: 16, scope: !1497)
!1507 = !DILocation(line: 377, column: 3, scope: !1497)
!1508 = !DILocation(line: 377, column: 3, scope: !1497)
!1509 = !{!157, !10}
!1510 = !DISubroutineType(types: !1509)
!1511 = distinct !DISubprogram(name: "select-range-91-102", linkageName: "topal.dispatch.topal.fn.select_2drange_2d91_2d102.114", scope: !0, file: !0, line: 381, type: !1510, scopeLine: 381, spFlags: DISPFlagDefinition, unit: !2)
!1512 = !DILocalVariable(name: "number", arg: 1, scope: !1511, file: !0, line: 381, type: !10)
!1513 = !DILocation(line: 381, column: 28, scope: !1511)
!1514 = !DILocation(line: 382, column: 3, scope: !1511)
!1515 = !DILocation(line: 382, column: 3, scope: !1511)
!1516 = !DILocation(line: 382, column: 3, scope: !1511)
!1517 = !DILocation(line: 383, column: 15, scope: !1511)
!1518 = !DILocation(line: 383, column: 15, scope: !1511)
!1519 = !DILocation(line: 384, column: 16, scope: !1511)
!1520 = !DILocation(line: 384, column: 16, scope: !1511)
!1521 = !DILocation(line: 382, column: 3, scope: !1511)
!1522 = !DILocation(line: 382, column: 3, scope: !1511)
!1523 = !{!65, !10, !10}
!1524 = !DISubroutineType(types: !1523)
!1525 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.115", scope: !73, file: !73, line: 3, type: !1524, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1526 = !DILocalVariable(name: "number", arg: 1, scope: !1525, file: !73, line: 3, type: !10)
!1527 = !DILocation(line: 3, column: 31, scope: !1525)
!1528 = !DILocalVariable(name: "expected", arg: 2, scope: !1525, file: !73, line: 3, type: !10)
!1529 = !DILocation(line: 3, column: 45, scope: !1525)
!1530 = !DILocation(line: 4, column: 3, scope: !1525)
!1531 = !DILocation(line: 4, column: 3, scope: !1525)
!1532 = !DILocation(line: 4, column: 3, scope: !1525)
!1533 = !DILocation(line: 4, column: 3, scope: !1525)
!1534 = !{!157, !10}
!1535 = !DISubroutineType(types: !1534)
!1536 = distinct !DISubprogram(name: "select-range-104-104", linkageName: "topal.dispatch.topal.fn.select_2drange_2d104_2d104.116", scope: !0, file: !0, line: 386, type: !1535, scopeLine: 386, spFlags: DISPFlagDefinition, unit: !2)
!1537 = !DILocalVariable(name: "number", arg: 1, scope: !1536, file: !0, line: 386, type: !10)
!1538 = !DILocation(line: 386, column: 29, scope: !1536)
!1539 = !DILocation(line: 387, column: 3, scope: !1536)
!1540 = !DILocation(line: 387, column: 3, scope: !1536)
!1541 = !DILocation(line: 388, column: 15, scope: !1536)
!1542 = !DILocation(line: 389, column: 16, scope: !1536)
!1543 = !DILocation(line: 387, column: 3, scope: !1536)
!1544 = !DILocation(line: 387, column: 3, scope: !1536)
!1545 = !{!65, !10, !10}
!1546 = !DISubroutineType(types: !1545)
!1547 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.117", scope: !73, file: !73, line: 3, type: !1546, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1548 = !DILocalVariable(name: "number", arg: 1, scope: !1547, file: !73, line: 3, type: !10)
!1549 = !DILocation(line: 3, column: 31, scope: !1547)
!1550 = !DILocalVariable(name: "expected", arg: 2, scope: !1547, file: !73, line: 3, type: !10)
!1551 = !DILocation(line: 3, column: 45, scope: !1547)
!1552 = !DILocation(line: 4, column: 3, scope: !1547)
!1553 = !DILocation(line: 4, column: 3, scope: !1547)
!1554 = !DILocation(line: 4, column: 3, scope: !1547)
!1555 = !DILocation(line: 4, column: 3, scope: !1547)
!1556 = !{!157, !10}
!1557 = !DISubroutineType(types: !1556)
!1558 = distinct !DISubprogram(name: "select-range-105-105", linkageName: "topal.dispatch.topal.fn.select_2drange_2d105_2d105.118", scope: !0, file: !0, line: 391, type: !1557, scopeLine: 391, spFlags: DISPFlagDefinition, unit: !2)
!1559 = !DILocalVariable(name: "number", arg: 1, scope: !1558, file: !0, line: 391, type: !10)
!1560 = !DILocation(line: 391, column: 29, scope: !1558)
!1561 = !DILocation(line: 392, column: 3, scope: !1558)
!1562 = !DILocation(line: 392, column: 3, scope: !1558)
!1563 = !DILocation(line: 393, column: 15, scope: !1558)
!1564 = !DILocation(line: 394, column: 16, scope: !1558)
!1565 = !DILocation(line: 392, column: 3, scope: !1558)
!1566 = !DILocation(line: 392, column: 3, scope: !1558)
!1567 = !{!157, !10}
!1568 = !DISubroutineType(types: !1567)
!1569 = distinct !DISubprogram(name: "select-range-104-105", linkageName: "topal.dispatch.topal.fn.select_2drange_2d104_2d105.119", scope: !0, file: !0, line: 396, type: !1568, scopeLine: 396, spFlags: DISPFlagDefinition, unit: !2)
!1570 = !DILocalVariable(name: "number", arg: 1, scope: !1569, file: !0, line: 396, type: !10)
!1571 = !DILocation(line: 396, column: 29, scope: !1569)
!1572 = !DILocation(line: 397, column: 3, scope: !1569)
!1573 = !DILocation(line: 397, column: 3, scope: !1569)
!1574 = !DILocation(line: 397, column: 3, scope: !1569)
!1575 = !DILocation(line: 398, column: 15, scope: !1569)
!1576 = !DILocation(line: 398, column: 15, scope: !1569)
!1577 = !DILocation(line: 399, column: 16, scope: !1569)
!1578 = !DILocation(line: 399, column: 16, scope: !1569)
!1579 = !DILocation(line: 397, column: 3, scope: !1569)
!1580 = !DILocation(line: 397, column: 3, scope: !1569)
!1581 = !{!65, !10, !10}
!1582 = !DISubroutineType(types: !1581)
!1583 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.120", scope: !73, file: !73, line: 3, type: !1582, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1584 = !DILocalVariable(name: "number", arg: 1, scope: !1583, file: !73, line: 3, type: !10)
!1585 = !DILocation(line: 3, column: 31, scope: !1583)
!1586 = !DILocalVariable(name: "expected", arg: 2, scope: !1583, file: !73, line: 3, type: !10)
!1587 = !DILocation(line: 3, column: 45, scope: !1583)
!1588 = !DILocation(line: 4, column: 3, scope: !1583)
!1589 = !DILocation(line: 4, column: 3, scope: !1583)
!1590 = !DILocation(line: 4, column: 3, scope: !1583)
!1591 = !DILocation(line: 4, column: 3, scope: !1583)
!1592 = !{!157, !10}
!1593 = !DISubroutineType(types: !1592)
!1594 = distinct !DISubprogram(name: "select-range-106-106", linkageName: "topal.dispatch.topal.fn.select_2drange_2d106_2d106.121", scope: !0, file: !0, line: 401, type: !1593, scopeLine: 401, spFlags: DISPFlagDefinition, unit: !2)
!1595 = !DILocalVariable(name: "number", arg: 1, scope: !1594, file: !0, line: 401, type: !10)
!1596 = !DILocation(line: 401, column: 29, scope: !1594)
!1597 = !DILocation(line: 402, column: 3, scope: !1594)
!1598 = !DILocation(line: 402, column: 3, scope: !1594)
!1599 = !DILocation(line: 403, column: 15, scope: !1594)
!1600 = !DILocation(line: 404, column: 16, scope: !1594)
!1601 = !DILocation(line: 402, column: 3, scope: !1594)
!1602 = !DILocation(line: 402, column: 3, scope: !1594)
!1603 = !{!65, !10, !10}
!1604 = !DISubroutineType(types: !1603)
!1605 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.122", scope: !73, file: !73, line: 3, type: !1604, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1606 = !DILocalVariable(name: "number", arg: 1, scope: !1605, file: !73, line: 3, type: !10)
!1607 = !DILocation(line: 3, column: 31, scope: !1605)
!1608 = !DILocalVariable(name: "expected", arg: 2, scope: !1605, file: !73, line: 3, type: !10)
!1609 = !DILocation(line: 3, column: 45, scope: !1605)
!1610 = !DILocation(line: 4, column: 3, scope: !1605)
!1611 = !DILocation(line: 4, column: 3, scope: !1605)
!1612 = !DILocation(line: 4, column: 3, scope: !1605)
!1613 = !DILocation(line: 4, column: 3, scope: !1605)
!1614 = !{!157, !10}
!1615 = !DISubroutineType(types: !1614)
!1616 = distinct !DISubprogram(name: "select-range-107-107", linkageName: "topal.dispatch.topal.fn.select_2drange_2d107_2d107.123", scope: !0, file: !0, line: 406, type: !1615, scopeLine: 406, spFlags: DISPFlagDefinition, unit: !2)
!1617 = !DILocalVariable(name: "number", arg: 1, scope: !1616, file: !0, line: 406, type: !10)
!1618 = !DILocation(line: 406, column: 29, scope: !1616)
!1619 = !DILocation(line: 407, column: 3, scope: !1616)
!1620 = !DILocation(line: 407, column: 3, scope: !1616)
!1621 = !DILocation(line: 408, column: 15, scope: !1616)
!1622 = !DILocation(line: 409, column: 16, scope: !1616)
!1623 = !DILocation(line: 407, column: 3, scope: !1616)
!1624 = !DILocation(line: 407, column: 3, scope: !1616)
!1625 = !{!157, !10}
!1626 = !DISubroutineType(types: !1625)
!1627 = distinct !DISubprogram(name: "select-range-106-107", linkageName: "topal.dispatch.topal.fn.select_2drange_2d106_2d107.124", scope: !0, file: !0, line: 411, type: !1626, scopeLine: 411, spFlags: DISPFlagDefinition, unit: !2)
!1628 = !DILocalVariable(name: "number", arg: 1, scope: !1627, file: !0, line: 411, type: !10)
!1629 = !DILocation(line: 411, column: 29, scope: !1627)
!1630 = !DILocation(line: 412, column: 3, scope: !1627)
!1631 = !DILocation(line: 412, column: 3, scope: !1627)
!1632 = !DILocation(line: 412, column: 3, scope: !1627)
!1633 = !DILocation(line: 413, column: 15, scope: !1627)
!1634 = !DILocation(line: 413, column: 15, scope: !1627)
!1635 = !DILocation(line: 414, column: 16, scope: !1627)
!1636 = !DILocation(line: 414, column: 16, scope: !1627)
!1637 = !DILocation(line: 412, column: 3, scope: !1627)
!1638 = !DILocation(line: 412, column: 3, scope: !1627)
!1639 = !{!157, !10}
!1640 = !DISubroutineType(types: !1639)
!1641 = distinct !DISubprogram(name: "select-range-104-107", linkageName: "topal.dispatch.topal.fn.select_2drange_2d104_2d107.125", scope: !0, file: !0, line: 416, type: !1640, scopeLine: 416, spFlags: DISPFlagDefinition, unit: !2)
!1642 = !DILocalVariable(name: "number", arg: 1, scope: !1641, file: !0, line: 416, type: !10)
!1643 = !DILocation(line: 416, column: 29, scope: !1641)
!1644 = !DILocation(line: 417, column: 3, scope: !1641)
!1645 = !DILocation(line: 417, column: 3, scope: !1641)
!1646 = !DILocation(line: 417, column: 3, scope: !1641)
!1647 = !DILocation(line: 418, column: 15, scope: !1641)
!1648 = !DILocation(line: 418, column: 15, scope: !1641)
!1649 = !DILocation(line: 419, column: 16, scope: !1641)
!1650 = !DILocation(line: 419, column: 16, scope: !1641)
!1651 = !DILocation(line: 417, column: 3, scope: !1641)
!1652 = !DILocation(line: 417, column: 3, scope: !1641)
!1653 = !{!157, !10}
!1654 = !DISubroutineType(types: !1653)
!1655 = distinct !DISubprogram(name: "select-range-91-107", linkageName: "topal.dispatch.topal.fn.select_2drange_2d91_2d107.126", scope: !0, file: !0, line: 421, type: !1654, scopeLine: 421, spFlags: DISPFlagDefinition, unit: !2)
!1656 = !DILocalVariable(name: "number", arg: 1, scope: !1655, file: !0, line: 421, type: !10)
!1657 = !DILocation(line: 421, column: 28, scope: !1655)
!1658 = !DILocation(line: 422, column: 3, scope: !1655)
!1659 = !DILocation(line: 422, column: 3, scope: !1655)
!1660 = !DILocation(line: 422, column: 3, scope: !1655)
!1661 = !DILocation(line: 423, column: 15, scope: !1655)
!1662 = !DILocation(line: 423, column: 15, scope: !1655)
!1663 = !DILocation(line: 424, column: 16, scope: !1655)
!1664 = !DILocation(line: 424, column: 16, scope: !1655)
!1665 = !DILocation(line: 422, column: 3, scope: !1655)
!1666 = !DILocation(line: 422, column: 3, scope: !1655)
!1667 = !{!65, !10, !10}
!1668 = !DISubroutineType(types: !1667)
!1669 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.127", scope: !73, file: !73, line: 3, type: !1668, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1670 = !DILocalVariable(name: "number", arg: 1, scope: !1669, file: !73, line: 3, type: !10)
!1671 = !DILocation(line: 3, column: 31, scope: !1669)
!1672 = !DILocalVariable(name: "expected", arg: 2, scope: !1669, file: !73, line: 3, type: !10)
!1673 = !DILocation(line: 3, column: 45, scope: !1669)
!1674 = !DILocation(line: 4, column: 3, scope: !1669)
!1675 = !DILocation(line: 4, column: 3, scope: !1669)
!1676 = !DILocation(line: 4, column: 3, scope: !1669)
!1677 = !DILocation(line: 4, column: 3, scope: !1669)
!1678 = !{!157, !10}
!1679 = !DISubroutineType(types: !1678)
!1680 = distinct !DISubprogram(name: "select-range-108-108", linkageName: "topal.dispatch.topal.fn.select_2drange_2d108_2d108.128", scope: !0, file: !0, line: 426, type: !1679, scopeLine: 426, spFlags: DISPFlagDefinition, unit: !2)
!1681 = !DILocalVariable(name: "number", arg: 1, scope: !1680, file: !0, line: 426, type: !10)
!1682 = !DILocation(line: 426, column: 29, scope: !1680)
!1683 = !DILocation(line: 427, column: 3, scope: !1680)
!1684 = !DILocation(line: 427, column: 3, scope: !1680)
!1685 = !DILocation(line: 428, column: 15, scope: !1680)
!1686 = !DILocation(line: 429, column: 16, scope: !1680)
!1687 = !DILocation(line: 427, column: 3, scope: !1680)
!1688 = !DILocation(line: 427, column: 3, scope: !1680)
!1689 = !{!65, !10, !10}
!1690 = !DISubroutineType(types: !1689)
!1691 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.129", scope: !73, file: !73, line: 3, type: !1690, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1692 = !DILocalVariable(name: "number", arg: 1, scope: !1691, file: !73, line: 3, type: !10)
!1693 = !DILocation(line: 3, column: 31, scope: !1691)
!1694 = !DILocalVariable(name: "expected", arg: 2, scope: !1691, file: !73, line: 3, type: !10)
!1695 = !DILocation(line: 3, column: 45, scope: !1691)
!1696 = !DILocation(line: 4, column: 3, scope: !1691)
!1697 = !DILocation(line: 4, column: 3, scope: !1691)
!1698 = !DILocation(line: 4, column: 3, scope: !1691)
!1699 = !DILocation(line: 4, column: 3, scope: !1691)
!1700 = !{!157, !10}
!1701 = !DISubroutineType(types: !1700)
!1702 = distinct !DISubprogram(name: "select-range-110-110", linkageName: "topal.dispatch.topal.fn.select_2drange_2d110_2d110.130", scope: !0, file: !0, line: 431, type: !1701, scopeLine: 431, spFlags: DISPFlagDefinition, unit: !2)
!1703 = !DILocalVariable(name: "number", arg: 1, scope: !1702, file: !0, line: 431, type: !10)
!1704 = !DILocation(line: 431, column: 29, scope: !1702)
!1705 = !DILocation(line: 432, column: 3, scope: !1702)
!1706 = !DILocation(line: 432, column: 3, scope: !1702)
!1707 = !DILocation(line: 433, column: 15, scope: !1702)
!1708 = !DILocation(line: 434, column: 16, scope: !1702)
!1709 = !DILocation(line: 432, column: 3, scope: !1702)
!1710 = !DILocation(line: 432, column: 3, scope: !1702)
!1711 = !{!157, !10}
!1712 = !DISubroutineType(types: !1711)
!1713 = distinct !DISubprogram(name: "select-range-108-110", linkageName: "topal.dispatch.topal.fn.select_2drange_2d108_2d110.131", scope: !0, file: !0, line: 436, type: !1712, scopeLine: 436, spFlags: DISPFlagDefinition, unit: !2)
!1714 = !DILocalVariable(name: "number", arg: 1, scope: !1713, file: !0, line: 436, type: !10)
!1715 = !DILocation(line: 436, column: 29, scope: !1713)
!1716 = !DILocation(line: 437, column: 3, scope: !1713)
!1717 = !DILocation(line: 437, column: 3, scope: !1713)
!1718 = !DILocation(line: 437, column: 3, scope: !1713)
!1719 = !DILocation(line: 438, column: 15, scope: !1713)
!1720 = !DILocation(line: 438, column: 15, scope: !1713)
!1721 = !DILocation(line: 439, column: 16, scope: !1713)
!1722 = !DILocation(line: 439, column: 16, scope: !1713)
!1723 = !DILocation(line: 437, column: 3, scope: !1713)
!1724 = !DILocation(line: 437, column: 3, scope: !1713)
!1725 = !{!65, !10, !10}
!1726 = !DISubroutineType(types: !1725)
!1727 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.132", scope: !73, file: !73, line: 3, type: !1726, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1728 = !DILocalVariable(name: "number", arg: 1, scope: !1727, file: !73, line: 3, type: !10)
!1729 = !DILocation(line: 3, column: 31, scope: !1727)
!1730 = !DILocalVariable(name: "expected", arg: 2, scope: !1727, file: !73, line: 3, type: !10)
!1731 = !DILocation(line: 3, column: 45, scope: !1727)
!1732 = !DILocation(line: 4, column: 3, scope: !1727)
!1733 = !DILocation(line: 4, column: 3, scope: !1727)
!1734 = !DILocation(line: 4, column: 3, scope: !1727)
!1735 = !DILocation(line: 4, column: 3, scope: !1727)
!1736 = !{!157, !10}
!1737 = !DISubroutineType(types: !1736)
!1738 = distinct !DISubprogram(name: "select-range-157-157", linkageName: "topal.dispatch.topal.fn.select_2drange_2d157_2d157.133", scope: !0, file: !0, line: 441, type: !1737, scopeLine: 441, spFlags: DISPFlagDefinition, unit: !2)
!1739 = !DILocalVariable(name: "number", arg: 1, scope: !1738, file: !0, line: 441, type: !10)
!1740 = !DILocation(line: 441, column: 29, scope: !1738)
!1741 = !DILocation(line: 442, column: 3, scope: !1738)
!1742 = !DILocation(line: 442, column: 3, scope: !1738)
!1743 = !DILocation(line: 443, column: 15, scope: !1738)
!1744 = !DILocation(line: 444, column: 16, scope: !1738)
!1745 = !DILocation(line: 442, column: 3, scope: !1738)
!1746 = !DILocation(line: 442, column: 3, scope: !1738)
!1747 = !{!65, !10, !10}
!1748 = !DISubroutineType(types: !1747)
!1749 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.134", scope: !73, file: !73, line: 3, type: !1748, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1750 = !DILocalVariable(name: "number", arg: 1, scope: !1749, file: !73, line: 3, type: !10)
!1751 = !DILocation(line: 3, column: 31, scope: !1749)
!1752 = !DILocalVariable(name: "expected", arg: 2, scope: !1749, file: !73, line: 3, type: !10)
!1753 = !DILocation(line: 3, column: 45, scope: !1749)
!1754 = !DILocation(line: 4, column: 3, scope: !1749)
!1755 = !DILocation(line: 4, column: 3, scope: !1749)
!1756 = !DILocation(line: 4, column: 3, scope: !1749)
!1757 = !DILocation(line: 4, column: 3, scope: !1749)
!1758 = !{!157, !10}
!1759 = !DISubroutineType(types: !1758)
!1760 = distinct !DISubprogram(name: "select-range-158-158", linkageName: "topal.dispatch.topal.fn.select_2drange_2d158_2d158.135", scope: !0, file: !0, line: 446, type: !1759, scopeLine: 446, spFlags: DISPFlagDefinition, unit: !2)
!1761 = !DILocalVariable(name: "number", arg: 1, scope: !1760, file: !0, line: 446, type: !10)
!1762 = !DILocation(line: 446, column: 29, scope: !1760)
!1763 = !DILocation(line: 447, column: 3, scope: !1760)
!1764 = !DILocation(line: 447, column: 3, scope: !1760)
!1765 = !DILocation(line: 448, column: 15, scope: !1760)
!1766 = !DILocation(line: 449, column: 16, scope: !1760)
!1767 = !DILocation(line: 447, column: 3, scope: !1760)
!1768 = !DILocation(line: 447, column: 3, scope: !1760)
!1769 = !{!157, !10}
!1770 = !DISubroutineType(types: !1769)
!1771 = distinct !DISubprogram(name: "select-range-157-158", linkageName: "topal.dispatch.topal.fn.select_2drange_2d157_2d158.136", scope: !0, file: !0, line: 451, type: !1770, scopeLine: 451, spFlags: DISPFlagDefinition, unit: !2)
!1772 = !DILocalVariable(name: "number", arg: 1, scope: !1771, file: !0, line: 451, type: !10)
!1773 = !DILocation(line: 451, column: 29, scope: !1771)
!1774 = !DILocation(line: 452, column: 3, scope: !1771)
!1775 = !DILocation(line: 452, column: 3, scope: !1771)
!1776 = !DILocation(line: 452, column: 3, scope: !1771)
!1777 = !DILocation(line: 453, column: 15, scope: !1771)
!1778 = !DILocation(line: 453, column: 15, scope: !1771)
!1779 = !DILocation(line: 454, column: 16, scope: !1771)
!1780 = !DILocation(line: 454, column: 16, scope: !1771)
!1781 = !DILocation(line: 452, column: 3, scope: !1771)
!1782 = !DILocation(line: 452, column: 3, scope: !1771)
!1783 = !{!157, !10}
!1784 = !DISubroutineType(types: !1783)
!1785 = distinct !DISubprogram(name: "select-range-108-158", linkageName: "topal.dispatch.topal.fn.select_2drange_2d108_2d158.137", scope: !0, file: !0, line: 456, type: !1784, scopeLine: 456, spFlags: DISPFlagDefinition, unit: !2)
!1786 = !DILocalVariable(name: "number", arg: 1, scope: !1785, file: !0, line: 456, type: !10)
!1787 = !DILocation(line: 456, column: 29, scope: !1785)
!1788 = !DILocation(line: 457, column: 3, scope: !1785)
!1789 = !DILocation(line: 457, column: 3, scope: !1785)
!1790 = !DILocation(line: 457, column: 3, scope: !1785)
!1791 = !DILocation(line: 458, column: 15, scope: !1785)
!1792 = !DILocation(line: 458, column: 15, scope: !1785)
!1793 = !DILocation(line: 459, column: 16, scope: !1785)
!1794 = !DILocation(line: 459, column: 16, scope: !1785)
!1795 = !DILocation(line: 457, column: 3, scope: !1785)
!1796 = !DILocation(line: 457, column: 3, scope: !1785)
!1797 = !{!65, !10, !10}
!1798 = !DISubroutineType(types: !1797)
!1799 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.138", scope: !73, file: !73, line: 3, type: !1798, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1800 = !DILocalVariable(name: "number", arg: 1, scope: !1799, file: !73, line: 3, type: !10)
!1801 = !DILocation(line: 3, column: 31, scope: !1799)
!1802 = !DILocalVariable(name: "expected", arg: 2, scope: !1799, file: !73, line: 3, type: !10)
!1803 = !DILocation(line: 3, column: 45, scope: !1799)
!1804 = !DILocation(line: 4, column: 3, scope: !1799)
!1805 = !DILocation(line: 4, column: 3, scope: !1799)
!1806 = !DILocation(line: 4, column: 3, scope: !1799)
!1807 = !DILocation(line: 4, column: 3, scope: !1799)
!1808 = !{!157, !10}
!1809 = !DISubroutineType(types: !1808)
!1810 = distinct !DISubprogram(name: "select-range-186-186", linkageName: "topal.dispatch.topal.fn.select_2drange_2d186_2d186.139", scope: !0, file: !0, line: 461, type: !1809, scopeLine: 461, spFlags: DISPFlagDefinition, unit: !2)
!1811 = !DILocalVariable(name: "number", arg: 1, scope: !1810, file: !0, line: 461, type: !10)
!1812 = !DILocation(line: 461, column: 29, scope: !1810)
!1813 = !DILocation(line: 462, column: 3, scope: !1810)
!1814 = !DILocation(line: 462, column: 3, scope: !1810)
!1815 = !DILocation(line: 463, column: 15, scope: !1810)
!1816 = !DILocation(line: 464, column: 16, scope: !1810)
!1817 = !DILocation(line: 462, column: 3, scope: !1810)
!1818 = !DILocation(line: 462, column: 3, scope: !1810)
!1819 = !{!65, !10, !10}
!1820 = !DISubroutineType(types: !1819)
!1821 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.140", scope: !73, file: !73, line: 3, type: !1820, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1822 = !DILocalVariable(name: "number", arg: 1, scope: !1821, file: !73, line: 3, type: !10)
!1823 = !DILocation(line: 3, column: 31, scope: !1821)
!1824 = !DILocalVariable(name: "expected", arg: 2, scope: !1821, file: !73, line: 3, type: !10)
!1825 = !DILocation(line: 3, column: 45, scope: !1821)
!1826 = !DILocation(line: 4, column: 3, scope: !1821)
!1827 = !DILocation(line: 4, column: 3, scope: !1821)
!1828 = !DILocation(line: 4, column: 3, scope: !1821)
!1829 = !DILocation(line: 4, column: 3, scope: !1821)
!1830 = !{!157, !10}
!1831 = !DISubroutineType(types: !1830)
!1832 = distinct !DISubprogram(name: "select-range-201-201", linkageName: "topal.dispatch.topal.fn.select_2drange_2d201_2d201.141", scope: !0, file: !0, line: 466, type: !1831, scopeLine: 466, spFlags: DISPFlagDefinition, unit: !2)
!1833 = !DILocalVariable(name: "number", arg: 1, scope: !1832, file: !0, line: 466, type: !10)
!1834 = !DILocation(line: 466, column: 29, scope: !1832)
!1835 = !DILocation(line: 467, column: 3, scope: !1832)
!1836 = !DILocation(line: 467, column: 3, scope: !1832)
!1837 = !DILocation(line: 468, column: 15, scope: !1832)
!1838 = !DILocation(line: 469, column: 16, scope: !1832)
!1839 = !DILocation(line: 467, column: 3, scope: !1832)
!1840 = !DILocation(line: 467, column: 3, scope: !1832)
!1841 = !{!157, !10}
!1842 = !DISubroutineType(types: !1841)
!1843 = distinct !DISubprogram(name: "select-range-186-201", linkageName: "topal.dispatch.topal.fn.select_2drange_2d186_2d201.142", scope: !0, file: !0, line: 471, type: !1842, scopeLine: 471, spFlags: DISPFlagDefinition, unit: !2)
!1844 = !DILocalVariable(name: "number", arg: 1, scope: !1843, file: !0, line: 471, type: !10)
!1845 = !DILocation(line: 471, column: 29, scope: !1843)
!1846 = !DILocation(line: 472, column: 3, scope: !1843)
!1847 = !DILocation(line: 472, column: 3, scope: !1843)
!1848 = !DILocation(line: 472, column: 3, scope: !1843)
!1849 = !DILocation(line: 473, column: 15, scope: !1843)
!1850 = !DILocation(line: 473, column: 15, scope: !1843)
!1851 = !DILocation(line: 474, column: 16, scope: !1843)
!1852 = !DILocation(line: 474, column: 16, scope: !1843)
!1853 = !DILocation(line: 472, column: 3, scope: !1843)
!1854 = !DILocation(line: 472, column: 3, scope: !1843)
!1855 = !{!65, !10, !10}
!1856 = !DISubroutineType(types: !1855)
!1857 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.143", scope: !73, file: !73, line: 3, type: !1856, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1858 = !DILocalVariable(name: "number", arg: 1, scope: !1857, file: !73, line: 3, type: !10)
!1859 = !DILocation(line: 3, column: 31, scope: !1857)
!1860 = !DILocalVariable(name: "expected", arg: 2, scope: !1857, file: !73, line: 3, type: !10)
!1861 = !DILocation(line: 3, column: 45, scope: !1857)
!1862 = !DILocation(line: 4, column: 3, scope: !1857)
!1863 = !DILocation(line: 4, column: 3, scope: !1857)
!1864 = !DILocation(line: 4, column: 3, scope: !1857)
!1865 = !DILocation(line: 4, column: 3, scope: !1857)
!1866 = !{!157, !10}
!1867 = !DISubroutineType(types: !1866)
!1868 = distinct !DISubprogram(name: "select-range-217-217", linkageName: "topal.dispatch.topal.fn.select_2drange_2d217_2d217.144", scope: !0, file: !0, line: 476, type: !1867, scopeLine: 476, spFlags: DISPFlagDefinition, unit: !2)
!1869 = !DILocalVariable(name: "number", arg: 1, scope: !1868, file: !0, line: 476, type: !10)
!1870 = !DILocation(line: 476, column: 29, scope: !1868)
!1871 = !DILocation(line: 477, column: 3, scope: !1868)
!1872 = !DILocation(line: 477, column: 3, scope: !1868)
!1873 = !DILocation(line: 478, column: 15, scope: !1868)
!1874 = !DILocation(line: 479, column: 16, scope: !1868)
!1875 = !DILocation(line: 477, column: 3, scope: !1868)
!1876 = !DILocation(line: 477, column: 3, scope: !1868)
!1877 = !{!65, !10, !10}
!1878 = !DISubroutineType(types: !1877)
!1879 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.145", scope: !73, file: !73, line: 3, type: !1878, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1880 = !DILocalVariable(name: "number", arg: 1, scope: !1879, file: !73, line: 3, type: !10)
!1881 = !DILocation(line: 3, column: 31, scope: !1879)
!1882 = !DILocalVariable(name: "expected", arg: 2, scope: !1879, file: !73, line: 3, type: !10)
!1883 = !DILocation(line: 3, column: 45, scope: !1879)
!1884 = !DILocation(line: 4, column: 3, scope: !1879)
!1885 = !DILocation(line: 4, column: 3, scope: !1879)
!1886 = !DILocation(line: 4, column: 3, scope: !1879)
!1887 = !DILocation(line: 4, column: 3, scope: !1879)
!1888 = !{!157, !10}
!1889 = !DISubroutineType(types: !1888)
!1890 = distinct !DISubprogram(name: "select-range-218-218", linkageName: "topal.dispatch.topal.fn.select_2drange_2d218_2d218.146", scope: !0, file: !0, line: 481, type: !1889, scopeLine: 481, spFlags: DISPFlagDefinition, unit: !2)
!1891 = !DILocalVariable(name: "number", arg: 1, scope: !1890, file: !0, line: 481, type: !10)
!1892 = !DILocation(line: 481, column: 29, scope: !1890)
!1893 = !DILocation(line: 482, column: 3, scope: !1890)
!1894 = !DILocation(line: 482, column: 3, scope: !1890)
!1895 = !DILocation(line: 483, column: 15, scope: !1890)
!1896 = !DILocation(line: 484, column: 16, scope: !1890)
!1897 = !DILocation(line: 482, column: 3, scope: !1890)
!1898 = !DILocation(line: 482, column: 3, scope: !1890)
!1899 = !{!65, !10, !10}
!1900 = !DISubroutineType(types: !1899)
!1901 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.147", scope: !73, file: !73, line: 3, type: !1900, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1902 = !DILocalVariable(name: "number", arg: 1, scope: !1901, file: !73, line: 3, type: !10)
!1903 = !DILocation(line: 3, column: 31, scope: !1901)
!1904 = !DILocalVariable(name: "expected", arg: 2, scope: !1901, file: !73, line: 3, type: !10)
!1905 = !DILocation(line: 3, column: 45, scope: !1901)
!1906 = !DILocation(line: 4, column: 3, scope: !1901)
!1907 = !DILocation(line: 4, column: 3, scope: !1901)
!1908 = !DILocation(line: 4, column: 3, scope: !1901)
!1909 = !DILocation(line: 4, column: 3, scope: !1901)
!1910 = !{!157, !10}
!1911 = !DISubroutineType(types: !1910)
!1912 = distinct !DISubprogram(name: "select-range-228-228", linkageName: "topal.dispatch.topal.fn.select_2drange_2d228_2d228.148", scope: !0, file: !0, line: 486, type: !1911, scopeLine: 486, spFlags: DISPFlagDefinition, unit: !2)
!1913 = !DILocalVariable(name: "number", arg: 1, scope: !1912, file: !0, line: 486, type: !10)
!1914 = !DILocation(line: 486, column: 29, scope: !1912)
!1915 = !DILocation(line: 487, column: 3, scope: !1912)
!1916 = !DILocation(line: 487, column: 3, scope: !1912)
!1917 = !DILocation(line: 488, column: 15, scope: !1912)
!1918 = !DILocation(line: 489, column: 16, scope: !1912)
!1919 = !DILocation(line: 487, column: 3, scope: !1912)
!1920 = !DILocation(line: 487, column: 3, scope: !1912)
!1921 = !{!157, !10}
!1922 = !DISubroutineType(types: !1921)
!1923 = distinct !DISubprogram(name: "select-range-218-228", linkageName: "topal.dispatch.topal.fn.select_2drange_2d218_2d228.149", scope: !0, file: !0, line: 491, type: !1922, scopeLine: 491, spFlags: DISPFlagDefinition, unit: !2)
!1924 = !DILocalVariable(name: "number", arg: 1, scope: !1923, file: !0, line: 491, type: !10)
!1925 = !DILocation(line: 491, column: 29, scope: !1923)
!1926 = !DILocation(line: 492, column: 3, scope: !1923)
!1927 = !DILocation(line: 492, column: 3, scope: !1923)
!1928 = !DILocation(line: 492, column: 3, scope: !1923)
!1929 = !DILocation(line: 493, column: 15, scope: !1923)
!1930 = !DILocation(line: 493, column: 15, scope: !1923)
!1931 = !DILocation(line: 494, column: 16, scope: !1923)
!1932 = !DILocation(line: 494, column: 16, scope: !1923)
!1933 = !DILocation(line: 492, column: 3, scope: !1923)
!1934 = !DILocation(line: 492, column: 3, scope: !1923)
!1935 = !{!157, !10}
!1936 = !DISubroutineType(types: !1935)
!1937 = distinct !DISubprogram(name: "select-range-217-228", linkageName: "topal.dispatch.topal.fn.select_2drange_2d217_2d228.150", scope: !0, file: !0, line: 496, type: !1936, scopeLine: 496, spFlags: DISPFlagDefinition, unit: !2)
!1938 = !DILocalVariable(name: "number", arg: 1, scope: !1937, file: !0, line: 496, type: !10)
!1939 = !DILocation(line: 496, column: 29, scope: !1937)
!1940 = !DILocation(line: 497, column: 3, scope: !1937)
!1941 = !DILocation(line: 497, column: 3, scope: !1937)
!1942 = !DILocation(line: 497, column: 3, scope: !1937)
!1943 = !DILocation(line: 498, column: 15, scope: !1937)
!1944 = !DILocation(line: 498, column: 15, scope: !1937)
!1945 = !DILocation(line: 499, column: 16, scope: !1937)
!1946 = !DILocation(line: 499, column: 16, scope: !1937)
!1947 = !DILocation(line: 497, column: 3, scope: !1937)
!1948 = !DILocation(line: 497, column: 3, scope: !1937)
!1949 = !{!157, !10}
!1950 = !DISubroutineType(types: !1949)
!1951 = distinct !DISubprogram(name: "select-range-186-228", linkageName: "topal.dispatch.topal.fn.select_2drange_2d186_2d228.151", scope: !0, file: !0, line: 501, type: !1950, scopeLine: 501, spFlags: DISPFlagDefinition, unit: !2)
!1952 = !DILocalVariable(name: "number", arg: 1, scope: !1951, file: !0, line: 501, type: !10)
!1953 = !DILocation(line: 501, column: 29, scope: !1951)
!1954 = !DILocation(line: 502, column: 3, scope: !1951)
!1955 = !DILocation(line: 502, column: 3, scope: !1951)
!1956 = !DILocation(line: 502, column: 3, scope: !1951)
!1957 = !DILocation(line: 503, column: 15, scope: !1951)
!1958 = !DILocation(line: 503, column: 15, scope: !1951)
!1959 = !DILocation(line: 504, column: 16, scope: !1951)
!1960 = !DILocation(line: 504, column: 16, scope: !1951)
!1961 = !DILocation(line: 502, column: 3, scope: !1951)
!1962 = !DILocation(line: 502, column: 3, scope: !1951)
!1963 = !{!157, !10}
!1964 = !DISubroutineType(types: !1963)
!1965 = distinct !DISubprogram(name: "select-range-108-228", linkageName: "topal.dispatch.topal.fn.select_2drange_2d108_2d228.152", scope: !0, file: !0, line: 506, type: !1964, scopeLine: 506, spFlags: DISPFlagDefinition, unit: !2)
!1966 = !DILocalVariable(name: "number", arg: 1, scope: !1965, file: !0, line: 506, type: !10)
!1967 = !DILocation(line: 506, column: 29, scope: !1965)
!1968 = !DILocation(line: 507, column: 3, scope: !1965)
!1969 = !DILocation(line: 507, column: 3, scope: !1965)
!1970 = !DILocation(line: 507, column: 3, scope: !1965)
!1971 = !DILocation(line: 508, column: 15, scope: !1965)
!1972 = !DILocation(line: 508, column: 15, scope: !1965)
!1973 = !DILocation(line: 509, column: 16, scope: !1965)
!1974 = !DILocation(line: 509, column: 16, scope: !1965)
!1975 = !DILocation(line: 507, column: 3, scope: !1965)
!1976 = !DILocation(line: 507, column: 3, scope: !1965)
!1977 = !{!157, !10}
!1978 = !DISubroutineType(types: !1977)
!1979 = distinct !DISubprogram(name: "select-range-91-228", linkageName: "topal.dispatch.topal.fn.select_2drange_2d91_2d228.153", scope: !0, file: !0, line: 511, type: !1978, scopeLine: 511, spFlags: DISPFlagDefinition, unit: !2)
!1980 = !DILocalVariable(name: "number", arg: 1, scope: !1979, file: !0, line: 511, type: !10)
!1981 = !DILocation(line: 511, column: 28, scope: !1979)
!1982 = !DILocation(line: 512, column: 3, scope: !1979)
!1983 = !DILocation(line: 512, column: 3, scope: !1979)
!1984 = !DILocation(line: 512, column: 3, scope: !1979)
!1985 = !DILocation(line: 513, column: 15, scope: !1979)
!1986 = !DILocation(line: 513, column: 15, scope: !1979)
!1987 = !DILocation(line: 514, column: 16, scope: !1979)
!1988 = !DILocation(line: 514, column: 16, scope: !1979)
!1989 = !DILocation(line: 512, column: 3, scope: !1979)
!1990 = !DILocation(line: 512, column: 3, scope: !1979)
!1991 = !{!65, !10, !10}
!1992 = !DISubroutineType(types: !1991)
!1993 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.154", scope: !73, file: !73, line: 3, type: !1992, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!1994 = !DILocalVariable(name: "number", arg: 1, scope: !1993, file: !73, line: 3, type: !10)
!1995 = !DILocation(line: 3, column: 31, scope: !1993)
!1996 = !DILocalVariable(name: "expected", arg: 2, scope: !1993, file: !73, line: 3, type: !10)
!1997 = !DILocation(line: 3, column: 45, scope: !1993)
!1998 = !DILocation(line: 4, column: 3, scope: !1993)
!1999 = !DILocation(line: 4, column: 3, scope: !1993)
!2000 = !DILocation(line: 4, column: 3, scope: !1993)
!2001 = !DILocation(line: 4, column: 3, scope: !1993)
!2002 = !{!157, !10}
!2003 = !DISubroutineType(types: !2002)
!2004 = distinct !DISubprogram(name: "select-range-229-229", linkageName: "topal.dispatch.topal.fn.select_2drange_2d229_2d229.155", scope: !0, file: !0, line: 516, type: !2003, scopeLine: 516, spFlags: DISPFlagDefinition, unit: !2)
!2005 = !DILocalVariable(name: "number", arg: 1, scope: !2004, file: !0, line: 516, type: !10)
!2006 = !DILocation(line: 516, column: 29, scope: !2004)
!2007 = !DILocation(line: 517, column: 3, scope: !2004)
!2008 = !DILocation(line: 517, column: 3, scope: !2004)
!2009 = !DILocation(line: 518, column: 15, scope: !2004)
!2010 = !DILocation(line: 519, column: 16, scope: !2004)
!2011 = !DILocation(line: 517, column: 3, scope: !2004)
!2012 = !DILocation(line: 517, column: 3, scope: !2004)
!2013 = !{!65, !10, !10}
!2014 = !DISubroutineType(types: !2013)
!2015 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.156", scope: !73, file: !73, line: 3, type: !2014, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2016 = !DILocalVariable(name: "number", arg: 1, scope: !2015, file: !73, line: 3, type: !10)
!2017 = !DILocation(line: 3, column: 31, scope: !2015)
!2018 = !DILocalVariable(name: "expected", arg: 2, scope: !2015, file: !73, line: 3, type: !10)
!2019 = !DILocation(line: 3, column: 45, scope: !2015)
!2020 = !DILocation(line: 4, column: 3, scope: !2015)
!2021 = !DILocation(line: 4, column: 3, scope: !2015)
!2022 = !DILocation(line: 4, column: 3, scope: !2015)
!2023 = !DILocation(line: 4, column: 3, scope: !2015)
!2024 = !{!157, !10}
!2025 = !DISubroutineType(types: !2024)
!2026 = distinct !DISubprogram(name: "select-range-230-230", linkageName: "topal.dispatch.topal.fn.select_2drange_2d230_2d230.157", scope: !0, file: !0, line: 521, type: !2025, scopeLine: 521, spFlags: DISPFlagDefinition, unit: !2)
!2027 = !DILocalVariable(name: "number", arg: 1, scope: !2026, file: !0, line: 521, type: !10)
!2028 = !DILocation(line: 521, column: 29, scope: !2026)
!2029 = !DILocation(line: 522, column: 3, scope: !2026)
!2030 = !DILocation(line: 522, column: 3, scope: !2026)
!2031 = !DILocation(line: 523, column: 15, scope: !2026)
!2032 = !DILocation(line: 524, column: 16, scope: !2026)
!2033 = !DILocation(line: 522, column: 3, scope: !2026)
!2034 = !DILocation(line: 522, column: 3, scope: !2026)
!2035 = !{!157, !10}
!2036 = !DISubroutineType(types: !2035)
!2037 = distinct !DISubprogram(name: "select-range-229-230", linkageName: "topal.dispatch.topal.fn.select_2drange_2d229_2d230.158", scope: !0, file: !0, line: 526, type: !2036, scopeLine: 526, spFlags: DISPFlagDefinition, unit: !2)
!2038 = !DILocalVariable(name: "number", arg: 1, scope: !2037, file: !0, line: 526, type: !10)
!2039 = !DILocation(line: 526, column: 29, scope: !2037)
!2040 = !DILocation(line: 527, column: 3, scope: !2037)
!2041 = !DILocation(line: 527, column: 3, scope: !2037)
!2042 = !DILocation(line: 527, column: 3, scope: !2037)
!2043 = !DILocation(line: 528, column: 15, scope: !2037)
!2044 = !DILocation(line: 528, column: 15, scope: !2037)
!2045 = !DILocation(line: 529, column: 16, scope: !2037)
!2046 = !DILocation(line: 529, column: 16, scope: !2037)
!2047 = !DILocation(line: 527, column: 3, scope: !2037)
!2048 = !DILocation(line: 527, column: 3, scope: !2037)
!2049 = !{!65, !10, !10}
!2050 = !DISubroutineType(types: !2049)
!2051 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.159", scope: !73, file: !73, line: 3, type: !2050, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2052 = !DILocalVariable(name: "number", arg: 1, scope: !2051, file: !73, line: 3, type: !10)
!2053 = !DILocation(line: 3, column: 31, scope: !2051)
!2054 = !DILocalVariable(name: "expected", arg: 2, scope: !2051, file: !73, line: 3, type: !10)
!2055 = !DILocation(line: 3, column: 45, scope: !2051)
!2056 = !DILocation(line: 4, column: 3, scope: !2051)
!2057 = !DILocation(line: 4, column: 3, scope: !2051)
!2058 = !DILocation(line: 4, column: 3, scope: !2051)
!2059 = !DILocation(line: 4, column: 3, scope: !2051)
!2060 = !{!157, !10}
!2061 = !DISubroutineType(types: !2060)
!2062 = distinct !DISubprogram(name: "select-range-231-231", linkageName: "topal.dispatch.topal.fn.select_2drange_2d231_2d231.160", scope: !0, file: !0, line: 531, type: !2061, scopeLine: 531, spFlags: DISPFlagDefinition, unit: !2)
!2063 = !DILocalVariable(name: "number", arg: 1, scope: !2062, file: !0, line: 531, type: !10)
!2064 = !DILocation(line: 531, column: 29, scope: !2062)
!2065 = !DILocation(line: 532, column: 3, scope: !2062)
!2066 = !DILocation(line: 532, column: 3, scope: !2062)
!2067 = !DILocation(line: 533, column: 15, scope: !2062)
!2068 = !DILocation(line: 534, column: 16, scope: !2062)
!2069 = !DILocation(line: 532, column: 3, scope: !2062)
!2070 = !DILocation(line: 532, column: 3, scope: !2062)
!2071 = !{!65, !10, !10}
!2072 = !DISubroutineType(types: !2071)
!2073 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.161", scope: !73, file: !73, line: 3, type: !2072, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2074 = !DILocalVariable(name: "number", arg: 1, scope: !2073, file: !73, line: 3, type: !10)
!2075 = !DILocation(line: 3, column: 31, scope: !2073)
!2076 = !DILocalVariable(name: "expected", arg: 2, scope: !2073, file: !73, line: 3, type: !10)
!2077 = !DILocation(line: 3, column: 45, scope: !2073)
!2078 = !DILocation(line: 4, column: 3, scope: !2073)
!2079 = !DILocation(line: 4, column: 3, scope: !2073)
!2080 = !DILocation(line: 4, column: 3, scope: !2073)
!2081 = !DILocation(line: 4, column: 3, scope: !2073)
!2082 = !{!157, !10}
!2083 = !DISubroutineType(types: !2082)
!2084 = distinct !DISubprogram(name: "select-range-257-257", linkageName: "topal.dispatch.topal.fn.select_2drange_2d257_2d257.162", scope: !0, file: !0, line: 536, type: !2083, scopeLine: 536, spFlags: DISPFlagDefinition, unit: !2)
!2085 = !DILocalVariable(name: "number", arg: 1, scope: !2084, file: !0, line: 536, type: !10)
!2086 = !DILocation(line: 536, column: 29, scope: !2084)
!2087 = !DILocation(line: 537, column: 3, scope: !2084)
!2088 = !DILocation(line: 537, column: 3, scope: !2084)
!2089 = !DILocation(line: 538, column: 15, scope: !2084)
!2090 = !DILocation(line: 539, column: 16, scope: !2084)
!2091 = !DILocation(line: 537, column: 3, scope: !2084)
!2092 = !DILocation(line: 537, column: 3, scope: !2084)
!2093 = !{!157, !10}
!2094 = !DISubroutineType(types: !2093)
!2095 = distinct !DISubprogram(name: "select-range-231-257", linkageName: "topal.dispatch.topal.fn.select_2drange_2d231_2d257.163", scope: !0, file: !0, line: 541, type: !2094, scopeLine: 541, spFlags: DISPFlagDefinition, unit: !2)
!2096 = !DILocalVariable(name: "number", arg: 1, scope: !2095, file: !0, line: 541, type: !10)
!2097 = !DILocation(line: 541, column: 29, scope: !2095)
!2098 = !DILocation(line: 542, column: 3, scope: !2095)
!2099 = !DILocation(line: 542, column: 3, scope: !2095)
!2100 = !DILocation(line: 542, column: 3, scope: !2095)
!2101 = !DILocation(line: 543, column: 15, scope: !2095)
!2102 = !DILocation(line: 543, column: 15, scope: !2095)
!2103 = !DILocation(line: 544, column: 16, scope: !2095)
!2104 = !DILocation(line: 544, column: 16, scope: !2095)
!2105 = !DILocation(line: 542, column: 3, scope: !2095)
!2106 = !DILocation(line: 542, column: 3, scope: !2095)
!2107 = !{!157, !10}
!2108 = !DISubroutineType(types: !2107)
!2109 = distinct !DISubprogram(name: "select-range-229-257", linkageName: "topal.dispatch.topal.fn.select_2drange_2d229_2d257.164", scope: !0, file: !0, line: 546, type: !2108, scopeLine: 546, spFlags: DISPFlagDefinition, unit: !2)
!2110 = !DILocalVariable(name: "number", arg: 1, scope: !2109, file: !0, line: 546, type: !10)
!2111 = !DILocation(line: 546, column: 29, scope: !2109)
!2112 = !DILocation(line: 547, column: 3, scope: !2109)
!2113 = !DILocation(line: 547, column: 3, scope: !2109)
!2114 = !DILocation(line: 547, column: 3, scope: !2109)
!2115 = !DILocation(line: 548, column: 15, scope: !2109)
!2116 = !DILocation(line: 548, column: 15, scope: !2109)
!2117 = !DILocation(line: 549, column: 16, scope: !2109)
!2118 = !DILocation(line: 549, column: 16, scope: !2109)
!2119 = !DILocation(line: 547, column: 3, scope: !2109)
!2120 = !DILocation(line: 547, column: 3, scope: !2109)
!2121 = !{!65, !10, !10}
!2122 = !DISubroutineType(types: !2121)
!2123 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.165", scope: !73, file: !73, line: 3, type: !2122, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2124 = !DILocalVariable(name: "number", arg: 1, scope: !2123, file: !73, line: 3, type: !10)
!2125 = !DILocation(line: 3, column: 31, scope: !2123)
!2126 = !DILocalVariable(name: "expected", arg: 2, scope: !2123, file: !73, line: 3, type: !10)
!2127 = !DILocation(line: 3, column: 45, scope: !2123)
!2128 = !DILocation(line: 4, column: 3, scope: !2123)
!2129 = !DILocation(line: 4, column: 3, scope: !2123)
!2130 = !DILocation(line: 4, column: 3, scope: !2123)
!2131 = !DILocation(line: 4, column: 3, scope: !2123)
!2132 = !{!157, !10}
!2133 = !DISubroutineType(types: !2132)
!2134 = distinct !DISubprogram(name: "select-range-262-262", linkageName: "topal.dispatch.topal.fn.select_2drange_2d262_2d262.166", scope: !0, file: !0, line: 551, type: !2133, scopeLine: 551, spFlags: DISPFlagDefinition, unit: !2)
!2135 = !DILocalVariable(name: "number", arg: 1, scope: !2134, file: !0, line: 551, type: !10)
!2136 = !DILocation(line: 551, column: 29, scope: !2134)
!2137 = !DILocation(line: 552, column: 3, scope: !2134)
!2138 = !DILocation(line: 552, column: 3, scope: !2134)
!2139 = !DILocation(line: 553, column: 15, scope: !2134)
!2140 = !DILocation(line: 554, column: 16, scope: !2134)
!2141 = !DILocation(line: 552, column: 3, scope: !2134)
!2142 = !DILocation(line: 552, column: 3, scope: !2134)
!2143 = !{!65, !10, !10}
!2144 = !DISubroutineType(types: !2143)
!2145 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.167", scope: !73, file: !73, line: 3, type: !2144, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2146 = !DILocalVariable(name: "number", arg: 1, scope: !2145, file: !73, line: 3, type: !10)
!2147 = !DILocation(line: 3, column: 31, scope: !2145)
!2148 = !DILocalVariable(name: "expected", arg: 2, scope: !2145, file: !73, line: 3, type: !10)
!2149 = !DILocation(line: 3, column: 45, scope: !2145)
!2150 = !DILocation(line: 4, column: 3, scope: !2145)
!2151 = !DILocation(line: 4, column: 3, scope: !2145)
!2152 = !DILocation(line: 4, column: 3, scope: !2145)
!2153 = !DILocation(line: 4, column: 3, scope: !2145)
!2154 = !{!157, !10}
!2155 = !DISubroutineType(types: !2154)
!2156 = distinct !DISubprogram(name: "select-range-263-263", linkageName: "topal.dispatch.topal.fn.select_2drange_2d263_2d263.168", scope: !0, file: !0, line: 556, type: !2155, scopeLine: 556, spFlags: DISPFlagDefinition, unit: !2)
!2157 = !DILocalVariable(name: "number", arg: 1, scope: !2156, file: !0, line: 556, type: !10)
!2158 = !DILocation(line: 556, column: 29, scope: !2156)
!2159 = !DILocation(line: 557, column: 3, scope: !2156)
!2160 = !DILocation(line: 557, column: 3, scope: !2156)
!2161 = !DILocation(line: 558, column: 15, scope: !2156)
!2162 = !DILocation(line: 559, column: 16, scope: !2156)
!2163 = !DILocation(line: 557, column: 3, scope: !2156)
!2164 = !DILocation(line: 557, column: 3, scope: !2156)
!2165 = !{!157, !10}
!2166 = !DISubroutineType(types: !2165)
!2167 = distinct !DISubprogram(name: "select-range-262-263", linkageName: "topal.dispatch.topal.fn.select_2drange_2d262_2d263.169", scope: !0, file: !0, line: 561, type: !2166, scopeLine: 561, spFlags: DISPFlagDefinition, unit: !2)
!2168 = !DILocalVariable(name: "number", arg: 1, scope: !2167, file: !0, line: 561, type: !10)
!2169 = !DILocation(line: 561, column: 29, scope: !2167)
!2170 = !DILocation(line: 562, column: 3, scope: !2167)
!2171 = !DILocation(line: 562, column: 3, scope: !2167)
!2172 = !DILocation(line: 562, column: 3, scope: !2167)
!2173 = !DILocation(line: 563, column: 15, scope: !2167)
!2174 = !DILocation(line: 563, column: 15, scope: !2167)
!2175 = !DILocation(line: 564, column: 16, scope: !2167)
!2176 = !DILocation(line: 564, column: 16, scope: !2167)
!2177 = !DILocation(line: 562, column: 3, scope: !2167)
!2178 = !DILocation(line: 562, column: 3, scope: !2167)
!2179 = !{!65, !10, !10}
!2180 = !DISubroutineType(types: !2179)
!2181 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.170", scope: !73, file: !73, line: 3, type: !2180, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2182 = !DILocalVariable(name: "number", arg: 1, scope: !2181, file: !73, line: 3, type: !10)
!2183 = !DILocation(line: 3, column: 31, scope: !2181)
!2184 = !DILocalVariable(name: "expected", arg: 2, scope: !2181, file: !73, line: 3, type: !10)
!2185 = !DILocation(line: 3, column: 45, scope: !2181)
!2186 = !DILocation(line: 4, column: 3, scope: !2181)
!2187 = !DILocation(line: 4, column: 3, scope: !2181)
!2188 = !DILocation(line: 4, column: 3, scope: !2181)
!2189 = !DILocation(line: 4, column: 3, scope: !2181)
!2190 = !{!157, !10}
!2191 = !DISubroutineType(types: !2190)
!2192 = distinct !DISubprogram(name: "select-range-264-264", linkageName: "topal.dispatch.topal.fn.select_2drange_2d264_2d264.171", scope: !0, file: !0, line: 566, type: !2191, scopeLine: 566, spFlags: DISPFlagDefinition, unit: !2)
!2193 = !DILocalVariable(name: "number", arg: 1, scope: !2192, file: !0, line: 566, type: !10)
!2194 = !DILocation(line: 566, column: 29, scope: !2192)
!2195 = !DILocation(line: 567, column: 3, scope: !2192)
!2196 = !DILocation(line: 567, column: 3, scope: !2192)
!2197 = !DILocation(line: 568, column: 15, scope: !2192)
!2198 = !DILocation(line: 569, column: 16, scope: !2192)
!2199 = !DILocation(line: 567, column: 3, scope: !2192)
!2200 = !DILocation(line: 567, column: 3, scope: !2192)
!2201 = !{!65, !10, !10}
!2202 = !DISubroutineType(types: !2201)
!2203 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.172", scope: !73, file: !73, line: 3, type: !2202, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2204 = !DILocalVariable(name: "number", arg: 1, scope: !2203, file: !73, line: 3, type: !10)
!2205 = !DILocation(line: 3, column: 31, scope: !2203)
!2206 = !DILocalVariable(name: "expected", arg: 2, scope: !2203, file: !73, line: 3, type: !10)
!2207 = !DILocation(line: 3, column: 45, scope: !2203)
!2208 = !DILocation(line: 4, column: 3, scope: !2203)
!2209 = !DILocation(line: 4, column: 3, scope: !2203)
!2210 = !DILocation(line: 4, column: 3, scope: !2203)
!2211 = !DILocation(line: 4, column: 3, scope: !2203)
!2212 = !{!157, !10}
!2213 = !DISubroutineType(types: !2212)
!2214 = distinct !DISubprogram(name: "select-range-265-265", linkageName: "topal.dispatch.topal.fn.select_2drange_2d265_2d265.173", scope: !0, file: !0, line: 571, type: !2213, scopeLine: 571, spFlags: DISPFlagDefinition, unit: !2)
!2215 = !DILocalVariable(name: "number", arg: 1, scope: !2214, file: !0, line: 571, type: !10)
!2216 = !DILocation(line: 571, column: 29, scope: !2214)
!2217 = !DILocation(line: 572, column: 3, scope: !2214)
!2218 = !DILocation(line: 572, column: 3, scope: !2214)
!2219 = !DILocation(line: 573, column: 15, scope: !2214)
!2220 = !DILocation(line: 574, column: 16, scope: !2214)
!2221 = !DILocation(line: 572, column: 3, scope: !2214)
!2222 = !DILocation(line: 572, column: 3, scope: !2214)
!2223 = !{!65, !10, !10}
!2224 = !DISubroutineType(types: !2223)
!2225 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.174", scope: !73, file: !73, line: 3, type: !2224, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2226 = !DILocalVariable(name: "number", arg: 1, scope: !2225, file: !73, line: 3, type: !10)
!2227 = !DILocation(line: 3, column: 31, scope: !2225)
!2228 = !DILocalVariable(name: "expected", arg: 2, scope: !2225, file: !73, line: 3, type: !10)
!2229 = !DILocation(line: 3, column: 45, scope: !2225)
!2230 = !DILocation(line: 4, column: 3, scope: !2225)
!2231 = !DILocation(line: 4, column: 3, scope: !2225)
!2232 = !DILocation(line: 4, column: 3, scope: !2225)
!2233 = !DILocation(line: 4, column: 3, scope: !2225)
!2234 = !{!157, !10}
!2235 = !DISubroutineType(types: !2234)
!2236 = distinct !DISubprogram(name: "select-range-267-267", linkageName: "topal.dispatch.topal.fn.select_2drange_2d267_2d267.175", scope: !0, file: !0, line: 576, type: !2235, scopeLine: 576, spFlags: DISPFlagDefinition, unit: !2)
!2237 = !DILocalVariable(name: "number", arg: 1, scope: !2236, file: !0, line: 576, type: !10)
!2238 = !DILocation(line: 576, column: 29, scope: !2236)
!2239 = !DILocation(line: 577, column: 3, scope: !2236)
!2240 = !DILocation(line: 577, column: 3, scope: !2236)
!2241 = !DILocation(line: 578, column: 15, scope: !2236)
!2242 = !DILocation(line: 579, column: 16, scope: !2236)
!2243 = !DILocation(line: 577, column: 3, scope: !2236)
!2244 = !DILocation(line: 577, column: 3, scope: !2236)
!2245 = !{!157, !10}
!2246 = !DISubroutineType(types: !2245)
!2247 = distinct !DISubprogram(name: "select-range-265-267", linkageName: "topal.dispatch.topal.fn.select_2drange_2d265_2d267.176", scope: !0, file: !0, line: 581, type: !2246, scopeLine: 581, spFlags: DISPFlagDefinition, unit: !2)
!2248 = !DILocalVariable(name: "number", arg: 1, scope: !2247, file: !0, line: 581, type: !10)
!2249 = !DILocation(line: 581, column: 29, scope: !2247)
!2250 = !DILocation(line: 582, column: 3, scope: !2247)
!2251 = !DILocation(line: 582, column: 3, scope: !2247)
!2252 = !DILocation(line: 582, column: 3, scope: !2247)
!2253 = !DILocation(line: 583, column: 15, scope: !2247)
!2254 = !DILocation(line: 583, column: 15, scope: !2247)
!2255 = !DILocation(line: 584, column: 16, scope: !2247)
!2256 = !DILocation(line: 584, column: 16, scope: !2247)
!2257 = !DILocation(line: 582, column: 3, scope: !2247)
!2258 = !DILocation(line: 582, column: 3, scope: !2247)
!2259 = !{!157, !10}
!2260 = !DISubroutineType(types: !2259)
!2261 = distinct !DISubprogram(name: "select-range-264-267", linkageName: "topal.dispatch.topal.fn.select_2drange_2d264_2d267.177", scope: !0, file: !0, line: 586, type: !2260, scopeLine: 586, spFlags: DISPFlagDefinition, unit: !2)
!2262 = !DILocalVariable(name: "number", arg: 1, scope: !2261, file: !0, line: 586, type: !10)
!2263 = !DILocation(line: 586, column: 29, scope: !2261)
!2264 = !DILocation(line: 587, column: 3, scope: !2261)
!2265 = !DILocation(line: 587, column: 3, scope: !2261)
!2266 = !DILocation(line: 587, column: 3, scope: !2261)
!2267 = !DILocation(line: 588, column: 15, scope: !2261)
!2268 = !DILocation(line: 588, column: 15, scope: !2261)
!2269 = !DILocation(line: 589, column: 16, scope: !2261)
!2270 = !DILocation(line: 589, column: 16, scope: !2261)
!2271 = !DILocation(line: 587, column: 3, scope: !2261)
!2272 = !DILocation(line: 587, column: 3, scope: !2261)
!2273 = !{!157, !10}
!2274 = !DISubroutineType(types: !2273)
!2275 = distinct !DISubprogram(name: "select-range-262-267", linkageName: "topal.dispatch.topal.fn.select_2drange_2d262_2d267.178", scope: !0, file: !0, line: 591, type: !2274, scopeLine: 591, spFlags: DISPFlagDefinition, unit: !2)
!2276 = !DILocalVariable(name: "number", arg: 1, scope: !2275, file: !0, line: 591, type: !10)
!2277 = !DILocation(line: 591, column: 29, scope: !2275)
!2278 = !DILocation(line: 592, column: 3, scope: !2275)
!2279 = !DILocation(line: 592, column: 3, scope: !2275)
!2280 = !DILocation(line: 592, column: 3, scope: !2275)
!2281 = !DILocation(line: 593, column: 15, scope: !2275)
!2282 = !DILocation(line: 593, column: 15, scope: !2275)
!2283 = !DILocation(line: 594, column: 16, scope: !2275)
!2284 = !DILocation(line: 594, column: 16, scope: !2275)
!2285 = !DILocation(line: 592, column: 3, scope: !2275)
!2286 = !DILocation(line: 592, column: 3, scope: !2275)
!2287 = !{!157, !10}
!2288 = !DISubroutineType(types: !2287)
!2289 = distinct !DISubprogram(name: "select-range-229-267", linkageName: "topal.dispatch.topal.fn.select_2drange_2d229_2d267.179", scope: !0, file: !0, line: 596, type: !2288, scopeLine: 596, spFlags: DISPFlagDefinition, unit: !2)
!2290 = !DILocalVariable(name: "number", arg: 1, scope: !2289, file: !0, line: 596, type: !10)
!2291 = !DILocation(line: 596, column: 29, scope: !2289)
!2292 = !DILocation(line: 597, column: 3, scope: !2289)
!2293 = !DILocation(line: 597, column: 3, scope: !2289)
!2294 = !DILocation(line: 597, column: 3, scope: !2289)
!2295 = !DILocation(line: 598, column: 15, scope: !2289)
!2296 = !DILocation(line: 598, column: 15, scope: !2289)
!2297 = !DILocation(line: 599, column: 16, scope: !2289)
!2298 = !DILocation(line: 599, column: 16, scope: !2289)
!2299 = !DILocation(line: 597, column: 3, scope: !2289)
!2300 = !DILocation(line: 597, column: 3, scope: !2289)
!2301 = !{!65, !10, !10}
!2302 = !DISubroutineType(types: !2301)
!2303 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.180", scope: !73, file: !73, line: 3, type: !2302, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2304 = !DILocalVariable(name: "number", arg: 1, scope: !2303, file: !73, line: 3, type: !10)
!2305 = !DILocation(line: 3, column: 31, scope: !2303)
!2306 = !DILocalVariable(name: "expected", arg: 2, scope: !2303, file: !73, line: 3, type: !10)
!2307 = !DILocation(line: 3, column: 45, scope: !2303)
!2308 = !DILocation(line: 4, column: 3, scope: !2303)
!2309 = !DILocation(line: 4, column: 3, scope: !2303)
!2310 = !DILocation(line: 4, column: 3, scope: !2303)
!2311 = !DILocation(line: 4, column: 3, scope: !2303)
!2312 = !{!157, !10}
!2313 = !DISubroutineType(types: !2312)
!2314 = distinct !DISubprogram(name: "select-range-268-268", linkageName: "topal.dispatch.topal.fn.select_2drange_2d268_2d268.181", scope: !0, file: !0, line: 601, type: !2313, scopeLine: 601, spFlags: DISPFlagDefinition, unit: !2)
!2315 = !DILocalVariable(name: "number", arg: 1, scope: !2314, file: !0, line: 601, type: !10)
!2316 = !DILocation(line: 601, column: 29, scope: !2314)
!2317 = !DILocation(line: 602, column: 3, scope: !2314)
!2318 = !DILocation(line: 602, column: 3, scope: !2314)
!2319 = !DILocation(line: 603, column: 15, scope: !2314)
!2320 = !DILocation(line: 604, column: 16, scope: !2314)
!2321 = !DILocation(line: 602, column: 3, scope: !2314)
!2322 = !DILocation(line: 602, column: 3, scope: !2314)
!2323 = !{!65, !10, !10}
!2324 = !DISubroutineType(types: !2323)
!2325 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.182", scope: !73, file: !73, line: 3, type: !2324, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2326 = !DILocalVariable(name: "number", arg: 1, scope: !2325, file: !73, line: 3, type: !10)
!2327 = !DILocation(line: 3, column: 31, scope: !2325)
!2328 = !DILocalVariable(name: "expected", arg: 2, scope: !2325, file: !73, line: 3, type: !10)
!2329 = !DILocation(line: 3, column: 45, scope: !2325)
!2330 = !DILocation(line: 4, column: 3, scope: !2325)
!2331 = !DILocation(line: 4, column: 3, scope: !2325)
!2332 = !DILocation(line: 4, column: 3, scope: !2325)
!2333 = !DILocation(line: 4, column: 3, scope: !2325)
!2334 = !{!157, !10}
!2335 = !DISubroutineType(types: !2334)
!2336 = distinct !DISubprogram(name: "select-range-273-273", linkageName: "topal.dispatch.topal.fn.select_2drange_2d273_2d273.183", scope: !0, file: !0, line: 606, type: !2335, scopeLine: 606, spFlags: DISPFlagDefinition, unit: !2)
!2337 = !DILocalVariable(name: "number", arg: 1, scope: !2336, file: !0, line: 606, type: !10)
!2338 = !DILocation(line: 606, column: 29, scope: !2336)
!2339 = !DILocation(line: 607, column: 3, scope: !2336)
!2340 = !DILocation(line: 607, column: 3, scope: !2336)
!2341 = !DILocation(line: 608, column: 15, scope: !2336)
!2342 = !DILocation(line: 609, column: 16, scope: !2336)
!2343 = !DILocation(line: 607, column: 3, scope: !2336)
!2344 = !DILocation(line: 607, column: 3, scope: !2336)
!2345 = !{!157, !10}
!2346 = !DISubroutineType(types: !2345)
!2347 = distinct !DISubprogram(name: "select-range-268-273", linkageName: "topal.dispatch.topal.fn.select_2drange_2d268_2d273.184", scope: !0, file: !0, line: 611, type: !2346, scopeLine: 611, spFlags: DISPFlagDefinition, unit: !2)
!2348 = !DILocalVariable(name: "number", arg: 1, scope: !2347, file: !0, line: 611, type: !10)
!2349 = !DILocation(line: 611, column: 29, scope: !2347)
!2350 = !DILocation(line: 612, column: 3, scope: !2347)
!2351 = !DILocation(line: 612, column: 3, scope: !2347)
!2352 = !DILocation(line: 612, column: 3, scope: !2347)
!2353 = !DILocation(line: 613, column: 15, scope: !2347)
!2354 = !DILocation(line: 613, column: 15, scope: !2347)
!2355 = !DILocation(line: 614, column: 16, scope: !2347)
!2356 = !DILocation(line: 614, column: 16, scope: !2347)
!2357 = !DILocation(line: 612, column: 3, scope: !2347)
!2358 = !DILocation(line: 612, column: 3, scope: !2347)
!2359 = !{!65, !10, !10}
!2360 = !DISubroutineType(types: !2359)
!2361 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.185", scope: !73, file: !73, line: 3, type: !2360, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2362 = !DILocalVariable(name: "number", arg: 1, scope: !2361, file: !73, line: 3, type: !10)
!2363 = !DILocation(line: 3, column: 31, scope: !2361)
!2364 = !DILocalVariable(name: "expected", arg: 2, scope: !2361, file: !73, line: 3, type: !10)
!2365 = !DILocation(line: 3, column: 45, scope: !2361)
!2366 = !DILocation(line: 4, column: 3, scope: !2361)
!2367 = !DILocation(line: 4, column: 3, scope: !2361)
!2368 = !DILocation(line: 4, column: 3, scope: !2361)
!2369 = !DILocation(line: 4, column: 3, scope: !2361)
!2370 = !{!157, !10}
!2371 = !DISubroutineType(types: !2370)
!2372 = distinct !DISubprogram(name: "select-range-292-292", linkageName: "topal.dispatch.topal.fn.select_2drange_2d292_2d292.186", scope: !0, file: !0, line: 616, type: !2371, scopeLine: 616, spFlags: DISPFlagDefinition, unit: !2)
!2373 = !DILocalVariable(name: "number", arg: 1, scope: !2372, file: !0, line: 616, type: !10)
!2374 = !DILocation(line: 616, column: 29, scope: !2372)
!2375 = !DILocation(line: 617, column: 3, scope: !2372)
!2376 = !DILocation(line: 617, column: 3, scope: !2372)
!2377 = !DILocation(line: 618, column: 15, scope: !2372)
!2378 = !DILocation(line: 619, column: 16, scope: !2372)
!2379 = !DILocation(line: 617, column: 3, scope: !2372)
!2380 = !DILocation(line: 617, column: 3, scope: !2372)
!2381 = !{!65, !10, !10}
!2382 = !DISubroutineType(types: !2381)
!2383 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.187", scope: !73, file: !73, line: 3, type: !2382, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2384 = !DILocalVariable(name: "number", arg: 1, scope: !2383, file: !73, line: 3, type: !10)
!2385 = !DILocation(line: 3, column: 31, scope: !2383)
!2386 = !DILocalVariable(name: "expected", arg: 2, scope: !2383, file: !73, line: 3, type: !10)
!2387 = !DILocation(line: 3, column: 45, scope: !2383)
!2388 = !DILocation(line: 4, column: 3, scope: !2383)
!2389 = !DILocation(line: 4, column: 3, scope: !2383)
!2390 = !DILocation(line: 4, column: 3, scope: !2383)
!2391 = !DILocation(line: 4, column: 3, scope: !2383)
!2392 = !{!157, !10}
!2393 = !DISubroutineType(types: !2392)
!2394 = distinct !DISubprogram(name: "select-range-293-293", linkageName: "topal.dispatch.topal.fn.select_2drange_2d293_2d293.188", scope: !0, file: !0, line: 621, type: !2393, scopeLine: 621, spFlags: DISPFlagDefinition, unit: !2)
!2395 = !DILocalVariable(name: "number", arg: 1, scope: !2394, file: !0, line: 621, type: !10)
!2396 = !DILocation(line: 621, column: 29, scope: !2394)
!2397 = !DILocation(line: 622, column: 3, scope: !2394)
!2398 = !DILocation(line: 622, column: 3, scope: !2394)
!2399 = !DILocation(line: 623, column: 15, scope: !2394)
!2400 = !DILocation(line: 624, column: 16, scope: !2394)
!2401 = !DILocation(line: 622, column: 3, scope: !2394)
!2402 = !DILocation(line: 622, column: 3, scope: !2394)
!2403 = !{!157, !10}
!2404 = !DISubroutineType(types: !2403)
!2405 = distinct !DISubprogram(name: "select-range-292-293", linkageName: "topal.dispatch.topal.fn.select_2drange_2d292_2d293.189", scope: !0, file: !0, line: 626, type: !2404, scopeLine: 626, spFlags: DISPFlagDefinition, unit: !2)
!2406 = !DILocalVariable(name: "number", arg: 1, scope: !2405, file: !0, line: 626, type: !10)
!2407 = !DILocation(line: 626, column: 29, scope: !2405)
!2408 = !DILocation(line: 627, column: 3, scope: !2405)
!2409 = !DILocation(line: 627, column: 3, scope: !2405)
!2410 = !DILocation(line: 627, column: 3, scope: !2405)
!2411 = !DILocation(line: 628, column: 15, scope: !2405)
!2412 = !DILocation(line: 628, column: 15, scope: !2405)
!2413 = !DILocation(line: 629, column: 16, scope: !2405)
!2414 = !DILocation(line: 629, column: 16, scope: !2405)
!2415 = !DILocation(line: 627, column: 3, scope: !2405)
!2416 = !DILocation(line: 627, column: 3, scope: !2405)
!2417 = !{!157, !10}
!2418 = !DISubroutineType(types: !2417)
!2419 = distinct !DISubprogram(name: "select-range-268-293", linkageName: "topal.dispatch.topal.fn.select_2drange_2d268_2d293.190", scope: !0, file: !0, line: 631, type: !2418, scopeLine: 631, spFlags: DISPFlagDefinition, unit: !2)
!2420 = !DILocalVariable(name: "number", arg: 1, scope: !2419, file: !0, line: 631, type: !10)
!2421 = !DILocation(line: 631, column: 29, scope: !2419)
!2422 = !DILocation(line: 632, column: 3, scope: !2419)
!2423 = !DILocation(line: 632, column: 3, scope: !2419)
!2424 = !DILocation(line: 632, column: 3, scope: !2419)
!2425 = !DILocation(line: 633, column: 15, scope: !2419)
!2426 = !DILocation(line: 633, column: 15, scope: !2419)
!2427 = !DILocation(line: 634, column: 16, scope: !2419)
!2428 = !DILocation(line: 634, column: 16, scope: !2419)
!2429 = !DILocation(line: 632, column: 3, scope: !2419)
!2430 = !DILocation(line: 632, column: 3, scope: !2419)
!2431 = !{!65, !10, !10}
!2432 = !DISubroutineType(types: !2431)
!2433 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.191", scope: !73, file: !73, line: 3, type: !2432, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2434 = !DILocalVariable(name: "number", arg: 1, scope: !2433, file: !73, line: 3, type: !10)
!2435 = !DILocation(line: 3, column: 31, scope: !2433)
!2436 = !DILocalVariable(name: "expected", arg: 2, scope: !2433, file: !73, line: 3, type: !10)
!2437 = !DILocation(line: 3, column: 45, scope: !2433)
!2438 = !DILocation(line: 4, column: 3, scope: !2433)
!2439 = !DILocation(line: 4, column: 3, scope: !2433)
!2440 = !DILocation(line: 4, column: 3, scope: !2433)
!2441 = !DILocation(line: 4, column: 3, scope: !2433)
!2442 = !{!157, !10}
!2443 = !DISubroutineType(types: !2442)
!2444 = distinct !DISubprogram(name: "select-range-302-302", linkageName: "topal.dispatch.topal.fn.select_2drange_2d302_2d302.192", scope: !0, file: !0, line: 636, type: !2443, scopeLine: 636, spFlags: DISPFlagDefinition, unit: !2)
!2445 = !DILocalVariable(name: "number", arg: 1, scope: !2444, file: !0, line: 636, type: !10)
!2446 = !DILocation(line: 636, column: 29, scope: !2444)
!2447 = !DILocation(line: 637, column: 3, scope: !2444)
!2448 = !DILocation(line: 637, column: 3, scope: !2444)
!2449 = !DILocation(line: 638, column: 15, scope: !2444)
!2450 = !DILocation(line: 639, column: 16, scope: !2444)
!2451 = !DILocation(line: 637, column: 3, scope: !2444)
!2452 = !DILocation(line: 637, column: 3, scope: !2444)
!2453 = !{!65, !10, !10}
!2454 = !DISubroutineType(types: !2453)
!2455 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.193", scope: !73, file: !73, line: 3, type: !2454, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2456 = !DILocalVariable(name: "number", arg: 1, scope: !2455, file: !73, line: 3, type: !10)
!2457 = !DILocation(line: 3, column: 31, scope: !2455)
!2458 = !DILocalVariable(name: "expected", arg: 2, scope: !2455, file: !73, line: 3, type: !10)
!2459 = !DILocation(line: 3, column: 45, scope: !2455)
!2460 = !DILocation(line: 4, column: 3, scope: !2455)
!2461 = !DILocation(line: 4, column: 3, scope: !2455)
!2462 = !DILocation(line: 4, column: 3, scope: !2455)
!2463 = !DILocation(line: 4, column: 3, scope: !2455)
!2464 = !{!157, !10}
!2465 = !DISubroutineType(types: !2464)
!2466 = distinct !DISubprogram(name: "select-range-316-316", linkageName: "topal.dispatch.topal.fn.select_2drange_2d316_2d316.194", scope: !0, file: !0, line: 641, type: !2465, scopeLine: 641, spFlags: DISPFlagDefinition, unit: !2)
!2467 = !DILocalVariable(name: "number", arg: 1, scope: !2466, file: !0, line: 641, type: !10)
!2468 = !DILocation(line: 641, column: 29, scope: !2466)
!2469 = !DILocation(line: 642, column: 3, scope: !2466)
!2470 = !DILocation(line: 642, column: 3, scope: !2466)
!2471 = !DILocation(line: 643, column: 15, scope: !2466)
!2472 = !DILocation(line: 644, column: 16, scope: !2466)
!2473 = !DILocation(line: 642, column: 3, scope: !2466)
!2474 = !DILocation(line: 642, column: 3, scope: !2466)
!2475 = !{!157, !10}
!2476 = !DISubroutineType(types: !2475)
!2477 = distinct !DISubprogram(name: "select-range-302-316", linkageName: "topal.dispatch.topal.fn.select_2drange_2d302_2d316.195", scope: !0, file: !0, line: 646, type: !2476, scopeLine: 646, spFlags: DISPFlagDefinition, unit: !2)
!2478 = !DILocalVariable(name: "number", arg: 1, scope: !2477, file: !0, line: 646, type: !10)
!2479 = !DILocation(line: 646, column: 29, scope: !2477)
!2480 = !DILocation(line: 647, column: 3, scope: !2477)
!2481 = !DILocation(line: 647, column: 3, scope: !2477)
!2482 = !DILocation(line: 647, column: 3, scope: !2477)
!2483 = !DILocation(line: 648, column: 15, scope: !2477)
!2484 = !DILocation(line: 648, column: 15, scope: !2477)
!2485 = !DILocation(line: 649, column: 16, scope: !2477)
!2486 = !DILocation(line: 649, column: 16, scope: !2477)
!2487 = !DILocation(line: 647, column: 3, scope: !2477)
!2488 = !DILocation(line: 647, column: 3, scope: !2477)
!2489 = !{!65, !10, !10}
!2490 = !DISubroutineType(types: !2489)
!2491 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.196", scope: !73, file: !73, line: 3, type: !2490, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2492 = !DILocalVariable(name: "number", arg: 1, scope: !2491, file: !73, line: 3, type: !10)
!2493 = !DILocation(line: 3, column: 31, scope: !2491)
!2494 = !DILocalVariable(name: "expected", arg: 2, scope: !2491, file: !73, line: 3, type: !10)
!2495 = !DILocation(line: 3, column: 45, scope: !2491)
!2496 = !DILocation(line: 4, column: 3, scope: !2491)
!2497 = !DILocation(line: 4, column: 3, scope: !2491)
!2498 = !DILocation(line: 4, column: 3, scope: !2491)
!2499 = !DILocation(line: 4, column: 3, scope: !2491)
!2500 = !{!157, !10}
!2501 = !DISubroutineType(types: !2500)
!2502 = distinct !DISubprogram(name: "select-range-318-318", linkageName: "topal.dispatch.topal.fn.select_2drange_2d318_2d318.197", scope: !0, file: !0, line: 651, type: !2501, scopeLine: 651, spFlags: DISPFlagDefinition, unit: !2)
!2503 = !DILocalVariable(name: "number", arg: 1, scope: !2502, file: !0, line: 651, type: !10)
!2504 = !DILocation(line: 651, column: 29, scope: !2502)
!2505 = !DILocation(line: 652, column: 3, scope: !2502)
!2506 = !DILocation(line: 652, column: 3, scope: !2502)
!2507 = !DILocation(line: 653, column: 15, scope: !2502)
!2508 = !DILocation(line: 654, column: 16, scope: !2502)
!2509 = !DILocation(line: 652, column: 3, scope: !2502)
!2510 = !DILocation(line: 652, column: 3, scope: !2502)
!2511 = !{!65, !10, !10}
!2512 = !DISubroutineType(types: !2511)
!2513 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.198", scope: !73, file: !73, line: 3, type: !2512, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2514 = !DILocalVariable(name: "number", arg: 1, scope: !2513, file: !73, line: 3, type: !10)
!2515 = !DILocation(line: 3, column: 31, scope: !2513)
!2516 = !DILocalVariable(name: "expected", arg: 2, scope: !2513, file: !73, line: 3, type: !10)
!2517 = !DILocation(line: 3, column: 45, scope: !2513)
!2518 = !DILocation(line: 4, column: 3, scope: !2513)
!2519 = !DILocation(line: 4, column: 3, scope: !2513)
!2520 = !DILocation(line: 4, column: 3, scope: !2513)
!2521 = !DILocation(line: 4, column: 3, scope: !2513)
!2522 = !{!157, !10}
!2523 = !DISubroutineType(types: !2522)
!2524 = distinct !DISubprogram(name: "select-range-334-334", linkageName: "topal.dispatch.topal.fn.select_2drange_2d334_2d334.199", scope: !0, file: !0, line: 656, type: !2523, scopeLine: 656, spFlags: DISPFlagDefinition, unit: !2)
!2525 = !DILocalVariable(name: "number", arg: 1, scope: !2524, file: !0, line: 656, type: !10)
!2526 = !DILocation(line: 656, column: 29, scope: !2524)
!2527 = !DILocation(line: 657, column: 3, scope: !2524)
!2528 = !DILocation(line: 657, column: 3, scope: !2524)
!2529 = !DILocation(line: 658, column: 15, scope: !2524)
!2530 = !DILocation(line: 659, column: 16, scope: !2524)
!2531 = !DILocation(line: 657, column: 3, scope: !2524)
!2532 = !DILocation(line: 657, column: 3, scope: !2524)
!2533 = !{!65, !10, !10}
!2534 = !DISubroutineType(types: !2533)
!2535 = distinct !DISubprogram(name: "support.syscall.matches-selector?", linkageName: "topal.dispatch.topal.fn.support_2esyscall_2ematches_2dselector_3f.200", scope: !73, file: !73, line: 3, type: !2534, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!2536 = !DILocalVariable(name: "number", arg: 1, scope: !2535, file: !73, line: 3, type: !10)
!2537 = !DILocation(line: 3, column: 31, scope: !2535)
!2538 = !DILocalVariable(name: "expected", arg: 2, scope: !2535, file: !73, line: 3, type: !10)
!2539 = !DILocation(line: 3, column: 45, scope: !2535)
!2540 = !DILocation(line: 4, column: 3, scope: !2535)
!2541 = !DILocation(line: 4, column: 3, scope: !2535)
!2542 = !DILocation(line: 4, column: 3, scope: !2535)
!2543 = !DILocation(line: 4, column: 3, scope: !2535)
!2544 = !{!157, !10}
!2545 = !DISubroutineType(types: !2544)
!2546 = distinct !DISubprogram(name: "select-range-452-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d452_2d452.201", scope: !0, file: !0, line: 661, type: !2545, scopeLine: 661, spFlags: DISPFlagDefinition, unit: !2)
!2547 = !DILocalVariable(name: "number", arg: 1, scope: !2546, file: !0, line: 661, type: !10)
!2548 = !DILocation(line: 661, column: 29, scope: !2546)
!2549 = !DILocation(line: 662, column: 3, scope: !2546)
!2550 = !DILocation(line: 662, column: 3, scope: !2546)
!2551 = !DILocation(line: 663, column: 15, scope: !2546)
!2552 = !DILocation(line: 664, column: 16, scope: !2546)
!2553 = !DILocation(line: 662, column: 3, scope: !2546)
!2554 = !DILocation(line: 662, column: 3, scope: !2546)
!2555 = !{!157, !10}
!2556 = !DISubroutineType(types: !2555)
!2557 = distinct !DISubprogram(name: "select-range-334-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d334_2d452.202", scope: !0, file: !0, line: 666, type: !2556, scopeLine: 666, spFlags: DISPFlagDefinition, unit: !2)
!2558 = !DILocalVariable(name: "number", arg: 1, scope: !2557, file: !0, line: 666, type: !10)
!2559 = !DILocation(line: 666, column: 29, scope: !2557)
!2560 = !DILocation(line: 667, column: 3, scope: !2557)
!2561 = !DILocation(line: 667, column: 3, scope: !2557)
!2562 = !DILocation(line: 667, column: 3, scope: !2557)
!2563 = !DILocation(line: 668, column: 15, scope: !2557)
!2564 = !DILocation(line: 668, column: 15, scope: !2557)
!2565 = !DILocation(line: 669, column: 16, scope: !2557)
!2566 = !DILocation(line: 669, column: 16, scope: !2557)
!2567 = !DILocation(line: 667, column: 3, scope: !2557)
!2568 = !DILocation(line: 667, column: 3, scope: !2557)
!2569 = !{!157, !10}
!2570 = !DISubroutineType(types: !2569)
!2571 = distinct !DISubprogram(name: "select-range-318-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d318_2d452.203", scope: !0, file: !0, line: 671, type: !2570, scopeLine: 671, spFlags: DISPFlagDefinition, unit: !2)
!2572 = !DILocalVariable(name: "number", arg: 1, scope: !2571, file: !0, line: 671, type: !10)
!2573 = !DILocation(line: 671, column: 29, scope: !2571)
!2574 = !DILocation(line: 672, column: 3, scope: !2571)
!2575 = !DILocation(line: 672, column: 3, scope: !2571)
!2576 = !DILocation(line: 672, column: 3, scope: !2571)
!2577 = !DILocation(line: 673, column: 15, scope: !2571)
!2578 = !DILocation(line: 673, column: 15, scope: !2571)
!2579 = !DILocation(line: 674, column: 16, scope: !2571)
!2580 = !DILocation(line: 674, column: 16, scope: !2571)
!2581 = !DILocation(line: 672, column: 3, scope: !2571)
!2582 = !DILocation(line: 672, column: 3, scope: !2571)
!2583 = !{!157, !10}
!2584 = !DISubroutineType(types: !2583)
!2585 = distinct !DISubprogram(name: "select-range-302-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d302_2d452.204", scope: !0, file: !0, line: 676, type: !2584, scopeLine: 676, spFlags: DISPFlagDefinition, unit: !2)
!2586 = !DILocalVariable(name: "number", arg: 1, scope: !2585, file: !0, line: 676, type: !10)
!2587 = !DILocation(line: 676, column: 29, scope: !2585)
!2588 = !DILocation(line: 677, column: 3, scope: !2585)
!2589 = !DILocation(line: 677, column: 3, scope: !2585)
!2590 = !DILocation(line: 677, column: 3, scope: !2585)
!2591 = !DILocation(line: 678, column: 15, scope: !2585)
!2592 = !DILocation(line: 678, column: 15, scope: !2585)
!2593 = !DILocation(line: 679, column: 16, scope: !2585)
!2594 = !DILocation(line: 679, column: 16, scope: !2585)
!2595 = !DILocation(line: 677, column: 3, scope: !2585)
!2596 = !DILocation(line: 677, column: 3, scope: !2585)
!2597 = !{!157, !10}
!2598 = !DISubroutineType(types: !2597)
!2599 = distinct !DISubprogram(name: "select-range-268-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d268_2d452.205", scope: !0, file: !0, line: 681, type: !2598, scopeLine: 681, spFlags: DISPFlagDefinition, unit: !2)
!2600 = !DILocalVariable(name: "number", arg: 1, scope: !2599, file: !0, line: 681, type: !10)
!2601 = !DILocation(line: 681, column: 29, scope: !2599)
!2602 = !DILocation(line: 682, column: 3, scope: !2599)
!2603 = !DILocation(line: 682, column: 3, scope: !2599)
!2604 = !DILocation(line: 682, column: 3, scope: !2599)
!2605 = !DILocation(line: 683, column: 15, scope: !2599)
!2606 = !DILocation(line: 683, column: 15, scope: !2599)
!2607 = !DILocation(line: 684, column: 16, scope: !2599)
!2608 = !DILocation(line: 684, column: 16, scope: !2599)
!2609 = !DILocation(line: 682, column: 3, scope: !2599)
!2610 = !DILocation(line: 682, column: 3, scope: !2599)
!2611 = !{!157, !10}
!2612 = !DISubroutineType(types: !2611)
!2613 = distinct !DISubprogram(name: "select-range-229-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d229_2d452.206", scope: !0, file: !0, line: 686, type: !2612, scopeLine: 686, spFlags: DISPFlagDefinition, unit: !2)
!2614 = !DILocalVariable(name: "number", arg: 1, scope: !2613, file: !0, line: 686, type: !10)
!2615 = !DILocation(line: 686, column: 29, scope: !2613)
!2616 = !DILocation(line: 687, column: 3, scope: !2613)
!2617 = !DILocation(line: 687, column: 3, scope: !2613)
!2618 = !DILocation(line: 687, column: 3, scope: !2613)
!2619 = !DILocation(line: 688, column: 15, scope: !2613)
!2620 = !DILocation(line: 688, column: 15, scope: !2613)
!2621 = !DILocation(line: 689, column: 16, scope: !2613)
!2622 = !DILocation(line: 689, column: 16, scope: !2613)
!2623 = !DILocation(line: 687, column: 3, scope: !2613)
!2624 = !DILocation(line: 687, column: 3, scope: !2613)
!2625 = !{!157, !10}
!2626 = !DISubroutineType(types: !2625)
!2627 = distinct !DISubprogram(name: "select-range-91-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d91_2d452.207", scope: !0, file: !0, line: 691, type: !2626, scopeLine: 691, spFlags: DISPFlagDefinition, unit: !2)
!2628 = !DILocalVariable(name: "number", arg: 1, scope: !2627, file: !0, line: 691, type: !10)
!2629 = !DILocation(line: 691, column: 28, scope: !2627)
!2630 = !DILocation(line: 692, column: 3, scope: !2627)
!2631 = !DILocation(line: 692, column: 3, scope: !2627)
!2632 = !DILocation(line: 692, column: 3, scope: !2627)
!2633 = !DILocation(line: 693, column: 15, scope: !2627)
!2634 = !DILocation(line: 693, column: 15, scope: !2627)
!2635 = !DILocation(line: 694, column: 16, scope: !2627)
!2636 = !DILocation(line: 694, column: 16, scope: !2627)
!2637 = !DILocation(line: 692, column: 3, scope: !2627)
!2638 = !DILocation(line: 692, column: 3, scope: !2627)
!2639 = !{!157, !10}
!2640 = !DISubroutineType(types: !2639)
!2641 = distinct !DISubprogram(name: "select-range-0-452", linkageName: "topal.dispatch.topal.fn.select_2drange_2d0_2d452.208", scope: !0, file: !0, line: 696, type: !2640, scopeLine: 696, spFlags: DISPFlagDefinition, unit: !2)
!2642 = !DILocalVariable(name: "number", arg: 1, scope: !2641, file: !0, line: 696, type: !10)
!2643 = !DILocation(line: 696, column: 27, scope: !2641)
!2644 = !DILocation(line: 697, column: 3, scope: !2641)
!2645 = !DILocation(line: 697, column: 3, scope: !2641)
!2646 = !DILocation(line: 697, column: 3, scope: !2641)
!2647 = !DILocation(line: 698, column: 15, scope: !2641)
!2648 = !DILocation(line: 698, column: 15, scope: !2641)
!2649 = !DILocation(line: 699, column: 16, scope: !2641)
!2650 = !DILocation(line: 699, column: 16, scope: !2641)
!2651 = !DILocation(line: 697, column: 3, scope: !2641)
!2652 = !DILocation(line: 697, column: 3, scope: !2641)
!2653 = !{!157, !10}
!2654 = !DISubroutineType(types: !2653)
!2655 = distinct !DISubprogram(name: "select-operation", linkageName: "topal.dispatch.topal.fn.select_2doperation.209", scope: !0, file: !0, line: 701, type: !2654, scopeLine: 701, spFlags: DISPFlagDefinition, unit: !2)
!2656 = !DILocalVariable(name: "number", arg: 1, scope: !2655, file: !0, line: 701, type: !10)
!2657 = !DILocation(line: 701, column: 29, scope: !2655)
!2658 = !DILocation(line: 702, column: 3, scope: !2655)
!2659 = !DILocation(line: 702, column: 3, scope: !2655)
!2660 = !{i32 2, !"Dwarf Version", i32 5}
!2661 = !{i32 2, !"Debug Info Version", i32 3}
!2662 = !{!"topalc 0.1.0"}
