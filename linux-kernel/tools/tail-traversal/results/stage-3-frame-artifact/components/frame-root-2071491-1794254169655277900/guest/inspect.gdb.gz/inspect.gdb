set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/tk282-frame-artifact-37531127/frame-root-2071491-1794254169655277900/kernel.elf"
target remote 127.0.0.1:54719
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/tk282-frame-artifact-37531127/frame-root-2071491-1794254169655277900/guest/observations.json'

import gdb, json, time, traceback

observed = dict(passed=False, calls=[], live={}, firmware_map_modified=False)
pending = None
preserved = ['rbx','rbp','r12','r13','r14','r15']

def value(s): return int(gdb.parse_and_eval(s))
def address(s): return value('(unsigned long long)&'+s)
def memory(p,n): return bytes(gdb.selected_inferior().read_memory(p,n))
def words(p,n):
    data=memory(p,n*8)
    return [int.from_bytes(data[i:i+8],'little') for i in range(0,len(data),8)]
def word(p): return words(p,1)[0]
def zeros(p,n): assert memory(p,n)==bytes(n),(hex(p),n)
def privileged():
    assert value('$cs')&3==0 and value('$eflags')&0x600==0
def record(token):
    issuer,identity,index=words(token,3)
    assert issuer==1 and identity>0 and index<observed['n']
    p=address('topal_x86_frame_registry_v1')+index*64
    data=words(p,8)
    assert data[:2]==[issuer,identity] and data[7]==1
    return p,data
def cells(start,count):
    return words(address('topal_x86_frame_table_v1')+128+start*24,count*3)
def fail():
    traceback.print_exc()
    with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
    gdb.execute('quit 1')

class Gateway(gdb.Breakpoint):
    def __init__(self,symbol,role):
        super().__init__('*'+symbol)
        self.role=role
    def stop(self):
        global pending
        try:
            privileged()
            if self.role=='entry':
                assert pending is None
                zeros(address('topal_x86_frame_details_v1'),32)
                pending=dict(op=value('$rdi'),a=value('$rsi'),b=value('$rdx'),
                    token=value('$rcx'),facts=value('$r8'),sp=value('$rsp'),
                    registers={r:value('$'+r) for r in preserved},started=time.monotonic())
                op=pending['op']
                if op==0:
                    boot=pending['a']
                    n=memory(boot+488,1)[0]
                    observed['e820']=[words(boot+720+20*i,2)+[
                        int.from_bytes(memory(boot+736+20*i,4),'little')] for i in range(n)]
                    resource=int.from_bytes(memory(boot+536,4),'little')
                    size=int.from_bytes(memory(boot+540,4),'little')
                    observed['reservations']=[[0,address('topal_x86_kernel_reservation_end_v1')],
                                              [resource,resource+size]]
                else:
                    assert 1<=op<=4
                    delta=pending['token']-address('topal_x86_frame_root_tokens_v1')
                    assert 0<=delta<token_bytes and delta%24==0
                    pending['next_id']=word(address('topal_x86_frame_context_v1')+16)
                    if op!=1:
                        p,r=record(pending['token'])
                        pending.update(record_address=p,record=r)
                        assert str(r[1]) in observed['live']
                        if op==2:assert r[6]==0
                print('FRAME_ROOT_ENTER',len(observed['calls']),op,pending['a'],flush=True)
                return False
            assert pending is not None
            assert value('$rsp')==pending['sp']
            for r,n in pending['registers'].items():assert value('$'+r)==n,r
            for r in ['rcx','rdx','rsi','rdi','r8','r9','r10','r11']:assert value('$'+r)==0,r
            zeros(pending['sp']-4080,4080)
            for name,size in [('private',65528),('stack',4096),('facts',24),
                              ('output',56),('gateway_recovery',48)]:
                zeros(address('topal_x86_frame_'+name+'_v1'),size)
            assert word(address('topal_frame_allocator_active_v1'))==0
            assert word(address('topal_x86_tail_boundary_active_v1'))==0
            ctx=address('topal_x86_frame_context_v1')
            assert word(ctx)==1
            op=pending['op']
            assert value('$rax')==(ctx if op==0 else 1),(op,value('$rax'))
            if op==0:
                n=word(ctx+24)
                assert 0<n<=262144
                observed['n']=n
                data=cells(0,n)
                frames=data[2::3]
                assert data[0::3]==[0]*n and data[1::3]==[1]*n
                assert frames==sorted(set(frames))
                for frame in frames:
                    assert any(kind==1 and start<=frame*4096 and (frame+1)*4096<=start+size
                               for start,size,kind in observed['e820'])
                    assert all(kind==1 or (frame+1)*4096<=start or frame*4096>=start+size
                               for start,size,kind in observed['e820'])
                    assert all((frame+1)*4096<=start or frame*4096>=end
                               for start,end in observed['reservations'])
                observed['physical_frames']=frames
                # Independent complete boundary sweep: checking only the frames
                # returned by the constructor would miss silently dropped RAM.
                claims=[(start,start+size,kind) for start,size,kind in observed['e820']]
                cuts=sorted({v for start,end,_ in claims for v in (start,end)} |
                            {v for pair in observed['reservations'] for v in pair})
                expected=[]
                for start,end in zip(cuts,cuts[1:]):
                    ram=any(kind==1 and a<=start and end<=b for a,b,kind in claims)
                    blocked=any(kind!=1 and a<end and start<b for a,b,kind in claims)
                    reserved=any(a<end and start<b for a,b in observed['reservations'])
                    if ram and not blocked and not reserved:
                        expected.extend(range((start+4095)//4096,end//4096))
                assert frames==expected,'constructor omitted or added allocatable RAM'
                observed['complete_topology_checked']=True
                assert word(ctx+16)==1
            elif op==1:
                p,r=record(pending['token'])
                issuer,identity,start,count,alignment,provenance,pins,live=r
                assert identity==pending['next_id'] and word(ctx+16)==identity+1
                assert [count,alignment]==[pending['a'],pending['b']]
                assert pins==0 and provenance==1
                frames=observed['physical_frames'][start:start+count]
                assert frames==list(range(frames[0],frames[0]+count))
                assert frames[0]%alignment==0
                for old in observed['live'].values():
                    assert start+count<=old['start'] or start>=old['start']+old['count']
                assert cells(start,count)==sum(([identity,1,f] for f in frames),[])
                zeros(frames[0]*4096,count*4096)
                observed['live'][str(identity)]=dict(start=start,count=count,physical=frames[0],
                    pins=0,record=p,token=pending['token'])
                pending['issued_record']=r
            else:
                r=pending['record'];identity=r[1]
                assert word(ctx+16)==pending['next_id']
                if op==2:
                    zeros(pending['record_address'],64);zeros(pending['token'],24)
                    assert cells(r[2],r[3])[0::3]==[0]*r[3]
                    del observed['live'][str(identity)]
                elif op==3:
                    pins=r[6]+(1 if pending['a']==1 else -1)
                    assert word(pending['record_address']+48)==pins
                    observed['live'][str(identity)]['pins']=pins
                else:
                    assert pending['facts']==address('topal_x86_frame_details_v1')
                    assert words(pending['facts'],4)==[
                        observed['physical_frames'][r[2]],r[3],r[4],r[5]]
            pending['elapsed_seconds']=time.monotonic()-pending.pop('started')
            observed['calls'].append(pending)
            pending=None
        except Exception:fail()
        return False

class Unexpected(gdb.Breakpoint):
    def stop(self):
        try:raise AssertionError('unexpected allocator/legacy selector path: '+self.location)
        except Exception:fail()
        return True

class TranslationEdit(gdb.Breakpoint):
    def stop(self):
        try:assert value('$rdx')==1,'legacy translation edit allocated map storage'
        except Exception:fail()
        return False

class Complete(gdb.Breakpoint):
    def stop(self):
        try:
            privileged();assert pending is None
            assert len(observed['live'])==1,observed['live']
            only=next(iter(observed['live'].values()))
            assert only['count']==5 and only['pins']==1
            assert value('$cr3')==only['physical']*4096
            n=observed['n'];table=cells(0,n)
            assert table[1::3]==[1]*n
            assert table[2::3]==observed['physical_frames']
            registry=words(address('topal_x86_frame_registry_v1'),n*8)
            identity=int(next(iter(observed['live'])))
            for i in range(n):
                assert table[i*3]==(identity if only['start']<=i<only['start']+5 else 0)
                if i*64+address('topal_x86_frame_registry_v1')!=only['record']:
                    assert registry[i*8:i*8+8]==[0]*8
            tokens=address('topal_x86_frame_root_tokens_v1')
            for at in range(tokens,tokens+token_bytes,24):
                if at!=only['token']:zeros(at,24)
            assert words(address('topal_x86_frame_history_v1')+24,2)==[0,0]
            assert word(address('topal_x86_frame_context_v1'))==1
            zeros(address('topal_x86_frame_details_v1'),32)
            observed['passed']=True
            with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
            return True
        except Exception:fail()

try:
    Gateway('topal_x86_frame_gateway_v1','entry')
    Gateway('topal_x86_frame_gateway_return_reclaimed_v1','return')
    for symbol in ['topal_x86_frame_gateway_refused_v1','topal_x86_frame_gateway_fatal_reclaimed_v1',
                   'topal_x86_frame_gateway_late_reclaimed_v1',
                   'topal_x86_systems_allocate_physical_frames','topal_x86_systems_begin_bootstrap_translation']:
        Unexpected('*'+symbol)
    TranslationEdit('*topal_x86_systems_begin_active_translation_edit')
    Complete('*topal_x86_systems_fatal')
    gdb.execute('continue')
    assert observed['passed']
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:fail()

end
