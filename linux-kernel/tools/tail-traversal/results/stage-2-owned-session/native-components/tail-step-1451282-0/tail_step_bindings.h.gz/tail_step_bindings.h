#include <stdint.h>
#define TAIL_PARAMETERS 4
#define TAIL_FUNCTIONS 1
#define TAIL_DEPTH 1
#define TAIL_ENTRY_ID 1
#define TAIL_BANK_BYTES 80
#define TAIL_WORK_BYTES 256
#define TAIL_OPERAND_BITS 64
#define TAIL_MEASURE_PARAMETER 1
#define TAIL_TEST_KIND 6
#define TAIL_FRAMES_PER_STEP UINT64_C(1)
#define TAIL_LOANS_PER_STEP UINT64_C(1)
#define TAIL_BASE_BOUND UINT64_C(0)
#define TAIL_MIN_DECREMENT UINT64_C(1)
typedef struct { uint64_t offset, bytes, bits; unsigned kind; } TailRoot;
static const TailRoot TailRoots[TAIL_PARAMETERS] = {
{0,0,0,4},
{0,24,64,1},
{24,24,64,1},
{48,24,64,1},
};
#define TAIL_SCALAR_MASK UINT64_C(14)
static const unsigned char TailHasRegion[TAIL_FUNCTIONS+1] = {
[1]=1,
};
static const unsigned char TailCalls[TAIL_FUNCTIONS+1][TAIL_FUNCTIONS+1] = {
[1]={},
};
