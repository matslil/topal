# Source-tool conformance matrix

This matrix refines `TOPAL-REQ-TOOLS-001` for the accepted `v0.1` and `v0.2`
specifications. Each row applies to every stable rule in the named specification
file. It makes applicability explicit for the interpreter, language server,
linter, and source debugger instead of treating a mention anywhere in the
traceability ledger as proof for every tool.

The dispositions are:

- **direct** — the tool owns observable implementation and functional evidence;
- **shared** — the tool consumes the listed shared implementation and its
  tool-facing corpus verifies that the feature is accepted without divergence;
- **boundary** — the rule is compiler- or artifact-only and the tool enforces a
  tested rejection boundary; and
- **not-applicable** — the rule has no behavior in that tool under its approved
  tool requirements.

A shared disposition does not claim that an analysis-only tool executes runtime
semantics. It means the tool recognizes the same source representation and does
not introduce a private interpretation. Runtime results remain directly
applicable to the interpreter and debugger.

| Specification | Interpreter | LSP | Linter | Debugger | Evidence |
| --- | --- | --- | --- | --- | --- |
| `spec/abstractions.md` | direct | shared | shared | shared | `topal-semantics`; interpreter and debugger functional suites; LSP and linter source corpora |
| `spec/advent-of-code-library.md` | direct | shared | shared | shared | companion-library Topal tests and Advent of Code application corpus; shared loader and source-tool acceptance suites |
| `spec/architecture-models.md` | shared | shared | shared | not-applicable | `topal-semantics` architecture reference model; source/model diagnostics; physical target qualification is a compiler boundary |
| `spec/best-practices.md` | not-applicable | direct | direct | not-applicable | `topal-best-practices`; `topal-linter`; LSP lint adapter tests |
| `spec/concurrency-model.md` | shared | not-applicable | shared | shared | `topal-semantics`; task source tests; contained task-rule views; reversible message tests |
| `spec/concurrency-implementations.md` | shared | shared | shared | shared | `topal-semantics::portable_runtime` reference models and unit tests; source-operation and debugger integration remains planned |
| `spec/contracts-and-evidence.md` | direct | shared | shared | shared | v0.2 function-clause parser and interpreter tests; `topal-semantics::assurance`; `topal-geir` revision-2 evidence tests |
| `spec/containers.md` | direct | shared | shared | shared | `topal-language`; cross-tool source corpora |
| `spec/data-transfer-packages.md` | boundary | shared | shared | boundary | explicit host-capability boundary; package source corpora; debugger replay boundary |
| `spec/data-transfers.md` | direct | shared | shared | shared | Topal standard-library tests and cross-tool package corpus; native adapter boundary tests |
| `spec/debugger-scripting.md` | not-applicable | shared | not-applicable | direct | `topal-debugger`; debugger scripts; LSP debug-variant completion tests |
| `spec/decisions.md` | direct | shared | shared | shared | `topal-syntax`; `topal-language`; cross-tool source corpora |
| `spec/diagnostics.md` | shared | direct | direct | shared | `topal-source`; tool adapter and functional suites |
| `spec/effects.md` | shared | shared | shared | shared | `topal-semantics`; effect source corpus and debugger history tests |
| `spec/effect-handlers-and-plans.md` | shared | shared | shared | shared | shared handler and compiler-owned plan models; handler source execution and compiler lowering remain planned |
| `spec/functions.md` | direct | shared | shared | shared | `topal-language`; cross-tool source and standard-library corpora |
| `spec/generators.md` | direct | shared | shared | shared | `topal-language`; cross-tool source corpora and close-history tests |
| `spec/generic-ir.md` | boundary | boundary | not-applicable | boundary | `topal-geir` compiler-only boundary matrix |
| `spec/memory-model.md` | shared | not-applicable | not-applicable | shared | `topal-semantics` memory-model tests; shared execution boundary |
| `spec/modules.md` | direct | shared | shared | shared | shared module loader; directory-application and library corpus tests |
| `spec/numbers.md` | direct | shared | shared | shared | `topal-language`; cross-tool source corpora |
| `spec/optimization-policy.md` | not-applicable | not-applicable | not-applicable | not-applicable | compiler implementation-plan and optimization-policy evidence; source tools preserve controls and diagnostics through shared syntax boundaries |
| `spec/ranges.md` | direct | shared | shared | shared | `topal-language`; cross-tool source corpora |
| `spec/resources.md` | shared | not-applicable | shared | shared | `topal-semantics` ownership tests; shared semantic views and execution |
| `spec/resource-evidence.md` | shared | shared | shared | shared | shared bounds, progress, exclusivity, and region models; compiler inference and source-region integration remain planned |
| `spec/serialization.md` | direct | shared | shared | shared | `topal-serialization`; source serialization and checked-location corpora |
| `spec/source-documentation.md` | shared | shared | not-applicable | direct | `topal-syntax`; `topal-language`; LSP corpus; debugger help tests |
| `spec/standard-library.md` | direct | shared | shared | shared | shared library application and cross-tool conformance suites |
| `spec/strings.md` | direct | shared | shared | shared | `topal-source`; `topal-language`; cross-tool source corpora |
| `spec/systems-profile.md` | shared | shared | shared | shared | planned `topal-semantics` systems model; shared feature/context diagnostics; debugger trace/replay views; physical lowering remains a compiler boundary |
| `spec/syntax.md` | shared | direct | shared | shared | `topal-source`; `topal-syntax`; all four source-tool corpora |
| `spec/tasks.md` | direct | shared | shared | shared | task examples, contained rule views, and reversible transaction tests |
| `spec/time-and-dataflow.md` | shared | shared | shared | shared | shared clock, periodic-release, balance, causality, and schedule models; source execution integration remains planned |
| `spec/tracing.md` | direct | not-applicable | shared | direct | `topal-semantics`; interpreter test traces; supplied lint trace views; debugger history |
| `spec/type-system.md` | direct | shared | shared | shared | `topal-semantics`; `topal-language`; cross-tool source corpora |
| `spec/composite-layouts-and-information-flow.md` | shared | shared | shared | shared | shared shape, sparse, lattice, propagation, and authority models; source checking and backend selection remain planned |
| `spec/compiler.md` | not-applicable | not-applicable | not-applicable | not-applicable | native compiler unit, CLI, ELF, GDB, differential-execution, metadata, and resource tests; compiler coverage is tracked separately in `se/compiler-conformance.md` |

The repository conformance test expands these domain rows to every stable rule,
requires one row per stable specification file, validates every disposition,
and requires a nonempty evidence description for each domain. Adding a rule or
specification domain therefore cannot silently inherit an unreviewed tool
disposition.
