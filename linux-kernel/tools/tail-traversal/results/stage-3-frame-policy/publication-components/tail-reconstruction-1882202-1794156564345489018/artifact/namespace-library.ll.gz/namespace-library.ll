; checked ordinary Topal region source object
source_filename = "namespace-action.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

@llvm.used = appending global [1 x ptr] [ptr @topal.region-instance.namespace-metadata.memset], section "llvm.metadata"
; Shared private topal-native/6 value algorithms.
; Platform allocation, write and termination hooks are supplied separately.
; Int values are immutable sign-and-magnitude objects with little-endian
; base-2^32 limbs. A zero has sign = 0 and length = 0. Root-local exact
; infinities use executable-private sign tags 2 (+) and 3 (-) with no limbs;
; Rational infinities wrap one sentinel over denominator one at run time. Those
; values are not admitted at a native function or library boundary.

%topal.StringStorage = type { ptr, i64, ptr, i64 }
%topal.IntStorage = type { i64, i64, [0 x i32] }

define internal ptr @topal.region-instance.namespace-metadata.runtime.character.ascii.decimal.digit(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %single.byte = icmp eq i64 %length, 1
  br i1 %single.byte, label %load, label %none
load:
  %data.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 0
  %data = load ptr, ptr %data.pointer, align 8
  %byte = load i8, ptr %data, align 1
  %at.least.zero = icmp uge i8 %byte, 48
  %at.most.nine = icmp ule i8 %byte, 57
  %is.digit = and i1 %at.least.zero, %at.most.nine
  br i1 %is.digit, label %some, label %none
some:
  %digit.byte = sub i8 %byte, 48
  %digit = zext i8 %digit.byte to i64
  %value = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %digit)
  %present = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %value)
  ret ptr %present
none:
  %absent = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %absent
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.character.unicode.whitespace(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.region-instance.namespace-metadata.runtime.string.unicode.scalar.value(ptr %character)
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp eq i64 %length, 1
  br i1 %present, label %load, label %not.whitespace
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %scalar = load i32, ptr %limb.pointer, align 4
  %ascii.lower = icmp uge i32 %scalar, 9
  %ascii.upper = icmp ule i32 %scalar, 13
  %ascii.control = and i1 %ascii.lower, %ascii.upper
  %space = icmp eq i32 %scalar, 32
  %next.line = icmp eq i32 %scalar, 133
  %no.break = icmp eq i32 %scalar, 160
  %ogham = icmp eq i32 %scalar, 5760
  %quad.lower = icmp uge i32 %scalar, 8192
  %quad.upper = icmp ule i32 %scalar, 8202
  %quad = and i1 %quad.lower, %quad.upper
  %line.separator = icmp eq i32 %scalar, 8232
  %paragraph.separator = icmp eq i32 %scalar, 8233
  %narrow.no.break = icmp eq i32 %scalar, 8239
  %medium.math = icmp eq i32 %scalar, 8287
  %ideographic = icmp eq i32 %scalar, 12288
  %match.0 = or i1 %ascii.control, %space
  %match.1 = or i1 %match.0, %next.line
  %match.2 = or i1 %match.1, %no.break
  %match.3 = or i1 %match.2, %ogham
  %match.4 = or i1 %match.3, %quad
  %match.5 = or i1 %match.4, %line.separator
  %match.6 = or i1 %match.5, %paragraph.separator
  %match.7 = or i1 %match.6, %narrow.no.break
  %match.8 = or i1 %match.7, %medium.math
  %match.9 = or i1 %match.8, %ideographic
  ret i1 %match.9
not.whitespace:
  ret i1 false
}
%topal.IntDivmod = type { ptr, ptr }
%topal.RationalStorage = type { ptr, ptr }
%topal.RangeStorage = type { ptr, ptr, i64, i64 }
%topal.ResultStorage = type { i64, ptr }
%topal.OptionalStorage = type { i64, ptr }
%topal.ErrorStorage = type { ptr, i32, i32, ptr, ptr, ptr, i64, i64 }
%topal.SourceLocationStorage = type { ptr, ptr }
%topal.SerializationStreamStorage = type { ptr, i64 }
%topal.TaskStorage = type { i64, i64, ptr }
%topal.LocationStorage = type { ptr, ptr, i64, ptr }

@topal.region-instance.namespace-metadata.runtime.int.zero = internal constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.region-instance.namespace-metadata.runtime.int.one = internal constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.runtime.int.positive.infinity = internal constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.region-instance.namespace-metadata.runtime.int.negative.infinity = internal constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.region-instance.namespace-metadata.runtime.byte.zero = internal constant [1 x i8] c"0", align 1
@topal.region-instance.namespace-metadata.runtime.byte.minus = internal constant [1 x i8] c"-", align 1
@topal.region-instance.namespace-metadata.runtime.int.positive.infinity.text = internal constant [9 x i8] c"+Infinity", align 1
@topal.region-instance.namespace-metadata.runtime.int.negative.infinity.text = internal constant [9 x i8] c"-Infinity", align 1
@topal.region-instance.namespace-metadata.runtime.byte.quote = internal constant [1 x i8] c"\22", align 1
@topal.region-instance.namespace-metadata.runtime.byte.underscore = internal constant [1 x i8] c"_", align 1
@topal.region-instance.namespace-metadata.runtime.string.tag.text = internal constant [4 x i8] c"text", align 1
@topal.region-instance.namespace-metadata.runtime.rational.prefix = internal constant [11 x i8] c"Rational ( ", align 1
@topal.region-instance.namespace-metadata.runtime.rational.separator = internal constant [2 x i8] c", ", align 1
@topal.region-instance.namespace-metadata.runtime.rational.suffix = internal constant [2 x i8] c" )", align 1
@topal.region-instance.namespace-metadata.runtime.range.closed.open = internal constant [4 x i8] c" .. ", align 1
@topal.region-instance.namespace-metadata.runtime.range.open.open = internal constant [5 x i8] c" <.. ", align 1
@topal.region-instance.namespace-metadata.runtime.range.closed.closed = internal constant [5 x i8] c" ..= ", align 1
@topal.region-instance.namespace-metadata.runtime.range.open.closed = internal constant [6 x i8] c" <..= ", align 1
@topal.region-instance.namespace-metadata.runtime.error.prefix = internal constant [18 x i8] c"Error ( domain is ", align 1
@topal.region-instance.namespace-metadata.runtime.error.code.separator = internal constant [10 x i8] c", code is ", align 1
@topal.region-instance.namespace-metadata.runtime.error.suffix = internal constant [2 x i8] c" )", align 1
@topal.region-instance.namespace-metadata.runtime.error.code.out.of.range = internal constant [12 x i8] c"out-of-range", align 1
@topal.region-instance.namespace-metadata.runtime.error.code.not.representable = internal constant [17 x i8] c"not-representable", align 1
@topal.region-instance.namespace-metadata.runtime.error.code.division.by.zero = internal constant [16 x i8] c"division-by-zero", align 1
@topal.region-instance.namespace-metadata.runtime.error.code.indeterminate = internal constant [13 x i8] c"indeterminate", align 1
@topal.region-instance.namespace-metadata.runtime.pattern.identity.diagnostic = internal constant [68 x i8] c"error[E-ANONYMOUS-PATTERN-IDENTITY]: repeated pattern values differ\0A", align 1
@topal.region-instance.namespace-metadata.runtime.c.int32.range.diagnostic = internal constant [71 x i8] c"error[E-C-ABI-RANGE]: Topal Int is not representable as a C signed int\0A", align 1
@topal.region-instance.namespace-metadata.runtime.task.next.identity = internal global i64 1, align 8

declare i32 @llvm.ctlz.i32(i32, i1 immarg)
declare void @llvm.memcpy.inline.p0.p0.i64(ptr, ptr, i64, i1 immarg)

; Optimized freestanding code can lower a recognized fill loop to the standard
; LLVM memset libcall. Supply that ABI locally so no C runtime is introduced.
define internal ptr @topal.region-instance.namespace-metadata.memset(ptr %destination, i32 %value, i64 %length) nounwind noinline optnone noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill
fill:
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill
complete:
  ret ptr %destination
}



define internal void @topal.region-instance.namespace-metadata.runtime.pattern.identity.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.region-instance.namespace-metadata.platform.write(i64 2, ptr @topal.region-instance.namespace-metadata.runtime.pattern.identity.diagnostic, i64 68)
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
}

define internal void @topal.region-instance.namespace-metadata.runtime.c.int32.range.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.region-instance.namespace-metadata.platform.write(i64 2, ptr @topal.region-instance.namespace-metadata.runtime.c.int32.range.diagnostic, i64 71)
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
}


; Closed direct tasks run on the deterministic root scheduler. Each instance
; still owns distinct identity, lifecycle state, and private semantic state.
define internal ptr @topal.region-instance.namespace-metadata.runtime.task.make(ptr %initial) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %task = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 24)
  %identity = load i64, ptr @topal.region-instance.namespace-metadata.runtime.task.next.identity, align 8
  %next.identity = add i64 %identity, 1
  store i64 %next.identity, ptr @topal.region-instance.namespace-metadata.runtime.task.next.identity, align 8
  %identity.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 0
  %terminated.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 1
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store i64 %identity, ptr %identity.pointer, align 8
  store i64 0, ptr %terminated.pointer, align 8
  store ptr %initial, ptr %state.pointer, align 8
  ret ptr %task
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.task.state.load(ptr %task) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  %state = load ptr, ptr %state.pointer, align 8
  ret ptr %state
}

define internal void @topal.region-instance.namespace-metadata.runtime.task.state.replace(ptr %task, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store ptr %value, ptr %state.pointer, align 8
  ret void
}

; A source-only location without a granted device adapter is backed by private
; Topal storage. The semantic range start and offset remain available for
; debugging, while every read and write remains an ordered runtime call.
define internal ptr @topal.region-instance.namespace-metadata.runtime.location.make(ptr %range.start, ptr %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %location = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 32)
  %range.start.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 0
  %offset.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 1
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %range.start, ptr %range.start.pointer, align 8
  store ptr %offset, ptr %offset.pointer, align 8
  store i64 0, ptr %initialized.pointer, align 8
  store ptr null, ptr %value.pointer, align 8
  ret ptr %location
}

define internal void @topal.region-instance.namespace-metadata.runtime.location.write(ptr %location, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %value, ptr %value.pointer, align 8
  store i64 1, ptr %initialized.pointer, align 8
  ret void
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.location.read(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %initialized = load i64, ptr %initialized.pointer, align 8
  %valid = icmp eq i64 %initialized, 1
  br i1 %valid, label %load, label %failure
load:
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  %value = load ptr, ptr %value.pointer, align 8
  %non.null = icmp ne ptr %value, null
  br i1 %non.null, label %success, label %failure
success:
  ret ptr %value
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 74)
  unreachable
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.serialization.make(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %publish.empty, label %copy.start
copy.start:
  %copy = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %length)
  br label %copy.loop
copy.loop:
  %index = phi i64 [ 0, %copy.start ], [ %next, %copy.loop ]
  %source.pointer = getelementptr i8, ptr %data, i64 %index
  %target.pointer = getelementptr i8, ptr %copy, i64 %index
  %byte = load i8, ptr %source.pointer, align 1
  store i8 %byte, ptr %target.pointer, align 1
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %publish.copy, label %copy.loop
publish.copy:
  store ptr %copy, ptr %data.pointer, align 8
  br label %publish.length
publish.empty:
  store ptr null, ptr %data.pointer, align 8
  br label %publish.length
publish.length:
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %stream
}

define internal void @topal.region-instance.namespace-metadata.runtime.serialization.verify(ptr %stream, ptr %expected, i64 %expected.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream.valid = icmp ne ptr %stream, null
  br i1 %stream.valid, label %load, label %failure
load:
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %length.matches = icmp eq i64 %length, %expected.length
  br i1 %length.matches, label %check.empty, label %failure
check.empty:
  %empty = icmp eq i64 %expected.length, 0
  br i1 %empty, label %done, label %check.pointers
check.pointers:
  %data.valid = icmp ne ptr %data, null
  %expected.valid = icmp ne ptr %expected, null
  %pointers.valid = and i1 %data.valid, %expected.valid
  br i1 %pointers.valid, label %loop, label %failure
loop:
  %index = phi i64 [ 0, %check.pointers ], [ %next, %advance ]
  %actual.pointer = getelementptr i8, ptr %data, i64 %index
  %expected.pointer = getelementptr i8, ptr %expected, i64 %index
  %actual.byte = load i8, ptr %actual.pointer, align 1
  %expected.byte = load i8, ptr %expected.pointer, align 1
  %matches = icmp eq i8 %actual.byte, %expected.byte
  br i1 %matches, label %advance, label %failure
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %expected.length
  br i1 %complete, label %done, label %loop
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 70)
  unreachable
done:
  ret void
}

define internal void @topal.region-instance.namespace-metadata.platform.write_all(ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %done, label %loop
loop:
  %offset = phi i64 [0, %entry], [%next, %progress], [%offset, %retry]
  %remaining = sub i64 %length, %offset
  %cursor = getelementptr i8, ptr %buffer, i64 %offset
  %written = call i64 @topal.region-instance.namespace-metadata.platform.write(i64 1, ptr %cursor, i64 %remaining)
  %positive = icmp sgt i64 %written, 0
  br i1 %positive, label %progress, label %error
progress:
  %next = add i64 %offset, %written
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %done, label %loop
error:
  %interrupted = icmp eq i64 %written, -4
  br i1 %interrupted, label %retry, label %failure
retry:
  br label %loop
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 74)
  unreachable
done:
  ret void
}

define internal void @topal.region-instance.namespace-metadata.runtime.u64.print(i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %buffer = alloca [20 x i8], align 1
  %zero = icmp eq i64 %value, 0
  br i1 %zero, label %write.zero, label %convert
write.zero:
  %zero.pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 19
  store i8 48, ptr %zero.pointer, align 1
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr %zero.pointer, i64 1)
  ret void
convert:
  %remaining = phi i64 [ %value, %entry ], [ %quotient, %convert ]
  %position = phi i64 [ 20, %entry ], [ %next.position, %convert ]
  %digit = urem i64 %remaining, 10
  %quotient = udiv i64 %remaining, 10
  %next.position = sub i64 %position, 1
  %pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 %next.position
  %digit.byte = trunc i64 %digit to i8
  %ascii = add i8 %digit.byte, 48
  store i8 %ascii, ptr %pointer, align 1
  %complete = icmp eq i64 %quotient, 0
  br i1 %complete, label %write, label %convert
write:
  %length = sub i64 20, %next.position
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr %pointer, i64 %length)
  ret void
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.string.make(ptr %data, i64 %length, ptr %display, i64 %display.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %string = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 32)
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  store ptr %data, ptr %data.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  store ptr %display, ptr %display.pointer, align 8
  store i64 %display.length, ptr %display.length.pointer, align 8
  ret ptr %string
}

define internal void @topal.region-instance.namespace-metadata.runtime.string.raw.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr %data, i64 %length)
  ret void
}

define internal void @topal.region-instance.namespace-metadata.runtime.string.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  %display = load ptr, ptr %display.pointer, align 8
  %display.length = load i64, ptr %display.length.pointer, align 8
  %cached = icmp ne ptr %display, null
  br i1 %cached, label %write.cached, label %write.dynamic
write.cached:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr %display, i64 %display.length)
  ret void
write.dynamic:
  call void @topal.region-instance.namespace-metadata.runtime.string.dynamic.print(ptr %string)
  ret void
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.string.contains.quote(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %not.found, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %pointer = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %pointer, align 1
  %quote = icmp eq i8 %byte, 34
  br i1 %quote, label %found, label %advance
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %not.found, label %loop
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %minimum = add i64 %underscores, 5
  %possible = icmp ule i64 %minimum, %length
  br i1 %possible, label %search, label %not.found
search:
  %position = phi i64 [ 0, %entry ], [ %next.position, %advance ]
  %remaining = sub i64 %length, %position
  %enough = icmp uge i64 %remaining, %minimum
  br i1 %enough, label %check.base, label %not.found
check.base:
  %quote.pointer = getelementptr i8, ptr %data, i64 %position
  %quote = load i8, ptr %quote.pointer, align 1
  %offset.t0 = add i64 %position, 1
  %offset.e = add i64 %position, 2
  %offset.x = add i64 %position, 3
  %offset.t1 = add i64 %position, 4
  %pointer.t0 = getelementptr i8, ptr %data, i64 %offset.t0
  %pointer.e = getelementptr i8, ptr %data, i64 %offset.e
  %pointer.x = getelementptr i8, ptr %data, i64 %offset.x
  %pointer.t1 = getelementptr i8, ptr %data, i64 %offset.t1
  %byte.t0 = load i8, ptr %pointer.t0, align 1
  %byte.e = load i8, ptr %pointer.e, align 1
  %byte.x = load i8, ptr %pointer.x, align 1
  %byte.t1 = load i8, ptr %pointer.t1, align 1
  %match.quote = icmp eq i8 %quote, 34
  %match.t0 = icmp eq i8 %byte.t0, 116
  %match.e = icmp eq i8 %byte.e, 101
  %match.x = icmp eq i8 %byte.x, 120
  %match.t1 = icmp eq i8 %byte.t1, 116
  %match.0 = and i1 %match.quote, %match.t0
  %match.1 = and i1 %match.0, %match.e
  %match.2 = and i1 %match.1, %match.x
  %match.base = and i1 %match.2, %match.t1
  br i1 %match.base, label %check.underscores, label %advance
check.underscores:
  %underscore.index = phi i64 [ 0, %check.base ], [ %next.underscore, %underscore.advance ]
  %underscores.complete = icmp eq i64 %underscore.index, %underscores
  br i1 %underscores.complete, label %found, label %check.underscore
check.underscore:
  %underscore.offset.base = add i64 %position, 5
  %underscore.offset = add i64 %underscore.offset.base, %underscore.index
  %underscore.pointer = getelementptr i8, ptr %data, i64 %underscore.offset
  %underscore.byte = load i8, ptr %underscore.pointer, align 1
  %match.underscore = icmp eq i8 %underscore.byte, 95
  br i1 %match.underscore, label %underscore.advance, label %advance
underscore.advance:
  %next.underscore = add i64 %underscore.index, 1
  br label %check.underscores
advance:
  %next.position = add i64 %position, 1
  br label %search
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal void @topal.region-instance.namespace-metadata.runtime.string.write.underscores(i64 %count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %done, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.byte.underscore, i64 1)
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %count
  br i1 %complete, label %done, label %loop
done:
  ret void
}

define internal void @topal.region-instance.namespace-metadata.runtime.string.dynamic.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %contains.quote = call i1 @topal.region-instance.namespace-metadata.runtime.string.contains.quote(ptr %data, i64 %length)
  br i1 %contains.quote, label %select.tag, label %plain
plain:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.byte.quote, i64 1)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr %data, i64 %length)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.byte.quote, i64 1)
  ret void
select.tag:
  %underscores = phi i64 [ 0, %entry ], [ %next.underscores, %collision ]
  %collides = call i1 @topal.region-instance.namespace-metadata.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores)
  br i1 %collides, label %collision, label %tagged
collision:
  %next.underscores = add i64 %underscores, 1
  br label %select.tag
tagged:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.string.tag.text, i64 4)
  call void @topal.region-instance.namespace-metadata.runtime.string.write.underscores(i64 %underscores)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.byte.quote, i64 1)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr %data, i64 %length)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.byte.quote, i64 1)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.string.tag.text, i64 4)
  call void @topal.region-instance.namespace-metadata.runtime.string.write.underscores(i64 %underscores)
  ret void
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.string.concat(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %length = add i64 %left.length, %right.length
  %valid = icmp uge i64 %length, %left.length
  br i1 %valid, label %allocate, label %failure
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
allocate:
  %empty = icmp eq i64 %length, 0
  %allocation.length = select i1 %empty, i64 1, i64 %length
  %data = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %allocation.length)
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %data, ptr %left.data, i64 %left.length, i1 false)
  %right.destination = getelementptr i8, ptr %data, i64 %left.length
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %right.destination, ptr %right.data, i64 %right.length, i1 false)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.string.make(ptr %data, i64 %length, ptr null, i64 0)
  ret ptr %result
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.string.is.empty(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  ret i1 %empty
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.string.utf8.byte.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %count = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %length)
  ret ptr %count
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.string.unicode.scalar.value(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  switch i64 %length, label %invalid [
    i64 1, label %one
    i64 2, label %two
    i64 3, label %three
    i64 4, label %four
  ]
one:
  %one.byte = load i8, ptr %data, align 1
  %one.ascii = icmp ult i8 %one.byte, -128
  br i1 %one.ascii, label %one.valid, label %invalid
one.valid:
  %one.value = zext i8 %one.byte to i64
  br label %complete
two:
  %two.byte.0 = load i8, ptr %data, align 1
  %two.pointer.1 = getelementptr i8, ptr %data, i64 1
  %two.byte.1 = load i8, ptr %two.pointer.1, align 1
  %two.lead = and i8 %two.byte.0, -32
  %two.lead.valid = icmp eq i8 %two.lead, -64
  %two.continuation = and i8 %two.byte.1, -64
  %two.continuation.valid = icmp eq i8 %two.continuation, -128
  %two.valid = and i1 %two.lead.valid, %two.continuation.valid
  br i1 %two.valid, label %two.decode, label %invalid
two.decode:
  %two.head.masked = and i8 %two.byte.0, 31
  %two.tail.masked = and i8 %two.byte.1, 63
  %two.head = zext i8 %two.head.masked to i64
  %two.tail = zext i8 %two.tail.masked to i64
  %two.shifted = shl i64 %two.head, 6
  %two.value = or i64 %two.shifted, %two.tail
  br label %complete
three:
  %three.byte.0 = load i8, ptr %data, align 1
  %three.pointer.1 = getelementptr i8, ptr %data, i64 1
  %three.pointer.2 = getelementptr i8, ptr %data, i64 2
  %three.byte.1 = load i8, ptr %three.pointer.1, align 1
  %three.byte.2 = load i8, ptr %three.pointer.2, align 1
  %three.head.masked = and i8 %three.byte.0, 15
  %three.middle.masked = and i8 %three.byte.1, 63
  %three.tail.masked = and i8 %three.byte.2, 63
  %three.head = zext i8 %three.head.masked to i64
  %three.middle = zext i8 %three.middle.masked to i64
  %three.tail = zext i8 %three.tail.masked to i64
  %three.head.shifted = shl i64 %three.head, 12
  %three.middle.shifted = shl i64 %three.middle, 6
  %three.partial = or i64 %three.head.shifted, %three.middle.shifted
  %three.value = or i64 %three.partial, %three.tail
  br label %complete
four:
  %four.byte.0 = load i8, ptr %data, align 1
  %four.pointer.1 = getelementptr i8, ptr %data, i64 1
  %four.pointer.2 = getelementptr i8, ptr %data, i64 2
  %four.pointer.3 = getelementptr i8, ptr %data, i64 3
  %four.byte.1 = load i8, ptr %four.pointer.1, align 1
  %four.byte.2 = load i8, ptr %four.pointer.2, align 1
  %four.byte.3 = load i8, ptr %four.pointer.3, align 1
  %four.head.masked = and i8 %four.byte.0, 7
  %four.second.masked = and i8 %four.byte.1, 63
  %four.third.masked = and i8 %four.byte.2, 63
  %four.tail.masked = and i8 %four.byte.3, 63
  %four.head = zext i8 %four.head.masked to i64
  %four.second = zext i8 %four.second.masked to i64
  %four.third = zext i8 %four.third.masked to i64
  %four.tail = zext i8 %four.tail.masked to i64
  %four.head.shifted = shl i64 %four.head, 18
  %four.second.shifted = shl i64 %four.second, 12
  %four.third.shifted = shl i64 %four.third, 6
  %four.partial.0 = or i64 %four.head.shifted, %four.second.shifted
  %four.partial.1 = or i64 %four.partial.0, %four.third.shifted
  %four.value = or i64 %four.partial.1, %four.tail
  br label %complete
complete:
  %value = phi i64 [ %one.value, %one.valid ], [ %two.value, %two.decode ], [ %three.value, %three ], [ %four.value, %four ]
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %value)
  ret ptr %result
invalid:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.string.unicode.scalar.characters(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  br label %loop
loop:
  %offset = phi i64 [ 0, %entry ], [ %next.offset, %append ]
  %head = phi ptr [ null, %entry ], [ %next.head, %append ]
  %tail = phi ptr [ null, %entry ], [ %node, %append ]
  %complete = icmp eq i64 %offset, %length
  br i1 %complete, label %done, label %decode
decode:
  %byte.pointer = getelementptr i8, ptr %data, i64 %offset
  %byte = load i8, ptr %byte.pointer, align 1
  %ascii = icmp ult i8 %byte, -128
  %two.mask = and i8 %byte, -32
  %two = icmp eq i8 %two.mask, -64
  %three.mask = and i8 %byte, -16
  %three = icmp eq i8 %three.mask, -32
  %non.ascii.width = select i1 %two, i64 2, i64 4
  %multi.width = select i1 %three, i64 3, i64 %non.ascii.width
  %width = select i1 %ascii, i64 1, i64 %multi.width
  %next.offset = add i64 %offset, %width
  %valid = icmp ule i64 %next.offset, %length
  br i1 %valid, label %make, label %invalid
make:
  %character.data = getelementptr i8, ptr %data, i64 %offset
  %character = call ptr @topal.region-instance.namespace-metadata.runtime.string.make(ptr %character.data, i64 %width, ptr null, i64 0)
  %node = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  store ptr %character, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %append, label %link
link:
  %tail.next = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next, align 8
  br label %append
append:
  %next.head = select i1 %empty, ptr %node, ptr %head
  br label %loop
done:
  ret ptr %head
invalid:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.string.select.index.range(ptr %string, ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.region-instance.namespace-metadata.runtime.string.unicode.scalar.characters(ptr %string)
  %empty.data = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 1)
  %empty = call ptr @topal.region-instance.namespace-metadata.runtime.string.make(ptr %empty.data, i64 0, ptr null, i64 0)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %index = phi i64 [ 0, %entry ], [ %next.index, %advance ]
  %selected = phi ptr [ %empty, %entry ], [ %next.selected, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %visit
visit:
  %index.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %index)
  %present = call i1 @topal.region-instance.namespace-metadata.runtime.range.int.contains(ptr %range, ptr %index.value)
  %character = load ptr, ptr %current, align 8
  br i1 %present, label %append, label %skip
append:
  %appended = call ptr @topal.region-instance.namespace-metadata.runtime.string.concat(ptr %selected, ptr %character)
  br label %advance
skip:
  br label %advance
advance:
  %next.selected = phi ptr [ %appended, %append ], [ %selected, %skip ]
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.index = add i64 %index, 1
  br label %loop
done:
  ret ptr %selected
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.string.character.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.region-instance.namespace-metadata.runtime.string.unicode.scalar.characters(ptr %string)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %count = phi i64 [ 0, %entry ], [ %next.count, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.count = add i64 %count, 1
  br label %loop
done:
  %value = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %same.length = icmp eq i64 %left.length, %right.length
  br i1 %same.length, label %loop, label %not.equal
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %complete = icmp eq i64 %index, %left.length
  br i1 %complete, label %equal, label %compare
compare:
  %left.pointer = getelementptr i8, ptr %left.data, i64 %index
  %right.pointer = getelementptr i8, ptr %right.data, i64 %index
  %left.byte = load i8, ptr %left.pointer, align 1
  %right.byte = load i8, ptr %right.pointer, align 1
  %same.byte = icmp eq i8 %left.byte, %right.byte
  br i1 %same.byte, label %advance, label %not.equal
advance:
  %next = add i64 %index, 1
  br label %loop
equal:
  ret i1 true
not.equal:
  ret i1 false
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.result.error(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.result.is.error(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %is.error = icmp eq i64 %tag, 1
  ret i1 %is.error
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.result.payload(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.optional.none() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid
checked:
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some
invalid:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 70)
  unreachable
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.optional.from.nullable(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %present = icmp ne ptr %payload, null
  br i1 %present, label %some, label %none
some:
  %some.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none.value
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.optional.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.optional.rational.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.rational.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.optional.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %right)
  %payloads.equal = call i1 @topal.region-instance.namespace-metadata.runtime.string.equal(ptr %left.payload, ptr %right.payload)
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 56)
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %reserved.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 2
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  store ptr %domain, ptr %domain.pointer, align 8
  store i32 %code, ptr %code.pointer, align 4
  store i32 0, ptr %reserved.pointer, align 4
  store ptr null, ptr %detail.pointer, align 8
  store ptr null, ptr %cause.pointer, align 8
  store ptr %source, ptr %source.pointer, align 8
  store i64 %line, ptr %line.pointer, align 8
  store i64 %column, ptr %column.pointer, align 8
  ret ptr %error
}

define internal i32 @topal.region-instance.namespace-metadata.runtime.error.code(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %code = load i32, ptr %code.pointer, align 4
  ret i32 %code
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.error.domain(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %domain = load ptr, ptr %domain.pointer, align 8
  ret ptr %domain
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.error.detail(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %detail = load ptr, ptr %detail.pointer, align 8
  %optional = call ptr @topal.region-instance.namespace-metadata.runtime.optional.from.nullable(ptr %detail)
  ret ptr %optional
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.error.cause(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %cause = load ptr, ptr %cause.pointer, align 8
  %optional = call ptr @topal.region-instance.namespace-metadata.runtime.optional.from.nullable(ptr %cause)
  ret ptr %optional
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.error.source(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %source = load ptr, ptr %source.pointer, align 8
  %present = icmp ne ptr %source, null
  br i1 %present, label %some, label %none
some:
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  %line.number = load i64, ptr %line.pointer, align 8
  %column.number = load i64, ptr %column.pointer, align 8
  %line = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %line.number)
  %column = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %column.number)
  %location = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %location.line = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %location.column = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  store ptr %line, ptr %location.line, align 8
  store ptr %column, ptr %location.column, align 8
  %some.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %location)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.source.location.line(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %line.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %line = load ptr, ptr %line.pointer, align 8
  ret ptr %line
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.source.location.column(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %column.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  %column = load ptr, ptr %column.pointer, align 8
  ret ptr %column
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.region-instance.namespace-metadata.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.error(ptr %error)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.try.to.nat(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %success
failure:
  %failed = call ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 0, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %value)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.try.to.int(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %value)
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %denominator, ptr @topal.region-instance.namespace-metadata.runtime.int.one)
  %exact = icmp eq i32 %ordering, 0
  br i1 %exact, label %success, label %failure
failure:
  %failed = call ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 1, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %value)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %numerator)
  ret ptr %result
}

define internal void @topal.region-instance.namespace-metadata.runtime.error.print(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %domain = load ptr, ptr %domain.pointer, align 8
  %code = load i32, ptr %code.pointer, align 4
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.error.prefix, i64 18)
  call void @topal.region-instance.namespace-metadata.runtime.string.raw.print(ptr %domain)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.error.code.separator, i64 10)
  call void @topal.region-instance.namespace-metadata.runtime.error.code.print(i32 %code)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.error.suffix, i64 2)
  ret void
}

define internal void @topal.region-instance.namespace-metadata.runtime.error.code.print(i32 %code) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  switch i32 %code, label %indeterminate [ i32 0, label %out.of.range i32 1, label %not.representable i32 2, label %division.by.zero ]
out.of.range:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.error.code.out.of.range, i64 12)
  br label %done
not.representable:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.error.code.not.representable, i64 17)
  br label %done
division.by.zero:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.error.code.division.by.zero, i64 16)
  br label %done
indeterminate:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.error.code.indeterminate, i64 13)
  br label %done
done:
  ret void
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure
allocate:
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero
zero:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero
nonzero:
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done
store.high:
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done
done:
  ret ptr %value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.from.i64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = icmp slt i64 %source, 0
  %negated = sub i64 0, %source
  %magnitude = select i1 %negative, i64 %negated, i64 %source
  %value = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %magnitude)
  br i1 %negative, label %signed, label %done
signed:
  %negative.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %value, i64 1)
  ret ptr %negative.value
done:
  ret ptr %value
}

define internal i32 @topal.region-instance.namespace-metadata.runtime.int.to.c.i32(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %sign = load i64, ptr %sign.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %return.zero, label %nonzero
return.zero:
  ret i32 0
nonzero:
  %one.limb = icmp eq i64 %length, 1
  %finite.sign = icmp ule i64 %sign, 1
  %shape.valid = and i1 %one.limb, %finite.sign
  br i1 %shape.valid, label %load, label %failure
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %limb = load i32, ptr %limb.pointer, align 4
  %negative = icmp eq i64 %sign, 1
  %positive.valid = icmp ule i32 %limb, 2147483647
  %negative.valid = icmp ule i32 %limb, 2147483648
  %range.valid = select i1 %negative, i1 %negative.valid, i1 %positive.valid
  br i1 %range.valid, label %convert, label %failure
convert:
  %negated = sub i32 0, %limb
  %result = select i1 %negative, i32 %negated, i32 %limb
  ret i32 %result
failure:
  call void @topal.region-instance.namespace-metadata.runtime.c.int32.range.fail()
  unreachable
}

define internal i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended
zero:
  ret i64 0
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim
trim:
  %candidate = phi i64 [%length, %entry], [%next, %leading.zero]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done
leading.zero:
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim
zero:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value
done:
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %value, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate
zero:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero
allocate:
  %copy = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %allocate], [%next, %loop]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  ret ptr %copy
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.negative.infinity
negative.infinity:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.positive.infinity
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %copy
zero:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero
copy:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %opposite = xor i64 %negative, 1
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %value, i64 %opposite)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite
infinite:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.positive.infinity
finite:
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy
same:
  ret ptr %value
copy:
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

define internal i32 @topal.region-instance.namespace-metadata.runtime.int.compare.absolute(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer
check.longer:
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty
check.empty:
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs
limbs:
  %position = phi i64 [%left.length, %check.empty], [%index, %limbs.equal]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater
check.limb.greater:
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal
limbs.equal:
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal
less:
  ret i32 -1
equal:
  ret i32 0
greater:
  ret i32 1
}

define internal i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity
left.positive:
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result
check.left.negative.infinity:
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity
left.negative:
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result
check.right.positive.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity
check.right.negative.infinity:
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite
less:
  ret i32 -1
greater:
  ret i32 1
finite:
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute
signed.result:
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result
absolute:
  %magnitude = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %carry = phi i64 [0, %entry], [%next.carry, %loop]
  %left.limb = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish
finish:
  %final.carry = phi i64 [0, %entry], [%next.carry, %loop]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry
store.carry:
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result
without.carry:
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %borrow = phi i64 [0, %entry], [%next.borrow, %loop]
  %left = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.region-instance.namespace-metadata.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  %normalized = call ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity
validate.left.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity
indeterminate.infinity:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 70)
  unreachable
return.left.infinity:
  ret ptr %left
check.right.infinity:
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite
return.right.infinity:
  ret ptr %right
finite:
  %left.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right
return.right:
  ret ptr %right
check.right:
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero
return.left:
  ret ptr %left
nonzero:
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference
sum:
  %sum.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value
difference:
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger
zero:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero
select.larger:
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference
left.difference:
  %left.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value
right.difference:
  %right.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %opposite = call ptr @topal.region-instance.namespace-metadata.runtime.int.negate(ptr %right)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %left, ptr %opposite)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %left.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity
indeterminate.infinity:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 70)
  unreachable
select.infinity:
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.region-instance.namespace-metadata.runtime.int.negative.infinity, ptr @topal.region-instance.namespace-metadata.runtime.int.positive.infinity
  ret ptr %infinity
finite:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length
zero:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.zero
check.length:
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
allocate:
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear
clear:
  %clear.index = phi i64 [0, %allocate], [%clear.next, %clear]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry
outer.entry:
  br label %outer
outer:
  %left.index = phi i64 [0, %outer.entry], [%left.next, %outer.done]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner
inner:
  %right.index = phi i64 [0, %outer], [%right.next, %inner]
  %carry = phi i64 [0, %outer], [%next.carry, %inner]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done
outer.done:
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done
done:
  %normalized = call ptr @topal.region-instance.namespace-metadata.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal void @topal.region-instance.namespace-metadata.runtime.int.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.int.positive.infinity.text, i64 9)
  ret void
negative.infinity:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.int.negative.infinity.text, i64 9)
  ret void
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check.sign
zero:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.byte.zero, i64 1)
  ret void
check.sign:
  %is.negative = icmp ne i64 %sign, 0
  br i1 %is.negative, label %write.sign, label %prepare
write.sign:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.byte.minus, i64 1)
  br label %prepare
prepare:
  %capacity.valid = icmp ule i64 %length, 922337203685477580
  br i1 %capacity.valid, label %allocate, label %failure
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
allocate:
  %scratch.bytes = mul i64 %length, 4
  %capacity = mul i64 %length, 10
  %scratch = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %scratch.bytes)
  %buffer = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %capacity)
  br label %copy
copy:
  %copy.index = phi i64 [0, %allocate], [%copy.next, %copy]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %copy.index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr i32, ptr %scratch, i64 %copy.index
  store i32 %limb, ptr %destination, align 4
  %copy.next = add i64 %copy.index, 1
  %copy.more = icmp ult i64 %copy.next, %length
  br i1 %copy.more, label %copy, label %digits
digits:
  %work.length = phi i64 [%length, %copy], [%next.length, %division.finish]
  %position = phi i64 [%capacity, %copy], [%next.position, %division.finish]
  br label %divide
divide:
  %division.position = phi i64 [%work.length, %digits], [%division.index, %divide.step]
  %remainder = phi i64 [0, %digits], [%next.remainder, %divide.step]
  %division.index = sub i64 %division.position, 1
  %work.pointer = getelementptr i32, ptr %scratch, i64 %division.index
  %work.raw = load i32, ptr %work.pointer, align 4
  %work = zext i32 %work.raw to i64
  %high = shl i64 %remainder, 32
  %current = or i64 %high, %work
  %quotient = udiv i64 %current, 10
  %next.remainder = urem i64 %current, 10
  %quotient.limb = trunc i64 %quotient to i32
  store i32 %quotient.limb, ptr %work.pointer, align 4
  %division.more = icmp ne i64 %division.index, 0
  br i1 %division.more, label %divide.step, label %division.done
divide.step:
  br label %divide
division.done:
  %next.position = sub i64 %position, 1
  %digit = trunc i64 %next.remainder to i8
  %ascii = add i8 %digit, 48
  %digit.pointer = getelementptr i8, ptr %buffer, i64 %next.position
  store i8 %ascii, ptr %digit.pointer, align 1
  br label %trim
trim:
  %candidate = phi i64 [%work.length, %division.done], [%trim.next, %trim.zero]
  %trim.index = sub i64 %candidate, 1
  %trim.pointer = getelementptr i32, ptr %scratch, i64 %trim.index
  %trim.limb = load i32, ptr %trim.pointer, align 4
  %leading.zero = icmp eq i32 %trim.limb, 0
  br i1 %leading.zero, label %trim.zero, label %trim.done
trim.zero:
  %trim.next = sub i64 %candidate, 1
  %trim.empty = icmp eq i64 %trim.next, 0
  br i1 %trim.empty, label %trim.empty.done, label %trim
trim.empty.done:
  br label %division.finish
trim.done:
  br label %division.finish
division.finish:
  %next.length = phi i64 [0, %trim.empty.done], [%candidate, %trim.done]
  %more.digits = icmp ne i64 %next.length, 0
  br i1 %more.digits, label %digits, label %emit
emit:
  %count = sub i64 %capacity, %next.position
  %first = getelementptr i8, ptr %buffer, i64 %next.position
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr %first, i64 %count)
  ret void
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.pair(ptr %quotient, ptr %remainder) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %quotient.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %remainder.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  store ptr %quotient, ptr %quotient.pointer, align 8
  store ptr %remainder, ptr %remainder.pointer, align 8
  ret ptr %pair
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.quotient(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.remainder(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i64 @topal.region-instance.namespace-metadata.runtime.int.bit.length(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check
zero:
  ret i64 0
check:
  %valid = icmp ule i64 %length, 576460752303423487
  br i1 %valid, label %calculate, label %failure
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 71)
  unreachable
calculate:
  %last = sub i64 %length, 1
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %last
  %limb = load i32, ptr %pointer, align 4
  %leading = call i32 @llvm.ctlz.i32(i32 %limb, i1 false)
  %top.bits.raw = sub i32 32, %leading
  %top.bits = zext i32 %top.bits.raw to i64
  %lower.bits = mul i64 %last, 32
  %bits = add i64 %lower.bits, %top.bits
  ret i64 %bits
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.int.bit.at(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %limb.index = lshr i64 %index, 5
  %offset.raw = and i64 %index, 31
  %offset = trunc i64 %offset.raw to i32
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %limb.index
  %limb = load i32, ptr %pointer, align 4
  %shifted = lshr i32 %limb, %offset
  %bit.raw = and i32 %shifted, 1
  %bit = icmp ne i32 %bit.raw, 0
  ret i1 %bit
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.absolute(ptr %dividend, ptr %divisor) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %divisor.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %divisor)
  br i1 %divisor.zero, label %failure, label %check.dividend
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
check.dividend:
  %dividend.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %dividend)
  br i1 %dividend.zero, label %zero, label %prepare
zero:
  %zero.pair = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.pair(ptr @topal.region-instance.namespace-metadata.runtime.int.zero, ptr @topal.region-instance.namespace-metadata.runtime.int.zero)
  ret ptr %zero.pair
prepare:
  %bits = call i64 @topal.region-instance.namespace-metadata.runtime.int.bit.length(ptr %dividend)
  br label %loop
loop:
  %position = phi i64 [%bits, %prepare], [%next.position, %merge]
  %quotient = phi ptr [@topal.region-instance.namespace-metadata.runtime.int.zero, %prepare], [%next.quotient, %merge]
  %remainder = phi ptr [@topal.region-instance.namespace-metadata.runtime.int.zero, %prepare], [%next.remainder, %merge]
  %bit.index = sub i64 %position, 1
  %bit = call i1 @topal.region-instance.namespace-metadata.runtime.int.bit.at(ptr %dividend, i64 %bit.index)
  %quotient.twice = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %quotient, ptr %quotient)
  %remainder.twice = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %remainder, ptr %remainder)
  br i1 %bit, label %append.bit, label %compare
append.bit:
  %remainder.with.bit = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %remainder.twice, ptr @topal.region-instance.namespace-metadata.runtime.int.one)
  br label %compare
compare:
  %candidate = phi ptr [%remainder.twice, %loop], [%remainder.with.bit, %append.bit]
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare.absolute(ptr %candidate, ptr %divisor)
  %subtract = icmp sge i32 %ordering, 0
  br i1 %subtract, label %subtract.divisor, label %retain
subtract.divisor:
  %reduced = call ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %candidate, ptr %divisor, i64 0)
  %incremented = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %quotient.twice, ptr @topal.region-instance.namespace-metadata.runtime.int.one)
  br label %merge
retain:
  br label %merge
merge:
  %next.quotient = phi ptr [%incremented, %subtract.divisor], [%quotient.twice, %retain]
  %next.remainder = phi ptr [%reduced, %subtract.divisor], [%candidate, %retain]
  %next.position = sub i64 %position, 1
  %more = icmp ne i64 %next.position, 0
  br i1 %more, label %loop, label %done
done:
  %pair = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.pair(ptr %next.quotient, ptr %next.remainder)
  ret ptr %pair
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.quotient.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %divide
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
divide:
  %left.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %right)
  %unsigned = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.absolute(ptr %left.absolute, ptr %right.absolute)
  %quotient.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.quotient(ptr %unsigned)
  %remainder.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.remainder(ptr %unsigned)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.negative = icmp ne i64 %left.sign, 0
  %remainder.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %remainder.absolute)
  %remainder.present = xor i1 %remainder.zero, true
  %needs.adjustment = and i1 %left.negative, %remainder.present
  %quotient.sign = xor i64 %left.sign, %right.sign
  br i1 %needs.adjustment, label %adjust, label %direct
direct:
  %direct.quotient = call ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %quotient.absolute, i64 %quotient.sign)
  %direct.pair = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.pair(ptr %direct.quotient, ptr %remainder.absolute)
  ret ptr %direct.pair
adjust:
  %larger.quotient = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %quotient.absolute, ptr @topal.region-instance.namespace-metadata.runtime.int.one)
  %adjusted.quotient = call ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %larger.quotient, i64 %quotient.sign)
  %adjusted.remainder = call ptr @topal.region-instance.namespace-metadata.runtime.int.subtract.absolute(ptr %right.absolute, ptr %remainder.absolute, i64 0)
  %adjusted.pair = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.pair(ptr %adjusted.quotient, ptr %adjusted.remainder)
  ret ptr %adjusted.pair
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.region-instance.namespace-metadata.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %remainder = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.remainder(ptr %pair)
  ret ptr %remainder
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.try.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %remainder = call ptr @topal.region-instance.namespace-metadata.runtime.int.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %remainder)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.try.quotient.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %pair = call ptr @topal.region-instance.namespace-metadata.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %pair)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %prepare
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
prepare:
  %bits = call i64 @topal.region-instance.namespace-metadata.runtime.int.bit.length(ptr %exponent)
  %empty = icmp eq i64 %bits, 0
  br i1 %empty, label %one, label %loop
one:
  ret ptr @topal.region-instance.namespace-metadata.runtime.int.one
loop:
  %position = phi i64 [0, %prepare], [%next.position, %square]
  %result = phi ptr [@topal.region-instance.namespace-metadata.runtime.int.one, %prepare], [%next.result, %square]
  %factor = phi ptr [%base, %prepare], [%next.factor, %square]
  %bit = call i1 @topal.region-instance.namespace-metadata.runtime.int.bit.at(ptr %exponent, i64 %position)
  br i1 %bit, label %multiply, label %retain
multiply:
  %product = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %result, ptr %factor)
  br label %advance
retain:
  br label %advance
advance:
  %next.result = phi ptr [%product, %multiply], [%result, %retain]
  %next.position = add i64 %position, 1
  %complete = icmp eq i64 %next.position, %bits
  br i1 %complete, label %done, label %square
square:
  %next.factor = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %factor, ptr %factor)
  br label %loop
done:
  ret ptr %next.result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.int.greatest.common.divisor(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %right)
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right.absolute)
  br i1 %right.zero, label %initial.done, label %loop
initial.done:
  ret ptr %left.absolute
loop:
  %current.left = phi ptr [%left.absolute, %entry], [%current.right, %again]
  %current.right = phi ptr [%right.absolute, %entry], [%remainder, %again]
  %division = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.absolute(ptr %current.left, ptr %current.right)
  %remainder = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.remainder(ptr %division)
  %done = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %remainder)
  br i1 %done, label %result, label %again
again:
  br label %loop
result:
  ret ptr %current.right
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %numerator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %denominator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  store ptr %numerator, ptr %numerator.pointer, align 8
  store ptr %denominator, ptr %denominator.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %numerator = load ptr, ptr %pointer, align 8
  ret ptr %numerator
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  %denominator = load ptr, ptr %pointer, align 8
  ret ptr %denominator
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.make(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %numerator.sign = load i64, ptr %numerator.sign.pointer, align 8
  %positive.infinity = icmp eq i64 %numerator.sign, 2
  %negative.infinity = icmp eq i64 %numerator.sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %make.infinity, label %finite
make.infinity:
  %infinite.value = call ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr %numerator, ptr @topal.region-instance.namespace-metadata.runtime.int.one)
  ret ptr %infinite.value
finite:
  %denominator.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %check.numerator
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
check.numerator:
  %numerator.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %numerator)
  br i1 %numerator.zero, label %zero, label %normalize
zero:
  %zero.value = call ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr @topal.region-instance.namespace-metadata.runtime.int.zero, ptr @topal.region-instance.namespace-metadata.runtime.int.one)
  ret ptr %zero.value
normalize:
  %numerator.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %numerator)
  %denominator.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %denominator)
  %divisor = call ptr @topal.region-instance.namespace-metadata.runtime.int.greatest.common.divisor(ptr %numerator.absolute, ptr %denominator.absolute)
  %numerator.division = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.absolute(ptr %numerator.absolute, ptr %divisor)
  %denominator.division = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.absolute(ptr %denominator.absolute, ptr %divisor)
  %reduced.numerator.absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.quotient(ptr %numerator.division)
  %reduced.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.int.divmod.quotient(ptr %denominator.division)
  %finite.numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %finite.denominator.sign.pointer = getelementptr %topal.IntStorage, ptr %denominator, i32 0, i32 0
  %finite.numerator.sign = load i64, ptr %finite.numerator.sign.pointer, align 8
  %finite.denominator.sign = load i64, ptr %finite.denominator.sign.pointer, align 8
  %sign = xor i64 %finite.numerator.sign, %finite.denominator.sign
  %reduced.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.int.copy.with.sign(ptr %reduced.numerator.absolute, i64 %sign)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr %reduced.numerator, ptr %reduced.denominator)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.from.int(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr %value, ptr @topal.region-instance.namespace-metadata.runtime.int.one)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %value)
  %negative = call ptr @topal.region-instance.namespace-metadata.runtime.int.negate(ptr %numerator)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr %negative, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %value)
  %absolute = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %numerator)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr %absolute, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %right)
  %left.scaled = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %left.scaled, ptr %right.scaled)
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = call ptr @topal.region-instance.namespace-metadata.runtime.rational.negate(ptr %right)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.add(ptr %left, ptr %negative)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %right)
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left.numerator, ptr %right.numerator)
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.divide(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %right)
  %zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right.numerator)
  br i1 %zero, label %failure, label %calculate
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
calculate:
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left.denominator, ptr %right.numerator)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal i32 @topal.region-instance.namespace-metadata.runtime.rational.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %right)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left.numerator, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right.numerator, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %infinite.result = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left.numerator, ptr %right.numerator)
  ret i32 %infinite.result
finite:
  %left.scaled = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %result = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left.scaled, ptr %right.scaled)
  ret i32 %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %base)
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %base)
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  %absolute.exponent = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %exponent)
  %powered.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.int.power(ptr %numerator, ptr %absolute.exponent)
  %powered.denominator = call ptr @topal.region-instance.namespace-metadata.runtime.int.power(ptr %denominator, ptr %absolute.exponent)
  br i1 %negative, label %reciprocal, label %direct
direct:
  %direct.result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.raw(ptr %powered.numerator, ptr %powered.denominator)
  ret ptr %direct.result
reciprocal:
  %zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %powered.numerator)
  br i1 %zero, label %failure, label %invert
failure:
  call void @topal.region-instance.namespace-metadata.platform.exit(i64 65)
  unreachable
invert:
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.rational.make(ptr %powered.denominator, ptr %powered.numerator)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.try.make(ptr %numerator, ptr %denominator, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %success
failure:
  %numerator.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %numerator)
  %code = select i1 %numerator.zero, i32 3, i32 2
  %failed = call ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.region-instance.namespace-metadata.runtime.rational.make(ptr %numerator, ptr %denominator)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.try.divide(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %right)
  %right.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %right.numerator)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.region-instance.namespace-metadata.runtime.rational.divide(ptr %left, ptr %right)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.rational.try.power(ptr %base, ptr %exponent, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  br i1 %negative, label %check.base, label %success
check.base:
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %base)
  %base.zero = call i1 @topal.region-instance.namespace-metadata.runtime.int.is.zero(ptr %numerator)
  br i1 %base.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.region-instance.namespace-metadata.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.region-instance.namespace-metadata.runtime.rational.power(ptr %base, ptr %exponent)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal void @topal.region-instance.namespace-metadata.runtime.rational.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.region-instance.namespace-metadata.runtime.rational.denominator(ptr %value)
  %sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %positive.infinity = icmp eq i64 %sign, 2
  %negative.infinity = icmp eq i64 %sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %print.infinity, label %print.finite
print.infinity:
  call void @topal.region-instance.namespace-metadata.runtime.int.print(ptr %numerator)
  ret void
print.finite:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.rational.prefix, i64 11)
  call void @topal.region-instance.namespace-metadata.runtime.int.print(ptr %numerator)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.rational.separator, i64 2)
  call void @topal.region-instance.namespace-metadata.runtime.int.print(ptr %denominator)
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.rational.suffix, i64 2)
  ret void
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.range.make(ptr %lower, ptr %upper, i64 %lower.inclusive, i64 %upper.inclusive) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 32)
  %lower.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 0
  %upper.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 1
  %lower.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 2
  %upper.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 3
  store ptr %lower, ptr %lower.pointer, align 8
  store ptr %upper, ptr %upper.pointer, align 8
  store i64 %lower.inclusive, ptr %lower.inclusive.pointer, align 8
  store i64 %upper.inclusive, ptr %upper.inclusive.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %left)
  %right.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %right)
  %lower.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %left)
  %right.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %right)
  %upper.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %bounds.equal = and i1 %lower.equal, %upper.equal
  %left.lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %right)
  %lower.inclusive.equal = icmp eq i1 %left.lower.inclusive, %right.lower.inclusive
  %left.upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %left)
  %right.upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %right)
  %upper.inclusive.equal = icmp eq i1 %left.upper.inclusive, %right.upper.inclusive
  %inclusivity.equal = and i1 %lower.inclusive.equal, %upper.inclusive.equal
  %equal = and i1 %bounds.equal, %inclusivity.equal
  ret i1 %equal
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 2
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 3
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.empty.from.comparison(ptr %range, i32 %ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %reversed = icmp sgt i32 %ordering, 0
  %equal = icmp eq i32 %ordering, 0
  %lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %range)
  %both.inclusive = and i1 %lower.inclusive, %upper.inclusive
  %open.equal = xor i1 %both.inclusive, true
  %empty.equal = and i1 %equal, %open.equal
  %empty = or i1 %reversed, %empty.equal
  ret i1 %empty
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.int.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.region-instance.namespace-metadata.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.rational.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.rational.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.region-instance.namespace-metadata.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.int.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.range.rational.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.rational.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.rational.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %right)
  %left.lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %left)
  %left.upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %right)
  %right.upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %right)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.lower.stricter = icmp sgt i32 %lower.ordering, 0
  %selected.lower = select i1 %left.lower.stricter, ptr %left.lower, ptr %right.lower
  %selected.lower.inclusive = select i1 %left.lower.stricter, i1 %left.lower.inclusive, i1 %right.lower.inclusive
  %equal.lower.inclusive = and i1 %left.lower.inclusive, %right.lower.inclusive
  %lower.inclusive = select i1 %lower.equal, i1 %equal.lower.inclusive, i1 %selected.lower.inclusive
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %left.upper.stricter = icmp slt i32 %upper.ordering, 0
  %selected.upper = select i1 %left.upper.stricter, ptr %left.upper, ptr %right.upper
  %selected.upper.inclusive = select i1 %left.upper.stricter, i1 %left.upper.inclusive, i1 %right.upper.inclusive
  %equal.upper.inclusive = and i1 %left.upper.inclusive, %right.upper.inclusive
  %upper.inclusive = select i1 %upper.equal, i1 %equal.upper.inclusive, i1 %selected.upper.inclusive
  %lower.inclusive.raw = zext i1 %lower.inclusive to i64
  %upper.inclusive.raw = zext i1 %upper.inclusive to i64
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.range.make(ptr %selected.lower, ptr %selected.upper, i64 %lower.inclusive.raw, i64 %upper.inclusive.raw)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.range.int.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.range.rational.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.rational.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.region-instance.namespace-metadata.runtime.rational.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.region-instance.namespace-metadata.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal void @topal.region-instance.namespace-metadata.runtime.range.print.symbol(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.region-instance.namespace-metadata.runtime.range.upper.inclusive(ptr %range)
  br i1 %lower.inclusive, label %lower.closed, label %lower.open
lower.closed:
  br i1 %upper.inclusive, label %closed.closed, label %closed.open
lower.open:
  br i1 %upper.inclusive, label %open.closed, label %open.open
closed.closed:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.range.closed.closed, i64 5)
  ret void
closed.open:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.range.closed.open, i64 4)
  ret void
open.closed:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.range.open.closed, i64 6)
  ret void
open.open:
  call void @topal.region-instance.namespace-metadata.platform.write_all(ptr @topal.region-instance.namespace-metadata.runtime.range.open.open, i64 5)
  ret void
}

define internal void @topal.region-instance.namespace-metadata.runtime.range.int.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %range)
  call void @topal.region-instance.namespace-metadata.runtime.int.print(ptr %lower)
  call void @topal.region-instance.namespace-metadata.runtime.range.print.symbol(ptr %range)
  call void @topal.region-instance.namespace-metadata.runtime.int.print(ptr %upper)
  ret void
}

define internal void @topal.region-instance.namespace-metadata.runtime.range.rational.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.region-instance.namespace-metadata.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.region-instance.namespace-metadata.runtime.range.upper(ptr %range)
  call void @topal.region-instance.namespace-metadata.runtime.rational.print(ptr %lower)
  call void @topal.region-instance.namespace-metadata.runtime.range.print.symbol(ptr %range)
  call void @topal.region-instance.namespace-metadata.runtime.rational.print(ptr %upper)
  ret void
}
; Compiler-selected List Int layout for private topal-native/6 operations.

%topal.ListStorage = type { ptr, ptr }
; Compiler-private fundamental homogeneous containers. Construction may mutate
; unpublished result nodes; published Array, Set, Bag, and Map values are immutable.

%topal.ContainerSequenceHeader = type { i64, ptr }
%topal.ContainerBagHeader = type { i64, i64, ptr }
%topal.ContainerBagNode = type { ptr, i64, ptr }
%topal.ContainerMapNode = type { ptr, ptr, ptr }

define internal i64 @topal.region-instance.namespace-metadata.runtime.container.list.count(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop
done:
  ret i64 %count
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.array.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.region-instance.namespace-metadata.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.array.function.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.region-instance.namespace-metadata.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.container.int.list.contains(ptr %list, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret i1 true
absent:
  ret i1 false
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.set.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %duplicate = call i1 @topal.region-instance.namespace-metadata.runtime.container.int.list.contains(ptr %head, ptr %value)
  br i1 %duplicate, label %skip, label %add
add:
  %node = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  store ptr %value, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
skip:
  br label %advance
advance:
  %head.next = phi ptr [%head, %skip], [%added.head, %added]
  %tail.next = phi ptr [%tail, %skip], [%node, %added]
  %count.next = phi i64 [%count, %skip], [%added.count, %added]
  br label %loop
done:
  %set = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %set.count = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 0
  %set.entries = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  store i64 %count, ptr %set.count, align 8
  store ptr %head, ptr %set.entries, align 8
  ret ptr %set
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.bag.int.find(ptr %entries, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerBagNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.bag.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %total = phi i64 [0, %entry], [%total.next, %advance]
  %distinct = phi i64 [0, %entry], [%distinct.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.region-instance.namespace-metadata.runtime.container.bag.int.find(ptr %head, ptr %value)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %increment, label %add
increment:
  %existing.count.pointer = getelementptr %topal.ContainerBagNode, ptr %existing, i32 0, i32 1
  %existing.count = load i64, ptr %existing.count.pointer, align 8
  %incremented = add i64 %existing.count, 1
  store i64 %incremented, ptr %existing.count.pointer, align 8
  br label %advance
add:
  %node = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 24)
  %node.value = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 0
  %node.count = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 2
  store ptr %value, ptr %node.value, align 8
  store i64 1, ptr %node.count, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerBagNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.distinct = add i64 %distinct, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %increment], [%added.head, %added]
  %tail.next = phi ptr [%tail, %increment], [%node, %added]
  %distinct.next = phi i64 [%distinct, %increment], [%added.distinct, %added]
  %total.next = add i64 %total, 1
  br label %loop
done:
  %bag = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 24)
  %bag.total = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 0
  %bag.distinct = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 1
  %bag.entries = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  store i64 %total, ptr %bag.total, align 8
  store i64 %distinct, ptr %bag.distinct, align 8
  store ptr %head, ptr %bag.entries, align 8
  ret ptr %bag
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-int.find(ptr %entries, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %equal = call i1 @topal.region-instance.namespace-metadata.runtime.string.equal(ptr %candidate, ptr %key)
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerMapNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-int.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load ptr, ptr %source.value.pointer, align 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store ptr %value, ptr %existing.value, align 8
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store ptr %value, ptr %node.value, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-function.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load i32, ptr %source.value.pointer, align 4
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store i32 %value, ptr %existing.value, align 4
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store i32 %value, ptr %node.value, align 4
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.entry.count(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %value = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.container.empty(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %empty = icmp eq i64 %count, 0
  ret i1 %empty
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.array.int.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load ptr, ptr %current, align 8
  %some = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %value)
  ret ptr %some
absent:
  %none = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.array.function.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load i32, ptr %current, align 4
  %payload = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %payload)
  ret ptr %some
absent:
  %none = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.region-instance.namespace-metadata.runtime.container.set.int.contains(ptr %set, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %present = call i1 @topal.region-instance.namespace-metadata.runtime.container.int.list.contains(ptr %entries, ptr %value)
  ret i1 %present
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.bag.int.multiplicity(ptr %bag, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.region-instance.namespace-metadata.runtime.container.bag.int.find(ptr %entries, ptr %value)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %zero, label %present
zero:
  %zero.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 0)
  ret ptr %zero.value
present:
  %count.pointer = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %count = load i64, ptr %count.pointer, align 8
  %count.value = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %count)
  ret ptr %count.value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-int.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load ptr, ptr %value.pointer, align 8
  %some.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %value)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-function.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.region-instance.namespace-metadata.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load i32, ptr %value.pointer, align 4
  %payload = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none.value
}
; Qualified hooks for the explicitly owned root-region invocation.
; No process/GS context, address or allocator function is exposed to source.
declare ptr @topal_kernel_region_frame_namespace_metadata_allocate_v1(i64)
declare void @topal_kernel_region_frame_namespace_metadata_abort_v1() noreturn

define internal ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = call ptr @topal_kernel_region_frame_namespace_metadata_allocate_v1(i64 %length)
  ret ptr %pointer
}

define internal void @topal.region-instance.namespace-metadata.platform.exit(i64 %status) noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_region_frame_namespace_metadata_abort_v1()
  unreachable
}

define internal i64 @topal.region-instance.namespace-metadata.platform.write(i64 %fd, ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_region_frame_namespace_metadata_abort_v1()
  unreachable
}
; Private source-object ABI. The caller supplies live, mapped, disjoint owner,
; control and temporary storage. These words are not source authority.
; Control: code, owner, generation, active, base, count, writable, issued views.
; View: control, offset, count, writable, generation, owner, code, zero.
%topal.KernelRegionControl = type { ptr, i64, i64, i64, ptr, i64, i64, i64 }
%topal.KernelRegionView = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }

define internal void @topal.region-instance.namespace-metadata.primitive.abort() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_kernel_region_frame_namespace_metadata_abort_v1()
  unreachable
}

; Returns a contained byte pointer only after complete view/control validation.
; The generated closed source graph proves view pointer provenance/nonescape.
define internal ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %address = ptrtoint ptr %view to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %valid.pointer = and i1 %nonnull, %aligned
  br i1 %valid.pointer, label %view.fields, label %invalid
view.fields:
  %control = load ptr, ptr %view, align 8
  %control.address = ptrtoint ptr %control to i64
  %control.nonnull = icmp ne i64 %control.address, 0
  %control.alignment = and i64 %control.address, 7
  %control.aligned = icmp eq i64 %control.alignment, 0
  %control.valid = and i1 %control.nonnull, %control.aligned
  br i1 %control.valid, label %control.fields, label %invalid
control.fields:
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %view.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %view.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %view.epoch.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 4
  %view.owner.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 5
  %view.code.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 6
  %view.zero.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 7
  %offset = load i64, ptr %offset.pointer, align 8
  %view.count = load i64, ptr %view.count.pointer, align 8
  %view.rights = load i64, ptr %view.rights.pointer, align 8
  %view.epoch = load i64, ptr %view.epoch.pointer, align 8
  %view.owner = load i64, ptr %view.owner.pointer, align 8
  %view.code = load ptr, ptr %view.code.pointer, align 8
  %view.zero = load i64, ptr %view.zero.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_namespace_metadata_apply_v1
  %view.code.valid = icmp eq ptr %view.code, %code
  %owner.valid = icmp ne i64 %owner, 0
  %view.owner.valid = icmp eq i64 %view.owner, %owner
  %epoch.valid = icmp ne i64 %epoch, 0
  %view.epoch.valid = icmp eq i64 %view.epoch, %epoch
  %active.valid = icmp eq i64 %active, 1
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %view.rights.valid = icmp ule i64 %view.rights, %rights
  %zero.valid = icmp eq i64 %view.zero, 0
  %offset.valid = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %view.count.valid = icmp ule i64 %view.count, %remaining
  %base.address = ptrtoint ptr %base to i64
  %base.nonnull = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %issued.positive = icmp uge i64 %issued, 1
  %issued.bounded = icmp ule i64 %issued, 256
  %issued.valid = and i1 %issued.positive, %issued.bounded
  %a = and i1 %code.valid, %view.code.valid
  %b = and i1 %owner.valid, %view.owner.valid
  %c = and i1 %epoch.valid, %view.epoch.valid
  %d = and i1 %active.valid, %count.valid
  %e = and i1 %rights.valid, %view.rights.valid
  %f = and i1 %zero.valid, %offset.valid
  %g = and i1 %view.count.valid, %base.nonnull
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %ef = and i1 %e, %f
  %g.end = and i1 %g, %end.valid
  %abcd = and i1 %ab, %cd
  %efgh = and i1 %ef, %g.end
  %all.fields = and i1 %abcd, %efgh
  %valid = and i1 %all.fields, %issued.valid
  br i1 %valid, label %success, label %invalid
success:
  %bytes = getelementptr i8, ptr %base, i64 %offset
  ret ptr %bytes
invalid:
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}

; Valid arbitrary-precision Nat outside u64 refuses; it is not truncated.
define internal { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %number) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign = load i64, ptr %number, align 8
  %nonnegative = icmp eq i64 %sign, 0
  br i1 %nonnegative, label %number.length, label %invalid
number.length:
  %length.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %zero.result, label %bounded
zero.result:
  ret { i1, i64 } { i1 true, i64 0 }
bounded:
  %fits = icmp ule i64 %length, 2
  br i1 %fits, label %low, label %refuse
low:
  %low.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 0
  %low.word = load i32, ptr %low.pointer, align 4
  %low.value = zext i32 %low.word to i64
  %single = icmp eq i64 %length, 1
  br i1 %single, label %single.result, label %high
single.result:
  %one = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %low.value, 1
  ret { i1, i64 } %one
high:
  %high.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 1
  %high.word = load i32, ptr %high.pointer, align 4
  %high.value = zext i32 %high.word to i64
  %shifted = shl i64 %high.value, 32
  %value = or i64 %shifted, %low.value
  %two = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %value, 1
  ret { i1, i64 } %two
refuse:
  ret { i1, i64 } { i1 false, i64 0 }
invalid:
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}

define internal ptr @topal.region-instance.namespace-metadata.primitive.count(ptr %view) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %number = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %count)
  ret ptr %number
}

define internal ptr @topal.region-instance.namespace-metadata.primitive.load(ptr %view, ptr %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  %decoded = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %valid = and i1 %fits, %contained
  br i1 %valid, label %read, label %refuse
read:
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = load i8, ptr %pointer, align 1
  %value = zext i8 %byte to i64
  %number = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %value)
  %some = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %number)
  ret ptr %some
refuse:
  %none = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.region-instance.namespace-metadata.primitive.store(ptr %view, ptr %index, ptr %number) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  %decoded.index = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %index)
  %decoded.value = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %number)
  %index.fits = extractvalue { i1, i64 } %decoded.index, 0
  %offset = extractvalue { i1, i64 } %decoded.index, 1
  %value.fits = extractvalue { i1, i64 } %decoded.value, 0
  %value = extractvalue { i1, i64 } %decoded.value, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %writable = icmp eq i64 %rights, 1
  %byte.valid = icmp ule i64 %value, 255
  %both.fit = and i1 %index.fits, %value.fits
  %access = and i1 %contained, %writable
  %range = and i1 %both.fit, %byte.valid
  %valid = and i1 %access, %range
  br i1 %valid, label %write, label %refuse
write:
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = trunc i64 %value to i8
  store i8 %byte, ptr %pointer, align 1
  ret i1 true
refuse:
  ret i1 false
}

define internal ptr @topal.region-instance.namespace-metadata.primitive.window(ptr %view, ptr %start.number, ptr %count.number, i1 %write) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  %decoded.start = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %start.number)
  %decoded.count = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %count.number)
  %start.fits = extractvalue { i1, i64 } %decoded.start, 0
  %start = extractvalue { i1, i64 } %decoded.start, 1
  %count.fits = extractvalue { i1, i64 } %decoded.count, 0
  %count = extractvalue { i1, i64 } %decoded.count, 1
  %parent.offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %parent.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %parent.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %parent.offset = load i64, ptr %parent.offset.pointer, align 8
  %parent.count = load i64, ptr %parent.count.pointer, align 8
  %parent.rights = load i64, ptr %parent.rights.pointer, align 8
  %start.valid = icmp ule i64 %start, %parent.count
  %remaining = sub i64 %parent.count, %start
  %count.valid = icmp ule i64 %count, %remaining
  %rights = zext i1 %write to i64
  %rights.valid = icmp ule i64 %rights, %parent.rights
  %range = and i1 %start.valid, %count.valid
  %facts = and i1 %start.fits, %count.fits
  %allowed = and i1 %range, %rights.valid
  %valid = and i1 %allowed, %facts
  br i1 %valid, label %capacity, label %refuse
capacity:
  %control = load ptr, ptr %view, align 8
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %issued = load i64, ptr %issued.pointer, align 8
  %available = icmp ult i64 %issued, 256
  br i1 %available, label %derive, label %invalid
derive:
  %new = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 64)
  %fields = load %topal.KernelRegionView, ptr %view, align 8
  store %topal.KernelRegionView %fields, ptr %new, align 8
  %new.offset = add i64 %parent.offset, %start
  %new.offset.pointer = getelementptr %topal.KernelRegionView, ptr %new, i32 0, i32 1
  %new.count.pointer = getelementptr %topal.KernelRegionView, ptr %new, i32 0, i32 2
  %new.rights.pointer = getelementptr %topal.KernelRegionView, ptr %new, i32 0, i32 3
  store i64 %new.offset, ptr %new.offset.pointer, align 8
  store i64 %count, ptr %new.count.pointer, align 8
  store i64 %rights, ptr %new.rights.pointer, align 8
  %next.issued = add i64 %issued, 1
  store i64 %next.issued, ptr %issued.pointer, align 8
  %some = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %new)
  ret ptr %some
refuse:
  %none = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none
invalid:
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}
; Optional checked field encoding runtime. Core values and the base region
; implementation remain shared. Static source formats admit one to eight bytes.

define internal { i1, ptr } @topal.region-instance.namespace-metadata.primitive.unsigned.span(ptr %view, ptr %index, i64 %width) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  %positive = icmp uge i64 %width, 1
  %bounded = icmp ule i64 %width, 8
  %format.valid = and i1 %positive, %bounded
  br i1 %format.valid, label %decode, label %invalid
decode:
  %decoded = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %starts = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %ends = icmp ule i64 %width, %remaining
  %contained = and i1 %starts, %ends
  %valid = and i1 %fits, %contained
  br i1 %valid, label %success, label %refuse
success:
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %result = insertvalue { i1, ptr } { i1 true, ptr null }, ptr %pointer, 1
  ret { i1, ptr } %result
refuse:
  ret { i1, ptr } { i1 false, ptr null }
invalid:
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}

define internal ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %view, ptr %index, i64 %width, i1 %big) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %checked = call { i1, ptr } @topal.region-instance.namespace-metadata.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %valid, label %loop, label %refuse
loop:
  %index.byte = phi i64 [ 0, %entry ], [ %next, %loop ]
  %value = phi i64 [ 0, %entry ], [ %merged, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  %byte = load i8, ptr %pointer, align 1
  %extended = zext i8 %byte to i64
  %part = shl i64 %extended, %shift
  %merged = or i64 %value, %part
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop
result:
  %number = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %merged)
  %some = call ptr @topal.region-instance.namespace-metadata.runtime.optional.some(ptr %number)
  ret ptr %some
refuse:
  %none = call ptr @topal.region-instance.namespace-metadata.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %view, ptr %index, ptr %number, i64 %width, i1 %big) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %checked = call { i1, ptr } @topal.region-instance.namespace-metadata.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %span.valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %span.valid, label %value.check, label %refuse
value.check:
  %decoded = call { i1, i64 } @topal.region-instance.namespace-metadata.primitive.index(ptr %number)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %value = extractvalue { i1, i64 } %decoded, 1
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %rights = load i64, ptr %rights.pointer, align 8
  %writable = icmp eq i64 %rights, 1
  ; Width is proved in [1,8], so this shift is always in [0,56]. In particular
  ; width eight never attempts a poison-producing shift by 64.
  %bits = mul i64 %width, 8
  %unused = sub i64 64, %bits
  %mask = lshr i64 -1, %unused
  %outside.mask = xor i64 %mask, -1
  %outside = and i64 %value, %outside.mask
  %value.valid = icmp eq i64 %outside, 0
  %range = and i1 %fits, %value.valid
  %valid = and i1 %range, %writable
  br i1 %valid, label %loop, label %refuse
loop:
  %index.byte = phi i64 [ 0, %value.check ], [ %next, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %part = lshr i64 %value, %shift
  %byte = trunc i64 %part to i8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  store i8 %byte, ptr %pointer, align 1
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop
result:
  ret i1 true
refuse:
  ret i1 false
}
@topal.region-instance.namespace-metadata.literal.int.0 = internal unnamed_addr constant { i64, i64, [3 x i32] } { i64 0, i64 3, [3 x i32] [i32 0, i32 0, i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.1 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.2 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.3 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.4 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.5 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.6 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.7 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.8 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.9 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.10 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.11 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.12 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.region-instance.namespace-metadata.literal.int.13 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.14 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.15 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.16 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.17 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.18 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.region-instance.namespace-metadata.literal.int.19 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 96] }, align 8
@topal.region-instance.namespace-metadata.literal.int.20 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 112] }, align 8
@topal.region-instance.namespace-metadata.literal.int.21 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.region-instance.namespace-metadata.literal.int.22 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.23 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.24 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32768] }, align 8
@topal.region-instance.namespace-metadata.literal.int.25 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 36863] }, align 8
@topal.region-instance.namespace-metadata.literal.int.26 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.27 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.28 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.29 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.30 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.31 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.32 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.33 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.34 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.35 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.36 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.37 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.38 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.39 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.40 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.41 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.42 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.43 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1536] }, align 8
@topal.region-instance.namespace-metadata.literal.int.44 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.45 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.46 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.47 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.48 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.49 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.50 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.51 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.52 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.53 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.54 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.55 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.56 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.57 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.58 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.59 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.60 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.61 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.62 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.63 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.64 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.65 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.66 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.67 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 46] }, align 8
@topal.region-instance.namespace-metadata.literal.int.68 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 46] }, align 8
@topal.region-instance.namespace-metadata.literal.int.69 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.70 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.71 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 47] }, align 8
@topal.region-instance.namespace-metadata.literal.int.72 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.73 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.74 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.75 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3201] }, align 8
@topal.region-instance.namespace-metadata.literal.int.76 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.77 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3202] }, align 8
@topal.region-instance.namespace-metadata.literal.int.78 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.79 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3203] }, align 8
@topal.region-instance.namespace-metadata.literal.int.80 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.region-instance.namespace-metadata.literal.int.81 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3204] }, align 8
@topal.region-instance.namespace-metadata.literal.int.82 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.region-instance.namespace-metadata.literal.int.83 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3205] }, align 8
@topal.region-instance.namespace-metadata.literal.int.84 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 5] }, align 8
@topal.region-instance.namespace-metadata.literal.int.85 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3206] }, align 8
@topal.region-instance.namespace-metadata.literal.int.86 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 6] }, align 8
@topal.region-instance.namespace-metadata.literal.int.87 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3207] }, align 8
@topal.region-instance.namespace-metadata.literal.int.88 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 7] }, align 8
@topal.region-instance.namespace-metadata.literal.int.89 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3208] }, align 8
@topal.region-instance.namespace-metadata.literal.int.90 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.91 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3209] }, align 8
@topal.region-instance.namespace-metadata.literal.int.92 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 9] }, align 8
@topal.region-instance.namespace-metadata.literal.int.93 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3210] }, align 8
@topal.region-instance.namespace-metadata.literal.int.94 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 10] }, align 8
@topal.region-instance.namespace-metadata.literal.int.95 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3211] }, align 8
@topal.region-instance.namespace-metadata.literal.int.96 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 11] }, align 8
@topal.region-instance.namespace-metadata.literal.int.97 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3212] }, align 8
@topal.region-instance.namespace-metadata.literal.int.98 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 12] }, align 8
@topal.region-instance.namespace-metadata.literal.int.99 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3213] }, align 8
@topal.region-instance.namespace-metadata.literal.int.100 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 13] }, align 8
@topal.region-instance.namespace-metadata.literal.int.101 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3214] }, align 8
@topal.region-instance.namespace-metadata.literal.int.102 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 14] }, align 8
@topal.region-instance.namespace-metadata.literal.int.103 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3215] }, align 8
@topal.region-instance.namespace-metadata.literal.int.104 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 15] }, align 8
@topal.region-instance.namespace-metadata.literal.int.105 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3216] }, align 8
@topal.region-instance.namespace-metadata.literal.int.106 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.107 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3217] }, align 8
@topal.region-instance.namespace-metadata.literal.int.108 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 17] }, align 8
@topal.region-instance.namespace-metadata.literal.int.109 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3218] }, align 8
@topal.region-instance.namespace-metadata.literal.int.110 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 18] }, align 8
@topal.region-instance.namespace-metadata.literal.int.111 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3219] }, align 8
@topal.region-instance.namespace-metadata.literal.int.112 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 19] }, align 8
@topal.region-instance.namespace-metadata.literal.int.113 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3220] }, align 8
@topal.region-instance.namespace-metadata.literal.int.114 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 20] }, align 8
@topal.region-instance.namespace-metadata.literal.int.115 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3221] }, align 8
@topal.region-instance.namespace-metadata.literal.int.116 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 21] }, align 8
@topal.region-instance.namespace-metadata.literal.int.117 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3222] }, align 8
@topal.region-instance.namespace-metadata.literal.int.118 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 22] }, align 8
@topal.region-instance.namespace-metadata.literal.int.119 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3223] }, align 8
@topal.region-instance.namespace-metadata.literal.int.120 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 23] }, align 8
@topal.region-instance.namespace-metadata.literal.int.121 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3224] }, align 8
@topal.region-instance.namespace-metadata.literal.int.122 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.region-instance.namespace-metadata.literal.int.123 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3225] }, align 8
@topal.region-instance.namespace-metadata.literal.int.124 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 25] }, align 8
@topal.region-instance.namespace-metadata.literal.int.125 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3226] }, align 8
@topal.region-instance.namespace-metadata.literal.int.126 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 26] }, align 8
@topal.region-instance.namespace-metadata.literal.int.127 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3227] }, align 8
@topal.region-instance.namespace-metadata.literal.int.128 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 27] }, align 8
@topal.region-instance.namespace-metadata.literal.int.129 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3228] }, align 8
@topal.region-instance.namespace-metadata.literal.int.130 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 28] }, align 8
@topal.region-instance.namespace-metadata.literal.int.131 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3229] }, align 8
@topal.region-instance.namespace-metadata.literal.int.132 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 29] }, align 8
@topal.region-instance.namespace-metadata.literal.int.133 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3230] }, align 8
@topal.region-instance.namespace-metadata.literal.int.134 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 30] }, align 8
@topal.region-instance.namespace-metadata.literal.int.135 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3231] }, align 8
@topal.region-instance.namespace-metadata.literal.int.136 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 31] }, align 8
@topal.region-instance.namespace-metadata.literal.int.137 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3232] }, align 8
@topal.region-instance.namespace-metadata.literal.int.138 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.139 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3233] }, align 8
@topal.region-instance.namespace-metadata.literal.int.140 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 33] }, align 8
@topal.region-instance.namespace-metadata.literal.int.141 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3234] }, align 8
@topal.region-instance.namespace-metadata.literal.int.142 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 34] }, align 8
@topal.region-instance.namespace-metadata.literal.int.143 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3235] }, align 8
@topal.region-instance.namespace-metadata.literal.int.144 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 35] }, align 8
@topal.region-instance.namespace-metadata.literal.int.145 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3236] }, align 8
@topal.region-instance.namespace-metadata.literal.int.146 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 36] }, align 8
@topal.region-instance.namespace-metadata.literal.int.147 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3237] }, align 8
@topal.region-instance.namespace-metadata.literal.int.148 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 37] }, align 8
@topal.region-instance.namespace-metadata.literal.int.149 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3238] }, align 8
@topal.region-instance.namespace-metadata.literal.int.150 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 38] }, align 8
@topal.region-instance.namespace-metadata.literal.int.151 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3239] }, align 8
@topal.region-instance.namespace-metadata.literal.int.152 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 39] }, align 8
@topal.region-instance.namespace-metadata.literal.int.153 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3240] }, align 8
@topal.region-instance.namespace-metadata.literal.int.154 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.region-instance.namespace-metadata.literal.int.155 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3241] }, align 8
@topal.region-instance.namespace-metadata.literal.int.156 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 41] }, align 8
@topal.region-instance.namespace-metadata.literal.int.157 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3242] }, align 8
@topal.region-instance.namespace-metadata.literal.int.158 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 42] }, align 8
@topal.region-instance.namespace-metadata.literal.int.159 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3243] }, align 8
@topal.region-instance.namespace-metadata.literal.int.160 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 43] }, align 8
@topal.region-instance.namespace-metadata.literal.int.161 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3244] }, align 8
@topal.region-instance.namespace-metadata.literal.int.162 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 44] }, align 8
@topal.region-instance.namespace-metadata.literal.int.163 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3245] }, align 8
@topal.region-instance.namespace-metadata.literal.int.164 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 45] }, align 8
@topal.region-instance.namespace-metadata.literal.int.165 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3246] }, align 8
@topal.region-instance.namespace-metadata.literal.int.166 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 46] }, align 8
@topal.region-instance.namespace-metadata.literal.int.167 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3247] }, align 8
@topal.region-instance.namespace-metadata.literal.int.168 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 47] }, align 8
@topal.region-instance.namespace-metadata.literal.int.169 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3248] }, align 8
@topal.region-instance.namespace-metadata.literal.int.170 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.171 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3249] }, align 8
@topal.region-instance.namespace-metadata.literal.int.172 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 49] }, align 8
@topal.region-instance.namespace-metadata.literal.int.173 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3250] }, align 8
@topal.region-instance.namespace-metadata.literal.int.174 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 50] }, align 8
@topal.region-instance.namespace-metadata.literal.int.175 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3251] }, align 8
@topal.region-instance.namespace-metadata.literal.int.176 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 51] }, align 8
@topal.region-instance.namespace-metadata.literal.int.177 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3252] }, align 8
@topal.region-instance.namespace-metadata.literal.int.178 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 52] }, align 8
@topal.region-instance.namespace-metadata.literal.int.179 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3253] }, align 8
@topal.region-instance.namespace-metadata.literal.int.180 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 53] }, align 8
@topal.region-instance.namespace-metadata.literal.int.181 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3254] }, align 8
@topal.region-instance.namespace-metadata.literal.int.182 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 54] }, align 8
@topal.region-instance.namespace-metadata.literal.int.183 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.184 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 55] }, align 8
@topal.region-instance.namespace-metadata.literal.int.185 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3256] }, align 8
@topal.region-instance.namespace-metadata.literal.int.186 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.187 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3257] }, align 8
@topal.region-instance.namespace-metadata.literal.int.188 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 57] }, align 8
@topal.region-instance.namespace-metadata.literal.int.189 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3258] }, align 8
@topal.region-instance.namespace-metadata.literal.int.190 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 58] }, align 8
@topal.region-instance.namespace-metadata.literal.int.191 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3259] }, align 8
@topal.region-instance.namespace-metadata.literal.int.192 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 59] }, align 8
@topal.region-instance.namespace-metadata.literal.int.193 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3260] }, align 8
@topal.region-instance.namespace-metadata.literal.int.194 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 60] }, align 8
@topal.region-instance.namespace-metadata.literal.int.195 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3261] }, align 8
@topal.region-instance.namespace-metadata.literal.int.196 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 61] }, align 8
@topal.region-instance.namespace-metadata.literal.int.197 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3262] }, align 8
@topal.region-instance.namespace-metadata.literal.int.198 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 62] }, align 8
@topal.region-instance.namespace-metadata.literal.int.199 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3263] }, align 8
@topal.region-instance.namespace-metadata.literal.int.200 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 63] }, align 8
@topal.region-instance.namespace-metadata.literal.int.201 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3264] }, align 8
@topal.region-instance.namespace-metadata.literal.int.202 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.203 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3265] }, align 8
@topal.region-instance.namespace-metadata.literal.int.204 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 65] }, align 8
@topal.region-instance.namespace-metadata.literal.int.205 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3266] }, align 8
@topal.region-instance.namespace-metadata.literal.int.206 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 66] }, align 8
@topal.region-instance.namespace-metadata.literal.int.207 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3267] }, align 8
@topal.region-instance.namespace-metadata.literal.int.208 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 67] }, align 8
@topal.region-instance.namespace-metadata.literal.int.209 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3268] }, align 8
@topal.region-instance.namespace-metadata.literal.int.210 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 68] }, align 8
@topal.region-instance.namespace-metadata.literal.int.211 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3269] }, align 8
@topal.region-instance.namespace-metadata.literal.int.212 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 69] }, align 8
@topal.region-instance.namespace-metadata.literal.int.213 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3270] }, align 8
@topal.region-instance.namespace-metadata.literal.int.214 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 70] }, align 8
@topal.region-instance.namespace-metadata.literal.int.215 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3271] }, align 8
@topal.region-instance.namespace-metadata.literal.int.216 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 71] }, align 8
@topal.region-instance.namespace-metadata.literal.int.217 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3272] }, align 8
@topal.region-instance.namespace-metadata.literal.int.218 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.region-instance.namespace-metadata.literal.int.219 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3273] }, align 8
@topal.region-instance.namespace-metadata.literal.int.220 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 73] }, align 8
@topal.region-instance.namespace-metadata.literal.int.221 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3274] }, align 8
@topal.region-instance.namespace-metadata.literal.int.222 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 74] }, align 8
@topal.region-instance.namespace-metadata.literal.int.223 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3275] }, align 8
@topal.region-instance.namespace-metadata.literal.int.224 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 75] }, align 8
@topal.region-instance.namespace-metadata.literal.int.225 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3276] }, align 8
@topal.region-instance.namespace-metadata.literal.int.226 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 76] }, align 8
@topal.region-instance.namespace-metadata.literal.int.227 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3277] }, align 8
@topal.region-instance.namespace-metadata.literal.int.228 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 77] }, align 8
@topal.region-instance.namespace-metadata.literal.int.229 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3278] }, align 8
@topal.region-instance.namespace-metadata.literal.int.230 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 78] }, align 8
@topal.region-instance.namespace-metadata.literal.int.231 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3279] }, align 8
@topal.region-instance.namespace-metadata.literal.int.232 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 79] }, align 8
@topal.region-instance.namespace-metadata.literal.int.233 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3280] }, align 8
@topal.region-instance.namespace-metadata.literal.int.234 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.region-instance.namespace-metadata.literal.int.235 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3281] }, align 8
@topal.region-instance.namespace-metadata.literal.int.236 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 81] }, align 8
@topal.region-instance.namespace-metadata.literal.int.237 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3282] }, align 8
@topal.region-instance.namespace-metadata.literal.int.238 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 82] }, align 8
@topal.region-instance.namespace-metadata.literal.int.239 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3283] }, align 8
@topal.region-instance.namespace-metadata.literal.int.240 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 83] }, align 8
@topal.region-instance.namespace-metadata.literal.int.241 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3284] }, align 8
@topal.region-instance.namespace-metadata.literal.int.242 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 84] }, align 8
@topal.region-instance.namespace-metadata.literal.int.243 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3285] }, align 8
@topal.region-instance.namespace-metadata.literal.int.244 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 85] }, align 8
@topal.region-instance.namespace-metadata.literal.int.245 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3286] }, align 8
@topal.region-instance.namespace-metadata.literal.int.246 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 86] }, align 8
@topal.region-instance.namespace-metadata.literal.int.247 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3287] }, align 8
@topal.region-instance.namespace-metadata.literal.int.248 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 87] }, align 8
@topal.region-instance.namespace-metadata.literal.int.249 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3288] }, align 8
@topal.region-instance.namespace-metadata.literal.int.250 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.region-instance.namespace-metadata.literal.int.251 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3289] }, align 8
@topal.region-instance.namespace-metadata.literal.int.252 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 89] }, align 8
@topal.region-instance.namespace-metadata.literal.int.253 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3290] }, align 8
@topal.region-instance.namespace-metadata.literal.int.254 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 90] }, align 8
@topal.region-instance.namespace-metadata.literal.int.255 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3291] }, align 8
@topal.region-instance.namespace-metadata.literal.int.256 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 91] }, align 8
@topal.region-instance.namespace-metadata.literal.int.257 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3292] }, align 8
@topal.region-instance.namespace-metadata.literal.int.258 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 92] }, align 8
@topal.region-instance.namespace-metadata.literal.int.259 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3293] }, align 8
@topal.region-instance.namespace-metadata.literal.int.260 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 93] }, align 8
@topal.region-instance.namespace-metadata.literal.int.261 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3294] }, align 8
@topal.region-instance.namespace-metadata.literal.int.262 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 94] }, align 8
@topal.region-instance.namespace-metadata.literal.int.263 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3295] }, align 8
@topal.region-instance.namespace-metadata.literal.int.264 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 95] }, align 8
@topal.region-instance.namespace-metadata.literal.int.265 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3296] }, align 8
@topal.region-instance.namespace-metadata.literal.int.266 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 96] }, align 8
@topal.region-instance.namespace-metadata.literal.int.267 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3297] }, align 8
@topal.region-instance.namespace-metadata.literal.int.268 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 97] }, align 8
@topal.region-instance.namespace-metadata.literal.int.269 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3298] }, align 8
@topal.region-instance.namespace-metadata.literal.int.270 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 98] }, align 8
@topal.region-instance.namespace-metadata.literal.int.271 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3299] }, align 8
@topal.region-instance.namespace-metadata.literal.int.272 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 99] }, align 8
@topal.region-instance.namespace-metadata.literal.int.273 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3300] }, align 8
@topal.region-instance.namespace-metadata.literal.int.274 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 100] }, align 8
@topal.region-instance.namespace-metadata.literal.int.275 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3301] }, align 8
@topal.region-instance.namespace-metadata.literal.int.276 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 101] }, align 8
@topal.region-instance.namespace-metadata.literal.int.277 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3302] }, align 8
@topal.region-instance.namespace-metadata.literal.int.278 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 102] }, align 8
@topal.region-instance.namespace-metadata.literal.int.279 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3303] }, align 8
@topal.region-instance.namespace-metadata.literal.int.280 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 103] }, align 8
@topal.region-instance.namespace-metadata.literal.int.281 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3304] }, align 8
@topal.region-instance.namespace-metadata.literal.int.282 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 104] }, align 8
@topal.region-instance.namespace-metadata.literal.int.283 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3305] }, align 8
@topal.region-instance.namespace-metadata.literal.int.284 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 105] }, align 8
@topal.region-instance.namespace-metadata.literal.int.285 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3306] }, align 8
@topal.region-instance.namespace-metadata.literal.int.286 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 106] }, align 8
@topal.region-instance.namespace-metadata.literal.int.287 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3307] }, align 8
@topal.region-instance.namespace-metadata.literal.int.288 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 107] }, align 8
@topal.region-instance.namespace-metadata.literal.int.289 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3308] }, align 8
@topal.region-instance.namespace-metadata.literal.int.290 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 108] }, align 8
@topal.region-instance.namespace-metadata.literal.int.291 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3309] }, align 8
@topal.region-instance.namespace-metadata.literal.int.292 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 109] }, align 8
@topal.region-instance.namespace-metadata.literal.int.293 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3310] }, align 8
@topal.region-instance.namespace-metadata.literal.int.294 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 110] }, align 8
@topal.region-instance.namespace-metadata.literal.int.295 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3311] }, align 8
@topal.region-instance.namespace-metadata.literal.int.296 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 111] }, align 8
@topal.region-instance.namespace-metadata.literal.int.297 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3312] }, align 8
@topal.region-instance.namespace-metadata.literal.int.298 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 112] }, align 8
@topal.region-instance.namespace-metadata.literal.int.299 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3313] }, align 8
@topal.region-instance.namespace-metadata.literal.int.300 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 113] }, align 8
@topal.region-instance.namespace-metadata.literal.int.301 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3314] }, align 8
@topal.region-instance.namespace-metadata.literal.int.302 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 114] }, align 8
@topal.region-instance.namespace-metadata.literal.int.303 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3315] }, align 8
@topal.region-instance.namespace-metadata.literal.int.304 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 115] }, align 8
@topal.region-instance.namespace-metadata.literal.int.305 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3316] }, align 8
@topal.region-instance.namespace-metadata.literal.int.306 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 116] }, align 8
@topal.region-instance.namespace-metadata.literal.int.307 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3317] }, align 8
@topal.region-instance.namespace-metadata.literal.int.308 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 117] }, align 8
@topal.region-instance.namespace-metadata.literal.int.309 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3318] }, align 8
@topal.region-instance.namespace-metadata.literal.int.310 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 118] }, align 8
@topal.region-instance.namespace-metadata.literal.int.311 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3319] }, align 8
@topal.region-instance.namespace-metadata.literal.int.312 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 119] }, align 8
@topal.region-instance.namespace-metadata.literal.int.313 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3320] }, align 8
@topal.region-instance.namespace-metadata.literal.int.314 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 120] }, align 8
@topal.region-instance.namespace-metadata.literal.int.315 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3321] }, align 8
@topal.region-instance.namespace-metadata.literal.int.316 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 121] }, align 8
@topal.region-instance.namespace-metadata.literal.int.317 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3322] }, align 8
@topal.region-instance.namespace-metadata.literal.int.318 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 122] }, align 8
@topal.region-instance.namespace-metadata.literal.int.319 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3323] }, align 8
@topal.region-instance.namespace-metadata.literal.int.320 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 123] }, align 8
@topal.region-instance.namespace-metadata.literal.int.321 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3324] }, align 8
@topal.region-instance.namespace-metadata.literal.int.322 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 124] }, align 8
@topal.region-instance.namespace-metadata.literal.int.323 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3325] }, align 8
@topal.region-instance.namespace-metadata.literal.int.324 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 125] }, align 8
@topal.region-instance.namespace-metadata.literal.int.325 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3326] }, align 8
@topal.region-instance.namespace-metadata.literal.int.326 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 126] }, align 8
@topal.region-instance.namespace-metadata.literal.int.327 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3327] }, align 8
@topal.region-instance.namespace-metadata.literal.int.328 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 127] }, align 8
@topal.region-instance.namespace-metadata.literal.int.329 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3328] }, align 8
@topal.region-instance.namespace-metadata.literal.int.330 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.331 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3329] }, align 8
@topal.region-instance.namespace-metadata.literal.int.332 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 129] }, align 8
@topal.region-instance.namespace-metadata.literal.int.333 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3330] }, align 8
@topal.region-instance.namespace-metadata.literal.int.334 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 130] }, align 8
@topal.region-instance.namespace-metadata.literal.int.335 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3331] }, align 8
@topal.region-instance.namespace-metadata.literal.int.336 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 131] }, align 8
@topal.region-instance.namespace-metadata.literal.int.337 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3332] }, align 8
@topal.region-instance.namespace-metadata.literal.int.338 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 132] }, align 8
@topal.region-instance.namespace-metadata.literal.int.339 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3333] }, align 8
@topal.region-instance.namespace-metadata.literal.int.340 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 133] }, align 8
@topal.region-instance.namespace-metadata.literal.int.341 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3334] }, align 8
@topal.region-instance.namespace-metadata.literal.int.342 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 134] }, align 8
@topal.region-instance.namespace-metadata.literal.int.343 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3335] }, align 8
@topal.region-instance.namespace-metadata.literal.int.344 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 135] }, align 8
@topal.region-instance.namespace-metadata.literal.int.345 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3336] }, align 8
@topal.region-instance.namespace-metadata.literal.int.346 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 136] }, align 8
@topal.region-instance.namespace-metadata.literal.int.347 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3337] }, align 8
@topal.region-instance.namespace-metadata.literal.int.348 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 137] }, align 8
@topal.region-instance.namespace-metadata.literal.int.349 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3338] }, align 8
@topal.region-instance.namespace-metadata.literal.int.350 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 138] }, align 8
@topal.region-instance.namespace-metadata.literal.int.351 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3339] }, align 8
@topal.region-instance.namespace-metadata.literal.int.352 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 139] }, align 8
@topal.region-instance.namespace-metadata.literal.int.353 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3340] }, align 8
@topal.region-instance.namespace-metadata.literal.int.354 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 140] }, align 8
@topal.region-instance.namespace-metadata.literal.int.355 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3341] }, align 8
@topal.region-instance.namespace-metadata.literal.int.356 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 141] }, align 8
@topal.region-instance.namespace-metadata.literal.int.357 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3342] }, align 8
@topal.region-instance.namespace-metadata.literal.int.358 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 142] }, align 8
@topal.region-instance.namespace-metadata.literal.int.359 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3343] }, align 8
@topal.region-instance.namespace-metadata.literal.int.360 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 143] }, align 8
@topal.region-instance.namespace-metadata.literal.int.361 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3344] }, align 8
@topal.region-instance.namespace-metadata.literal.int.362 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 144] }, align 8
@topal.region-instance.namespace-metadata.literal.int.363 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3345] }, align 8
@topal.region-instance.namespace-metadata.literal.int.364 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 145] }, align 8
@topal.region-instance.namespace-metadata.literal.int.365 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3346] }, align 8
@topal.region-instance.namespace-metadata.literal.int.366 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 146] }, align 8
@topal.region-instance.namespace-metadata.literal.int.367 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3347] }, align 8
@topal.region-instance.namespace-metadata.literal.int.368 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 147] }, align 8
@topal.region-instance.namespace-metadata.literal.int.369 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3348] }, align 8
@topal.region-instance.namespace-metadata.literal.int.370 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 148] }, align 8
@topal.region-instance.namespace-metadata.literal.int.371 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3349] }, align 8
@topal.region-instance.namespace-metadata.literal.int.372 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 149] }, align 8
@topal.region-instance.namespace-metadata.literal.int.373 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3350] }, align 8
@topal.region-instance.namespace-metadata.literal.int.374 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 150] }, align 8
@topal.region-instance.namespace-metadata.literal.int.375 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3351] }, align 8
@topal.region-instance.namespace-metadata.literal.int.376 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 151] }, align 8
@topal.region-instance.namespace-metadata.literal.int.377 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3352] }, align 8
@topal.region-instance.namespace-metadata.literal.int.378 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 152] }, align 8
@topal.region-instance.namespace-metadata.literal.int.379 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3353] }, align 8
@topal.region-instance.namespace-metadata.literal.int.380 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 153] }, align 8
@topal.region-instance.namespace-metadata.literal.int.381 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3354] }, align 8
@topal.region-instance.namespace-metadata.literal.int.382 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 154] }, align 8
@topal.region-instance.namespace-metadata.literal.int.383 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3355] }, align 8
@topal.region-instance.namespace-metadata.literal.int.384 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 155] }, align 8
@topal.region-instance.namespace-metadata.literal.int.385 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3356] }, align 8
@topal.region-instance.namespace-metadata.literal.int.386 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 156] }, align 8
@topal.region-instance.namespace-metadata.literal.int.387 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3357] }, align 8
@topal.region-instance.namespace-metadata.literal.int.388 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 157] }, align 8
@topal.region-instance.namespace-metadata.literal.int.389 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3358] }, align 8
@topal.region-instance.namespace-metadata.literal.int.390 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 158] }, align 8
@topal.region-instance.namespace-metadata.literal.int.391 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3359] }, align 8
@topal.region-instance.namespace-metadata.literal.int.392 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 159] }, align 8
@topal.region-instance.namespace-metadata.literal.int.393 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3360] }, align 8
@topal.region-instance.namespace-metadata.literal.int.394 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 160] }, align 8
@topal.region-instance.namespace-metadata.literal.int.395 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3361] }, align 8
@topal.region-instance.namespace-metadata.literal.int.396 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 161] }, align 8
@topal.region-instance.namespace-metadata.literal.int.397 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3362] }, align 8
@topal.region-instance.namespace-metadata.literal.int.398 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 162] }, align 8
@topal.region-instance.namespace-metadata.literal.int.399 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3363] }, align 8
@topal.region-instance.namespace-metadata.literal.int.400 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 163] }, align 8
@topal.region-instance.namespace-metadata.literal.int.401 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3364] }, align 8
@topal.region-instance.namespace-metadata.literal.int.402 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 164] }, align 8
@topal.region-instance.namespace-metadata.literal.int.403 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3365] }, align 8
@topal.region-instance.namespace-metadata.literal.int.404 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 165] }, align 8
@topal.region-instance.namespace-metadata.literal.int.405 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3366] }, align 8
@topal.region-instance.namespace-metadata.literal.int.406 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 166] }, align 8
@topal.region-instance.namespace-metadata.literal.int.407 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3367] }, align 8
@topal.region-instance.namespace-metadata.literal.int.408 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 167] }, align 8
@topal.region-instance.namespace-metadata.literal.int.409 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3368] }, align 8
@topal.region-instance.namespace-metadata.literal.int.410 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 168] }, align 8
@topal.region-instance.namespace-metadata.literal.int.411 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3369] }, align 8
@topal.region-instance.namespace-metadata.literal.int.412 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 169] }, align 8
@topal.region-instance.namespace-metadata.literal.int.413 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3370] }, align 8
@topal.region-instance.namespace-metadata.literal.int.414 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 170] }, align 8
@topal.region-instance.namespace-metadata.literal.int.415 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3371] }, align 8
@topal.region-instance.namespace-metadata.literal.int.416 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 171] }, align 8
@topal.region-instance.namespace-metadata.literal.int.417 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3372] }, align 8
@topal.region-instance.namespace-metadata.literal.int.418 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 172] }, align 8
@topal.region-instance.namespace-metadata.literal.int.419 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3373] }, align 8
@topal.region-instance.namespace-metadata.literal.int.420 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 173] }, align 8
@topal.region-instance.namespace-metadata.literal.int.421 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3374] }, align 8
@topal.region-instance.namespace-metadata.literal.int.422 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 174] }, align 8
@topal.region-instance.namespace-metadata.literal.int.423 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3375] }, align 8
@topal.region-instance.namespace-metadata.literal.int.424 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 175] }, align 8
@topal.region-instance.namespace-metadata.literal.int.425 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3376] }, align 8
@topal.region-instance.namespace-metadata.literal.int.426 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 176] }, align 8
@topal.region-instance.namespace-metadata.literal.int.427 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3377] }, align 8
@topal.region-instance.namespace-metadata.literal.int.428 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 177] }, align 8
@topal.region-instance.namespace-metadata.literal.int.429 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3378] }, align 8
@topal.region-instance.namespace-metadata.literal.int.430 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 178] }, align 8
@topal.region-instance.namespace-metadata.literal.int.431 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3379] }, align 8
@topal.region-instance.namespace-metadata.literal.int.432 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 179] }, align 8
@topal.region-instance.namespace-metadata.literal.int.433 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3380] }, align 8
@topal.region-instance.namespace-metadata.literal.int.434 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 180] }, align 8
@topal.region-instance.namespace-metadata.literal.int.435 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3381] }, align 8
@topal.region-instance.namespace-metadata.literal.int.436 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 181] }, align 8
@topal.region-instance.namespace-metadata.literal.int.437 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3382] }, align 8
@topal.region-instance.namespace-metadata.literal.int.438 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 182] }, align 8
@topal.region-instance.namespace-metadata.literal.int.439 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3383] }, align 8
@topal.region-instance.namespace-metadata.literal.int.440 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 183] }, align 8
@topal.region-instance.namespace-metadata.literal.int.441 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3384] }, align 8
@topal.region-instance.namespace-metadata.literal.int.442 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 184] }, align 8
@topal.region-instance.namespace-metadata.literal.int.443 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3385] }, align 8
@topal.region-instance.namespace-metadata.literal.int.444 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 185] }, align 8
@topal.region-instance.namespace-metadata.literal.int.445 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3386] }, align 8
@topal.region-instance.namespace-metadata.literal.int.446 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 186] }, align 8
@topal.region-instance.namespace-metadata.literal.int.447 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3387] }, align 8
@topal.region-instance.namespace-metadata.literal.int.448 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 187] }, align 8
@topal.region-instance.namespace-metadata.literal.int.449 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3388] }, align 8
@topal.region-instance.namespace-metadata.literal.int.450 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 188] }, align 8
@topal.region-instance.namespace-metadata.literal.int.451 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3389] }, align 8
@topal.region-instance.namespace-metadata.literal.int.452 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 189] }, align 8
@topal.region-instance.namespace-metadata.literal.int.453 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3390] }, align 8
@topal.region-instance.namespace-metadata.literal.int.454 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 190] }, align 8
@topal.region-instance.namespace-metadata.literal.int.455 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3391] }, align 8
@topal.region-instance.namespace-metadata.literal.int.456 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 191] }, align 8
@topal.region-instance.namespace-metadata.literal.int.457 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3392] }, align 8
@topal.region-instance.namespace-metadata.literal.int.458 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 192] }, align 8
@topal.region-instance.namespace-metadata.literal.int.459 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3393] }, align 8
@topal.region-instance.namespace-metadata.literal.int.460 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 193] }, align 8
@topal.region-instance.namespace-metadata.literal.int.461 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3394] }, align 8
@topal.region-instance.namespace-metadata.literal.int.462 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 194] }, align 8
@topal.region-instance.namespace-metadata.literal.int.463 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3395] }, align 8
@topal.region-instance.namespace-metadata.literal.int.464 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 195] }, align 8
@topal.region-instance.namespace-metadata.literal.int.465 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3396] }, align 8
@topal.region-instance.namespace-metadata.literal.int.466 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 196] }, align 8
@topal.region-instance.namespace-metadata.literal.int.467 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3397] }, align 8
@topal.region-instance.namespace-metadata.literal.int.468 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 197] }, align 8
@topal.region-instance.namespace-metadata.literal.int.469 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3398] }, align 8
@topal.region-instance.namespace-metadata.literal.int.470 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 198] }, align 8
@topal.region-instance.namespace-metadata.literal.int.471 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3399] }, align 8
@topal.region-instance.namespace-metadata.literal.int.472 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 199] }, align 8
@topal.region-instance.namespace-metadata.literal.int.473 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3400] }, align 8
@topal.region-instance.namespace-metadata.literal.int.474 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.475 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3401] }, align 8
@topal.region-instance.namespace-metadata.literal.int.476 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 201] }, align 8
@topal.region-instance.namespace-metadata.literal.int.477 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3402] }, align 8
@topal.region-instance.namespace-metadata.literal.int.478 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 202] }, align 8
@topal.region-instance.namespace-metadata.literal.int.479 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3403] }, align 8
@topal.region-instance.namespace-metadata.literal.int.480 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 203] }, align 8
@topal.region-instance.namespace-metadata.literal.int.481 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3404] }, align 8
@topal.region-instance.namespace-metadata.literal.int.482 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 204] }, align 8
@topal.region-instance.namespace-metadata.literal.int.483 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3405] }, align 8
@topal.region-instance.namespace-metadata.literal.int.484 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 205] }, align 8
@topal.region-instance.namespace-metadata.literal.int.485 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3406] }, align 8
@topal.region-instance.namespace-metadata.literal.int.486 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 206] }, align 8
@topal.region-instance.namespace-metadata.literal.int.487 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3407] }, align 8
@topal.region-instance.namespace-metadata.literal.int.488 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 207] }, align 8
@topal.region-instance.namespace-metadata.literal.int.489 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3408] }, align 8
@topal.region-instance.namespace-metadata.literal.int.490 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 208] }, align 8
@topal.region-instance.namespace-metadata.literal.int.491 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3409] }, align 8
@topal.region-instance.namespace-metadata.literal.int.492 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 209] }, align 8
@topal.region-instance.namespace-metadata.literal.int.493 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3410] }, align 8
@topal.region-instance.namespace-metadata.literal.int.494 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 210] }, align 8
@topal.region-instance.namespace-metadata.literal.int.495 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3411] }, align 8
@topal.region-instance.namespace-metadata.literal.int.496 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 211] }, align 8
@topal.region-instance.namespace-metadata.literal.int.497 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3412] }, align 8
@topal.region-instance.namespace-metadata.literal.int.498 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 212] }, align 8
@topal.region-instance.namespace-metadata.literal.int.499 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3413] }, align 8
@topal.region-instance.namespace-metadata.literal.int.500 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 213] }, align 8
@topal.region-instance.namespace-metadata.literal.int.501 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3414] }, align 8
@topal.region-instance.namespace-metadata.literal.int.502 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 214] }, align 8
@topal.region-instance.namespace-metadata.literal.int.503 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3415] }, align 8
@topal.region-instance.namespace-metadata.literal.int.504 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 215] }, align 8
@topal.region-instance.namespace-metadata.literal.int.505 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3416] }, align 8
@topal.region-instance.namespace-metadata.literal.int.506 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 216] }, align 8
@topal.region-instance.namespace-metadata.literal.int.507 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3417] }, align 8
@topal.region-instance.namespace-metadata.literal.int.508 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 217] }, align 8
@topal.region-instance.namespace-metadata.literal.int.509 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3418] }, align 8
@topal.region-instance.namespace-metadata.literal.int.510 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 218] }, align 8
@topal.region-instance.namespace-metadata.literal.int.511 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3419] }, align 8
@topal.region-instance.namespace-metadata.literal.int.512 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 219] }, align 8
@topal.region-instance.namespace-metadata.literal.int.513 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3420] }, align 8
@topal.region-instance.namespace-metadata.literal.int.514 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 220] }, align 8
@topal.region-instance.namespace-metadata.literal.int.515 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3421] }, align 8
@topal.region-instance.namespace-metadata.literal.int.516 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 221] }, align 8
@topal.region-instance.namespace-metadata.literal.int.517 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3422] }, align 8
@topal.region-instance.namespace-metadata.literal.int.518 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 222] }, align 8
@topal.region-instance.namespace-metadata.literal.int.519 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3423] }, align 8
@topal.region-instance.namespace-metadata.literal.int.520 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 223] }, align 8
@topal.region-instance.namespace-metadata.literal.int.521 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3424] }, align 8
@topal.region-instance.namespace-metadata.literal.int.522 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 224] }, align 8
@topal.region-instance.namespace-metadata.literal.int.523 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3425] }, align 8
@topal.region-instance.namespace-metadata.literal.int.524 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 225] }, align 8
@topal.region-instance.namespace-metadata.literal.int.525 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3426] }, align 8
@topal.region-instance.namespace-metadata.literal.int.526 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 226] }, align 8
@topal.region-instance.namespace-metadata.literal.int.527 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3427] }, align 8
@topal.region-instance.namespace-metadata.literal.int.528 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 227] }, align 8
@topal.region-instance.namespace-metadata.literal.int.529 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3428] }, align 8
@topal.region-instance.namespace-metadata.literal.int.530 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 228] }, align 8
@topal.region-instance.namespace-metadata.literal.int.531 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3429] }, align 8
@topal.region-instance.namespace-metadata.literal.int.532 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 229] }, align 8
@topal.region-instance.namespace-metadata.literal.int.533 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3430] }, align 8
@topal.region-instance.namespace-metadata.literal.int.534 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 230] }, align 8
@topal.region-instance.namespace-metadata.literal.int.535 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3431] }, align 8
@topal.region-instance.namespace-metadata.literal.int.536 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 231] }, align 8
@topal.region-instance.namespace-metadata.literal.int.537 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3432] }, align 8
@topal.region-instance.namespace-metadata.literal.int.538 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 232] }, align 8
@topal.region-instance.namespace-metadata.literal.int.539 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3433] }, align 8
@topal.region-instance.namespace-metadata.literal.int.540 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 233] }, align 8
@topal.region-instance.namespace-metadata.literal.int.541 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3434] }, align 8
@topal.region-instance.namespace-metadata.literal.int.542 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 234] }, align 8
@topal.region-instance.namespace-metadata.literal.int.543 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3435] }, align 8
@topal.region-instance.namespace-metadata.literal.int.544 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 235] }, align 8
@topal.region-instance.namespace-metadata.literal.int.545 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3436] }, align 8
@topal.region-instance.namespace-metadata.literal.int.546 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 236] }, align 8
@topal.region-instance.namespace-metadata.literal.int.547 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3437] }, align 8
@topal.region-instance.namespace-metadata.literal.int.548 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 237] }, align 8
@topal.region-instance.namespace-metadata.literal.int.549 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3438] }, align 8
@topal.region-instance.namespace-metadata.literal.int.550 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 238] }, align 8
@topal.region-instance.namespace-metadata.literal.int.551 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3439] }, align 8
@topal.region-instance.namespace-metadata.literal.int.552 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 239] }, align 8
@topal.region-instance.namespace-metadata.literal.int.553 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3440] }, align 8
@topal.region-instance.namespace-metadata.literal.int.554 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 240] }, align 8
@topal.region-instance.namespace-metadata.literal.int.555 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3441] }, align 8
@topal.region-instance.namespace-metadata.literal.int.556 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 241] }, align 8
@topal.region-instance.namespace-metadata.literal.int.557 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3442] }, align 8
@topal.region-instance.namespace-metadata.literal.int.558 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 242] }, align 8
@topal.region-instance.namespace-metadata.literal.int.559 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3443] }, align 8
@topal.region-instance.namespace-metadata.literal.int.560 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 243] }, align 8
@topal.region-instance.namespace-metadata.literal.int.561 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3444] }, align 8
@topal.region-instance.namespace-metadata.literal.int.562 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 244] }, align 8
@topal.region-instance.namespace-metadata.literal.int.563 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3445] }, align 8
@topal.region-instance.namespace-metadata.literal.int.564 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 245] }, align 8
@topal.region-instance.namespace-metadata.literal.int.565 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3446] }, align 8
@topal.region-instance.namespace-metadata.literal.int.566 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 246] }, align 8
@topal.region-instance.namespace-metadata.literal.int.567 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3447] }, align 8
@topal.region-instance.namespace-metadata.literal.int.568 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 247] }, align 8
@topal.region-instance.namespace-metadata.literal.int.569 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3448] }, align 8
@topal.region-instance.namespace-metadata.literal.int.570 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 248] }, align 8
@topal.region-instance.namespace-metadata.literal.int.571 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3449] }, align 8
@topal.region-instance.namespace-metadata.literal.int.572 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 249] }, align 8
@topal.region-instance.namespace-metadata.literal.int.573 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3450] }, align 8
@topal.region-instance.namespace-metadata.literal.int.574 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 250] }, align 8
@topal.region-instance.namespace-metadata.literal.int.575 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3451] }, align 8
@topal.region-instance.namespace-metadata.literal.int.576 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 251] }, align 8
@topal.region-instance.namespace-metadata.literal.int.577 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3452] }, align 8
@topal.region-instance.namespace-metadata.literal.int.578 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 252] }, align 8
@topal.region-instance.namespace-metadata.literal.int.579 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3453] }, align 8
@topal.region-instance.namespace-metadata.literal.int.580 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 253] }, align 8
@topal.region-instance.namespace-metadata.literal.int.581 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3454] }, align 8
@topal.region-instance.namespace-metadata.literal.int.582 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 254] }, align 8
@topal.region-instance.namespace-metadata.literal.int.583 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3455] }, align 8
@topal.region-instance.namespace-metadata.literal.int.584 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.585 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 255] }, align 8
@topal.region-instance.namespace-metadata.literal.int.586 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.587 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3136] }, align 8
@topal.region-instance.namespace-metadata.literal.int.588 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3456] }, align 8
@topal.region-instance.namespace-metadata.literal.int.589 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.590 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.591 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.592 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.593 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.594 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.595 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.596 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.597 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.598 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.599 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.600 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.601 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.602 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.603 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.604 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.605 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.606 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.607 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.608 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3200] }, align 8
@topal.region-instance.namespace-metadata.literal.int.609 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.610 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.611 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.612 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.613 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.region-instance.namespace-metadata.literal.int.614 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.region-instance.namespace-metadata.literal.int.615 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.region-instance.namespace-metadata.literal.int.616 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.617 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.618 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 1, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.619 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.620 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.region-instance.namespace-metadata.literal.int.621 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.622 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.region-instance.namespace-metadata.literal.int.623 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.624 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.625 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.626 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.region-instance.namespace-metadata.literal.int.627 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.region-instance.namespace-metadata.literal.int.628 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.629 = internal unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.region-instance.namespace-metadata.literal.int.630 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.region-instance.namespace-metadata.literal.int.631 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3072] }, align 8
@topal.region-instance.namespace-metadata.literal.int.632 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3080] }, align 8
@topal.region-instance.namespace-metadata.literal.int.633 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3088] }, align 8
@topal.region-instance.namespace-metadata.literal.int.634 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3096] }, align 8
@topal.region-instance.namespace-metadata.literal.int.635 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3104] }, align 8
@topal.region-instance.namespace-metadata.literal.int.636 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3112] }, align 8
@topal.region-instance.namespace-metadata.literal.int.637 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3120] }, align 8
@topal.region-instance.namespace-metadata.literal.int.638 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3128] }, align 8
@topal.region-instance.namespace-metadata.literal.int.639 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4096] }, align 8
@topal.region-instance.namespace-metadata.literal.int.640 = internal unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.region-instance.namespace-metadata.literal.int.641 = internal unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 4294967295, i32 4294967295] }, align 8
@topal.region-instance.namespace-metadata.literal.int.642 = internal unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 4294967295, i32 4294967295] }, align 8
define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !119 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !120, !DIExpression(), !121)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !122, !DIExpression(), !123)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !124
decision.true.0:
  br label %decision.merge.2, !dbg !125
decision.false.1:
  br label %decision.merge.2, !dbg !126
decision.merge.2:
  %v2 = phi i1 [%arg1, %decision.true.0], [false, %decision.false.1], !dbg !127
  ret i1 %v2, !dbg !128
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !131 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !132, !DIExpression(), !133)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !134, !DIExpression(), !135)
  %v2 = alloca i1, align 1
  store i1 %arg2, ptr %v2, align 1
    #dbg_declare(ptr %v2, !136, !DIExpression(), !137)
  %v3 = alloca i1, align 1
  store i1 %arg3, ptr %v3, align 1
    #dbg_declare(ptr %v3, !138, !DIExpression(), !139)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %arg0, i1 %arg1), !dbg !140
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %arg2, i1 %arg3), !dbg !141
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v4, i1 %v5), !dbg !142
  ret i1 %v6, !dbg !143
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !149 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !150, !DIExpression(), !151)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !152, !DIExpression(), !153)
  %v2 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %arg1, i64 8, i1 false), !dbg !154
  %v3 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v2), !dbg !155
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !156
optional.decision.some.0:
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v2), !dbg !157
    #dbg_value(ptr %v4, !158, !DIExpression(), !159)
  br label %optional.decision.merge.2, !dbg !160
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !161
optional.decision.merge.2:
  %v5 = phi ptr [%v4, %optional.decision.some.0], [@topal.region-instance.namespace-metadata.literal.int.0, %optional.decision.none.1], !dbg !162
  ret ptr %v5, !dbg !163
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !166 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !167, !DIExpression(), !168)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !169, !DIExpression(), !170)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4(ptr %arg0, ptr %arg1), !dbg !171
  ret ptr %v2, !dbg !172
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eindex_2dshape.36({ ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !185 {
entry:
  %v0 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 0, !dbg !186
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 1, !dbg !187
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 2, !dbg !188
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 3, !dbg !189
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 4, !dbg !190
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 5, !dbg !191
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 6, !dbg !192
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 7, !dbg !193
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 8, !dbg !194
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 9, !dbg !195
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 10, !dbg !196
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 11, !dbg !197
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 12, !dbg !198
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 13, !dbg !199
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 14, !dbg !200
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, 15, !dbg !201
  %v16 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg0, ptr %v16, align 8
    #dbg_declare(ptr %v16, !202, !DIExpression(), !203)
  %v17 = alloca ptr, align 8
  store ptr %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !204, !DIExpression(), !205)
  %v18 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.1), !dbg !206
  %v19 = icmp sle i32 %v18, 0, !dbg !207
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v7, ptr @topal.region-instance.namespace-metadata.literal.int.2), !dbg !208
  %v21 = icmp eq i32 %v20, 0, !dbg !209
  %v22 = icmp eq i1 %v21, true, !dbg !210
  %v23 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr @topal.region-instance.namespace-metadata.literal.int.3), !dbg !211
  %v24 = icmp eq i32 %v23, 0, !dbg !212
  %v25 = icmp eq i1 %v24, true, !dbg !213
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v25), !dbg !214
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v19, i1 %v26), !dbg !215
    #dbg_value(i1 %v27, !216, !DIExpression(), !217)
  %v28 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v7, ptr @topal.region-instance.namespace-metadata.literal.int.4), !dbg !218
  %v29 = icmp slt i32 %v28, 0, !dbg !219
  %v30 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v7, ptr %v4), !dbg !220
  %v31 = icmp eq i32 %v30, 0, !dbg !221
  %v32 = icmp ne i1 %v31, true, !dbg !222
  %v33 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr @topal.region-instance.namespace-metadata.literal.int.5), !dbg !223
  %v34 = icmp sge i32 %v33, 0, !dbg !224
  %v35 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %v2), !dbg !225
  %v36 = icmp eq i32 %v35, 0, !dbg !226
  %v37 = icmp ne i1 %v36, true, !dbg !227
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v29, i1 %v32, i1 %v34, i1 %v37), !dbg !228
    #dbg_value(i1 %v38, !229, !DIExpression(), !230)
  %v39 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.6), !dbg !231
  %v40 = icmp sge i32 %v39, 0, !dbg !232
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v40, i1 %v38), !dbg !233
    #dbg_value(i1 %v41, !234, !DIExpression(), !235)
  %v42 = xor i1 %v27, true, !dbg !236
  %v43 = xor i1 %v41, true, !dbg !237
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v42, i1 %v43), !dbg !238
  %v45 = xor i1 %v44, true, !dbg !239
    #dbg_value(i1 %v45, !240, !DIExpression(), !241)
  %v46 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.7), !dbg !242
  %v47 = icmp slt i32 %v46, 0, !dbg !243
  %v48 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v1, ptr @topal.region-instance.namespace-metadata.literal.int.8), !dbg !244
  %v49 = icmp sle i32 %v48, 0, !dbg !245
  %v50 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.9), !dbg !246
  %v51 = icmp sge i32 %v50, 0, !dbg !247
  %v52 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.10), !dbg !248
  %v53 = icmp sle i32 %v52, 0, !dbg !249
  %v54 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v47, i1 %v49, i1 %v51, i1 %v53), !dbg !250
    #dbg_value(i1 %v54, !251, !DIExpression(), !252)
  %v55 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.11), !dbg !253
  %v56 = icmp slt i32 %v55, 0, !dbg !254
  %v57 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.12), !dbg !255
  %v58 = icmp sle i32 %v57, 0, !dbg !256
  %v59 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v54, i1 %v45, i1 %v56, i1 %v58), !dbg !257
  ret i1 %v59, !dbg !258
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !261 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !262, !DIExpression(), !263)
  %v1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.14), !dbg !264
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.13, ptr %v1), !dbg !265
  ret ptr %v2, !dbg !266
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !269 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !270, !DIExpression(), !271)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !272, !DIExpression(), !273)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !274, !DIExpression(), !275)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %arg1), !dbg !276
  %v4 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr %arg2), !dbg !277
  %v5 = icmp eq i32 %v4, 0, !dbg !278
  %v6 = icmp eq i1 %v5, true, !dbg !279
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !280
decision.true.0:
  br label %decision.merge.2, !dbg !281
decision.false.1:
  br label %decision.merge.2, !dbg !282
decision.merge.2:
  %v7 = phi ptr [@topal.region-instance.namespace-metadata.literal.int.15, %decision.true.0], [@topal.region-instance.namespace-metadata.literal.int.16, %decision.false.1], !dbg !283
  ret ptr %v7, !dbg !284
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !287 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !288, !DIExpression(), !289)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !290, !DIExpression(), !291)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.17, ptr %arg1), !dbg !292
    #dbg_value(ptr %v2, !293, !DIExpression(), !294)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.18, ptr %arg1), !dbg !295
    #dbg_value(ptr %v3, !296, !DIExpression(), !297)
  %v4 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.19, ptr %arg1), !dbg !298
    #dbg_value(ptr %v4, !299, !DIExpression(), !300)
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.20, ptr %arg1), !dbg !301
    #dbg_value(ptr %v5, !302, !DIExpression(), !303)
  %v6 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v2, ptr %v3), !dbg !304
  %v7 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v6, ptr %v4), !dbg !305
  %v8 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v7, ptr %v5), !dbg !306
  ret ptr %v8, !dbg !307
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !310 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !311, !DIExpression(), !312)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !313, !DIExpression(), !314)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !315, !DIExpression(), !316)
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.21), !dbg !317
  %v4 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v3), !dbg !318
    #dbg_value(ptr %v4, !319, !DIExpression(), !320)
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %arg1), !dbg !321
  %v6 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.22), !dbg !322
  %v7 = icmp eq i32 %v6, 0, !dbg !323
  %v8 = icmp eq i1 %v7, true, !dbg !324
  %v9 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.23), !dbg !325
  %v10 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v9), !dbg !326
  %v11 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v10, ptr %arg2), !dbg !327
  %v12 = icmp eq i32 %v11, 0, !dbg !328
  %v13 = icmp eq i1 %v12, true, !dbg !329
  %v14 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.24), !dbg !330
  %v15 = icmp sge i32 %v14, 0, !dbg !331
  %v16 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.25), !dbg !332
  %v17 = icmp sle i32 %v16, 0, !dbg !333
  %v18 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v8, i1 %v13, i1 %v15, i1 %v17), !dbg !334
  ret i1 %v18, !dbg !335
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !338 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !339, !DIExpression(), !340)
  %v1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.27), !dbg !341
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.26, ptr %v1), !dbg !342
  ret ptr %v2, !dbg !343
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !346 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !347, !DIExpression(), !348)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !349, !DIExpression(), !350)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !351, !DIExpression(), !352)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %arg1), !dbg !353
    #dbg_value(ptr %v3, !354, !DIExpression(), !355)
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.28), !dbg !356
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v4), !dbg !357
    #dbg_value(ptr %v5, !358, !DIExpression(), !359)
  %v6 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v3), !dbg !360
  %v7 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %arg2), !dbg !361
  %v8 = icmp eq i32 %v7, 0, !dbg !362
  %v9 = icmp eq i1 %v8, true, !dbg !363
  %v10 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.29), !dbg !364
  %v11 = icmp sgt i32 %v10, 0, !dbg !365
  %v12 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v5, ptr @topal.region-instance.namespace-metadata.literal.int.30), !dbg !366
  %v13 = icmp sle i32 %v12, 0, !dbg !367
  %v14 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.31), !dbg !368
  %v15 = icmp sge i32 %v14, 0, !dbg !369
  %v16 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v9, i1 %v11, i1 %v13, i1 %v15), !dbg !370
  ret i1 %v16, !dbg !371
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dentry_2dvalid.96(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !374 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !375, !DIExpression(), !376)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !377
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !378
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !379
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !380
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !381
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !382
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !383
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !384
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !385
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !386
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !387
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !388
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !389
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !390
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !391
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !392
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !393, !DIExpression(), !394)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !395, !DIExpression(), !396)
  %v19 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.32), !dbg !397
  %v20 = icmp slt i32 %v19, 0, !dbg !398
  br i1 %v20, label %decision.true.0, label %decision.false.1, !dbg !399
decision.true.0:
  %v21 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94(ptr %arg0, ptr %v2, ptr %v3), !dbg !400
  br label %decision.merge.2, !dbg !401
decision.false.1:
  %v22 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.33), !dbg !402
  %v23 = icmp eq i32 %v22, 0, !dbg !403
  %v24 = icmp eq i1 %v23, true, !dbg !404
  %v25 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.34), !dbg !405
  %v26 = icmp eq i32 %v25, 0, !dbg !406
  %v27 = icmp eq i1 %v26, true, !dbg !407
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v24, i1 %v27), !dbg !408
  br label %decision.merge.2, !dbg !409
decision.merge.2:
  %v29 = phi i1 [%v21, %decision.true.0], [%v28, %decision.false.1], !dbg !410
  ret i1 %v29, !dbg !411
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dvalid.98(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !414 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !415, !DIExpression(), !416)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !417
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !418
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !419
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !420
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !421
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !422
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !423
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !424
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !425
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !426
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !427
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !428
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !429
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !430
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !431
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !432
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !433, !DIExpression(), !434)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !435, !DIExpression(), !436)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !437
    #dbg_value(ptr %v19, !438, !DIExpression(), !439)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59(ptr %arg0, ptr %v3), !dbg !440
    #dbg_value(ptr %v20, !441, !DIExpression(), !442)
  %v21 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.35), !dbg !443
  %v22 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v21), !dbg !444
    #dbg_value(ptr %v22, !445, !DIExpression(), !446)
  %v23 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.36), !dbg !447
  %v24 = icmp eq i32 %v23, 0, !dbg !448
  %v25 = icmp eq i1 %v24, true, !dbg !449
  %v26 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.37), !dbg !450
  %v27 = icmp eq i32 %v26, 0, !dbg !451
  %v28 = icmp eq i1 %v27, true, !dbg !452
  %v29 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v22, ptr @topal.region-instance.namespace-metadata.literal.int.38), !dbg !453
  %v30 = icmp eq i32 %v29, 0, !dbg !454
  %v31 = icmp eq i1 %v30, true, !dbg !455
  %v32 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.39), !dbg !456
  %v33 = icmp eq i32 %v32, 0, !dbg !457
  %v34 = icmp eq i1 %v33, true, !dbg !458
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v25, i1 %v28, i1 %v31, i1 %v34), !dbg !459
    #dbg_value(i1 %v35, !460, !DIExpression(), !461)
  %v36 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.40), !dbg !462
  %v37 = icmp sgt i32 %v36, 0, !dbg !463
  %v38 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v22, ptr @topal.region-instance.namespace-metadata.literal.int.41), !dbg !464
  %v39 = icmp eq i32 %v38, 0, !dbg !465
  %v40 = icmp eq i1 %v39, true, !dbg !466
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v37, i1 %v40), !dbg !467
    #dbg_value(i1 %v41, !468, !DIExpression(), !469)
  %v42 = xor i1 %v35, true, !dbg !470
  %v43 = xor i1 %v41, true, !dbg !471
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v42, i1 %v43), !dbg !472
  %v45 = xor i1 %v44, true, !dbg !473
    #dbg_value(i1 %v45, !474, !DIExpression(), !475)
  %v46 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78(ptr %arg0, ptr %v19, ptr %v3), !dbg !476
  %v47 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v20, ptr %v4), !dbg !477
  %v48 = icmp eq i32 %v47, 0, !dbg !478
  %v49 = icmp eq i1 %v48, true, !dbg !479
  %v50 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.42), !dbg !480
  %v51 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v50), !dbg !481
  %v52 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v51, ptr %v20), !dbg !482
  %v53 = icmp eq i32 %v52, 0, !dbg !483
  %v54 = icmp eq i1 %v53, true, !dbg !484
  %v55 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v46, i1 %v49, i1 %v54, i1 %v45), !dbg !485
    #dbg_value(i1 %v55, !486, !DIExpression(), !487)
  %v56 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !488
  %v57 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v56, ptr %v2, 1, !dbg !489
  %v58 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v57, ptr %v3, 2, !dbg !490
  %v59 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v58, ptr %v4, 3, !dbg !491
  %v60 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v59, ptr %v5, 4, !dbg !492
  %v61 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v60, ptr %v6, 5, !dbg !493
  %v62 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v61, ptr %v7, 6, !dbg !494
  %v63 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v62, ptr %v8, 7, !dbg !495
  %v64 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v63, i32 %v9, 8, !dbg !496
  %v65 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v64, i32 %v10, 9, !dbg !497
  %v66 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v65, i32 %v11, 10, !dbg !498
  %v67 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v66, i32 %v12, 11, !dbg !499
  %v68 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v67, i32 %v13, 12, !dbg !500
  %v69 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v68, i32 %v14, 13, !dbg !501
  %v70 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v69, i32 %v15, 14, !dbg !502
  %v71 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v70, i32 %v16, 15, !dbg !503
  %v72 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dentry_2dvalid.96(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v71, ptr %arg2), !dbg !504
  %v73 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v55, i1 %v72), !dbg !505
  ret i1 %v73, !dbg !506
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !509 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !510, !DIExpression(), !511)
  %v1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.multiply(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.44), !dbg !512
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.43, ptr %v1), !dbg !513
  ret ptr %v2, !dbg !514
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !517 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !518, !DIExpression(), !519)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !520, !DIExpression(), !521)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4(ptr %arg0, ptr %arg1), !dbg !522
    #dbg_value(ptr %v2, !523, !DIExpression(), !524)
  %v3 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.45), !dbg !525
  %v4 = icmp eq i32 %v3, 0, !dbg !526
  %v5 = icmp eq i1 %v4, true, !dbg !527
  ret i1 %v5, !dbg !528
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !531 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !532, !DIExpression(), !533)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !534, !DIExpression(), !535)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102(ptr %arg0, ptr %arg1), !dbg !536
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !537
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.46), !dbg !538
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102(ptr %arg0, ptr %v3), !dbg !539
  br label %decision.merge.2, !dbg !540
decision.false.1:
  br label %decision.merge.2, !dbg !541
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !542
  ret i1 %v5, !dbg !543
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !546 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !547, !DIExpression(), !548)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !549, !DIExpression(), !550)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105(ptr %arg0, ptr %arg1), !dbg !551
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !552
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.47), !dbg !553
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105(ptr %arg0, ptr %v3), !dbg !554
  br label %decision.merge.2, !dbg !555
decision.false.1:
  br label %decision.merge.2, !dbg !556
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !557
  ret i1 %v5, !dbg !558
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !561 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !562, !DIExpression(), !563)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !564, !DIExpression(), !565)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111(ptr %arg0, ptr %arg1), !dbg !566
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !567
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.48), !dbg !568
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111(ptr %arg0, ptr %v3), !dbg !569
  br label %decision.merge.2, !dbg !570
decision.false.1:
  br label %decision.merge.2, !dbg !571
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !572
  ret i1 %v5, !dbg !573
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !576 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !577, !DIExpression(), !578)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !579, !DIExpression(), !580)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr %arg1), !dbg !581
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !582
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.49), !dbg !583
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr %v3), !dbg !584
  br label %decision.merge.2, !dbg !585
decision.false.1:
  br label %decision.merge.2, !dbg !586
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !587
  ret i1 %v5, !dbg !588
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dname.195(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !591 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !592, !DIExpression(), !593)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !594, !DIExpression(), !595)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr %arg1), !dbg !596
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !597
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.50), !dbg !598
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr %v3), !dbg !599
  br label %decision.merge.2, !dbg !600
decision.false.1:
  br label %decision.merge.2, !dbg !601
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !602
  ret i1 %v5, !dbg !603
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eempty_2dtarget.204(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !606 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !607, !DIExpression(), !608)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !609
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !610
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !611
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !612
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !613
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !614
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !615
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !616
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !617
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !618
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !619
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !620
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !621
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !622
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !623
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !624
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !625, !DIExpression(), !626)
  %v18 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !627
    #dbg_value(ptr %v18, !628, !DIExpression(), !629)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v6), !dbg !630
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dname.195(ptr %arg0, ptr %v19), !dbg !631
    #dbg_value(i1 %v20, !632, !DIExpression(), !633)
  %v21 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v18), !dbg !634
  %v22 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v21, ptr @topal.region-instance.namespace-metadata.literal.int.51), !dbg !635
  %v23 = icmp eq i32 %v22, 0, !dbg !636
  %v24 = icmp eq i1 %v23, true, !dbg !637
  %v25 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v18, ptr @topal.region-instance.namespace-metadata.literal.int.52), !dbg !638
  %v26 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v25), !dbg !639
  %v27 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v26, ptr @topal.region-instance.namespace-metadata.literal.int.53), !dbg !640
  %v28 = icmp eq i32 %v27, 0, !dbg !641
  %v29 = icmp eq i1 %v28, true, !dbg !642
  %v30 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.54), !dbg !643
  %v31 = icmp slt i32 %v30, 0, !dbg !644
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v24, i1 %v29, i1 %v20, i1 %v31), !dbg !645
  ret i1 %v32, !dbg !646
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elive_2dtarget.257(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !649 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !650, !DIExpression(), !651)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !652
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !653
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !654
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !655
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !656
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !657
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !658
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !659
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !660
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !661
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !662
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !663
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !664
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !665
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !666
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !667
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !668, !DIExpression(), !669)
  %v18 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v8), !dbg !670
    #dbg_value(ptr %v18, !671, !DIExpression(), !672)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59(ptr %arg0, ptr %v7), !dbg !673
    #dbg_value(ptr %v19, !674, !DIExpression(), !675)
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78(ptr %arg0, ptr %v18, ptr %v7), !dbg !676
  %v21 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.55), !dbg !677
  %v22 = icmp sgt i32 %v21, 0, !dbg !678
  %v23 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v18, ptr @topal.region-instance.namespace-metadata.literal.int.56), !dbg !679
  %v24 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v23), !dbg !680
  %v25 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v24, ptr %v19), !dbg !681
  %v26 = icmp eq i32 %v25, 0, !dbg !682
  %v27 = icmp eq i1 %v26, true, !dbg !683
  %v28 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v18, ptr @topal.region-instance.namespace-metadata.literal.int.57), !dbg !684
  %v29 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v28), !dbg !685
  %v30 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v29, ptr @topal.region-instance.namespace-metadata.literal.int.58), !dbg !686
  %v31 = icmp eq i32 %v30, 0, !dbg !687
  %v32 = icmp eq i1 %v31, true, !dbg !688
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v20, i1 %v22, i1 %v27, i1 %v32), !dbg !689
    #dbg_value(i1 %v33, !690, !DIExpression(), !691)
  %v34 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94(ptr %arg0, ptr %v6, ptr %v7), !dbg !692
    #dbg_value(i1 %v34, !693, !DIExpression(), !694)
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v33, i1 %v34), !dbg !695
  ret i1 %v35, !dbg !696
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dmove_2dor_2dlive.258(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !699 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !700, !DIExpression(), !701)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !702
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !703
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !704
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !705
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !706
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !707
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !708
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !709
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !710
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !711
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !712
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !713
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !714
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !715
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !716
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !717
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !718, !DIExpression(), !719)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !720, !DIExpression(), !721)
  %v19 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.59), !dbg !722
  %v20 = icmp eq i32 %v19, 0, !dbg !723
  %v21 = icmp eq i1 %v20, true, !dbg !724
  br i1 %v21, label %decision.true.0, label %decision.false.1, !dbg !725
decision.true.0:
  %v22 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %v2), !dbg !726
  %v23 = icmp eq i32 %v22, 0, !dbg !727
  %v24 = icmp eq i1 %v23, true, !dbg !728
  br label %decision.merge.2, !dbg !729
decision.false.1:
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !730
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v2, 1, !dbg !731
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v3, 2, !dbg !732
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v4, 3, !dbg !733
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v5, 4, !dbg !734
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v6, 5, !dbg !735
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, ptr %v7, 6, !dbg !736
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, ptr %v8, 7, !dbg !737
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v9, 8, !dbg !738
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v10, 9, !dbg !739
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v11, 10, !dbg !740
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v12, 11, !dbg !741
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v13, 12, !dbg !742
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v14, 13, !dbg !743
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, i32 %v15, 14, !dbg !744
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, i32 %v16, 15, !dbg !745
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elive_2dtarget.257(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40), !dbg !746
  br label %decision.merge.2, !dbg !747
decision.merge.2:
  %v42 = phi i1 [%v24, %decision.true.0], [%v41, %decision.false.1], !dbg !748
  ret i1 %v42, !dbg !749
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dvalid.259(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !752 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !753, !DIExpression(), !754)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !755
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !756
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !757
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !758
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !759
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !760
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !761
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !762
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !763
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !764
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !765
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !766
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !767
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !768
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !769
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !770
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !771, !DIExpression(), !772)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !773, !DIExpression(), !774)
  %v19 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.60), !dbg !775
  %v20 = icmp eq i32 %v19, 0, !dbg !776
  %v21 = icmp eq i1 %v20, true, !dbg !777
  br i1 %v21, label %decision.true.0, label %decision.false.1, !dbg !778
decision.true.0:
  %v22 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !779
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v22, ptr %v2, 1, !dbg !780
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v3, 2, !dbg !781
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v4, 3, !dbg !782
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v5, 4, !dbg !783
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v6, 5, !dbg !784
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v7, 6, !dbg !785
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v8, 7, !dbg !786
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, i32 %v9, 8, !dbg !787
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v10, 9, !dbg !788
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v11, 10, !dbg !789
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v12, 11, !dbg !790
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v13, 12, !dbg !791
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v14, 13, !dbg !792
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v15, 14, !dbg !793
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v16, 15, !dbg !794
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eempty_2dtarget.204(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37), !dbg !795
  br label %decision.merge.2, !dbg !796
decision.false.1:
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !797
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, ptr %v2, 1, !dbg !798
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v3, 2, !dbg !799
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v4, 3, !dbg !800
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v5, 4, !dbg !801
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v6, 5, !dbg !802
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v7, 6, !dbg !803
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v8, 7, !dbg !804
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, i32 %v9, 8, !dbg !805
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v10, 9, !dbg !806
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v11, 10, !dbg !807
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v12, 11, !dbg !808
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v13, 12, !dbg !809
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v14, 13, !dbg !810
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v15, 14, !dbg !811
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v16, 15, !dbg !812
  %v55 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dmove_2dor_2dlive.258(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, ptr %arg2), !dbg !813
  br label %decision.merge.2, !dbg !814
decision.merge.2:
  %v56 = phi i1 [%v38, %decision.true.0], [%v55, %decision.false.1], !dbg !815
  ret i1 %v56, !dbg !816
}

define internal fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !819 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !820, !DIExpression(), !821)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !822, !DIExpression(), !823)
  %v2 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr @topal.region-instance.namespace-metadata.literal.int.61, ptr %arg1), !dbg !824
    #dbg_value(ptr %v2, !825, !DIExpression(), !826)
  %v3 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %v2, i64 1, i1 false), !dbg !827
  %v4 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v3), !dbg !828
  br i1 %v4, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !829
optional.decision.some.0:
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v3), !dbg !830
    #dbg_value(ptr %v5, !831, !DIExpression(), !832)
  br label %optional.decision.merge.2, !dbg !833
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !834
optional.decision.merge.2:
  %v6 = phi ptr [%v5, %optional.decision.some.0], [@topal.region-instance.namespace-metadata.literal.int.62, %optional.decision.none.1], !dbg !835
  ret ptr %v6, !dbg !836
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %arg0, i1 %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !839 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !840, !DIExpression(), !841)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !842, !DIExpression(), !843)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !844
decision.true.0:
  br label %decision.merge.2, !dbg !845
decision.false.1:
  br label %decision.merge.2, !dbg !846
decision.merge.2:
  %v2 = phi i1 [%arg1, %decision.true.0], [false, %decision.false.1], !dbg !847
  ret i1 %v2, !dbg !848
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2enot_2ddot.335(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !851 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !852, !DIExpression(), !853)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !854, !DIExpression(), !855)
  %v2 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.63), !dbg !856
    #dbg_value(ptr %v2, !857, !DIExpression(), !858)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.64), !dbg !859
    #dbg_value(ptr %v3, !860, !DIExpression(), !861)
  %v4 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.65), !dbg !862
  %v5 = icmp eq i32 %v4, 0, !dbg !863
  %v6 = icmp eq i1 %v5, true, !dbg !864
    #dbg_value(i1 %v6, !865, !DIExpression(), !866)
  %v7 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.66), !dbg !867
  %v8 = icmp eq i32 %v7, 0, !dbg !868
  %v9 = icmp eq i1 %v8, true, !dbg !869
    #dbg_value(i1 %v9, !870, !DIExpression(), !871)
  %v10 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v2, ptr @topal.region-instance.namespace-metadata.literal.int.67), !dbg !872
  %v11 = icmp eq i32 %v10, 0, !dbg !873
  %v12 = icmp eq i1 %v11, true, !dbg !874
    #dbg_value(i1 %v12, !875, !DIExpression(), !876)
  %v13 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.68), !dbg !877
  %v14 = icmp eq i32 %v13, 0, !dbg !878
  %v15 = icmp eq i1 %v14, true, !dbg !879
    #dbg_value(i1 %v15, !880, !DIExpression(), !881)
  %v16 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v6, i1 %v12), !dbg !882
    #dbg_value(i1 %v16, !883, !DIExpression(), !884)
  %v17 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v12, i1 %v15), !dbg !885
  %v18 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v9, i1 %v17), !dbg !886
    #dbg_value(i1 %v18, !887, !DIExpression(), !888)
  br i1 %v16, label %decision.true.0, label %decision.false.1, !dbg !889
decision.true.0:
  br label %decision.merge.2, !dbg !890
decision.false.1:
  %v19 = xor i1 %v18, true, !dbg !891
  br label %decision.merge.2, !dbg !892
decision.merge.2:
  %v20 = phi i1 [false, %decision.true.0], [%v19, %decision.false.1], !dbg !893
  ret i1 %v20, !dbg !894
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2echaracter.338(ptr %arg0) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !897 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !898, !DIExpression(), !899)
  %v1 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.69), !dbg !900
  %v2 = icmp sgt i32 %v1, 0, !dbg !901
    #dbg_value(i1 %v2, !902, !DIExpression(), !903)
  %v3 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.70), !dbg !904
  %v4 = icmp sle i32 %v3, 0, !dbg !905
    #dbg_value(i1 %v4, !906, !DIExpression(), !907)
  %v5 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.71), !dbg !908
  %v6 = icmp eq i32 %v5, 0, !dbg !909
  %v7 = icmp ne i1 %v6, true, !dbg !910
    #dbg_value(i1 %v7, !911, !DIExpression(), !912)
  %v8 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v4, i1 %v7), !dbg !913
  %v9 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v2, i1 %v8), !dbg !914
  ret i1 %v9, !dbg !915
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dvalue.339(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !918 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !919, !DIExpression(), !920)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !921, !DIExpression(), !922)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !923, !DIExpression(), !924)
  %v3 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr %arg2), !dbg !925
  %v4 = icmp slt i32 %v3, 0, !dbg !926
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !927
decision.true.0:
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2echaracter.338(ptr %arg0), !dbg !928
  br label %decision.merge.2, !dbg !929
decision.false.1:
  %v6 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.72), !dbg !930
  %v7 = icmp eq i32 %v6, 0, !dbg !931
  %v8 = icmp eq i1 %v7, true, !dbg !932
  br label %decision.merge.2, !dbg !933
decision.merge.2:
  %v9 = phi i1 [%v5, %decision.true.0], [%v8, %decision.false.1], !dbg !934
  ret i1 %v9, !dbg !935
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !938 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !939, !DIExpression(), !940)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !941, !DIExpression(), !942)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !943, !DIExpression(), !944)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !945, !DIExpression(), !946)
  %v4 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %arg1, i64 1, i1 false), !dbg !947
  %v5 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v4), !dbg !948
  br i1 %v5, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !949
optional.decision.some.0:
  %v6 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v4), !dbg !950
    #dbg_value(ptr %v6, !951, !DIExpression(), !952)
  %v7 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dvalue.339(ptr %v6, ptr %arg2, ptr %arg3), !dbg !953
  br label %optional.decision.merge.2, !dbg !954
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !955
optional.decision.merge.2:
  %v8 = phi i1 [%v7, %optional.decision.some.0], [false, %optional.decision.none.1], !dbg !956
  ret i1 %v8, !dbg !957
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %arg0, i1 %arg1, i1 %arg2, i1 %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !960 {
entry:
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !961, !DIExpression(), !962)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !963, !DIExpression(), !964)
  %v2 = alloca i1, align 1
  store i1 %arg2, ptr %v2, align 1
    #dbg_declare(ptr %v2, !965, !DIExpression(), !966)
  %v3 = alloca i1, align 1
  store i1 %arg3, ptr %v3, align 1
    #dbg_declare(ptr %v3, !967, !DIExpression(), !968)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %arg0, i1 %arg1), !dbg !969
    #dbg_value(i1 %v4, !970, !DIExpression(), !971)
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %arg2, i1 %arg3), !dbg !972
    #dbg_value(i1 %v5, !973, !DIExpression(), !974)
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332(i1 %v4, i1 %v5), !dbg !975
  ret i1 %v6, !dbg !976
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dpayload.1956(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !979 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !980, !DIExpression(), !981)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !982, !DIExpression(), !983)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.73, ptr @topal.region-instance.namespace-metadata.literal.int.74, ptr %arg1), !dbg !984
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.75, ptr @topal.region-instance.namespace-metadata.literal.int.76, ptr %arg1), !dbg !985
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.77, ptr @topal.region-instance.namespace-metadata.literal.int.78, ptr %arg1), !dbg !986
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.79, ptr @topal.region-instance.namespace-metadata.literal.int.80, ptr %arg1), !dbg !987
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v2, i1 %v3, i1 %v4, i1 %v5), !dbg !988
    #dbg_value(i1 %v6, !989, !DIExpression(), !990)
  %v7 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.81, ptr @topal.region-instance.namespace-metadata.literal.int.82, ptr %arg1), !dbg !991
  %v8 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.83, ptr @topal.region-instance.namespace-metadata.literal.int.84, ptr %arg1), !dbg !992
  %v9 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.85, ptr @topal.region-instance.namespace-metadata.literal.int.86, ptr %arg1), !dbg !993
  %v10 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.87, ptr @topal.region-instance.namespace-metadata.literal.int.88, ptr %arg1), !dbg !994
  %v11 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v7, i1 %v8, i1 %v9, i1 %v10), !dbg !995
    #dbg_value(i1 %v11, !996, !DIExpression(), !997)
  %v12 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.89, ptr @topal.region-instance.namespace-metadata.literal.int.90, ptr %arg1), !dbg !998
  %v13 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.91, ptr @topal.region-instance.namespace-metadata.literal.int.92, ptr %arg1), !dbg !999
  %v14 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.93, ptr @topal.region-instance.namespace-metadata.literal.int.94, ptr %arg1), !dbg !1000
  %v15 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.95, ptr @topal.region-instance.namespace-metadata.literal.int.96, ptr %arg1), !dbg !1001
  %v16 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v12, i1 %v13, i1 %v14, i1 %v15), !dbg !1002
    #dbg_value(i1 %v16, !1003, !DIExpression(), !1004)
  %v17 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.97, ptr @topal.region-instance.namespace-metadata.literal.int.98, ptr %arg1), !dbg !1005
  %v18 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.99, ptr @topal.region-instance.namespace-metadata.literal.int.100, ptr %arg1), !dbg !1006
  %v19 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.101, ptr @topal.region-instance.namespace-metadata.literal.int.102, ptr %arg1), !dbg !1007
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.103, ptr @topal.region-instance.namespace-metadata.literal.int.104, ptr %arg1), !dbg !1008
  %v21 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v17, i1 %v18, i1 %v19, i1 %v20), !dbg !1009
    #dbg_value(i1 %v21, !1010, !DIExpression(), !1011)
  %v22 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.105, ptr @topal.region-instance.namespace-metadata.literal.int.106, ptr %arg1), !dbg !1012
  %v23 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.107, ptr @topal.region-instance.namespace-metadata.literal.int.108, ptr %arg1), !dbg !1013
  %v24 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.109, ptr @topal.region-instance.namespace-metadata.literal.int.110, ptr %arg1), !dbg !1014
  %v25 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.111, ptr @topal.region-instance.namespace-metadata.literal.int.112, ptr %arg1), !dbg !1015
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v22, i1 %v23, i1 %v24, i1 %v25), !dbg !1016
    #dbg_value(i1 %v26, !1017, !DIExpression(), !1018)
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.113, ptr @topal.region-instance.namespace-metadata.literal.int.114, ptr %arg1), !dbg !1019
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.115, ptr @topal.region-instance.namespace-metadata.literal.int.116, ptr %arg1), !dbg !1020
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.117, ptr @topal.region-instance.namespace-metadata.literal.int.118, ptr %arg1), !dbg !1021
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.119, ptr @topal.region-instance.namespace-metadata.literal.int.120, ptr %arg1), !dbg !1022
  %v31 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v27, i1 %v28, i1 %v29, i1 %v30), !dbg !1023
    #dbg_value(i1 %v31, !1024, !DIExpression(), !1025)
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.121, ptr @topal.region-instance.namespace-metadata.literal.int.122, ptr %arg1), !dbg !1026
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.123, ptr @topal.region-instance.namespace-metadata.literal.int.124, ptr %arg1), !dbg !1027
  %v34 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.125, ptr @topal.region-instance.namespace-metadata.literal.int.126, ptr %arg1), !dbg !1028
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.127, ptr @topal.region-instance.namespace-metadata.literal.int.128, ptr %arg1), !dbg !1029
  %v36 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v32, i1 %v33, i1 %v34, i1 %v35), !dbg !1030
    #dbg_value(i1 %v36, !1031, !DIExpression(), !1032)
  %v37 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.129, ptr @topal.region-instance.namespace-metadata.literal.int.130, ptr %arg1), !dbg !1033
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.131, ptr @topal.region-instance.namespace-metadata.literal.int.132, ptr %arg1), !dbg !1034
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.133, ptr @topal.region-instance.namespace-metadata.literal.int.134, ptr %arg1), !dbg !1035
  %v40 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.135, ptr @topal.region-instance.namespace-metadata.literal.int.136, ptr %arg1), !dbg !1036
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v37, i1 %v38, i1 %v39, i1 %v40), !dbg !1037
    #dbg_value(i1 %v41, !1038, !DIExpression(), !1039)
  %v42 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.137, ptr @topal.region-instance.namespace-metadata.literal.int.138, ptr %arg1), !dbg !1040
  %v43 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.139, ptr @topal.region-instance.namespace-metadata.literal.int.140, ptr %arg1), !dbg !1041
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.141, ptr @topal.region-instance.namespace-metadata.literal.int.142, ptr %arg1), !dbg !1042
  %v45 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.143, ptr @topal.region-instance.namespace-metadata.literal.int.144, ptr %arg1), !dbg !1043
  %v46 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v42, i1 %v43, i1 %v44, i1 %v45), !dbg !1044
    #dbg_value(i1 %v46, !1045, !DIExpression(), !1046)
  %v47 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.145, ptr @topal.region-instance.namespace-metadata.literal.int.146, ptr %arg1), !dbg !1047
  %v48 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.147, ptr @topal.region-instance.namespace-metadata.literal.int.148, ptr %arg1), !dbg !1048
  %v49 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.149, ptr @topal.region-instance.namespace-metadata.literal.int.150, ptr %arg1), !dbg !1049
  %v50 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.151, ptr @topal.region-instance.namespace-metadata.literal.int.152, ptr %arg1), !dbg !1050
  %v51 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v47, i1 %v48, i1 %v49, i1 %v50), !dbg !1051
    #dbg_value(i1 %v51, !1052, !DIExpression(), !1053)
  %v52 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.153, ptr @topal.region-instance.namespace-metadata.literal.int.154, ptr %arg1), !dbg !1054
  %v53 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.155, ptr @topal.region-instance.namespace-metadata.literal.int.156, ptr %arg1), !dbg !1055
  %v54 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.157, ptr @topal.region-instance.namespace-metadata.literal.int.158, ptr %arg1), !dbg !1056
  %v55 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.159, ptr @topal.region-instance.namespace-metadata.literal.int.160, ptr %arg1), !dbg !1057
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v52, i1 %v53, i1 %v54, i1 %v55), !dbg !1058
    #dbg_value(i1 %v56, !1059, !DIExpression(), !1060)
  %v57 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.161, ptr @topal.region-instance.namespace-metadata.literal.int.162, ptr %arg1), !dbg !1061
  %v58 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.163, ptr @topal.region-instance.namespace-metadata.literal.int.164, ptr %arg1), !dbg !1062
  %v59 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.165, ptr @topal.region-instance.namespace-metadata.literal.int.166, ptr %arg1), !dbg !1063
  %v60 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.167, ptr @topal.region-instance.namespace-metadata.literal.int.168, ptr %arg1), !dbg !1064
  %v61 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v57, i1 %v58, i1 %v59, i1 %v60), !dbg !1065
    #dbg_value(i1 %v61, !1066, !DIExpression(), !1067)
  %v62 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.169, ptr @topal.region-instance.namespace-metadata.literal.int.170, ptr %arg1), !dbg !1068
  %v63 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.171, ptr @topal.region-instance.namespace-metadata.literal.int.172, ptr %arg1), !dbg !1069
  %v64 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.173, ptr @topal.region-instance.namespace-metadata.literal.int.174, ptr %arg1), !dbg !1070
  %v65 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.175, ptr @topal.region-instance.namespace-metadata.literal.int.176, ptr %arg1), !dbg !1071
  %v66 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v62, i1 %v63, i1 %v64, i1 %v65), !dbg !1072
    #dbg_value(i1 %v66, !1073, !DIExpression(), !1074)
  %v67 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.177, ptr @topal.region-instance.namespace-metadata.literal.int.178, ptr %arg1), !dbg !1075
  %v68 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.179, ptr @topal.region-instance.namespace-metadata.literal.int.180, ptr %arg1), !dbg !1076
  %v69 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.181, ptr @topal.region-instance.namespace-metadata.literal.int.182, ptr %arg1), !dbg !1077
  %v70 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.183, ptr @topal.region-instance.namespace-metadata.literal.int.184, ptr %arg1), !dbg !1078
  %v71 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v67, i1 %v68, i1 %v69, i1 %v70), !dbg !1079
    #dbg_value(i1 %v71, !1080, !DIExpression(), !1081)
  %v72 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.185, ptr @topal.region-instance.namespace-metadata.literal.int.186, ptr %arg1), !dbg !1082
  %v73 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.187, ptr @topal.region-instance.namespace-metadata.literal.int.188, ptr %arg1), !dbg !1083
  %v74 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.189, ptr @topal.region-instance.namespace-metadata.literal.int.190, ptr %arg1), !dbg !1084
  %v75 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.191, ptr @topal.region-instance.namespace-metadata.literal.int.192, ptr %arg1), !dbg !1085
  %v76 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v72, i1 %v73, i1 %v74, i1 %v75), !dbg !1086
    #dbg_value(i1 %v76, !1087, !DIExpression(), !1088)
  %v77 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.193, ptr @topal.region-instance.namespace-metadata.literal.int.194, ptr %arg1), !dbg !1089
  %v78 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.195, ptr @topal.region-instance.namespace-metadata.literal.int.196, ptr %arg1), !dbg !1090
  %v79 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.197, ptr @topal.region-instance.namespace-metadata.literal.int.198, ptr %arg1), !dbg !1091
  %v80 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.199, ptr @topal.region-instance.namespace-metadata.literal.int.200, ptr %arg1), !dbg !1092
  %v81 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v77, i1 %v78, i1 %v79, i1 %v80), !dbg !1093
    #dbg_value(i1 %v81, !1094, !DIExpression(), !1095)
  %v82 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.201, ptr @topal.region-instance.namespace-metadata.literal.int.202, ptr %arg1), !dbg !1096
  %v83 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.203, ptr @topal.region-instance.namespace-metadata.literal.int.204, ptr %arg1), !dbg !1097
  %v84 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.205, ptr @topal.region-instance.namespace-metadata.literal.int.206, ptr %arg1), !dbg !1098
  %v85 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.207, ptr @topal.region-instance.namespace-metadata.literal.int.208, ptr %arg1), !dbg !1099
  %v86 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v82, i1 %v83, i1 %v84, i1 %v85), !dbg !1100
    #dbg_value(i1 %v86, !1101, !DIExpression(), !1102)
  %v87 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.209, ptr @topal.region-instance.namespace-metadata.literal.int.210, ptr %arg1), !dbg !1103
  %v88 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.211, ptr @topal.region-instance.namespace-metadata.literal.int.212, ptr %arg1), !dbg !1104
  %v89 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.213, ptr @topal.region-instance.namespace-metadata.literal.int.214, ptr %arg1), !dbg !1105
  %v90 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.215, ptr @topal.region-instance.namespace-metadata.literal.int.216, ptr %arg1), !dbg !1106
  %v91 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v87, i1 %v88, i1 %v89, i1 %v90), !dbg !1107
    #dbg_value(i1 %v91, !1108, !DIExpression(), !1109)
  %v92 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.217, ptr @topal.region-instance.namespace-metadata.literal.int.218, ptr %arg1), !dbg !1110
  %v93 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.219, ptr @topal.region-instance.namespace-metadata.literal.int.220, ptr %arg1), !dbg !1111
  %v94 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.221, ptr @topal.region-instance.namespace-metadata.literal.int.222, ptr %arg1), !dbg !1112
  %v95 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.223, ptr @topal.region-instance.namespace-metadata.literal.int.224, ptr %arg1), !dbg !1113
  %v96 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v92, i1 %v93, i1 %v94, i1 %v95), !dbg !1114
    #dbg_value(i1 %v96, !1115, !DIExpression(), !1116)
  %v97 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.225, ptr @topal.region-instance.namespace-metadata.literal.int.226, ptr %arg1), !dbg !1117
  %v98 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.227, ptr @topal.region-instance.namespace-metadata.literal.int.228, ptr %arg1), !dbg !1118
  %v99 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.229, ptr @topal.region-instance.namespace-metadata.literal.int.230, ptr %arg1), !dbg !1119
  %v100 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.231, ptr @topal.region-instance.namespace-metadata.literal.int.232, ptr %arg1), !dbg !1120
  %v101 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v97, i1 %v98, i1 %v99, i1 %v100), !dbg !1121
    #dbg_value(i1 %v101, !1122, !DIExpression(), !1123)
  %v102 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.233, ptr @topal.region-instance.namespace-metadata.literal.int.234, ptr %arg1), !dbg !1124
  %v103 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.235, ptr @topal.region-instance.namespace-metadata.literal.int.236, ptr %arg1), !dbg !1125
  %v104 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.237, ptr @topal.region-instance.namespace-metadata.literal.int.238, ptr %arg1), !dbg !1126
  %v105 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.239, ptr @topal.region-instance.namespace-metadata.literal.int.240, ptr %arg1), !dbg !1127
  %v106 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v102, i1 %v103, i1 %v104, i1 %v105), !dbg !1128
    #dbg_value(i1 %v106, !1129, !DIExpression(), !1130)
  %v107 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.241, ptr @topal.region-instance.namespace-metadata.literal.int.242, ptr %arg1), !dbg !1131
  %v108 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.243, ptr @topal.region-instance.namespace-metadata.literal.int.244, ptr %arg1), !dbg !1132
  %v109 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.245, ptr @topal.region-instance.namespace-metadata.literal.int.246, ptr %arg1), !dbg !1133
  %v110 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.247, ptr @topal.region-instance.namespace-metadata.literal.int.248, ptr %arg1), !dbg !1134
  %v111 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v107, i1 %v108, i1 %v109, i1 %v110), !dbg !1135
    #dbg_value(i1 %v111, !1136, !DIExpression(), !1137)
  %v112 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.249, ptr @topal.region-instance.namespace-metadata.literal.int.250, ptr %arg1), !dbg !1138
  %v113 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.251, ptr @topal.region-instance.namespace-metadata.literal.int.252, ptr %arg1), !dbg !1139
  %v114 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.253, ptr @topal.region-instance.namespace-metadata.literal.int.254, ptr %arg1), !dbg !1140
  %v115 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.255, ptr @topal.region-instance.namespace-metadata.literal.int.256, ptr %arg1), !dbg !1141
  %v116 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v112, i1 %v113, i1 %v114, i1 %v115), !dbg !1142
    #dbg_value(i1 %v116, !1143, !DIExpression(), !1144)
  %v117 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.257, ptr @topal.region-instance.namespace-metadata.literal.int.258, ptr %arg1), !dbg !1145
  %v118 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.259, ptr @topal.region-instance.namespace-metadata.literal.int.260, ptr %arg1), !dbg !1146
  %v119 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.261, ptr @topal.region-instance.namespace-metadata.literal.int.262, ptr %arg1), !dbg !1147
  %v120 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.263, ptr @topal.region-instance.namespace-metadata.literal.int.264, ptr %arg1), !dbg !1148
  %v121 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v117, i1 %v118, i1 %v119, i1 %v120), !dbg !1149
    #dbg_value(i1 %v121, !1150, !DIExpression(), !1151)
  %v122 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.265, ptr @topal.region-instance.namespace-metadata.literal.int.266, ptr %arg1), !dbg !1152
  %v123 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.267, ptr @topal.region-instance.namespace-metadata.literal.int.268, ptr %arg1), !dbg !1153
  %v124 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.269, ptr @topal.region-instance.namespace-metadata.literal.int.270, ptr %arg1), !dbg !1154
  %v125 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.271, ptr @topal.region-instance.namespace-metadata.literal.int.272, ptr %arg1), !dbg !1155
  %v126 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v122, i1 %v123, i1 %v124, i1 %v125), !dbg !1156
    #dbg_value(i1 %v126, !1157, !DIExpression(), !1158)
  %v127 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.273, ptr @topal.region-instance.namespace-metadata.literal.int.274, ptr %arg1), !dbg !1159
  %v128 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.275, ptr @topal.region-instance.namespace-metadata.literal.int.276, ptr %arg1), !dbg !1160
  %v129 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.277, ptr @topal.region-instance.namespace-metadata.literal.int.278, ptr %arg1), !dbg !1161
  %v130 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.279, ptr @topal.region-instance.namespace-metadata.literal.int.280, ptr %arg1), !dbg !1162
  %v131 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v127, i1 %v128, i1 %v129, i1 %v130), !dbg !1163
    #dbg_value(i1 %v131, !1164, !DIExpression(), !1165)
  %v132 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.281, ptr @topal.region-instance.namespace-metadata.literal.int.282, ptr %arg1), !dbg !1166
  %v133 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.283, ptr @topal.region-instance.namespace-metadata.literal.int.284, ptr %arg1), !dbg !1167
  %v134 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.285, ptr @topal.region-instance.namespace-metadata.literal.int.286, ptr %arg1), !dbg !1168
  %v135 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.287, ptr @topal.region-instance.namespace-metadata.literal.int.288, ptr %arg1), !dbg !1169
  %v136 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v132, i1 %v133, i1 %v134, i1 %v135), !dbg !1170
    #dbg_value(i1 %v136, !1171, !DIExpression(), !1172)
  %v137 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.289, ptr @topal.region-instance.namespace-metadata.literal.int.290, ptr %arg1), !dbg !1173
  %v138 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.291, ptr @topal.region-instance.namespace-metadata.literal.int.292, ptr %arg1), !dbg !1174
  %v139 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.293, ptr @topal.region-instance.namespace-metadata.literal.int.294, ptr %arg1), !dbg !1175
  %v140 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.295, ptr @topal.region-instance.namespace-metadata.literal.int.296, ptr %arg1), !dbg !1176
  %v141 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v137, i1 %v138, i1 %v139, i1 %v140), !dbg !1177
    #dbg_value(i1 %v141, !1178, !DIExpression(), !1179)
  %v142 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.297, ptr @topal.region-instance.namespace-metadata.literal.int.298, ptr %arg1), !dbg !1180
  %v143 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.299, ptr @topal.region-instance.namespace-metadata.literal.int.300, ptr %arg1), !dbg !1181
  %v144 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.301, ptr @topal.region-instance.namespace-metadata.literal.int.302, ptr %arg1), !dbg !1182
  %v145 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.303, ptr @topal.region-instance.namespace-metadata.literal.int.304, ptr %arg1), !dbg !1183
  %v146 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v142, i1 %v143, i1 %v144, i1 %v145), !dbg !1184
    #dbg_value(i1 %v146, !1185, !DIExpression(), !1186)
  %v147 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.305, ptr @topal.region-instance.namespace-metadata.literal.int.306, ptr %arg1), !dbg !1187
  %v148 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.307, ptr @topal.region-instance.namespace-metadata.literal.int.308, ptr %arg1), !dbg !1188
  %v149 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.309, ptr @topal.region-instance.namespace-metadata.literal.int.310, ptr %arg1), !dbg !1189
  %v150 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.311, ptr @topal.region-instance.namespace-metadata.literal.int.312, ptr %arg1), !dbg !1190
  %v151 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v147, i1 %v148, i1 %v149, i1 %v150), !dbg !1191
    #dbg_value(i1 %v151, !1192, !DIExpression(), !1193)
  %v152 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.313, ptr @topal.region-instance.namespace-metadata.literal.int.314, ptr %arg1), !dbg !1194
  %v153 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.315, ptr @topal.region-instance.namespace-metadata.literal.int.316, ptr %arg1), !dbg !1195
  %v154 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.317, ptr @topal.region-instance.namespace-metadata.literal.int.318, ptr %arg1), !dbg !1196
  %v155 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.319, ptr @topal.region-instance.namespace-metadata.literal.int.320, ptr %arg1), !dbg !1197
  %v156 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v152, i1 %v153, i1 %v154, i1 %v155), !dbg !1198
    #dbg_value(i1 %v156, !1199, !DIExpression(), !1200)
  %v157 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.321, ptr @topal.region-instance.namespace-metadata.literal.int.322, ptr %arg1), !dbg !1201
  %v158 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.323, ptr @topal.region-instance.namespace-metadata.literal.int.324, ptr %arg1), !dbg !1202
  %v159 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.325, ptr @topal.region-instance.namespace-metadata.literal.int.326, ptr %arg1), !dbg !1203
  %v160 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.327, ptr @topal.region-instance.namespace-metadata.literal.int.328, ptr %arg1), !dbg !1204
  %v161 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v157, i1 %v158, i1 %v159, i1 %v160), !dbg !1205
    #dbg_value(i1 %v161, !1206, !DIExpression(), !1207)
  %v162 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.329, ptr @topal.region-instance.namespace-metadata.literal.int.330, ptr %arg1), !dbg !1208
  %v163 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.331, ptr @topal.region-instance.namespace-metadata.literal.int.332, ptr %arg1), !dbg !1209
  %v164 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.333, ptr @topal.region-instance.namespace-metadata.literal.int.334, ptr %arg1), !dbg !1210
  %v165 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.335, ptr @topal.region-instance.namespace-metadata.literal.int.336, ptr %arg1), !dbg !1211
  %v166 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v162, i1 %v163, i1 %v164, i1 %v165), !dbg !1212
    #dbg_value(i1 %v166, !1213, !DIExpression(), !1214)
  %v167 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.337, ptr @topal.region-instance.namespace-metadata.literal.int.338, ptr %arg1), !dbg !1215
  %v168 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.339, ptr @topal.region-instance.namespace-metadata.literal.int.340, ptr %arg1), !dbg !1216
  %v169 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.341, ptr @topal.region-instance.namespace-metadata.literal.int.342, ptr %arg1), !dbg !1217
  %v170 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.343, ptr @topal.region-instance.namespace-metadata.literal.int.344, ptr %arg1), !dbg !1218
  %v171 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v167, i1 %v168, i1 %v169, i1 %v170), !dbg !1219
    #dbg_value(i1 %v171, !1220, !DIExpression(), !1221)
  %v172 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.345, ptr @topal.region-instance.namespace-metadata.literal.int.346, ptr %arg1), !dbg !1222
  %v173 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.347, ptr @topal.region-instance.namespace-metadata.literal.int.348, ptr %arg1), !dbg !1223
  %v174 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.349, ptr @topal.region-instance.namespace-metadata.literal.int.350, ptr %arg1), !dbg !1224
  %v175 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.351, ptr @topal.region-instance.namespace-metadata.literal.int.352, ptr %arg1), !dbg !1225
  %v176 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v172, i1 %v173, i1 %v174, i1 %v175), !dbg !1226
    #dbg_value(i1 %v176, !1227, !DIExpression(), !1228)
  %v177 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.353, ptr @topal.region-instance.namespace-metadata.literal.int.354, ptr %arg1), !dbg !1229
  %v178 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.355, ptr @topal.region-instance.namespace-metadata.literal.int.356, ptr %arg1), !dbg !1230
  %v179 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.357, ptr @topal.region-instance.namespace-metadata.literal.int.358, ptr %arg1), !dbg !1231
  %v180 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.359, ptr @topal.region-instance.namespace-metadata.literal.int.360, ptr %arg1), !dbg !1232
  %v181 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v177, i1 %v178, i1 %v179, i1 %v180), !dbg !1233
    #dbg_value(i1 %v181, !1234, !DIExpression(), !1235)
  %v182 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.361, ptr @topal.region-instance.namespace-metadata.literal.int.362, ptr %arg1), !dbg !1236
  %v183 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.363, ptr @topal.region-instance.namespace-metadata.literal.int.364, ptr %arg1), !dbg !1237
  %v184 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.365, ptr @topal.region-instance.namespace-metadata.literal.int.366, ptr %arg1), !dbg !1238
  %v185 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.367, ptr @topal.region-instance.namespace-metadata.literal.int.368, ptr %arg1), !dbg !1239
  %v186 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v182, i1 %v183, i1 %v184, i1 %v185), !dbg !1240
    #dbg_value(i1 %v186, !1241, !DIExpression(), !1242)
  %v187 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.369, ptr @topal.region-instance.namespace-metadata.literal.int.370, ptr %arg1), !dbg !1243
  %v188 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.371, ptr @topal.region-instance.namespace-metadata.literal.int.372, ptr %arg1), !dbg !1244
  %v189 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.373, ptr @topal.region-instance.namespace-metadata.literal.int.374, ptr %arg1), !dbg !1245
  %v190 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.375, ptr @topal.region-instance.namespace-metadata.literal.int.376, ptr %arg1), !dbg !1246
  %v191 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v187, i1 %v188, i1 %v189, i1 %v190), !dbg !1247
    #dbg_value(i1 %v191, !1248, !DIExpression(), !1249)
  %v192 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.377, ptr @topal.region-instance.namespace-metadata.literal.int.378, ptr %arg1), !dbg !1250
  %v193 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.379, ptr @topal.region-instance.namespace-metadata.literal.int.380, ptr %arg1), !dbg !1251
  %v194 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.381, ptr @topal.region-instance.namespace-metadata.literal.int.382, ptr %arg1), !dbg !1252
  %v195 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.383, ptr @topal.region-instance.namespace-metadata.literal.int.384, ptr %arg1), !dbg !1253
  %v196 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v192, i1 %v193, i1 %v194, i1 %v195), !dbg !1254
    #dbg_value(i1 %v196, !1255, !DIExpression(), !1256)
  %v197 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.385, ptr @topal.region-instance.namespace-metadata.literal.int.386, ptr %arg1), !dbg !1257
  %v198 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.387, ptr @topal.region-instance.namespace-metadata.literal.int.388, ptr %arg1), !dbg !1258
  %v199 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.389, ptr @topal.region-instance.namespace-metadata.literal.int.390, ptr %arg1), !dbg !1259
  %v200 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.391, ptr @topal.region-instance.namespace-metadata.literal.int.392, ptr %arg1), !dbg !1260
  %v201 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v197, i1 %v198, i1 %v199, i1 %v200), !dbg !1261
    #dbg_value(i1 %v201, !1262, !DIExpression(), !1263)
  %v202 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.393, ptr @topal.region-instance.namespace-metadata.literal.int.394, ptr %arg1), !dbg !1264
  %v203 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.395, ptr @topal.region-instance.namespace-metadata.literal.int.396, ptr %arg1), !dbg !1265
  %v204 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.397, ptr @topal.region-instance.namespace-metadata.literal.int.398, ptr %arg1), !dbg !1266
  %v205 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.399, ptr @topal.region-instance.namespace-metadata.literal.int.400, ptr %arg1), !dbg !1267
  %v206 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v202, i1 %v203, i1 %v204, i1 %v205), !dbg !1268
    #dbg_value(i1 %v206, !1269, !DIExpression(), !1270)
  %v207 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.401, ptr @topal.region-instance.namespace-metadata.literal.int.402, ptr %arg1), !dbg !1271
  %v208 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.403, ptr @topal.region-instance.namespace-metadata.literal.int.404, ptr %arg1), !dbg !1272
  %v209 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.405, ptr @topal.region-instance.namespace-metadata.literal.int.406, ptr %arg1), !dbg !1273
  %v210 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.407, ptr @topal.region-instance.namespace-metadata.literal.int.408, ptr %arg1), !dbg !1274
  %v211 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v207, i1 %v208, i1 %v209, i1 %v210), !dbg !1275
    #dbg_value(i1 %v211, !1276, !DIExpression(), !1277)
  %v212 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.409, ptr @topal.region-instance.namespace-metadata.literal.int.410, ptr %arg1), !dbg !1278
  %v213 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.411, ptr @topal.region-instance.namespace-metadata.literal.int.412, ptr %arg1), !dbg !1279
  %v214 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.413, ptr @topal.region-instance.namespace-metadata.literal.int.414, ptr %arg1), !dbg !1280
  %v215 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.415, ptr @topal.region-instance.namespace-metadata.literal.int.416, ptr %arg1), !dbg !1281
  %v216 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v212, i1 %v213, i1 %v214, i1 %v215), !dbg !1282
    #dbg_value(i1 %v216, !1283, !DIExpression(), !1284)
  %v217 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.417, ptr @topal.region-instance.namespace-metadata.literal.int.418, ptr %arg1), !dbg !1285
  %v218 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.419, ptr @topal.region-instance.namespace-metadata.literal.int.420, ptr %arg1), !dbg !1286
  %v219 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.421, ptr @topal.region-instance.namespace-metadata.literal.int.422, ptr %arg1), !dbg !1287
  %v220 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.423, ptr @topal.region-instance.namespace-metadata.literal.int.424, ptr %arg1), !dbg !1288
  %v221 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v217, i1 %v218, i1 %v219, i1 %v220), !dbg !1289
    #dbg_value(i1 %v221, !1290, !DIExpression(), !1291)
  %v222 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.425, ptr @topal.region-instance.namespace-metadata.literal.int.426, ptr %arg1), !dbg !1292
  %v223 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.427, ptr @topal.region-instance.namespace-metadata.literal.int.428, ptr %arg1), !dbg !1293
  %v224 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.429, ptr @topal.region-instance.namespace-metadata.literal.int.430, ptr %arg1), !dbg !1294
  %v225 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.431, ptr @topal.region-instance.namespace-metadata.literal.int.432, ptr %arg1), !dbg !1295
  %v226 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v222, i1 %v223, i1 %v224, i1 %v225), !dbg !1296
    #dbg_value(i1 %v226, !1297, !DIExpression(), !1298)
  %v227 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.433, ptr @topal.region-instance.namespace-metadata.literal.int.434, ptr %arg1), !dbg !1299
  %v228 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.435, ptr @topal.region-instance.namespace-metadata.literal.int.436, ptr %arg1), !dbg !1300
  %v229 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.437, ptr @topal.region-instance.namespace-metadata.literal.int.438, ptr %arg1), !dbg !1301
  %v230 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.439, ptr @topal.region-instance.namespace-metadata.literal.int.440, ptr %arg1), !dbg !1302
  %v231 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v227, i1 %v228, i1 %v229, i1 %v230), !dbg !1303
    #dbg_value(i1 %v231, !1304, !DIExpression(), !1305)
  %v232 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.441, ptr @topal.region-instance.namespace-metadata.literal.int.442, ptr %arg1), !dbg !1306
  %v233 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.443, ptr @topal.region-instance.namespace-metadata.literal.int.444, ptr %arg1), !dbg !1307
  %v234 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.445, ptr @topal.region-instance.namespace-metadata.literal.int.446, ptr %arg1), !dbg !1308
  %v235 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.447, ptr @topal.region-instance.namespace-metadata.literal.int.448, ptr %arg1), !dbg !1309
  %v236 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v232, i1 %v233, i1 %v234, i1 %v235), !dbg !1310
    #dbg_value(i1 %v236, !1311, !DIExpression(), !1312)
  %v237 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.449, ptr @topal.region-instance.namespace-metadata.literal.int.450, ptr %arg1), !dbg !1313
  %v238 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.451, ptr @topal.region-instance.namespace-metadata.literal.int.452, ptr %arg1), !dbg !1314
  %v239 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.453, ptr @topal.region-instance.namespace-metadata.literal.int.454, ptr %arg1), !dbg !1315
  %v240 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.455, ptr @topal.region-instance.namespace-metadata.literal.int.456, ptr %arg1), !dbg !1316
  %v241 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v237, i1 %v238, i1 %v239, i1 %v240), !dbg !1317
    #dbg_value(i1 %v241, !1318, !DIExpression(), !1319)
  %v242 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.457, ptr @topal.region-instance.namespace-metadata.literal.int.458, ptr %arg1), !dbg !1320
  %v243 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.459, ptr @topal.region-instance.namespace-metadata.literal.int.460, ptr %arg1), !dbg !1321
  %v244 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.461, ptr @topal.region-instance.namespace-metadata.literal.int.462, ptr %arg1), !dbg !1322
  %v245 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.463, ptr @topal.region-instance.namespace-metadata.literal.int.464, ptr %arg1), !dbg !1323
  %v246 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v242, i1 %v243, i1 %v244, i1 %v245), !dbg !1324
    #dbg_value(i1 %v246, !1325, !DIExpression(), !1326)
  %v247 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.465, ptr @topal.region-instance.namespace-metadata.literal.int.466, ptr %arg1), !dbg !1327
  %v248 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.467, ptr @topal.region-instance.namespace-metadata.literal.int.468, ptr %arg1), !dbg !1328
  %v249 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.469, ptr @topal.region-instance.namespace-metadata.literal.int.470, ptr %arg1), !dbg !1329
  %v250 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.471, ptr @topal.region-instance.namespace-metadata.literal.int.472, ptr %arg1), !dbg !1330
  %v251 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v247, i1 %v248, i1 %v249, i1 %v250), !dbg !1331
    #dbg_value(i1 %v251, !1332, !DIExpression(), !1333)
  %v252 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.473, ptr @topal.region-instance.namespace-metadata.literal.int.474, ptr %arg1), !dbg !1334
  %v253 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.475, ptr @topal.region-instance.namespace-metadata.literal.int.476, ptr %arg1), !dbg !1335
  %v254 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.477, ptr @topal.region-instance.namespace-metadata.literal.int.478, ptr %arg1), !dbg !1336
  %v255 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.479, ptr @topal.region-instance.namespace-metadata.literal.int.480, ptr %arg1), !dbg !1337
  %v256 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v252, i1 %v253, i1 %v254, i1 %v255), !dbg !1338
    #dbg_value(i1 %v256, !1339, !DIExpression(), !1340)
  %v257 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.481, ptr @topal.region-instance.namespace-metadata.literal.int.482, ptr %arg1), !dbg !1341
  %v258 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.483, ptr @topal.region-instance.namespace-metadata.literal.int.484, ptr %arg1), !dbg !1342
  %v259 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.485, ptr @topal.region-instance.namespace-metadata.literal.int.486, ptr %arg1), !dbg !1343
  %v260 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.487, ptr @topal.region-instance.namespace-metadata.literal.int.488, ptr %arg1), !dbg !1344
  %v261 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v257, i1 %v258, i1 %v259, i1 %v260), !dbg !1345
    #dbg_value(i1 %v261, !1346, !DIExpression(), !1347)
  %v262 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.489, ptr @topal.region-instance.namespace-metadata.literal.int.490, ptr %arg1), !dbg !1348
  %v263 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.491, ptr @topal.region-instance.namespace-metadata.literal.int.492, ptr %arg1), !dbg !1349
  %v264 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.493, ptr @topal.region-instance.namespace-metadata.literal.int.494, ptr %arg1), !dbg !1350
  %v265 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.495, ptr @topal.region-instance.namespace-metadata.literal.int.496, ptr %arg1), !dbg !1351
  %v266 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v262, i1 %v263, i1 %v264, i1 %v265), !dbg !1352
    #dbg_value(i1 %v266, !1353, !DIExpression(), !1354)
  %v267 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.497, ptr @topal.region-instance.namespace-metadata.literal.int.498, ptr %arg1), !dbg !1355
  %v268 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.499, ptr @topal.region-instance.namespace-metadata.literal.int.500, ptr %arg1), !dbg !1356
  %v269 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.501, ptr @topal.region-instance.namespace-metadata.literal.int.502, ptr %arg1), !dbg !1357
  %v270 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.503, ptr @topal.region-instance.namespace-metadata.literal.int.504, ptr %arg1), !dbg !1358
  %v271 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v267, i1 %v268, i1 %v269, i1 %v270), !dbg !1359
    #dbg_value(i1 %v271, !1360, !DIExpression(), !1361)
  %v272 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.505, ptr @topal.region-instance.namespace-metadata.literal.int.506, ptr %arg1), !dbg !1362
  %v273 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.507, ptr @topal.region-instance.namespace-metadata.literal.int.508, ptr %arg1), !dbg !1363
  %v274 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.509, ptr @topal.region-instance.namespace-metadata.literal.int.510, ptr %arg1), !dbg !1364
  %v275 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.511, ptr @topal.region-instance.namespace-metadata.literal.int.512, ptr %arg1), !dbg !1365
  %v276 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v272, i1 %v273, i1 %v274, i1 %v275), !dbg !1366
    #dbg_value(i1 %v276, !1367, !DIExpression(), !1368)
  %v277 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.513, ptr @topal.region-instance.namespace-metadata.literal.int.514, ptr %arg1), !dbg !1369
  %v278 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.515, ptr @topal.region-instance.namespace-metadata.literal.int.516, ptr %arg1), !dbg !1370
  %v279 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.517, ptr @topal.region-instance.namespace-metadata.literal.int.518, ptr %arg1), !dbg !1371
  %v280 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.519, ptr @topal.region-instance.namespace-metadata.literal.int.520, ptr %arg1), !dbg !1372
  %v281 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v277, i1 %v278, i1 %v279, i1 %v280), !dbg !1373
    #dbg_value(i1 %v281, !1374, !DIExpression(), !1375)
  %v282 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.521, ptr @topal.region-instance.namespace-metadata.literal.int.522, ptr %arg1), !dbg !1376
  %v283 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.523, ptr @topal.region-instance.namespace-metadata.literal.int.524, ptr %arg1), !dbg !1377
  %v284 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.525, ptr @topal.region-instance.namespace-metadata.literal.int.526, ptr %arg1), !dbg !1378
  %v285 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.527, ptr @topal.region-instance.namespace-metadata.literal.int.528, ptr %arg1), !dbg !1379
  %v286 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v282, i1 %v283, i1 %v284, i1 %v285), !dbg !1380
    #dbg_value(i1 %v286, !1381, !DIExpression(), !1382)
  %v287 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.529, ptr @topal.region-instance.namespace-metadata.literal.int.530, ptr %arg1), !dbg !1383
  %v288 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.531, ptr @topal.region-instance.namespace-metadata.literal.int.532, ptr %arg1), !dbg !1384
  %v289 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.533, ptr @topal.region-instance.namespace-metadata.literal.int.534, ptr %arg1), !dbg !1385
  %v290 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.535, ptr @topal.region-instance.namespace-metadata.literal.int.536, ptr %arg1), !dbg !1386
  %v291 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v287, i1 %v288, i1 %v289, i1 %v290), !dbg !1387
    #dbg_value(i1 %v291, !1388, !DIExpression(), !1389)
  %v292 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.537, ptr @topal.region-instance.namespace-metadata.literal.int.538, ptr %arg1), !dbg !1390
  %v293 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.539, ptr @topal.region-instance.namespace-metadata.literal.int.540, ptr %arg1), !dbg !1391
  %v294 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.541, ptr @topal.region-instance.namespace-metadata.literal.int.542, ptr %arg1), !dbg !1392
  %v295 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.543, ptr @topal.region-instance.namespace-metadata.literal.int.544, ptr %arg1), !dbg !1393
  %v296 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v292, i1 %v293, i1 %v294, i1 %v295), !dbg !1394
    #dbg_value(i1 %v296, !1395, !DIExpression(), !1396)
  %v297 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.545, ptr @topal.region-instance.namespace-metadata.literal.int.546, ptr %arg1), !dbg !1397
  %v298 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.547, ptr @topal.region-instance.namespace-metadata.literal.int.548, ptr %arg1), !dbg !1398
  %v299 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.549, ptr @topal.region-instance.namespace-metadata.literal.int.550, ptr %arg1), !dbg !1399
  %v300 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.551, ptr @topal.region-instance.namespace-metadata.literal.int.552, ptr %arg1), !dbg !1400
  %v301 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v297, i1 %v298, i1 %v299, i1 %v300), !dbg !1401
    #dbg_value(i1 %v301, !1402, !DIExpression(), !1403)
  %v302 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.553, ptr @topal.region-instance.namespace-metadata.literal.int.554, ptr %arg1), !dbg !1404
  %v303 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.555, ptr @topal.region-instance.namespace-metadata.literal.int.556, ptr %arg1), !dbg !1405
  %v304 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.557, ptr @topal.region-instance.namespace-metadata.literal.int.558, ptr %arg1), !dbg !1406
  %v305 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.559, ptr @topal.region-instance.namespace-metadata.literal.int.560, ptr %arg1), !dbg !1407
  %v306 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v302, i1 %v303, i1 %v304, i1 %v305), !dbg !1408
    #dbg_value(i1 %v306, !1409, !DIExpression(), !1410)
  %v307 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.561, ptr @topal.region-instance.namespace-metadata.literal.int.562, ptr %arg1), !dbg !1411
  %v308 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.563, ptr @topal.region-instance.namespace-metadata.literal.int.564, ptr %arg1), !dbg !1412
  %v309 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.565, ptr @topal.region-instance.namespace-metadata.literal.int.566, ptr %arg1), !dbg !1413
  %v310 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.567, ptr @topal.region-instance.namespace-metadata.literal.int.568, ptr %arg1), !dbg !1414
  %v311 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v307, i1 %v308, i1 %v309, i1 %v310), !dbg !1415
    #dbg_value(i1 %v311, !1416, !DIExpression(), !1417)
  %v312 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.569, ptr @topal.region-instance.namespace-metadata.literal.int.570, ptr %arg1), !dbg !1418
  %v313 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.571, ptr @topal.region-instance.namespace-metadata.literal.int.572, ptr %arg1), !dbg !1419
  %v314 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.573, ptr @topal.region-instance.namespace-metadata.literal.int.574, ptr %arg1), !dbg !1420
  %v315 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.575, ptr @topal.region-instance.namespace-metadata.literal.int.576, ptr %arg1), !dbg !1421
  %v316 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v312, i1 %v313, i1 %v314, i1 %v315), !dbg !1422
    #dbg_value(i1 %v316, !1423, !DIExpression(), !1424)
  %v317 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.577, ptr @topal.region-instance.namespace-metadata.literal.int.578, ptr %arg1), !dbg !1425
  %v318 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.579, ptr @topal.region-instance.namespace-metadata.literal.int.580, ptr %arg1), !dbg !1426
  %v319 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.581, ptr @topal.region-instance.namespace-metadata.literal.int.582, ptr %arg1), !dbg !1427
  %v320 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.583, ptr @topal.region-instance.namespace-metadata.literal.int.584, ptr %arg1), !dbg !1428
  %v321 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v317, i1 %v318, i1 %v319, i1 %v320), !dbg !1429
    #dbg_value(i1 %v321, !1430, !DIExpression(), !1431)
  %v322 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v6, i1 %v11, i1 %v16, i1 %v21), !dbg !1432
    #dbg_value(i1 %v322, !1433, !DIExpression(), !1434)
  %v323 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v26, i1 %v31, i1 %v36, i1 %v41), !dbg !1435
    #dbg_value(i1 %v323, !1436, !DIExpression(), !1437)
  %v324 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v46, i1 %v51, i1 %v56, i1 %v61), !dbg !1438
    #dbg_value(i1 %v324, !1439, !DIExpression(), !1440)
  %v325 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v66, i1 %v71, i1 %v76, i1 %v81), !dbg !1441
    #dbg_value(i1 %v325, !1442, !DIExpression(), !1443)
  %v326 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v86, i1 %v91, i1 %v96, i1 %v101), !dbg !1444
    #dbg_value(i1 %v326, !1445, !DIExpression(), !1446)
  %v327 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v106, i1 %v111, i1 %v116, i1 %v121), !dbg !1447
    #dbg_value(i1 %v327, !1448, !DIExpression(), !1449)
  %v328 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v126, i1 %v131, i1 %v136, i1 %v141), !dbg !1450
    #dbg_value(i1 %v328, !1451, !DIExpression(), !1452)
  %v329 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v146, i1 %v151, i1 %v156, i1 %v161), !dbg !1453
    #dbg_value(i1 %v329, !1454, !DIExpression(), !1455)
  %v330 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v166, i1 %v171, i1 %v176, i1 %v181), !dbg !1456
    #dbg_value(i1 %v330, !1457, !DIExpression(), !1458)
  %v331 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v186, i1 %v191, i1 %v196, i1 %v201), !dbg !1459
    #dbg_value(i1 %v331, !1460, !DIExpression(), !1461)
  %v332 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v206, i1 %v211, i1 %v216, i1 %v221), !dbg !1462
    #dbg_value(i1 %v332, !1463, !DIExpression(), !1464)
  %v333 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v226, i1 %v231, i1 %v236, i1 %v241), !dbg !1465
    #dbg_value(i1 %v333, !1466, !DIExpression(), !1467)
  %v334 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v246, i1 %v251, i1 %v256, i1 %v261), !dbg !1468
    #dbg_value(i1 %v334, !1469, !DIExpression(), !1470)
  %v335 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v266, i1 %v271, i1 %v276, i1 %v281), !dbg !1471
    #dbg_value(i1 %v335, !1472, !DIExpression(), !1473)
  %v336 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v286, i1 %v291, i1 %v296, i1 %v301), !dbg !1474
    #dbg_value(i1 %v336, !1475, !DIExpression(), !1476)
  %v337 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v306, i1 %v311, i1 %v316, i1 %v321), !dbg !1477
    #dbg_value(i1 %v337, !1478, !DIExpression(), !1479)
  %v338 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v322, i1 %v323, i1 %v324, i1 %v325), !dbg !1480
    #dbg_value(i1 %v338, !1481, !DIExpression(), !1482)
  %v339 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v326, i1 %v327, i1 %v328, i1 %v329), !dbg !1483
    #dbg_value(i1 %v339, !1484, !DIExpression(), !1485)
  %v340 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v330, i1 %v331, i1 %v332, i1 %v333), !dbg !1486
    #dbg_value(i1 %v340, !1487, !DIExpression(), !1488)
  %v341 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v334, i1 %v335, i1 %v336, i1 %v337), !dbg !1489
    #dbg_value(i1 %v341, !1490, !DIExpression(), !1491)
  %v342 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359(i1 %v338, i1 %v339, i1 %v340, i1 %v341), !dbg !1492
  ret i1 %v342, !dbg !1493
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dnormal.1957(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1496 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1497, !DIExpression(), !1498)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1499, !DIExpression(), !1500)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2enot_2ddot.335(ptr %arg0, ptr %arg1), !dbg !1501
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1502
decision.true.0:
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dpayload.1956(ptr %arg0, ptr %arg1), !dbg !1503
  br label %decision.merge.2, !dbg !1504
decision.false.1:
  br label %decision.merge.2, !dbg !1505
decision.merge.2:
  %v4 = phi i1 [%v3, %decision.true.0], [false, %decision.false.1], !dbg !1506
  ret i1 %v4, !dbg !1507
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbounded.1958(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1510 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1511, !DIExpression(), !1512)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1513, !DIExpression(), !1514)
  %v2 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.585), !dbg !1515
  %v3 = icmp sle i32 %v2, 0, !dbg !1516
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1517
decision.true.0:
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dnormal.1957(ptr %arg0, ptr %arg1), !dbg !1518
  br label %decision.merge.2, !dbg !1519
decision.false.1:
  br label %decision.merge.2, !dbg !1520
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !1521
  ret i1 %v5, !dbg !1522
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dinput.1959(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1525 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1526, !DIExpression(), !1527)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1528, !DIExpression(), !1529)
  %v2 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.586), !dbg !1530
  %v3 = icmp sgt i32 %v2, 0, !dbg !1531
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1532
decision.true.0:
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbounded.1958(ptr %arg0, ptr %arg1), !dbg !1533
  br label %decision.merge.2, !dbg !1534
decision.false.1:
  br label %decision.merge.2, !dbg !1535
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !1536
  ret i1 %v5, !dbg !1537
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2einput_2dclean.1962(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1540 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1541, !DIExpression(), !1542)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1543, !DIExpression(), !1544)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.587), !dbg !1545
    #dbg_value(i1 %v2, !1546, !DIExpression(), !1547)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.588), !dbg !1548
    #dbg_value(i1 %v3, !1549, !DIExpression(), !1550)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dinput.1959(ptr %arg0, ptr %arg1), !dbg !1551
    #dbg_value(i1 %v4, !1552, !DIExpression(), !1553)
  %v5 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v2, i1 %v3), !dbg !1554
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v4, i1 %v5), !dbg !1555
  ret i1 %v6, !dbg !1556
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1559 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1560, !DIExpression(), !1561)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1562, !DIExpression(), !1563)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1564, !DIExpression(), !1565)
  %v3 = call ptr @topal.region-instance.namespace-metadata.primitive.unsigned.load(ptr %arg0, ptr %arg2, i64 8, i1 false), !dbg !1566
  %v4 = call i1 @topal.region-instance.namespace-metadata.runtime.optional.is.some(ptr %v3), !dbg !1567
  br i1 %v4, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !1568
optional.decision.some.0:
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.optional.payload(ptr %v3), !dbg !1569
    #dbg_value(ptr %v5, !1570, !DIExpression(), !1571)
  %v6 = call i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %arg0, ptr %arg1, ptr %v5, i64 8, i1 false), !dbg !1572
  br label %optional.decision.merge.2, !dbg !1573
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !1574
optional.decision.merge.2:
  %v7 = phi i1 [%v6, %optional.decision.some.0], [false, %optional.decision.none.1], !dbg !1575
  ret i1 %v7, !dbg !1576
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1579 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1580, !DIExpression(), !1581)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1582, !DIExpression(), !1583)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1584, !DIExpression(), !1585)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1586
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1587
decision.true.0:
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.589), !dbg !1588
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.590), !dbg !1589
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970(ptr %arg0, ptr %v4, ptr %v5), !dbg !1590
  br label %decision.merge.2, !dbg !1591
decision.false.1:
  br label %decision.merge.2, !dbg !1592
decision.merge.2:
  %v7 = phi i1 [%v6, %decision.true.0], [false, %decision.false.1], !dbg !1593
  ret i1 %v7, !dbg !1594
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1597 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1598, !DIExpression(), !1599)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1600, !DIExpression(), !1601)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1602, !DIExpression(), !1603)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1604
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1605
decision.true.0:
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.591), !dbg !1606
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.592), !dbg !1607
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972(ptr %arg0, ptr %v4, ptr %v5), !dbg !1608
  br label %decision.merge.2, !dbg !1609
decision.false.1:
  br label %decision.merge.2, !dbg !1610
decision.merge.2:
  %v7 = phi i1 [%v6, %decision.true.0], [false, %decision.false.1], !dbg !1611
  ret i1 %v7, !dbg !1612
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1615 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1616, !DIExpression(), !1617)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1618, !DIExpression(), !1619)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1620, !DIExpression(), !1621)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1622
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1623
decision.true.0:
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.593), !dbg !1624
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.594), !dbg !1625
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976(ptr %arg0, ptr %v4, ptr %v5), !dbg !1626
  br label %decision.merge.2, !dbg !1627
decision.false.1:
  br label %decision.merge.2, !dbg !1628
decision.merge.2:
  %v7 = phi i1 [%v6, %decision.true.0], [false, %decision.false.1], !dbg !1629
  ret i1 %v7, !dbg !1630
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1633 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1634, !DIExpression(), !1635)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1636, !DIExpression(), !1637)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1638, !DIExpression(), !1639)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1640
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1641
decision.true.0:
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.595), !dbg !1642
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.596), !dbg !1643
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984(ptr %arg0, ptr %v4, ptr %v5), !dbg !1644
  br label %decision.merge.2, !dbg !1645
decision.false.1:
  br label %decision.merge.2, !dbg !1646
decision.merge.2:
  %v7 = phi i1 [%v6, %decision.true.0], [false, %decision.false.1], !dbg !1647
  ret i1 %v7, !dbg !1648
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1651 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1652, !DIExpression(), !1653)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1654, !DIExpression(), !1655)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1656, !DIExpression(), !1657)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !1658
  br i1 %v3, label %decision.true.0, label %decision.false.1, !dbg !1659
decision.true.0:
  %v4 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.597), !dbg !1660
  %v5 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.598), !dbg !1661
  %v6 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000(ptr %arg0, ptr %v4, ptr %v5), !dbg !1662
  br label %decision.merge.2, !dbg !1663
decision.false.1:
  br label %decision.merge.2, !dbg !1664
decision.merge.2:
  %v7 = phi i1 [%v6, %decision.true.0], [false, %decision.false.1], !dbg !1665
  ret i1 %v7, !dbg !1666
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1669 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1670, !DIExpression(), !1671)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1672, !DIExpression(), !1673)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !1674, !DIExpression(), !1675)
  %v3 = call i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %arg0, ptr %arg1, ptr %arg2, i64 8, i1 false), !dbg !1676
  ret i1 %v3, !dbg !1677
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1680 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1681, !DIExpression(), !1682)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1683, !DIExpression(), !1684)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.599, ptr %arg1), !dbg !1685
    #dbg_value(i1 %v2, !1686, !DIExpression(), !1687)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.600, ptr %arg1), !dbg !1688
    #dbg_value(i1 %v3, !1689, !DIExpression(), !1690)
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v2, i1 %v3), !dbg !1691
  ret i1 %v4, !dbg !1692
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elink_2deffect.2048(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1695 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1696, !DIExpression(), !1697)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1698
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1699
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1700
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1701
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1702
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1703
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1704
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1705
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1706
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1707
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1708
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1709
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1710
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1711
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1712
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1713
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1714, !DIExpression(), !1715)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1716, !DIExpression(), !1717)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !1718
    #dbg_value(ptr %v19, !1719, !DIExpression(), !1720)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !1721
    #dbg_value(ptr %v20, !1722, !DIExpression(), !1723)
  %v21 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v6), !dbg !1724
  %v22 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032(ptr %arg0, ptr %v21, ptr @topal.region-instance.namespace-metadata.literal.int.601), !dbg !1725
    #dbg_value(i1 %v22, !1726, !DIExpression(), !1727)
  %v23 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v20, ptr %v3), !dbg !1728
    #dbg_value(i1 %v23, !1729, !DIExpression(), !1730)
  %v24 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.602), !dbg !1731
  %v25 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v24, ptr %v1), !dbg !1732
    #dbg_value(i1 %v25, !1733, !DIExpression(), !1734)
  %v26 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.603), !dbg !1735
  %v27 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v4, ptr @topal.region-instance.namespace-metadata.literal.int.604), !dbg !1736
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v26, ptr %v27), !dbg !1737
    #dbg_value(i1 %v28, !1738, !DIExpression(), !1739)
  %v29 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.605), !dbg !1740
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v29, ptr @topal.region-instance.namespace-metadata.literal.int.606), !dbg !1741
    #dbg_value(i1 %v30, !1742, !DIExpression(), !1743)
  %v31 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.607), !dbg !1744
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v31, ptr %arg2), !dbg !1745
    #dbg_value(i1 %v32, !1746, !DIExpression(), !1747)
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v30, i1 %v32), !dbg !1748
  %v34 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v28, i1 %v33), !dbg !1749
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v25, i1 %v34), !dbg !1750
  %v36 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v23, i1 %v35), !dbg !1751
  %v37 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v36), !dbg !1752
    #dbg_value(i1 %v37, !1753, !DIExpression(), !1754)
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !1755
    #dbg_value(i1 %v38, !1756, !DIExpression(), !1757)
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v37, i1 %v38), !dbg !1758
  ret i1 %v39, !dbg !1759
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2emove_2deffect.2124(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1762 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1763, !DIExpression(), !1764)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1765
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1766
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1767
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1768
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1769
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1770
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1771
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1772
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1773
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1774
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1775
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1776
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1777
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1778
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1779
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1780
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1781, !DIExpression(), !1782)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1783, !DIExpression(), !1784)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v2), !dbg !1785
    #dbg_value(ptr %v19, !1786, !DIExpression(), !1787)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v2), !dbg !1788
  %v21 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032(ptr %arg0, ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.608), !dbg !1789
    #dbg_value(i1 %v21, !1790, !DIExpression(), !1791)
  %v22 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.609), !dbg !1792
  %v23 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v22, ptr %v1), !dbg !1793
    #dbg_value(i1 %v23, !1794, !DIExpression(), !1795)
  %v24 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !1796
  %v25 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v24, ptr @topal.region-instance.namespace-metadata.literal.int.610), !dbg !1797
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v25, ptr %arg2), !dbg !1798
    #dbg_value(i1 %v26, !1799, !DIExpression(), !1800)
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v23, i1 %v26), !dbg !1801
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v21, i1 %v27), !dbg !1802
    #dbg_value(i1 %v28, !1803, !DIExpression(), !1804)
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !1805
    #dbg_value(i1 %v29, !1806, !DIExpression(), !1807)
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v28, i1 %v29), !dbg !1808
  ret i1 %v30, !dbg !1809
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1812 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1813, !DIExpression(), !1814)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1815, !DIExpression(), !1816)
  %v2 = call i1 @topal.region-instance.namespace-metadata.primitive.unsigned.store(ptr %arg0, ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.611, i64 8, i1 false), !dbg !1817
  ret i1 %v2, !dbg !1818
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1821 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1822, !DIExpression(), !1823)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1824, !DIExpression(), !1825)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134(ptr %arg0, ptr %arg1), !dbg !1826
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1827
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.612), !dbg !1828
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134(ptr %arg0, ptr %v3), !dbg !1829
  br label %decision.merge.2, !dbg !1830
decision.false.1:
  br label %decision.merge.2, !dbg !1831
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !1832
  ret i1 %v5, !dbg !1833
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1836 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1837, !DIExpression(), !1838)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1839, !DIExpression(), !1840)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136(ptr %arg0, ptr %arg1), !dbg !1841
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1842
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.613), !dbg !1843
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136(ptr %arg0, ptr %v3), !dbg !1844
  br label %decision.merge.2, !dbg !1845
decision.false.1:
  br label %decision.merge.2, !dbg !1846
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !1847
  ret i1 %v5, !dbg !1848
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1851 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1852, !DIExpression(), !1853)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1854, !DIExpression(), !1855)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140(ptr %arg0, ptr %arg1), !dbg !1856
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1857
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.614), !dbg !1858
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140(ptr %arg0, ptr %v3), !dbg !1859
  br label %decision.merge.2, !dbg !1860
decision.false.1:
  br label %decision.merge.2, !dbg !1861
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !1862
  ret i1 %v5, !dbg !1863
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1866 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1867, !DIExpression(), !1868)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1869, !DIExpression(), !1870)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148(ptr %arg0, ptr %arg1), !dbg !1871
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1872
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.615), !dbg !1873
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148(ptr %arg0, ptr %v3), !dbg !1874
  br label %decision.merge.2, !dbg !1875
decision.false.1:
  br label %decision.merge.2, !dbg !1876
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !1877
  ret i1 %v5, !dbg !1878
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dname.2196(ptr %arg0, ptr %arg1) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1881 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1882, !DIExpression(), !1883)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !1884, !DIExpression(), !1885)
  %v2 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164(ptr %arg0, ptr %arg1), !dbg !1886
  br i1 %v2, label %decision.true.0, label %decision.false.1, !dbg !1887
decision.true.0:
  %v3 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.616), !dbg !1888
  %v4 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164(ptr %arg0, ptr %v3), !dbg !1889
  br label %decision.merge.2, !dbg !1890
decision.false.1:
  br label %decision.merge.2, !dbg !1891
decision.merge.2:
  %v5 = phi i1 [%v4, %decision.true.0], [false, %decision.false.1], !dbg !1892
  ret i1 %v5, !dbg !1893
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ereplace_2deffect.2212(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1896 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1897, !DIExpression(), !1898)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1899
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1900
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1901
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1902
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1903
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1904
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1905
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1906
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1907
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1908
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1909
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1910
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1911
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1912
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1913
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1914
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1915, !DIExpression(), !1916)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1917, !DIExpression(), !1918)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v2), !dbg !1919
    #dbg_value(ptr %v19, !1920, !DIExpression(), !1921)
  %v20 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v8), !dbg !1922
    #dbg_value(ptr %v20, !1923, !DIExpression(), !1924)
  %v21 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.617), !dbg !1925
  %v22 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr %v21), !dbg !1926
  %v23 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v22, ptr @topal.region-instance.namespace-metadata.literal.int.618), !dbg !1927
  %v24 = call ptr @topal.region-instance.namespace-metadata.runtime.int.absolute(ptr %v23), !dbg !1928
    #dbg_value(ptr %v24, !1929, !DIExpression(), !1930)
  %v25 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !1931
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v25, ptr %v3), !dbg !1932
    #dbg_value(i1 %v26, !1933, !DIExpression(), !1934)
  %v27 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.619), !dbg !1935
    #dbg_value(i1 %v27, !1936, !DIExpression(), !1937)
  %v28 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v19, ptr @topal.region-instance.namespace-metadata.literal.int.620), !dbg !1938
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v28, ptr @topal.region-instance.namespace-metadata.literal.int.621), !dbg !1939
    #dbg_value(i1 %v29, !1940, !DIExpression(), !1941)
  %v30 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100(ptr %v2), !dbg !1942
  %v31 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dname.2196(ptr %arg0, ptr %v30), !dbg !1943
    #dbg_value(i1 %v31, !1944, !DIExpression(), !1945)
  %v32 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.622), !dbg !1946
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v32, ptr %v24), !dbg !1947
    #dbg_value(i1 %v33, !1948, !DIExpression(), !1949)
  %v34 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v20, ptr @topal.region-instance.namespace-metadata.literal.int.623), !dbg !1950
  %v35 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v34, ptr %arg2), !dbg !1951
    #dbg_value(i1 %v35, !1952, !DIExpression(), !1953)
  %v36 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !1954
  %v37 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v36, ptr @topal.region-instance.namespace-metadata.literal.int.624), !dbg !1955
  %v38 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v37, ptr %arg2), !dbg !1956
    #dbg_value(i1 %v38, !1957, !DIExpression(), !1958)
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v35, i1 %v38), !dbg !1959
  %v40 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v33, i1 %v39), !dbg !1960
  %v41 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v31, i1 %v40), !dbg !1961
  %v42 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v29, i1 %v41), !dbg !1962
  %v43 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v27, i1 %v42), !dbg !1963
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v26, i1 %v43), !dbg !1964
    #dbg_value(i1 %v44, !1965, !DIExpression(), !1966)
  %v45 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !1967
    #dbg_value(i1 %v45, !1968, !DIExpression(), !1969)
  %v46 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v44, i1 %v45), !dbg !1970
  ret i1 %v46, !dbg !1971
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eexchange_2deffect.2229(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !1974 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !1975, !DIExpression(), !1976)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !1977
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !1978
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !1979
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !1980
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !1981
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !1982
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !1983
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !1984
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !1985
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !1986
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !1987
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !1988
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !1989
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !1990
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !1991
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !1992
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !1993, !DIExpression(), !1994)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !1995, !DIExpression(), !1996)
  %v19 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v2), !dbg !1997
    #dbg_value(ptr %v19, !1998, !DIExpression(), !1999)
  %v20 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v19, ptr %v7), !dbg !2000
    #dbg_value(i1 %v20, !2001, !DIExpression(), !2002)
  %v21 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85(ptr %v6), !dbg !2003
  %v22 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v21, ptr %v3), !dbg !2004
    #dbg_value(i1 %v22, !2005, !DIExpression(), !2006)
  %v23 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v5), !dbg !2007
  %v24 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v23, ptr @topal.region-instance.namespace-metadata.literal.int.625), !dbg !2008
  %v25 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v24, ptr %arg2), !dbg !2009
    #dbg_value(i1 %v25, !2010, !DIExpression(), !2011)
  %v26 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38(ptr %v8), !dbg !2012
  %v27 = call ptr @topal.region-instance.namespace-metadata.runtime.int.add(ptr %v26, ptr @topal.region-instance.namespace-metadata.literal.int.626), !dbg !2013
  %v28 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033(ptr %arg0, ptr %v27, ptr %arg2), !dbg !2014
    #dbg_value(i1 %v28, !2015, !DIExpression(), !2016)
  %v29 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v25, i1 %v28), !dbg !2017
  %v30 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v29), !dbg !2018
  %v31 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v20, i1 %v30), !dbg !2019
    #dbg_value(i1 %v31, !2020, !DIExpression(), !2021)
  %v32 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046(ptr %arg0, ptr %arg2), !dbg !2022
    #dbg_value(i1 %v32, !2023, !DIExpression(), !2024)
  %v33 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v31, i1 %v32), !dbg !2025
  ret i1 %v33, !dbg !2026
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2dreplace_2dor_2dexchange.2230(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2029 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2030, !DIExpression(), !2031)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !2032
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !2033
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !2034
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !2035
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !2036
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !2037
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !2038
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !2039
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !2040
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !2041
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !2042
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !2043
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !2044
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !2045
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !2046
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !2047
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !2048, !DIExpression(), !2049)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !2050, !DIExpression(), !2051)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !2052, !DIExpression(), !2053)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.627), !dbg !2054
  %v21 = icmp eq i32 %v20, 0, !dbg !2055
  %v22 = icmp eq i1 %v21, true, !dbg !2056
  br i1 %v22, label %decision.true.0, label %decision.false.1, !dbg !2057
decision.true.0:
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2058
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v2, 1, !dbg !2059
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v3, 2, !dbg !2060
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v4, 3, !dbg !2061
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v5, 4, !dbg !2062
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v6, 5, !dbg !2063
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v7, 6, !dbg !2064
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 7, !dbg !2065
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v9, 8, !dbg !2066
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v10, 9, !dbg !2067
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v11, 10, !dbg !2068
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v12, 11, !dbg !2069
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v13, 12, !dbg !2070
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v14, 13, !dbg !2071
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v15, 14, !dbg !2072
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v16, 15, !dbg !2073
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ereplace_2deffect.2212(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, ptr %arg3), !dbg !2074
  br label %decision.merge.2, !dbg !2075
decision.false.1:
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2076
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v2, 1, !dbg !2077
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v3, 2, !dbg !2078
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v4, 3, !dbg !2079
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v5, 4, !dbg !2080
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v6, 5, !dbg !2081
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v7, 6, !dbg !2082
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 7, !dbg !2083
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v9, 8, !dbg !2084
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v10, 9, !dbg !2085
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v11, 10, !dbg !2086
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v12, 11, !dbg !2087
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v13, 12, !dbg !2088
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v14, 13, !dbg !2089
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v15, 14, !dbg !2090
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v16, 15, !dbg !2091
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eexchange_2deffect.2229(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, ptr %arg3), !dbg !2092
  br label %decision.merge.2, !dbg !2093
decision.merge.2:
  %v57 = phi i1 [%v39, %decision.true.0], [%v56, %decision.false.1], !dbg !2094
  ret i1 %v57, !dbg !2095
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2drename.2231(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2098 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2099, !DIExpression(), !2100)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !2101
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !2102
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !2103
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !2104
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !2105
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !2106
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !2107
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !2108
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !2109
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !2110
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !2111
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !2112
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !2113
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !2114
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !2115
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !2116
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !2117, !DIExpression(), !2118)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !2119, !DIExpression(), !2120)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !2121, !DIExpression(), !2122)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.628), !dbg !2123
  %v21 = icmp eq i32 %v20, 0, !dbg !2124
  %v22 = icmp eq i1 %v21, true, !dbg !2125
  br i1 %v22, label %decision.true.0, label %decision.false.1, !dbg !2126
decision.true.0:
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2127
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v2, 1, !dbg !2128
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v3, 2, !dbg !2129
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v4, 3, !dbg !2130
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v5, 4, !dbg !2131
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v6, 5, !dbg !2132
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v7, 6, !dbg !2133
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 7, !dbg !2134
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v9, 8, !dbg !2135
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v10, 9, !dbg !2136
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v11, 10, !dbg !2137
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v12, 11, !dbg !2138
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v13, 12, !dbg !2139
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v14, 13, !dbg !2140
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v15, 14, !dbg !2141
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v16, 15, !dbg !2142
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2emove_2deffect.2124(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, ptr %arg3), !dbg !2143
  br label %decision.merge.2, !dbg !2144
decision.false.1:
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2145
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v2, 1, !dbg !2146
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v3, 2, !dbg !2147
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v4, 3, !dbg !2148
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v5, 4, !dbg !2149
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v6, 5, !dbg !2150
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v7, 6, !dbg !2151
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 7, !dbg !2152
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v9, 8, !dbg !2153
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v10, 9, !dbg !2154
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v11, 10, !dbg !2155
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v12, 11, !dbg !2156
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v13, 12, !dbg !2157
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v14, 13, !dbg !2158
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v15, 14, !dbg !2159
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v16, 15, !dbg !2160
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2dreplace_2dor_2dexchange.2230(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, ptr %arg2, ptr %arg3), !dbg !2161
  br label %decision.merge.2, !dbg !2162
decision.merge.2:
  %v57 = phi i1 [%v39, %decision.true.0], [%v56, %decision.false.1], !dbg !2163
  ret i1 %v57, !dbg !2164
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect.2232(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2167 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2168, !DIExpression(), !2169)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !2170
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !2171
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !2172
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !2173
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !2174
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !2175
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !2176
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !2177
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !2178
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !2179
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !2180
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !2181
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !2182
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !2183
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !2184
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !2185
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !2186, !DIExpression(), !2187)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !2188, !DIExpression(), !2189)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !2190, !DIExpression(), !2191)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.629), !dbg !2192
  %v21 = icmp eq i32 %v20, 0, !dbg !2193
  %v22 = icmp eq i1 %v21, true, !dbg !2194
  br i1 %v22, label %decision.true.0, label %decision.false.1, !dbg !2195
decision.true.0:
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2196
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, ptr %v2, 1, !dbg !2197
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, ptr %v3, 2, !dbg !2198
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, ptr %v4, 3, !dbg !2199
  %v27 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v5, 4, !dbg !2200
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v27, ptr %v6, 5, !dbg !2201
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v7, 6, !dbg !2202
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 7, !dbg !2203
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, i32 %v9, 8, !dbg !2204
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, i32 %v10, 9, !dbg !2205
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, i32 %v11, 10, !dbg !2206
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, i32 %v12, 11, !dbg !2207
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, i32 %v13, 12, !dbg !2208
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v14, 13, !dbg !2209
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v15, 14, !dbg !2210
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v16, 15, !dbg !2211
  %v39 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elink_2deffect.2048(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, ptr %arg3), !dbg !2212
  br label %decision.merge.2, !dbg !2213
decision.false.1:
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2214
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, ptr %v2, 1, !dbg !2215
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, ptr %v3, 2, !dbg !2216
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, ptr %v4, 3, !dbg !2217
  %v44 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %v5, 4, !dbg !2218
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v44, ptr %v6, 5, !dbg !2219
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v7, 6, !dbg !2220
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 7, !dbg !2221
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, i32 %v9, 8, !dbg !2222
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, i32 %v10, 9, !dbg !2223
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, i32 %v11, 10, !dbg !2224
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, i32 %v12, 11, !dbg !2225
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, i32 %v13, 12, !dbg !2226
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v14, 13, !dbg !2227
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v15, 14, !dbg !2228
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v16, 15, !dbg !2229
  %v56 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2drename.2231(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, ptr %arg2, ptr %arg3), !dbg !2230
  br label %decision.merge.2, !dbg !2231
decision.merge.2:
  %v57 = phi i1 [%v39, %decision.true.0], [%v56, %decision.false.1], !dbg !2232
  ret i1 %v57, !dbg !2233
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2echecked.2233(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %arg2, ptr %arg3) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2236 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2237, !DIExpression(), !2238)
  %v1 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 0, !dbg !2239
  %v2 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 1, !dbg !2240
  %v3 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 2, !dbg !2241
  %v4 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 3, !dbg !2242
  %v5 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 4, !dbg !2243
  %v6 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 5, !dbg !2244
  %v7 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 6, !dbg !2245
  %v8 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 7, !dbg !2246
  %v9 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 8, !dbg !2247
  %v10 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 9, !dbg !2248
  %v11 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 10, !dbg !2249
  %v12 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 11, !dbg !2250
  %v13 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 12, !dbg !2251
  %v14 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 13, !dbg !2252
  %v15 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 14, !dbg !2253
  %v16 = extractvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, 15, !dbg !2254
  %v17 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %arg1, ptr %v17, align 8
    #dbg_declare(ptr %v17, !2255, !DIExpression(), !2256)
  %v18 = alloca ptr, align 8
  store ptr %arg2, ptr %v18, align 8
    #dbg_declare(ptr %v18, !2257, !DIExpression(), !2258)
  %v19 = alloca ptr, align 8
  store ptr %arg3, ptr %v19, align 8
    #dbg_declare(ptr %v19, !2259, !DIExpression(), !2260)
  %v20 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.630), !dbg !2261
  %v21 = icmp eq i32 %v20, 0, !dbg !2262
  %v22 = icmp ne i1 %v21, true, !dbg !2263
  %v23 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v6, ptr %v2), !dbg !2264
  %v24 = icmp eq i32 %v23, 0, !dbg !2265
  %v25 = icmp eq i1 %v24, true, !dbg !2266
  %v26 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0(i1 %v22, i1 %v25), !dbg !2267
  %v27 = xor i1 %v26, true, !dbg !2268
    #dbg_value(i1 %v27, !2269, !DIExpression(), !2270)
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2271
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v2, 1, !dbg !2272
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v3, 2, !dbg !2273
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, ptr %v4, 3, !dbg !2274
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, ptr %v5, 4, !dbg !2275
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, ptr %v6, 5, !dbg !2276
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, ptr %v7, 6, !dbg !2277
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, ptr %v8, 7, !dbg !2278
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 %v9, 8, !dbg !2279
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 %v10, 9, !dbg !2280
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 %v11, 10, !dbg !2281
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, i32 %v12, 11, !dbg !2282
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, i32 %v13, 12, !dbg !2283
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, i32 %v14, 13, !dbg !2284
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, i32 %v15, 14, !dbg !2285
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, i32 %v16, 15, !dbg !2286
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dvalid.98(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %arg2), !dbg !2287
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2288
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v2, 1, !dbg !2289
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v3, 2, !dbg !2290
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, ptr %v4, 3, !dbg !2291
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, ptr %v5, 4, !dbg !2292
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, ptr %v6, 5, !dbg !2293
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, ptr %v7, 6, !dbg !2294
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, ptr %v8, 7, !dbg !2295
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 %v9, 8, !dbg !2296
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 %v10, 9, !dbg !2297
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 %v11, 10, !dbg !2298
  %v56 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, i32 %v12, 11, !dbg !2299
  %v57 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v56, i32 %v13, 12, !dbg !2300
  %v58 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v57, i32 %v14, 13, !dbg !2301
  %v59 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v58, i32 %v15, 14, !dbg !2302
  %v60 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v59, i32 %v16, 15, !dbg !2303
  %v61 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dvalid.259(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v60, ptr %arg2), !dbg !2304
  %v62 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2einput_2dclean.1962(ptr %arg0, ptr %v1), !dbg !2305
  %v63 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v44, i1 %v61, i1 %v62, i1 %v27), !dbg !2306
    #dbg_value(i1 %v63, !2307, !DIExpression(), !2308)
  br i1 %v63, label %decision.true.0, label %decision.false.1, !dbg !2309
decision.true.0:
  %v64 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v1, 0, !dbg !2310
  %v65 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v64, ptr %v2, 1, !dbg !2311
  %v66 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v65, ptr %v3, 2, !dbg !2312
  %v67 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v66, ptr %v4, 3, !dbg !2313
  %v68 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v67, ptr %v5, 4, !dbg !2314
  %v69 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v68, ptr %v6, 5, !dbg !2315
  %v70 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v69, ptr %v7, 6, !dbg !2316
  %v71 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v70, ptr %v8, 7, !dbg !2317
  %v72 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v71, i32 %v9, 8, !dbg !2318
  %v73 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v72, i32 %v10, 9, !dbg !2319
  %v74 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v73, i32 %v11, 10, !dbg !2320
  %v75 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v74, i32 %v12, 11, !dbg !2321
  %v76 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v75, i32 %v13, 12, !dbg !2322
  %v77 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v76, i32 %v14, 13, !dbg !2323
  %v78 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v77, i32 %v15, 14, !dbg !2324
  %v79 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v78, i32 %v16, 15, !dbg !2325
  %v80 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect.2232(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v79, ptr %arg2, ptr %arg3), !dbg !2326
  br label %decision.merge.2, !dbg !2327
decision.false.1:
  br label %decision.merge.2, !dbg !2328
decision.merge.2:
  %v81 = phi i1 [%v80, %decision.true.0], [false, %decision.false.1], !dbg !2329
  ret i1 %v81, !dbg !2330
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eread_2dinput.2234(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2333 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2334, !DIExpression(), !2335)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2336, !DIExpression(), !2337)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !2338, !DIExpression(), !2339)
  %v3 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.631), !dbg !2340
  %v4 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.632), !dbg !2341
  %v5 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.633), !dbg !2342
  %v6 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.634), !dbg !2343
  %v7 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.635), !dbg !2344
  %v8 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.636), !dbg !2345
  %v9 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.637), !dbg !2346
  %v10 = call fastcc ptr @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5(ptr %arg0, ptr @topal.region-instance.namespace-metadata.literal.int.638), !dbg !2347
  %v11 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v7, 0, !dbg !2348
  %v12 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v11, ptr %v4, 1, !dbg !2349
  %v13 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v12, ptr %v8, 2, !dbg !2350
  %v14 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v13, ptr %v10, 3, !dbg !2351
  %v15 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v14, ptr %v3, 4, !dbg !2352
  %v16 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v15, ptr %v6, 5, !dbg !2353
  %v17 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v16, ptr %v9, 6, !dbg !2354
  %v18 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v17, ptr %v5, 7, !dbg !2355
  %v19 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v18, i32 4, 8, !dbg !2356
  %v20 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v19, i32 1, 9, !dbg !2357
  %v21 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v20, i32 7, 10, !dbg !2358
  %v22 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v21, i32 5, 11, !dbg !2359
  %v23 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v22, i32 0, 12, !dbg !2360
  %v24 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v23, i32 2, 13, !dbg !2361
  %v25 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v24, i32 6, 14, !dbg !2362
  %v26 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v25, i32 3, 15, !dbg !2363
  %v27 = alloca { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 }, align 8, !dbg !2366
  store { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v26, ptr %v27, align 8, !dbg !2367
    #dbg_declare(ptr %v27, !2364, !DIExpression(), !2365)
  %v28 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v7, 0, !dbg !2368
  %v29 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v28, ptr %v4, 1, !dbg !2369
  %v30 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v29, ptr %v8, 2, !dbg !2370
  %v31 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v30, ptr %v10, 3, !dbg !2371
  %v32 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v31, ptr %v3, 4, !dbg !2372
  %v33 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v32, ptr %v6, 5, !dbg !2373
  %v34 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v33, ptr %v9, 6, !dbg !2374
  %v35 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v34, ptr %v5, 7, !dbg !2375
  %v36 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v35, i32 4, 8, !dbg !2376
  %v37 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v36, i32 1, 9, !dbg !2377
  %v38 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v37, i32 7, 10, !dbg !2378
  %v39 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v38, i32 5, 11, !dbg !2379
  %v40 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v39, i32 0, 12, !dbg !2380
  %v41 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v40, i32 2, 13, !dbg !2381
  %v42 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v41, i32 6, 14, !dbg !2382
  %v43 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v42, i32 3, 15, !dbg !2383
  %v44 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eindex_2dshape.36({ ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v43, ptr %arg1), !dbg !2384
  br i1 %v44, label %decision.true.0, label %decision.false.1, !dbg !2385
decision.true.0:
  %v45 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } poison, ptr %v7, 0, !dbg !2386
  %v46 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v45, ptr %v4, 1, !dbg !2387
  %v47 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v46, ptr %v8, 2, !dbg !2388
  %v48 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v47, ptr %v10, 3, !dbg !2389
  %v49 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v48, ptr %v3, 4, !dbg !2390
  %v50 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v49, ptr %v6, 5, !dbg !2391
  %v51 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v50, ptr %v9, 6, !dbg !2392
  %v52 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v51, ptr %v5, 7, !dbg !2393
  %v53 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v52, i32 4, 8, !dbg !2394
  %v54 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v53, i32 1, 9, !dbg !2395
  %v55 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v54, i32 7, 10, !dbg !2396
  %v56 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v55, i32 5, 11, !dbg !2397
  %v57 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v56, i32 0, 12, !dbg !2398
  %v58 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v57, i32 2, 13, !dbg !2399
  %v59 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v58, i32 6, 14, !dbg !2400
  %v60 = insertvalue { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v59, i32 3, 15, !dbg !2401
  %v61 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2echecked.2233(ptr %arg0, { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i32, i32, i32, i32, i32, i32 } %v60, ptr %arg1, ptr %arg2), !dbg !2402
  br label %decision.merge.2, !dbg !2403
decision.false.1:
  br label %decision.merge.2, !dbg !2404
decision.merge.2:
  %v62 = phi i1 [%v61, %decision.true.0], [false, %decision.false.1], !dbg !2405
  ret i1 %v62, !dbg !2406
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eapply.2235(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2409 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2410, !DIExpression(), !2411)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2412, !DIExpression(), !2413)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !2414, !DIExpression(), !2415)
  %v3 = call ptr @topal.region-instance.namespace-metadata.primitive.count(ptr %arg0), !dbg !2416
    #dbg_value(ptr %v3, !2417, !DIExpression(), !2418)
  %v4 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.639), !dbg !2419
  %v5 = icmp sge i32 %v4, 0, !dbg !2420
  %v6 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg1, ptr @topal.region-instance.namespace-metadata.literal.int.640), !dbg !2421
  %v7 = icmp sle i32 %v6, 0, !dbg !2422
  %v8 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %arg2, ptr @topal.region-instance.namespace-metadata.literal.int.641), !dbg !2423
  %v9 = icmp sle i32 %v8, 0, !dbg !2424
  %v10 = call i32 @topal.region-instance.namespace-metadata.runtime.int.compare(ptr %v3, ptr @topal.region-instance.namespace-metadata.literal.int.642), !dbg !2425
  %v11 = icmp sle i32 %v10, 0, !dbg !2426
  %v12 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3(i1 %v5, i1 %v7, i1 %v9, i1 %v11), !dbg !2427
    #dbg_value(i1 %v12, !2428, !DIExpression(), !2429)
  br i1 %v12, label %decision.true.0, label %decision.false.1, !dbg !2430
decision.true.0:
  %v13 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eread_2dinput.2234(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !2431
  br label %decision.merge.2, !dbg !2432
decision.false.1:
  br label %decision.merge.2, !dbg !2433
decision.merge.2:
  %v14 = phi i1 [%v13, %decision.true.0], [false, %decision.false.1], !dbg !2434
  ret i1 %v14, !dbg !2435
}

define internal fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.apply.2236(ptr %arg0, ptr %arg1, ptr %arg2) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !2438 {
entry:
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !2439, !DIExpression(), !2440)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !2441, !DIExpression(), !2442)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !2443, !DIExpression(), !2444)
  %v3 = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eapply.2235(ptr %arg0, ptr %arg1, ptr %arg2), !dbg !2445
  ret i1 %v3, !dbg !2446
}


define i64 @topal_kernel_region_frame_namespace_metadata_apply_v1(ptr %control, i64 %expected.owner, i64 %next.epoch, ptr %frame.words, i64 %frame.word.count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %frame.arity.valid = icmp eq i64 %frame.word.count, 2
  br i1 %frame.arity.valid, label %frame.control, label %invalid
frame.control:
  %address = ptrtoint ptr %control to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %control.end = add i64 %address, 64
  %control.extent.valid = icmp uge i64 %control.end, %address
  %pointer.valid = and i1 %nonnull, %aligned
  %control.valid = and i1 %pointer.valid, %control.extent.valid
  br i1 %control.valid, label %fields, label %invalid
fields:
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_kernel_region_frame_namespace_metadata_apply_v1
  %owner.nonzero = icmp ne i64 %owner, 0
  %owner.matches = icmp eq i64 %owner, %expected.owner
  %owner.valid = and i1 %owner.nonzero, %owner.matches
  %epoch.bounded = icmp ne i64 %epoch, 18446744073709551615
  %successor = add i64 %epoch, 1
  %epoch.matches = icmp eq i64 %successor, %next.epoch
  %epoch.valid = and i1 %epoch.bounded, %epoch.matches
  %active.valid = icmp eq i64 %active, 0
  %issued.valid = icmp eq i64 %issued, 0
  %count.valid = icmp ule i64 %count, 65536
  %rights.valid = icmp ule i64 %rights, 1
  %base.address = ptrtoint ptr %base to i64
  %base.valid = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %below.control = icmp ule i64 %end, %address
  %above.control = icmp uge i64 %base.address, %control.end
  %disjoint = or i1 %below.control, %above.control
  %a = and i1 %code.valid, %owner.valid
  %b = and i1 %epoch.valid, %active.valid
  %c = and i1 %issued.valid, %count.valid
  %d = and i1 %rights.valid, %base.valid
  %e = and i1 %end.valid, %disjoint
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %abcd = and i1 %ab, %cd
  %valid = and i1 %abcd, %e
  br i1 %valid, label %frame.bounds, label %invalid
frame.bounds:
  %frame.address = ptrtoint ptr %frame.words to i64
  %frame.nonnull = icmp ne i64 %frame.address, 0
  %frame.alignment = and i64 %frame.address, 7
  %frame.aligned = icmp eq i64 %frame.alignment, 0
  %frame.end = add i64 %frame.address, 16
  %frame.extent.valid = icmp uge i64 %frame.end, %frame.address
  %frame.below.control = icmp ule i64 %frame.end, %address
  %frame.above.control = icmp uge i64 %frame.address, %control.end
  %frame.control.disjoint = or i1 %frame.below.control, %frame.above.control
  %frame.below.owner = icmp ule i64 %frame.end, %base.address
  %frame.above.owner = icmp uge i64 %frame.address, %end
  %frame.owner.disjoint = or i1 %frame.below.owner, %frame.above.owner
  %frame.pointer.valid = and i1 %frame.nonnull, %frame.aligned
  %frame.storage.valid = and i1 %frame.extent.valid, %frame.control.disjoint
  %frame.nonoverlapping = and i1 %frame.storage.valid, %frame.owner.disjoint
  %frame.valid = and i1 %frame.pointer.valid, %frame.nonoverlapping
  br i1 %frame.valid, label %prepare, label %invalid
prepare:
  store i64 %next.epoch, ptr %epoch.pointer, align 8
  store i64 1, ptr %active.pointer, align 8
  store i64 1, ptr %issued.pointer, align 8
  %view = call ptr @topal.region-instance.namespace-metadata.platform.allocate(i64 64)
  %v0 = insertvalue %topal.KernelRegionView zeroinitializer, ptr %control, 0
  %v1 = insertvalue %topal.KernelRegionView %v0, i64 %count, 2
  %v2 = insertvalue %topal.KernelRegionView %v1, i64 %rights, 3
  %v3 = insertvalue %topal.KernelRegionView %v2, i64 %next.epoch, 4
  %v4 = insertvalue %topal.KernelRegionView %v3, i64 %owner, 5
  %v5 = insertvalue %topal.KernelRegionView %v4, ptr @topal_kernel_region_frame_namespace_metadata_apply_v1, 6
  store %topal.KernelRegionView %v5, ptr %view, align 8
  %frame.word.pointer.0 = getelementptr i64, ptr %frame.words, i64 0
  %frame.word.0 = load i64, ptr %frame.word.pointer.0, align 8
  %frame.value.0 = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %frame.word.0)
  %frame.word.pointer.1 = getelementptr i64, ptr %frame.words, i64 1
  %frame.word.1 = load i64, ptr %frame.word.pointer.1, align 8
  %frame.value.1 = call ptr @topal.region-instance.namespace-metadata.runtime.int.from.u64(i64 %frame.word.1)
  %accepted = call fastcc i1 @topal.region-instance.namespace-metadata.topal.fn.apply.2236(ptr %view, ptr %frame.value.0, ptr %frame.value.1)

  %final.view = call ptr @topal.region-instance.namespace-metadata.primitive.guard(ptr %view)
  store ptr null, ptr %control, align 8
  store i64 0, ptr %owner.pointer, align 8
  store i64 0, ptr %active.pointer, align 8
  store ptr null, ptr %base.pointer, align 8
  store i64 0, ptr %count.pointer, align 8
  store i64 0, ptr %rights.pointer, align 8
  store i64 0, ptr %issued.pointer, align 8
  %result = zext i1 %accepted to i64
  ret i64 %result
invalid:
  call void @topal.region-instance.namespace-metadata.primitive.abort()
  unreachable
}
!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!2447, !2448}
!llvm.ident = !{!2449}
!0 = !DIFile(filename: "namespace-action.t", directory: "/home/mats/git/topal/linux-kernel/kernel/policy")
!1 = !{}
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !0, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !1, retainedTypes: !1)
!3 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!4 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!5 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!6 = !{!4, !5}
!7 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !0, size: 128, align: 64, elements: !6)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64, align: 64)
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !0, baseType: !8)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !0, baseType: !8)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "major", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "minor", file: !0, baseType: !10, size: 64, align: 64, offset: 64)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "patch", file: !0, baseType: !10, size: 64, align: 64, offset: 128)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "build", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!15 = !{!11, !12, !13, !14}
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalVersionHeader", file: !0, size: 256, align: 64, elements: !15)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "Version", file: !0, baseType: !17)
!19 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !20, size: 64, align: 64, offset: 0)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "byte_count", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!23 = !{!21, !22}
!24 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSerializationStreamHeader", file: !0, size: 128, align: 64, elements: !23)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64, align: 64)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "SerializationStream", file: !0, baseType: !25)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "numerator", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "denominator", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!29 = !{!27, !28}
!30 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRationalHeader", file: !0, size: 128, align: 64, elements: !29)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !30, size: 64, align: 64)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "Rational", file: !0, baseType: !31)
!33 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!34 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !33, size: 64, align: 64)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !34, size: 64, align: 64, offset: 0)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!37 = !DIDerivedType(tag: DW_TAG_member, name: "display", file: !0, baseType: !34, size: 64, align: 64, offset: 128)
!38 = !DIDerivedType(tag: DW_TAG_member, name: "display_length", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!39 = !{!35, !36, !37, !38}
!40 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalStringHeader", file: !0, size: 256, align: 64, elements: !39)
!41 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !40, size: 64, align: 64)
!42 = !DIDerivedType(tag: DW_TAG_typedef, name: "String", file: !0, baseType: !41)
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "Character", file: !0, baseType: !41)
!44 = !DIDerivedType(tag: DW_TAG_typedef, name: "ErrorDomain", file: !0, baseType: !41)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "line", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "column", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!47 = !{!45, !46}
!48 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSourceLocationHeader", file: !0, size: 128, align: 64, elements: !47)
!49 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !48, size: 64, align: 64)
!50 = !DIDerivedType(tag: DW_TAG_typedef, name: "SourceLocation", file: !0, baseType: !49)
!51 = !DIEnumerator(name: "out-of-range", value: 0)
!52 = !DIEnumerator(name: "not-representable", value: 1)
!53 = !DIEnumerator(name: "division-by-zero", value: 2)
!54 = !DIEnumerator(name: "indeterminate", value: 3)
!55 = !{!51, !52, !53, !54}
!56 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "lang arithmetic ArithmeticErrorCode", file: !0, size: 32, align: 32, elements: !55)
!57 = !DIDerivedType(tag: DW_TAG_member, name: "domain", file: !0, baseType: !44, size: 64, align: 64, offset: 0)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "code", file: !0, baseType: !56, size: 32, align: 32, offset: 64)
!59 = !{!57, !58}
!60 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalErrorHeader", file: !0, size: 448, align: 64, elements: !59)
!61 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !60, size: 64, align: 64)
!62 = !DIDerivedType(tag: DW_TAG_typedef, name: "Error", file: !0, baseType: !61)
!63 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!64 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!65 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!67 = !{!63, !64, !65, !66}
!68 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeIntHeader", file: !0, size: 256, align: 64, elements: !67)
!69 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !68, size: 64, align: 64)
!70 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Int", file: !0, baseType: !69)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !32, size: 64, align: 64, offset: 0)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !32, size: 64, align: 64, offset: 64)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!75 = !{!71, !72, !73, !74}
!76 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeRationalHeader", file: !0, size: 256, align: 64, elements: !75)
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !76, size: 64, align: 64)
!78 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Rational", file: !0, baseType: !77)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "is_error", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!80 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !80, size: 64, align: 64, offset: 64)
!82 = !{!79, !81}
!83 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalResultHeader", file: !0, size: 128, align: 64, elements: !82)
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !83, size: 64, align: 64)
!85 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Int, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!86 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Nat, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!87 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Rational, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!88 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (String, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!89 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result ((Int, Int), lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "tag", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!91 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !91, size: 64, align: 64, offset: 64)
!93 = !{!90, !92}
!94 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalOptionalHeader", file: !0, size: 128, align: 64, elements: !93)
!95 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64, align: 64)
!96 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Int", file: !0, baseType: !95)
!97 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Rational", file: !0, baseType: !95)
!98 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Character", file: !0, baseType: !95)
!99 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional String", file: !0, baseType: !95)
!100 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Error", file: !0, baseType: !95)
!101 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional SourceLocation", file: !0, baseType: !95)
!102 = !DIEnumerator(name: "Less", value: -1)
!103 = !DIEnumerator(name: "Equal", value: 0)
!104 = !DIEnumerator(name: "Greater", value: 1)
!105 = !{!102, !103, !104}
!106 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Comparison", file: !0, size: 32, align: 32, elements: !105)
!107 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!108 = !DIBasicType(name: "Unit", size: 8, encoding: DW_ATE_unsigned)
!109 = !DIEnumerator(name: "Completed", value: 0)
!110 = !{!109}
!111 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Completed", file: !0, size: 8, align: 8, elements: !110)
!112 = !DIEnumerator(name: "empty", value: 0)
!113 = !{!112}
!114 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Effect", file: !0, size: 8, align: 8, elements: !113)
!115 = !DIFile(filename: "namespace-bytes.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!116 = !DIFile(filename: "namespace-metadata.t", directory: "/home/mats/git/topal/linux-kernel/kernel/support")
!117 = !{!107, !107, !107}
!118 = !DISubroutineType(types: !117)
!119 = distinct !DISubprogram(name: "support.namespace-metadata.both", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eboth.0", scope: !116, file: !116, line: 14, type: !118, scopeLine: 14, spFlags: DISPFlagDefinition, unit: !2)
!120 = !DILocalVariable(name: "first", arg: 1, scope: !119, file: !116, line: 14, type: !107)
!121 = !DILocation(line: 14, column: 14, scope: !119)
!122 = !DILocalVariable(name: "second", arg: 2, scope: !119, file: !116, line: 14, type: !107)
!123 = !DILocation(line: 14, column: 31, scope: !119)
!124 = !DILocation(line: 15, column: 3, scope: !119)
!125 = !DILocation(line: 16, column: 15, scope: !119)
!126 = !DILocation(line: 17, column: 16, scope: !119)
!127 = !DILocation(line: 15, column: 3, scope: !119)
!128 = !DILocation(line: 15, column: 3, scope: !119)
!129 = !{!107, !107, !107, !107, !107}
!130 = !DISubroutineType(types: !129)
!131 = distinct !DISubprogram(name: "support.namespace-metadata.four", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2efour.3", scope: !116, file: !116, line: 19, type: !130, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !2)
!132 = !DILocalVariable(name: "first", arg: 1, scope: !131, file: !116, line: 19, type: !107)
!133 = !DILocation(line: 19, column: 14, scope: !131)
!134 = !DILocalVariable(name: "second", arg: 2, scope: !131, file: !116, line: 19, type: !107)
!135 = !DILocation(line: 19, column: 31, scope: !131)
!136 = !DILocalVariable(name: "third", arg: 3, scope: !131, file: !116, line: 19, type: !107)
!137 = !DILocation(line: 19, column: 49, scope: !131)
!138 = !DILocalVariable(name: "fourth", arg: 4, scope: !131, file: !116, line: 19, type: !107)
!139 = !DILocation(line: 19, column: 66, scope: !131)
!140 = !DILocation(line: 20, column: 9, scope: !131)
!141 = !DILocation(line: 20, column: 31, scope: !131)
!142 = !DILocation(line: 20, column: 3, scope: !131)
!143 = !DILocation(line: 20, column: 3, scope: !131)
!144 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalKernelRegionBorrow", flags: DIFlagFwdDecl)
!145 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !144, size: 64, align: 64)
!146 = !DIDerivedType(tag: DW_TAG_typedef, name: "KernelByteRegion", file: !0, baseType: !145)
!147 = !{!10, !146, !10}
!148 = !DISubroutineType(types: !147)
!149 = distinct !DISubprogram(name: "support.namespace-bytes.word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eword.4", scope: !115, file: !115, line: 3, type: !148, scopeLine: 3, spFlags: DISPFlagDefinition, unit: !2)
!150 = !DILocalVariable(name: "region", arg: 1, scope: !149, file: !115, line: 3, type: !146)
!151 = !DILocation(line: 3, column: 18, scope: !149)
!152 = !DILocalVariable(name: "offset", arg: 2, scope: !149, file: !115, line: 3, type: !10)
!153 = !DILocation(line: 3, column: 45, scope: !149)
!154 = !DILocation(line: 4, column: 3, scope: !149)
!155 = !DILocation(line: 4, column: 3, scope: !149)
!156 = !DILocation(line: 4, column: 3, scope: !149)
!157 = !DILocation(line: 5, column: 10, scope: !149)
!158 = !DILocalVariable(name: "value", scope: !149, file: !115, line: 5, type: !10)
!159 = !DILocation(line: 5, column: 10, scope: !149)
!160 = !DILocation(line: 5, column: 21, scope: !149)
!161 = !DILocation(line: 6, column: 15, scope: !149)
!162 = !DILocation(line: 4, column: 3, scope: !149)
!163 = !DILocation(line: 4, column: 3, scope: !149)
!164 = !{!10, !146, !10}
!165 = !DISubroutineType(types: !164)
!166 = distinct !DISubprogram(name: "support.namespace-metadata.word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eword.5", scope: !116, file: !116, line: 8, type: !165, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !2)
!167 = !DILocalVariable(name: "region", arg: 1, scope: !166, file: !116, line: 8, type: !146)
!168 = !DILocation(line: 8, column: 14, scope: !166)
!169 = !DILocalVariable(name: "offset", arg: 2, scope: !166, file: !116, line: 8, type: !10)
!170 = !DILocation(line: 8, column: 41, scope: !166)
!171 = !DILocation(line: 9, column: 3, scope: !166)
!172 = !DILocation(line: 9, column: 3, scope: !166)
!173 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!174 = !DIDerivedType(tag: DW_TAG_member, name: "source-entry", file: !0, baseType: !10, size: 64, align: 64, offset: 64)
!175 = !DIDerivedType(tag: DW_TAG_member, name: "source-identity", file: !0, baseType: !10, size: 64, align: 64, offset: 128)
!176 = !DIDerivedType(tag: DW_TAG_member, name: "source-links", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!177 = !DIDerivedType(tag: DW_TAG_member, name: "source-object", file: !0, baseType: !10, size: 64, align: 64, offset: 256)
!178 = !DIDerivedType(tag: DW_TAG_member, name: "target-entry", file: !0, baseType: !10, size: 64, align: 64, offset: 320)
!179 = !DIDerivedType(tag: DW_TAG_member, name: "target-identity", file: !0, baseType: !10, size: 64, align: 64, offset: 384)
!180 = !DIDerivedType(tag: DW_TAG_member, name: "target-object", file: !0, baseType: !10, size: 64, align: 64, offset: 448)
!181 = !{!173, !174, !175, !176, !177, !178, !179, !180}
!182 = !DICompositeType(tag: DW_TAG_structure_type, name: "(length : Nat, source-entry : Nat, source-identity : Nat, source-links : Nat, source-object : Nat, target-entry : Nat, target-identity : Nat, target-object : Nat)", file: !0, size: 768, align: 64, elements: !181)
!183 = !{!107, !182, !10}
!184 = !DISubroutineType(types: !183)
!185 = distinct !DISubprogram(name: "support.namespace-metadata.index-shape", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eindex_2dshape.36", scope: !116, file: !116, line: 89, type: !184, scopeLine: 89, spFlags: DISPFlagDefinition, unit: !2)
!186 = !DILocation(line: 89, column: 21, scope: !185)
!187 = !DILocation(line: 89, column: 21, scope: !185)
!188 = !DILocation(line: 89, column: 21, scope: !185)
!189 = !DILocation(line: 89, column: 21, scope: !185)
!190 = !DILocation(line: 89, column: 21, scope: !185)
!191 = !DILocation(line: 89, column: 21, scope: !185)
!192 = !DILocation(line: 89, column: 21, scope: !185)
!193 = !DILocation(line: 89, column: 21, scope: !185)
!194 = !DILocation(line: 89, column: 21, scope: !185)
!195 = !DILocation(line: 89, column: 21, scope: !185)
!196 = !DILocation(line: 89, column: 21, scope: !185)
!197 = !DILocation(line: 89, column: 21, scope: !185)
!198 = !DILocation(line: 89, column: 21, scope: !185)
!199 = !DILocation(line: 89, column: 21, scope: !185)
!200 = !DILocation(line: 89, column: 21, scope: !185)
!201 = !DILocation(line: 89, column: 21, scope: !185)
!202 = !DILocalVariable(name: "facts", arg: 1, scope: !185, file: !116, line: 89, type: !182)
!203 = !DILocation(line: 89, column: 21, scope: !185)
!204 = !DILocalVariable(name: "operation", arg: 2, scope: !185, file: !116, line: 89, type: !10)
!205 = !DILocation(line: 89, column: 200, scope: !185)
!206 = !DILocation(line: 90, column: 19, scope: !185)
!207 = !DILocation(line: 90, column: 19, scope: !185)
!208 = !DILocation(line: 90, column: 42, scope: !185)
!209 = !DILocation(line: 90, column: 42, scope: !185)
!210 = !DILocation(line: 90, column: 42, scope: !185)
!211 = !DILocation(line: 90, column: 69, scope: !185)
!212 = !DILocation(line: 90, column: 69, scope: !185)
!213 = !DILocation(line: 90, column: 69, scope: !185)
!214 = !DILocation(line: 90, column: 35, scope: !185)
!215 = !DILocation(line: 90, column: 13, scope: !185)
!216 = !DILocalVariable(name: "absent", scope: !185, file: !116, line: 90, type: !107)
!217 = !DILocation(line: 90, column: 3, scope: !185)
!218 = !DILocation(line: 91, column: 23, scope: !185)
!219 = !DILocation(line: 91, column: 23, scope: !185)
!220 = !DILocation(line: 91, column: 50, scope: !185)
!221 = !DILocation(line: 91, column: 50, scope: !185)
!222 = !DILocation(line: 91, column: 50, scope: !185)
!223 = !DILocation(line: 91, column: 98, scope: !185)
!224 = !DILocation(line: 91, column: 98, scope: !185)
!225 = !DILocation(line: 91, column: 128, scope: !185)
!226 = !DILocation(line: 91, column: 128, scope: !185)
!227 = !DILocation(line: 91, column: 128, scope: !185)
!228 = !DILocation(line: 91, column: 16, scope: !185)
!229 = !DILocalVariable(name: "different", scope: !185, file: !116, line: 91, type: !107)
!230 = !DILocation(line: 91, column: 3, scope: !185)
!231 = !DILocation(line: 92, column: 20, scope: !185)
!232 = !DILocation(line: 92, column: 20, scope: !185)
!233 = !DILocation(line: 92, column: 14, scope: !185)
!234 = !DILocalVariable(name: "present", scope: !185, file: !116, line: 92, type: !107)
!235 = !DILocation(line: 92, column: 3, scope: !185)
!236 = !DILocation(line: 93, column: 24, scope: !185)
!237 = !DILocation(line: 93, column: 36, scope: !185)
!238 = !DILocation(line: 93, column: 18, scope: !185)
!239 = !DILocation(line: 93, column: 13, scope: !185)
!240 = !DILocalVariable(name: "target", scope: !185, file: !116, line: 93, type: !107)
!241 = !DILocation(line: 93, column: 3, scope: !185)
!242 = !DILocation(line: 94, column: 20, scope: !185)
!243 = !DILocation(line: 94, column: 20, scope: !185)
!244 = !DILocation(line: 94, column: 47, scope: !185)
!245 = !DILocation(line: 94, column: 47, scope: !185)
!246 = !DILocation(line: 94, column: 74, scope: !185)
!247 = !DILocation(line: 94, column: 74, scope: !185)
!248 = !DILocation(line: 94, column: 104, scope: !185)
!249 = !DILocation(line: 94, column: 104, scope: !185)
!250 = !DILocation(line: 94, column: 13, scope: !185)
!251 = !DILocalVariable(name: "source", scope: !185, file: !116, line: 94, type: !107)
!252 = !DILocation(line: 94, column: 3, scope: !185)
!253 = !DILocation(line: 95, column: 26, scope: !185)
!254 = !DILocation(line: 95, column: 26, scope: !185)
!255 = !DILocation(line: 95, column: 51, scope: !185)
!256 = !DILocation(line: 95, column: 51, scope: !185)
!257 = !DILocation(line: 95, column: 3, scope: !185)
!258 = !DILocation(line: 95, column: 3, scope: !185)
!259 = !{!10, !10}
!260 = !DISubroutineType(types: !259)
!261 = distinct !DISubprogram(name: "support.namespace-metadata.object-base", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eobject_2dbase.38", scope: !116, file: !116, line: 22, type: !260, scopeLine: 22, spFlags: DISPFlagDefinition, unit: !2)
!262 = !DILocalVariable(name: "slot", arg: 1, scope: !261, file: !116, line: 22, type: !10)
!263 = !DILocation(line: 22, column: 20, scope: !261)
!264 = !DILocation(line: 23, column: 10, scope: !261)
!265 = !DILocation(line: 23, column: 3, scope: !261)
!266 = !DILocation(line: 23, column: 3, scope: !261)
!267 = !{!10, !146, !10, !10}
!268 = !DISubroutineType(types: !267)
!269 = distinct !DISubprogram(name: "support.namespace-metadata.count-association", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ecount_2dassociation.43", scope: !116, file: !116, line: 31, type: !268, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !2)
!270 = !DILocalVariable(name: "region", arg: 1, scope: !269, file: !116, line: 31, type: !146)
!271 = !DILocation(line: 31, column: 27, scope: !269)
!272 = !DILocalVariable(name: "offset", arg: 2, scope: !269, file: !116, line: 31, type: !10)
!273 = !DILocation(line: 31, column: 54, scope: !269)
!274 = !DILocalVariable(name: "identity", arg: 3, scope: !269, file: !116, line: 31, type: !10)
!275 = !DILocation(line: 31, column: 68, scope: !269)
!276 = !DILocation(line: 32, column: 4, scope: !269)
!277 = !DILocation(line: 32, column: 4, scope: !269)
!278 = !DILocation(line: 32, column: 4, scope: !269)
!279 = !DILocation(line: 32, column: 4, scope: !269)
!280 = !DILocation(line: 32, column: 4, scope: !269)
!281 = !DILocation(line: 33, column: 15, scope: !269)
!282 = !DILocation(line: 34, column: 16, scope: !269)
!283 = !DILocation(line: 32, column: 4, scope: !269)
!284 = !DILocation(line: 32, column: 4, scope: !269)
!285 = !{!10, !146, !10}
!286 = !DISubroutineType(types: !285)
!287 = distinct !DISubprogram(name: "support.namespace-metadata.links", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elinks.59", scope: !116, file: !116, line: 36, type: !286, scopeLine: 36, spFlags: DISPFlagDefinition, unit: !2)
!288 = !DILocalVariable(name: "region", arg: 1, scope: !287, file: !116, line: 36, type: !146)
!289 = !DILocation(line: 36, column: 15, scope: !287)
!290 = !DILocalVariable(name: "identity", arg: 2, scope: !287, file: !116, line: 36, type: !10)
!291 = !DILocation(line: 36, column: 42, scope: !287)
!292 = !DILocation(line: 37, column: 13, scope: !287)
!293 = !DILocalVariable(name: "seen-0", scope: !287, file: !116, line: 37, type: !10)
!294 = !DILocation(line: 37, column: 3, scope: !287)
!295 = !DILocation(line: 38, column: 13, scope: !287)
!296 = !DILocalVariable(name: "seen-1", scope: !287, file: !116, line: 38, type: !10)
!297 = !DILocation(line: 38, column: 3, scope: !287)
!298 = !DILocation(line: 39, column: 13, scope: !287)
!299 = !DILocalVariable(name: "seen-2", scope: !287, file: !116, line: 39, type: !10)
!300 = !DILocation(line: 39, column: 3, scope: !287)
!301 = !DILocation(line: 40, column: 13, scope: !287)
!302 = !DILocalVariable(name: "seen-3", scope: !287, file: !116, line: 40, type: !10)
!303 = !DILocation(line: 40, column: 3, scope: !287)
!304 = !DILocation(line: 41, column: 3, scope: !287)
!305 = !DILocation(line: 41, column: 3, scope: !287)
!306 = !DILocation(line: 41, column: 3, scope: !287)
!307 = !DILocation(line: 41, column: 3, scope: !287)
!308 = !{!107, !146, !10, !10}
!309 = !DISubroutineType(types: !308)
!310 = distinct !DISubprogram(name: "support.namespace-metadata.regular", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eregular.78", scope: !116, file: !116, line: 43, type: !309, scopeLine: 43, spFlags: DISPFlagDefinition, unit: !2)
!311 = !DILocalVariable(name: "region", arg: 1, scope: !310, file: !116, line: 43, type: !146)
!312 = !DILocation(line: 43, column: 17, scope: !310)
!313 = !DILocalVariable(name: "base", arg: 2, scope: !310, file: !116, line: 43, type: !10)
!314 = !DILocation(line: 43, column: 44, scope: !310)
!315 = !DILocalVariable(name: "identity", arg: 3, scope: !310, file: !116, line: 43, type: !10)
!316 = !DILocation(line: 43, column: 56, scope: !310)
!317 = !DILocation(line: 44, column: 25, scope: !310)
!318 = !DILocation(line: 44, column: 11, scope: !310)
!319 = !DILocalVariable(name: "mode", scope: !310, file: !116, line: 44, type: !10)
!320 = !DILocation(line: 44, column: 3, scope: !310)
!321 = !DILocation(line: 45, column: 10, scope: !310)
!322 = !DILocation(line: 45, column: 10, scope: !310)
!323 = !DILocation(line: 45, column: 10, scope: !310)
!324 = !DILocation(line: 45, column: 10, scope: !310)
!325 = !DILocation(line: 45, column: 51, scope: !310)
!326 = !DILocation(line: 45, column: 37, scope: !310)
!327 = !DILocation(line: 45, column: 37, scope: !310)
!328 = !DILocation(line: 45, column: 37, scope: !310)
!329 = !DILocation(line: 45, column: 37, scope: !310)
!330 = !DILocation(line: 45, column: 74, scope: !310)
!331 = !DILocation(line: 45, column: 74, scope: !310)
!332 = !DILocation(line: 45, column: 89, scope: !310)
!333 = !DILocation(line: 45, column: 89, scope: !310)
!334 = !DILocation(line: 45, column: 3, scope: !310)
!335 = !DILocation(line: 45, column: 3, scope: !310)
!336 = !{!10, !10}
!337 = !DISubroutineType(types: !336)
!338 = distinct !DISubprogram(name: "support.namespace-metadata.entry-base", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dbase.85", scope: !116, file: !116, line: 25, type: !337, scopeLine: 25, spFlags: DISPFlagDefinition, unit: !2)
!339 = !DILocalVariable(name: "slot", arg: 1, scope: !338, file: !116, line: 25, type: !10)
!340 = !DILocation(line: 25, column: 19, scope: !338)
!341 = !DILocation(line: 26, column: 9, scope: !338)
!342 = !DILocation(line: 26, column: 3, scope: !338)
!343 = !DILocation(line: 26, column: 3, scope: !338)
!344 = !{!107, !146, !10, !10}
!345 = !DISubroutineType(types: !344)
!346 = distinct !DISubprogram(name: "support.namespace-metadata.entry-names", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eentry_2dnames.94", scope: !116, file: !116, line: 47, type: !345, scopeLine: 47, spFlags: DISPFlagDefinition, unit: !2)
!347 = !DILocalVariable(name: "region", arg: 1, scope: !346, file: !116, line: 47, type: !146)
!348 = !DILocation(line: 47, column: 21, scope: !346)
!349 = !DILocalVariable(name: "slot", arg: 2, scope: !346, file: !116, line: 47, type: !10)
!350 = !DILocation(line: 47, column: 48, scope: !346)
!351 = !DILocalVariable(name: "identity", arg: 3, scope: !346, file: !116, line: 47, type: !10)
!352 = !DILocation(line: 47, column: 60, scope: !346)
!353 = !DILocation(line: 48, column: 11, scope: !346)
!354 = !DILocalVariable(name: "base", scope: !346, file: !116, line: 48, type: !10)
!355 = !DILocation(line: 48, column: 3, scope: !346)
!356 = !DILocation(line: 49, column: 27, scope: !346)
!357 = !DILocation(line: 49, column: 13, scope: !346)
!358 = !DILocalVariable(name: "length", scope: !346, file: !116, line: 49, type: !10)
!359 = !DILocation(line: 49, column: 3, scope: !346)
!360 = !DILocation(line: 50, column: 10, scope: !346)
!361 = !DILocation(line: 50, column: 10, scope: !346)
!362 = !DILocation(line: 50, column: 10, scope: !346)
!363 = !DILocation(line: 50, column: 10, scope: !346)
!364 = !DILocation(line: 50, column: 43, scope: !346)
!365 = !DILocation(line: 50, column: 43, scope: !346)
!366 = !DILocation(line: 50, column: 55, scope: !346)
!367 = !DILocation(line: 50, column: 55, scope: !346)
!368 = !DILocation(line: 50, column: 70, scope: !346)
!369 = !DILocation(line: 50, column: 70, scope: !346)
!370 = !DILocation(line: 50, column: 3, scope: !346)
!371 = !DILocation(line: 50, column: 3, scope: !346)
!372 = !{!107, !146, !182, !10}
!373 = !DISubroutineType(types: !372)
!374 = distinct !DISubprogram(name: "support.namespace-metadata.source-entry-valid", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dentry_2dvalid.96", scope: !116, file: !116, line: 52, type: !373, scopeLine: 52, spFlags: DISPFlagDefinition, unit: !2)
!375 = !DILocalVariable(name: "region", arg: 1, scope: !374, file: !116, line: 52, type: !146)
!376 = !DILocation(line: 52, column: 28, scope: !374)
!377 = !DILocation(line: 52, column: 55, scope: !374)
!378 = !DILocation(line: 52, column: 55, scope: !374)
!379 = !DILocation(line: 52, column: 55, scope: !374)
!380 = !DILocation(line: 52, column: 55, scope: !374)
!381 = !DILocation(line: 52, column: 55, scope: !374)
!382 = !DILocation(line: 52, column: 55, scope: !374)
!383 = !DILocation(line: 52, column: 55, scope: !374)
!384 = !DILocation(line: 52, column: 55, scope: !374)
!385 = !DILocation(line: 52, column: 55, scope: !374)
!386 = !DILocation(line: 52, column: 55, scope: !374)
!387 = !DILocation(line: 52, column: 55, scope: !374)
!388 = !DILocation(line: 52, column: 55, scope: !374)
!389 = !DILocation(line: 52, column: 55, scope: !374)
!390 = !DILocation(line: 52, column: 55, scope: !374)
!391 = !DILocation(line: 52, column: 55, scope: !374)
!392 = !DILocation(line: 52, column: 55, scope: !374)
!393 = !DILocalVariable(name: "facts", arg: 2, scope: !374, file: !116, line: 52, type: !182)
!394 = !DILocation(line: 52, column: 55, scope: !374)
!395 = !DILocalVariable(name: "operation", arg: 3, scope: !374, file: !116, line: 52, type: !10)
!396 = !DILocation(line: 52, column: 234, scope: !374)
!397 = !DILocation(line: 53, column: 4, scope: !374)
!398 = !DILocation(line: 53, column: 4, scope: !374)
!399 = !DILocation(line: 53, column: 4, scope: !374)
!400 = !DILocation(line: 54, column: 15, scope: !374)
!401 = !DILocation(line: 54, column: 15, scope: !374)
!402 = !DILocation(line: 55, column: 22, scope: !374)
!403 = !DILocation(line: 55, column: 22, scope: !374)
!404 = !DILocation(line: 55, column: 22, scope: !374)
!405 = !DILocation(line: 55, column: 38, scope: !374)
!406 = !DILocation(line: 55, column: 38, scope: !374)
!407 = !DILocation(line: 55, column: 38, scope: !374)
!408 = !DILocation(line: 55, column: 16, scope: !374)
!409 = !DILocation(line: 55, column: 16, scope: !374)
!410 = !DILocation(line: 53, column: 4, scope: !374)
!411 = !DILocation(line: 53, column: 4, scope: !374)
!412 = !{!107, !146, !182, !10}
!413 = !DISubroutineType(types: !412)
!414 = distinct !DISubprogram(name: "support.namespace-metadata.source-valid", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2esource_2dvalid.98", scope: !116, file: !116, line: 57, type: !413, scopeLine: 57, spFlags: DISPFlagDefinition, unit: !2)
!415 = !DILocalVariable(name: "region", arg: 1, scope: !414, file: !116, line: 57, type: !146)
!416 = !DILocation(line: 57, column: 22, scope: !414)
!417 = !DILocation(line: 57, column: 49, scope: !414)
!418 = !DILocation(line: 57, column: 49, scope: !414)
!419 = !DILocation(line: 57, column: 49, scope: !414)
!420 = !DILocation(line: 57, column: 49, scope: !414)
!421 = !DILocation(line: 57, column: 49, scope: !414)
!422 = !DILocation(line: 57, column: 49, scope: !414)
!423 = !DILocation(line: 57, column: 49, scope: !414)
!424 = !DILocation(line: 57, column: 49, scope: !414)
!425 = !DILocation(line: 57, column: 49, scope: !414)
!426 = !DILocation(line: 57, column: 49, scope: !414)
!427 = !DILocation(line: 57, column: 49, scope: !414)
!428 = !DILocation(line: 57, column: 49, scope: !414)
!429 = !DILocation(line: 57, column: 49, scope: !414)
!430 = !DILocation(line: 57, column: 49, scope: !414)
!431 = !DILocation(line: 57, column: 49, scope: !414)
!432 = !DILocation(line: 57, column: 49, scope: !414)
!433 = !DILocalVariable(name: "facts", arg: 2, scope: !414, file: !116, line: 57, type: !182)
!434 = !DILocation(line: 57, column: 49, scope: !414)
!435 = !DILocalVariable(name: "operation", arg: 3, scope: !414, file: !116, line: 57, type: !10)
!436 = !DILocation(line: 57, column: 228, scope: !414)
!437 = !DILocation(line: 58, column: 11, scope: !414)
!438 = !DILocalVariable(name: "base", scope: !414, file: !116, line: 58, type: !10)
!439 = !DILocation(line: 58, column: 3, scope: !414)
!440 = !DILocation(line: 59, column: 12, scope: !414)
!441 = !DILocalVariable(name: "count", scope: !414, file: !116, line: 59, type: !10)
!442 = !DILocation(line: 59, column: 3, scope: !414)
!443 = !DILocation(line: 60, column: 27, scope: !414)
!444 = !DILocation(line: 60, column: 13, scope: !414)
!445 = !DILocalVariable(name: "intent", scope: !414, file: !116, line: 60, type: !10)
!446 = !DILocation(line: 60, column: 3, scope: !414)
!447 = !DILocation(line: 61, column: 20, scope: !414)
!448 = !DILocation(line: 61, column: 20, scope: !414)
!449 = !DILocation(line: 61, column: 20, scope: !414)
!450 = !DILocation(line: 61, column: 31, scope: !414)
!451 = !DILocation(line: 61, column: 31, scope: !414)
!452 = !DILocation(line: 61, column: 31, scope: !414)
!453 = !DILocation(line: 61, column: 46, scope: !414)
!454 = !DILocation(line: 61, column: 46, scope: !414)
!455 = !DILocation(line: 61, column: 46, scope: !414)
!456 = !DILocation(line: 61, column: 59, scope: !414)
!457 = !DILocation(line: 61, column: 59, scope: !414)
!458 = !DILocation(line: 61, column: 59, scope: !414)
!459 = !DILocation(line: 61, column: 14, scope: !414)
!460 = !DILocalVariable(name: "initial", scope: !414, file: !116, line: 61, type: !107)
!461 = !DILocation(line: 61, column: 3, scope: !414)
!462 = !DILocation(line: 62, column: 19, scope: !414)
!463 = !DILocation(line: 62, column: 19, scope: !414)
!464 = !DILocation(line: 62, column: 30, scope: !414)
!465 = !DILocation(line: 62, column: 30, scope: !414)
!466 = !DILocation(line: 62, column: 30, scope: !414)
!467 = !DILocation(line: 62, column: 13, scope: !414)
!468 = !DILocalVariable(name: "linked", scope: !414, file: !116, line: 62, type: !107)
!469 = !DILocation(line: 62, column: 3, scope: !414)
!470 = !DILocation(line: 63, column: 26, scope: !414)
!471 = !DILocation(line: 63, column: 39, scope: !414)
!472 = !DILocation(line: 63, column: 20, scope: !414)
!473 = !DILocation(line: 63, column: 15, scope: !414)
!474 = !DILocalVariable(name: "eligible", scope: !414, file: !116, line: 63, type: !107)
!475 = !DILocation(line: 63, column: 3, scope: !414)
!476 = !DILocation(line: 64, column: 21, scope: !414)
!477 = !DILocation(line: 64, column: 70, scope: !414)
!478 = !DILocation(line: 64, column: 70, scope: !414)
!479 = !DILocation(line: 64, column: 70, scope: !414)
!480 = !DILocation(line: 64, column: 115, scope: !414)
!481 = !DILocation(line: 64, column: 101, scope: !414)
!482 = !DILocation(line: 64, column: 101, scope: !414)
!483 = !DILocation(line: 64, column: 101, scope: !414)
!484 = !DILocation(line: 64, column: 101, scope: !414)
!485 = !DILocation(line: 64, column: 15, scope: !414)
!486 = !DILocalVariable(name: "metadata", scope: !414, file: !116, line: 64, type: !107)
!487 = !DILocation(line: 64, column: 3, scope: !414)
!488 = !DILocation(line: 65, column: 19, scope: !414)
!489 = !DILocation(line: 65, column: 19, scope: !414)
!490 = !DILocation(line: 65, column: 19, scope: !414)
!491 = !DILocation(line: 65, column: 19, scope: !414)
!492 = !DILocation(line: 65, column: 19, scope: !414)
!493 = !DILocation(line: 65, column: 19, scope: !414)
!494 = !DILocation(line: 65, column: 19, scope: !414)
!495 = !DILocation(line: 65, column: 19, scope: !414)
!496 = !DILocation(line: 65, column: 19, scope: !414)
!497 = !DILocation(line: 65, column: 19, scope: !414)
!498 = !DILocation(line: 65, column: 19, scope: !414)
!499 = !DILocation(line: 65, column: 19, scope: !414)
!500 = !DILocation(line: 65, column: 19, scope: !414)
!501 = !DILocation(line: 65, column: 19, scope: !414)
!502 = !DILocation(line: 65, column: 19, scope: !414)
!503 = !DILocation(line: 65, column: 19, scope: !414)
!504 = !DILocation(line: 65, column: 19, scope: !414)
!505 = !DILocation(line: 65, column: 3, scope: !414)
!506 = !DILocation(line: 65, column: 3, scope: !414)
!507 = !{!10, !10}
!508 = !DISubroutineType(types: !507)
!509 = distinct !DISubprogram(name: "support.namespace-metadata.name-base", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ename_2dbase.100", scope: !116, file: !116, line: 28, type: !508, scopeLine: 28, spFlags: DISPFlagDefinition, unit: !2)
!510 = !DILocalVariable(name: "slot", arg: 1, scope: !509, file: !116, line: 28, type: !10)
!511 = !DILocation(line: 28, column: 18, scope: !509)
!512 = !DILocation(line: 29, column: 11, scope: !509)
!513 = !DILocation(line: 29, column: 3, scope: !509)
!514 = !DILocation(line: 29, column: 3, scope: !509)
!515 = !{!107, !146, !10}
!516 = !DISubroutineType(types: !515)
!517 = distinct !DISubprogram(name: "support.namespace-bytes.zero-word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dword.102", scope: !115, file: !115, line: 164, type: !516, scopeLine: 164, spFlags: DISPFlagDefinition, unit: !2)
!518 = !DILocalVariable(name: "region", arg: 1, scope: !517, file: !115, line: 164, type: !146)
!519 = !DILocation(line: 164, column: 19, scope: !517)
!520 = !DILocalVariable(name: "offset", arg: 2, scope: !517, file: !115, line: 164, type: !10)
!521 = !DILocation(line: 164, column: 46, scope: !517)
!522 = !DILocation(line: 165, column: 12, scope: !517)
!523 = !DILocalVariable(name: "value", scope: !517, file: !115, line: 165, type: !10)
!524 = !DILocation(line: 165, column: 3, scope: !517)
!525 = !DILocation(line: 166, column: 3, scope: !517)
!526 = !DILocation(line: 166, column: 3, scope: !517)
!527 = !DILocation(line: 166, column: 3, scope: !517)
!528 = !DILocation(line: 166, column: 3, scope: !517)
!529 = !{!107, !146, !10}
!530 = !DISubroutineType(types: !529)
!531 = distinct !DISubprogram(name: "support.namespace-bytes.zero-pair", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dpair.105", scope: !115, file: !115, line: 178, type: !530, scopeLine: 178, spFlags: DISPFlagDefinition, unit: !2)
!532 = !DILocalVariable(name: "region", arg: 1, scope: !531, file: !115, line: 178, type: !146)
!533 = !DILocation(line: 178, column: 19, scope: !531)
!534 = !DILocalVariable(name: "offset", arg: 2, scope: !531, file: !115, line: 178, type: !10)
!535 = !DILocation(line: 178, column: 46, scope: !531)
!536 = !DILocation(line: 179, column: 3, scope: !531)
!537 = !DILocation(line: 179, column: 3, scope: !531)
!538 = !DILocation(line: 180, column: 34, scope: !531)
!539 = !DILocation(line: 180, column: 15, scope: !531)
!540 = !DILocation(line: 180, column: 15, scope: !531)
!541 = !DILocation(line: 181, column: 16, scope: !531)
!542 = !DILocation(line: 179, column: 3, scope: !531)
!543 = !DILocation(line: 179, column: 3, scope: !531)
!544 = !{!107, !146, !10}
!545 = !DISubroutineType(types: !544)
!546 = distinct !DISubprogram(name: "support.namespace-bytes.zero-block", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dblock.111", scope: !115, file: !115, line: 193, type: !545, scopeLine: 193, spFlags: DISPFlagDefinition, unit: !2)
!547 = !DILocalVariable(name: "region", arg: 1, scope: !546, file: !115, line: 193, type: !146)
!548 = !DILocation(line: 193, column: 20, scope: !546)
!549 = !DILocalVariable(name: "offset", arg: 2, scope: !546, file: !115, line: 193, type: !10)
!550 = !DILocation(line: 193, column: 47, scope: !546)
!551 = !DILocation(line: 194, column: 3, scope: !546)
!552 = !DILocation(line: 194, column: 3, scope: !546)
!553 = !DILocation(line: 195, column: 34, scope: !546)
!554 = !DILocation(line: 195, column: 15, scope: !546)
!555 = !DILocation(line: 195, column: 15, scope: !546)
!556 = !DILocation(line: 196, column: 16, scope: !546)
!557 = !DILocation(line: 194, column: 3, scope: !546)
!558 = !DILocation(line: 194, column: 3, scope: !546)
!559 = !{!107, !146, !10}
!560 = !DISubroutineType(types: !559)
!561 = distinct !DISubprogram(name: "support.namespace-bytes.zero-quarter", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dquarter.123", scope: !115, file: !115, line: 208, type: !560, scopeLine: 208, spFlags: DISPFlagDefinition, unit: !2)
!562 = !DILocalVariable(name: "region", arg: 1, scope: !561, file: !115, line: 208, type: !146)
!563 = !DILocation(line: 208, column: 26, scope: !561)
!564 = !DILocalVariable(name: "offset", arg: 2, scope: !561, file: !115, line: 208, type: !10)
!565 = !DILocation(line: 208, column: 53, scope: !561)
!566 = !DILocation(line: 209, column: 3, scope: !561)
!567 = !DILocation(line: 209, column: 3, scope: !561)
!568 = !DILocation(line: 210, column: 35, scope: !561)
!569 = !DILocation(line: 210, column: 15, scope: !561)
!570 = !DILocation(line: 210, column: 15, scope: !561)
!571 = !DILocation(line: 211, column: 16, scope: !561)
!572 = !DILocation(line: 209, column: 3, scope: !561)
!573 = !DILocation(line: 209, column: 3, scope: !561)
!574 = !{!107, !146, !10}
!575 = !DISubroutineType(types: !574)
!576 = distinct !DISubprogram(name: "support.namespace-bytes.zero-half", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dhalf.147", scope: !115, file: !115, line: 223, type: !575, scopeLine: 223, spFlags: DISPFlagDefinition, unit: !2)
!577 = !DILocalVariable(name: "region", arg: 1, scope: !576, file: !115, line: 223, type: !146)
!578 = !DILocation(line: 223, column: 23, scope: !576)
!579 = !DILocalVariable(name: "offset", arg: 2, scope: !576, file: !115, line: 223, type: !10)
!580 = !DILocation(line: 223, column: 50, scope: !576)
!581 = !DILocation(line: 224, column: 3, scope: !576)
!582 = !DILocation(line: 224, column: 3, scope: !576)
!583 = !DILocation(line: 225, column: 37, scope: !576)
!584 = !DILocation(line: 225, column: 15, scope: !576)
!585 = !DILocation(line: 225, column: 15, scope: !576)
!586 = !DILocation(line: 226, column: 16, scope: !576)
!587 = !DILocation(line: 224, column: 3, scope: !576)
!588 = !DILocation(line: 224, column: 3, scope: !576)
!589 = !{!107, !146, !10}
!590 = !DISubroutineType(types: !589)
!591 = distinct !DISubprogram(name: "support.namespace-bytes.zero-name", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ezero_2dname.195", scope: !115, file: !115, line: 238, type: !590, scopeLine: 238, spFlags: DISPFlagDefinition, unit: !2)
!592 = !DILocalVariable(name: "region", arg: 1, scope: !591, file: !115, line: 238, type: !146)
!593 = !DILocation(line: 238, column: 23, scope: !591)
!594 = !DILocalVariable(name: "offset", arg: 2, scope: !591, file: !115, line: 238, type: !10)
!595 = !DILocation(line: 238, column: 50, scope: !591)
!596 = !DILocation(line: 239, column: 3, scope: !591)
!597 = !DILocation(line: 239, column: 3, scope: !591)
!598 = !DILocation(line: 240, column: 34, scope: !591)
!599 = !DILocation(line: 240, column: 15, scope: !591)
!600 = !DILocation(line: 240, column: 15, scope: !591)
!601 = !DILocation(line: 241, column: 16, scope: !591)
!602 = !DILocation(line: 239, column: 3, scope: !591)
!603 = !DILocation(line: 239, column: 3, scope: !591)
!604 = !{!107, !146, !182}
!605 = !DISubroutineType(types: !604)
!606 = distinct !DISubprogram(name: "support.namespace-metadata.empty-target", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eempty_2dtarget.204", scope: !116, file: !116, line: 67, type: !605, scopeLine: 67, spFlags: DISPFlagDefinition, unit: !2)
!607 = !DILocalVariable(name: "region", arg: 1, scope: !606, file: !116, line: 67, type: !146)
!608 = !DILocation(line: 67, column: 22, scope: !606)
!609 = !DILocation(line: 67, column: 49, scope: !606)
!610 = !DILocation(line: 67, column: 49, scope: !606)
!611 = !DILocation(line: 67, column: 49, scope: !606)
!612 = !DILocation(line: 67, column: 49, scope: !606)
!613 = !DILocation(line: 67, column: 49, scope: !606)
!614 = !DILocation(line: 67, column: 49, scope: !606)
!615 = !DILocation(line: 67, column: 49, scope: !606)
!616 = !DILocation(line: 67, column: 49, scope: !606)
!617 = !DILocation(line: 67, column: 49, scope: !606)
!618 = !DILocation(line: 67, column: 49, scope: !606)
!619 = !DILocation(line: 67, column: 49, scope: !606)
!620 = !DILocation(line: 67, column: 49, scope: !606)
!621 = !DILocation(line: 67, column: 49, scope: !606)
!622 = !DILocation(line: 67, column: 49, scope: !606)
!623 = !DILocation(line: 67, column: 49, scope: !606)
!624 = !DILocation(line: 67, column: 49, scope: !606)
!625 = !DILocalVariable(name: "facts", arg: 2, scope: !606, file: !116, line: 67, type: !182)
!626 = !DILocation(line: 67, column: 49, scope: !606)
!627 = !DILocation(line: 68, column: 11, scope: !606)
!628 = !DILocalVariable(name: "base", scope: !606, file: !116, line: 68, type: !10)
!629 = !DILocation(line: 68, column: 3, scope: !606)
!630 = !DILocation(line: 69, column: 55, scope: !606)
!631 = !DILocation(line: 69, column: 12, scope: !606)
!632 = !DILocalVariable(name: "clean", scope: !606, file: !116, line: 69, type: !107)
!633 = !DILocation(line: 69, column: 3, scope: !606)
!634 = !DILocation(line: 70, column: 10, scope: !606)
!635 = !DILocation(line: 70, column: 10, scope: !606)
!636 = !DILocation(line: 70, column: 10, scope: !606)
!637 = !DILocation(line: 70, column: 10, scope: !606)
!638 = !DILocation(line: 70, column: 51, scope: !606)
!639 = !DILocation(line: 70, column: 37, scope: !606)
!640 = !DILocation(line: 70, column: 37, scope: !606)
!641 = !DILocation(line: 70, column: 37, scope: !606)
!642 = !DILocation(line: 70, column: 37, scope: !606)
!643 = !DILocation(line: 70, column: 75, scope: !606)
!644 = !DILocation(line: 70, column: 75, scope: !606)
!645 = !DILocation(line: 70, column: 3, scope: !606)
!646 = !DILocation(line: 70, column: 3, scope: !606)
!647 = !{!107, !146, !182}
!648 = !DISubroutineType(types: !647)
!649 = distinct !DISubprogram(name: "support.namespace-metadata.live-target", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elive_2dtarget.257", scope: !116, file: !116, line: 72, type: !648, scopeLine: 72, spFlags: DISPFlagDefinition, unit: !2)
!650 = !DILocalVariable(name: "region", arg: 1, scope: !649, file: !116, line: 72, type: !146)
!651 = !DILocation(line: 72, column: 21, scope: !649)
!652 = !DILocation(line: 72, column: 48, scope: !649)
!653 = !DILocation(line: 72, column: 48, scope: !649)
!654 = !DILocation(line: 72, column: 48, scope: !649)
!655 = !DILocation(line: 72, column: 48, scope: !649)
!656 = !DILocation(line: 72, column: 48, scope: !649)
!657 = !DILocation(line: 72, column: 48, scope: !649)
!658 = !DILocation(line: 72, column: 48, scope: !649)
!659 = !DILocation(line: 72, column: 48, scope: !649)
!660 = !DILocation(line: 72, column: 48, scope: !649)
!661 = !DILocation(line: 72, column: 48, scope: !649)
!662 = !DILocation(line: 72, column: 48, scope: !649)
!663 = !DILocation(line: 72, column: 48, scope: !649)
!664 = !DILocation(line: 72, column: 48, scope: !649)
!665 = !DILocation(line: 72, column: 48, scope: !649)
!666 = !DILocation(line: 72, column: 48, scope: !649)
!667 = !DILocation(line: 72, column: 48, scope: !649)
!668 = !DILocalVariable(name: "facts", arg: 2, scope: !649, file: !116, line: 72, type: !182)
!669 = !DILocation(line: 72, column: 48, scope: !649)
!670 = !DILocation(line: 73, column: 11, scope: !649)
!671 = !DILocalVariable(name: "base", scope: !649, file: !116, line: 73, type: !10)
!672 = !DILocation(line: 73, column: 3, scope: !649)
!673 = !DILocation(line: 74, column: 12, scope: !649)
!674 = !DILocalVariable(name: "count", scope: !649, file: !116, line: 74, type: !10)
!675 = !DILocation(line: 74, column: 3, scope: !649)
!676 = !DILocation(line: 75, column: 21, scope: !649)
!677 = !DILocation(line: 75, column: 70, scope: !649)
!678 = !DILocation(line: 75, column: 70, scope: !649)
!679 = !DILocation(line: 75, column: 96, scope: !649)
!680 = !DILocation(line: 75, column: 82, scope: !649)
!681 = !DILocation(line: 75, column: 82, scope: !649)
!682 = !DILocation(line: 75, column: 82, scope: !649)
!683 = !DILocation(line: 75, column: 82, scope: !649)
!684 = !DILocation(line: 75, column: 132, scope: !649)
!685 = !DILocation(line: 75, column: 118, scope: !649)
!686 = !DILocation(line: 75, column: 118, scope: !649)
!687 = !DILocation(line: 75, column: 118, scope: !649)
!688 = !DILocation(line: 75, column: 118, scope: !649)
!689 = !DILocation(line: 75, column: 15, scope: !649)
!690 = !DILocalVariable(name: "metadata", scope: !649, file: !116, line: 75, type: !107)
!691 = !DILocation(line: 75, column: 3, scope: !649)
!692 = !DILocation(line: 76, column: 12, scope: !649)
!693 = !DILocalVariable(name: "entry", scope: !649, file: !116, line: 76, type: !107)
!694 = !DILocation(line: 76, column: 3, scope: !649)
!695 = !DILocation(line: 77, column: 3, scope: !649)
!696 = !DILocation(line: 77, column: 3, scope: !649)
!697 = !{!107, !146, !182, !10}
!698 = !DISubroutineType(types: !697)
!699 = distinct !DISubprogram(name: "support.namespace-metadata.target-move-or-live", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dmove_2dor_2dlive.258", scope: !116, file: !116, line: 79, type: !698, scopeLine: 79, spFlags: DISPFlagDefinition, unit: !2)
!700 = !DILocalVariable(name: "region", arg: 1, scope: !699, file: !116, line: 79, type: !146)
!701 = !DILocation(line: 79, column: 29, scope: !699)
!702 = !DILocation(line: 79, column: 56, scope: !699)
!703 = !DILocation(line: 79, column: 56, scope: !699)
!704 = !DILocation(line: 79, column: 56, scope: !699)
!705 = !DILocation(line: 79, column: 56, scope: !699)
!706 = !DILocation(line: 79, column: 56, scope: !699)
!707 = !DILocation(line: 79, column: 56, scope: !699)
!708 = !DILocation(line: 79, column: 56, scope: !699)
!709 = !DILocation(line: 79, column: 56, scope: !699)
!710 = !DILocation(line: 79, column: 56, scope: !699)
!711 = !DILocation(line: 79, column: 56, scope: !699)
!712 = !DILocation(line: 79, column: 56, scope: !699)
!713 = !DILocation(line: 79, column: 56, scope: !699)
!714 = !DILocation(line: 79, column: 56, scope: !699)
!715 = !DILocation(line: 79, column: 56, scope: !699)
!716 = !DILocation(line: 79, column: 56, scope: !699)
!717 = !DILocation(line: 79, column: 56, scope: !699)
!718 = !DILocalVariable(name: "facts", arg: 2, scope: !699, file: !116, line: 79, type: !182)
!719 = !DILocation(line: 79, column: 56, scope: !699)
!720 = !DILocalVariable(name: "operation", arg: 3, scope: !699, file: !116, line: 79, type: !10)
!721 = !DILocation(line: 79, column: 235, scope: !699)
!722 = !DILocation(line: 80, column: 3, scope: !699)
!723 = !DILocation(line: 80, column: 3, scope: !699)
!724 = !DILocation(line: 80, column: 3, scope: !699)
!725 = !DILocation(line: 80, column: 3, scope: !699)
!726 = !DILocation(line: 81, column: 16, scope: !699)
!727 = !DILocation(line: 81, column: 16, scope: !699)
!728 = !DILocation(line: 81, column: 16, scope: !699)
!729 = !DILocation(line: 81, column: 16, scope: !699)
!730 = !DILocation(line: 82, column: 16, scope: !699)
!731 = !DILocation(line: 82, column: 16, scope: !699)
!732 = !DILocation(line: 82, column: 16, scope: !699)
!733 = !DILocation(line: 82, column: 16, scope: !699)
!734 = !DILocation(line: 82, column: 16, scope: !699)
!735 = !DILocation(line: 82, column: 16, scope: !699)
!736 = !DILocation(line: 82, column: 16, scope: !699)
!737 = !DILocation(line: 82, column: 16, scope: !699)
!738 = !DILocation(line: 82, column: 16, scope: !699)
!739 = !DILocation(line: 82, column: 16, scope: !699)
!740 = !DILocation(line: 82, column: 16, scope: !699)
!741 = !DILocation(line: 82, column: 16, scope: !699)
!742 = !DILocation(line: 82, column: 16, scope: !699)
!743 = !DILocation(line: 82, column: 16, scope: !699)
!744 = !DILocation(line: 82, column: 16, scope: !699)
!745 = !DILocation(line: 82, column: 16, scope: !699)
!746 = !DILocation(line: 82, column: 16, scope: !699)
!747 = !DILocation(line: 82, column: 16, scope: !699)
!748 = !DILocation(line: 80, column: 3, scope: !699)
!749 = !DILocation(line: 80, column: 3, scope: !699)
!750 = !{!107, !146, !182, !10}
!751 = !DISubroutineType(types: !750)
!752 = distinct !DISubprogram(name: "support.namespace-metadata.target-valid", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2etarget_2dvalid.259", scope: !116, file: !116, line: 84, type: !751, scopeLine: 84, spFlags: DISPFlagDefinition, unit: !2)
!753 = !DILocalVariable(name: "region", arg: 1, scope: !752, file: !116, line: 84, type: !146)
!754 = !DILocation(line: 84, column: 22, scope: !752)
!755 = !DILocation(line: 84, column: 49, scope: !752)
!756 = !DILocation(line: 84, column: 49, scope: !752)
!757 = !DILocation(line: 84, column: 49, scope: !752)
!758 = !DILocation(line: 84, column: 49, scope: !752)
!759 = !DILocation(line: 84, column: 49, scope: !752)
!760 = !DILocation(line: 84, column: 49, scope: !752)
!761 = !DILocation(line: 84, column: 49, scope: !752)
!762 = !DILocation(line: 84, column: 49, scope: !752)
!763 = !DILocation(line: 84, column: 49, scope: !752)
!764 = !DILocation(line: 84, column: 49, scope: !752)
!765 = !DILocation(line: 84, column: 49, scope: !752)
!766 = !DILocation(line: 84, column: 49, scope: !752)
!767 = !DILocation(line: 84, column: 49, scope: !752)
!768 = !DILocation(line: 84, column: 49, scope: !752)
!769 = !DILocation(line: 84, column: 49, scope: !752)
!770 = !DILocation(line: 84, column: 49, scope: !752)
!771 = !DILocalVariable(name: "facts", arg: 2, scope: !752, file: !116, line: 84, type: !182)
!772 = !DILocation(line: 84, column: 49, scope: !752)
!773 = !DILocalVariable(name: "operation", arg: 3, scope: !752, file: !116, line: 84, type: !10)
!774 = !DILocation(line: 84, column: 228, scope: !752)
!775 = !DILocation(line: 85, column: 3, scope: !752)
!776 = !DILocation(line: 85, column: 3, scope: !752)
!777 = !DILocation(line: 85, column: 3, scope: !752)
!778 = !DILocation(line: 85, column: 3, scope: !752)
!779 = !DILocation(line: 86, column: 15, scope: !752)
!780 = !DILocation(line: 86, column: 15, scope: !752)
!781 = !DILocation(line: 86, column: 15, scope: !752)
!782 = !DILocation(line: 86, column: 15, scope: !752)
!783 = !DILocation(line: 86, column: 15, scope: !752)
!784 = !DILocation(line: 86, column: 15, scope: !752)
!785 = !DILocation(line: 86, column: 15, scope: !752)
!786 = !DILocation(line: 86, column: 15, scope: !752)
!787 = !DILocation(line: 86, column: 15, scope: !752)
!788 = !DILocation(line: 86, column: 15, scope: !752)
!789 = !DILocation(line: 86, column: 15, scope: !752)
!790 = !DILocation(line: 86, column: 15, scope: !752)
!791 = !DILocation(line: 86, column: 15, scope: !752)
!792 = !DILocation(line: 86, column: 15, scope: !752)
!793 = !DILocation(line: 86, column: 15, scope: !752)
!794 = !DILocation(line: 86, column: 15, scope: !752)
!795 = !DILocation(line: 86, column: 15, scope: !752)
!796 = !DILocation(line: 86, column: 15, scope: !752)
!797 = !DILocation(line: 87, column: 16, scope: !752)
!798 = !DILocation(line: 87, column: 16, scope: !752)
!799 = !DILocation(line: 87, column: 16, scope: !752)
!800 = !DILocation(line: 87, column: 16, scope: !752)
!801 = !DILocation(line: 87, column: 16, scope: !752)
!802 = !DILocation(line: 87, column: 16, scope: !752)
!803 = !DILocation(line: 87, column: 16, scope: !752)
!804 = !DILocation(line: 87, column: 16, scope: !752)
!805 = !DILocation(line: 87, column: 16, scope: !752)
!806 = !DILocation(line: 87, column: 16, scope: !752)
!807 = !DILocation(line: 87, column: 16, scope: !752)
!808 = !DILocation(line: 87, column: 16, scope: !752)
!809 = !DILocation(line: 87, column: 16, scope: !752)
!810 = !DILocation(line: 87, column: 16, scope: !752)
!811 = !DILocation(line: 87, column: 16, scope: !752)
!812 = !DILocation(line: 87, column: 16, scope: !752)
!813 = !DILocation(line: 87, column: 16, scope: !752)
!814 = !DILocation(line: 87, column: 16, scope: !752)
!815 = !DILocation(line: 85, column: 3, scope: !752)
!816 = !DILocation(line: 85, column: 3, scope: !752)
!817 = !{!10, !146, !10}
!818 = !DISubroutineType(types: !817)
!819 = distinct !DISubprogram(name: "support.namespace-bytes.input-byte", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2einput_2dbyte.330", scope: !115, file: !115, line: 8, type: !818, scopeLine: 8, spFlags: DISPFlagDefinition, unit: !2)
!820 = !DILocalVariable(name: "region", arg: 1, scope: !819, file: !115, line: 8, type: !146)
!821 = !DILocation(line: 8, column: 20, scope: !819)
!822 = !DILocalVariable(name: "index", arg: 2, scope: !819, file: !115, line: 8, type: !10)
!823 = !DILocation(line: 8, column: 47, scope: !819)
!824 = !DILocation(line: 9, column: 13, scope: !819)
!825 = !DILocalVariable(name: "offset", scope: !819, file: !115, line: 9, type: !10)
!826 = !DILocation(line: 9, column: 3, scope: !819)
!827 = !DILocation(line: 10, column: 3, scope: !819)
!828 = !DILocation(line: 10, column: 3, scope: !819)
!829 = !DILocation(line: 10, column: 3, scope: !819)
!830 = !DILocation(line: 11, column: 10, scope: !819)
!831 = !DILocalVariable(name: "value", scope: !819, file: !115, line: 11, type: !10)
!832 = !DILocation(line: 11, column: 10, scope: !819)
!833 = !DILocation(line: 11, column: 21, scope: !819)
!834 = !DILocation(line: 12, column: 15, scope: !819)
!835 = !DILocation(line: 10, column: 3, scope: !819)
!836 = !DILocation(line: 10, column: 3, scope: !819)
!837 = !{!107, !107, !107}
!838 = !DISubroutineType(types: !837)
!839 = distinct !DISubprogram(name: "support.namespace-bytes.both", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eboth.332", scope: !115, file: !115, line: 15, type: !838, scopeLine: 15, spFlags: DISPFlagDefinition, unit: !2)
!840 = !DILocalVariable(name: "first", arg: 1, scope: !839, file: !115, line: 15, type: !107)
!841 = !DILocation(line: 15, column: 14, scope: !839)
!842 = !DILocalVariable(name: "second", arg: 2, scope: !839, file: !115, line: 15, type: !107)
!843 = !DILocation(line: 15, column: 31, scope: !839)
!844 = !DILocation(line: 16, column: 3, scope: !839)
!845 = !DILocation(line: 17, column: 15, scope: !839)
!846 = !DILocation(line: 18, column: 16, scope: !839)
!847 = !DILocation(line: 16, column: 3, scope: !839)
!848 = !DILocation(line: 16, column: 3, scope: !839)
!849 = !{!107, !146, !10}
!850 = !DISubroutineType(types: !849)
!851 = distinct !DISubprogram(name: "support.namespace-bytes.not-dot", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2enot_2ddot.335", scope: !115, file: !115, line: 128, type: !850, scopeLine: 128, spFlags: DISPFlagDefinition, unit: !2)
!852 = !DILocalVariable(name: "region", arg: 1, scope: !851, file: !115, line: 128, type: !146)
!853 = !DILocation(line: 128, column: 17, scope: !851)
!854 = !DILocalVariable(name: "length", arg: 2, scope: !851, file: !115, line: 128, type: !10)
!855 = !DILocation(line: 128, column: 44, scope: !851)
!856 = !DILocation(line: 129, column: 12, scope: !851)
!857 = !DILocalVariable(name: "first", scope: !851, file: !115, line: 129, type: !10)
!858 = !DILocation(line: 129, column: 3, scope: !851)
!859 = !DILocation(line: 130, column: 13, scope: !851)
!860 = !DILocalVariable(name: "second", scope: !851, file: !115, line: 130, type: !10)
!861 = !DILocation(line: 130, column: 3, scope: !851)
!862 = !DILocation(line: 131, column: 10, scope: !851)
!863 = !DILocation(line: 131, column: 10, scope: !851)
!864 = !DILocation(line: 131, column: 10, scope: !851)
!865 = !DILocalVariable(name: "one", scope: !851, file: !115, line: 131, type: !107)
!866 = !DILocation(line: 131, column: 3, scope: !851)
!867 = !DILocation(line: 132, column: 10, scope: !851)
!868 = !DILocation(line: 132, column: 10, scope: !851)
!869 = !DILocation(line: 132, column: 10, scope: !851)
!870 = !DILocalVariable(name: "two", scope: !851, file: !115, line: 132, type: !107)
!871 = !DILocation(line: 132, column: 3, scope: !851)
!872 = !DILocation(line: 133, column: 16, scope: !851)
!873 = !DILocation(line: 133, column: 16, scope: !851)
!874 = !DILocation(line: 133, column: 16, scope: !851)
!875 = !DILocalVariable(name: "first-dot", scope: !851, file: !115, line: 133, type: !107)
!876 = !DILocation(line: 133, column: 3, scope: !851)
!877 = !DILocation(line: 134, column: 17, scope: !851)
!878 = !DILocation(line: 134, column: 17, scope: !851)
!879 = !DILocation(line: 134, column: 17, scope: !851)
!880 = !DILocalVariable(name: "second-dot", scope: !851, file: !115, line: 134, type: !107)
!881 = !DILocation(line: 134, column: 3, scope: !851)
!882 = !DILocation(line: 135, column: 17, scope: !851)
!883 = !DILocalVariable(name: "bad-single", scope: !851, file: !115, line: 135, type: !107)
!884 = !DILocation(line: 135, column: 3, scope: !851)
!885 = !DILocation(line: 136, column: 26, scope: !851)
!886 = !DILocation(line: 136, column: 15, scope: !851)
!887 = !DILocalVariable(name: "bad-pair", scope: !851, file: !115, line: 136, type: !107)
!888 = !DILocation(line: 136, column: 3, scope: !851)
!889 = !DILocation(line: 137, column: 3, scope: !851)
!890 = !DILocation(line: 138, column: 15, scope: !851)
!891 = !DILocation(line: 139, column: 16, scope: !851)
!892 = !DILocation(line: 139, column: 16, scope: !851)
!893 = !DILocation(line: 137, column: 3, scope: !851)
!894 = !DILocation(line: 137, column: 3, scope: !851)
!895 = !{!107, !10}
!896 = !DISubroutineType(types: !895)
!897 = distinct !DISubprogram(name: "support.namespace-bytes.character", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2echaracter.338", scope: !115, file: !115, line: 20, type: !896, scopeLine: 20, spFlags: DISPFlagDefinition, unit: !2)
!898 = !DILocalVariable(name: "value", arg: 1, scope: !897, file: !115, line: 20, type: !10)
!899 = !DILocation(line: 20, column: 18, scope: !897)
!900 = !DILocation(line: 21, column: 15, scope: !897)
!901 = !DILocation(line: 21, column: 15, scope: !897)
!902 = !DILocalVariable(name: "positive", scope: !897, file: !115, line: 21, type: !107)
!903 = !DILocation(line: 21, column: 3, scope: !897)
!904 = !DILocation(line: 22, column: 14, scope: !897)
!905 = !DILocation(line: 22, column: 14, scope: !897)
!906 = !DILocalVariable(name: "bounded", scope: !897, file: !115, line: 22, type: !107)
!907 = !DILocation(line: 22, column: 3, scope: !897)
!908 = !DILocation(line: 23, column: 13, scope: !897)
!909 = !DILocation(line: 23, column: 13, scope: !897)
!910 = !DILocation(line: 23, column: 13, scope: !897)
!911 = !DILocalVariable(name: "normal", scope: !897, file: !115, line: 23, type: !107)
!912 = !DILocation(line: 23, column: 3, scope: !897)
!913 = !DILocation(line: 24, column: 19, scope: !897)
!914 = !DILocation(line: 24, column: 3, scope: !897)
!915 = !DILocation(line: 24, column: 3, scope: !897)
!916 = !{!107, !10, !10, !10}
!917 = !DISubroutineType(types: !916)
!918 = distinct !DISubprogram(name: "support.namespace-bytes.valid-value", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dvalue.339", scope: !115, file: !115, line: 26, type: !917, scopeLine: 26, spFlags: DISPFlagDefinition, unit: !2)
!919 = !DILocalVariable(name: "value", arg: 1, scope: !918, file: !115, line: 26, type: !10)
!920 = !DILocation(line: 26, column: 21, scope: !918)
!921 = !DILocalVariable(name: "index", arg: 2, scope: !918, file: !115, line: 26, type: !10)
!922 = !DILocation(line: 26, column: 34, scope: !918)
!923 = !DILocalVariable(name: "length", arg: 3, scope: !918, file: !115, line: 26, type: !10)
!924 = !DILocation(line: 26, column: 47, scope: !918)
!925 = !DILocation(line: 27, column: 3, scope: !918)
!926 = !DILocation(line: 27, column: 3, scope: !918)
!927 = !DILocation(line: 27, column: 3, scope: !918)
!928 = !DILocation(line: 28, column: 15, scope: !918)
!929 = !DILocation(line: 28, column: 15, scope: !918)
!930 = !DILocation(line: 29, column: 16, scope: !918)
!931 = !DILocation(line: 29, column: 16, scope: !918)
!932 = !DILocation(line: 29, column: 16, scope: !918)
!933 = !DILocation(line: 29, column: 16, scope: !918)
!934 = !DILocation(line: 27, column: 3, scope: !918)
!935 = !DILocation(line: 27, column: 3, scope: !918)
!936 = !{!107, !146, !10, !10, !10}
!937 = !DISubroutineType(types: !936)
!938 = distinct !DISubprogram(name: "support.namespace-bytes.valid-byte", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbyte.340", scope: !115, file: !115, line: 31, type: !937, scopeLine: 31, spFlags: DISPFlagDefinition, unit: !2)
!939 = !DILocalVariable(name: "region", arg: 1, scope: !938, file: !115, line: 31, type: !146)
!940 = !DILocation(line: 31, column: 20, scope: !938)
!941 = !DILocalVariable(name: "offset", arg: 2, scope: !938, file: !115, line: 31, type: !10)
!942 = !DILocation(line: 31, column: 47, scope: !938)
!943 = !DILocalVariable(name: "index", arg: 3, scope: !938, file: !115, line: 31, type: !10)
!944 = !DILocation(line: 31, column: 61, scope: !938)
!945 = !DILocalVariable(name: "length", arg: 4, scope: !938, file: !115, line: 31, type: !10)
!946 = !DILocation(line: 31, column: 74, scope: !938)
!947 = !DILocation(line: 32, column: 3, scope: !938)
!948 = !DILocation(line: 32, column: 3, scope: !938)
!949 = !DILocation(line: 32, column: 3, scope: !938)
!950 = !DILocation(line: 33, column: 10, scope: !938)
!951 = !DILocalVariable(name: "value", scope: !938, file: !115, line: 33, type: !10)
!952 = !DILocation(line: 33, column: 10, scope: !938)
!953 = !DILocation(line: 33, column: 21, scope: !938)
!954 = !DILocation(line: 33, column: 21, scope: !938)
!955 = !DILocation(line: 34, column: 15, scope: !938)
!956 = !DILocation(line: 32, column: 3, scope: !938)
!957 = !DILocation(line: 32, column: 3, scope: !938)
!958 = !{!107, !107, !107, !107, !107}
!959 = !DISubroutineType(types: !958)
!960 = distinct !DISubprogram(name: "support.namespace-bytes.all-four", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eall_2dfour.359", scope: !115, file: !115, line: 36, type: !959, scopeLine: 36, spFlags: DISPFlagDefinition, unit: !2)
!961 = !DILocalVariable(name: "first", arg: 1, scope: !960, file: !115, line: 36, type: !107)
!962 = !DILocation(line: 36, column: 18, scope: !960)
!963 = !DILocalVariable(name: "second", arg: 2, scope: !960, file: !115, line: 36, type: !107)
!964 = !DILocation(line: 36, column: 35, scope: !960)
!965 = !DILocalVariable(name: "third", arg: 3, scope: !960, file: !115, line: 36, type: !107)
!966 = !DILocation(line: 36, column: 53, scope: !960)
!967 = !DILocalVariable(name: "fourth", arg: 4, scope: !960, file: !115, line: 36, type: !107)
!968 = !DILocation(line: 36, column: 70, scope: !960)
!969 = !DILocation(line: 37, column: 11, scope: !960)
!970 = !DILocalVariable(name: "left", scope: !960, file: !115, line: 37, type: !107)
!971 = !DILocation(line: 37, column: 3, scope: !960)
!972 = !DILocation(line: 38, column: 12, scope: !960)
!973 = !DILocalVariable(name: "right", scope: !960, file: !115, line: 38, type: !107)
!974 = !DILocation(line: 38, column: 3, scope: !960)
!975 = !DILocation(line: 39, column: 3, scope: !960)
!976 = !DILocation(line: 39, column: 3, scope: !960)
!977 = !{!107, !146, !10}
!978 = !DISubroutineType(types: !977)
!979 = distinct !DISubprogram(name: "support.namespace-bytes.valid-payload", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dpayload.1956", scope: !115, file: !115, line: 41, type: !978, scopeLine: 41, spFlags: DISPFlagDefinition, unit: !2)
!980 = !DILocalVariable(name: "region", arg: 1, scope: !979, file: !115, line: 41, type: !146)
!981 = !DILocation(line: 41, column: 23, scope: !979)
!982 = !DILocalVariable(name: "length", arg: 2, scope: !979, file: !115, line: 41, type: !10)
!983 = !DILocation(line: 41, column: 50, scope: !979)
!984 = !DILocation(line: 42, column: 23, scope: !979)
!985 = !DILocation(line: 42, column: 61, scope: !979)
!986 = !DILocation(line: 42, column: 99, scope: !979)
!987 = !DILocation(line: 42, column: 137, scope: !979)
!988 = !DILocation(line: 42, column: 13, scope: !979)
!989 = !DILocalVariable(name: "seen-0", scope: !979, file: !115, line: 42, type: !107)
!990 = !DILocation(line: 42, column: 3, scope: !979)
!991 = !DILocation(line: 43, column: 23, scope: !979)
!992 = !DILocation(line: 43, column: 61, scope: !979)
!993 = !DILocation(line: 43, column: 99, scope: !979)
!994 = !DILocation(line: 43, column: 137, scope: !979)
!995 = !DILocation(line: 43, column: 13, scope: !979)
!996 = !DILocalVariable(name: "seen-1", scope: !979, file: !115, line: 43, type: !107)
!997 = !DILocation(line: 43, column: 3, scope: !979)
!998 = !DILocation(line: 44, column: 23, scope: !979)
!999 = !DILocation(line: 44, column: 61, scope: !979)
!1000 = !DILocation(line: 44, column: 99, scope: !979)
!1001 = !DILocation(line: 44, column: 138, scope: !979)
!1002 = !DILocation(line: 44, column: 13, scope: !979)
!1003 = !DILocalVariable(name: "seen-2", scope: !979, file: !115, line: 44, type: !107)
!1004 = !DILocation(line: 44, column: 3, scope: !979)
!1005 = !DILocation(line: 45, column: 23, scope: !979)
!1006 = !DILocation(line: 45, column: 62, scope: !979)
!1007 = !DILocation(line: 45, column: 101, scope: !979)
!1008 = !DILocation(line: 45, column: 140, scope: !979)
!1009 = !DILocation(line: 45, column: 13, scope: !979)
!1010 = !DILocalVariable(name: "seen-3", scope: !979, file: !115, line: 45, type: !107)
!1011 = !DILocation(line: 45, column: 3, scope: !979)
!1012 = !DILocation(line: 46, column: 23, scope: !979)
!1013 = !DILocation(line: 46, column: 62, scope: !979)
!1014 = !DILocation(line: 46, column: 101, scope: !979)
!1015 = !DILocation(line: 46, column: 140, scope: !979)
!1016 = !DILocation(line: 46, column: 13, scope: !979)
!1017 = !DILocalVariable(name: "seen-4", scope: !979, file: !115, line: 46, type: !107)
!1018 = !DILocation(line: 46, column: 3, scope: !979)
!1019 = !DILocation(line: 47, column: 23, scope: !979)
!1020 = !DILocation(line: 47, column: 62, scope: !979)
!1021 = !DILocation(line: 47, column: 101, scope: !979)
!1022 = !DILocation(line: 47, column: 140, scope: !979)
!1023 = !DILocation(line: 47, column: 13, scope: !979)
!1024 = !DILocalVariable(name: "seen-5", scope: !979, file: !115, line: 47, type: !107)
!1025 = !DILocation(line: 47, column: 3, scope: !979)
!1026 = !DILocation(line: 48, column: 23, scope: !979)
!1027 = !DILocation(line: 48, column: 62, scope: !979)
!1028 = !DILocation(line: 48, column: 101, scope: !979)
!1029 = !DILocation(line: 48, column: 140, scope: !979)
!1030 = !DILocation(line: 48, column: 13, scope: !979)
!1031 = !DILocalVariable(name: "seen-6", scope: !979, file: !115, line: 48, type: !107)
!1032 = !DILocation(line: 48, column: 3, scope: !979)
!1033 = !DILocation(line: 49, column: 23, scope: !979)
!1034 = !DILocation(line: 49, column: 62, scope: !979)
!1035 = !DILocation(line: 49, column: 101, scope: !979)
!1036 = !DILocation(line: 49, column: 140, scope: !979)
!1037 = !DILocation(line: 49, column: 13, scope: !979)
!1038 = !DILocalVariable(name: "seen-7", scope: !979, file: !115, line: 49, type: !107)
!1039 = !DILocation(line: 49, column: 3, scope: !979)
!1040 = !DILocation(line: 50, column: 23, scope: !979)
!1041 = !DILocation(line: 50, column: 62, scope: !979)
!1042 = !DILocation(line: 50, column: 101, scope: !979)
!1043 = !DILocation(line: 50, column: 140, scope: !979)
!1044 = !DILocation(line: 50, column: 13, scope: !979)
!1045 = !DILocalVariable(name: "seen-8", scope: !979, file: !115, line: 50, type: !107)
!1046 = !DILocation(line: 50, column: 3, scope: !979)
!1047 = !DILocation(line: 51, column: 23, scope: !979)
!1048 = !DILocation(line: 51, column: 62, scope: !979)
!1049 = !DILocation(line: 51, column: 101, scope: !979)
!1050 = !DILocation(line: 51, column: 140, scope: !979)
!1051 = !DILocation(line: 51, column: 13, scope: !979)
!1052 = !DILocalVariable(name: "seen-9", scope: !979, file: !115, line: 51, type: !107)
!1053 = !DILocation(line: 51, column: 3, scope: !979)
!1054 = !DILocation(line: 52, column: 24, scope: !979)
!1055 = !DILocation(line: 52, column: 63, scope: !979)
!1056 = !DILocation(line: 52, column: 102, scope: !979)
!1057 = !DILocation(line: 52, column: 141, scope: !979)
!1058 = !DILocation(line: 52, column: 14, scope: !979)
!1059 = !DILocalVariable(name: "seen-10", scope: !979, file: !115, line: 52, type: !107)
!1060 = !DILocation(line: 52, column: 3, scope: !979)
!1061 = !DILocation(line: 53, column: 24, scope: !979)
!1062 = !DILocation(line: 53, column: 63, scope: !979)
!1063 = !DILocation(line: 53, column: 102, scope: !979)
!1064 = !DILocation(line: 53, column: 141, scope: !979)
!1065 = !DILocation(line: 53, column: 14, scope: !979)
!1066 = !DILocalVariable(name: "seen-11", scope: !979, file: !115, line: 53, type: !107)
!1067 = !DILocation(line: 53, column: 3, scope: !979)
!1068 = !DILocation(line: 54, column: 24, scope: !979)
!1069 = !DILocation(line: 54, column: 63, scope: !979)
!1070 = !DILocation(line: 54, column: 102, scope: !979)
!1071 = !DILocation(line: 54, column: 141, scope: !979)
!1072 = !DILocation(line: 54, column: 14, scope: !979)
!1073 = !DILocalVariable(name: "seen-12", scope: !979, file: !115, line: 54, type: !107)
!1074 = !DILocation(line: 54, column: 3, scope: !979)
!1075 = !DILocation(line: 55, column: 24, scope: !979)
!1076 = !DILocation(line: 55, column: 63, scope: !979)
!1077 = !DILocation(line: 55, column: 102, scope: !979)
!1078 = !DILocation(line: 55, column: 141, scope: !979)
!1079 = !DILocation(line: 55, column: 14, scope: !979)
!1080 = !DILocalVariable(name: "seen-13", scope: !979, file: !115, line: 55, type: !107)
!1081 = !DILocation(line: 55, column: 3, scope: !979)
!1082 = !DILocation(line: 56, column: 24, scope: !979)
!1083 = !DILocation(line: 56, column: 63, scope: !979)
!1084 = !DILocation(line: 56, column: 102, scope: !979)
!1085 = !DILocation(line: 56, column: 141, scope: !979)
!1086 = !DILocation(line: 56, column: 14, scope: !979)
!1087 = !DILocalVariable(name: "seen-14", scope: !979, file: !115, line: 56, type: !107)
!1088 = !DILocation(line: 56, column: 3, scope: !979)
!1089 = !DILocation(line: 57, column: 24, scope: !979)
!1090 = !DILocation(line: 57, column: 63, scope: !979)
!1091 = !DILocation(line: 57, column: 102, scope: !979)
!1092 = !DILocation(line: 57, column: 141, scope: !979)
!1093 = !DILocation(line: 57, column: 14, scope: !979)
!1094 = !DILocalVariable(name: "seen-15", scope: !979, file: !115, line: 57, type: !107)
!1095 = !DILocation(line: 57, column: 3, scope: !979)
!1096 = !DILocation(line: 58, column: 24, scope: !979)
!1097 = !DILocation(line: 58, column: 63, scope: !979)
!1098 = !DILocation(line: 58, column: 102, scope: !979)
!1099 = !DILocation(line: 58, column: 141, scope: !979)
!1100 = !DILocation(line: 58, column: 14, scope: !979)
!1101 = !DILocalVariable(name: "seen-16", scope: !979, file: !115, line: 58, type: !107)
!1102 = !DILocation(line: 58, column: 3, scope: !979)
!1103 = !DILocation(line: 59, column: 24, scope: !979)
!1104 = !DILocation(line: 59, column: 63, scope: !979)
!1105 = !DILocation(line: 59, column: 102, scope: !979)
!1106 = !DILocation(line: 59, column: 141, scope: !979)
!1107 = !DILocation(line: 59, column: 14, scope: !979)
!1108 = !DILocalVariable(name: "seen-17", scope: !979, file: !115, line: 59, type: !107)
!1109 = !DILocation(line: 59, column: 3, scope: !979)
!1110 = !DILocation(line: 60, column: 24, scope: !979)
!1111 = !DILocation(line: 60, column: 63, scope: !979)
!1112 = !DILocation(line: 60, column: 102, scope: !979)
!1113 = !DILocation(line: 60, column: 141, scope: !979)
!1114 = !DILocation(line: 60, column: 14, scope: !979)
!1115 = !DILocalVariable(name: "seen-18", scope: !979, file: !115, line: 60, type: !107)
!1116 = !DILocation(line: 60, column: 3, scope: !979)
!1117 = !DILocation(line: 61, column: 24, scope: !979)
!1118 = !DILocation(line: 61, column: 63, scope: !979)
!1119 = !DILocation(line: 61, column: 102, scope: !979)
!1120 = !DILocation(line: 61, column: 141, scope: !979)
!1121 = !DILocation(line: 61, column: 14, scope: !979)
!1122 = !DILocalVariable(name: "seen-19", scope: !979, file: !115, line: 61, type: !107)
!1123 = !DILocation(line: 61, column: 3, scope: !979)
!1124 = !DILocation(line: 62, column: 24, scope: !979)
!1125 = !DILocation(line: 62, column: 63, scope: !979)
!1126 = !DILocation(line: 62, column: 102, scope: !979)
!1127 = !DILocation(line: 62, column: 141, scope: !979)
!1128 = !DILocation(line: 62, column: 14, scope: !979)
!1129 = !DILocalVariable(name: "seen-20", scope: !979, file: !115, line: 62, type: !107)
!1130 = !DILocation(line: 62, column: 3, scope: !979)
!1131 = !DILocation(line: 63, column: 24, scope: !979)
!1132 = !DILocation(line: 63, column: 63, scope: !979)
!1133 = !DILocation(line: 63, column: 102, scope: !979)
!1134 = !DILocation(line: 63, column: 141, scope: !979)
!1135 = !DILocation(line: 63, column: 14, scope: !979)
!1136 = !DILocalVariable(name: "seen-21", scope: !979, file: !115, line: 63, type: !107)
!1137 = !DILocation(line: 63, column: 3, scope: !979)
!1138 = !DILocation(line: 64, column: 24, scope: !979)
!1139 = !DILocation(line: 64, column: 63, scope: !979)
!1140 = !DILocation(line: 64, column: 102, scope: !979)
!1141 = !DILocation(line: 64, column: 141, scope: !979)
!1142 = !DILocation(line: 64, column: 14, scope: !979)
!1143 = !DILocalVariable(name: "seen-22", scope: !979, file: !115, line: 64, type: !107)
!1144 = !DILocation(line: 64, column: 3, scope: !979)
!1145 = !DILocation(line: 65, column: 24, scope: !979)
!1146 = !DILocation(line: 65, column: 63, scope: !979)
!1147 = !DILocation(line: 65, column: 102, scope: !979)
!1148 = !DILocation(line: 65, column: 141, scope: !979)
!1149 = !DILocation(line: 65, column: 14, scope: !979)
!1150 = !DILocalVariable(name: "seen-23", scope: !979, file: !115, line: 65, type: !107)
!1151 = !DILocation(line: 65, column: 3, scope: !979)
!1152 = !DILocation(line: 66, column: 24, scope: !979)
!1153 = !DILocation(line: 66, column: 63, scope: !979)
!1154 = !DILocation(line: 66, column: 102, scope: !979)
!1155 = !DILocation(line: 66, column: 141, scope: !979)
!1156 = !DILocation(line: 66, column: 14, scope: !979)
!1157 = !DILocalVariable(name: "seen-24", scope: !979, file: !115, line: 66, type: !107)
!1158 = !DILocation(line: 66, column: 3, scope: !979)
!1159 = !DILocation(line: 67, column: 24, scope: !979)
!1160 = !DILocation(line: 67, column: 64, scope: !979)
!1161 = !DILocation(line: 67, column: 104, scope: !979)
!1162 = !DILocation(line: 67, column: 144, scope: !979)
!1163 = !DILocation(line: 67, column: 14, scope: !979)
!1164 = !DILocalVariable(name: "seen-25", scope: !979, file: !115, line: 67, type: !107)
!1165 = !DILocation(line: 67, column: 3, scope: !979)
!1166 = !DILocation(line: 68, column: 24, scope: !979)
!1167 = !DILocation(line: 68, column: 64, scope: !979)
!1168 = !DILocation(line: 68, column: 104, scope: !979)
!1169 = !DILocation(line: 68, column: 144, scope: !979)
!1170 = !DILocation(line: 68, column: 14, scope: !979)
!1171 = !DILocalVariable(name: "seen-26", scope: !979, file: !115, line: 68, type: !107)
!1172 = !DILocation(line: 68, column: 3, scope: !979)
!1173 = !DILocation(line: 69, column: 24, scope: !979)
!1174 = !DILocation(line: 69, column: 64, scope: !979)
!1175 = !DILocation(line: 69, column: 104, scope: !979)
!1176 = !DILocation(line: 69, column: 144, scope: !979)
!1177 = !DILocation(line: 69, column: 14, scope: !979)
!1178 = !DILocalVariable(name: "seen-27", scope: !979, file: !115, line: 69, type: !107)
!1179 = !DILocation(line: 69, column: 3, scope: !979)
!1180 = !DILocation(line: 70, column: 24, scope: !979)
!1181 = !DILocation(line: 70, column: 64, scope: !979)
!1182 = !DILocation(line: 70, column: 104, scope: !979)
!1183 = !DILocation(line: 70, column: 144, scope: !979)
!1184 = !DILocation(line: 70, column: 14, scope: !979)
!1185 = !DILocalVariable(name: "seen-28", scope: !979, file: !115, line: 70, type: !107)
!1186 = !DILocation(line: 70, column: 3, scope: !979)
!1187 = !DILocation(line: 71, column: 24, scope: !979)
!1188 = !DILocation(line: 71, column: 64, scope: !979)
!1189 = !DILocation(line: 71, column: 104, scope: !979)
!1190 = !DILocation(line: 71, column: 144, scope: !979)
!1191 = !DILocation(line: 71, column: 14, scope: !979)
!1192 = !DILocalVariable(name: "seen-29", scope: !979, file: !115, line: 71, type: !107)
!1193 = !DILocation(line: 71, column: 3, scope: !979)
!1194 = !DILocation(line: 72, column: 24, scope: !979)
!1195 = !DILocation(line: 72, column: 64, scope: !979)
!1196 = !DILocation(line: 72, column: 104, scope: !979)
!1197 = !DILocation(line: 72, column: 144, scope: !979)
!1198 = !DILocation(line: 72, column: 14, scope: !979)
!1199 = !DILocalVariable(name: "seen-30", scope: !979, file: !115, line: 72, type: !107)
!1200 = !DILocation(line: 72, column: 3, scope: !979)
!1201 = !DILocation(line: 73, column: 24, scope: !979)
!1202 = !DILocation(line: 73, column: 64, scope: !979)
!1203 = !DILocation(line: 73, column: 104, scope: !979)
!1204 = !DILocation(line: 73, column: 144, scope: !979)
!1205 = !DILocation(line: 73, column: 14, scope: !979)
!1206 = !DILocalVariable(name: "seen-31", scope: !979, file: !115, line: 73, type: !107)
!1207 = !DILocation(line: 73, column: 3, scope: !979)
!1208 = !DILocation(line: 74, column: 24, scope: !979)
!1209 = !DILocation(line: 74, column: 64, scope: !979)
!1210 = !DILocation(line: 74, column: 104, scope: !979)
!1211 = !DILocation(line: 74, column: 144, scope: !979)
!1212 = !DILocation(line: 74, column: 14, scope: !979)
!1213 = !DILocalVariable(name: "seen-32", scope: !979, file: !115, line: 74, type: !107)
!1214 = !DILocation(line: 74, column: 3, scope: !979)
!1215 = !DILocation(line: 75, column: 24, scope: !979)
!1216 = !DILocation(line: 75, column: 64, scope: !979)
!1217 = !DILocation(line: 75, column: 104, scope: !979)
!1218 = !DILocation(line: 75, column: 144, scope: !979)
!1219 = !DILocation(line: 75, column: 14, scope: !979)
!1220 = !DILocalVariable(name: "seen-33", scope: !979, file: !115, line: 75, type: !107)
!1221 = !DILocation(line: 75, column: 3, scope: !979)
!1222 = !DILocation(line: 76, column: 24, scope: !979)
!1223 = !DILocation(line: 76, column: 64, scope: !979)
!1224 = !DILocation(line: 76, column: 104, scope: !979)
!1225 = !DILocation(line: 76, column: 144, scope: !979)
!1226 = !DILocation(line: 76, column: 14, scope: !979)
!1227 = !DILocalVariable(name: "seen-34", scope: !979, file: !115, line: 76, type: !107)
!1228 = !DILocation(line: 76, column: 3, scope: !979)
!1229 = !DILocation(line: 77, column: 24, scope: !979)
!1230 = !DILocation(line: 77, column: 64, scope: !979)
!1231 = !DILocation(line: 77, column: 104, scope: !979)
!1232 = !DILocation(line: 77, column: 144, scope: !979)
!1233 = !DILocation(line: 77, column: 14, scope: !979)
!1234 = !DILocalVariable(name: "seen-35", scope: !979, file: !115, line: 77, type: !107)
!1235 = !DILocation(line: 77, column: 3, scope: !979)
!1236 = !DILocation(line: 78, column: 24, scope: !979)
!1237 = !DILocation(line: 78, column: 64, scope: !979)
!1238 = !DILocation(line: 78, column: 104, scope: !979)
!1239 = !DILocation(line: 78, column: 144, scope: !979)
!1240 = !DILocation(line: 78, column: 14, scope: !979)
!1241 = !DILocalVariable(name: "seen-36", scope: !979, file: !115, line: 78, type: !107)
!1242 = !DILocation(line: 78, column: 3, scope: !979)
!1243 = !DILocation(line: 79, column: 24, scope: !979)
!1244 = !DILocation(line: 79, column: 64, scope: !979)
!1245 = !DILocation(line: 79, column: 104, scope: !979)
!1246 = !DILocation(line: 79, column: 144, scope: !979)
!1247 = !DILocation(line: 79, column: 14, scope: !979)
!1248 = !DILocalVariable(name: "seen-37", scope: !979, file: !115, line: 79, type: !107)
!1249 = !DILocation(line: 79, column: 3, scope: !979)
!1250 = !DILocation(line: 80, column: 24, scope: !979)
!1251 = !DILocation(line: 80, column: 64, scope: !979)
!1252 = !DILocation(line: 80, column: 104, scope: !979)
!1253 = !DILocation(line: 80, column: 144, scope: !979)
!1254 = !DILocation(line: 80, column: 14, scope: !979)
!1255 = !DILocalVariable(name: "seen-38", scope: !979, file: !115, line: 80, type: !107)
!1256 = !DILocation(line: 80, column: 3, scope: !979)
!1257 = !DILocation(line: 81, column: 24, scope: !979)
!1258 = !DILocation(line: 81, column: 64, scope: !979)
!1259 = !DILocation(line: 81, column: 104, scope: !979)
!1260 = !DILocation(line: 81, column: 144, scope: !979)
!1261 = !DILocation(line: 81, column: 14, scope: !979)
!1262 = !DILocalVariable(name: "seen-39", scope: !979, file: !115, line: 81, type: !107)
!1263 = !DILocation(line: 81, column: 3, scope: !979)
!1264 = !DILocation(line: 82, column: 24, scope: !979)
!1265 = !DILocation(line: 82, column: 64, scope: !979)
!1266 = !DILocation(line: 82, column: 104, scope: !979)
!1267 = !DILocation(line: 82, column: 144, scope: !979)
!1268 = !DILocation(line: 82, column: 14, scope: !979)
!1269 = !DILocalVariable(name: "seen-40", scope: !979, file: !115, line: 82, type: !107)
!1270 = !DILocation(line: 82, column: 3, scope: !979)
!1271 = !DILocation(line: 83, column: 24, scope: !979)
!1272 = !DILocation(line: 83, column: 64, scope: !979)
!1273 = !DILocation(line: 83, column: 104, scope: !979)
!1274 = !DILocation(line: 83, column: 144, scope: !979)
!1275 = !DILocation(line: 83, column: 14, scope: !979)
!1276 = !DILocalVariable(name: "seen-41", scope: !979, file: !115, line: 83, type: !107)
!1277 = !DILocation(line: 83, column: 3, scope: !979)
!1278 = !DILocation(line: 84, column: 24, scope: !979)
!1279 = !DILocation(line: 84, column: 64, scope: !979)
!1280 = !DILocation(line: 84, column: 104, scope: !979)
!1281 = !DILocation(line: 84, column: 144, scope: !979)
!1282 = !DILocation(line: 84, column: 14, scope: !979)
!1283 = !DILocalVariable(name: "seen-42", scope: !979, file: !115, line: 84, type: !107)
!1284 = !DILocation(line: 84, column: 3, scope: !979)
!1285 = !DILocation(line: 85, column: 24, scope: !979)
!1286 = !DILocation(line: 85, column: 64, scope: !979)
!1287 = !DILocation(line: 85, column: 104, scope: !979)
!1288 = !DILocation(line: 85, column: 144, scope: !979)
!1289 = !DILocation(line: 85, column: 14, scope: !979)
!1290 = !DILocalVariable(name: "seen-43", scope: !979, file: !115, line: 85, type: !107)
!1291 = !DILocation(line: 85, column: 3, scope: !979)
!1292 = !DILocation(line: 86, column: 24, scope: !979)
!1293 = !DILocation(line: 86, column: 64, scope: !979)
!1294 = !DILocation(line: 86, column: 104, scope: !979)
!1295 = !DILocation(line: 86, column: 144, scope: !979)
!1296 = !DILocation(line: 86, column: 14, scope: !979)
!1297 = !DILocalVariable(name: "seen-44", scope: !979, file: !115, line: 86, type: !107)
!1298 = !DILocation(line: 86, column: 3, scope: !979)
!1299 = !DILocation(line: 87, column: 24, scope: !979)
!1300 = !DILocation(line: 87, column: 64, scope: !979)
!1301 = !DILocation(line: 87, column: 104, scope: !979)
!1302 = !DILocation(line: 87, column: 144, scope: !979)
!1303 = !DILocation(line: 87, column: 14, scope: !979)
!1304 = !DILocalVariable(name: "seen-45", scope: !979, file: !115, line: 87, type: !107)
!1305 = !DILocation(line: 87, column: 3, scope: !979)
!1306 = !DILocation(line: 88, column: 24, scope: !979)
!1307 = !DILocation(line: 88, column: 64, scope: !979)
!1308 = !DILocation(line: 88, column: 104, scope: !979)
!1309 = !DILocation(line: 88, column: 144, scope: !979)
!1310 = !DILocation(line: 88, column: 14, scope: !979)
!1311 = !DILocalVariable(name: "seen-46", scope: !979, file: !115, line: 88, type: !107)
!1312 = !DILocation(line: 88, column: 3, scope: !979)
!1313 = !DILocation(line: 89, column: 24, scope: !979)
!1314 = !DILocation(line: 89, column: 64, scope: !979)
!1315 = !DILocation(line: 89, column: 104, scope: !979)
!1316 = !DILocation(line: 89, column: 144, scope: !979)
!1317 = !DILocation(line: 89, column: 14, scope: !979)
!1318 = !DILocalVariable(name: "seen-47", scope: !979, file: !115, line: 89, type: !107)
!1319 = !DILocation(line: 89, column: 3, scope: !979)
!1320 = !DILocation(line: 90, column: 24, scope: !979)
!1321 = !DILocation(line: 90, column: 64, scope: !979)
!1322 = !DILocation(line: 90, column: 104, scope: !979)
!1323 = !DILocation(line: 90, column: 144, scope: !979)
!1324 = !DILocation(line: 90, column: 14, scope: !979)
!1325 = !DILocalVariable(name: "seen-48", scope: !979, file: !115, line: 90, type: !107)
!1326 = !DILocation(line: 90, column: 3, scope: !979)
!1327 = !DILocation(line: 91, column: 24, scope: !979)
!1328 = !DILocation(line: 91, column: 64, scope: !979)
!1329 = !DILocation(line: 91, column: 104, scope: !979)
!1330 = !DILocation(line: 91, column: 144, scope: !979)
!1331 = !DILocation(line: 91, column: 14, scope: !979)
!1332 = !DILocalVariable(name: "seen-49", scope: !979, file: !115, line: 91, type: !107)
!1333 = !DILocation(line: 91, column: 3, scope: !979)
!1334 = !DILocation(line: 92, column: 24, scope: !979)
!1335 = !DILocation(line: 92, column: 64, scope: !979)
!1336 = !DILocation(line: 92, column: 104, scope: !979)
!1337 = !DILocation(line: 92, column: 144, scope: !979)
!1338 = !DILocation(line: 92, column: 14, scope: !979)
!1339 = !DILocalVariable(name: "seen-50", scope: !979, file: !115, line: 92, type: !107)
!1340 = !DILocation(line: 92, column: 3, scope: !979)
!1341 = !DILocation(line: 93, column: 24, scope: !979)
!1342 = !DILocation(line: 93, column: 64, scope: !979)
!1343 = !DILocation(line: 93, column: 104, scope: !979)
!1344 = !DILocation(line: 93, column: 144, scope: !979)
!1345 = !DILocation(line: 93, column: 14, scope: !979)
!1346 = !DILocalVariable(name: "seen-51", scope: !979, file: !115, line: 93, type: !107)
!1347 = !DILocation(line: 93, column: 3, scope: !979)
!1348 = !DILocation(line: 94, column: 24, scope: !979)
!1349 = !DILocation(line: 94, column: 64, scope: !979)
!1350 = !DILocation(line: 94, column: 104, scope: !979)
!1351 = !DILocation(line: 94, column: 144, scope: !979)
!1352 = !DILocation(line: 94, column: 14, scope: !979)
!1353 = !DILocalVariable(name: "seen-52", scope: !979, file: !115, line: 94, type: !107)
!1354 = !DILocation(line: 94, column: 3, scope: !979)
!1355 = !DILocation(line: 95, column: 24, scope: !979)
!1356 = !DILocation(line: 95, column: 64, scope: !979)
!1357 = !DILocation(line: 95, column: 104, scope: !979)
!1358 = !DILocation(line: 95, column: 144, scope: !979)
!1359 = !DILocation(line: 95, column: 14, scope: !979)
!1360 = !DILocalVariable(name: "seen-53", scope: !979, file: !115, line: 95, type: !107)
!1361 = !DILocation(line: 95, column: 3, scope: !979)
!1362 = !DILocation(line: 96, column: 24, scope: !979)
!1363 = !DILocation(line: 96, column: 64, scope: !979)
!1364 = !DILocation(line: 96, column: 104, scope: !979)
!1365 = !DILocation(line: 96, column: 144, scope: !979)
!1366 = !DILocation(line: 96, column: 14, scope: !979)
!1367 = !DILocalVariable(name: "seen-54", scope: !979, file: !115, line: 96, type: !107)
!1368 = !DILocation(line: 96, column: 3, scope: !979)
!1369 = !DILocation(line: 97, column: 24, scope: !979)
!1370 = !DILocation(line: 97, column: 64, scope: !979)
!1371 = !DILocation(line: 97, column: 104, scope: !979)
!1372 = !DILocation(line: 97, column: 144, scope: !979)
!1373 = !DILocation(line: 97, column: 14, scope: !979)
!1374 = !DILocalVariable(name: "seen-55", scope: !979, file: !115, line: 97, type: !107)
!1375 = !DILocation(line: 97, column: 3, scope: !979)
!1376 = !DILocation(line: 98, column: 24, scope: !979)
!1377 = !DILocation(line: 98, column: 64, scope: !979)
!1378 = !DILocation(line: 98, column: 104, scope: !979)
!1379 = !DILocation(line: 98, column: 144, scope: !979)
!1380 = !DILocation(line: 98, column: 14, scope: !979)
!1381 = !DILocalVariable(name: "seen-56", scope: !979, file: !115, line: 98, type: !107)
!1382 = !DILocation(line: 98, column: 3, scope: !979)
!1383 = !DILocation(line: 99, column: 24, scope: !979)
!1384 = !DILocation(line: 99, column: 64, scope: !979)
!1385 = !DILocation(line: 99, column: 104, scope: !979)
!1386 = !DILocation(line: 99, column: 144, scope: !979)
!1387 = !DILocation(line: 99, column: 14, scope: !979)
!1388 = !DILocalVariable(name: "seen-57", scope: !979, file: !115, line: 99, type: !107)
!1389 = !DILocation(line: 99, column: 3, scope: !979)
!1390 = !DILocation(line: 100, column: 24, scope: !979)
!1391 = !DILocation(line: 100, column: 64, scope: !979)
!1392 = !DILocation(line: 100, column: 104, scope: !979)
!1393 = !DILocation(line: 100, column: 144, scope: !979)
!1394 = !DILocation(line: 100, column: 14, scope: !979)
!1395 = !DILocalVariable(name: "seen-58", scope: !979, file: !115, line: 100, type: !107)
!1396 = !DILocation(line: 100, column: 3, scope: !979)
!1397 = !DILocation(line: 101, column: 24, scope: !979)
!1398 = !DILocation(line: 101, column: 64, scope: !979)
!1399 = !DILocation(line: 101, column: 104, scope: !979)
!1400 = !DILocation(line: 101, column: 144, scope: !979)
!1401 = !DILocation(line: 101, column: 14, scope: !979)
!1402 = !DILocalVariable(name: "seen-59", scope: !979, file: !115, line: 101, type: !107)
!1403 = !DILocation(line: 101, column: 3, scope: !979)
!1404 = !DILocation(line: 102, column: 24, scope: !979)
!1405 = !DILocation(line: 102, column: 64, scope: !979)
!1406 = !DILocation(line: 102, column: 104, scope: !979)
!1407 = !DILocation(line: 102, column: 144, scope: !979)
!1408 = !DILocation(line: 102, column: 14, scope: !979)
!1409 = !DILocalVariable(name: "seen-60", scope: !979, file: !115, line: 102, type: !107)
!1410 = !DILocation(line: 102, column: 3, scope: !979)
!1411 = !DILocation(line: 103, column: 24, scope: !979)
!1412 = !DILocation(line: 103, column: 64, scope: !979)
!1413 = !DILocation(line: 103, column: 104, scope: !979)
!1414 = !DILocation(line: 103, column: 144, scope: !979)
!1415 = !DILocation(line: 103, column: 14, scope: !979)
!1416 = !DILocalVariable(name: "seen-61", scope: !979, file: !115, line: 103, type: !107)
!1417 = !DILocation(line: 103, column: 3, scope: !979)
!1418 = !DILocation(line: 104, column: 24, scope: !979)
!1419 = !DILocation(line: 104, column: 64, scope: !979)
!1420 = !DILocation(line: 104, column: 104, scope: !979)
!1421 = !DILocation(line: 104, column: 144, scope: !979)
!1422 = !DILocation(line: 104, column: 14, scope: !979)
!1423 = !DILocalVariable(name: "seen-62", scope: !979, file: !115, line: 104, type: !107)
!1424 = !DILocation(line: 104, column: 3, scope: !979)
!1425 = !DILocation(line: 105, column: 24, scope: !979)
!1426 = !DILocation(line: 105, column: 64, scope: !979)
!1427 = !DILocation(line: 105, column: 104, scope: !979)
!1428 = !DILocation(line: 105, column: 144, scope: !979)
!1429 = !DILocation(line: 105, column: 14, scope: !979)
!1430 = !DILocalVariable(name: "seen-63", scope: !979, file: !115, line: 105, type: !107)
!1431 = !DILocation(line: 105, column: 3, scope: !979)
!1432 = !DILocation(line: 106, column: 16, scope: !979)
!1433 = !DILocalVariable(name: "checked-0", scope: !979, file: !115, line: 106, type: !107)
!1434 = !DILocation(line: 106, column: 3, scope: !979)
!1435 = !DILocation(line: 107, column: 16, scope: !979)
!1436 = !DILocalVariable(name: "checked-1", scope: !979, file: !115, line: 107, type: !107)
!1437 = !DILocation(line: 107, column: 3, scope: !979)
!1438 = !DILocation(line: 108, column: 16, scope: !979)
!1439 = !DILocalVariable(name: "checked-2", scope: !979, file: !115, line: 108, type: !107)
!1440 = !DILocation(line: 108, column: 3, scope: !979)
!1441 = !DILocation(line: 109, column: 16, scope: !979)
!1442 = !DILocalVariable(name: "checked-3", scope: !979, file: !115, line: 109, type: !107)
!1443 = !DILocation(line: 109, column: 3, scope: !979)
!1444 = !DILocation(line: 110, column: 16, scope: !979)
!1445 = !DILocalVariable(name: "checked-4", scope: !979, file: !115, line: 110, type: !107)
!1446 = !DILocation(line: 110, column: 3, scope: !979)
!1447 = !DILocation(line: 111, column: 16, scope: !979)
!1448 = !DILocalVariable(name: "checked-5", scope: !979, file: !115, line: 111, type: !107)
!1449 = !DILocation(line: 111, column: 3, scope: !979)
!1450 = !DILocation(line: 112, column: 16, scope: !979)
!1451 = !DILocalVariable(name: "checked-6", scope: !979, file: !115, line: 112, type: !107)
!1452 = !DILocation(line: 112, column: 3, scope: !979)
!1453 = !DILocation(line: 113, column: 16, scope: !979)
!1454 = !DILocalVariable(name: "checked-7", scope: !979, file: !115, line: 113, type: !107)
!1455 = !DILocation(line: 113, column: 3, scope: !979)
!1456 = !DILocation(line: 114, column: 16, scope: !979)
!1457 = !DILocalVariable(name: "checked-8", scope: !979, file: !115, line: 114, type: !107)
!1458 = !DILocation(line: 114, column: 3, scope: !979)
!1459 = !DILocation(line: 115, column: 16, scope: !979)
!1460 = !DILocalVariable(name: "checked-9", scope: !979, file: !115, line: 115, type: !107)
!1461 = !DILocation(line: 115, column: 3, scope: !979)
!1462 = !DILocation(line: 116, column: 17, scope: !979)
!1463 = !DILocalVariable(name: "checked-10", scope: !979, file: !115, line: 116, type: !107)
!1464 = !DILocation(line: 116, column: 3, scope: !979)
!1465 = !DILocation(line: 117, column: 17, scope: !979)
!1466 = !DILocalVariable(name: "checked-11", scope: !979, file: !115, line: 117, type: !107)
!1467 = !DILocation(line: 117, column: 3, scope: !979)
!1468 = !DILocation(line: 118, column: 17, scope: !979)
!1469 = !DILocalVariable(name: "checked-12", scope: !979, file: !115, line: 118, type: !107)
!1470 = !DILocation(line: 118, column: 3, scope: !979)
!1471 = !DILocation(line: 119, column: 17, scope: !979)
!1472 = !DILocalVariable(name: "checked-13", scope: !979, file: !115, line: 119, type: !107)
!1473 = !DILocation(line: 119, column: 3, scope: !979)
!1474 = !DILocation(line: 120, column: 17, scope: !979)
!1475 = !DILocalVariable(name: "checked-14", scope: !979, file: !115, line: 120, type: !107)
!1476 = !DILocation(line: 120, column: 3, scope: !979)
!1477 = !DILocation(line: 121, column: 17, scope: !979)
!1478 = !DILocalVariable(name: "checked-15", scope: !979, file: !115, line: 121, type: !107)
!1479 = !DILocation(line: 121, column: 3, scope: !979)
!1480 = !DILocation(line: 122, column: 14, scope: !979)
!1481 = !DILocalVariable(name: "range-0", scope: !979, file: !115, line: 122, type: !107)
!1482 = !DILocation(line: 122, column: 3, scope: !979)
!1483 = !DILocation(line: 123, column: 14, scope: !979)
!1484 = !DILocalVariable(name: "range-1", scope: !979, file: !115, line: 123, type: !107)
!1485 = !DILocation(line: 123, column: 3, scope: !979)
!1486 = !DILocation(line: 124, column: 14, scope: !979)
!1487 = !DILocalVariable(name: "range-2", scope: !979, file: !115, line: 124, type: !107)
!1488 = !DILocation(line: 124, column: 3, scope: !979)
!1489 = !DILocation(line: 125, column: 14, scope: !979)
!1490 = !DILocalVariable(name: "range-3", scope: !979, file: !115, line: 125, type: !107)
!1491 = !DILocation(line: 125, column: 3, scope: !979)
!1492 = !DILocation(line: 126, column: 3, scope: !979)
!1493 = !DILocation(line: 126, column: 3, scope: !979)
!1494 = !{!107, !146, !10}
!1495 = !DISubroutineType(types: !1494)
!1496 = distinct !DISubprogram(name: "support.namespace-bytes.valid-normal", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dnormal.1957", scope: !115, file: !115, line: 141, type: !1495, scopeLine: 141, spFlags: DISPFlagDefinition, unit: !2)
!1497 = !DILocalVariable(name: "region", arg: 1, scope: !1496, file: !115, line: 141, type: !146)
!1498 = !DILocation(line: 141, column: 22, scope: !1496)
!1499 = !DILocalVariable(name: "length", arg: 2, scope: !1496, file: !115, line: 141, type: !10)
!1500 = !DILocation(line: 141, column: 49, scope: !1496)
!1501 = !DILocation(line: 142, column: 3, scope: !1496)
!1502 = !DILocation(line: 142, column: 3, scope: !1496)
!1503 = !DILocation(line: 143, column: 15, scope: !1496)
!1504 = !DILocation(line: 143, column: 15, scope: !1496)
!1505 = !DILocation(line: 144, column: 16, scope: !1496)
!1506 = !DILocation(line: 142, column: 3, scope: !1496)
!1507 = !DILocation(line: 142, column: 3, scope: !1496)
!1508 = !{!107, !146, !10}
!1509 = !DISubroutineType(types: !1508)
!1510 = distinct !DISubprogram(name: "support.namespace-bytes.valid-bounded", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dbounded.1958", scope: !115, file: !115, line: 146, type: !1509, scopeLine: 146, spFlags: DISPFlagDefinition, unit: !2)
!1511 = !DILocalVariable(name: "region", arg: 1, scope: !1510, file: !115, line: 146, type: !146)
!1512 = !DILocation(line: 146, column: 23, scope: !1510)
!1513 = !DILocalVariable(name: "length", arg: 2, scope: !1510, file: !115, line: 146, type: !10)
!1514 = !DILocation(line: 146, column: 50, scope: !1510)
!1515 = !DILocation(line: 147, column: 3, scope: !1510)
!1516 = !DILocation(line: 147, column: 3, scope: !1510)
!1517 = !DILocation(line: 147, column: 3, scope: !1510)
!1518 = !DILocation(line: 148, column: 15, scope: !1510)
!1519 = !DILocation(line: 148, column: 15, scope: !1510)
!1520 = !DILocation(line: 149, column: 16, scope: !1510)
!1521 = !DILocation(line: 147, column: 3, scope: !1510)
!1522 = !DILocation(line: 147, column: 3, scope: !1510)
!1523 = !{!107, !146, !10}
!1524 = !DISubroutineType(types: !1523)
!1525 = distinct !DISubprogram(name: "support.namespace-bytes.valid-input", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2evalid_2dinput.1959", scope: !115, file: !115, line: 151, type: !1524, scopeLine: 151, spFlags: DISPFlagDefinition, unit: !2)
!1526 = !DILocalVariable(name: "region", arg: 1, scope: !1525, file: !115, line: 151, type: !146)
!1527 = !DILocation(line: 151, column: 25, scope: !1525)
!1528 = !DILocalVariable(name: "length", arg: 2, scope: !1525, file: !115, line: 151, type: !10)
!1529 = !DILocation(line: 151, column: 52, scope: !1525)
!1530 = !DILocation(line: 152, column: 3, scope: !1525)
!1531 = !DILocation(line: 152, column: 3, scope: !1525)
!1532 = !DILocation(line: 152, column: 3, scope: !1525)
!1533 = !DILocation(line: 153, column: 15, scope: !1525)
!1534 = !DILocation(line: 153, column: 15, scope: !1525)
!1535 = !DILocation(line: 154, column: 16, scope: !1525)
!1536 = !DILocation(line: 152, column: 3, scope: !1525)
!1537 = !DILocation(line: 152, column: 3, scope: !1525)
!1538 = !{!107, !146, !10}
!1539 = !DISubroutineType(types: !1538)
!1540 = distinct !DISubprogram(name: "support.namespace-metadata.input-clean", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2einput_2dclean.1962", scope: !116, file: !116, line: 97, type: !1539, scopeLine: 97, spFlags: DISPFlagDefinition, unit: !2)
!1541 = !DILocalVariable(name: "region", arg: 1, scope: !1540, file: !116, line: 97, type: !146)
!1542 = !DILocation(line: 97, column: 21, scope: !1540)
!1543 = !DILocalVariable(name: "length", arg: 2, scope: !1540, file: !116, line: 97, type: !10)
!1544 = !DILocation(line: 97, column: 48, scope: !1540)
!1545 = !DILocation(line: 98, column: 13, scope: !1540)
!1546 = !DILocalVariable(name: "middle", scope: !1540, file: !116, line: 98, type: !107)
!1547 = !DILocation(line: 98, column: 3, scope: !1540)
!1548 = !DILocation(line: 99, column: 10, scope: !1540)
!1549 = !DILocalVariable(name: "end", scope: !1540, file: !116, line: 99, type: !107)
!1550 = !DILocation(line: 99, column: 3, scope: !1540)
!1551 = !DILocation(line: 100, column: 12, scope: !1540)
!1552 = !DILocalVariable(name: "valid", scope: !1540, file: !116, line: 100, type: !107)
!1553 = !DILocation(line: 100, column: 3, scope: !1540)
!1554 = !DILocation(line: 101, column: 16, scope: !1540)
!1555 = !DILocation(line: 101, column: 3, scope: !1540)
!1556 = !DILocation(line: 101, column: 3, scope: !1540)
!1557 = !{!107, !146, !10, !10}
!1558 = !DISubroutineType(types: !1557)
!1559 = distinct !DISubprogram(name: "support.namespace-bytes.copy-word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dword.1970", scope: !115, file: !115, line: 156, type: !1558, scopeLine: 156, spFlags: DISPFlagDefinition, unit: !2)
!1560 = !DILocalVariable(name: "region", arg: 1, scope: !1559, file: !115, line: 156, type: !146)
!1561 = !DILocation(line: 156, column: 19, scope: !1559)
!1562 = !DILocalVariable(name: "destination", arg: 2, scope: !1559, file: !115, line: 156, type: !10)
!1563 = !DILocation(line: 156, column: 46, scope: !1559)
!1564 = !DILocalVariable(name: "source", arg: 3, scope: !1559, file: !115, line: 156, type: !10)
!1565 = !DILocation(line: 156, column: 65, scope: !1559)
!1566 = !DILocation(line: 157, column: 3, scope: !1559)
!1567 = !DILocation(line: 157, column: 3, scope: !1559)
!1568 = !DILocation(line: 157, column: 3, scope: !1559)
!1569 = !DILocation(line: 158, column: 10, scope: !1559)
!1570 = !DILocalVariable(name: "value", scope: !1559, file: !115, line: 158, type: !10)
!1571 = !DILocation(line: 158, column: 10, scope: !1559)
!1572 = !DILocation(line: 158, column: 21, scope: !1559)
!1573 = !DILocation(line: 158, column: 21, scope: !1559)
!1574 = !DILocation(line: 159, column: 15, scope: !1559)
!1575 = !DILocation(line: 157, column: 3, scope: !1559)
!1576 = !DILocation(line: 157, column: 3, scope: !1559)
!1577 = !{!107, !146, !10, !10}
!1578 = !DISubroutineType(types: !1577)
!1579 = distinct !DISubprogram(name: "support.namespace-bytes.copy-pair", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dpair.1972", scope: !115, file: !115, line: 168, type: !1578, scopeLine: 168, spFlags: DISPFlagDefinition, unit: !2)
!1580 = !DILocalVariable(name: "region", arg: 1, scope: !1579, file: !115, line: 168, type: !146)
!1581 = !DILocation(line: 168, column: 19, scope: !1579)
!1582 = !DILocalVariable(name: "destination", arg: 2, scope: !1579, file: !115, line: 168, type: !10)
!1583 = !DILocation(line: 168, column: 46, scope: !1579)
!1584 = !DILocalVariable(name: "source", arg: 3, scope: !1579, file: !115, line: 168, type: !10)
!1585 = !DILocation(line: 168, column: 65, scope: !1579)
!1586 = !DILocation(line: 169, column: 3, scope: !1579)
!1587 = !DILocation(line: 169, column: 3, scope: !1579)
!1588 = !DILocation(line: 170, column: 34, scope: !1579)
!1589 = !DILocation(line: 170, column: 51, scope: !1579)
!1590 = !DILocation(line: 170, column: 15, scope: !1579)
!1591 = !DILocation(line: 170, column: 15, scope: !1579)
!1592 = !DILocation(line: 171, column: 16, scope: !1579)
!1593 = !DILocation(line: 169, column: 3, scope: !1579)
!1594 = !DILocation(line: 169, column: 3, scope: !1579)
!1595 = !{!107, !146, !10, !10}
!1596 = !DISubroutineType(types: !1595)
!1597 = distinct !DISubprogram(name: "support.namespace-bytes.copy-block", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dblock.1976", scope: !115, file: !115, line: 183, type: !1596, scopeLine: 183, spFlags: DISPFlagDefinition, unit: !2)
!1598 = !DILocalVariable(name: "region", arg: 1, scope: !1597, file: !115, line: 183, type: !146)
!1599 = !DILocation(line: 183, column: 20, scope: !1597)
!1600 = !DILocalVariable(name: "destination", arg: 2, scope: !1597, file: !115, line: 183, type: !10)
!1601 = !DILocation(line: 183, column: 47, scope: !1597)
!1602 = !DILocalVariable(name: "source", arg: 3, scope: !1597, file: !115, line: 183, type: !10)
!1603 = !DILocation(line: 183, column: 66, scope: !1597)
!1604 = !DILocation(line: 184, column: 3, scope: !1597)
!1605 = !DILocation(line: 184, column: 3, scope: !1597)
!1606 = !DILocation(line: 185, column: 34, scope: !1597)
!1607 = !DILocation(line: 185, column: 52, scope: !1597)
!1608 = !DILocation(line: 185, column: 15, scope: !1597)
!1609 = !DILocation(line: 185, column: 15, scope: !1597)
!1610 = !DILocation(line: 186, column: 16, scope: !1597)
!1611 = !DILocation(line: 184, column: 3, scope: !1597)
!1612 = !DILocation(line: 184, column: 3, scope: !1597)
!1613 = !{!107, !146, !10, !10}
!1614 = !DISubroutineType(types: !1613)
!1615 = distinct !DISubprogram(name: "support.namespace-bytes.copy-quarter", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dquarter.1984", scope: !115, file: !115, line: 198, type: !1614, scopeLine: 198, spFlags: DISPFlagDefinition, unit: !2)
!1616 = !DILocalVariable(name: "region", arg: 1, scope: !1615, file: !115, line: 198, type: !146)
!1617 = !DILocation(line: 198, column: 22, scope: !1615)
!1618 = !DILocalVariable(name: "destination", arg: 2, scope: !1615, file: !115, line: 198, type: !10)
!1619 = !DILocation(line: 198, column: 49, scope: !1615)
!1620 = !DILocalVariable(name: "source", arg: 3, scope: !1615, file: !115, line: 198, type: !10)
!1621 = !DILocation(line: 198, column: 68, scope: !1615)
!1622 = !DILocation(line: 199, column: 3, scope: !1615)
!1623 = !DILocation(line: 199, column: 3, scope: !1615)
!1624 = !DILocation(line: 200, column: 35, scope: !1615)
!1625 = !DILocation(line: 200, column: 53, scope: !1615)
!1626 = !DILocation(line: 200, column: 15, scope: !1615)
!1627 = !DILocation(line: 200, column: 15, scope: !1615)
!1628 = !DILocation(line: 201, column: 16, scope: !1615)
!1629 = !DILocation(line: 199, column: 3, scope: !1615)
!1630 = !DILocation(line: 199, column: 3, scope: !1615)
!1631 = !{!107, !146, !10, !10}
!1632 = !DISubroutineType(types: !1631)
!1633 = distinct !DISubprogram(name: "support.namespace-bytes.copy-half", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dhalf.2000", scope: !115, file: !115, line: 213, type: !1632, scopeLine: 213, spFlags: DISPFlagDefinition, unit: !2)
!1634 = !DILocalVariable(name: "region", arg: 1, scope: !1633, file: !115, line: 213, type: !146)
!1635 = !DILocation(line: 213, column: 19, scope: !1633)
!1636 = !DILocalVariable(name: "destination", arg: 2, scope: !1633, file: !115, line: 213, type: !10)
!1637 = !DILocation(line: 213, column: 46, scope: !1633)
!1638 = !DILocalVariable(name: "source", arg: 3, scope: !1633, file: !115, line: 213, type: !10)
!1639 = !DILocation(line: 213, column: 65, scope: !1633)
!1640 = !DILocation(line: 214, column: 3, scope: !1633)
!1641 = !DILocation(line: 214, column: 3, scope: !1633)
!1642 = !DILocation(line: 215, column: 37, scope: !1633)
!1643 = !DILocation(line: 215, column: 55, scope: !1633)
!1644 = !DILocation(line: 215, column: 15, scope: !1633)
!1645 = !DILocation(line: 215, column: 15, scope: !1633)
!1646 = !DILocation(line: 216, column: 16, scope: !1633)
!1647 = !DILocation(line: 214, column: 3, scope: !1633)
!1648 = !DILocation(line: 214, column: 3, scope: !1633)
!1649 = !{!107, !146, !10, !10}
!1650 = !DISubroutineType(types: !1649)
!1651 = distinct !DISubprogram(name: "support.namespace-bytes.copy-name", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2ecopy_2dname.2032", scope: !115, file: !115, line: 228, type: !1650, scopeLine: 228, spFlags: DISPFlagDefinition, unit: !2)
!1652 = !DILocalVariable(name: "region", arg: 1, scope: !1651, file: !115, line: 228, type: !146)
!1653 = !DILocation(line: 228, column: 23, scope: !1651)
!1654 = !DILocalVariable(name: "destination", arg: 2, scope: !1651, file: !115, line: 228, type: !10)
!1655 = !DILocation(line: 228, column: 50, scope: !1651)
!1656 = !DILocalVariable(name: "source", arg: 3, scope: !1651, file: !115, line: 228, type: !10)
!1657 = !DILocation(line: 228, column: 69, scope: !1651)
!1658 = !DILocation(line: 229, column: 3, scope: !1651)
!1659 = !DILocation(line: 229, column: 3, scope: !1651)
!1660 = !DILocation(line: 230, column: 34, scope: !1651)
!1661 = !DILocation(line: 230, column: 53, scope: !1651)
!1662 = !DILocation(line: 230, column: 15, scope: !1651)
!1663 = !DILocation(line: 230, column: 15, scope: !1651)
!1664 = !DILocation(line: 231, column: 16, scope: !1651)
!1665 = !DILocation(line: 229, column: 3, scope: !1651)
!1666 = !DILocation(line: 229, column: 3, scope: !1651)
!1667 = !{!107, !146, !10, !10}
!1668 = !DISubroutineType(types: !1667)
!1669 = distinct !DISubprogram(name: "support.namespace-metadata.write", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ewrite.2033", scope: !116, file: !116, line: 11, type: !1668, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2)
!1670 = !DILocalVariable(name: "region", arg: 1, scope: !1669, file: !116, line: 11, type: !146)
!1671 = !DILocation(line: 11, column: 15, scope: !1669)
!1672 = !DILocalVariable(name: "offset", arg: 2, scope: !1669, file: !116, line: 11, type: !10)
!1673 = !DILocation(line: 11, column: 42, scope: !1669)
!1674 = !DILocalVariable(name: "value", arg: 3, scope: !1669, file: !116, line: 11, type: !10)
!1675 = !DILocation(line: 11, column: 56, scope: !1669)
!1676 = !DILocation(line: 12, column: 3, scope: !1669)
!1677 = !DILocation(line: 12, column: 3, scope: !1669)
!1678 = !{!107, !146, !10}
!1679 = !DISubroutineType(types: !1678)
!1680 = distinct !DISubprogram(name: "support.namespace-metadata.parent-times", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eparent_2dtimes.2046", scope: !116, file: !116, line: 103, type: !1679, scopeLine: 103, spFlags: DISPFlagDefinition, unit: !2)
!1681 = !DILocalVariable(name: "region", arg: 1, scope: !1680, file: !116, line: 103, type: !146)
!1682 = !DILocation(line: 103, column: 22, scope: !1680)
!1683 = !DILocalVariable(name: "seconds", arg: 2, scope: !1680, file: !116, line: 103, type: !10)
!1684 = !DILocation(line: 103, column: 49, scope: !1680)
!1685 = !DILocation(line: 104, column: 15, scope: !1680)
!1686 = !DILocalVariable(name: "modified", scope: !1680, file: !116, line: 104, type: !107)
!1687 = !DILocation(line: 104, column: 3, scope: !1680)
!1688 = !DILocation(line: 105, column: 14, scope: !1680)
!1689 = !DILocalVariable(name: "changed", scope: !1680, file: !116, line: 105, type: !107)
!1690 = !DILocation(line: 105, column: 3, scope: !1680)
!1691 = !DILocation(line: 106, column: 3, scope: !1680)
!1692 = !DILocation(line: 106, column: 3, scope: !1680)
!1693 = !{!107, !146, !182, !10}
!1694 = !DISubroutineType(types: !1693)
!1695 = distinct !DISubprogram(name: "support.namespace-metadata.link-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2elink_2deffect.2048", scope: !116, file: !116, line: 108, type: !1694, scopeLine: 108, spFlags: DISPFlagDefinition, unit: !2)
!1696 = !DILocalVariable(name: "region", arg: 1, scope: !1695, file: !116, line: 108, type: !146)
!1697 = !DILocation(line: 108, column: 21, scope: !1695)
!1698 = !DILocation(line: 108, column: 48, scope: !1695)
!1699 = !DILocation(line: 108, column: 48, scope: !1695)
!1700 = !DILocation(line: 108, column: 48, scope: !1695)
!1701 = !DILocation(line: 108, column: 48, scope: !1695)
!1702 = !DILocation(line: 108, column: 48, scope: !1695)
!1703 = !DILocation(line: 108, column: 48, scope: !1695)
!1704 = !DILocation(line: 108, column: 48, scope: !1695)
!1705 = !DILocation(line: 108, column: 48, scope: !1695)
!1706 = !DILocation(line: 108, column: 48, scope: !1695)
!1707 = !DILocation(line: 108, column: 48, scope: !1695)
!1708 = !DILocation(line: 108, column: 48, scope: !1695)
!1709 = !DILocation(line: 108, column: 48, scope: !1695)
!1710 = !DILocation(line: 108, column: 48, scope: !1695)
!1711 = !DILocation(line: 108, column: 48, scope: !1695)
!1712 = !DILocation(line: 108, column: 48, scope: !1695)
!1713 = !DILocation(line: 108, column: 48, scope: !1695)
!1714 = !DILocalVariable(name: "facts", arg: 2, scope: !1695, file: !116, line: 108, type: !182)
!1715 = !DILocation(line: 108, column: 48, scope: !1695)
!1716 = !DILocalVariable(name: "seconds", arg: 3, scope: !1695, file: !116, line: 108, type: !10)
!1717 = !DILocation(line: 108, column: 227, scope: !1695)
!1718 = !DILocation(line: 109, column: 11, scope: !1695)
!1719 = !DILocalVariable(name: "base", scope: !1695, file: !116, line: 109, type: !10)
!1720 = !DILocation(line: 109, column: 3, scope: !1695)
!1721 = !DILocation(line: 110, column: 12, scope: !1695)
!1722 = !DILocalVariable(name: "entry", scope: !1695, file: !116, line: 110, type: !10)
!1723 = !DILocation(line: 110, column: 3, scope: !1695)
!1724 = !DILocation(line: 111, column: 58, scope: !1695)
!1725 = !DILocation(line: 111, column: 15, scope: !1695)
!1726 = !DILocalVariable(name: "effect-0", scope: !1695, file: !116, line: 111, type: !107)
!1727 = !DILocation(line: 111, column: 3, scope: !1695)
!1728 = !DILocation(line: 112, column: 15, scope: !1695)
!1729 = !DILocalVariable(name: "effect-1", scope: !1695, file: !116, line: 112, type: !107)
!1730 = !DILocation(line: 112, column: 3, scope: !1695)
!1731 = !DILocation(line: 113, column: 30, scope: !1695)
!1732 = !DILocation(line: 113, column: 15, scope: !1695)
!1733 = !DILocalVariable(name: "effect-2", scope: !1695, file: !116, line: 113, type: !107)
!1734 = !DILocation(line: 113, column: 3, scope: !1695)
!1735 = !DILocation(line: 114, column: 30, scope: !1695)
!1736 = !DILocation(line: 114, column: 42, scope: !1695)
!1737 = !DILocation(line: 114, column: 15, scope: !1695)
!1738 = !DILocalVariable(name: "effect-3", scope: !1695, file: !116, line: 114, type: !107)
!1739 = !DILocation(line: 114, column: 3, scope: !1695)
!1740 = !DILocation(line: 115, column: 30, scope: !1695)
!1741 = !DILocation(line: 115, column: 15, scope: !1695)
!1742 = !DILocalVariable(name: "effect-4", scope: !1695, file: !116, line: 115, type: !107)
!1743 = !DILocation(line: 115, column: 3, scope: !1695)
!1744 = !DILocation(line: 116, column: 30, scope: !1695)
!1745 = !DILocation(line: 116, column: 15, scope: !1695)
!1746 = !DILocalVariable(name: "effect-5", scope: !1695, file: !116, line: 116, type: !107)
!1747 = !DILocation(line: 116, column: 3, scope: !1695)
!1748 = !DILocation(line: 117, column: 86, scope: !1695)
!1749 = !DILocation(line: 117, column: 70, scope: !1695)
!1750 = !DILocation(line: 117, column: 54, scope: !1695)
!1751 = !DILocation(line: 117, column: 38, scope: !1695)
!1752 = !DILocation(line: 117, column: 22, scope: !1695)
!1753 = !DILocalVariable(name: "objects-changed", scope: !1695, file: !116, line: 117, type: !107)
!1754 = !DILocation(line: 117, column: 3, scope: !1695)
!1755 = !DILocation(line: 118, column: 21, scope: !1695)
!1756 = !DILocalVariable(name: "parent-changed", scope: !1695, file: !116, line: 118, type: !107)
!1757 = !DILocation(line: 118, column: 3, scope: !1695)
!1758 = !DILocation(line: 119, column: 3, scope: !1695)
!1759 = !DILocation(line: 119, column: 3, scope: !1695)
!1760 = !{!107, !146, !182, !10}
!1761 = !DISubroutineType(types: !1760)
!1762 = distinct !DISubprogram(name: "support.namespace-metadata.move-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2emove_2deffect.2124", scope: !116, file: !116, line: 121, type: !1761, scopeLine: 121, spFlags: DISPFlagDefinition, unit: !2)
!1763 = !DILocalVariable(name: "region", arg: 1, scope: !1762, file: !116, line: 121, type: !146)
!1764 = !DILocation(line: 121, column: 21, scope: !1762)
!1765 = !DILocation(line: 121, column: 48, scope: !1762)
!1766 = !DILocation(line: 121, column: 48, scope: !1762)
!1767 = !DILocation(line: 121, column: 48, scope: !1762)
!1768 = !DILocation(line: 121, column: 48, scope: !1762)
!1769 = !DILocation(line: 121, column: 48, scope: !1762)
!1770 = !DILocation(line: 121, column: 48, scope: !1762)
!1771 = !DILocation(line: 121, column: 48, scope: !1762)
!1772 = !DILocation(line: 121, column: 48, scope: !1762)
!1773 = !DILocation(line: 121, column: 48, scope: !1762)
!1774 = !DILocation(line: 121, column: 48, scope: !1762)
!1775 = !DILocation(line: 121, column: 48, scope: !1762)
!1776 = !DILocation(line: 121, column: 48, scope: !1762)
!1777 = !DILocation(line: 121, column: 48, scope: !1762)
!1778 = !DILocation(line: 121, column: 48, scope: !1762)
!1779 = !DILocation(line: 121, column: 48, scope: !1762)
!1780 = !DILocation(line: 121, column: 48, scope: !1762)
!1781 = !DILocalVariable(name: "facts", arg: 2, scope: !1762, file: !116, line: 121, type: !182)
!1782 = !DILocation(line: 121, column: 48, scope: !1762)
!1783 = !DILocalVariable(name: "seconds", arg: 3, scope: !1762, file: !116, line: 121, type: !10)
!1784 = !DILocation(line: 121, column: 227, scope: !1762)
!1785 = !DILocation(line: 122, column: 12, scope: !1762)
!1786 = !DILocalVariable(name: "entry", scope: !1762, file: !116, line: 122, type: !10)
!1787 = !DILocation(line: 122, column: 3, scope: !1762)
!1788 = !DILocation(line: 123, column: 58, scope: !1762)
!1789 = !DILocation(line: 123, column: 15, scope: !1762)
!1790 = !DILocalVariable(name: "effect-0", scope: !1762, file: !116, line: 123, type: !107)
!1791 = !DILocation(line: 123, column: 3, scope: !1762)
!1792 = !DILocation(line: 124, column: 30, scope: !1762)
!1793 = !DILocation(line: 124, column: 15, scope: !1762)
!1794 = !DILocalVariable(name: "effect-1", scope: !1762, file: !116, line: 124, type: !107)
!1795 = !DILocation(line: 124, column: 3, scope: !1762)
!1796 = !DILocation(line: 125, column: 31, scope: !1762)
!1797 = !DILocation(line: 125, column: 31, scope: !1762)
!1798 = !DILocation(line: 125, column: 15, scope: !1762)
!1799 = !DILocalVariable(name: "effect-2", scope: !1762, file: !116, line: 125, type: !107)
!1800 = !DILocation(line: 125, column: 3, scope: !1762)
!1801 = !DILocation(line: 126, column: 38, scope: !1762)
!1802 = !DILocation(line: 126, column: 22, scope: !1762)
!1803 = !DILocalVariable(name: "objects-changed", scope: !1762, file: !116, line: 126, type: !107)
!1804 = !DILocation(line: 126, column: 3, scope: !1762)
!1805 = !DILocation(line: 127, column: 21, scope: !1762)
!1806 = !DILocalVariable(name: "parent-changed", scope: !1762, file: !116, line: 127, type: !107)
!1807 = !DILocation(line: 127, column: 3, scope: !1762)
!1808 = !DILocation(line: 128, column: 3, scope: !1762)
!1809 = !DILocation(line: 128, column: 3, scope: !1762)
!1810 = !{!107, !146, !10}
!1811 = !DISubroutineType(types: !1810)
!1812 = distinct !DISubprogram(name: "support.namespace-bytes.clear-word", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dword.2134", scope: !115, file: !115, line: 161, type: !1811, scopeLine: 161, spFlags: DISPFlagDefinition, unit: !2)
!1813 = !DILocalVariable(name: "region", arg: 1, scope: !1812, file: !115, line: 161, type: !146)
!1814 = !DILocation(line: 161, column: 20, scope: !1812)
!1815 = !DILocalVariable(name: "destination", arg: 2, scope: !1812, file: !115, line: 161, type: !10)
!1816 = !DILocation(line: 161, column: 47, scope: !1812)
!1817 = !DILocation(line: 162, column: 3, scope: !1812)
!1818 = !DILocation(line: 162, column: 3, scope: !1812)
!1819 = !{!107, !146, !10}
!1820 = !DISubroutineType(types: !1819)
!1821 = distinct !DISubprogram(name: "support.namespace-bytes.clear-pair", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dpair.2136", scope: !115, file: !115, line: 173, type: !1820, scopeLine: 173, spFlags: DISPFlagDefinition, unit: !2)
!1822 = !DILocalVariable(name: "region", arg: 1, scope: !1821, file: !115, line: 173, type: !146)
!1823 = !DILocation(line: 173, column: 20, scope: !1821)
!1824 = !DILocalVariable(name: "destination", arg: 2, scope: !1821, file: !115, line: 173, type: !10)
!1825 = !DILocation(line: 173, column: 47, scope: !1821)
!1826 = !DILocation(line: 174, column: 3, scope: !1821)
!1827 = !DILocation(line: 174, column: 3, scope: !1821)
!1828 = !DILocation(line: 175, column: 35, scope: !1821)
!1829 = !DILocation(line: 175, column: 15, scope: !1821)
!1830 = !DILocation(line: 175, column: 15, scope: !1821)
!1831 = !DILocation(line: 176, column: 16, scope: !1821)
!1832 = !DILocation(line: 174, column: 3, scope: !1821)
!1833 = !DILocation(line: 174, column: 3, scope: !1821)
!1834 = !{!107, !146, !10}
!1835 = !DISubroutineType(types: !1834)
!1836 = distinct !DISubprogram(name: "support.namespace-bytes.clear-block", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dblock.2140", scope: !115, file: !115, line: 188, type: !1835, scopeLine: 188, spFlags: DISPFlagDefinition, unit: !2)
!1837 = !DILocalVariable(name: "region", arg: 1, scope: !1836, file: !115, line: 188, type: !146)
!1838 = !DILocation(line: 188, column: 21, scope: !1836)
!1839 = !DILocalVariable(name: "destination", arg: 2, scope: !1836, file: !115, line: 188, type: !10)
!1840 = !DILocation(line: 188, column: 48, scope: !1836)
!1841 = !DILocation(line: 189, column: 3, scope: !1836)
!1842 = !DILocation(line: 189, column: 3, scope: !1836)
!1843 = !DILocation(line: 190, column: 35, scope: !1836)
!1844 = !DILocation(line: 190, column: 15, scope: !1836)
!1845 = !DILocation(line: 190, column: 15, scope: !1836)
!1846 = !DILocation(line: 191, column: 16, scope: !1836)
!1847 = !DILocation(line: 189, column: 3, scope: !1836)
!1848 = !DILocation(line: 189, column: 3, scope: !1836)
!1849 = !{!107, !146, !10}
!1850 = !DISubroutineType(types: !1849)
!1851 = distinct !DISubprogram(name: "support.namespace-bytes.clear-quarter", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dquarter.2148", scope: !115, file: !115, line: 203, type: !1850, scopeLine: 203, spFlags: DISPFlagDefinition, unit: !2)
!1852 = !DILocalVariable(name: "region", arg: 1, scope: !1851, file: !115, line: 203, type: !146)
!1853 = !DILocation(line: 203, column: 23, scope: !1851)
!1854 = !DILocalVariable(name: "destination", arg: 2, scope: !1851, file: !115, line: 203, type: !10)
!1855 = !DILocation(line: 203, column: 50, scope: !1851)
!1856 = !DILocation(line: 204, column: 3, scope: !1851)
!1857 = !DILocation(line: 204, column: 3, scope: !1851)
!1858 = !DILocation(line: 205, column: 36, scope: !1851)
!1859 = !DILocation(line: 205, column: 15, scope: !1851)
!1860 = !DILocation(line: 205, column: 15, scope: !1851)
!1861 = !DILocation(line: 206, column: 16, scope: !1851)
!1862 = !DILocation(line: 204, column: 3, scope: !1851)
!1863 = !DILocation(line: 204, column: 3, scope: !1851)
!1864 = !{!107, !146, !10}
!1865 = !DISubroutineType(types: !1864)
!1866 = distinct !DISubprogram(name: "support.namespace-bytes.clear-half", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dhalf.2164", scope: !115, file: !115, line: 218, type: !1865, scopeLine: 218, spFlags: DISPFlagDefinition, unit: !2)
!1867 = !DILocalVariable(name: "region", arg: 1, scope: !1866, file: !115, line: 218, type: !146)
!1868 = !DILocation(line: 218, column: 20, scope: !1866)
!1869 = !DILocalVariable(name: "destination", arg: 2, scope: !1866, file: !115, line: 218, type: !10)
!1870 = !DILocation(line: 218, column: 47, scope: !1866)
!1871 = !DILocation(line: 219, column: 3, scope: !1866)
!1872 = !DILocation(line: 219, column: 3, scope: !1866)
!1873 = !DILocation(line: 220, column: 38, scope: !1866)
!1874 = !DILocation(line: 220, column: 15, scope: !1866)
!1875 = !DILocation(line: 220, column: 15, scope: !1866)
!1876 = !DILocation(line: 221, column: 16, scope: !1866)
!1877 = !DILocation(line: 219, column: 3, scope: !1866)
!1878 = !DILocation(line: 219, column: 3, scope: !1866)
!1879 = !{!107, !146, !10}
!1880 = !DISubroutineType(types: !1879)
!1881 = distinct !DISubprogram(name: "support.namespace-bytes.clear-name", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dbytes_2eclear_2dname.2196", scope: !115, file: !115, line: 233, type: !1880, scopeLine: 233, spFlags: DISPFlagDefinition, unit: !2)
!1882 = !DILocalVariable(name: "region", arg: 1, scope: !1881, file: !115, line: 233, type: !146)
!1883 = !DILocation(line: 233, column: 24, scope: !1881)
!1884 = !DILocalVariable(name: "destination", arg: 2, scope: !1881, file: !115, line: 233, type: !10)
!1885 = !DILocation(line: 233, column: 51, scope: !1881)
!1886 = !DILocation(line: 234, column: 3, scope: !1881)
!1887 = !DILocation(line: 234, column: 3, scope: !1881)
!1888 = !DILocation(line: 235, column: 35, scope: !1881)
!1889 = !DILocation(line: 235, column: 15, scope: !1881)
!1890 = !DILocation(line: 235, column: 15, scope: !1881)
!1891 = !DILocation(line: 236, column: 16, scope: !1881)
!1892 = !DILocation(line: 234, column: 3, scope: !1881)
!1893 = !DILocation(line: 234, column: 3, scope: !1881)
!1894 = !{!107, !146, !182, !10}
!1895 = !DISubroutineType(types: !1894)
!1896 = distinct !DISubprogram(name: "support.namespace-metadata.replace-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2ereplace_2deffect.2212", scope: !116, file: !116, line: 130, type: !1895, scopeLine: 130, spFlags: DISPFlagDefinition, unit: !2)
!1897 = !DILocalVariable(name: "region", arg: 1, scope: !1896, file: !116, line: 130, type: !146)
!1898 = !DILocation(line: 130, column: 24, scope: !1896)
!1899 = !DILocation(line: 130, column: 51, scope: !1896)
!1900 = !DILocation(line: 130, column: 51, scope: !1896)
!1901 = !DILocation(line: 130, column: 51, scope: !1896)
!1902 = !DILocation(line: 130, column: 51, scope: !1896)
!1903 = !DILocation(line: 130, column: 51, scope: !1896)
!1904 = !DILocation(line: 130, column: 51, scope: !1896)
!1905 = !DILocation(line: 130, column: 51, scope: !1896)
!1906 = !DILocation(line: 130, column: 51, scope: !1896)
!1907 = !DILocation(line: 130, column: 51, scope: !1896)
!1908 = !DILocation(line: 130, column: 51, scope: !1896)
!1909 = !DILocation(line: 130, column: 51, scope: !1896)
!1910 = !DILocation(line: 130, column: 51, scope: !1896)
!1911 = !DILocation(line: 130, column: 51, scope: !1896)
!1912 = !DILocation(line: 130, column: 51, scope: !1896)
!1913 = !DILocation(line: 130, column: 51, scope: !1896)
!1914 = !DILocation(line: 130, column: 51, scope: !1896)
!1915 = !DILocalVariable(name: "facts", arg: 2, scope: !1896, file: !116, line: 130, type: !182)
!1916 = !DILocation(line: 130, column: 51, scope: !1896)
!1917 = !DILocalVariable(name: "seconds", arg: 3, scope: !1896, file: !116, line: 130, type: !10)
!1918 = !DILocation(line: 130, column: 230, scope: !1896)
!1919 = !DILocation(line: 131, column: 13, scope: !1896)
!1920 = !DILocalVariable(name: "source", scope: !1896, file: !116, line: 131, type: !10)
!1921 = !DILocation(line: 131, column: 3, scope: !1896)
!1922 = !DILocation(line: 132, column: 13, scope: !1896)
!1923 = !DILocalVariable(name: "victim", scope: !1896, file: !116, line: 132, type: !10)
!1924 = !DILocation(line: 132, column: 3, scope: !1896)
!1925 = !DILocation(line: 133, column: 47, scope: !1896)
!1926 = !DILocation(line: 133, column: 33, scope: !1896)
!1927 = !DILocation(line: 133, column: 33, scope: !1896)
!1928 = !DILocation(line: 133, column: 22, scope: !1896)
!1929 = !DILocalVariable(name: "remaining", scope: !1896, file: !116, line: 133, type: !10)
!1930 = !DILocation(line: 133, column: 3, scope: !1896)
!1931 = !DILocation(line: 134, column: 30, scope: !1896)
!1932 = !DILocation(line: 134, column: 15, scope: !1896)
!1933 = !DILocalVariable(name: "effect-0", scope: !1896, file: !116, line: 134, type: !107)
!1934 = !DILocation(line: 134, column: 3, scope: !1896)
!1935 = !DILocation(line: 135, column: 15, scope: !1896)
!1936 = !DILocalVariable(name: "effect-1", scope: !1896, file: !116, line: 135, type: !107)
!1937 = !DILocation(line: 135, column: 3, scope: !1896)
!1938 = !DILocation(line: 136, column: 30, scope: !1896)
!1939 = !DILocation(line: 136, column: 15, scope: !1896)
!1940 = !DILocalVariable(name: "effect-2", scope: !1896, file: !116, line: 136, type: !107)
!1941 = !DILocation(line: 136, column: 3, scope: !1896)
!1942 = !DILocation(line: 137, column: 59, scope: !1896)
!1943 = !DILocation(line: 137, column: 15, scope: !1896)
!1944 = !DILocalVariable(name: "effect-3", scope: !1896, file: !116, line: 137, type: !107)
!1945 = !DILocation(line: 137, column: 3, scope: !1896)
!1946 = !DILocation(line: 138, column: 30, scope: !1896)
!1947 = !DILocation(line: 138, column: 15, scope: !1896)
!1948 = !DILocalVariable(name: "effect-4", scope: !1896, file: !116, line: 138, type: !107)
!1949 = !DILocation(line: 138, column: 3, scope: !1896)
!1950 = !DILocation(line: 139, column: 30, scope: !1896)
!1951 = !DILocation(line: 139, column: 15, scope: !1896)
!1952 = !DILocalVariable(name: "effect-5", scope: !1896, file: !116, line: 139, type: !107)
!1953 = !DILocation(line: 139, column: 3, scope: !1896)
!1954 = !DILocation(line: 140, column: 31, scope: !1896)
!1955 = !DILocation(line: 140, column: 31, scope: !1896)
!1956 = !DILocation(line: 140, column: 15, scope: !1896)
!1957 = !DILocalVariable(name: "effect-6", scope: !1896, file: !116, line: 140, type: !107)
!1958 = !DILocation(line: 140, column: 3, scope: !1896)
!1959 = !DILocation(line: 141, column: 102, scope: !1896)
!1960 = !DILocation(line: 141, column: 86, scope: !1896)
!1961 = !DILocation(line: 141, column: 70, scope: !1896)
!1962 = !DILocation(line: 141, column: 54, scope: !1896)
!1963 = !DILocation(line: 141, column: 38, scope: !1896)
!1964 = !DILocation(line: 141, column: 22, scope: !1896)
!1965 = !DILocalVariable(name: "objects-changed", scope: !1896, file: !116, line: 141, type: !107)
!1966 = !DILocation(line: 141, column: 3, scope: !1896)
!1967 = !DILocation(line: 142, column: 21, scope: !1896)
!1968 = !DILocalVariable(name: "parent-changed", scope: !1896, file: !116, line: 142, type: !107)
!1969 = !DILocation(line: 142, column: 3, scope: !1896)
!1970 = !DILocation(line: 143, column: 3, scope: !1896)
!1971 = !DILocation(line: 143, column: 3, scope: !1896)
!1972 = !{!107, !146, !182, !10}
!1973 = !DISubroutineType(types: !1972)
!1974 = distinct !DISubprogram(name: "support.namespace-metadata.exchange-effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eexchange_2deffect.2229", scope: !116, file: !116, line: 145, type: !1973, scopeLine: 145, spFlags: DISPFlagDefinition, unit: !2)
!1975 = !DILocalVariable(name: "region", arg: 1, scope: !1974, file: !116, line: 145, type: !146)
!1976 = !DILocation(line: 145, column: 25, scope: !1974)
!1977 = !DILocation(line: 145, column: 52, scope: !1974)
!1978 = !DILocation(line: 145, column: 52, scope: !1974)
!1979 = !DILocation(line: 145, column: 52, scope: !1974)
!1980 = !DILocation(line: 145, column: 52, scope: !1974)
!1981 = !DILocation(line: 145, column: 52, scope: !1974)
!1982 = !DILocation(line: 145, column: 52, scope: !1974)
!1983 = !DILocation(line: 145, column: 52, scope: !1974)
!1984 = !DILocation(line: 145, column: 52, scope: !1974)
!1985 = !DILocation(line: 145, column: 52, scope: !1974)
!1986 = !DILocation(line: 145, column: 52, scope: !1974)
!1987 = !DILocation(line: 145, column: 52, scope: !1974)
!1988 = !DILocation(line: 145, column: 52, scope: !1974)
!1989 = !DILocation(line: 145, column: 52, scope: !1974)
!1990 = !DILocation(line: 145, column: 52, scope: !1974)
!1991 = !DILocation(line: 145, column: 52, scope: !1974)
!1992 = !DILocation(line: 145, column: 52, scope: !1974)
!1993 = !DILocalVariable(name: "facts", arg: 2, scope: !1974, file: !116, line: 145, type: !182)
!1994 = !DILocation(line: 145, column: 52, scope: !1974)
!1995 = !DILocalVariable(name: "seconds", arg: 3, scope: !1974, file: !116, line: 145, type: !10)
!1996 = !DILocation(line: 145, column: 231, scope: !1974)
!1997 = !DILocation(line: 146, column: 13, scope: !1974)
!1998 = !DILocalVariable(name: "source", scope: !1974, file: !116, line: 146, type: !10)
!1999 = !DILocation(line: 146, column: 3, scope: !1974)
!2000 = !DILocation(line: 147, column: 15, scope: !1974)
!2001 = !DILocalVariable(name: "effect-0", scope: !1974, file: !116, line: 147, type: !107)
!2002 = !DILocation(line: 147, column: 3, scope: !1974)
!2003 = !DILocation(line: 148, column: 30, scope: !1974)
!2004 = !DILocation(line: 148, column: 15, scope: !1974)
!2005 = !DILocalVariable(name: "effect-1", scope: !1974, file: !116, line: 148, type: !107)
!2006 = !DILocation(line: 148, column: 3, scope: !1974)
!2007 = !DILocation(line: 149, column: 31, scope: !1974)
!2008 = !DILocation(line: 149, column: 31, scope: !1974)
!2009 = !DILocation(line: 149, column: 15, scope: !1974)
!2010 = !DILocalVariable(name: "effect-2", scope: !1974, file: !116, line: 149, type: !107)
!2011 = !DILocation(line: 149, column: 3, scope: !1974)
!2012 = !DILocation(line: 150, column: 31, scope: !1974)
!2013 = !DILocation(line: 150, column: 31, scope: !1974)
!2014 = !DILocation(line: 150, column: 15, scope: !1974)
!2015 = !DILocalVariable(name: "effect-3", scope: !1974, file: !116, line: 150, type: !107)
!2016 = !DILocation(line: 150, column: 3, scope: !1974)
!2017 = !DILocation(line: 151, column: 54, scope: !1974)
!2018 = !DILocation(line: 151, column: 38, scope: !1974)
!2019 = !DILocation(line: 151, column: 22, scope: !1974)
!2020 = !DILocalVariable(name: "objects-changed", scope: !1974, file: !116, line: 151, type: !107)
!2021 = !DILocation(line: 151, column: 3, scope: !1974)
!2022 = !DILocation(line: 152, column: 21, scope: !1974)
!2023 = !DILocalVariable(name: "parent-changed", scope: !1974, file: !116, line: 152, type: !107)
!2024 = !DILocation(line: 152, column: 3, scope: !1974)
!2025 = !DILocation(line: 153, column: 3, scope: !1974)
!2026 = !DILocation(line: 153, column: 3, scope: !1974)
!2027 = !{!107, !146, !182, !10, !10}
!2028 = !DISubroutineType(types: !2027)
!2029 = distinct !DISubprogram(name: "support.namespace-metadata.effect-replace-or-exchange", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2dreplace_2dor_2dexchange.2230", scope: !116, file: !116, line: 155, type: !2028, scopeLine: 155, spFlags: DISPFlagDefinition, unit: !2)
!2030 = !DILocalVariable(name: "region", arg: 1, scope: !2029, file: !116, line: 155, type: !146)
!2031 = !DILocation(line: 155, column: 36, scope: !2029)
!2032 = !DILocation(line: 155, column: 63, scope: !2029)
!2033 = !DILocation(line: 155, column: 63, scope: !2029)
!2034 = !DILocation(line: 155, column: 63, scope: !2029)
!2035 = !DILocation(line: 155, column: 63, scope: !2029)
!2036 = !DILocation(line: 155, column: 63, scope: !2029)
!2037 = !DILocation(line: 155, column: 63, scope: !2029)
!2038 = !DILocation(line: 155, column: 63, scope: !2029)
!2039 = !DILocation(line: 155, column: 63, scope: !2029)
!2040 = !DILocation(line: 155, column: 63, scope: !2029)
!2041 = !DILocation(line: 155, column: 63, scope: !2029)
!2042 = !DILocation(line: 155, column: 63, scope: !2029)
!2043 = !DILocation(line: 155, column: 63, scope: !2029)
!2044 = !DILocation(line: 155, column: 63, scope: !2029)
!2045 = !DILocation(line: 155, column: 63, scope: !2029)
!2046 = !DILocation(line: 155, column: 63, scope: !2029)
!2047 = !DILocation(line: 155, column: 63, scope: !2029)
!2048 = !DILocalVariable(name: "facts", arg: 2, scope: !2029, file: !116, line: 155, type: !182)
!2049 = !DILocation(line: 155, column: 63, scope: !2029)
!2050 = !DILocalVariable(name: "operation", arg: 3, scope: !2029, file: !116, line: 155, type: !10)
!2051 = !DILocation(line: 155, column: 242, scope: !2029)
!2052 = !DILocalVariable(name: "seconds", arg: 4, scope: !2029, file: !116, line: 155, type: !10)
!2053 = !DILocation(line: 155, column: 259, scope: !2029)
!2054 = !DILocation(line: 156, column: 3, scope: !2029)
!2055 = !DILocation(line: 156, column: 3, scope: !2029)
!2056 = !DILocation(line: 156, column: 3, scope: !2029)
!2057 = !DILocation(line: 156, column: 3, scope: !2029)
!2058 = !DILocation(line: 157, column: 15, scope: !2029)
!2059 = !DILocation(line: 157, column: 15, scope: !2029)
!2060 = !DILocation(line: 157, column: 15, scope: !2029)
!2061 = !DILocation(line: 157, column: 15, scope: !2029)
!2062 = !DILocation(line: 157, column: 15, scope: !2029)
!2063 = !DILocation(line: 157, column: 15, scope: !2029)
!2064 = !DILocation(line: 157, column: 15, scope: !2029)
!2065 = !DILocation(line: 157, column: 15, scope: !2029)
!2066 = !DILocation(line: 157, column: 15, scope: !2029)
!2067 = !DILocation(line: 157, column: 15, scope: !2029)
!2068 = !DILocation(line: 157, column: 15, scope: !2029)
!2069 = !DILocation(line: 157, column: 15, scope: !2029)
!2070 = !DILocation(line: 157, column: 15, scope: !2029)
!2071 = !DILocation(line: 157, column: 15, scope: !2029)
!2072 = !DILocation(line: 157, column: 15, scope: !2029)
!2073 = !DILocation(line: 157, column: 15, scope: !2029)
!2074 = !DILocation(line: 157, column: 15, scope: !2029)
!2075 = !DILocation(line: 157, column: 15, scope: !2029)
!2076 = !DILocation(line: 158, column: 16, scope: !2029)
!2077 = !DILocation(line: 158, column: 16, scope: !2029)
!2078 = !DILocation(line: 158, column: 16, scope: !2029)
!2079 = !DILocation(line: 158, column: 16, scope: !2029)
!2080 = !DILocation(line: 158, column: 16, scope: !2029)
!2081 = !DILocation(line: 158, column: 16, scope: !2029)
!2082 = !DILocation(line: 158, column: 16, scope: !2029)
!2083 = !DILocation(line: 158, column: 16, scope: !2029)
!2084 = !DILocation(line: 158, column: 16, scope: !2029)
!2085 = !DILocation(line: 158, column: 16, scope: !2029)
!2086 = !DILocation(line: 158, column: 16, scope: !2029)
!2087 = !DILocation(line: 158, column: 16, scope: !2029)
!2088 = !DILocation(line: 158, column: 16, scope: !2029)
!2089 = !DILocation(line: 158, column: 16, scope: !2029)
!2090 = !DILocation(line: 158, column: 16, scope: !2029)
!2091 = !DILocation(line: 158, column: 16, scope: !2029)
!2092 = !DILocation(line: 158, column: 16, scope: !2029)
!2093 = !DILocation(line: 158, column: 16, scope: !2029)
!2094 = !DILocation(line: 156, column: 3, scope: !2029)
!2095 = !DILocation(line: 156, column: 3, scope: !2029)
!2096 = !{!107, !146, !182, !10, !10}
!2097 = !DISubroutineType(types: !2096)
!2098 = distinct !DISubprogram(name: "support.namespace-metadata.effect-rename", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect_2drename.2231", scope: !116, file: !116, line: 160, type: !2097, scopeLine: 160, spFlags: DISPFlagDefinition, unit: !2)
!2099 = !DILocalVariable(name: "region", arg: 1, scope: !2098, file: !116, line: 160, type: !146)
!2100 = !DILocation(line: 160, column: 23, scope: !2098)
!2101 = !DILocation(line: 160, column: 50, scope: !2098)
!2102 = !DILocation(line: 160, column: 50, scope: !2098)
!2103 = !DILocation(line: 160, column: 50, scope: !2098)
!2104 = !DILocation(line: 160, column: 50, scope: !2098)
!2105 = !DILocation(line: 160, column: 50, scope: !2098)
!2106 = !DILocation(line: 160, column: 50, scope: !2098)
!2107 = !DILocation(line: 160, column: 50, scope: !2098)
!2108 = !DILocation(line: 160, column: 50, scope: !2098)
!2109 = !DILocation(line: 160, column: 50, scope: !2098)
!2110 = !DILocation(line: 160, column: 50, scope: !2098)
!2111 = !DILocation(line: 160, column: 50, scope: !2098)
!2112 = !DILocation(line: 160, column: 50, scope: !2098)
!2113 = !DILocation(line: 160, column: 50, scope: !2098)
!2114 = !DILocation(line: 160, column: 50, scope: !2098)
!2115 = !DILocation(line: 160, column: 50, scope: !2098)
!2116 = !DILocation(line: 160, column: 50, scope: !2098)
!2117 = !DILocalVariable(name: "facts", arg: 2, scope: !2098, file: !116, line: 160, type: !182)
!2118 = !DILocation(line: 160, column: 50, scope: !2098)
!2119 = !DILocalVariable(name: "operation", arg: 3, scope: !2098, file: !116, line: 160, type: !10)
!2120 = !DILocation(line: 160, column: 229, scope: !2098)
!2121 = !DILocalVariable(name: "seconds", arg: 4, scope: !2098, file: !116, line: 160, type: !10)
!2122 = !DILocation(line: 160, column: 246, scope: !2098)
!2123 = !DILocation(line: 161, column: 3, scope: !2098)
!2124 = !DILocation(line: 161, column: 3, scope: !2098)
!2125 = !DILocation(line: 161, column: 3, scope: !2098)
!2126 = !DILocation(line: 161, column: 3, scope: !2098)
!2127 = !DILocation(line: 162, column: 15, scope: !2098)
!2128 = !DILocation(line: 162, column: 15, scope: !2098)
!2129 = !DILocation(line: 162, column: 15, scope: !2098)
!2130 = !DILocation(line: 162, column: 15, scope: !2098)
!2131 = !DILocation(line: 162, column: 15, scope: !2098)
!2132 = !DILocation(line: 162, column: 15, scope: !2098)
!2133 = !DILocation(line: 162, column: 15, scope: !2098)
!2134 = !DILocation(line: 162, column: 15, scope: !2098)
!2135 = !DILocation(line: 162, column: 15, scope: !2098)
!2136 = !DILocation(line: 162, column: 15, scope: !2098)
!2137 = !DILocation(line: 162, column: 15, scope: !2098)
!2138 = !DILocation(line: 162, column: 15, scope: !2098)
!2139 = !DILocation(line: 162, column: 15, scope: !2098)
!2140 = !DILocation(line: 162, column: 15, scope: !2098)
!2141 = !DILocation(line: 162, column: 15, scope: !2098)
!2142 = !DILocation(line: 162, column: 15, scope: !2098)
!2143 = !DILocation(line: 162, column: 15, scope: !2098)
!2144 = !DILocation(line: 162, column: 15, scope: !2098)
!2145 = !DILocation(line: 163, column: 16, scope: !2098)
!2146 = !DILocation(line: 163, column: 16, scope: !2098)
!2147 = !DILocation(line: 163, column: 16, scope: !2098)
!2148 = !DILocation(line: 163, column: 16, scope: !2098)
!2149 = !DILocation(line: 163, column: 16, scope: !2098)
!2150 = !DILocation(line: 163, column: 16, scope: !2098)
!2151 = !DILocation(line: 163, column: 16, scope: !2098)
!2152 = !DILocation(line: 163, column: 16, scope: !2098)
!2153 = !DILocation(line: 163, column: 16, scope: !2098)
!2154 = !DILocation(line: 163, column: 16, scope: !2098)
!2155 = !DILocation(line: 163, column: 16, scope: !2098)
!2156 = !DILocation(line: 163, column: 16, scope: !2098)
!2157 = !DILocation(line: 163, column: 16, scope: !2098)
!2158 = !DILocation(line: 163, column: 16, scope: !2098)
!2159 = !DILocation(line: 163, column: 16, scope: !2098)
!2160 = !DILocation(line: 163, column: 16, scope: !2098)
!2161 = !DILocation(line: 163, column: 16, scope: !2098)
!2162 = !DILocation(line: 163, column: 16, scope: !2098)
!2163 = !DILocation(line: 161, column: 3, scope: !2098)
!2164 = !DILocation(line: 161, column: 3, scope: !2098)
!2165 = !{!107, !146, !182, !10, !10}
!2166 = !DISubroutineType(types: !2165)
!2167 = distinct !DISubprogram(name: "support.namespace-metadata.effect", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eeffect.2232", scope: !116, file: !116, line: 165, type: !2166, scopeLine: 165, spFlags: DISPFlagDefinition, unit: !2)
!2168 = !DILocalVariable(name: "region", arg: 1, scope: !2167, file: !116, line: 165, type: !146)
!2169 = !DILocation(line: 165, column: 16, scope: !2167)
!2170 = !DILocation(line: 165, column: 43, scope: !2167)
!2171 = !DILocation(line: 165, column: 43, scope: !2167)
!2172 = !DILocation(line: 165, column: 43, scope: !2167)
!2173 = !DILocation(line: 165, column: 43, scope: !2167)
!2174 = !DILocation(line: 165, column: 43, scope: !2167)
!2175 = !DILocation(line: 165, column: 43, scope: !2167)
!2176 = !DILocation(line: 165, column: 43, scope: !2167)
!2177 = !DILocation(line: 165, column: 43, scope: !2167)
!2178 = !DILocation(line: 165, column: 43, scope: !2167)
!2179 = !DILocation(line: 165, column: 43, scope: !2167)
!2180 = !DILocation(line: 165, column: 43, scope: !2167)
!2181 = !DILocation(line: 165, column: 43, scope: !2167)
!2182 = !DILocation(line: 165, column: 43, scope: !2167)
!2183 = !DILocation(line: 165, column: 43, scope: !2167)
!2184 = !DILocation(line: 165, column: 43, scope: !2167)
!2185 = !DILocation(line: 165, column: 43, scope: !2167)
!2186 = !DILocalVariable(name: "facts", arg: 2, scope: !2167, file: !116, line: 165, type: !182)
!2187 = !DILocation(line: 165, column: 43, scope: !2167)
!2188 = !DILocalVariable(name: "operation", arg: 3, scope: !2167, file: !116, line: 165, type: !10)
!2189 = !DILocation(line: 165, column: 222, scope: !2167)
!2190 = !DILocalVariable(name: "seconds", arg: 4, scope: !2167, file: !116, line: 165, type: !10)
!2191 = !DILocation(line: 165, column: 239, scope: !2167)
!2192 = !DILocation(line: 166, column: 3, scope: !2167)
!2193 = !DILocation(line: 166, column: 3, scope: !2167)
!2194 = !DILocation(line: 166, column: 3, scope: !2167)
!2195 = !DILocation(line: 166, column: 3, scope: !2167)
!2196 = !DILocation(line: 167, column: 15, scope: !2167)
!2197 = !DILocation(line: 167, column: 15, scope: !2167)
!2198 = !DILocation(line: 167, column: 15, scope: !2167)
!2199 = !DILocation(line: 167, column: 15, scope: !2167)
!2200 = !DILocation(line: 167, column: 15, scope: !2167)
!2201 = !DILocation(line: 167, column: 15, scope: !2167)
!2202 = !DILocation(line: 167, column: 15, scope: !2167)
!2203 = !DILocation(line: 167, column: 15, scope: !2167)
!2204 = !DILocation(line: 167, column: 15, scope: !2167)
!2205 = !DILocation(line: 167, column: 15, scope: !2167)
!2206 = !DILocation(line: 167, column: 15, scope: !2167)
!2207 = !DILocation(line: 167, column: 15, scope: !2167)
!2208 = !DILocation(line: 167, column: 15, scope: !2167)
!2209 = !DILocation(line: 167, column: 15, scope: !2167)
!2210 = !DILocation(line: 167, column: 15, scope: !2167)
!2211 = !DILocation(line: 167, column: 15, scope: !2167)
!2212 = !DILocation(line: 167, column: 15, scope: !2167)
!2213 = !DILocation(line: 167, column: 15, scope: !2167)
!2214 = !DILocation(line: 168, column: 16, scope: !2167)
!2215 = !DILocation(line: 168, column: 16, scope: !2167)
!2216 = !DILocation(line: 168, column: 16, scope: !2167)
!2217 = !DILocation(line: 168, column: 16, scope: !2167)
!2218 = !DILocation(line: 168, column: 16, scope: !2167)
!2219 = !DILocation(line: 168, column: 16, scope: !2167)
!2220 = !DILocation(line: 168, column: 16, scope: !2167)
!2221 = !DILocation(line: 168, column: 16, scope: !2167)
!2222 = !DILocation(line: 168, column: 16, scope: !2167)
!2223 = !DILocation(line: 168, column: 16, scope: !2167)
!2224 = !DILocation(line: 168, column: 16, scope: !2167)
!2225 = !DILocation(line: 168, column: 16, scope: !2167)
!2226 = !DILocation(line: 168, column: 16, scope: !2167)
!2227 = !DILocation(line: 168, column: 16, scope: !2167)
!2228 = !DILocation(line: 168, column: 16, scope: !2167)
!2229 = !DILocation(line: 168, column: 16, scope: !2167)
!2230 = !DILocation(line: 168, column: 16, scope: !2167)
!2231 = !DILocation(line: 168, column: 16, scope: !2167)
!2232 = !DILocation(line: 166, column: 3, scope: !2167)
!2233 = !DILocation(line: 166, column: 3, scope: !2167)
!2234 = !{!107, !146, !182, !10, !10}
!2235 = !DISubroutineType(types: !2234)
!2236 = distinct !DISubprogram(name: "support.namespace-metadata.checked", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2echecked.2233", scope: !116, file: !116, line: 171, type: !2235, scopeLine: 171, spFlags: DISPFlagDefinition, unit: !2)
!2237 = !DILocalVariable(name: "region", arg: 1, scope: !2236, file: !116, line: 171, type: !146)
!2238 = !DILocation(line: 171, column: 17, scope: !2236)
!2239 = !DILocation(line: 171, column: 44, scope: !2236)
!2240 = !DILocation(line: 171, column: 44, scope: !2236)
!2241 = !DILocation(line: 171, column: 44, scope: !2236)
!2242 = !DILocation(line: 171, column: 44, scope: !2236)
!2243 = !DILocation(line: 171, column: 44, scope: !2236)
!2244 = !DILocation(line: 171, column: 44, scope: !2236)
!2245 = !DILocation(line: 171, column: 44, scope: !2236)
!2246 = !DILocation(line: 171, column: 44, scope: !2236)
!2247 = !DILocation(line: 171, column: 44, scope: !2236)
!2248 = !DILocation(line: 171, column: 44, scope: !2236)
!2249 = !DILocation(line: 171, column: 44, scope: !2236)
!2250 = !DILocation(line: 171, column: 44, scope: !2236)
!2251 = !DILocation(line: 171, column: 44, scope: !2236)
!2252 = !DILocation(line: 171, column: 44, scope: !2236)
!2253 = !DILocation(line: 171, column: 44, scope: !2236)
!2254 = !DILocation(line: 171, column: 44, scope: !2236)
!2255 = !DILocalVariable(name: "facts", arg: 2, scope: !2236, file: !116, line: 171, type: !182)
!2256 = !DILocation(line: 171, column: 44, scope: !2236)
!2257 = !DILocalVariable(name: "operation", arg: 3, scope: !2236, file: !116, line: 171, type: !10)
!2258 = !DILocation(line: 171, column: 223, scope: !2236)
!2259 = !DILocalVariable(name: "seconds", arg: 4, scope: !2236, file: !116, line: 171, type: !10)
!2260 = !DILocation(line: 171, column: 240, scope: !2236)
!2261 = !DILocation(line: 172, column: 26, scope: !2236)
!2262 = !DILocation(line: 172, column: 26, scope: !2236)
!2263 = !DILocation(line: 172, column: 26, scope: !2236)
!2264 = !DILocation(line: 172, column: 43, scope: !2236)
!2265 = !DILocation(line: 172, column: 43, scope: !2236)
!2266 = !DILocation(line: 172, column: 43, scope: !2236)
!2267 = !DILocation(line: 172, column: 20, scope: !2236)
!2268 = !DILocation(line: 172, column: 15, scope: !2236)
!2269 = !DILocalVariable(name: "distinct", scope: !2236, file: !116, line: 172, type: !107)
!2270 = !DILocation(line: 172, column: 3, scope: !2236)
!2271 = !DILocation(line: 173, column: 18, scope: !2236)
!2272 = !DILocation(line: 173, column: 18, scope: !2236)
!2273 = !DILocation(line: 173, column: 18, scope: !2236)
!2274 = !DILocation(line: 173, column: 18, scope: !2236)
!2275 = !DILocation(line: 173, column: 18, scope: !2236)
!2276 = !DILocation(line: 173, column: 18, scope: !2236)
!2277 = !DILocation(line: 173, column: 18, scope: !2236)
!2278 = !DILocation(line: 173, column: 18, scope: !2236)
!2279 = !DILocation(line: 173, column: 18, scope: !2236)
!2280 = !DILocation(line: 173, column: 18, scope: !2236)
!2281 = !DILocation(line: 173, column: 18, scope: !2236)
!2282 = !DILocation(line: 173, column: 18, scope: !2236)
!2283 = !DILocation(line: 173, column: 18, scope: !2236)
!2284 = !DILocation(line: 173, column: 18, scope: !2236)
!2285 = !DILocation(line: 173, column: 18, scope: !2236)
!2286 = !DILocation(line: 173, column: 18, scope: !2236)
!2287 = !DILocation(line: 173, column: 18, scope: !2236)
!2288 = !DILocation(line: 173, column: 59, scope: !2236)
!2289 = !DILocation(line: 173, column: 59, scope: !2236)
!2290 = !DILocation(line: 173, column: 59, scope: !2236)
!2291 = !DILocation(line: 173, column: 59, scope: !2236)
!2292 = !DILocation(line: 173, column: 59, scope: !2236)
!2293 = !DILocation(line: 173, column: 59, scope: !2236)
!2294 = !DILocation(line: 173, column: 59, scope: !2236)
!2295 = !DILocation(line: 173, column: 59, scope: !2236)
!2296 = !DILocation(line: 173, column: 59, scope: !2236)
!2297 = !DILocation(line: 173, column: 59, scope: !2236)
!2298 = !DILocation(line: 173, column: 59, scope: !2236)
!2299 = !DILocation(line: 173, column: 59, scope: !2236)
!2300 = !DILocation(line: 173, column: 59, scope: !2236)
!2301 = !DILocation(line: 173, column: 59, scope: !2236)
!2302 = !DILocation(line: 173, column: 59, scope: !2236)
!2303 = !DILocation(line: 173, column: 59, scope: !2236)
!2304 = !DILocation(line: 173, column: 59, scope: !2236)
!2305 = !DILocation(line: 173, column: 100, scope: !2236)
!2306 = !DILocation(line: 173, column: 12, scope: !2236)
!2307 = !DILocalVariable(name: "valid", scope: !2236, file: !116, line: 173, type: !107)
!2308 = !DILocation(line: 173, column: 3, scope: !2236)
!2309 = !DILocation(line: 174, column: 3, scope: !2236)
!2310 = !DILocation(line: 175, column: 15, scope: !2236)
!2311 = !DILocation(line: 175, column: 15, scope: !2236)
!2312 = !DILocation(line: 175, column: 15, scope: !2236)
!2313 = !DILocation(line: 175, column: 15, scope: !2236)
!2314 = !DILocation(line: 175, column: 15, scope: !2236)
!2315 = !DILocation(line: 175, column: 15, scope: !2236)
!2316 = !DILocation(line: 175, column: 15, scope: !2236)
!2317 = !DILocation(line: 175, column: 15, scope: !2236)
!2318 = !DILocation(line: 175, column: 15, scope: !2236)
!2319 = !DILocation(line: 175, column: 15, scope: !2236)
!2320 = !DILocation(line: 175, column: 15, scope: !2236)
!2321 = !DILocation(line: 175, column: 15, scope: !2236)
!2322 = !DILocation(line: 175, column: 15, scope: !2236)
!2323 = !DILocation(line: 175, column: 15, scope: !2236)
!2324 = !DILocation(line: 175, column: 15, scope: !2236)
!2325 = !DILocation(line: 175, column: 15, scope: !2236)
!2326 = !DILocation(line: 175, column: 15, scope: !2236)
!2327 = !DILocation(line: 175, column: 15, scope: !2236)
!2328 = !DILocation(line: 176, column: 16, scope: !2236)
!2329 = !DILocation(line: 174, column: 3, scope: !2236)
!2330 = !DILocation(line: 174, column: 3, scope: !2236)
!2331 = !{!107, !146, !10, !10}
!2332 = !DISubroutineType(types: !2331)
!2333 = distinct !DISubprogram(name: "support.namespace-metadata.read-input", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eread_2dinput.2234", scope: !116, file: !116, line: 179, type: !2332, scopeLine: 179, spFlags: DISPFlagDefinition, unit: !2)
!2334 = !DILocalVariable(name: "region", arg: 1, scope: !2333, file: !116, line: 179, type: !146)
!2335 = !DILocation(line: 179, column: 20, scope: !2333)
!2336 = !DILocalVariable(name: "operation", arg: 2, scope: !2333, file: !116, line: 179, type: !10)
!2337 = !DILocation(line: 179, column: 47, scope: !2333)
!2338 = !DILocalVariable(name: "seconds", arg: 3, scope: !2333, file: !116, line: 179, type: !10)
!2339 = !DILocation(line: 179, column: 64, scope: !2333)
!2340 = !DILocation(line: 180, column: 30, scope: !2333)
!2341 = !DILocation(line: 180, column: 67, scope: !2333)
!2342 = !DILocation(line: 180, column: 105, scope: !2333)
!2343 = !DILocation(line: 180, column: 142, scope: !2333)
!2344 = !DILocation(line: 180, column: 173, scope: !2333)
!2345 = !DILocation(line: 180, column: 213, scope: !2333)
!2346 = !DILocation(line: 180, column: 253, scope: !2333)
!2347 = !DILocation(line: 180, column: 290, scope: !2333)
!2348 = !DILocation(line: 180, column: 3, scope: !2333)
!2349 = !DILocation(line: 180, column: 3, scope: !2333)
!2350 = !DILocation(line: 180, column: 3, scope: !2333)
!2351 = !DILocation(line: 180, column: 3, scope: !2333)
!2352 = !DILocation(line: 180, column: 3, scope: !2333)
!2353 = !DILocation(line: 180, column: 3, scope: !2333)
!2354 = !DILocation(line: 180, column: 3, scope: !2333)
!2355 = !DILocation(line: 180, column: 3, scope: !2333)
!2356 = !DILocation(line: 180, column: 3, scope: !2333)
!2357 = !DILocation(line: 180, column: 3, scope: !2333)
!2358 = !DILocation(line: 180, column: 3, scope: !2333)
!2359 = !DILocation(line: 180, column: 3, scope: !2333)
!2360 = !DILocation(line: 180, column: 3, scope: !2333)
!2361 = !DILocation(line: 180, column: 3, scope: !2333)
!2362 = !DILocation(line: 180, column: 3, scope: !2333)
!2363 = !DILocation(line: 180, column: 3, scope: !2333)
!2364 = !DILocalVariable(name: "facts", scope: !2333, file: !116, line: 180, type: !182)
!2365 = !DILocation(line: 180, column: 3, scope: !2333)
!2366 = !DILocation(line: 180, column: 3, scope: !2333)
!2367 = !DILocation(line: 180, column: 3, scope: !2333)
!2368 = !DILocation(line: 181, column: 3, scope: !2333)
!2369 = !DILocation(line: 181, column: 3, scope: !2333)
!2370 = !DILocation(line: 181, column: 3, scope: !2333)
!2371 = !DILocation(line: 181, column: 3, scope: !2333)
!2372 = !DILocation(line: 181, column: 3, scope: !2333)
!2373 = !DILocation(line: 181, column: 3, scope: !2333)
!2374 = !DILocation(line: 181, column: 3, scope: !2333)
!2375 = !DILocation(line: 181, column: 3, scope: !2333)
!2376 = !DILocation(line: 181, column: 3, scope: !2333)
!2377 = !DILocation(line: 181, column: 3, scope: !2333)
!2378 = !DILocation(line: 181, column: 3, scope: !2333)
!2379 = !DILocation(line: 181, column: 3, scope: !2333)
!2380 = !DILocation(line: 181, column: 3, scope: !2333)
!2381 = !DILocation(line: 181, column: 3, scope: !2333)
!2382 = !DILocation(line: 181, column: 3, scope: !2333)
!2383 = !DILocation(line: 181, column: 3, scope: !2333)
!2384 = !DILocation(line: 181, column: 3, scope: !2333)
!2385 = !DILocation(line: 181, column: 3, scope: !2333)
!2386 = !DILocation(line: 182, column: 15, scope: !2333)
!2387 = !DILocation(line: 182, column: 15, scope: !2333)
!2388 = !DILocation(line: 182, column: 15, scope: !2333)
!2389 = !DILocation(line: 182, column: 15, scope: !2333)
!2390 = !DILocation(line: 182, column: 15, scope: !2333)
!2391 = !DILocation(line: 182, column: 15, scope: !2333)
!2392 = !DILocation(line: 182, column: 15, scope: !2333)
!2393 = !DILocation(line: 182, column: 15, scope: !2333)
!2394 = !DILocation(line: 182, column: 15, scope: !2333)
!2395 = !DILocation(line: 182, column: 15, scope: !2333)
!2396 = !DILocation(line: 182, column: 15, scope: !2333)
!2397 = !DILocation(line: 182, column: 15, scope: !2333)
!2398 = !DILocation(line: 182, column: 15, scope: !2333)
!2399 = !DILocation(line: 182, column: 15, scope: !2333)
!2400 = !DILocation(line: 182, column: 15, scope: !2333)
!2401 = !DILocation(line: 182, column: 15, scope: !2333)
!2402 = !DILocation(line: 182, column: 15, scope: !2333)
!2403 = !DILocation(line: 182, column: 15, scope: !2333)
!2404 = !DILocation(line: 183, column: 16, scope: !2333)
!2405 = !DILocation(line: 181, column: 3, scope: !2333)
!2406 = !DILocation(line: 181, column: 3, scope: !2333)
!2407 = !{!107, !146, !10, !10}
!2408 = !DISubroutineType(types: !2407)
!2409 = distinct !DISubprogram(name: "support.namespace-metadata.apply", linkageName: "topal.region-instance.namespace-metadata.topal.fn.support_2enamespace_2dmetadata_2eapply.2235", scope: !116, file: !116, line: 185, type: !2408, scopeLine: 185, spFlags: DISPFlagDefinition, unit: !2)
!2410 = !DILocalVariable(name: "region", arg: 1, scope: !2409, file: !116, line: 185, type: !146)
!2411 = !DILocation(line: 185, column: 19, scope: !2409)
!2412 = !DILocalVariable(name: "operation", arg: 2, scope: !2409, file: !116, line: 185, type: !10)
!2413 = !DILocation(line: 185, column: 46, scope: !2409)
!2414 = !DILocalVariable(name: "seconds", arg: 3, scope: !2409, file: !116, line: 185, type: !10)
!2415 = !DILocation(line: 185, column: 63, scope: !2409)
!2416 = !DILocation(line: 186, column: 13, scope: !2409)
!2417 = !DILocalVariable(name: "extent", scope: !2409, file: !116, line: 186, type: !10)
!2418 = !DILocation(line: 186, column: 3, scope: !2409)
!2419 = !DILocation(line: 187, column: 21, scope: !2409)
!2420 = !DILocation(line: 187, column: 21, scope: !2409)
!2421 = !DILocation(line: 187, column: 37, scope: !2409)
!2422 = !DILocation(line: 187, column: 37, scope: !2409)
!2423 = !DILocation(line: 187, column: 53, scope: !2409)
!2424 = !DILocation(line: 187, column: 53, scope: !2409)
!2425 = !DILocation(line: 187, column: 86, scope: !2409)
!2426 = !DILocation(line: 187, column: 86, scope: !2409)
!2427 = !DILocation(line: 187, column: 15, scope: !2409)
!2428 = !DILocalVariable(name: "geometry", scope: !2409, file: !116, line: 187, type: !107)
!2429 = !DILocation(line: 187, column: 3, scope: !2409)
!2430 = !DILocation(line: 188, column: 3, scope: !2409)
!2431 = !DILocation(line: 189, column: 15, scope: !2409)
!2432 = !DILocation(line: 189, column: 15, scope: !2409)
!2433 = !DILocation(line: 190, column: 16, scope: !2409)
!2434 = !DILocation(line: 188, column: 3, scope: !2409)
!2435 = !DILocation(line: 188, column: 3, scope: !2409)
!2436 = !{!107, !146, !10, !10}
!2437 = !DISubroutineType(types: !2436)
!2438 = distinct !DISubprogram(name: "apply", linkageName: "topal.region-instance.namespace-metadata.topal.fn.apply.2236", scope: !0, file: !0, line: 4, type: !2437, scopeLine: 4, spFlags: DISPFlagDefinition, unit: !2)
!2439 = !DILocalVariable(name: "region", arg: 1, scope: !2438, file: !0, line: 4, type: !146)
!2440 = !DILocation(line: 4, column: 19, scope: !2438)
!2441 = !DILocalVariable(name: "operation", arg: 2, scope: !2438, file: !0, line: 4, type: !10)
!2442 = !DILocation(line: 4, column: 46, scope: !2438)
!2443 = !DILocalVariable(name: "seconds", arg: 3, scope: !2438, file: !0, line: 4, type: !10)
!2444 = !DILocation(line: 4, column: 63, scope: !2438)
!2445 = !DILocation(line: 5, column: 3, scope: !2438)
!2446 = !DILocation(line: 5, column: 3, scope: !2438)
!2447 = !{i32 2, !"Dwarf Version", i32 5}
!2448 = !{i32 2, !"Debug Info Version", i32 3}
!2449 = !{!"topalc 0.1.0"}
