set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/tk282-bootstrap-frame-target-c3221c84/frame-target-1962780-1794163702426799496/kernel.elf"
target remote 127.0.0.1:38231
python
mode = 'empty-map'
observation_path = '/home/mats/git/topal/linux-kernel/.cache/tk282-bootstrap-frame-target-c3221c84/frame-target-1962780-1794163702426799496/empty-map/observations.json'

import gdb, json, traceback

observed = dict(mode=mode, passed=False, created=False, zeros=[])
successful = mode in ['real-map','sparse-map','unaligned-map','duplicate-create','zero-reservation']
allocating = mode in ['sparse-map','unaligned-map','zero-reservation']

def value(s): return int(gdb.parse_and_eval(s))
def address(s): return value('(unsigned long long)&'+s)
def memory(p,n): return bytes(gdb.selected_inferior().read_memory(p,n))
def word(p): return int.from_bytes(memory(p,8),'little')
def put(p,n,size=8): gdb.selected_inferior().write_memory(p,int(n).to_bytes(size,'little'))
def privileged():
    assert value('$cs')&3 == 0
    assert value('$eflags')&512 == 0

class Entry(gdb.Breakpoint):
    def stop(self):
        try:
            privileged()
            boot=value('$rsi')
            end=address('topal_x86_kernel_reservation_end_v1')
            base=(end+4095)&-4096
            resource=int.from_bytes(memory(boot+536,4),'little')
            size=int.from_bytes(memory(boot+540,4),'little')
            if mode in ['sparse-map','zero-reservation']:
                claims=[(0,base+64*4096,1),(base+8*4096,4096,2)]
            elif mode=='unaligned-map':
                claims=[(0,base+64*4096,1),(base+5*4096+13,3*4096+17,1),
                        (base+20*4096+5,33,2)]
            elif mode=='unsupported-map': claims=[(0,(1<<30)+4096,1)]
            elif mode=='overflow-map': claims=[((1<<64)-4096,8192,1)]
            elif mode=='empty-map': claims=[]
            elif mode=='reserved-map': claims=[(0,1<<30,2)]
            else: claims=None
            if claims is not None:
                put(boot+488,len(claims),1)
                for i,(start,length,kind) in enumerate(claims):
                    put(boot+720+20*i,start)
                    put(boot+728+20*i,length)
                    put(boot+736+20*i,kind,4)
            n=memory(boot+488,1)[0]
            observed['e820']=[[word(boot+720+20*i),word(boot+728+20*i),
                int.from_bytes(memory(boot+736+20*i,4),'little')] for i in range(n)]
            observed['reservations']=[[0,end],[resource,resource+size]]
            observed['boot_params']=boot
            put(address('topal_frame_target_probe_mode_v1'),int(allocating))
            if mode=='duplicate-create': put(address('topal_frame_target_probe_mode_v1'),2)
            if mode=='interrupts': gdb.execute('set $eflags = $eflags | 512')
            if mode=='bad-stack': gdb.execute('set $rsp = 0x300000')
            count,alignment=(5,8) if mode=='unaligned-map' else (3,4)
            request=address('topal_frame_target_probe_request_v1')
            put(request,count);put(request+8,alignment)
            observed['runtime_request']=[count,alignment]
        except Exception:
            traceback.print_exc();gdb.execute('quit 1')
        return False

class Created(gdb.Breakpoint):
    def stop(self):
        try:
            if mode=='interrupts':
                assert value('$eflags')&512
                gdb.execute('set $eflags = $eflags & ~512')
            privileged()
            ctx=value('$rdi')
            assert bool(ctx)==successful,(mode,hex(ctx))
            observed['created']=bool(ctx)
            context=address('topal_x86_frame_context_v1')
            if not ctx:
                assert word(context)==(0 if mode in ['interrupts','bad-stack'] else 3)
                observed['frames']=[]
                return False
            assert ctx==context and word(ctx)==1 and word(ctx+8)==1 and word(ctx+16)==1
            n=word(ctx+24)
            assert 0<n<=262144
            table=address('topal_x86_frame_table_v1')
            assert word(table)==n
            frames=[]
            data=memory(table+128,n*24)
            for i in range(n):
                at=i*24
                identity=int.from_bytes(data[at:at+8],'little')
                provenance=int.from_bytes(data[at+8:at+16],'little')
                frame=int.from_bytes(data[at+16:at+24],'little')
                assert identity==0 and provenance==1
                assert not frames or frames[-1]<frame
                for start,end in observed['reservations']:
                    assert (frame+1)*4096<=start or frame*4096>=end
                frames.append(frame)
            observed['frames']=frames
            observed['n']=n
        except Exception:
            traceback.print_exc();gdb.execute('quit 1')
        return False

class ZeroReturn(gdb.Breakpoint):
    def __init__(self,at,physical,count,victim=None):
        super().__init__('*'+str(at),internal=True,temporary=True)
        self.physical,self.count=physical,count
        self.victim=victim
    def stop(self):
        try:
            privileged()
            if self.victim is not None:
                assert value('$rax')&255 == 0
                assert memory(self.physical*4096,self.count*4096)==self.victim
                observed['zeros'][-1]['reserved_bytes_unchanged']=True
            else:
                assert value('$rax')&255 == 1
                assert memory(self.physical*4096,self.count*4096)==bytes(self.count*4096)
                observed['zeros'][-1]['actual_physical_bytes_zero']=True
        except Exception:
            traceback.print_exc();gdb.execute('quit 1')
        return False

class Zero(gdb.Breakpoint):
    def stop(self):
        try:
            privileged()
            ctx,physical,count=value('$rdi'),value('$rsi'),value('$rdx')
            assert ctx==address('topal_x86_frame_context_v1') and word(ctx)==2
            assert word(ctx+14*8)==count and word(ctx+15*8)==word(ctx+2*8)
            issuer=word(ctx+2*8)
            registry=address('topal_x86_frame_registry_v1')
            records=memory(registry,observed['n']*64)
            for at in range(0,len(records),64):
                assert not int.from_bytes(records[at+56:at+64],'little') or int.from_bytes(records[at+8:at+16],'little')!=issuer
            if len(observed['zeros'])==2:
                assert memory(physical*4096,count*4096)==bytes([165])*(count*4096)
                assert physical==observed['zeros'][0]['physical_frame']
            observed['zeros'].append(dict(physical_frame=physical,count=count,id=issuer))
            victim=None
            if mode=='zero-reservation':
                physical=0x200
                gdb.execute('set $rsi = 0x200')
                victim=memory(physical*4096,count*4096)
            ZeroReturn(word(value('$rsp')),physical,count,victim)
        except Exception:
            traceback.print_exc();gdb.execute('quit 1')
        return False

class Complete(gdb.Breakpoint):
    def stop(self):
        try:
            privileged()
            assert mode!='zero-reservation', 'fatal allocator resumed its caller'
            result=word(address('topal_frame_target_probe_result_v1'))
            assert result==(1 if successful else (1<<64)-1),(mode,result)
            if successful:
                ctx=address('topal_x86_frame_context_v1')
                assert word(ctx)==1
                assert word(ctx+16)==(4 if allocating else 1)
                n=observed['n']
                for name,size in [('private',65528),('stack',4096),('facts',24),('output',56),
                                  ('registry',n*64),('tokens',n*24)]:
                    assert memory(address('topal_x86_frame_'+name+'_v1'),size)==bytes(size),name
                history=address('topal_x86_frame_history_v1')
                assert word(history+24)==0 and word(history+32)==0
                assert word(address('topal_frame_allocator_active_v1'))==0
                assert word(address('topal_x86_tail_boundary_active_v1'))==0
                assert len(observed['zeros'])==(3 if allocating else 0)
                observed['history']=[word(history+i*8) for i in range(5)]
                data=memory(address('topal_x86_frame_table_v1')+128,n*24)
                assert all(int.from_bytes(data[i*24:i*24+8],'little')==0 for i in range(n))
            observed['passed']=True
            return True
        except Exception:
            traceback.print_exc();gdb.execute('quit 1')

class Fatal(gdb.Breakpoint):
    def stop(self):
        try:
            privileged()
            assert mode=='zero-reservation'
            ctx=address('topal_x86_frame_context_v1')
            assert word(ctx)==3 and word(ctx+16)==1
            start,count,identity=[word(ctx+i*8) for i in [13,14,15]]
            assert count==observed['runtime_request'][0] and identity==1
            for i in range(count):
                assert word(address('topal_x86_frame_table_v1')+128+(start+i)*24)==identity
            history=address('topal_x86_frame_history_v1')
            assert word(history+24)==0 and word(history+32)==1
            for name,size in [('private',65528),('stack',4096),('facts',24),('output',56),
                              ('registry',observed['n']*64),('tokens',observed['n']*24)]:
                assert memory(address('topal_x86_frame_'+name+'_v1'),size)==bytes(size),name
            assert word(address('topal_frame_allocator_active_v1'))==0
            assert word(address('topal_x86_tail_boundary_active_v1'))==0
            assert len(observed['zeros'])==1 and observed['zeros'][0]['reserved_bytes_unchanged']
            observed.update(passed=True, poisoned=True, source_writes_retained=True,
                            pending_issuance_retained=True, caller_retirement_qualified=False)
            return True
        except Exception:
            traceback.print_exc();gdb.execute('quit 1')

try:
    Entry('*_topal_kernel_entry')
    Created('*topal_frame_target_created_v1')
    Zero('*topal_frame_kernel_zero_v1')
    Complete('*topal_frame_target_complete_v1')
    Fatal('*topal_x86_frame_target_halt_v1')
    gdb.execute('continue')
    assert observed['passed'],observed
    with open(observation_path,'w') as f: json.dump(observed,f,indent=2)
    print('FRAME_TARGET_GDB_PASS',mode)
    gdb.execute('detach')
except Exception:
    traceback.print_exc();gdb.execute('quit 1')

end
