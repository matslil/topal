; unqualified ordinary source tail step component
source_filename = "frame-metadata.t"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-none"

; Shared private topal-native/6 value algorithms.
; Platform allocation, write and termination hooks are supplied separately.
; Int values are immutable sign-and-magnitude objects with little-endian
; base-2^32 limbs. A zero has sign = 0 and length = 0. Root-local exact
; infinities use executable-private sign tags 2 (+) and 3 (-) with no limbs;
; Rational infinities wrap one sentinel over denominator one at run time. Those
; values are not admitted at a native function or library boundary.

%topal.StringStorage = type { ptr, i64, ptr, i64 }
%topal.IntStorage = type { i64, i64, [0 x i32] }

define internal ptr @topal.tail.component.runtime.character.ascii.decimal.digit(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %single.byte = icmp eq i64 %length, 1
  br i1 %single.byte, label %load, label %none
load:
  %data.pointer = getelementptr %topal.StringStorage, ptr %character, i32 0, i32 0
  %data = load ptr, ptr %data.pointer, align 8
  %byte = load i8, ptr %data, align 1
  %at.least.zero = icmp uge i8 %byte, 48
  %at.most.nine = icmp ule i8 %byte, 57
  %is.digit = and i1 %at.least.zero, %at.most.nine
  br i1 %is.digit, label %some, label %none
some:
  %digit.byte = sub i8 %byte, 48
  %digit = zext i8 %digit.byte to i64
  %value = call ptr @topal.tail.component.runtime.int.from.u64(i64 %digit)
  %present = call ptr @topal.tail.component.runtime.optional.some(ptr %value)
  ret ptr %present
none:
  %absent = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %absent
}

define internal i1 @topal.tail.component.runtime.character.unicode.whitespace(ptr %character) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.tail.component.runtime.string.unicode.scalar.value(ptr %character)
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp eq i64 %length, 1
  br i1 %present, label %load, label %not.whitespace
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %scalar = load i32, ptr %limb.pointer, align 4
  %ascii.lower = icmp uge i32 %scalar, 9
  %ascii.upper = icmp ule i32 %scalar, 13
  %ascii.control = and i1 %ascii.lower, %ascii.upper
  %space = icmp eq i32 %scalar, 32
  %next.line = icmp eq i32 %scalar, 133
  %no.break = icmp eq i32 %scalar, 160
  %ogham = icmp eq i32 %scalar, 5760
  %quad.lower = icmp uge i32 %scalar, 8192
  %quad.upper = icmp ule i32 %scalar, 8202
  %quad = and i1 %quad.lower, %quad.upper
  %line.separator = icmp eq i32 %scalar, 8232
  %paragraph.separator = icmp eq i32 %scalar, 8233
  %narrow.no.break = icmp eq i32 %scalar, 8239
  %medium.math = icmp eq i32 %scalar, 8287
  %ideographic = icmp eq i32 %scalar, 12288
  %match.0 = or i1 %ascii.control, %space
  %match.1 = or i1 %match.0, %next.line
  %match.2 = or i1 %match.1, %no.break
  %match.3 = or i1 %match.2, %ogham
  %match.4 = or i1 %match.3, %quad
  %match.5 = or i1 %match.4, %line.separator
  %match.6 = or i1 %match.5, %paragraph.separator
  %match.7 = or i1 %match.6, %narrow.no.break
  %match.8 = or i1 %match.7, %medium.math
  %match.9 = or i1 %match.8, %ideographic
  ret i1 %match.9
not.whitespace:
  ret i1 false
}
%topal.IntDivmod = type { ptr, ptr }
%topal.RationalStorage = type { ptr, ptr }
%topal.RangeStorage = type { ptr, ptr, i64, i64 }
%topal.ResultStorage = type { i64, ptr }
%topal.OptionalStorage = type { i64, ptr }
%topal.ErrorStorage = type { ptr, i32, i32, ptr, ptr, ptr, i64, i64 }
%topal.SourceLocationStorage = type { ptr, ptr }
%topal.SerializationStreamStorage = type { ptr, i64 }
%topal.TaskStorage = type { i64, i64, ptr }
%topal.LocationStorage = type { ptr, ptr, i64, ptr }

@topal.tail.component.runtime.int.zero = private constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.tail.component.runtime.int.one = private constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.runtime.int.positive.infinity = private constant { i64, i64, [0 x i32] } { i64 2, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.tail.component.runtime.int.negative.infinity = private constant { i64, i64, [0 x i32] } { i64 3, i64 0, [0 x i32] zeroinitializer }, align 8
@topal.tail.component.runtime.byte.zero = private constant [1 x i8] c"0", align 1
@topal.tail.component.runtime.byte.minus = private constant [1 x i8] c"-", align 1
@topal.tail.component.runtime.int.positive.infinity.text = private constant [9 x i8] c"+Infinity", align 1
@topal.tail.component.runtime.int.negative.infinity.text = private constant [9 x i8] c"-Infinity", align 1
@topal.tail.component.runtime.byte.quote = private constant [1 x i8] c"\22", align 1
@topal.tail.component.runtime.byte.underscore = private constant [1 x i8] c"_", align 1
@topal.tail.component.runtime.string.tag.text = private constant [4 x i8] c"text", align 1
@topal.tail.component.runtime.rational.prefix = private constant [11 x i8] c"Rational ( ", align 1
@topal.tail.component.runtime.rational.separator = private constant [2 x i8] c", ", align 1
@topal.tail.component.runtime.rational.suffix = private constant [2 x i8] c" )", align 1
@topal.tail.component.runtime.range.closed.open = private constant [4 x i8] c" .. ", align 1
@topal.tail.component.runtime.range.open.open = private constant [5 x i8] c" <.. ", align 1
@topal.tail.component.runtime.range.closed.closed = private constant [5 x i8] c" ..= ", align 1
@topal.tail.component.runtime.range.open.closed = private constant [6 x i8] c" <..= ", align 1
@topal.tail.component.runtime.error.prefix = private constant [18 x i8] c"Error ( domain is ", align 1
@topal.tail.component.runtime.error.code.separator = private constant [10 x i8] c", code is ", align 1
@topal.tail.component.runtime.error.suffix = private constant [2 x i8] c" )", align 1
@topal.tail.component.runtime.error.code.out.of.range = private constant [12 x i8] c"out-of-range", align 1
@topal.tail.component.runtime.error.code.not.representable = private constant [17 x i8] c"not-representable", align 1
@topal.tail.component.runtime.error.code.division.by.zero = private constant [16 x i8] c"division-by-zero", align 1
@topal.tail.component.runtime.error.code.indeterminate = private constant [13 x i8] c"indeterminate", align 1
@topal.tail.component.runtime.pattern.identity.diagnostic = private constant [68 x i8] c"error[E-ANONYMOUS-PATTERN-IDENTITY]: repeated pattern values differ\0A", align 1
@topal.tail.component.runtime.c.int32.range.diagnostic = private constant [71 x i8] c"error[E-C-ABI-RANGE]: Topal Int is not representable as a C signed int\0A", align 1
@topal.tail.component.runtime.task.next.identity = private global i64 1, align 8

declare i32 @llvm.ctlz.i32(i32, i1 immarg)
declare void @llvm.memcpy.inline.p0.p0.i64(ptr, ptr, i64, i1 immarg)

; Optimized freestanding code can lower a recognized fill loop to the standard
; LLVM memset libcall. Supply that ABI locally so no C runtime is introduced.
define internal ptr @topal.tail.component.memset(ptr %destination, i32 %value, i64 %length) nounwind noinline optnone noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %complete, label %fill
fill:
  %index = phi i64 [ 0, %entry ], [ %next, %fill ]
  %pointer = getelementptr i8, ptr %destination, i64 %index
  %byte = trunc i32 %value to i8
  store i8 %byte, ptr %pointer, align 1
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %length
  br i1 %done, label %complete, label %fill
complete:
  ret ptr %destination
}



define internal void @topal.tail.component.runtime.pattern.identity.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.tail.component.platform.write(i64 2, ptr @topal.tail.component.runtime.pattern.identity.diagnostic, i64 68)
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
}

define internal void @topal.tail.component.runtime.c.int32.range.fail() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %ignored = call i64 @topal.tail.component.platform.write(i64 2, ptr @topal.tail.component.runtime.c.int32.range.diagnostic, i64 71)
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
}


; Closed direct tasks run on the deterministic root scheduler. Each instance
; still owns distinct identity, lifecycle state, and private semantic state.
define internal ptr @topal.tail.component.runtime.task.make(ptr %initial) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %task = call ptr @topal.tail.component.platform.allocate(i64 24)
  %identity = load i64, ptr @topal.tail.component.runtime.task.next.identity, align 8
  %next.identity = add i64 %identity, 1
  store i64 %next.identity, ptr @topal.tail.component.runtime.task.next.identity, align 8
  %identity.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 0
  %terminated.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 1
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store i64 %identity, ptr %identity.pointer, align 8
  store i64 0, ptr %terminated.pointer, align 8
  store ptr %initial, ptr %state.pointer, align 8
  ret ptr %task
}

define internal ptr @topal.tail.component.runtime.task.state.load(ptr %task) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  %state = load ptr, ptr %state.pointer, align 8
  ret ptr %state
}

define internal void @topal.tail.component.runtime.task.state.replace(ptr %task, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %state.pointer = getelementptr %topal.TaskStorage, ptr %task, i32 0, i32 2
  store ptr %value, ptr %state.pointer, align 8
  ret void
}

; A source-only location without a granted device adapter is backed by private
; Topal storage. The semantic range start and offset remain available for
; debugging, while every read and write remains an ordered runtime call.
define internal ptr @topal.tail.component.runtime.location.make(ptr %range.start, ptr %offset) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %location = call ptr @topal.tail.component.platform.allocate(i64 32)
  %range.start.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 0
  %offset.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 1
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %range.start, ptr %range.start.pointer, align 8
  store ptr %offset, ptr %offset.pointer, align 8
  store i64 0, ptr %initialized.pointer, align 8
  store ptr null, ptr %value.pointer, align 8
  ret ptr %location
}

define internal void @topal.tail.component.runtime.location.write(ptr %location, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  store ptr %value, ptr %value.pointer, align 8
  store i64 1, ptr %initialized.pointer, align 8
  ret void
}

define internal ptr @topal.tail.component.runtime.location.read(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %initialized.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 2
  %initialized = load i64, ptr %initialized.pointer, align 8
  %valid = icmp eq i64 %initialized, 1
  br i1 %valid, label %load, label %failure
load:
  %value.pointer = getelementptr %topal.LocationStorage, ptr %location, i32 0, i32 3
  %value = load ptr, ptr %value.pointer, align 8
  %non.null = icmp ne ptr %value, null
  br i1 %non.null, label %success, label %failure
success:
  ret ptr %value
failure:
  call void @topal.tail.component.platform.exit(i64 74)
  unreachable
}

define internal ptr @topal.tail.component.runtime.serialization.make(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream = call ptr @topal.tail.component.platform.allocate(i64 16)
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %publish.empty, label %copy.start
copy.start:
  %copy = call ptr @topal.tail.component.platform.allocate(i64 %length)
  br label %copy.loop
copy.loop:
  %index = phi i64 [ 0, %copy.start ], [ %next, %copy.loop ]
  %source.pointer = getelementptr i8, ptr %data, i64 %index
  %target.pointer = getelementptr i8, ptr %copy, i64 %index
  %byte = load i8, ptr %source.pointer, align 1
  store i8 %byte, ptr %target.pointer, align 1
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %publish.copy, label %copy.loop
publish.copy:
  store ptr %copy, ptr %data.pointer, align 8
  br label %publish.length
publish.empty:
  store ptr null, ptr %data.pointer, align 8
  br label %publish.length
publish.length:
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %stream
}

define internal void @topal.tail.component.runtime.serialization.verify(ptr %stream, ptr %expected, i64 %expected.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %stream.valid = icmp ne ptr %stream, null
  br i1 %stream.valid, label %load, label %failure
load:
  %data.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 0
  %length.pointer = getelementptr %topal.SerializationStreamStorage, ptr %stream, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %length.matches = icmp eq i64 %length, %expected.length
  br i1 %length.matches, label %check.empty, label %failure
check.empty:
  %empty = icmp eq i64 %expected.length, 0
  br i1 %empty, label %done, label %check.pointers
check.pointers:
  %data.valid = icmp ne ptr %data, null
  %expected.valid = icmp ne ptr %expected, null
  %pointers.valid = and i1 %data.valid, %expected.valid
  br i1 %pointers.valid, label %loop, label %failure
loop:
  %index = phi i64 [ 0, %check.pointers ], [ %next, %advance ]
  %actual.pointer = getelementptr i8, ptr %data, i64 %index
  %expected.pointer = getelementptr i8, ptr %expected, i64 %index
  %actual.byte = load i8, ptr %actual.pointer, align 1
  %expected.byte = load i8, ptr %expected.pointer, align 1
  %matches = icmp eq i8 %actual.byte, %expected.byte
  br i1 %matches, label %advance, label %failure
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %expected.length
  br i1 %complete, label %done, label %loop
failure:
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable
done:
  ret void
}

define internal void @topal.tail.component.platform.write_all(ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %done, label %loop
loop:
  %offset = phi i64 [0, %entry], [%next, %progress], [%offset, %retry]
  %remaining = sub i64 %length, %offset
  %cursor = getelementptr i8, ptr %buffer, i64 %offset
  %written = call i64 @topal.tail.component.platform.write(i64 1, ptr %cursor, i64 %remaining)
  %positive = icmp sgt i64 %written, 0
  br i1 %positive, label %progress, label %error
progress:
  %next = add i64 %offset, %written
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %done, label %loop
error:
  %interrupted = icmp eq i64 %written, -4
  br i1 %interrupted, label %retry, label %failure
retry:
  br label %loop
failure:
  call void @topal.tail.component.platform.exit(i64 74)
  unreachable
done:
  ret void
}

define internal void @topal.tail.component.runtime.u64.print(i64 %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %buffer = alloca [20 x i8], align 1
  %zero = icmp eq i64 %value, 0
  br i1 %zero, label %write.zero, label %convert
write.zero:
  %zero.pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 19
  store i8 48, ptr %zero.pointer, align 1
  call void @topal.tail.component.platform.write_all(ptr %zero.pointer, i64 1)
  ret void
convert:
  %remaining = phi i64 [ %value, %entry ], [ %quotient, %convert ]
  %position = phi i64 [ 20, %entry ], [ %next.position, %convert ]
  %digit = urem i64 %remaining, 10
  %quotient = udiv i64 %remaining, 10
  %next.position = sub i64 %position, 1
  %pointer = getelementptr [20 x i8], ptr %buffer, i64 0, i64 %next.position
  %digit.byte = trunc i64 %digit to i8
  %ascii = add i8 %digit.byte, 48
  store i8 %ascii, ptr %pointer, align 1
  %complete = icmp eq i64 %quotient, 0
  br i1 %complete, label %write, label %convert
write:
  %length = sub i64 20, %next.position
  call void @topal.tail.component.platform.write_all(ptr %pointer, i64 %length)
  ret void
}

define internal ptr @topal.tail.component.runtime.string.make(ptr %data, i64 %length, ptr %display, i64 %display.length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %string = call ptr @topal.tail.component.platform.allocate(i64 32)
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  store ptr %data, ptr %data.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  store ptr %display, ptr %display.pointer, align 8
  store i64 %display.length, ptr %display.length.pointer, align 8
  ret ptr %string
}

define internal void @topal.tail.component.runtime.string.raw.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  call void @topal.tail.component.platform.write_all(ptr %data, i64 %length)
  ret void
}

define internal void @topal.tail.component.runtime.string.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %display.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 2
  %display.length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 3
  %display = load ptr, ptr %display.pointer, align 8
  %display.length = load i64, ptr %display.length.pointer, align 8
  %cached = icmp ne ptr %display, null
  br i1 %cached, label %write.cached, label %write.dynamic
write.cached:
  call void @topal.tail.component.platform.write_all(ptr %display, i64 %display.length)
  ret void
write.dynamic:
  call void @topal.tail.component.runtime.string.dynamic.print(ptr %string)
  ret void
}

define internal i1 @topal.tail.component.runtime.string.contains.quote(ptr %data, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %not.found, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %pointer = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %pointer, align 1
  %quote = icmp eq i8 %byte, 34
  br i1 %quote, label %found, label %advance
advance:
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %length
  br i1 %complete, label %not.found, label %loop
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal i1 @topal.tail.component.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %minimum = add i64 %underscores, 5
  %possible = icmp ule i64 %minimum, %length
  br i1 %possible, label %search, label %not.found
search:
  %position = phi i64 [ 0, %entry ], [ %next.position, %advance ]
  %remaining = sub i64 %length, %position
  %enough = icmp uge i64 %remaining, %minimum
  br i1 %enough, label %check.base, label %not.found
check.base:
  %quote.pointer = getelementptr i8, ptr %data, i64 %position
  %quote = load i8, ptr %quote.pointer, align 1
  %offset.t0 = add i64 %position, 1
  %offset.e = add i64 %position, 2
  %offset.x = add i64 %position, 3
  %offset.t1 = add i64 %position, 4
  %pointer.t0 = getelementptr i8, ptr %data, i64 %offset.t0
  %pointer.e = getelementptr i8, ptr %data, i64 %offset.e
  %pointer.x = getelementptr i8, ptr %data, i64 %offset.x
  %pointer.t1 = getelementptr i8, ptr %data, i64 %offset.t1
  %byte.t0 = load i8, ptr %pointer.t0, align 1
  %byte.e = load i8, ptr %pointer.e, align 1
  %byte.x = load i8, ptr %pointer.x, align 1
  %byte.t1 = load i8, ptr %pointer.t1, align 1
  %match.quote = icmp eq i8 %quote, 34
  %match.t0 = icmp eq i8 %byte.t0, 116
  %match.e = icmp eq i8 %byte.e, 101
  %match.x = icmp eq i8 %byte.x, 120
  %match.t1 = icmp eq i8 %byte.t1, 116
  %match.0 = and i1 %match.quote, %match.t0
  %match.1 = and i1 %match.0, %match.e
  %match.2 = and i1 %match.1, %match.x
  %match.base = and i1 %match.2, %match.t1
  br i1 %match.base, label %check.underscores, label %advance
check.underscores:
  %underscore.index = phi i64 [ 0, %check.base ], [ %next.underscore, %underscore.advance ]
  %underscores.complete = icmp eq i64 %underscore.index, %underscores
  br i1 %underscores.complete, label %found, label %check.underscore
check.underscore:
  %underscore.offset.base = add i64 %position, 5
  %underscore.offset = add i64 %underscore.offset.base, %underscore.index
  %underscore.pointer = getelementptr i8, ptr %data, i64 %underscore.offset
  %underscore.byte = load i8, ptr %underscore.pointer, align 1
  %match.underscore = icmp eq i8 %underscore.byte, 95
  br i1 %match.underscore, label %underscore.advance, label %advance
underscore.advance:
  %next.underscore = add i64 %underscore.index, 1
  br label %check.underscores
advance:
  %next.position = add i64 %position, 1
  br label %search
found:
  ret i1 true
not.found:
  ret i1 false
}

define internal void @topal.tail.component.runtime.string.write.underscores(i64 %count) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %done, label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %loop ]
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.byte.underscore, i64 1)
  %next = add i64 %index, 1
  %complete = icmp eq i64 %next, %count
  br i1 %complete, label %done, label %loop
done:
  ret void
}

define internal void @topal.tail.component.runtime.string.dynamic.print(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %contains.quote = call i1 @topal.tail.component.runtime.string.contains.quote(ptr %data, i64 %length)
  br i1 %contains.quote, label %select.tag, label %plain
plain:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.byte.quote, i64 1)
  call void @topal.tail.component.platform.write_all(ptr %data, i64 %length)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.byte.quote, i64 1)
  ret void
select.tag:
  %underscores = phi i64 [ 0, %entry ], [ %next.underscores, %collision ]
  %collides = call i1 @topal.tail.component.runtime.string.has.delimiter(ptr %data, i64 %length, i64 %underscores)
  br i1 %collides, label %collision, label %tagged
collision:
  %next.underscores = add i64 %underscores, 1
  br label %select.tag
tagged:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.string.tag.text, i64 4)
  call void @topal.tail.component.runtime.string.write.underscores(i64 %underscores)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.byte.quote, i64 1)
  call void @topal.tail.component.platform.write_all(ptr %data, i64 %length)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.byte.quote, i64 1)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.string.tag.text, i64 4)
  call void @topal.tail.component.runtime.string.write.underscores(i64 %underscores)
  ret void
}

define internal ptr @topal.tail.component.runtime.string.concat(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %length = add i64 %left.length, %right.length
  %valid = icmp uge i64 %length, %left.length
  br i1 %valid, label %allocate, label %failure
failure:
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
allocate:
  %empty = icmp eq i64 %length, 0
  %allocation.length = select i1 %empty, i64 1, i64 %length
  %data = call ptr @topal.tail.component.platform.allocate(i64 %allocation.length)
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %data, ptr %left.data, i64 %left.length, i1 false)
  %right.destination = getelementptr i8, ptr %data, i64 %left.length
  call void @llvm.memcpy.inline.p0.p0.i64(ptr %right.destination, ptr %right.data, i64 %right.length, i1 false)
  %result = call ptr @topal.tail.component.runtime.string.make(ptr %data, i64 %length, ptr null, i64 0)
  ret ptr %result
}

define internal i1 @topal.tail.component.runtime.string.is.empty(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  ret i1 %empty
}

define internal ptr @topal.tail.component.runtime.string.utf8.byte.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %count = call ptr @topal.tail.component.runtime.int.from.u64(i64 %length)
  ret ptr %count
}

define internal ptr @topal.tail.component.runtime.string.unicode.scalar.value(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  switch i64 %length, label %invalid [
    i64 1, label %one
    i64 2, label %two
    i64 3, label %three
    i64 4, label %four
  ]
one:
  %one.byte = load i8, ptr %data, align 1
  %one.ascii = icmp ult i8 %one.byte, -128
  br i1 %one.ascii, label %one.valid, label %invalid
one.valid:
  %one.value = zext i8 %one.byte to i64
  br label %complete
two:
  %two.byte.0 = load i8, ptr %data, align 1
  %two.pointer.1 = getelementptr i8, ptr %data, i64 1
  %two.byte.1 = load i8, ptr %two.pointer.1, align 1
  %two.lead = and i8 %two.byte.0, -32
  %two.lead.valid = icmp eq i8 %two.lead, -64
  %two.continuation = and i8 %two.byte.1, -64
  %two.continuation.valid = icmp eq i8 %two.continuation, -128
  %two.valid = and i1 %two.lead.valid, %two.continuation.valid
  br i1 %two.valid, label %two.decode, label %invalid
two.decode:
  %two.head.masked = and i8 %two.byte.0, 31
  %two.tail.masked = and i8 %two.byte.1, 63
  %two.head = zext i8 %two.head.masked to i64
  %two.tail = zext i8 %two.tail.masked to i64
  %two.shifted = shl i64 %two.head, 6
  %two.value = or i64 %two.shifted, %two.tail
  br label %complete
three:
  %three.byte.0 = load i8, ptr %data, align 1
  %three.pointer.1 = getelementptr i8, ptr %data, i64 1
  %three.pointer.2 = getelementptr i8, ptr %data, i64 2
  %three.byte.1 = load i8, ptr %three.pointer.1, align 1
  %three.byte.2 = load i8, ptr %three.pointer.2, align 1
  %three.head.masked = and i8 %three.byte.0, 15
  %three.middle.masked = and i8 %three.byte.1, 63
  %three.tail.masked = and i8 %three.byte.2, 63
  %three.head = zext i8 %three.head.masked to i64
  %three.middle = zext i8 %three.middle.masked to i64
  %three.tail = zext i8 %three.tail.masked to i64
  %three.head.shifted = shl i64 %three.head, 12
  %three.middle.shifted = shl i64 %three.middle, 6
  %three.partial = or i64 %three.head.shifted, %three.middle.shifted
  %three.value = or i64 %three.partial, %three.tail
  br label %complete
four:
  %four.byte.0 = load i8, ptr %data, align 1
  %four.pointer.1 = getelementptr i8, ptr %data, i64 1
  %four.pointer.2 = getelementptr i8, ptr %data, i64 2
  %four.pointer.3 = getelementptr i8, ptr %data, i64 3
  %four.byte.1 = load i8, ptr %four.pointer.1, align 1
  %four.byte.2 = load i8, ptr %four.pointer.2, align 1
  %four.byte.3 = load i8, ptr %four.pointer.3, align 1
  %four.head.masked = and i8 %four.byte.0, 7
  %four.second.masked = and i8 %four.byte.1, 63
  %four.third.masked = and i8 %four.byte.2, 63
  %four.tail.masked = and i8 %four.byte.3, 63
  %four.head = zext i8 %four.head.masked to i64
  %four.second = zext i8 %four.second.masked to i64
  %four.third = zext i8 %four.third.masked to i64
  %four.tail = zext i8 %four.tail.masked to i64
  %four.head.shifted = shl i64 %four.head, 18
  %four.second.shifted = shl i64 %four.second, 12
  %four.third.shifted = shl i64 %four.third, 6
  %four.partial.0 = or i64 %four.head.shifted, %four.second.shifted
  %four.partial.1 = or i64 %four.partial.0, %four.third.shifted
  %four.value = or i64 %four.partial.1, %four.tail
  br label %complete
complete:
  %value = phi i64 [ %one.value, %one.valid ], [ %two.value, %two.decode ], [ %three.value, %three ], [ %four.value, %four ]
  %result = call ptr @topal.tail.component.runtime.int.from.u64(i64 %value)
  ret ptr %result
invalid:
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.tail.component.runtime.string.unicode.scalar.characters(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %data.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 0
  %length.pointer = getelementptr %topal.StringStorage, ptr %string, i32 0, i32 1
  %data = load ptr, ptr %data.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  br label %loop
loop:
  %offset = phi i64 [ 0, %entry ], [ %next.offset, %append ]
  %head = phi ptr [ null, %entry ], [ %next.head, %append ]
  %tail = phi ptr [ null, %entry ], [ %node, %append ]
  %complete = icmp eq i64 %offset, %length
  br i1 %complete, label %done, label %decode
decode:
  %byte.pointer = getelementptr i8, ptr %data, i64 %offset
  %byte = load i8, ptr %byte.pointer, align 1
  %ascii = icmp ult i8 %byte, -128
  %two.mask = and i8 %byte, -32
  %two = icmp eq i8 %two.mask, -64
  %three.mask = and i8 %byte, -16
  %three = icmp eq i8 %three.mask, -32
  %non.ascii.width = select i1 %two, i64 2, i64 4
  %multi.width = select i1 %three, i64 3, i64 %non.ascii.width
  %width = select i1 %ascii, i64 1, i64 %multi.width
  %next.offset = add i64 %offset, %width
  %valid = icmp ule i64 %next.offset, %length
  br i1 %valid, label %make, label %invalid
make:
  %character.data = getelementptr i8, ptr %data, i64 %offset
  %character = call ptr @topal.tail.component.runtime.string.make(ptr %character.data, i64 %width, ptr null, i64 0)
  %node = call ptr @topal.tail.component.platform.allocate(i64 16)
  store ptr %character, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %append, label %link
link:
  %tail.next = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next, align 8
  br label %append
append:
  %next.head = select i1 %empty, ptr %node, ptr %head
  br label %loop
done:
  ret ptr %head
invalid:
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.tail.component.runtime.string.select.index.range(ptr %string, ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.tail.component.runtime.string.unicode.scalar.characters(ptr %string)
  %empty.data = call ptr @topal.tail.component.platform.allocate(i64 1)
  %empty = call ptr @topal.tail.component.runtime.string.make(ptr %empty.data, i64 0, ptr null, i64 0)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %index = phi i64 [ 0, %entry ], [ %next.index, %advance ]
  %selected = phi ptr [ %empty, %entry ], [ %next.selected, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %visit
visit:
  %index.value = call ptr @topal.tail.component.runtime.int.from.u64(i64 %index)
  %present = call i1 @topal.tail.component.runtime.range.int.contains(ptr %range, ptr %index.value)
  %character = load ptr, ptr %current, align 8
  br i1 %present, label %append, label %skip
append:
  %appended = call ptr @topal.tail.component.runtime.string.concat(ptr %selected, ptr %character)
  br label %advance
skip:
  br label %advance
advance:
  %next.selected = phi ptr [ %appended, %append ], [ %selected, %skip ]
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.index = add i64 %index, 1
  br label %loop
done:
  ret ptr %selected
}

define internal ptr @topal.tail.component.runtime.string.character.count(ptr %string) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %characters = call ptr @topal.tail.component.runtime.string.unicode.scalar.characters(ptr %string)
  br label %loop
loop:
  %current = phi ptr [ %characters, %entry ], [ %next, %advance ]
  %count = phi i64 [ 0, %entry ], [ %next.count, %advance ]
  %complete = icmp eq ptr %current, null
  br i1 %complete, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %next.count = add i64 %count, 1
  br label %loop
done:
  %value = call ptr @topal.tail.component.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.tail.component.runtime.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.data.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 0
  %left.length.pointer = getelementptr %topal.StringStorage, ptr %left, i32 0, i32 1
  %right.data.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 0
  %right.length.pointer = getelementptr %topal.StringStorage, ptr %right, i32 0, i32 1
  %left.data = load ptr, ptr %left.data.pointer, align 8
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.data = load ptr, ptr %right.data.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %same.length = icmp eq i64 %left.length, %right.length
  br i1 %same.length, label %loop, label %not.equal
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %complete = icmp eq i64 %index, %left.length
  br i1 %complete, label %equal, label %compare
compare:
  %left.pointer = getelementptr i8, ptr %left.data, i64 %index
  %right.pointer = getelementptr i8, ptr %right.data, i64 %index
  %left.byte = load i8, ptr %left.pointer, align 1
  %right.byte = load i8, ptr %right.pointer, align 1
  %same.byte = icmp eq i8 %left.byte, %right.byte
  br i1 %same.byte, label %advance, label %not.equal
advance:
  %next = add i64 %index, 1
  br label %loop
equal:
  ret i1 true
not.equal:
  ret i1 false
}

define internal ptr @topal.tail.component.runtime.result.success(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.tail.component.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.result.error(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.tail.component.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %result
}

define internal i1 @topal.tail.component.runtime.result.is.error(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %is.error = icmp eq i64 %tag, 1
  ret i1 %is.error
}

define internal ptr @topal.tail.component.runtime.result.payload(ptr %result) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.ResultStorage, ptr %result, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.tail.component.runtime.optional.some(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.tail.component.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 1, ptr %tag.pointer, align 8
  store ptr %payload, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal ptr @topal.tail.component.runtime.optional.none() nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %optional = call ptr @topal.tail.component.platform.allocate(i64 16)
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  store i64 0, ptr %tag.pointer, align 8
  store ptr null, ptr %payload.pointer, align 8
  ret ptr %optional
}

define internal i1 @topal.tail.component.runtime.optional.is.some(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %tag.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 0
  %tag = load i64, ptr %tag.pointer, align 8
  %valid = icmp ule i64 %tag, 1
  br i1 %valid, label %checked, label %invalid
checked:
  %is.some = icmp eq i64 %tag, 1
  ret i1 %is.some
invalid:
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable
}

define internal ptr @topal.tail.component.runtime.optional.payload(ptr %optional) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %payload.pointer = getelementptr %topal.OptionalStorage, ptr %optional, i32 0, i32 1
  %payload = load ptr, ptr %payload.pointer, align 8
  ret ptr %payload
}

define internal ptr @topal.tail.component.runtime.optional.from.nullable(ptr %payload) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %present = icmp ne ptr %payload, null
  br i1 %present, label %some, label %none
some:
  %some.value = call ptr @topal.tail.component.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none.value
}

define internal i1 @topal.tail.component.runtime.optional.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.tail.component.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.tail.component.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.tail.component.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.tail.component.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.tail.component.runtime.optional.rational.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.tail.component.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.tail.component.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.tail.component.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.tail.component.runtime.optional.payload(ptr %right)
  %ordering = call i32 @topal.tail.component.runtime.rational.compare(ptr %left.payload, ptr %right.payload)
  %payloads.equal = icmp eq i32 %ordering, 0
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal i1 @topal.tail.component.runtime.optional.string.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.some = call i1 @topal.tail.component.runtime.optional.is.some(ptr %left)
  %right.some = call i1 @topal.tail.component.runtime.optional.is.some(ptr %right)
  %same.alternative = icmp eq i1 %left.some, %right.some
  br i1 %same.alternative, label %same, label %different
different:
  br label %done
same:
  br i1 %left.some, label %payloads, label %both.none
both.none:
  br label %done
payloads:
  %left.payload = call ptr @topal.tail.component.runtime.optional.payload(ptr %left)
  %right.payload = call ptr @topal.tail.component.runtime.optional.payload(ptr %right)
  %payloads.equal = call i1 @topal.tail.component.runtime.string.equal(ptr %left.payload, ptr %right.payload)
  br label %done
done:
  %equal = phi i1 [ false, %different ], [ true, %both.none ], [ %payloads.equal, %payloads ]
  ret i1 %equal
}

define internal ptr @topal.tail.component.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.tail.component.platform.allocate(i64 56)
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %reserved.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 2
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  store ptr %domain, ptr %domain.pointer, align 8
  store i32 %code, ptr %code.pointer, align 4
  store i32 0, ptr %reserved.pointer, align 4
  store ptr null, ptr %detail.pointer, align 8
  store ptr null, ptr %cause.pointer, align 8
  store ptr %source, ptr %source.pointer, align 8
  store i64 %line, ptr %line.pointer, align 8
  store i64 %column, ptr %column.pointer, align 8
  ret ptr %error
}

define internal i32 @topal.tail.component.runtime.error.code(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %code = load i32, ptr %code.pointer, align 4
  ret i32 %code
}

define internal ptr @topal.tail.component.runtime.error.domain(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %domain = load ptr, ptr %domain.pointer, align 8
  ret ptr %domain
}

define internal ptr @topal.tail.component.runtime.error.detail(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %detail.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 3
  %detail = load ptr, ptr %detail.pointer, align 8
  %optional = call ptr @topal.tail.component.runtime.optional.from.nullable(ptr %detail)
  ret ptr %optional
}

define internal ptr @topal.tail.component.runtime.error.cause(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %cause.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 4
  %cause = load ptr, ptr %cause.pointer, align 8
  %optional = call ptr @topal.tail.component.runtime.optional.from.nullable(ptr %cause)
  ret ptr %optional
}

define internal ptr @topal.tail.component.runtime.error.source(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %source.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 5
  %source = load ptr, ptr %source.pointer, align 8
  %present = icmp ne ptr %source, null
  br i1 %present, label %some, label %none
some:
  %line.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 6
  %column.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 7
  %line.number = load i64, ptr %line.pointer, align 8
  %column.number = load i64, ptr %column.pointer, align 8
  %line = call ptr @topal.tail.component.runtime.int.from.u64(i64 %line.number)
  %column = call ptr @topal.tail.component.runtime.int.from.u64(i64 %column.number)
  %location = call ptr @topal.tail.component.platform.allocate(i64 16)
  %location.line = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %location.column = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  store ptr %line, ptr %location.line, align 8
  store ptr %column, ptr %location.column, align 8
  %some.value = call ptr @topal.tail.component.runtime.optional.some(ptr %location)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.tail.component.runtime.source.location.line(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %line.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 0
  %line = load ptr, ptr %line.pointer, align 8
  ret ptr %line
}

define internal ptr @topal.tail.component.runtime.source.location.column(ptr %location) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %column.pointer = getelementptr %topal.SourceLocationStorage, ptr %location, i32 0, i32 1
  %column = load ptr, ptr %column.pointer, align 8
  ret ptr %column
}

define internal ptr @topal.tail.component.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %error = call ptr @topal.tail.component.runtime.error.make(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  %result = call ptr @topal.tail.component.runtime.result.error(ptr %error)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.int.try.to.nat(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %success
failure:
  %failed = call ptr @topal.tail.component.runtime.result.failure(i32 0, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %result = call ptr @topal.tail.component.runtime.result.success(ptr %value)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.try.to.int(ptr %value, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %value)
  %ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %denominator, ptr @topal.tail.component.runtime.int.one)
  %exact = icmp eq i32 %ordering, 0
  br i1 %exact, label %success, label %failure
failure:
  %failed = call ptr @topal.tail.component.runtime.result.failure(i32 1, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %value)
  %result = call ptr @topal.tail.component.runtime.result.success(ptr %numerator)
  ret ptr %result
}

define internal void @topal.tail.component.runtime.error.print(ptr %error) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %domain.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 0
  %code.pointer = getelementptr %topal.ErrorStorage, ptr %error, i32 0, i32 1
  %domain = load ptr, ptr %domain.pointer, align 8
  %code = load i32, ptr %code.pointer, align 4
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.error.prefix, i64 18)
  call void @topal.tail.component.runtime.string.raw.print(ptr %domain)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.error.code.separator, i64 10)
  call void @topal.tail.component.runtime.error.code.print(i32 %code)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.error.suffix, i64 2)
  ret void
}

define internal void @topal.tail.component.runtime.error.code.print(i32 %code) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  switch i32 %code, label %indeterminate [ i32 0, label %out.of.range i32 1, label %not.representable i32 2, label %division.by.zero ]
out.of.range:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.error.code.out.of.range, i64 12)
  br label %done
not.representable:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.error.code.not.representable, i64 17)
  br label %done
division.by.zero:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.error.code.division.by.zero, i64 16)
  br label %done
indeterminate:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.error.code.indeterminate, i64 13)
  br label %done
done:
  ret void
}

define internal ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.valid = icmp ule i64 %length, 2305843009213693947
  br i1 %length.valid, label %allocate, label %failure
allocate:
  %limb.bytes = mul i64 %length, 4
  %bytes = add i64 %limb.bytes, 16
  %value = call ptr @topal.tail.component.platform.allocate(i64 %bytes)
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  store i64 %negative, ptr %negative.pointer, align 8
  store i64 %length, ptr %length.pointer, align 8
  ret ptr %value
failure:
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
}

define internal ptr @topal.tail.component.runtime.int.from.u64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %is.zero = icmp eq i64 %source, 0
  br i1 %is.zero, label %zero, label %nonzero
zero:
  ret ptr @topal.tail.component.runtime.int.zero
nonzero:
  %high.source = lshr i64 %source, 32
  %has.high = icmp ne i64 %high.source, 0
  %length = select i1 %has.high, i64 2, i64 1
  %value = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 0)
  %low = trunc i64 %source to i32
  %low.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  store i32 %low, ptr %low.pointer, align 4
  br i1 %has.high, label %store.high, label %done
store.high:
  %high = trunc i64 %high.source to i32
  %high.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 1
  store i32 %high, ptr %high.pointer, align 4
  br label %done
done:
  ret ptr %value
}

define internal ptr @topal.tail.component.runtime.int.from.i64(i64 %source) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = icmp slt i64 %source, 0
  %negated = sub i64 0, %source
  %magnitude = select i1 %negative, i64 %negated, i64 %source
  %value = call ptr @topal.tail.component.runtime.int.from.u64(i64 %magnitude)
  br i1 %negative, label %signed, label %done
signed:
  %negative.value = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 1)
  ret ptr %negative.value
done:
  ret ptr %value
}

define internal i32 @topal.tail.component.runtime.int.to.c.i32(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %sign = load i64, ptr %sign.pointer, align 8
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %return.zero, label %nonzero
return.zero:
  ret i32 0
nonzero:
  %one.limb = icmp eq i64 %length, 1
  %finite.sign = icmp ule i64 %sign, 1
  %shape.valid = and i1 %one.limb, %finite.sign
  br i1 %shape.valid, label %load, label %failure
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 0
  %limb = load i32, ptr %limb.pointer, align 4
  %negative = icmp eq i64 %sign, 1
  %positive.valid = icmp ule i32 %limb, 2147483647
  %negative.valid = icmp ule i32 %limb, 2147483648
  %range.valid = select i1 %negative, i1 %negative.valid, i1 %positive.valid
  br i1 %range.valid, label %convert, label %failure
convert:
  %negated = sub i32 0, %limb
  %result = select i1 %negative, i32 %negated, i32 %limb
  ret i32 %result
failure:
  call void @topal.tail.component.runtime.c.int32.range.fail()
  unreachable
}

define internal i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %present = icmp ult i64 %index, %length
  br i1 %present, label %load, label %zero
load:
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %extended = zext i32 %limb to i64
  ret i64 %extended
zero:
  ret i64 0
}

define internal ptr @topal.tail.component.runtime.int.normalize(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %trim
trim:
  %candidate = phi i64 [%length, %entry], [%next, %leading.zero]
  %index = sub i64 %candidate, 1
  %limb.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %limb.pointer, align 4
  %is.zero = icmp eq i32 %limb, 0
  br i1 %is.zero, label %leading.zero, label %done
leading.zero:
  %next = sub i64 %candidate, 1
  %now.empty = icmp eq i64 %next, 0
  br i1 %now.empty, label %zero, label %trim
zero:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  store i64 0, ptr %negative.pointer, align 8
  store i64 0, ptr %length.pointer, align 8
  ret ptr %value
done:
  store i64 %candidate, ptr %length.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %allocate
zero:
  ret ptr @topal.tail.component.runtime.int.zero
allocate:
  %copy = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %allocate], [%next, %loop]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr %topal.IntStorage, ptr %copy, i32 0, i32 2, i64 %index
  store i32 %limb, ptr %destination, align 4
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  ret ptr %copy
}

define internal ptr @topal.tail.component.runtime.int.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  ret ptr @topal.tail.component.runtime.int.negative.infinity
negative.infinity:
  ret ptr @topal.tail.component.runtime.int.positive.infinity
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %copy
zero:
  ret ptr @topal.tail.component.runtime.int.zero
copy:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %opposite = xor i64 %negative, 1
  %result = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 %opposite)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.int.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %negative = load i64, ptr %negative.pointer, align 8
  %positive.infinity = icmp eq i64 %negative, 2
  %negative.infinity = icmp eq i64 %negative, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %infinite, label %finite
infinite:
  ret ptr @topal.tail.component.runtime.int.positive.infinity
finite:
  %already.absolute = icmp eq i64 %negative, 0
  br i1 %already.absolute, label %same, label %copy
same:
  ret ptr %value
copy:
  %result = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %value, i64 0)
  ret ptr %result
}

define internal i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %shorter = icmp ult i64 %left.length, %right.length
  br i1 %shorter, label %less, label %check.longer
check.longer:
  %longer = icmp ugt i64 %left.length, %right.length
  br i1 %longer, label %greater, label %check.empty
check.empty:
  %empty = icmp eq i64 %left.length, 0
  br i1 %empty, label %equal, label %limbs
limbs:
  %position = phi i64 [%left.length, %check.empty], [%index, %limbs.equal]
  %index = sub i64 %position, 1
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %index
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %index
  %left.limb = load i32, ptr %left.pointer, align 4
  %right.limb = load i32, ptr %right.pointer, align 4
  %limb.less = icmp ult i32 %left.limb, %right.limb
  br i1 %limb.less, label %less, label %check.limb.greater
check.limb.greater:
  %limb.greater = icmp ugt i32 %left.limb, %right.limb
  br i1 %limb.greater, label %greater, label %limbs.equal
limbs.equal:
  %more = icmp ne i64 %index, 0
  br i1 %more, label %limbs, label %equal
less:
  ret i32 -1
equal:
  ret i32 0
greater:
  ret i32 1
}

define internal i32 @topal.tail.component.runtime.int.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  br i1 %left.positive.infinity, label %left.positive, label %check.left.negative.infinity
left.positive:
  %both.positive.infinity = icmp eq i64 %right.sign, 2
  %left.positive.result = select i1 %both.positive.infinity, i32 0, i32 1
  ret i32 %left.positive.result
check.left.negative.infinity:
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  br i1 %left.negative.infinity, label %left.negative, label %check.right.positive.infinity
left.negative:
  %both.negative.infinity = icmp eq i64 %right.sign, 3
  %left.negative.result = select i1 %both.negative.infinity, i32 0, i32 -1
  ret i32 %left.negative.result
check.right.positive.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  br i1 %right.positive.infinity, label %less, label %check.right.negative.infinity
check.right.negative.infinity:
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  br i1 %right.negative.infinity, label %greater, label %finite
less:
  ret i32 -1
greater:
  ret i32 1
finite:
  %different.signs = icmp ne i64 %left.sign, %right.sign
  br i1 %different.signs, label %signed.result, label %absolute
signed.result:
  %left.is.negative = icmp ne i64 %left.sign, 0
  %result = select i1 %left.is.negative, i32 -1, i32 1
  ret i32 %result
absolute:
  %magnitude = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right)
  %both.negative = icmp ne i64 %left.sign, 0
  %reversed = sub i32 0, %magnitude
  %ordered = select i1 %both.negative, i32 %reversed, i32 %magnitude
  ret i32 %ordered
}

define internal ptr @topal.tail.component.runtime.int.add.absolute(ptr %left, ptr %right, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.longer = icmp ugt i64 %left.length, %right.length
  %maximum = select i1 %left.longer, i64 %left.length, i64 %right.length
  %result.length = add i64 %maximum, 1
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %result.length, i64 %negative)
  %none = icmp eq i64 %maximum, 0
  br i1 %none, label %finish, label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %carry = phi i64 [0, %entry], [%next.carry, %loop]
  %left.limb = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %left, i64 %index)
  %right.limb = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %right, i64 %index)
  %pair = add i64 %left.limb, %right.limb
  %sum = add i64 %pair, %carry
  %low = trunc i64 %sum to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.carry = lshr i64 %sum, 32
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %maximum
  br i1 %more, label %loop, label %finish
finish:
  %final.carry = phi i64 [0, %entry], [%next.carry, %loop]
  %carry.present = icmp ne i64 %final.carry, 0
  br i1 %carry.present, label %store.carry, label %without.carry
store.carry:
  %carry.limb = trunc i64 %final.carry to i32
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %maximum
  store i32 %carry.limb, ptr %carry.pointer, align 4
  ret ptr %result
without.carry:
  %result.length.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 1
  store i64 %maximum, ptr %result.length.pointer, align 8
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %larger, ptr %smaller, i64 %negative) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %larger, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %length, i64 %negative)
  br label %loop
loop:
  %index = phi i64 [0, %entry], [%next, %loop]
  %borrow = phi i64 [0, %entry], [%next.borrow, %loop]
  %left = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %larger, i64 %index)
  %right = call i64 @topal.tail.component.runtime.int.limb.or.zero(ptr %smaller, i64 %index)
  %subtrahend = add i64 %right, %borrow
  %needs.borrow = icmp ult i64 %left, %subtrahend
  %extension = select i1 %needs.borrow, i64 4294967296, i64 0
  %extended.left = add i64 %left, %extension
  %difference = sub i64 %extended.left, %subtrahend
  %low = trunc i64 %difference to i32
  %destination = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %index
  store i32 %low, ptr %destination, align 4
  %next.borrow = zext i1 %needs.borrow to i64
  %next = add i64 %index, 1
  %more = icmp ult i64 %next, %length
  br i1 %more, label %loop, label %done
done:
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal ptr @topal.tail.component.runtime.int.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  br i1 %left.infinity, label %validate.left.infinity, label %check.right.infinity
validate.left.infinity:
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %different.infinity = icmp ne i64 %left.sign, %right.sign
  %indeterminate = and i1 %right.infinity, %different.infinity
  br i1 %indeterminate, label %indeterminate.infinity, label %return.left.infinity
indeterminate.infinity:
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable
return.left.infinity:
  ret ptr %left
check.right.infinity:
  %right.is.positive.infinity = icmp eq i64 %right.sign, 2
  %right.is.negative.infinity = icmp eq i64 %right.sign, 3
  %right.is.infinity = or i1 %right.is.positive.infinity, %right.is.negative.infinity
  br i1 %right.is.infinity, label %return.right.infinity, label %finite
return.right.infinity:
  ret ptr %right
finite:
  %left.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %left)
  br i1 %left.zero, label %return.right, label %check.right
return.right:
  ret ptr %right
check.right:
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %return.left, label %nonzero
return.left:
  ret ptr %left
nonzero:
  %left.negative.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.negative.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.negative = load i64, ptr %left.negative.pointer, align 8
  %right.negative = load i64, ptr %right.negative.pointer, align 8
  %same.sign = icmp eq i64 %left.negative, %right.negative
  br i1 %same.sign, label %sum, label %difference
sum:
  %sum.value = call ptr @topal.tail.component.runtime.int.add.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %sum.value
difference:
  %ordering = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %left, ptr %right)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %zero, label %select.larger
zero:
  ret ptr @topal.tail.component.runtime.int.zero
select.larger:
  %left.larger = icmp sgt i32 %ordering, 0
  br i1 %left.larger, label %left.difference, label %right.difference
left.difference:
  %left.value = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %left, ptr %right, i64 %left.negative)
  ret ptr %left.value
right.difference:
  %right.value = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %right, ptr %left, i64 %right.negative)
  ret ptr %right.value
}

define internal ptr @topal.tail.component.runtime.int.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %opposite = call ptr @topal.tail.component.runtime.int.negate(ptr %right)
  %result = call ptr @topal.tail.component.runtime.int.add(ptr %left, ptr %opposite)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.int.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %left.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %left)
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  %either.zero = or i1 %left.zero, %right.zero
  br i1 %either.zero, label %indeterminate.infinity, label %select.infinity
indeterminate.infinity:
  call void @topal.tail.component.platform.exit(i64 70)
  unreachable
select.infinity:
  %left.negative = and i64 %left.sign, 1
  %right.negative = and i64 %right.sign, 1
  %negative = xor i64 %left.negative, %right.negative
  %result.negative = icmp ne i64 %negative, 0
  %infinity = select i1 %result.negative, ptr @topal.tail.component.runtime.int.negative.infinity, ptr @topal.tail.component.runtime.int.positive.infinity
  ret ptr %infinity
finite:
  %left.length.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 1
  %right.length.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 1
  %left.length = load i64, ptr %left.length.pointer, align 8
  %right.length = load i64, ptr %right.length.pointer, align 8
  %left.empty = icmp eq i64 %left.length, 0
  %right.empty = icmp eq i64 %right.length, 0
  %empty = or i1 %left.empty, %right.empty
  br i1 %empty, label %zero, label %check.length
zero:
  ret ptr @topal.tail.component.runtime.int.zero
check.length:
  %available = sub i64 -1, %left.length
  %overflow = icmp ugt i64 %right.length, %available
  br i1 %overflow, label %failure, label %allocate
failure:
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
allocate:
  %result.length = add i64 %left.length, %right.length
  %finite.negative = xor i64 %left.sign, %right.sign
  %result = call ptr @topal.tail.component.runtime.int.allocate(i64 %result.length, i64 %finite.negative)
  br label %clear
clear:
  %clear.index = phi i64 [0, %allocate], [%clear.next, %clear]
  %clear.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %clear.index
  store i32 0, ptr %clear.pointer, align 4
  %clear.next = add i64 %clear.index, 1
  %clear.more = icmp ult i64 %clear.next, %result.length
  br i1 %clear.more, label %clear, label %outer.entry
outer.entry:
  br label %outer
outer:
  %left.index = phi i64 [0, %outer.entry], [%left.next, %outer.done]
  %left.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 2, i64 %left.index
  %left.limb.raw = load i32, ptr %left.pointer, align 4
  %left.limb = zext i32 %left.limb.raw to i64
  br label %inner
inner:
  %right.index = phi i64 [0, %outer], [%right.next, %inner]
  %carry = phi i64 [0, %outer], [%next.carry, %inner]
  %right.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 2, i64 %right.index
  %right.limb.raw = load i32, ptr %right.pointer, align 4
  %right.limb = zext i32 %right.limb.raw to i64
  %result.index = add i64 %left.index, %right.index
  %result.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %result.index
  %existing.raw = load i32, ptr %result.pointer, align 4
  %existing = zext i32 %existing.raw to i64
  %product = mul i64 %left.limb, %right.limb
  %partial = add i64 %product, %existing
  %total = add i64 %partial, %carry
  %low = trunc i64 %total to i32
  store i32 %low, ptr %result.pointer, align 4
  %next.carry = lshr i64 %total, 32
  %right.next = add i64 %right.index, 1
  %right.more = icmp ult i64 %right.next, %right.length
  br i1 %right.more, label %inner, label %outer.done
outer.done:
  %carry.index = add i64 %left.index, %right.length
  %carry.pointer = getelementptr %topal.IntStorage, ptr %result, i32 0, i32 2, i64 %carry.index
  %carry.limb = trunc i64 %next.carry to i32
  store i32 %carry.limb, ptr %carry.pointer, align 4
  %left.next = add i64 %left.index, 1
  %left.more = icmp ult i64 %left.next, %left.length
  br i1 %left.more, label %outer, label %done
done:
  %normalized = call ptr @topal.tail.component.runtime.int.normalize(ptr %result)
  ret ptr %normalized
}

define internal void @topal.tail.component.runtime.int.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  switch i64 %sign, label %finite [ i64 2, label %positive.infinity i64 3, label %negative.infinity ]
positive.infinity:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.int.positive.infinity.text, i64 9)
  ret void
negative.infinity:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.int.negative.infinity.text, i64 9)
  ret void
finite:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check.sign
zero:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.byte.zero, i64 1)
  ret void
check.sign:
  %is.negative = icmp ne i64 %sign, 0
  br i1 %is.negative, label %write.sign, label %prepare
write.sign:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.byte.minus, i64 1)
  br label %prepare
prepare:
  %capacity.valid = icmp ule i64 %length, 922337203685477580
  br i1 %capacity.valid, label %allocate, label %failure
failure:
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
allocate:
  %scratch.bytes = mul i64 %length, 4
  %capacity = mul i64 %length, 10
  %scratch = call ptr @topal.tail.component.platform.allocate(i64 %scratch.bytes)
  %buffer = call ptr @topal.tail.component.platform.allocate(i64 %capacity)
  br label %copy
copy:
  %copy.index = phi i64 [0, %allocate], [%copy.next, %copy]
  %source = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %copy.index
  %limb = load i32, ptr %source, align 4
  %destination = getelementptr i32, ptr %scratch, i64 %copy.index
  store i32 %limb, ptr %destination, align 4
  %copy.next = add i64 %copy.index, 1
  %copy.more = icmp ult i64 %copy.next, %length
  br i1 %copy.more, label %copy, label %digits
digits:
  %work.length = phi i64 [%length, %copy], [%next.length, %division.finish]
  %position = phi i64 [%capacity, %copy], [%next.position, %division.finish]
  br label %divide
divide:
  %division.position = phi i64 [%work.length, %digits], [%division.index, %divide.step]
  %remainder = phi i64 [0, %digits], [%next.remainder, %divide.step]
  %division.index = sub i64 %division.position, 1
  %work.pointer = getelementptr i32, ptr %scratch, i64 %division.index
  %work.raw = load i32, ptr %work.pointer, align 4
  %work = zext i32 %work.raw to i64
  %high = shl i64 %remainder, 32
  %current = or i64 %high, %work
  %quotient = udiv i64 %current, 10
  %next.remainder = urem i64 %current, 10
  %quotient.limb = trunc i64 %quotient to i32
  store i32 %quotient.limb, ptr %work.pointer, align 4
  %division.more = icmp ne i64 %division.index, 0
  br i1 %division.more, label %divide.step, label %division.done
divide.step:
  br label %divide
division.done:
  %next.position = sub i64 %position, 1
  %digit = trunc i64 %next.remainder to i8
  %ascii = add i8 %digit, 48
  %digit.pointer = getelementptr i8, ptr %buffer, i64 %next.position
  store i8 %ascii, ptr %digit.pointer, align 1
  br label %trim
trim:
  %candidate = phi i64 [%work.length, %division.done], [%trim.next, %trim.zero]
  %trim.index = sub i64 %candidate, 1
  %trim.pointer = getelementptr i32, ptr %scratch, i64 %trim.index
  %trim.limb = load i32, ptr %trim.pointer, align 4
  %leading.zero = icmp eq i32 %trim.limb, 0
  br i1 %leading.zero, label %trim.zero, label %trim.done
trim.zero:
  %trim.next = sub i64 %candidate, 1
  %trim.empty = icmp eq i64 %trim.next, 0
  br i1 %trim.empty, label %trim.empty.done, label %trim
trim.empty.done:
  br label %division.finish
trim.done:
  br label %division.finish
division.finish:
  %next.length = phi i64 [0, %trim.empty.done], [%candidate, %trim.done]
  %more.digits = icmp ne i64 %next.length, 0
  br i1 %more.digits, label %digits, label %emit
emit:
  %count = sub i64 %capacity, %next.position
  %first = getelementptr i8, ptr %buffer, i64 %next.position
  call void @topal.tail.component.platform.write_all(ptr %first, i64 %count)
  ret void
}

define internal i1 @topal.tail.component.runtime.int.is.zero(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %finite = icmp ult i64 %sign, 2
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  %zero = and i1 %finite, %empty
  ret i1 %zero
}

define internal ptr @topal.tail.component.runtime.int.divmod.pair(ptr %quotient, ptr %remainder) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.tail.component.platform.allocate(i64 16)
  %quotient.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %remainder.pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  store ptr %quotient, ptr %quotient.pointer, align 8
  store ptr %remainder, ptr %remainder.pointer, align 8
  ret ptr %pair
}

define internal ptr @topal.tail.component.runtime.int.divmod.quotient(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.tail.component.runtime.int.divmod.remainder(ptr %pair) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.IntDivmod, ptr %pair, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i64 @topal.tail.component.runtime.int.bit.length(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %length.pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %empty = icmp eq i64 %length, 0
  br i1 %empty, label %zero, label %check
zero:
  ret i64 0
check:
  %valid = icmp ule i64 %length, 576460752303423487
  br i1 %valid, label %calculate, label %failure
failure:
  call void @topal.tail.component.platform.exit(i64 71)
  unreachable
calculate:
  %last = sub i64 %length, 1
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %last
  %limb = load i32, ptr %pointer, align 4
  %leading = call i32 @llvm.ctlz.i32(i32 %limb, i1 false)
  %top.bits.raw = sub i32 32, %leading
  %top.bits = zext i32 %top.bits.raw to i64
  %lower.bits = mul i64 %last, 32
  %bits = add i64 %lower.bits, %top.bits
  ret i64 %bits
}

define internal i1 @topal.tail.component.runtime.int.bit.at(ptr %value, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %limb.index = lshr i64 %index, 5
  %offset.raw = and i64 %index, 31
  %offset = trunc i64 %offset.raw to i32
  %pointer = getelementptr %topal.IntStorage, ptr %value, i32 0, i32 2, i64 %limb.index
  %limb = load i32, ptr %pointer, align 4
  %shifted = lshr i32 %limb, %offset
  %bit.raw = and i32 %shifted, 1
  %bit = icmp ne i32 %bit.raw, 0
  ret i1 %bit
}

define internal ptr @topal.tail.component.runtime.int.divmod.absolute(ptr %dividend, ptr %divisor) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %divisor.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %divisor)
  br i1 %divisor.zero, label %failure, label %check.dividend
failure:
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
check.dividend:
  %dividend.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %dividend)
  br i1 %dividend.zero, label %zero, label %prepare
zero:
  %zero.pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr @topal.tail.component.runtime.int.zero, ptr @topal.tail.component.runtime.int.zero)
  ret ptr %zero.pair
prepare:
  %bits = call i64 @topal.tail.component.runtime.int.bit.length(ptr %dividend)
  br label %loop
loop:
  %position = phi i64 [%bits, %prepare], [%next.position, %merge]
  %quotient = phi ptr [@topal.tail.component.runtime.int.zero, %prepare], [%next.quotient, %merge]
  %remainder = phi ptr [@topal.tail.component.runtime.int.zero, %prepare], [%next.remainder, %merge]
  %bit.index = sub i64 %position, 1
  %bit = call i1 @topal.tail.component.runtime.int.bit.at(ptr %dividend, i64 %bit.index)
  %quotient.twice = call ptr @topal.tail.component.runtime.int.add(ptr %quotient, ptr %quotient)
  %remainder.twice = call ptr @topal.tail.component.runtime.int.add(ptr %remainder, ptr %remainder)
  br i1 %bit, label %append.bit, label %compare
append.bit:
  %remainder.with.bit = call ptr @topal.tail.component.runtime.int.add(ptr %remainder.twice, ptr @topal.tail.component.runtime.int.one)
  br label %compare
compare:
  %candidate = phi ptr [%remainder.twice, %loop], [%remainder.with.bit, %append.bit]
  %ordering = call i32 @topal.tail.component.runtime.int.compare.absolute(ptr %candidate, ptr %divisor)
  %subtract = icmp sge i32 %ordering, 0
  br i1 %subtract, label %subtract.divisor, label %retain
subtract.divisor:
  %reduced = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %candidate, ptr %divisor, i64 0)
  %incremented = call ptr @topal.tail.component.runtime.int.add(ptr %quotient.twice, ptr @topal.tail.component.runtime.int.one)
  br label %merge
retain:
  br label %merge
merge:
  %next.quotient = phi ptr [%incremented, %subtract.divisor], [%quotient.twice, %retain]
  %next.remainder = phi ptr [%reduced, %subtract.divisor], [%candidate, %retain]
  %next.position = sub i64 %position, 1
  %more = icmp ne i64 %next.position, 0
  br i1 %more, label %loop, label %done
done:
  %pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr %next.quotient, ptr %next.remainder)
  ret ptr %pair
}

define internal ptr @topal.tail.component.runtime.int.quotient.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %divide
failure:
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
divide:
  %left.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %right)
  %unsigned = call ptr @topal.tail.component.runtime.int.divmod.absolute(ptr %left.absolute, ptr %right.absolute)
  %quotient.absolute = call ptr @topal.tail.component.runtime.int.divmod.quotient(ptr %unsigned)
  %remainder.absolute = call ptr @topal.tail.component.runtime.int.divmod.remainder(ptr %unsigned)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.negative = icmp ne i64 %left.sign, 0
  %remainder.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %remainder.absolute)
  %remainder.present = xor i1 %remainder.zero, true
  %needs.adjustment = and i1 %left.negative, %remainder.present
  %quotient.sign = xor i64 %left.sign, %right.sign
  br i1 %needs.adjustment, label %adjust, label %direct
direct:
  %direct.quotient = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %quotient.absolute, i64 %quotient.sign)
  %direct.pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr %direct.quotient, ptr %remainder.absolute)
  ret ptr %direct.pair
adjust:
  %larger.quotient = call ptr @topal.tail.component.runtime.int.add(ptr %quotient.absolute, ptr @topal.tail.component.runtime.int.one)
  %adjusted.quotient = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %larger.quotient, i64 %quotient.sign)
  %adjusted.remainder = call ptr @topal.tail.component.runtime.int.subtract.absolute(ptr %right.absolute, ptr %remainder.absolute, i64 0)
  %adjusted.pair = call ptr @topal.tail.component.runtime.int.divmod.pair(ptr %adjusted.quotient, ptr %adjusted.remainder)
  ret ptr %adjusted.pair
}

define internal ptr @topal.tail.component.runtime.int.modulo(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pair = call ptr @topal.tail.component.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %remainder = call ptr @topal.tail.component.runtime.int.divmod.remainder(ptr %pair)
  ret ptr %remainder
}

define internal ptr @topal.tail.component.runtime.int.try.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.tail.component.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %remainder = call ptr @topal.tail.component.runtime.int.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.tail.component.runtime.result.success(ptr %remainder)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.int.try.quotient.modulo(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.tail.component.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %pair = call ptr @topal.tail.component.runtime.int.quotient.modulo(ptr %left, ptr %right)
  %result = call ptr @topal.tail.component.runtime.result.success(ptr %pair)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.int.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %negative = icmp ne i64 %sign, 0
  br i1 %negative, label %failure, label %prepare
failure:
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
prepare:
  %bits = call i64 @topal.tail.component.runtime.int.bit.length(ptr %exponent)
  %empty = icmp eq i64 %bits, 0
  br i1 %empty, label %one, label %loop
one:
  ret ptr @topal.tail.component.runtime.int.one
loop:
  %position = phi i64 [0, %prepare], [%next.position, %square]
  %result = phi ptr [@topal.tail.component.runtime.int.one, %prepare], [%next.result, %square]
  %factor = phi ptr [%base, %prepare], [%next.factor, %square]
  %bit = call i1 @topal.tail.component.runtime.int.bit.at(ptr %exponent, i64 %position)
  br i1 %bit, label %multiply, label %retain
multiply:
  %product = call ptr @topal.tail.component.runtime.int.multiply(ptr %result, ptr %factor)
  br label %advance
retain:
  br label %advance
advance:
  %next.result = phi ptr [%product, %multiply], [%result, %retain]
  %next.position = add i64 %position, 1
  %complete = icmp eq i64 %next.position, %bits
  br i1 %complete, label %done, label %square
square:
  %next.factor = call ptr @topal.tail.component.runtime.int.multiply(ptr %factor, ptr %factor)
  br label %loop
done:
  ret ptr %next.result
}

define internal ptr @topal.tail.component.runtime.int.greatest.common.divisor(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %left)
  %right.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %right)
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right.absolute)
  br i1 %right.zero, label %initial.done, label %loop
initial.done:
  ret ptr %left.absolute
loop:
  %current.left = phi ptr [%left.absolute, %entry], [%current.right, %again]
  %current.right = phi ptr [%right.absolute, %entry], [%remainder, %again]
  %division = call ptr @topal.tail.component.runtime.int.divmod.absolute(ptr %current.left, ptr %current.right)
  %remainder = call ptr @topal.tail.component.runtime.int.divmod.remainder(ptr %division)
  %done = call i1 @topal.tail.component.runtime.int.is.zero(ptr %remainder)
  br i1 %done, label %result, label %again
again:
  br label %loop
result:
  ret ptr %current.right
}

define internal ptr @topal.tail.component.runtime.rational.raw(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.tail.component.platform.allocate(i64 16)
  %numerator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %denominator.pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  store ptr %numerator, ptr %numerator.pointer, align 8
  store ptr %denominator, ptr %denominator.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.tail.component.runtime.rational.numerator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 0
  %numerator = load ptr, ptr %pointer, align 8
  ret ptr %numerator
}

define internal ptr @topal.tail.component.runtime.rational.denominator(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RationalStorage, ptr %value, i32 0, i32 1
  %denominator = load ptr, ptr %pointer, align 8
  ret ptr %denominator
}

define internal ptr @topal.tail.component.runtime.rational.make(ptr %numerator, ptr %denominator) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %numerator.sign = load i64, ptr %numerator.sign.pointer, align 8
  %positive.infinity = icmp eq i64 %numerator.sign, 2
  %negative.infinity = icmp eq i64 %numerator.sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %make.infinity, label %finite
make.infinity:
  %infinite.value = call ptr @topal.tail.component.runtime.rational.raw(ptr %numerator, ptr @topal.tail.component.runtime.int.one)
  ret ptr %infinite.value
finite:
  %denominator.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %check.numerator
failure:
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
check.numerator:
  %numerator.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %numerator)
  br i1 %numerator.zero, label %zero, label %normalize
zero:
  %zero.value = call ptr @topal.tail.component.runtime.rational.raw(ptr @topal.tail.component.runtime.int.zero, ptr @topal.tail.component.runtime.int.one)
  ret ptr %zero.value
normalize:
  %numerator.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %numerator)
  %denominator.absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %denominator)
  %divisor = call ptr @topal.tail.component.runtime.int.greatest.common.divisor(ptr %numerator.absolute, ptr %denominator.absolute)
  %numerator.division = call ptr @topal.tail.component.runtime.int.divmod.absolute(ptr %numerator.absolute, ptr %divisor)
  %denominator.division = call ptr @topal.tail.component.runtime.int.divmod.absolute(ptr %denominator.absolute, ptr %divisor)
  %reduced.numerator.absolute = call ptr @topal.tail.component.runtime.int.divmod.quotient(ptr %numerator.division)
  %reduced.denominator = call ptr @topal.tail.component.runtime.int.divmod.quotient(ptr %denominator.division)
  %finite.numerator.sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %finite.denominator.sign.pointer = getelementptr %topal.IntStorage, ptr %denominator, i32 0, i32 0
  %finite.numerator.sign = load i64, ptr %finite.numerator.sign.pointer, align 8
  %finite.denominator.sign = load i64, ptr %finite.denominator.sign.pointer, align 8
  %sign = xor i64 %finite.numerator.sign, %finite.denominator.sign
  %reduced.numerator = call ptr @topal.tail.component.runtime.int.copy.with.sign(ptr %reduced.numerator.absolute, i64 %sign)
  %result = call ptr @topal.tail.component.runtime.rational.raw(ptr %reduced.numerator, ptr %reduced.denominator)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.from.int(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %result = call ptr @topal.tail.component.runtime.rational.raw(ptr %value, ptr @topal.tail.component.runtime.int.one)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.negate(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %value)
  %negative = call ptr @topal.tail.component.runtime.int.negate(ptr %numerator)
  %result = call ptr @topal.tail.component.runtime.rational.raw(ptr %negative, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.absolute(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %value)
  %absolute = call ptr @topal.tail.component.runtime.int.absolute(ptr %numerator)
  %result = call ptr @topal.tail.component.runtime.rational.raw(ptr %absolute, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.add(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %right)
  %left.scaled = call ptr @topal.tail.component.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.tail.component.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %numerator = call ptr @topal.tail.component.runtime.int.add(ptr %left.scaled, ptr %right.scaled)
  %denominator = call ptr @topal.tail.component.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.tail.component.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.subtract(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %negative = call ptr @topal.tail.component.runtime.rational.negate(ptr %right)
  %result = call ptr @topal.tail.component.runtime.rational.add(ptr %left, ptr %negative)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.multiply(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %right)
  %numerator = call ptr @topal.tail.component.runtime.int.multiply(ptr %left.numerator, ptr %right.numerator)
  %denominator = call ptr @topal.tail.component.runtime.int.multiply(ptr %left.denominator, ptr %right.denominator)
  %result = call ptr @topal.tail.component.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.divide(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %right)
  %zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right.numerator)
  br i1 %zero, label %failure, label %calculate
failure:
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
calculate:
  %numerator = call ptr @topal.tail.component.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %denominator = call ptr @topal.tail.component.runtime.int.multiply(ptr %left.denominator, ptr %right.numerator)
  %result = call ptr @topal.tail.component.runtime.rational.make(ptr %numerator, ptr %denominator)
  ret ptr %result
}

define internal i32 @topal.tail.component.runtime.rational.compare(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %left)
  %left.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %left)
  %right.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %right)
  %right.denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %right)
  %left.sign.pointer = getelementptr %topal.IntStorage, ptr %left.numerator, i32 0, i32 0
  %right.sign.pointer = getelementptr %topal.IntStorage, ptr %right.numerator, i32 0, i32 0
  %left.sign = load i64, ptr %left.sign.pointer, align 8
  %right.sign = load i64, ptr %right.sign.pointer, align 8
  %left.positive.infinity = icmp eq i64 %left.sign, 2
  %left.negative.infinity = icmp eq i64 %left.sign, 3
  %left.infinity = or i1 %left.positive.infinity, %left.negative.infinity
  %right.positive.infinity = icmp eq i64 %right.sign, 2
  %right.negative.infinity = icmp eq i64 %right.sign, 3
  %right.infinity = or i1 %right.positive.infinity, %right.negative.infinity
  %either.infinity = or i1 %left.infinity, %right.infinity
  br i1 %either.infinity, label %infinite, label %finite
infinite:
  %infinite.result = call i32 @topal.tail.component.runtime.int.compare(ptr %left.numerator, ptr %right.numerator)
  ret i32 %infinite.result
finite:
  %left.scaled = call ptr @topal.tail.component.runtime.int.multiply(ptr %left.numerator, ptr %right.denominator)
  %right.scaled = call ptr @topal.tail.component.runtime.int.multiply(ptr %right.numerator, ptr %left.denominator)
  %result = call i32 @topal.tail.component.runtime.int.compare(ptr %left.scaled, ptr %right.scaled)
  ret i32 %result
}

define internal ptr @topal.tail.component.runtime.rational.power(ptr %base, ptr %exponent) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %base)
  %denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %base)
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  %absolute.exponent = call ptr @topal.tail.component.runtime.int.absolute(ptr %exponent)
  %powered.numerator = call ptr @topal.tail.component.runtime.int.power(ptr %numerator, ptr %absolute.exponent)
  %powered.denominator = call ptr @topal.tail.component.runtime.int.power(ptr %denominator, ptr %absolute.exponent)
  br i1 %negative, label %reciprocal, label %direct
direct:
  %direct.result = call ptr @topal.tail.component.runtime.rational.raw(ptr %powered.numerator, ptr %powered.denominator)
  ret ptr %direct.result
reciprocal:
  %zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %powered.numerator)
  br i1 %zero, label %failure, label %invert
failure:
  call void @topal.tail.component.platform.exit(i64 65)
  unreachable
invert:
  %result = call ptr @topal.tail.component.runtime.rational.make(ptr %powered.denominator, ptr %powered.numerator)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.try.make(ptr %numerator, ptr %denominator, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %denominator.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %denominator)
  br i1 %denominator.zero, label %failure, label %success
failure:
  %numerator.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %numerator)
  %code = select i1 %numerator.zero, i32 3, i32 2
  %failed = call ptr @topal.tail.component.runtime.result.failure(i32 %code, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.tail.component.runtime.rational.make(ptr %numerator, ptr %denominator)
  %result = call ptr @topal.tail.component.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.try.divide(ptr %left, ptr %right, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %right.numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %right)
  %right.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %right.numerator)
  br i1 %right.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.tail.component.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.tail.component.runtime.rational.divide(ptr %left, ptr %right)
  %result = call ptr @topal.tail.component.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.rational.try.power(ptr %base, ptr %exponent, ptr %domain, ptr %source, i64 %line, i64 %column) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %exponent.sign.pointer = getelementptr %topal.IntStorage, ptr %exponent, i32 0, i32 0
  %exponent.sign = load i64, ptr %exponent.sign.pointer, align 8
  %negative = icmp ne i64 %exponent.sign, 0
  br i1 %negative, label %check.base, label %success
check.base:
  %numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %base)
  %base.zero = call i1 @topal.tail.component.runtime.int.is.zero(ptr %numerator)
  br i1 %base.zero, label %failure, label %success
failure:
  %failed = call ptr @topal.tail.component.runtime.result.failure(i32 2, ptr %domain, ptr %source, i64 %line, i64 %column)
  ret ptr %failed
success:
  %ratio = call ptr @topal.tail.component.runtime.rational.power(ptr %base, ptr %exponent)
  %result = call ptr @topal.tail.component.runtime.result.success(ptr %ratio)
  ret ptr %result
}

define internal void @topal.tail.component.runtime.rational.print(ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %numerator = call ptr @topal.tail.component.runtime.rational.numerator(ptr %value)
  %denominator = call ptr @topal.tail.component.runtime.rational.denominator(ptr %value)
  %sign.pointer = getelementptr %topal.IntStorage, ptr %numerator, i32 0, i32 0
  %sign = load i64, ptr %sign.pointer, align 8
  %positive.infinity = icmp eq i64 %sign, 2
  %negative.infinity = icmp eq i64 %sign, 3
  %infinity = or i1 %positive.infinity, %negative.infinity
  br i1 %infinity, label %print.infinity, label %print.finite
print.infinity:
  call void @topal.tail.component.runtime.int.print(ptr %numerator)
  ret void
print.finite:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.rational.prefix, i64 11)
  call void @topal.tail.component.runtime.int.print(ptr %numerator)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.rational.separator, i64 2)
  call void @topal.tail.component.runtime.int.print(ptr %denominator)
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.rational.suffix, i64 2)
  ret void
}

define internal ptr @topal.tail.component.runtime.range.make(ptr %lower, ptr %upper, i64 %lower.inclusive, i64 %upper.inclusive) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %value = call ptr @topal.tail.component.platform.allocate(i64 32)
  %lower.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 0
  %upper.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 1
  %lower.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 2
  %upper.inclusive.pointer = getelementptr %topal.RangeStorage, ptr %value, i32 0, i32 3
  store ptr %lower, ptr %lower.pointer, align 8
  store ptr %upper, ptr %upper.pointer, align 8
  store i64 %lower.inclusive, ptr %lower.inclusive.pointer, align 8
  store i64 %upper.inclusive, ptr %upper.inclusive.pointer, align 8
  ret ptr %value
}

define internal ptr @topal.tail.component.runtime.range.lower(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 0
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal ptr @topal.tail.component.runtime.range.upper(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 1
  %value = load ptr, ptr %pointer, align 8
  ret ptr %value
}

define internal i1 @topal.tail.component.runtime.range.int.equal(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %left)
  %right.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %right)
  %lower.ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %left)
  %right.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %right)
  %upper.ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %bounds.equal = and i1 %lower.equal, %upper.equal
  %left.lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %right)
  %lower.inclusive.equal = icmp eq i1 %left.lower.inclusive, %right.lower.inclusive
  %left.upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %left)
  %right.upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %right)
  %upper.inclusive.equal = icmp eq i1 %left.upper.inclusive, %right.upper.inclusive
  %inclusivity.equal = and i1 %lower.inclusive.equal, %upper.inclusive.equal
  %equal = and i1 %bounds.equal, %inclusivity.equal
  ret i1 %equal
}

define internal i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 2
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = getelementptr %topal.RangeStorage, ptr %range, i32 0, i32 3
  %raw = load i64, ptr %pointer, align 8
  %value = icmp ne i64 %raw, 0
  ret i1 %value
}

define internal i1 @topal.tail.component.runtime.range.empty.from.comparison(ptr %range, i32 %ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %reversed = icmp sgt i32 %ordering, 0
  %equal = icmp eq i32 %ordering, 0
  %lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %range)
  %both.inclusive = and i1 %lower.inclusive, %upper.inclusive
  %open.equal = xor i1 %both.inclusive, true
  %empty.equal = and i1 %equal, %open.equal
  %empty = or i1 %reversed, %empty.equal
  ret i1 %empty
}

define internal i1 @topal.tail.component.runtime.range.int.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.tail.component.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.tail.component.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.tail.component.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.tail.component.runtime.range.rational.empty(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.tail.component.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.tail.component.runtime.range.upper(ptr %range)
  %ordering = call i32 @topal.tail.component.runtime.rational.compare(ptr %lower, ptr %upper)
  %empty = call i1 @topal.tail.component.runtime.range.empty.from.comparison(ptr %range, i32 %ordering)
  ret i1 %empty
}

define internal i1 @topal.tail.component.runtime.range.int.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.tail.component.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.tail.component.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal i1 @topal.tail.component.runtime.range.rational.contains(ptr %range, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.tail.component.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.tail.component.runtime.range.upper(ptr %range)
  %lower.ordering = call i32 @topal.tail.component.runtime.rational.compare(ptr %value, ptr %lower)
  %upper.ordering = call i32 @topal.tail.component.runtime.rational.compare(ptr %value, ptr %upper)
  %lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %range)
  %above.lower = icmp sgt i32 %lower.ordering, 0
  %at.lower = icmp eq i32 %lower.ordering, 0
  %included.lower = and i1 %at.lower, %lower.inclusive
  %lower.accepted = or i1 %above.lower, %included.lower
  %below.upper = icmp slt i32 %upper.ordering, 0
  %at.upper = icmp eq i32 %upper.ordering, 0
  %included.upper = and i1 %at.upper, %upper.inclusive
  %upper.accepted = or i1 %below.upper, %included.upper
  %accepted = and i1 %lower.accepted, %upper.accepted
  ret i1 %accepted
}

define internal ptr @topal.tail.component.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %right)
  %left.lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %left)
  %left.upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %left)
  %right.lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %right)
  %right.upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %right)
  %lower.equal = icmp eq i32 %lower.ordering, 0
  %left.lower.stricter = icmp sgt i32 %lower.ordering, 0
  %selected.lower = select i1 %left.lower.stricter, ptr %left.lower, ptr %right.lower
  %selected.lower.inclusive = select i1 %left.lower.stricter, i1 %left.lower.inclusive, i1 %right.lower.inclusive
  %equal.lower.inclusive = and i1 %left.lower.inclusive, %right.lower.inclusive
  %lower.inclusive = select i1 %lower.equal, i1 %equal.lower.inclusive, i1 %selected.lower.inclusive
  %upper.equal = icmp eq i32 %upper.ordering, 0
  %left.upper.stricter = icmp slt i32 %upper.ordering, 0
  %selected.upper = select i1 %left.upper.stricter, ptr %left.upper, ptr %right.upper
  %selected.upper.inclusive = select i1 %left.upper.stricter, i1 %left.upper.inclusive, i1 %right.upper.inclusive
  %equal.upper.inclusive = and i1 %left.upper.inclusive, %right.upper.inclusive
  %upper.inclusive = select i1 %upper.equal, i1 %equal.upper.inclusive, i1 %selected.upper.inclusive
  %lower.inclusive.raw = zext i1 %lower.inclusive to i64
  %upper.inclusive.raw = zext i1 %upper.inclusive to i64
  %result = call ptr @topal.tail.component.runtime.range.make(ptr %selected.lower, ptr %selected.upper, i64 %lower.inclusive.raw, i64 %upper.inclusive.raw)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.range.int.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.tail.component.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal ptr @topal.tail.component.runtime.range.rational.intersection(ptr %left, ptr %right) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %left.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %left)
  %left.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %left)
  %right.lower = call ptr @topal.tail.component.runtime.range.lower(ptr %right)
  %right.upper = call ptr @topal.tail.component.runtime.range.upper(ptr %right)
  %lower.ordering = call i32 @topal.tail.component.runtime.rational.compare(ptr %left.lower, ptr %right.lower)
  %upper.ordering = call i32 @topal.tail.component.runtime.rational.compare(ptr %left.upper, ptr %right.upper)
  %result = call ptr @topal.tail.component.runtime.range.intersection.from.orderings(ptr %left, ptr %right, i32 %lower.ordering, i32 %upper.ordering)
  ret ptr %result
}

define internal void @topal.tail.component.runtime.range.print.symbol(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower.inclusive = call i1 @topal.tail.component.runtime.range.lower.inclusive(ptr %range)
  %upper.inclusive = call i1 @topal.tail.component.runtime.range.upper.inclusive(ptr %range)
  br i1 %lower.inclusive, label %lower.closed, label %lower.open
lower.closed:
  br i1 %upper.inclusive, label %closed.closed, label %closed.open
lower.open:
  br i1 %upper.inclusive, label %open.closed, label %open.open
closed.closed:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.range.closed.closed, i64 5)
  ret void
closed.open:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.range.closed.open, i64 4)
  ret void
open.closed:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.range.open.closed, i64 6)
  ret void
open.open:
  call void @topal.tail.component.platform.write_all(ptr @topal.tail.component.runtime.range.open.open, i64 5)
  ret void
}

define internal void @topal.tail.component.runtime.range.int.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.tail.component.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.tail.component.runtime.range.upper(ptr %range)
  call void @topal.tail.component.runtime.int.print(ptr %lower)
  call void @topal.tail.component.runtime.range.print.symbol(ptr %range)
  call void @topal.tail.component.runtime.int.print(ptr %upper)
  ret void
}

define internal void @topal.tail.component.runtime.range.rational.print(ptr %range) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %lower = call ptr @topal.tail.component.runtime.range.lower(ptr %range)
  %upper = call ptr @topal.tail.component.runtime.range.upper(ptr %range)
  call void @topal.tail.component.runtime.rational.print(ptr %lower)
  call void @topal.tail.component.runtime.range.print.symbol(ptr %range)
  call void @topal.tail.component.runtime.rational.print(ptr %upper)
  ret void
}
; Compiler-selected List Int layout for private topal-native/6 operations.

%topal.ListStorage = type { ptr, ptr }
; Compiler-private fundamental homogeneous containers. Construction may mutate
; unpublished result nodes; published Array, Set, Bag, and Map values are immutable.

%topal.ContainerSequenceHeader = type { i64, ptr }
%topal.ContainerBagHeader = type { i64, i64, ptr }
%topal.ContainerBagNode = type { ptr, i64, ptr }
%topal.ContainerMapNode = type { ptr, ptr, ptr }

define internal i64 @topal.tail.component.runtime.container.list.count(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %count.next = add i64 %count, 1
  br label %loop
done:
  ret i64 %count
}

define internal ptr @topal.tail.component.runtime.container.array.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.tail.component.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.tail.component.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal ptr @topal.tail.component.runtime.container.array.function.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = call i64 @topal.tail.component.runtime.container.list.count(ptr %list)
  %array = call ptr @topal.tail.component.platform.allocate(i64 16)
  %count.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 0
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  store i64 %count, ptr %count.pointer, align 8
  store ptr %list, ptr %entries.pointer, align 8
  ret ptr %array
}

define internal i1 @topal.tail.component.runtime.container.int.list.contains(ptr %list, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret i1 true
absent:
  ret i1 false
}

define internal ptr @topal.tail.component.runtime.container.set.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %duplicate = call i1 @topal.tail.component.runtime.container.int.list.contains(ptr %head, ptr %value)
  br i1 %duplicate, label %skip, label %add
add:
  %node = call ptr @topal.tail.component.platform.allocate(i64 16)
  store ptr %value, ptr %node, align 8
  %node.next = getelementptr i8, ptr %node, i64 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr i8, ptr %tail, i64 8
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
skip:
  br label %advance
advance:
  %head.next = phi ptr [%head, %skip], [%added.head, %added]
  %tail.next = phi ptr [%tail, %skip], [%node, %added]
  %count.next = phi i64 [%count, %skip], [%added.count, %added]
  br label %loop
done:
  %set = call ptr @topal.tail.component.platform.allocate(i64 16)
  %set.count = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 0
  %set.entries = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  store i64 %count, ptr %set.count, align 8
  store ptr %head, ptr %set.entries, align 8
  ret ptr %set
}

define internal ptr @topal.tail.component.runtime.container.bag.int.find(ptr %entries, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %ordering = call i32 @topal.tail.component.runtime.int.compare(ptr %candidate, ptr %value)
  %equal = icmp eq i32 %ordering, 0
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerBagNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.tail.component.runtime.container.bag.int.collect(ptr %list) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%list, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %total = phi i64 [0, %entry], [%total.next, %advance]
  %distinct = phi i64 [0, %entry], [%distinct.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %value = load ptr, ptr %current, align 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.tail.component.runtime.container.bag.int.find(ptr %head, ptr %value)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %increment, label %add
increment:
  %existing.count.pointer = getelementptr %topal.ContainerBagNode, ptr %existing, i32 0, i32 1
  %existing.count = load i64, ptr %existing.count.pointer, align 8
  %incremented = add i64 %existing.count, 1
  store i64 %incremented, ptr %existing.count.pointer, align 8
  br label %advance
add:
  %node = call ptr @topal.tail.component.platform.allocate(i64 24)
  %node.value = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 0
  %node.count = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 2
  store ptr %value, ptr %node.value, align 8
  store i64 1, ptr %node.count, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerBagNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.distinct = add i64 %distinct, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %increment], [%added.head, %added]
  %tail.next = phi ptr [%tail, %increment], [%node, %added]
  %distinct.next = phi i64 [%distinct, %increment], [%added.distinct, %added]
  %total.next = add i64 %total, 1
  br label %loop
done:
  %bag = call ptr @topal.tail.component.platform.allocate(i64 24)
  %bag.total = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 0
  %bag.distinct = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 1
  %bag.entries = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  store i64 %total, ptr %bag.total, align 8
  store i64 %distinct, ptr %bag.distinct, align 8
  store ptr %head, ptr %bag.entries, align 8
  ret ptr %bag
}

define internal ptr @topal.tail.component.runtime.container.map.string-int.find(ptr %entries, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%entries, %entry], [%next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %absent, label %compare
compare:
  %candidate = load ptr, ptr %current, align 8
  %equal = call i1 @topal.tail.component.runtime.string.equal(ptr %candidate, ptr %key)
  br i1 %equal, label %present, label %advance
advance:
  %next.pointer = getelementptr %topal.ContainerMapNode, ptr %current, i32 0, i32 2
  %next = load ptr, ptr %next.pointer, align 8
  br label %loop
present:
  ret ptr %current
absent:
  ret ptr null
}

define internal ptr @topal.tail.component.runtime.container.map.string-int.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load ptr, ptr %source.value.pointer, align 8
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.tail.component.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store ptr %value, ptr %existing.value, align 8
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.tail.component.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store ptr %value, ptr %node.value, align 8
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.tail.component.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.tail.component.runtime.container.map.string-function.collect(ptr %pairs, i1 %keep.last) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  br label %loop
loop:
  %current = phi ptr [%pairs, %entry], [%source.next, %advance]
  %head = phi ptr [null, %entry], [%head.next, %advance]
  %tail = phi ptr [null, %entry], [%tail.next, %advance]
  %count = phi i64 [0, %entry], [%count.next, %advance]
  %empty = icmp eq ptr %current, null
  br i1 %empty, label %done, label %visit
visit:
  %key = load ptr, ptr %current, align 8
  %source.value.pointer = getelementptr i8, ptr %current, i64 8
  %source.next.pointer = getelementptr i8, ptr %current, i64 16
  %value = load i32, ptr %source.value.pointer, align 4
  %source.next = load ptr, ptr %source.next.pointer, align 8
  %existing = call ptr @topal.tail.component.runtime.container.map.string-int.find(ptr %head, ptr %key)
  %found = icmp ne ptr %existing, null
  br i1 %found, label %collision, label %add
collision:
  br i1 %keep.last, label %replace, label %keep
replace:
  %existing.value = getelementptr %topal.ContainerMapNode, ptr %existing, i32 0, i32 1
  store i32 %value, ptr %existing.value, align 4
  br label %advance
keep:
  br label %advance
add:
  %node = call ptr @topal.tail.component.platform.allocate(i64 24)
  %node.key = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 0
  %node.value = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %node.next = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 2
  store ptr %key, ptr %node.key, align 8
  store i32 %value, ptr %node.value, align 4
  store ptr null, ptr %node.next, align 8
  %first = icmp eq ptr %tail, null
  br i1 %first, label %start, label %link
start:
  br label %added
link:
  %tail.next.pointer = getelementptr %topal.ContainerMapNode, ptr %tail, i32 0, i32 2
  store ptr %node, ptr %tail.next.pointer, align 8
  br label %added
added:
  %added.head = phi ptr [%node, %start], [%head, %link]
  %added.count = add i64 %count, 1
  br label %advance
advance:
  %head.next = phi ptr [%head, %replace], [%head, %keep], [%added.head, %added]
  %tail.next = phi ptr [%tail, %replace], [%tail, %keep], [%node, %added]
  %count.next = phi i64 [%count, %replace], [%count, %keep], [%added.count, %added]
  br label %loop
done:
  %mapping = call ptr @topal.tail.component.platform.allocate(i64 16)
  %mapping.count = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 0
  %mapping.entries = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  store i64 %count, ptr %mapping.count, align 8
  store ptr %head, ptr %mapping.entries, align 8
  ret ptr %mapping
}

define internal ptr @topal.tail.component.runtime.container.entry.count(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %value = call ptr @topal.tail.component.runtime.int.from.u64(i64 %count)
  ret ptr %value
}

define internal i1 @topal.tail.component.runtime.container.empty(ptr %container) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %container, align 8
  %empty = icmp eq i64 %count, 0
  ret i1 %empty
}

define internal ptr @topal.tail.component.runtime.container.array.int.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load ptr, ptr %current, align 8
  %some = call ptr @topal.tail.component.runtime.optional.some(ptr %value)
  ret ptr %some
absent:
  %none = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none
}

define internal ptr @topal.tail.component.runtime.container.array.function.at(ptr %array, i64 %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %count = load i64, ptr %array, align 8
  %in.bounds = icmp ult i64 %index, %count
  br i1 %in.bounds, label %find, label %absent
find:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %array, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  br label %loop
loop:
  %current = phi ptr [%entries, %find], [%next, %advance]
  %position = phi i64 [0, %find], [%position.next, %advance]
  %found = icmp eq i64 %position, %index
  br i1 %found, label %present, label %advance
advance:
  %next.pointer = getelementptr i8, ptr %current, i64 8
  %next = load ptr, ptr %next.pointer, align 8
  %position.next = add i64 %position, 1
  br label %loop
present:
  %value = load i32, ptr %current, align 4
  %payload = call ptr @topal.tail.component.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some = call ptr @topal.tail.component.runtime.optional.some(ptr %payload)
  ret ptr %some
absent:
  %none = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.tail.component.runtime.container.set.int.contains(ptr %set, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %set, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %present = call i1 @topal.tail.component.runtime.container.int.list.contains(ptr %entries, ptr %value)
  ret i1 %present
}

define internal ptr @topal.tail.component.runtime.container.bag.int.multiplicity(ptr %bag, ptr %value) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerBagHeader, ptr %bag, i32 0, i32 2
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.tail.component.runtime.container.bag.int.find(ptr %entries, ptr %value)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %zero, label %present
zero:
  %zero.value = call ptr @topal.tail.component.runtime.int.from.u64(i64 0)
  ret ptr %zero.value
present:
  %count.pointer = getelementptr %topal.ContainerBagNode, ptr %node, i32 0, i32 1
  %count = load i64, ptr %count.pointer, align 8
  %count.value = call ptr @topal.tail.component.runtime.int.from.u64(i64 %count)
  ret ptr %count.value
}

define internal ptr @topal.tail.component.runtime.container.map.string-int.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.tail.component.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load ptr, ptr %value.pointer, align 8
  %some.value = call ptr @topal.tail.component.runtime.optional.some(ptr %value)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none.value
}

define internal ptr @topal.tail.component.runtime.container.map.string-function.lookup(ptr %mapping, ptr %key) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %entries.pointer = getelementptr %topal.ContainerSequenceHeader, ptr %mapping, i32 0, i32 1
  %entries = load ptr, ptr %entries.pointer, align 8
  %node = call ptr @topal.tail.component.runtime.container.map.string-int.find(ptr %entries, ptr %key)
  %absent = icmp eq ptr %node, null
  br i1 %absent, label %none, label %some
some:
  %value.pointer = getelementptr %topal.ContainerMapNode, ptr %node, i32 0, i32 1
  %value = load i32, ptr %value.pointer, align 4
  %payload = call ptr @topal.tail.component.platform.allocate(i64 4)
  store i32 %value, ptr %payload, align 4
  %some.value = call ptr @topal.tail.component.runtime.optional.some(ptr %payload)
  ret ptr %some.value
none:
  %none.value = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none.value
}

declare ptr @topal_tail_allocate_v1(i64)
declare void @topal_tail_abort_v1() noreturn
declare void @topal_tail_step_begin_v1(ptr)
declare ptr @topal_tail_input_number_v1(ptr, i64)
declare i64 @topal_tail_input_boolean_v1(ptr, i64)
declare ptr @topal_tail_input_view_v1(ptr)
declare ptr @topal_tail_helper_enter_v1(ptr, i64, ptr)
declare void @topal_tail_helper_leave_v1(ptr, i64)
declare void @topal_tail_validate_view_v1(ptr, ptr)
declare void @topal_tail_stage_number_v1(ptr, i64, ptr)
declare void @topal_tail_stage_boolean_v1(ptr, i64, i64)
declare void @topal_tail_result_number_v1(ptr, ptr)
declare void @topal_tail_result_boolean_v1(ptr, i64)
declare void @topal_tail_result_unit_v1(ptr)
define internal ptr @topal.tail.component.platform.allocate(i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %pointer = call ptr @topal_tail_allocate_v1(i64 %length)
  ret ptr %pointer
}
define internal void @topal.tail.component.platform.exit(i64 %status) noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_tail_abort_v1()
  unreachable
}
define internal i64 @topal.tail.component.platform.write(i64 %fd, ptr %buffer, i64 %length) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_tail_abort_v1()
  unreachable
}
; Private source-object ABI. The caller supplies live, mapped, disjoint owner,
; control and temporary storage. These words are not source authority.
; Control: code, owner, generation, active, base, count, writable, issued views.
; View: control, offset, count, writable, generation, owner, code, zero.
%topal.KernelRegionControl = type { ptr, i64, i64, i64, ptr, i64, i64, i64 }
%topal.KernelRegionView = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }

define internal void @topal.tail.component.primitive.abort() noreturn nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  call void @topal_tail_abort_v1()
  unreachable
}

; Returns a contained byte pointer only after complete view/control validation.
; The generated closed source graph proves view pointer provenance/nonescape.
define internal ptr @topal.tail.component.primitive.guard(ptr %view) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %address = ptrtoint ptr %view to i64
  %nonnull = icmp ne i64 %address, 0
  %alignment = and i64 %address, 7
  %aligned = icmp eq i64 %alignment, 0
  %valid.pointer = and i1 %nonnull, %aligned
  br i1 %valid.pointer, label %view.fields, label %invalid
view.fields:
  %control = load ptr, ptr %view, align 8
  %control.address = ptrtoint ptr %control to i64
  %control.nonnull = icmp ne i64 %control.address, 0
  %control.alignment = and i64 %control.address, 7
  %control.aligned = icmp eq i64 %control.alignment, 0
  %control.valid = and i1 %control.nonnull, %control.aligned
  br i1 %control.valid, label %control.fields, label %invalid
control.fields:
  %code = load ptr, ptr %control, align 8
  %owner.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 1
  %epoch.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 2
  %active.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 3
  %base.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 4
  %count.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 5
  %rights.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 6
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %owner = load i64, ptr %owner.pointer, align 8
  %epoch = load i64, ptr %epoch.pointer, align 8
  %active = load i64, ptr %active.pointer, align 8
  %base = load ptr, ptr %base.pointer, align 8
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %issued = load i64, ptr %issued.pointer, align 8
  %offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %view.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %view.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %view.epoch.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 4
  %view.owner.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 5
  %view.code.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 6
  %view.zero.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 7
  %offset = load i64, ptr %offset.pointer, align 8
  %view.count = load i64, ptr %view.count.pointer, align 8
  %view.rights = load i64, ptr %view.rights.pointer, align 8
  %view.epoch = load i64, ptr %view.epoch.pointer, align 8
  %view.owner = load i64, ptr %view.owner.pointer, align 8
  %view.code = load ptr, ptr %view.code.pointer, align 8
  %view.zero = load i64, ptr %view.zero.pointer, align 8
  %code.valid = icmp eq ptr %code, @topal_tail_step_component_v1
  %view.code.valid = icmp eq ptr %view.code, %code
  %owner.valid = icmp ne i64 %owner, 0
  %view.owner.valid = icmp eq i64 %view.owner, %owner
  %epoch.valid = icmp ne i64 %epoch, 0
  %view.epoch.valid = icmp eq i64 %view.epoch, %epoch
  %active.valid = icmp eq i64 %active, 1
  %count.valid = icmp ule i64 %count, 18446744073709551615
  %rights.valid = icmp ule i64 %rights, 1
  %view.rights.valid = icmp ule i64 %view.rights, %rights
  %zero.valid = icmp eq i64 %view.zero, 0
  %offset.valid = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %view.count.valid = icmp ule i64 %view.count, %remaining
  %base.address = ptrtoint ptr %base to i64
  %base.nonnull = icmp ne i64 %base.address, 0
  %end = add i64 %base.address, %count
  %end.valid = icmp uge i64 %end, %base.address
  %issued.positive = icmp uge i64 %issued, 1
  %issued.bounded = icmp ule i64 %issued, 256
  %issued.valid = and i1 %issued.positive, %issued.bounded
  %a = and i1 %code.valid, %view.code.valid
  %b = and i1 %owner.valid, %view.owner.valid
  %c = and i1 %epoch.valid, %view.epoch.valid
  %d = and i1 %active.valid, %count.valid
  %e = and i1 %rights.valid, %view.rights.valid
  %f = and i1 %zero.valid, %offset.valid
  %g = and i1 %view.count.valid, %base.nonnull
  %ab = and i1 %a, %b
  %cd = and i1 %c, %d
  %ef = and i1 %e, %f
  %g.end = and i1 %g, %end.valid
  %abcd = and i1 %ab, %cd
  %efgh = and i1 %ef, %g.end
  %all.fields = and i1 %abcd, %efgh
  %valid = and i1 %all.fields, %issued.valid
  br i1 %valid, label %success, label %invalid
success:
  %bytes = getelementptr i8, ptr %base, i64 %offset
  ret ptr %bytes
invalid:
  call void @topal.tail.component.primitive.abort()
  unreachable
}

; Valid arbitrary-precision Nat outside u64 refuses; it is not truncated.
define internal { i1, i64 } @topal.tail.component.primitive.index(ptr %number) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %sign = load i64, ptr %number, align 8
  %nonnegative = icmp eq i64 %sign, 0
  br i1 %nonnegative, label %number.length, label %invalid
number.length:
  %length.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 1
  %length = load i64, ptr %length.pointer, align 8
  %zero = icmp eq i64 %length, 0
  br i1 %zero, label %zero.result, label %bounded
zero.result:
  ret { i1, i64 } { i1 true, i64 0 }
bounded:
  %fits = icmp ule i64 %length, 2
  br i1 %fits, label %low, label %refuse
low:
  %low.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 0
  %low.word = load i32, ptr %low.pointer, align 4
  %low.value = zext i32 %low.word to i64
  %single = icmp eq i64 %length, 1
  br i1 %single, label %single.result, label %high
single.result:
  %one = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %low.value, 1
  ret { i1, i64 } %one
high:
  %high.pointer = getelementptr %topal.IntStorage, ptr %number, i32 0, i32 2, i64 1
  %high.word = load i32, ptr %high.pointer, align 4
  %high.value = zext i32 %high.word to i64
  %shifted = shl i64 %high.value, 32
  %value = or i64 %shifted, %low.value
  %two = insertvalue { i1, i64 } { i1 true, i64 0 }, i64 %value, 1
  ret { i1, i64 } %two
refuse:
  ret { i1, i64 } { i1 false, i64 0 }
invalid:
  call void @topal.tail.component.primitive.abort()
  unreachable
}

define internal ptr @topal.tail.component.primitive.count(ptr %view) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %number = call ptr @topal.tail.component.runtime.int.from.u64(i64 %count)
  ret ptr %number
}

define internal ptr @topal.tail.component.primitive.load(ptr %view, ptr %index) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %decoded = call { i1, i64 } @topal.tail.component.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %valid = and i1 %fits, %contained
  br i1 %valid, label %read, label %refuse
read:
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = load i8, ptr %pointer, align 1
  %value = zext i8 %byte to i64
  %number = call ptr @topal.tail.component.runtime.int.from.u64(i64 %value)
  %some = call ptr @topal.tail.component.runtime.optional.some(ptr %number)
  ret ptr %some
refuse:
  %none = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.tail.component.primitive.store(ptr %view, ptr %index, ptr %number) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %decoded.index = call { i1, i64 } @topal.tail.component.primitive.index(ptr %index)
  %decoded.value = call { i1, i64 } @topal.tail.component.primitive.index(ptr %number)
  %index.fits = extractvalue { i1, i64 } %decoded.index, 0
  %offset = extractvalue { i1, i64 } %decoded.index, 1
  %value.fits = extractvalue { i1, i64 } %decoded.value, 0
  %value = extractvalue { i1, i64 } %decoded.value, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %count = load i64, ptr %count.pointer, align 8
  %rights = load i64, ptr %rights.pointer, align 8
  %contained = icmp ult i64 %offset, %count
  %writable = icmp eq i64 %rights, 1
  %byte.valid = icmp ule i64 %value, 255
  %both.fit = and i1 %index.fits, %value.fits
  %access = and i1 %contained, %writable
  %range = and i1 %both.fit, %byte.valid
  %valid = and i1 %access, %range
  br i1 %valid, label %write, label %refuse
write:
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %byte = trunc i64 %value to i8
  store i8 %byte, ptr %pointer, align 1
  ret i1 true
refuse:
  ret i1 false
}

define internal ptr @topal.tail.component.primitive.window(ptr %view, ptr %start.number, ptr %count.number, i1 %write) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %decoded.start = call { i1, i64 } @topal.tail.component.primitive.index(ptr %start.number)
  %decoded.count = call { i1, i64 } @topal.tail.component.primitive.index(ptr %count.number)
  %start.fits = extractvalue { i1, i64 } %decoded.start, 0
  %start = extractvalue { i1, i64 } %decoded.start, 1
  %count.fits = extractvalue { i1, i64 } %decoded.count, 0
  %count = extractvalue { i1, i64 } %decoded.count, 1
  %parent.offset.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 1
  %parent.count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %parent.rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %parent.offset = load i64, ptr %parent.offset.pointer, align 8
  %parent.count = load i64, ptr %parent.count.pointer, align 8
  %parent.rights = load i64, ptr %parent.rights.pointer, align 8
  %start.valid = icmp ule i64 %start, %parent.count
  %remaining = sub i64 %parent.count, %start
  %count.valid = icmp ule i64 %count, %remaining
  %rights = zext i1 %write to i64
  %rights.valid = icmp ule i64 %rights, %parent.rights
  %range = and i1 %start.valid, %count.valid
  %facts = and i1 %start.fits, %count.fits
  %allowed = and i1 %range, %rights.valid
  %valid = and i1 %allowed, %facts
  br i1 %valid, label %capacity, label %refuse
capacity:
  %control = load ptr, ptr %view, align 8
  %issued.pointer = getelementptr %topal.KernelRegionControl, ptr %control, i32 0, i32 7
  %issued = load i64, ptr %issued.pointer, align 8
  %available = icmp ult i64 %issued, 256
  br i1 %available, label %derive, label %invalid
derive:
  %new = call ptr @topal.tail.component.platform.allocate(i64 64)
  %fields = load %topal.KernelRegionView, ptr %view, align 8
  store %topal.KernelRegionView %fields, ptr %new, align 8
  %new.offset = add i64 %parent.offset, %start
  %new.offset.pointer = getelementptr %topal.KernelRegionView, ptr %new, i32 0, i32 1
  %new.count.pointer = getelementptr %topal.KernelRegionView, ptr %new, i32 0, i32 2
  %new.rights.pointer = getelementptr %topal.KernelRegionView, ptr %new, i32 0, i32 3
  store i64 %new.offset, ptr %new.offset.pointer, align 8
  store i64 %count, ptr %new.count.pointer, align 8
  store i64 %rights, ptr %new.rights.pointer, align 8
  %next.issued = add i64 %issued, 1
  store i64 %next.issued, ptr %issued.pointer, align 8
  %some = call ptr @topal.tail.component.runtime.optional.some(ptr %new)
  ret ptr %some
refuse:
  %none = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none
invalid:
  call void @topal.tail.component.primitive.abort()
  unreachable
}
; Optional checked field encoding runtime. Core values and the base region
; implementation remain shared. Static source formats admit one to eight bytes.

define internal { i1, ptr } @topal.tail.component.primitive.unsigned.span(ptr %view, ptr %index, i64 %width) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %bytes = call ptr @topal.tail.component.primitive.guard(ptr %view)
  %positive = icmp uge i64 %width, 1
  %bounded = icmp ule i64 %width, 8
  %format.valid = and i1 %positive, %bounded
  br i1 %format.valid, label %decode, label %invalid
decode:
  %decoded = call { i1, i64 } @topal.tail.component.primitive.index(ptr %index)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %offset = extractvalue { i1, i64 } %decoded, 1
  %count.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 2
  %count = load i64, ptr %count.pointer, align 8
  %starts = icmp ule i64 %offset, %count
  %remaining = sub i64 %count, %offset
  %ends = icmp ule i64 %width, %remaining
  %contained = and i1 %starts, %ends
  %valid = and i1 %fits, %contained
  br i1 %valid, label %success, label %refuse
success:
  %pointer = getelementptr i8, ptr %bytes, i64 %offset
  %result = insertvalue { i1, ptr } { i1 true, ptr null }, ptr %pointer, 1
  ret { i1, ptr } %result
refuse:
  ret { i1, ptr } { i1 false, ptr null }
invalid:
  call void @topal.tail.component.primitive.abort()
  unreachable
}

define internal ptr @topal.tail.component.primitive.unsigned.load(ptr %view, ptr %index, i64 %width, i1 %big) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %checked = call { i1, ptr } @topal.tail.component.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %valid, label %loop, label %refuse
loop:
  %index.byte = phi i64 [ 0, %entry ], [ %next, %loop ]
  %value = phi i64 [ 0, %entry ], [ %merged, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  %byte = load i8, ptr %pointer, align 1
  %extended = zext i8 %byte to i64
  %part = shl i64 %extended, %shift
  %merged = or i64 %value, %part
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop
result:
  %number = call ptr @topal.tail.component.runtime.int.from.u64(i64 %merged)
  %some = call ptr @topal.tail.component.runtime.optional.some(ptr %number)
  ret ptr %some
refuse:
  %none = call ptr @topal.tail.component.runtime.optional.none()
  ret ptr %none
}

define internal i1 @topal.tail.component.primitive.unsigned.store(ptr %view, ptr %index, ptr %number, i64 %width, i1 %big) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %checked = call { i1, ptr } @topal.tail.component.primitive.unsigned.span(ptr %view, ptr %index, i64 %width)
  %span.valid = extractvalue { i1, ptr } %checked, 0
  %base = extractvalue { i1, ptr } %checked, 1
  br i1 %span.valid, label %value.check, label %refuse
value.check:
  %decoded = call { i1, i64 } @topal.tail.component.primitive.index(ptr %number)
  %fits = extractvalue { i1, i64 } %decoded, 0
  %value = extractvalue { i1, i64 } %decoded, 1
  %rights.pointer = getelementptr %topal.KernelRegionView, ptr %view, i32 0, i32 3
  %rights = load i64, ptr %rights.pointer, align 8
  %writable = icmp eq i64 %rights, 1
  ; Width is proved in [1,8], so this shift is always in [0,56]. In particular
  ; width eight never attempts a poison-producing shift by 64.
  %bits = mul i64 %width, 8
  %unused = sub i64 64, %bits
  %mask = lshr i64 -1, %unused
  %outside.mask = xor i64 %mask, -1
  %outside = and i64 %value, %outside.mask
  %value.valid = icmp eq i64 %outside, 0
  %range = and i1 %fits, %value.valid
  %valid = and i1 %range, %writable
  br i1 %valid, label %loop, label %refuse
loop:
  %index.byte = phi i64 [ 0, %value.check ], [ %next, %loop ]
  %last = sub i64 %width, 1
  %reverse = sub i64 %last, %index.byte
  %place = select i1 %big, i64 %reverse, i64 %index.byte
  %shift = mul i64 %place, 8
  %part = lshr i64 %value, %shift
  %byte = trunc i64 %part to i8
  %pointer = getelementptr i8, ptr %base, i64 %index.byte
  store i8 %byte, ptr %pointer, align 1
  %next = add i64 %index.byte, 1
  %done = icmp eq i64 %next, %width
  br i1 %done, label %result, label %loop
result:
  ret i1 true
refuse:
  ret i1 false
}
@topal.tail.component.literal.int.0 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 4294967295, i32 4294967295] }, align 8
@topal.tail.component.literal.int.1 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 4294967295, i32 4294967295] }, align 8
@topal.tail.component.literal.int.2 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.3 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.4 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.tail.component.literal.int.5 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.6 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.tail.component.literal.int.7 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.8 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.9 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.10 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.11 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.12 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.13 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.14 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.15 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.16 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.tail.component.literal.int.17 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.18 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.tail.component.literal.int.19 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.20 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.21 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.22 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.23 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.24 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.25 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.26 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.27 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.28 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.tail.component.literal.int.29 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.30 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.31 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.32 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.tail.component.literal.int.33 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.34 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.35 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.36 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.tail.component.literal.int.37 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.38 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.39 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.tail.component.literal.int.40 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.41 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.42 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.43 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.44 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.tail.component.literal.int.45 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.46 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.47 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.48 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.49 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.50 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.51 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.52 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.53 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.54 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.55 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.56 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.57 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.58 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 72] }, align 8
@topal.tail.component.literal.int.59 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.60 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.61 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.62 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.63 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.64 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.65 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.66 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.67 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.68 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.69 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.70 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 56] }, align 8
@topal.tail.component.literal.int.71 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.72 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.73 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.74 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 88] }, align 8
@topal.tail.component.literal.int.75 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.76 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.77 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.tail.component.literal.int.78 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.79 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.80 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.81 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.82 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.83 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.84 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.85 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.86 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.87 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.88 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.89 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 16] }, align 8
@topal.tail.component.literal.int.90 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.91 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.92 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 80] }, align 8
@topal.tail.component.literal.int.93 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.94 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 48] }, align 8
@topal.tail.component.literal.int.95 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.96 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 64] }, align 8
@topal.tail.component.literal.int.97 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.98 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 32] }, align 8
@topal.tail.component.literal.int.99 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.100 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.101 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
@topal.tail.component.literal.int.102 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 2] }, align 8
@topal.tail.component.literal.int.103 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 3] }, align 8
@topal.tail.component.literal.int.104 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 4] }, align 8
@topal.tail.component.literal.int.105 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.106 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 8] }, align 8
@topal.tail.component.literal.int.107 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.108 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 128] }, align 8
@topal.tail.component.literal.int.109 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 24] }, align 8
@topal.tail.component.literal.int.110 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.111 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.112 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 4294967295, i32 4294967295] }, align 8
@topal.tail.component.literal.int.113 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 40] }, align 8
@topal.tail.component.literal.int.114 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.115 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 4294967295, i32 4294967295] }, align 8
@topal.tail.component.literal.int.116 = private unnamed_addr constant { i64, i64, [2 x i32] } { i64 0, i64 2, [2 x i32] [i32 4294967295, i32 4294967295] }, align 8
@topal.tail.component.literal.int.117 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.118 = private unnamed_addr constant { i64, i64, [0 x i32] } { i64 0, i64 0, [0 x i32] [] }, align 8
@topal.tail.component.literal.int.119 = private unnamed_addr constant { i64, i64, [1 x i32] } { i64 0, i64 1, [1 x i32] [i32 1] }, align 8
define internal fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !120 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 1, ptr %arg0), !dbg !121
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !122, !DIExpression(), !123)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !124, !DIExpression(), !125)
    #dbg_value(ptr @topal.tail.component.literal.int.0, !126, !DIExpression(), !127)
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %tail.helper.view), !dbg !128
  %v2 = call ptr @topal.tail.component.primitive.unsigned.load(ptr %tail.helper.view, ptr %arg1, i64 8, i1 false), !dbg !129
  %v3 = call i1 @topal.tail.component.runtime.optional.is.some(ptr %v2), !dbg !130
  br i1 %v3, label %optional.decision.some.0, label %optional.decision.none.1, !dbg !131
optional.decision.some.0:
  %v4 = call ptr @topal.tail.component.runtime.optional.payload(ptr %v2), !dbg !132
    #dbg_value(ptr %v4, !133, !DIExpression(), !134)
  br label %optional.decision.merge.2, !dbg !135
optional.decision.none.1:
  br label %optional.decision.merge.2, !dbg !136
optional.decision.merge.2:
  %v5 = phi ptr [%v4, %optional.decision.some.0], [@topal.tail.component.literal.int.0, %optional.decision.none.1], !dbg !137
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 1), !dbg !138
  ret ptr %v5, !dbg !139
}
define internal fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %arg0, i1 %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !142 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 2, ptr null), !dbg !143
  %v0 = alloca i1, align 1
  store i1 %arg0, ptr %v0, align 1
    #dbg_declare(ptr %v0, !144, !DIExpression(), !145)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !146, !DIExpression(), !147)
  br i1 %arg0, label %decision.true.0, label %decision.false.1, !dbg !148
decision.true.0:
  br label %decision.merge.2, !dbg !149
decision.false.1:
  br label %decision.merge.2, !dbg !150
decision.merge.2:
  %v2 = phi i1 [%arg1, %decision.true.0], [false, %decision.false.1], !dbg !151
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 2), !dbg !152
  ret i1 %v2, !dbg !153
}
define internal fastcc ptr @topal.tail.component.topal.fn.finish.4(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !156 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 3, ptr %arg0), !dbg !157
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !158, !DIExpression(), !159)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !160, !DIExpression(), !161)
    #dbg_value(ptr @topal.tail.component.literal.int.1, !162, !DIExpression(), !163)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.2), !dbg !164
  %v3 = icmp eq i32 %v2, 0, !dbg !165
  %v4 = icmp eq i1 %v3, true, !dbg !166
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.3, ptr %tail.context), !dbg !167
  %v6 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr @topal.tail.component.literal.int.4), !dbg !168
  %v7 = icmp eq i32 %v6, 0, !dbg !169
  %v8 = icmp eq i1 %v7, true, !dbg !170
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v4, i1 %v8, ptr %tail.context), !dbg !171
    #dbg_value(i1 %v9, !172, !DIExpression(), !173)
  br i1 %v9, label %decision.true.0, label %decision.false.1, !dbg !174
decision.true.0:
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.5, ptr %tail.context), !dbg !175
  br label %decision.merge.2, !dbg !176
decision.false.1:
  br label %decision.merge.2, !dbg !177
decision.merge.2:
  %v11 = phi ptr [%v10, %decision.true.0], [@topal.tail.component.literal.int.1, %decision.false.1], !dbg !178
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 3), !dbg !179
  ret ptr %v11, !dbg !180
}
define internal fastcc ptr @topal.tail.component.topal.fn.cell.14(ptr %arg0, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !183 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 4, ptr null), !dbg !184
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !185, !DIExpression(), !186)
  %v1 = call ptr @topal.tail.component.runtime.int.multiply(ptr %arg0, ptr @topal.tail.component.literal.int.7), !dbg !187
  %v2 = call ptr @topal.tail.component.runtime.int.add(ptr @topal.tail.component.literal.int.6, ptr %v1), !dbg !188
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 4), !dbg !189
  ret ptr %v2, !dbg !190
}
define internal fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !193 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 5, ptr %arg0), !dbg !194
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !195, !DIExpression(), !196)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !197, !DIExpression(), !198)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !199, !DIExpression(), !200)
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %tail.helper.view), !dbg !201
  %v3 = call i1 @topal.tail.component.primitive.unsigned.store(ptr %tail.helper.view, ptr %arg1, ptr %arg2, i64 8, i1 false), !dbg !202
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 5), !dbg !203
  ret i1 %v3, !dbg !204
}
define internal fastcc i1 @topal.tail.component.topal.fn.select_2dspan.41(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !207 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 6, ptr %arg0), !dbg !208
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !209, !DIExpression(), !210)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !211, !DIExpression(), !212)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.8, ptr %arg1, ptr %tail.context), !dbg !213
    #dbg_value(i1 %v2, !214, !DIExpression(), !215)
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.9, ptr @topal.tail.component.literal.int.10, ptr %tail.context), !dbg !216
    #dbg_value(i1 %v3, !217, !DIExpression(), !218)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.12), !dbg !219
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.11, ptr %v4, ptr %tail.context), !dbg !220
    #dbg_value(i1 %v5, !221, !DIExpression(), !222)
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.13, ptr @topal.tail.component.literal.int.14, ptr %tail.context), !dbg !223
    #dbg_value(i1 %v6, !224, !DIExpression(), !225)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v3, ptr %tail.context), !dbg !226
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v6, ptr %tail.context), !dbg !227
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v8, ptr %tail.context), !dbg !228
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 6), !dbg !229
  ret i1 %v9, !dbg !230
}
define internal fastcc i1 @topal.tail.component.topal.fn.maybe_2dselect.42(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !233 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 7, ptr %arg0), !dbg !234
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !235, !DIExpression(), !236)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !237, !DIExpression(), !238)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !239, !DIExpression(), !240)
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg2, ptr @topal.tail.component.literal.int.15), !dbg !241
  %v4 = icmp slt i32 %v3, 0, !dbg !242
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !243
decision.true.0:
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.select_2dspan.41(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !244
  br label %decision.merge.2, !dbg !245
decision.false.1:
  br label %decision.merge.2, !dbg !246
decision.merge.2:
  %v6 = phi i1 [%v5, %decision.true.0], [true, %decision.false.1], !dbg !247
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 7), !dbg !248
  ret i1 %v6, !dbg !249
}
define internal fastcc i1 @topal.tail.component.topal.fn.extend_2dspan.43(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3, ptr %arg4, ptr %arg5, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !252 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 8, ptr %arg0), !dbg !253
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !254, !DIExpression(), !255)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !256, !DIExpression(), !257)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !258, !DIExpression(), !259)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !260, !DIExpression(), !261)
  %v4 = alloca ptr, align 8
  store ptr %arg4, ptr %v4, align 8
    #dbg_declare(ptr %v4, !262, !DIExpression(), !263)
  %v5 = alloca ptr, align 8
  store ptr %arg5, ptr %v5, align 8
    #dbg_declare(ptr %v5, !264, !DIExpression(), !265)
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.16, ptr %arg2, ptr %tail.context), !dbg !266
    #dbg_value(i1 %v6, !267, !DIExpression(), !268)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.17, ptr %arg3, ptr %tail.context), !dbg !269
    #dbg_value(i1 %v7, !270, !DIExpression(), !271)
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.18, ptr %arg4, ptr %tail.context), !dbg !272
    #dbg_value(i1 %v8, !273, !DIExpression(), !274)
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.19, ptr %arg5, ptr %tail.context), !dbg !275
    #dbg_value(i1 %v9, !276, !DIExpression(), !277)
  %v10 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.21), !dbg !278
  %v11 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.20, ptr %v10, ptr %tail.context), !dbg !279
    #dbg_value(i1 %v11, !280, !DIExpression(), !281)
  %v12 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v6, i1 %v7, ptr %tail.context), !dbg !282
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v9, i1 %v11, ptr %tail.context), !dbg !283
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v8, i1 %v13, ptr %tail.context), !dbg !284
  %v15 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v12, i1 %v14, ptr %tail.context), !dbg !285
    #dbg_value(i1 %v15, !286, !DIExpression(), !287)
  br i1 %v15, label %decision.true.0, label %decision.false.1, !dbg !288
decision.true.0:
  %v16 = call fastcc i1 @topal.tail.component.topal.fn.maybe_2dselect.42(ptr %tail.helper.view, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !289
  br label %decision.merge.2, !dbg !290
decision.false.1:
  br label %decision.merge.2, !dbg !291
decision.merge.2:
  %v17 = phi i1 [%v16, %decision.true.0], [false, %decision.false.1], !dbg !292
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 8), !dbg !293
  ret i1 %v17, !dbg !294
}
define internal fastcc i1 @topal.tail.component.topal.fn.aligned.45(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !297 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 9, ptr null), !dbg !298
  %v0 = alloca ptr, align 8
  store ptr %arg0, ptr %v0, align 8
    #dbg_declare(ptr %v0, !299, !DIExpression(), !300)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !301, !DIExpression(), !302)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.22), !dbg !303
  %v3 = icmp eq i32 %v2, 0, !dbg !304
  %v4 = icmp eq i1 %v3, true, !dbg !305
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !306
decision.true.0:
  br label %decision.merge.2, !dbg !307
decision.false.1:
  %v5 = call ptr @topal.tail.component.runtime.int.modulo(ptr %arg0, ptr %arg1), !dbg !308
  %v6 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr @topal.tail.component.literal.int.23), !dbg !309
  %v7 = icmp eq i32 %v6, 0, !dbg !310
  %v8 = icmp eq i1 %v7, true, !dbg !311
  br label %decision.merge.2, !dbg !312
decision.merge.2:
  %v9 = phi i1 [false, %decision.true.0], [%v8, %decision.false.1], !dbg !313
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 9), !dbg !314
  ret i1 %v9, !dbg !315
}
define internal fastcc i1 @topal.tail.component.topal.fn.skip.68(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !318 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 10, ptr %arg0), !dbg !319
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !320, !DIExpression(), !321)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !322, !DIExpression(), !323)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.24, ptr @topal.tail.component.literal.int.25, ptr %tail.context), !dbg !324
    #dbg_value(i1 %v2, !325, !DIExpression(), !326)
  %v3 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.27), !dbg !327
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.26, ptr %v3, ptr %tail.context), !dbg !328
    #dbg_value(i1 %v4, !329, !DIExpression(), !330)
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v4, ptr %tail.context), !dbg !331
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 10), !dbg !332
  ret i1 %v5, !dbg !333
}
define internal fastcc i1 @topal.tail.component.topal.fn.start_2dspan.69(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !336 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 11, ptr %arg0), !dbg !337
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !338, !DIExpression(), !339)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !340, !DIExpression(), !341)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !342, !DIExpression(), !343)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !344, !DIExpression(), !345)
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.28, ptr %tail.context), !dbg !346
  %v5 = call ptr @topal.tail.component.runtime.int.add(ptr %v4, ptr @topal.tail.component.literal.int.29), !dbg !347
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.aligned.45(ptr %arg3, ptr %v5, ptr %tail.context), !dbg !348
  br i1 %v6, label %decision.true.0, label %decision.false.1, !dbg !349
decision.true.0:
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.extend_2dspan.43(ptr %tail.helper.view, ptr %arg1, ptr %arg1, ptr @topal.tail.component.literal.int.30, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !350
  br label %decision.merge.2, !dbg !351
decision.false.1:
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.skip.68(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !352
  br label %decision.merge.2, !dbg !353
decision.merge.2:
  %v9 = phi i1 [%v7, %decision.true.0], [%v8, %decision.false.1], !dbg !354
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 11), !dbg !355
  ret i1 %v9, !dbg !356
}
define internal fastcc i1 @topal.tail.component.topal.fn.free_2dcell.70(ptr %arg0, ptr %arg1, ptr %arg2, ptr %arg3, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !359 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 12, ptr %arg0), !dbg !360
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !361, !DIExpression(), !362)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !363, !DIExpression(), !364)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !365, !DIExpression(), !366)
  %v3 = alloca ptr, align 8
  store ptr %arg3, ptr %v3, align 8
    #dbg_declare(ptr %v3, !367, !DIExpression(), !368)
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.31, ptr %tail.context), !dbg !369
    #dbg_value(ptr %v4, !370, !DIExpression(), !371)
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.32, ptr %tail.context), !dbg !372
  %v6 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg2, ptr %v5), !dbg !373
  %v7 = icmp eq i32 %v6, 0, !dbg !374
  %v8 = icmp eq i1 %v7, true, !dbg !375
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.33, ptr %tail.context), !dbg !376
  %v10 = call ptr @topal.tail.component.runtime.int.add(ptr %v9, ptr @topal.tail.component.literal.int.34), !dbg !377
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg3, ptr %v10), !dbg !378
  %v12 = icmp eq i32 %v11, 0, !dbg !379
  %v13 = icmp eq i1 %v12, true, !dbg !380
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v8, i1 %v13, ptr %tail.context), !dbg !381
    #dbg_value(i1 %v14, !382, !DIExpression(), !383)
  %v15 = call i32 @topal.tail.component.runtime.int.compare(ptr %v4, ptr @topal.tail.component.literal.int.35), !dbg !384
  %v16 = icmp sgt i32 %v15, 0, !dbg !385
  %v17 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v16, i1 %v14, ptr %tail.context), !dbg !386
  br i1 %v17, label %decision.true.0, label %decision.false.1, !dbg !387
decision.true.0:
  %v18 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.36, ptr %tail.context), !dbg !388
  %v19 = call ptr @topal.tail.component.runtime.int.add(ptr %v4, ptr @topal.tail.component.literal.int.37), !dbg !389
  %v20 = call fastcc i1 @topal.tail.component.topal.fn.extend_2dspan.43(ptr %tail.helper.view, ptr %arg1, ptr %v18, ptr %v19, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !390
  br label %decision.merge.2, !dbg !391
decision.false.1:
  %v21 = call fastcc i1 @topal.tail.component.topal.fn.start_2dspan.69(ptr %tail.helper.view, ptr %arg1, ptr %arg2, ptr %arg3, ptr %tail.context), !dbg !392
  br label %decision.merge.2, !dbg !393
decision.merge.2:
  %v22 = phi i1 [%v20, %decision.true.0], [%v21, %decision.false.1], !dbg !394
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 12), !dbg !395
  ret i1 %v22, !dbg !396
}
define internal fastcc i1 @topal.tail.component.topal.fn.search_2dcell.75(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !399 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 13, ptr %arg0), !dbg !400
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !401, !DIExpression(), !402)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !403, !DIExpression(), !404)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.14(ptr %arg1, ptr %tail.context), !dbg !405
    #dbg_value(ptr %v2, !406, !DIExpression(), !407)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !408
    #dbg_value(ptr %v3, !409, !DIExpression(), !410)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.38), !dbg !411
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v4, ptr %tail.context), !dbg !412
    #dbg_value(ptr %v5, !413, !DIExpression(), !414)
  %v6 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.39), !dbg !415
  %v7 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v6, ptr %tail.context), !dbg !416
    #dbg_value(ptr %v7, !417, !DIExpression(), !418)
  %v8 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr @topal.tail.component.literal.int.40), !dbg !419
  %v9 = icmp eq i32 %v8, 0, !dbg !420
  %v10 = icmp eq i1 %v9, true, !dbg !421
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr @topal.tail.component.literal.int.41), !dbg !422
  %v12 = icmp sgt i32 %v11, 0, !dbg !423
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v10, i1 %v12, ptr %tail.context), !dbg !424
  br i1 %v13, label %decision.true.0, label %decision.false.1, !dbg !425
decision.true.0:
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.free_2dcell.70(ptr %tail.helper.view, ptr %arg1, ptr %v5, ptr %v7, ptr %tail.context), !dbg !426
  br label %decision.merge.2, !dbg !427
decision.false.1:
  %v15 = call fastcc i1 @topal.tail.component.topal.fn.skip.68(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !428
  br label %decision.merge.2, !dbg !429
decision.merge.2:
  %v16 = phi i1 [%v14, %decision.true.0], [%v15, %decision.false.1], !dbg !430
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 13), !dbg !431
  ret i1 %v16, !dbg !432
}
define internal fastcc i1 @topal.tail.component.topal.fn.complete.79(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !435 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 14, ptr %arg0), !dbg !436
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !437, !DIExpression(), !438)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !439, !DIExpression(), !440)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.42, ptr %arg1, ptr %tail.context), !dbg !441
    #dbg_value(i1 %v2, !442, !DIExpression(), !443)
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.43, ptr @topal.tail.component.literal.int.44, ptr %tail.context), !dbg !444
    #dbg_value(i1 %v3, !445, !DIExpression(), !446)
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v3, ptr %tail.context), !dbg !447
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 14), !dbg !448
  ret i1 %v4, !dbg !449
}
define internal fastcc i1 @topal.tail.component.topal.fn.search.80(ptr %arg0, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !452 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 15, ptr %arg0), !dbg !453
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !454, !DIExpression(), !455)
  %v1 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.45, ptr %tail.context), !dbg !456
    #dbg_value(ptr %v1, !457, !DIExpression(), !458)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.46, ptr %tail.context), !dbg !459
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr %v2), !dbg !460
  %v4 = icmp slt i32 %v3, 0, !dbg !461
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !462
decision.true.0:
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.search_2dcell.75(ptr %tail.helper.view, ptr %v1, ptr %tail.context), !dbg !463
  br label %decision.merge.2, !dbg !464
decision.false.1:
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.complete.79(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.47, ptr %tail.context), !dbg !465
  br label %decision.merge.2, !dbg !466
decision.merge.2:
  %v7 = phi i1 [%v5, %decision.true.0], [%v6, %decision.false.1], !dbg !467
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 15), !dbg !468
  ret i1 %v7, !dbg !469
}
define internal fastcc i1 @topal.tail.component.topal.fn.maybe_2dcomplete.104(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !472 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 16, ptr %arg0), !dbg !473
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !474, !DIExpression(), !475)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !476, !DIExpression(), !477)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.48, ptr %tail.context), !dbg !478
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr %v2), !dbg !479
  %v4 = icmp eq i32 %v3, 0, !dbg !480
  %v5 = icmp eq i1 %v4, true, !dbg !481
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !482
decision.true.0:
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.49, ptr %tail.context), !dbg !483
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.complete.79(ptr %tail.helper.view, ptr %v6, ptr %tail.context), !dbg !484
  br label %decision.merge.2, !dbg !485
decision.false.1:
  br label %decision.merge.2, !dbg !486
decision.merge.2:
  %v8 = phi i1 [%v7, %decision.true.0], [true, %decision.false.1], !dbg !487
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 16), !dbg !488
  ret i1 %v8, !dbg !489
}
define internal fastcc i1 @topal.tail.component.topal.fn.advance_2dcommit.105(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !492 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 17, ptr %arg0), !dbg !493
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !494, !DIExpression(), !495)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !496, !DIExpression(), !497)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !498, !DIExpression(), !499)
  %v3 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.51), !dbg !500
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.50, ptr %v3, ptr %tail.context), !dbg !501
    #dbg_value(i1 %v4, !502, !DIExpression(), !503)
  %v5 = call ptr @topal.tail.component.runtime.int.add(ptr %arg2, ptr @topal.tail.component.literal.int.53), !dbg !504
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.52, ptr %v5, ptr %tail.context), !dbg !505
    #dbg_value(i1 %v6, !506, !DIExpression(), !507)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v4, i1 %v6, ptr %tail.context), !dbg !508
  br i1 %v7, label %decision.true.0, label %decision.false.1, !dbg !509
decision.true.0:
  %v8 = call ptr @topal.tail.component.runtime.int.add(ptr %arg2, ptr @topal.tail.component.literal.int.54), !dbg !510
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.maybe_2dcomplete.104(ptr %tail.helper.view, ptr %v8, ptr %tail.context), !dbg !511
  br label %decision.merge.2, !dbg !512
decision.false.1:
  br label %decision.merge.2, !dbg !513
decision.merge.2:
  %v10 = phi i1 [%v9, %decision.true.0], [false, %decision.false.1], !dbg !514
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 17), !dbg !515
  ret i1 %v10, !dbg !516
}
define internal fastcc i1 @topal.tail.component.topal.fn.commit_2dcell.106(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !519 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 18, ptr %arg0), !dbg !520
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !521, !DIExpression(), !522)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !523, !DIExpression(), !524)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !525, !DIExpression(), !526)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.cell.14(ptr %arg1, ptr %tail.context), !dbg !527
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr %v3, ptr %arg2, ptr %tail.context), !dbg !528
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !529
decision.true.0:
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.55, ptr %tail.context), !dbg !530
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.advance_2dcommit.105(ptr %tail.helper.view, ptr %arg1, ptr %v5, ptr %tail.context), !dbg !531
  br label %decision.merge.2, !dbg !532
decision.false.1:
  br label %decision.merge.2, !dbg !533
decision.merge.2:
  %v7 = phi i1 [%v6, %decision.true.0], [false, %decision.false.1], !dbg !534
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 18), !dbg !535
  ret i1 %v7, !dbg !536
}
define internal fastcc i1 @topal.tail.component.topal.fn.allocate_2dcell.107(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !539 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 19, ptr %arg0), !dbg !540
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !541, !DIExpression(), !542)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !543, !DIExpression(), !544)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.14(ptr %arg1, ptr %tail.context), !dbg !545
    #dbg_value(ptr %v2, !546, !DIExpression(), !547)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !548
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr @topal.tail.component.literal.int.56), !dbg !549
  %v5 = icmp eq i32 %v4, 0, !dbg !550
  %v6 = icmp eq i1 %v5, true, !dbg !551
    #dbg_value(i1 %v6, !552, !DIExpression(), !553)
  %v7 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.57), !dbg !554
  %v8 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v7, ptr %tail.context), !dbg !555
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.58, ptr %tail.context), !dbg !556
  %v10 = call i32 @topal.tail.component.runtime.int.compare(ptr %v8, ptr %v9), !dbg !557
  %v11 = icmp eq i32 %v10, 0, !dbg !558
  %v12 = icmp eq i1 %v11, true, !dbg !559
    #dbg_value(i1 %v12, !560, !DIExpression(), !561)
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v6, i1 %v12, ptr %tail.context), !dbg !562
  br i1 %v13, label %decision.true.0, label %decision.false.1, !dbg !563
decision.true.0:
  %v14 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.59, ptr %tail.context), !dbg !564
  %v15 = call fastcc i1 @topal.tail.component.topal.fn.commit_2dcell.106(ptr %tail.helper.view, ptr %arg1, ptr %v14, ptr %tail.context), !dbg !565
  br label %decision.merge.2, !dbg !566
decision.false.1:
  br label %decision.merge.2, !dbg !567
decision.merge.2:
  %v16 = phi i1 [%v15, %decision.true.0], [false, %decision.false.1], !dbg !568
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 19), !dbg !569
  ret i1 %v16, !dbg !570
}
define internal fastcc i1 @topal.tail.component.topal.fn.release_2dcell.131(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !573 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 20, ptr %arg0), !dbg !574
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !575, !DIExpression(), !576)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !577, !DIExpression(), !578)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.14(ptr %arg1, ptr %tail.context), !dbg !579
    #dbg_value(ptr %v2, !580, !DIExpression(), !581)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !582
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.60, ptr %tail.context), !dbg !583
  %v5 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr %v4), !dbg !584
  %v6 = icmp eq i32 %v5, 0, !dbg !585
  %v7 = icmp eq i1 %v6, true, !dbg !586
    #dbg_value(i1 %v7, !587, !DIExpression(), !588)
  %v8 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.61), !dbg !589
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v8, ptr %tail.context), !dbg !590
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.62, ptr %tail.context), !dbg !591
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v9, ptr %v10), !dbg !592
  %v12 = icmp eq i32 %v11, 0, !dbg !593
  %v13 = icmp eq i1 %v12, true, !dbg !594
  %v14 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.63, ptr %tail.context), !dbg !595
  %v15 = call i32 @topal.tail.component.runtime.int.compare(ptr %v14, ptr @topal.tail.component.literal.int.64), !dbg !596
  %v16 = icmp sgt i32 %v15, 0, !dbg !597
  %v17 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v13, i1 %v16, ptr %tail.context), !dbg !598
    #dbg_value(i1 %v17, !599, !DIExpression(), !600)
  %v18 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v17, ptr %tail.context), !dbg !601
  br i1 %v18, label %decision.true.0, label %decision.false.1, !dbg !602
decision.true.0:
  %v19 = call fastcc i1 @topal.tail.component.topal.fn.commit_2dcell.106(ptr %tail.helper.view, ptr %arg1, ptr @topal.tail.component.literal.int.65, ptr %tail.context), !dbg !603
  br label %decision.merge.2, !dbg !604
decision.false.1:
  br label %decision.merge.2, !dbg !605
decision.merge.2:
  %v20 = phi i1 [%v19, %decision.true.0], [false, %decision.false.1], !dbg !606
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 20), !dbg !607
  ret i1 %v20, !dbg !608
}
define internal fastcc i1 @topal.tail.component.topal.fn.commit_2dselected.132(ptr %arg0, ptr %arg1, i1 %arg2, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !611 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 21, ptr %arg0), !dbg !612
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !613, !DIExpression(), !614)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !615, !DIExpression(), !616)
  %v2 = alloca i1, align 1
  store i1 %arg2, ptr %v2, align 1
    #dbg_declare(ptr %v2, !617, !DIExpression(), !618)
  br i1 %arg2, label %decision.true.0, label %decision.false.1, !dbg !619
decision.true.0:
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.allocate_2dcell.107(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !620
  br label %decision.merge.2, !dbg !621
decision.false.1:
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.release_2dcell.131(ptr %tail.helper.view, ptr %arg1, ptr %tail.context), !dbg !622
  br label %decision.merge.2, !dbg !623
decision.merge.2:
  %v5 = phi i1 [%v3, %decision.true.0], [%v4, %decision.false.1], !dbg !624
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 21), !dbg !625
  ret i1 %v5, !dbg !626
}
define internal fastcc i1 @topal.tail.component.topal.fn.commit.133(ptr %arg0, i1 %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !629 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 22, ptr %arg0), !dbg !630
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !631, !DIExpression(), !632)
  %v1 = alloca i1, align 1
  store i1 %arg1, ptr %v1, align 1
    #dbg_declare(ptr %v1, !633, !DIExpression(), !634)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.66, ptr %tail.context), !dbg !635
    #dbg_value(ptr %v2, !636, !DIExpression(), !637)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.67, ptr %tail.context), !dbg !638
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %v2, ptr %v3), !dbg !639
  %v5 = icmp slt i32 %v4, 0, !dbg !640
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.68, ptr %tail.context), !dbg !641
  %v7 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.69, ptr %tail.context), !dbg !642
  %v8 = call i32 @topal.tail.component.runtime.int.compare(ptr %v6, ptr %v7), !dbg !643
  %v9 = icmp slt i32 %v8, 0, !dbg !644
  %v10 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v9, ptr %tail.context), !dbg !645
    #dbg_value(i1 %v10, !646, !DIExpression(), !647)
  br i1 %v10, label %decision.true.0, label %decision.false.1, !dbg !648
decision.true.0:
  %v11 = call fastcc i1 @topal.tail.component.topal.fn.commit_2dselected.132(ptr %tail.helper.view, ptr %v2, i1 %arg1, ptr %tail.context), !dbg !649
  br label %decision.merge.2, !dbg !650
decision.false.1:
  br label %decision.merge.2, !dbg !651
decision.merge.2:
  %v12 = phi i1 [%v11, %decision.true.0], [false, %decision.false.1], !dbg !652
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 22), !dbg !653
  ret i1 %v12, !dbg !654
}
define internal fastcc i1 @topal.tail.component.topal.fn.begin_2drelease.167(ptr %arg0, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !657 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 23, ptr %arg0), !dbg !658
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !659, !DIExpression(), !660)
  %v1 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.70, ptr %tail.context), !dbg !661
    #dbg_value(ptr %v1, !662, !DIExpression(), !663)
  %v2 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.71, ptr %v1, ptr %tail.context), !dbg !664
    #dbg_value(i1 %v2, !665, !DIExpression(), !666)
  %v3 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.72, ptr @topal.tail.component.literal.int.73, ptr %tail.context), !dbg !667
    #dbg_value(i1 %v3, !668, !DIExpression(), !669)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %v1, ptr @topal.tail.component.literal.int.75), !dbg !670
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.74, ptr %v4, ptr %tail.context), !dbg !671
    #dbg_value(i1 %v5, !672, !DIExpression(), !673)
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.76, ptr @topal.tail.component.literal.int.77, ptr %tail.context), !dbg !674
    #dbg_value(i1 %v6, !675, !DIExpression(), !676)
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v2, i1 %v3, ptr %tail.context), !dbg !677
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v6, ptr %tail.context), !dbg !678
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v8, ptr %tail.context), !dbg !679
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 23), !dbg !680
  ret i1 %v9, !dbg !681
}
define internal fastcc i1 @topal.tail.component.topal.fn.maybe_2dbegin_2drelease.168(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !684 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 24, ptr %arg0), !dbg !685
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !686, !DIExpression(), !687)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !688, !DIExpression(), !689)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.78, ptr %tail.context), !dbg !690
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr %v2), !dbg !691
  %v4 = icmp eq i32 %v3, 0, !dbg !692
  %v5 = icmp eq i1 %v4, true, !dbg !693
  br i1 %v5, label %decision.true.0, label %decision.false.1, !dbg !694
decision.true.0:
  %v6 = call fastcc i1 @topal.tail.component.topal.fn.begin_2drelease.167(ptr %tail.helper.view, ptr %tail.context), !dbg !695
  br label %decision.merge.2, !dbg !696
decision.false.1:
  br label %decision.merge.2, !dbg !697
decision.merge.2:
  %v7 = phi i1 [%v6, %decision.true.0], [true, %decision.false.1], !dbg !698
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 24), !dbg !699
  ret i1 %v7, !dbg !700
}
define internal fastcc i1 @topal.tail.component.topal.fn.validated_2dcell.169(ptr %arg0, ptr %arg1, ptr %arg2, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !703 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 25, ptr %arg0), !dbg !704
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !705, !DIExpression(), !706)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !707, !DIExpression(), !708)
  %v2 = alloca ptr, align 8
  store ptr %arg2, ptr %v2, align 8
    #dbg_declare(ptr %v2, !709, !DIExpression(), !710)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.79, ptr %tail.context), !dbg !711
    #dbg_value(ptr %v3, !712, !DIExpression(), !713)
  %v4 = call ptr @topal.tail.component.runtime.int.add(ptr %arg1, ptr @topal.tail.component.literal.int.81), !dbg !714
  %v5 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.80, ptr %v4, ptr %tail.context), !dbg !715
    #dbg_value(i1 %v5, !716, !DIExpression(), !717)
  %v6 = call ptr @topal.tail.component.runtime.int.add(ptr %v3, ptr @topal.tail.component.literal.int.83), !dbg !718
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.82, ptr %v6, ptr %tail.context), !dbg !719
    #dbg_value(i1 %v7, !720, !DIExpression(), !721)
  %v8 = call fastcc i1 @topal.tail.component.topal.fn.write.25(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.84, ptr %arg2, ptr %tail.context), !dbg !722
    #dbg_value(i1 %v8, !723, !DIExpression(), !724)
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v8, ptr %tail.context), !dbg !725
  %v10 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v5, i1 %v9, ptr %tail.context), !dbg !726
  br i1 %v10, label %decision.true.0, label %decision.false.1, !dbg !727
decision.true.0:
  %v11 = call ptr @topal.tail.component.runtime.int.add(ptr %v3, ptr @topal.tail.component.literal.int.85), !dbg !728
  %v12 = call fastcc i1 @topal.tail.component.topal.fn.maybe_2dbegin_2drelease.168(ptr %tail.helper.view, ptr %v11, ptr %tail.context), !dbg !729
  br label %decision.merge.2, !dbg !730
decision.false.1:
  br label %decision.merge.2, !dbg !731
decision.merge.2:
  %v13 = phi i1 [%v12, %decision.true.0], [false, %decision.false.1], !dbg !732
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 25), !dbg !733
  ret i1 %v13, !dbg !734
}
define internal fastcc i1 @topal.tail.component.topal.fn.validate_2dcell.170(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !737 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 26, ptr %arg0), !dbg !738
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !739, !DIExpression(), !740)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !741, !DIExpression(), !742)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.cell.14(ptr %arg1, ptr %tail.context), !dbg !743
    #dbg_value(ptr %v2, !744, !DIExpression(), !745)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v2, ptr %tail.context), !dbg !746
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.86, ptr %tail.context), !dbg !747
  %v5 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr %v4), !dbg !748
  %v6 = icmp eq i32 %v5, 0, !dbg !749
  %v7 = icmp eq i1 %v6, true, !dbg !750
    #dbg_value(i1 %v7, !751, !DIExpression(), !752)
  %v8 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.87), !dbg !753
  %v9 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v8, ptr %tail.context), !dbg !754
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.88, ptr %tail.context), !dbg !755
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v9, ptr %v10), !dbg !756
  %v12 = icmp eq i32 %v11, 0, !dbg !757
  %v13 = icmp eq i1 %v12, true, !dbg !758
    #dbg_value(i1 %v13, !759, !DIExpression(), !760)
  %v14 = call ptr @topal.tail.component.runtime.int.add(ptr %v2, ptr @topal.tail.component.literal.int.89), !dbg !761
  %v15 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr %v14, ptr %tail.context), !dbg !762
    #dbg_value(ptr %v15, !763, !DIExpression(), !764)
  %v16 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.90, ptr %tail.context), !dbg !765
  %v17 = call i32 @topal.tail.component.runtime.int.compare(ptr %v16, ptr @topal.tail.component.literal.int.91), !dbg !766
  %v18 = icmp eq i32 %v17, 0, !dbg !767
  %v19 = icmp eq i1 %v18, true, !dbg !768
    #dbg_value(i1 %v19, !769, !DIExpression(), !770)
  %v20 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.92, ptr %tail.context), !dbg !771
  %v21 = call ptr @topal.tail.component.runtime.int.add(ptr %v20, ptr @topal.tail.component.literal.int.93), !dbg !772
  %v22 = call i32 @topal.tail.component.runtime.int.compare(ptr %v15, ptr %v21), !dbg !773
  %v23 = icmp eq i32 %v22, 0, !dbg !774
  %v24 = icmp eq i1 %v23, true, !dbg !775
    #dbg_value(i1 %v24, !776, !DIExpression(), !777)
  %v25 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v7, i1 %v13, ptr %tail.context), !dbg !778
  %v26 = xor i1 %v19, true, !dbg !779
  %v27 = xor i1 %v24, true, !dbg !780
  %v28 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v26, i1 %v27, ptr %tail.context), !dbg !781
  %v29 = xor i1 %v28, true, !dbg !782
  %v30 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v25, i1 %v29, ptr %tail.context), !dbg !783
    #dbg_value(i1 %v30, !784, !DIExpression(), !785)
  br i1 %v30, label %decision.true.0, label %decision.false.1, !dbg !786
decision.true.0:
  %v31 = call fastcc i1 @topal.tail.component.topal.fn.validated_2dcell.169(ptr %tail.helper.view, ptr %arg1, ptr %v15, ptr %tail.context), !dbg !787
  br label %decision.merge.2, !dbg !788
decision.false.1:
  br label %decision.merge.2, !dbg !789
decision.merge.2:
  %v32 = phi i1 [%v31, %decision.true.0], [false, %decision.false.1], !dbg !790
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 26), !dbg !791
  ret i1 %v32, !dbg !792
}
define internal fastcc i1 @topal.tail.component.topal.fn.validate_2drelease.171(ptr %arg0, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !795 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 27, ptr %arg0), !dbg !796
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !797, !DIExpression(), !798)
  %v1 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.94, ptr %tail.context), !dbg !799
    #dbg_value(ptr %v1, !800, !DIExpression(), !801)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.95, ptr %tail.context), !dbg !802
  %v3 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr %v2), !dbg !803
  %v4 = icmp slt i32 %v3, 0, !dbg !804
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.96, ptr %tail.context), !dbg !805
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.97, ptr %tail.context), !dbg !806
  %v7 = call i32 @topal.tail.component.runtime.int.compare(ptr %v5, ptr %v6), !dbg !807
  %v8 = icmp slt i32 %v7, 0, !dbg !808
  %v9 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v4, i1 %v8, ptr %tail.context), !dbg !809
    #dbg_value(i1 %v9, !810, !DIExpression(), !811)
  %v10 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.98, ptr %tail.context), !dbg !812
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %v10, ptr @topal.tail.component.literal.int.99), !dbg !813
  %v12 = icmp sgt i32 %v11, 0, !dbg !814
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v9, i1 %v12, ptr %tail.context), !dbg !815
    #dbg_value(i1 %v13, !816, !DIExpression(), !817)
  br i1 %v13, label %decision.true.0, label %decision.false.1, !dbg !818
decision.true.0:
  %v14 = call fastcc i1 @topal.tail.component.topal.fn.validate_2dcell.170(ptr %tail.helper.view, ptr %v1, ptr %tail.context), !dbg !819
  br label %decision.merge.2, !dbg !820
decision.false.1:
  br label %decision.merge.2, !dbg !821
decision.merge.2:
  %v15 = phi i1 [%v14, %decision.true.0], [false, %decision.false.1], !dbg !822
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 27), !dbg !823
  ret i1 %v15, !dbg !824
}
define internal fastcc i1 @topal.tail.component.topal.fn.phase_2dstep.225(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !827 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 28, ptr %arg0), !dbg !828
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !829, !DIExpression(), !830)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !831, !DIExpression(), !832)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.100), !dbg !833
  %v3 = icmp sle i32 %v2, 0, !dbg !834
  br i1 %v3, label %comparison.decision.action.1, label %comparison.decision.next.2, !dbg !835
comparison.decision.action.1:
  %v4 = call fastcc i1 @topal.tail.component.topal.fn.search.80(ptr %tail.helper.view, ptr %tail.context), !dbg !836
  br label %comparison.decision.merge.0, !dbg !835
comparison.decision.next.2:
  %v5 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.101), !dbg !837
  %v6 = icmp sle i32 %v5, 0, !dbg !838
  br i1 %v6, label %comparison.decision.action.3, label %comparison.decision.next.4, !dbg !839
comparison.decision.action.3:
  %v7 = call fastcc i1 @topal.tail.component.topal.fn.commit.133(ptr %tail.helper.view, i1 true, ptr %tail.context), !dbg !840
  br label %comparison.decision.merge.0, !dbg !839
comparison.decision.next.4:
  %v8 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.102), !dbg !841
  %v9 = icmp sle i32 %v8, 0, !dbg !842
  br i1 %v9, label %comparison.decision.action.5, label %comparison.decision.next.6, !dbg !843
comparison.decision.action.5:
  %v10 = call fastcc i1 @topal.tail.component.topal.fn.validate_2drelease.171(ptr %tail.helper.view, ptr %tail.context), !dbg !844
  br label %comparison.decision.merge.0, !dbg !843
comparison.decision.next.6:
  %v11 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.103), !dbg !845
  %v12 = icmp sle i32 %v11, 0, !dbg !846
  br i1 %v12, label %comparison.decision.action.7, label %comparison.decision.next.8, !dbg !847
comparison.decision.action.7:
  %v13 = call fastcc i1 @topal.tail.component.topal.fn.commit.133(ptr %tail.helper.view, i1 false, ptr %tail.context), !dbg !848
  br label %comparison.decision.merge.0, !dbg !847
comparison.decision.next.8:
  %v14 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.104), !dbg !849
  %v15 = icmp sle i32 %v14, 0, !dbg !850
  br i1 %v15, label %comparison.decision.action.9, label %comparison.decision.next.10, !dbg !851
comparison.decision.action.9:
  br label %comparison.decision.merge.0, !dbg !851
comparison.decision.next.10:
  br label %comparison.decision.merge.0, !dbg !852
comparison.decision.merge.0:
  %v16 = phi i1 [%v4, %comparison.decision.action.1], [%v7, %comparison.decision.action.3], [%v10, %comparison.decision.action.5], [%v13, %comparison.decision.action.7], [true, %comparison.decision.action.9], [false, %comparison.decision.next.10], !dbg !853
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 28), !dbg !854
  ret i1 %v16, !dbg !855
}
define internal fastcc i1 @topal.tail.component.topal.fn.step.226(ptr %arg0, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !858 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 29, ptr %arg0), !dbg !859
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !860, !DIExpression(), !861)
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %tail.helper.view), !dbg !862
  %v1 = call ptr @topal.tail.component.primitive.count(ptr %tail.helper.view), !dbg !863
    #dbg_value(ptr %v1, !864, !DIExpression(), !865)
  %v2 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.105, ptr %tail.context), !dbg !866
    #dbg_value(ptr %v2, !867, !DIExpression(), !868)
  %v3 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.106, ptr %tail.context), !dbg !869
    #dbg_value(ptr %v3, !870, !DIExpression(), !871)
  %v4 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.107, ptr %tail.context), !dbg !872
    #dbg_value(ptr %v4, !873, !DIExpression(), !874)
  %v5 = call ptr @topal.tail.component.runtime.int.multiply(ptr %v2, ptr @topal.tail.component.literal.int.109), !dbg !875
  %v6 = call ptr @topal.tail.component.runtime.int.add(ptr @topal.tail.component.literal.int.108, ptr %v5), !dbg !876
  %v7 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr %v6), !dbg !877
  %v8 = icmp sge i32 %v7, 0, !dbg !878
  %v9 = call i32 @topal.tail.component.runtime.int.compare(ptr %v3, ptr @topal.tail.component.literal.int.110), !dbg !879
  %v10 = icmp sgt i32 %v9, 0, !dbg !880
  %v11 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v8, i1 %v10, ptr %tail.context), !dbg !881
    #dbg_value(i1 %v11, !882, !DIExpression(), !883)
  %v12 = call i32 @topal.tail.component.runtime.int.compare(ptr %v4, ptr @topal.tail.component.literal.int.111), !dbg !884
  %v13 = icmp sgt i32 %v12, 0, !dbg !885
  %v14 = call i32 @topal.tail.component.runtime.int.compare(ptr %v4, ptr @topal.tail.component.literal.int.112), !dbg !886
  %v15 = icmp slt i32 %v14, 0, !dbg !887
  %v16 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v13, i1 %v15, ptr %tail.context), !dbg !888
    #dbg_value(i1 %v16, !889, !DIExpression(), !890)
  %v17 = call fastcc i1 @topal.tail.component.topal.fn.both.2(i1 %v11, i1 %v16, ptr %tail.context), !dbg !891
  br i1 %v17, label %decision.true.0, label %decision.false.1, !dbg !892
decision.true.0:
  %v18 = call fastcc ptr @topal.tail.component.topal.fn.word.1(ptr %tail.helper.view, ptr @topal.tail.component.literal.int.113, ptr %tail.context), !dbg !893
  %v19 = call fastcc i1 @topal.tail.component.topal.fn.phase_2dstep.225(ptr %tail.helper.view, ptr %v18, ptr %tail.context), !dbg !894
  br label %decision.merge.2, !dbg !895
decision.false.1:
  br label %decision.merge.2, !dbg !896
decision.merge.2:
  %v20 = phi i1 [%v19, %decision.true.0], [false, %decision.false.1], !dbg !897
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 29), !dbg !898
  ret i1 %v20, !dbg !899
}
define internal fastcc ptr @topal.tail.component.topal.fn.step_2dstatus.449(ptr %arg0, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !902 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 30, ptr %arg0), !dbg !903
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !904, !DIExpression(), !905)
    #dbg_value(ptr @topal.tail.component.literal.int.114, !906, !DIExpression(), !907)
    #dbg_value(ptr @topal.tail.component.literal.int.115, !908, !DIExpression(), !909)
  %v1 = call fastcc i1 @topal.tail.component.topal.fn.step.226(ptr %tail.helper.view, ptr %tail.context), !dbg !910
  br i1 %v1, label %decision.true.0, label %decision.false.1, !dbg !911
decision.true.0:
  br label %decision.merge.2, !dbg !912
decision.false.1:
  br label %decision.merge.2, !dbg !913
decision.merge.2:
  %v2 = phi ptr [@topal.tail.component.literal.int.114, %decision.true.0], [@topal.tail.component.literal.int.115, %decision.false.1], !dbg !914
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 30), !dbg !915
  ret ptr %v2, !dbg !916
}
define internal fastcc ptr @topal.tail.component.topal.fn.next_2dstatus.450(ptr %arg0, ptr %arg1, ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !919 {
entry:
  %tail.helper.view = call ptr @topal_tail_helper_enter_v1(ptr %tail.context, i64 31, ptr %arg0), !dbg !920
  %v0 = alloca ptr, align 8
  store ptr %tail.helper.view, ptr %v0, align 8
    #dbg_declare(ptr %v0, !921, !DIExpression(), !922)
  %v1 = alloca ptr, align 8
  store ptr %arg1, ptr %v1, align 8
    #dbg_declare(ptr %v1, !923, !DIExpression(), !924)
    #dbg_value(ptr @topal.tail.component.literal.int.116, !925, !DIExpression(), !926)
  %v2 = call i32 @topal.tail.component.runtime.int.compare(ptr %arg1, ptr @topal.tail.component.literal.int.117), !dbg !927
  %v3 = icmp eq i32 %v2, 0, !dbg !928
  %v4 = icmp eq i1 %v3, true, !dbg !929
  br i1 %v4, label %decision.true.0, label %decision.false.1, !dbg !930
decision.true.0:
  %v5 = call fastcc ptr @topal.tail.component.topal.fn.step_2dstatus.449(ptr %tail.helper.view, ptr %tail.context), !dbg !931
  br label %decision.merge.2, !dbg !932
decision.false.1:
  br label %decision.merge.2, !dbg !933
decision.merge.2:
  %v6 = phi ptr [%v5, %decision.true.0], [@topal.tail.component.literal.int.116, %decision.false.1], !dbg !934
  call void @topal_tail_helper_leave_v1(ptr %tail.context, i64 31), !dbg !935
  ret ptr %v6, !dbg !936
}
define i64 @topal_tail_step_component_v1(ptr %tail.context) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" !dbg !939 {
entry:
  call void @topal_tail_step_begin_v1(ptr %tail.context), !dbg !940
  %v0 = call ptr @topal_tail_input_view_v1(ptr %tail.context), !dbg !941
    #dbg_value(ptr %v0, !942, !DIExpression(), !943)
  %v1 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 1), !dbg !944
    #dbg_value(ptr %v1, !945, !DIExpression(), !946)
  %v2 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 2), !dbg !947
    #dbg_value(ptr %v2, !948, !DIExpression(), !949)
  %v3 = call ptr @topal_tail_input_number_v1(ptr %tail.context, i64 3), !dbg !950
    #dbg_value(ptr %v3, !951, !DIExpression(), !952)
  %v4 = call i32 @topal.tail.component.runtime.int.compare(ptr %v1, ptr @topal.tail.component.literal.int.118), !dbg !953
  %v5 = icmp sle i32 %v4, 0, !dbg !954
  br i1 %v5, label %tail.compare.action.0, label %tail.compare.next.1, !dbg !955
tail.compare.action.0:
  %v6 = call fastcc ptr @topal.tail.component.topal.fn.finish.4(ptr %v0, ptr %v3, ptr %tail.context), !dbg !956
  call void @topal_tail_result_number_v1(ptr %tail.context, ptr %v6), !dbg !957
  ret i64 0, !dbg !958
tail.compare.next.1:
  %v7 = call ptr @topal.tail.component.runtime.int.subtract(ptr %v1, ptr @topal.tail.component.literal.int.119), !dbg !959
  %v8 = call fastcc ptr @topal.tail.component.topal.fn.next_2dstatus.450(ptr %v0, ptr %v3, ptr %tail.context), !dbg !960
  call void @topal_tail_validate_view_v1(ptr %tail.context, ptr %v0), !dbg !961
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 1, ptr %v7), !dbg !962
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 2, ptr %v2), !dbg !963
  call void @topal_tail_stage_number_v1(ptr %tail.context, i64 3, ptr %v8), !dbg !964
  ret i64 1, !dbg !965
}
define i64 @topal_tail_readonly_bytes_v1(ptr %root) nounwind noinline noredzone noimplicitfloat "disable-tail-calls"="true" {
entry:
  %match0 = icmp eq ptr %root, @topal.tail.component.literal.int.0
  %size0 = select i1 %match0, i64 24, i64 0
  %match1 = icmp eq ptr %root, @topal.tail.component.literal.int.1
  %size1 = select i1 %match1, i64 24, i64 %size0
  %match2 = icmp eq ptr %root, @topal.tail.component.literal.int.10
  %size2 = select i1 %match2, i64 16, i64 %size1
  %match3 = icmp eq ptr %root, @topal.tail.component.literal.int.100
  %size3 = select i1 %match3, i64 16, i64 %size2
  %match4 = icmp eq ptr %root, @topal.tail.component.literal.int.101
  %size4 = select i1 %match4, i64 20, i64 %size3
  %match5 = icmp eq ptr %root, @topal.tail.component.literal.int.102
  %size5 = select i1 %match5, i64 20, i64 %size4
  %match6 = icmp eq ptr %root, @topal.tail.component.literal.int.103
  %size6 = select i1 %match6, i64 20, i64 %size5
  %match7 = icmp eq ptr %root, @topal.tail.component.literal.int.104
  %size7 = select i1 %match7, i64 20, i64 %size6
  %match8 = icmp eq ptr %root, @topal.tail.component.literal.int.105
  %size8 = select i1 %match8, i64 16, i64 %size7
  %match9 = icmp eq ptr %root, @topal.tail.component.literal.int.106
  %size9 = select i1 %match9, i64 20, i64 %size8
  %match10 = icmp eq ptr %root, @topal.tail.component.literal.int.107
  %size10 = select i1 %match10, i64 20, i64 %size9
  %match11 = icmp eq ptr %root, @topal.tail.component.literal.int.108
  %size11 = select i1 %match11, i64 20, i64 %size10
  %match12 = icmp eq ptr %root, @topal.tail.component.literal.int.109
  %size12 = select i1 %match12, i64 20, i64 %size11
  %match13 = icmp eq ptr %root, @topal.tail.component.literal.int.11
  %size13 = select i1 %match13, i64 20, i64 %size12
  %match14 = icmp eq ptr %root, @topal.tail.component.literal.int.110
  %size14 = select i1 %match14, i64 16, i64 %size13
  %match15 = icmp eq ptr %root, @topal.tail.component.literal.int.111
  %size15 = select i1 %match15, i64 16, i64 %size14
  %match16 = icmp eq ptr %root, @topal.tail.component.literal.int.112
  %size16 = select i1 %match16, i64 24, i64 %size15
  %match17 = icmp eq ptr %root, @topal.tail.component.literal.int.113
  %size17 = select i1 %match17, i64 20, i64 %size16
  %match18 = icmp eq ptr %root, @topal.tail.component.literal.int.114
  %size18 = select i1 %match18, i64 16, i64 %size17
  %match19 = icmp eq ptr %root, @topal.tail.component.literal.int.115
  %size19 = select i1 %match19, i64 24, i64 %size18
  %match20 = icmp eq ptr %root, @topal.tail.component.literal.int.116
  %size20 = select i1 %match20, i64 24, i64 %size19
  %match21 = icmp eq ptr %root, @topal.tail.component.literal.int.117
  %size21 = select i1 %match21, i64 16, i64 %size20
  %match22 = icmp eq ptr %root, @topal.tail.component.literal.int.118
  %size22 = select i1 %match22, i64 16, i64 %size21
  %match23 = icmp eq ptr %root, @topal.tail.component.literal.int.119
  %size23 = select i1 %match23, i64 20, i64 %size22
  %match24 = icmp eq ptr %root, @topal.tail.component.literal.int.12
  %size24 = select i1 %match24, i64 20, i64 %size23
  %match25 = icmp eq ptr %root, @topal.tail.component.literal.int.13
  %size25 = select i1 %match25, i64 20, i64 %size24
  %match26 = icmp eq ptr %root, @topal.tail.component.literal.int.14
  %size26 = select i1 %match26, i64 20, i64 %size25
  %match27 = icmp eq ptr %root, @topal.tail.component.literal.int.15
  %size27 = select i1 %match27, i64 16, i64 %size26
  %match28 = icmp eq ptr %root, @topal.tail.component.literal.int.16
  %size28 = select i1 %match28, i64 20, i64 %size27
  %match29 = icmp eq ptr %root, @topal.tail.component.literal.int.17
  %size29 = select i1 %match29, i64 20, i64 %size28
  %match30 = icmp eq ptr %root, @topal.tail.component.literal.int.18
  %size30 = select i1 %match30, i64 20, i64 %size29
  %match31 = icmp eq ptr %root, @topal.tail.component.literal.int.19
  %size31 = select i1 %match31, i64 20, i64 %size30
  %match32 = icmp eq ptr %root, @topal.tail.component.literal.int.2
  %size32 = select i1 %match32, i64 16, i64 %size31
  %match33 = icmp eq ptr %root, @topal.tail.component.literal.int.20
  %size33 = select i1 %match33, i64 20, i64 %size32
  %match34 = icmp eq ptr %root, @topal.tail.component.literal.int.21
  %size34 = select i1 %match34, i64 20, i64 %size33
  %match35 = icmp eq ptr %root, @topal.tail.component.literal.int.22
  %size35 = select i1 %match35, i64 16, i64 %size34
  %match36 = icmp eq ptr %root, @topal.tail.component.literal.int.23
  %size36 = select i1 %match36, i64 16, i64 %size35
  %match37 = icmp eq ptr %root, @topal.tail.component.literal.int.24
  %size37 = select i1 %match37, i64 20, i64 %size36
  %match38 = icmp eq ptr %root, @topal.tail.component.literal.int.25
  %size38 = select i1 %match38, i64 16, i64 %size37
  %match39 = icmp eq ptr %root, @topal.tail.component.literal.int.26
  %size39 = select i1 %match39, i64 20, i64 %size38
  %match40 = icmp eq ptr %root, @topal.tail.component.literal.int.27
  %size40 = select i1 %match40, i64 20, i64 %size39
  %match41 = icmp eq ptr %root, @topal.tail.component.literal.int.28
  %size41 = select i1 %match41, i64 20, i64 %size40
  %match42 = icmp eq ptr %root, @topal.tail.component.literal.int.29
  %size42 = select i1 %match42, i64 20, i64 %size41
  %match43 = icmp eq ptr %root, @topal.tail.component.literal.int.3
  %size43 = select i1 %match43, i64 20, i64 %size42
  %match44 = icmp eq ptr %root, @topal.tail.component.literal.int.30
  %size44 = select i1 %match44, i64 20, i64 %size43
  %match45 = icmp eq ptr %root, @topal.tail.component.literal.int.31
  %size45 = select i1 %match45, i64 20, i64 %size44
  %match46 = icmp eq ptr %root, @topal.tail.component.literal.int.32
  %size46 = select i1 %match46, i64 20, i64 %size45
  %match47 = icmp eq ptr %root, @topal.tail.component.literal.int.33
  %size47 = select i1 %match47, i64 20, i64 %size46
  %match48 = icmp eq ptr %root, @topal.tail.component.literal.int.34
  %size48 = select i1 %match48, i64 20, i64 %size47
  %match49 = icmp eq ptr %root, @topal.tail.component.literal.int.35
  %size49 = select i1 %match49, i64 16, i64 %size48
  %match50 = icmp eq ptr %root, @topal.tail.component.literal.int.36
  %size50 = select i1 %match50, i64 20, i64 %size49
  %match51 = icmp eq ptr %root, @topal.tail.component.literal.int.37
  %size51 = select i1 %match51, i64 20, i64 %size50
  %match52 = icmp eq ptr %root, @topal.tail.component.literal.int.38
  %size52 = select i1 %match52, i64 20, i64 %size51
  %match53 = icmp eq ptr %root, @topal.tail.component.literal.int.39
  %size53 = select i1 %match53, i64 20, i64 %size52
  %match54 = icmp eq ptr %root, @topal.tail.component.literal.int.4
  %size54 = select i1 %match54, i64 20, i64 %size53
  %match55 = icmp eq ptr %root, @topal.tail.component.literal.int.40
  %size55 = select i1 %match55, i64 16, i64 %size54
  %match56 = icmp eq ptr %root, @topal.tail.component.literal.int.41
  %size56 = select i1 %match56, i64 16, i64 %size55
  %match57 = icmp eq ptr %root, @topal.tail.component.literal.int.42
  %size57 = select i1 %match57, i64 20, i64 %size56
  %match58 = icmp eq ptr %root, @topal.tail.component.literal.int.43
  %size58 = select i1 %match58, i64 20, i64 %size57
  %match59 = icmp eq ptr %root, @topal.tail.component.literal.int.44
  %size59 = select i1 %match59, i64 20, i64 %size58
  %match60 = icmp eq ptr %root, @topal.tail.component.literal.int.45
  %size60 = select i1 %match60, i64 20, i64 %size59
  %match61 = icmp eq ptr %root, @topal.tail.component.literal.int.46
  %size61 = select i1 %match61, i64 16, i64 %size60
  %match62 = icmp eq ptr %root, @topal.tail.component.literal.int.47
  %size62 = select i1 %match62, i64 16, i64 %size61
  %match63 = icmp eq ptr %root, @topal.tail.component.literal.int.48
  %size63 = select i1 %match63, i64 20, i64 %size62
  %match64 = icmp eq ptr %root, @topal.tail.component.literal.int.49
  %size64 = select i1 %match64, i64 20, i64 %size63
  %match65 = icmp eq ptr %root, @topal.tail.component.literal.int.5
  %size65 = select i1 %match65, i64 20, i64 %size64
  %match66 = icmp eq ptr %root, @topal.tail.component.literal.int.50
  %size66 = select i1 %match66, i64 20, i64 %size65
  %match67 = icmp eq ptr %root, @topal.tail.component.literal.int.51
  %size67 = select i1 %match67, i64 20, i64 %size66
  %match68 = icmp eq ptr %root, @topal.tail.component.literal.int.52
  %size68 = select i1 %match68, i64 20, i64 %size67
  %match69 = icmp eq ptr %root, @topal.tail.component.literal.int.53
  %size69 = select i1 %match69, i64 20, i64 %size68
  %match70 = icmp eq ptr %root, @topal.tail.component.literal.int.54
  %size70 = select i1 %match70, i64 20, i64 %size69
  %match71 = icmp eq ptr %root, @topal.tail.component.literal.int.55
  %size71 = select i1 %match71, i64 20, i64 %size70
  %match72 = icmp eq ptr %root, @topal.tail.component.literal.int.56
  %size72 = select i1 %match72, i64 16, i64 %size71
  %match73 = icmp eq ptr %root, @topal.tail.component.literal.int.57
  %size73 = select i1 %match73, i64 20, i64 %size72
  %match74 = icmp eq ptr %root, @topal.tail.component.literal.int.58
  %size74 = select i1 %match74, i64 20, i64 %size73
  %match75 = icmp eq ptr %root, @topal.tail.component.literal.int.59
  %size75 = select i1 %match75, i64 20, i64 %size74
  %match76 = icmp eq ptr %root, @topal.tail.component.literal.int.6
  %size76 = select i1 %match76, i64 20, i64 %size75
  %match77 = icmp eq ptr %root, @topal.tail.component.literal.int.60
  %size77 = select i1 %match77, i64 20, i64 %size76
  %match78 = icmp eq ptr %root, @topal.tail.component.literal.int.61
  %size78 = select i1 %match78, i64 20, i64 %size77
  %match79 = icmp eq ptr %root, @topal.tail.component.literal.int.62
  %size79 = select i1 %match79, i64 20, i64 %size78
  %match80 = icmp eq ptr %root, @topal.tail.component.literal.int.63
  %size80 = select i1 %match80, i64 20, i64 %size79
  %match81 = icmp eq ptr %root, @topal.tail.component.literal.int.64
  %size81 = select i1 %match81, i64 16, i64 %size80
  %match82 = icmp eq ptr %root, @topal.tail.component.literal.int.65
  %size82 = select i1 %match82, i64 16, i64 %size81
  %match83 = icmp eq ptr %root, @topal.tail.component.literal.int.66
  %size83 = select i1 %match83, i64 20, i64 %size82
  %match84 = icmp eq ptr %root, @topal.tail.component.literal.int.67
  %size84 = select i1 %match84, i64 16, i64 %size83
  %match85 = icmp eq ptr %root, @topal.tail.component.literal.int.68
  %size85 = select i1 %match85, i64 20, i64 %size84
  %match86 = icmp eq ptr %root, @topal.tail.component.literal.int.69
  %size86 = select i1 %match86, i64 20, i64 %size85
  %match87 = icmp eq ptr %root, @topal.tail.component.literal.int.7
  %size87 = select i1 %match87, i64 20, i64 %size86
  %match88 = icmp eq ptr %root, @topal.tail.component.literal.int.70
  %size88 = select i1 %match88, i64 20, i64 %size87
  %match89 = icmp eq ptr %root, @topal.tail.component.literal.int.71
  %size89 = select i1 %match89, i64 20, i64 %size88
  %match90 = icmp eq ptr %root, @topal.tail.component.literal.int.72
  %size90 = select i1 %match90, i64 20, i64 %size89
  %match91 = icmp eq ptr %root, @topal.tail.component.literal.int.73
  %size91 = select i1 %match91, i64 16, i64 %size90
  %match92 = icmp eq ptr %root, @topal.tail.component.literal.int.74
  %size92 = select i1 %match92, i64 20, i64 %size91
  %match93 = icmp eq ptr %root, @topal.tail.component.literal.int.75
  %size93 = select i1 %match93, i64 20, i64 %size92
  %match94 = icmp eq ptr %root, @topal.tail.component.literal.int.76
  %size94 = select i1 %match94, i64 20, i64 %size93
  %match95 = icmp eq ptr %root, @topal.tail.component.literal.int.77
  %size95 = select i1 %match95, i64 20, i64 %size94
  %match96 = icmp eq ptr %root, @topal.tail.component.literal.int.78
  %size96 = select i1 %match96, i64 20, i64 %size95
  %match97 = icmp eq ptr %root, @topal.tail.component.literal.int.79
  %size97 = select i1 %match97, i64 20, i64 %size96
  %match98 = icmp eq ptr %root, @topal.tail.component.literal.int.8
  %size98 = select i1 %match98, i64 20, i64 %size97
  %match99 = icmp eq ptr %root, @topal.tail.component.literal.int.80
  %size99 = select i1 %match99, i64 20, i64 %size98
  %match100 = icmp eq ptr %root, @topal.tail.component.literal.int.81
  %size100 = select i1 %match100, i64 20, i64 %size99
  %match101 = icmp eq ptr %root, @topal.tail.component.literal.int.82
  %size101 = select i1 %match101, i64 20, i64 %size100
  %match102 = icmp eq ptr %root, @topal.tail.component.literal.int.83
  %size102 = select i1 %match102, i64 20, i64 %size101
  %match103 = icmp eq ptr %root, @topal.tail.component.literal.int.84
  %size103 = select i1 %match103, i64 20, i64 %size102
  %match104 = icmp eq ptr %root, @topal.tail.component.literal.int.85
  %size104 = select i1 %match104, i64 20, i64 %size103
  %match105 = icmp eq ptr %root, @topal.tail.component.literal.int.86
  %size105 = select i1 %match105, i64 20, i64 %size104
  %match106 = icmp eq ptr %root, @topal.tail.component.literal.int.87
  %size106 = select i1 %match106, i64 20, i64 %size105
  %match107 = icmp eq ptr %root, @topal.tail.component.literal.int.88
  %size107 = select i1 %match107, i64 20, i64 %size106
  %match108 = icmp eq ptr %root, @topal.tail.component.literal.int.89
  %size108 = select i1 %match108, i64 20, i64 %size107
  %match109 = icmp eq ptr %root, @topal.tail.component.literal.int.9
  %size109 = select i1 %match109, i64 20, i64 %size108
  %match110 = icmp eq ptr %root, @topal.tail.component.literal.int.90
  %size110 = select i1 %match110, i64 20, i64 %size109
  %match111 = icmp eq ptr %root, @topal.tail.component.literal.int.91
  %size111 = select i1 %match111, i64 16, i64 %size110
  %match112 = icmp eq ptr %root, @topal.tail.component.literal.int.92
  %size112 = select i1 %match112, i64 20, i64 %size111
  %match113 = icmp eq ptr %root, @topal.tail.component.literal.int.93
  %size113 = select i1 %match113, i64 20, i64 %size112
  %match114 = icmp eq ptr %root, @topal.tail.component.literal.int.94
  %size114 = select i1 %match114, i64 20, i64 %size113
  %match115 = icmp eq ptr %root, @topal.tail.component.literal.int.95
  %size115 = select i1 %match115, i64 16, i64 %size114
  %match116 = icmp eq ptr %root, @topal.tail.component.literal.int.96
  %size116 = select i1 %match116, i64 20, i64 %size115
  %match117 = icmp eq ptr %root, @topal.tail.component.literal.int.97
  %size117 = select i1 %match117, i64 20, i64 %size116
  %match118 = icmp eq ptr %root, @topal.tail.component.literal.int.98
  %size118 = select i1 %match118, i64 20, i64 %size117
  %match119 = icmp eq ptr %root, @topal.tail.component.literal.int.99
  %size119 = select i1 %match119, i64 16, i64 %size118
  %match120 = icmp eq ptr %root, @topal.tail.component.runtime.int.one
  %size120 = select i1 %match120, i64 20, i64 %size119
  %match121 = icmp eq ptr %root, @topal.tail.component.runtime.int.zero
  %size121 = select i1 %match121, i64 16, i64 %size120
  ret i64 %size121
}

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!966, !967}
!llvm.ident = !{!968}
!0 = !DIFile(filename: "frame-metadata.t", directory: "memory")
!1 = !{}
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !0, producer: "topalc 0.1.0", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, enums: !1, retainedTypes: !1)
!3 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!4 = !DIDerivedType(tag: DW_TAG_member, name: "negative", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!5 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!6 = !{!4, !5}
!7 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalIntHeader", file: !0, size: 128, align: 64, elements: !6)
!8 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !7, size: 64, align: 64)
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "Int", file: !0, baseType: !8)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "Nat", file: !0, baseType: !8)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "major", file: !0, baseType: !10, size: 64, align: 64, offset: 0)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "minor", file: !0, baseType: !10, size: 64, align: 64, offset: 64)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "patch", file: !0, baseType: !10, size: 64, align: 64, offset: 128)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "build", file: !0, baseType: !10, size: 64, align: 64, offset: 192)
!15 = !{!11, !12, !13, !14}
!16 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalVersionHeader", file: !0, size: 256, align: 64, elements: !15)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !16, size: 64, align: 64)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "Version", file: !0, baseType: !17)
!19 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64, align: 64)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !20, size: 64, align: 64, offset: 0)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "byte_count", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!23 = !{!21, !22}
!24 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSerializationStreamHeader", file: !0, size: 128, align: 64, elements: !23)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64, align: 64)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "SerializationStream", file: !0, baseType: !25)
!27 = !DIDerivedType(tag: DW_TAG_member, name: "numerator", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "denominator", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!29 = !{!27, !28}
!30 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRationalHeader", file: !0, size: 128, align: 64, elements: !29)
!31 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !30, size: 64, align: 64)
!32 = !DIDerivedType(tag: DW_TAG_typedef, name: "Rational", file: !0, baseType: !31)
!33 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned_char)
!34 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !33, size: 64, align: 64)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "data", file: !0, baseType: !34, size: 64, align: 64, offset: 0)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "length", file: !0, baseType: !3, size: 64, align: 64, offset: 64)
!37 = !DIDerivedType(tag: DW_TAG_member, name: "display", file: !0, baseType: !34, size: 64, align: 64, offset: 128)
!38 = !DIDerivedType(tag: DW_TAG_member, name: "display_length", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!39 = !{!35, !36, !37, !38}
!40 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalStringHeader", file: !0, size: 256, align: 64, elements: !39)
!41 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !40, size: 64, align: 64)
!42 = !DIDerivedType(tag: DW_TAG_typedef, name: "String", file: !0, baseType: !41)
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "Character", file: !0, baseType: !41)
!44 = !DIDerivedType(tag: DW_TAG_typedef, name: "ErrorDomain", file: !0, baseType: !41)
!45 = !DIDerivedType(tag: DW_TAG_member, name: "line", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!46 = !DIDerivedType(tag: DW_TAG_member, name: "column", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!47 = !{!45, !46}
!48 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalSourceLocationHeader", file: !0, size: 128, align: 64, elements: !47)
!49 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !48, size: 64, align: 64)
!50 = !DIDerivedType(tag: DW_TAG_typedef, name: "SourceLocation", file: !0, baseType: !49)
!51 = !DIEnumerator(name: "out-of-range", value: 0)
!52 = !DIEnumerator(name: "not-representable", value: 1)
!53 = !DIEnumerator(name: "division-by-zero", value: 2)
!54 = !DIEnumerator(name: "indeterminate", value: 3)
!55 = !{!51, !52, !53, !54}
!56 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "lang arithmetic ArithmeticErrorCode", file: !0, size: 32, align: 32, elements: !55)
!57 = !DIDerivedType(tag: DW_TAG_member, name: "domain", file: !0, baseType: !44, size: 64, align: 64, offset: 0)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "code", file: !0, baseType: !56, size: 32, align: 32, offset: 64)
!59 = !{!57, !58}
!60 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalErrorHeader", file: !0, size: 448, align: 64, elements: !59)
!61 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !60, size: 64, align: 64)
!62 = !DIDerivedType(tag: DW_TAG_typedef, name: "Error", file: !0, baseType: !61)
!63 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !9, size: 64, align: 64, offset: 0)
!64 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !9, size: 64, align: 64, offset: 64)
!65 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!67 = !{!63, !64, !65, !66}
!68 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeIntHeader", file: !0, size: 256, align: 64, elements: !67)
!69 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !68, size: 64, align: 64)
!70 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Int", file: !0, baseType: !69)
!71 = !DIDerivedType(tag: DW_TAG_member, name: "lower", file: !0, baseType: !32, size: 64, align: 64, offset: 0)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "upper", file: !0, baseType: !32, size: 64, align: 64, offset: 64)
!73 = !DIDerivedType(tag: DW_TAG_member, name: "lower_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 128)
!74 = !DIDerivedType(tag: DW_TAG_member, name: "upper_inclusive", file: !0, baseType: !3, size: 64, align: 64, offset: 192)
!75 = !{!71, !72, !73, !74}
!76 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalRangeRationalHeader", file: !0, size: 256, align: 64, elements: !75)
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !76, size: 64, align: 64)
!78 = !DIDerivedType(tag: DW_TAG_typedef, name: "Range Rational", file: !0, baseType: !77)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "is_error", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!80 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !80, size: 64, align: 64, offset: 64)
!82 = !{!79, !81}
!83 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalResultHeader", file: !0, size: 128, align: 64, elements: !82)
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !83, size: 64, align: 64)
!85 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Int, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!86 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Nat, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!87 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (Rational, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!88 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result (String, lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!89 = !DIDerivedType(tag: DW_TAG_typedef, name: "Result ((Int, Int), lang arithmetic ArithmeticErrorCode)", file: !0, baseType: !84)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "tag", file: !0, baseType: !3, size: 64, align: 64, offset: 0)
!91 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !3, size: 64, align: 64)
!92 = !DIDerivedType(tag: DW_TAG_member, name: "payload", file: !0, baseType: !91, size: 64, align: 64, offset: 64)
!93 = !{!90, !92}
!94 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalOptionalHeader", file: !0, size: 128, align: 64, elements: !93)
!95 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !94, size: 64, align: 64)
!96 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Int", file: !0, baseType: !95)
!97 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Rational", file: !0, baseType: !95)
!98 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Character", file: !0, baseType: !95)
!99 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional String", file: !0, baseType: !95)
!100 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional Error", file: !0, baseType: !95)
!101 = !DIDerivedType(tag: DW_TAG_typedef, name: "Optional SourceLocation", file: !0, baseType: !95)
!102 = !DIEnumerator(name: "Less", value: -1)
!103 = !DIEnumerator(name: "Equal", value: 0)
!104 = !DIEnumerator(name: "Greater", value: 1)
!105 = !{!102, !103, !104}
!106 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Comparison", file: !0, size: 32, align: 32, elements: !105)
!107 = !DIBasicType(name: "Boolean", size: 8, encoding: DW_ATE_boolean)
!108 = !DIBasicType(name: "Unit", size: 8, encoding: DW_ATE_unsigned)
!109 = !DIEnumerator(name: "Completed", value: 0)
!110 = !{!109}
!111 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Completed", file: !0, size: 8, align: 8, elements: !110)
!112 = !DIEnumerator(name: "empty", value: 0)
!113 = !{!112}
!114 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Effect", file: !0, size: 8, align: 8, elements: !113)
!115 = !DICompositeType(tag: DW_TAG_structure_type, name: "TopalKernelRegionBorrow", flags: DIFlagFwdDecl)
!116 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !115, size: 64, align: 64)
!117 = !DIDerivedType(tag: DW_TAG_typedef, name: "KernelByteRegion", file: !0, baseType: !116)
!118 = !{!10, !117, !10}
!119 = !DISubroutineType(types: !118)
!120 = distinct !DISubprogram(name: "word", linkageName: "topal.tail.component.topal.fn.word.1", scope: !0, file: !0, line: 5, type: !119, scopeLine: 5, spFlags: DISPFlagDefinition, unit: !2)
!121 = !DILocation(line: 5, column: 1, scope: !120)
!122 = !DILocalVariable(name: "region", arg: 1, scope: !120, file: !0, line: 5, type: !117)
!123 = !DILocation(line: 5, column: 14, scope: !120)
!124 = !DILocalVariable(name: "offset", arg: 2, scope: !120, file: !0, line: 5, type: !10)
!125 = !DILocation(line: 5, column: 41, scope: !120)
!126 = !DILocalVariable(name: "invalid", scope: !120, file: !0, line: 6, type: !10)
!127 = !DILocation(line: 6, column: 3, scope: !120)
!128 = !DILocation(line: 7, column: 3, scope: !120)
!129 = !DILocation(line: 7, column: 3, scope: !120)
!130 = !DILocation(line: 7, column: 3, scope: !120)
!131 = !DILocation(line: 7, column: 3, scope: !120)
!132 = !DILocation(line: 8, column: 10, scope: !120)
!133 = !DILocalVariable(name: "value", scope: !120, file: !0, line: 8, type: !10)
!134 = !DILocation(line: 8, column: 10, scope: !120)
!135 = !DILocation(line: 8, column: 21, scope: !120)
!136 = !DILocation(line: 9, column: 15, scope: !120)
!137 = !DILocation(line: 7, column: 3, scope: !120)
!138 = !DILocation(line: 7, column: 3, scope: !120)
!139 = !DILocation(line: 7, column: 3, scope: !120)
!140 = !{!107, !107, !107}
!141 = !DISubroutineType(types: !140)
!142 = distinct !DISubprogram(name: "both", linkageName: "topal.tail.component.topal.fn.both.2", scope: !0, file: !0, line: 14, type: !141, scopeLine: 14, spFlags: DISPFlagDefinition, unit: !2)
!143 = !DILocation(line: 14, column: 1, scope: !142)
!144 = !DILocalVariable(name: "first", arg: 1, scope: !142, file: !0, line: 14, type: !107)
!145 = !DILocation(line: 14, column: 14, scope: !142)
!146 = !DILocalVariable(name: "second", arg: 2, scope: !142, file: !0, line: 14, type: !107)
!147 = !DILocation(line: 14, column: 31, scope: !142)
!148 = !DILocation(line: 15, column: 3, scope: !142)
!149 = !DILocation(line: 16, column: 15, scope: !142)
!150 = !DILocation(line: 17, column: 16, scope: !142)
!151 = !DILocation(line: 15, column: 3, scope: !142)
!152 = !DILocation(line: 15, column: 3, scope: !142)
!153 = !DILocation(line: 15, column: 3, scope: !142)
!154 = !{!10, !117, !10}
!155 = !DISubroutineType(types: !154)
!156 = distinct !DISubprogram(name: "finish", linkageName: "topal.tail.component.topal.fn.finish.4", scope: !0, file: !0, line: 207, type: !155, scopeLine: 207, spFlags: DISPFlagDefinition, unit: !2)
!157 = !DILocation(line: 207, column: 1, scope: !156)
!158 = !DILocalVariable(name: "region", arg: 1, scope: !156, file: !0, line: 207, type: !117)
!159 = !DILocation(line: 207, column: 16, scope: !156)
!160 = !DILocalVariable(name: "status", arg: 2, scope: !156, file: !0, line: 207, type: !10)
!161 = !DILocation(line: 207, column: 43, scope: !156)
!162 = !DILocalVariable(name: "invalid", scope: !156, file: !0, line: 208, type: !10)
!163 = !DILocation(line: 208, column: 3, scope: !156)
!164 = !DILocation(line: 209, column: 18, scope: !156)
!165 = !DILocation(line: 209, column: 18, scope: !156)
!166 = !DILocation(line: 209, column: 18, scope: !156)
!167 = !DILocation(line: 209, column: 31, scope: !156)
!168 = !DILocation(line: 209, column: 31, scope: !156)
!169 = !DILocation(line: 209, column: 31, scope: !156)
!170 = !DILocation(line: 209, column: 31, scope: !156)
!171 = !DILocation(line: 209, column: 12, scope: !156)
!172 = !DILocalVariable(name: "ready", scope: !156, file: !0, line: 209, type: !107)
!173 = !DILocation(line: 209, column: 3, scope: !156)
!174 = !DILocation(line: 210, column: 3, scope: !156)
!175 = !DILocation(line: 211, column: 15, scope: !156)
!176 = !DILocation(line: 211, column: 15, scope: !156)
!177 = !DILocation(line: 212, column: 16, scope: !156)
!178 = !DILocation(line: 210, column: 3, scope: !156)
!179 = !DILocation(line: 210, column: 3, scope: !156)
!180 = !DILocation(line: 210, column: 3, scope: !156)
!181 = !{!10, !10}
!182 = !DISubroutineType(types: !181)
!183 = distinct !DISubprogram(name: "cell", linkageName: "topal.tail.component.topal.fn.cell.14", scope: !0, file: !0, line: 19, type: !182, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !2)
!184 = !DILocation(line: 19, column: 1, scope: !183)
!185 = !DILocalVariable(name: "index", arg: 1, scope: !183, file: !0, line: 19, type: !10)
!186 = !DILocation(line: 19, column: 13, scope: !183)
!187 = !DILocation(line: 20, column: 10, scope: !183)
!188 = !DILocation(line: 20, column: 3, scope: !183)
!189 = !DILocation(line: 20, column: 3, scope: !183)
!190 = !DILocation(line: 20, column: 3, scope: !183)
!191 = !{!107, !117, !10, !10}
!192 = !DISubroutineType(types: !191)
!193 = distinct !DISubprogram(name: "write", linkageName: "topal.tail.component.topal.fn.write.25", scope: !0, file: !0, line: 11, type: !192, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2)
!194 = !DILocation(line: 11, column: 1, scope: !193)
!195 = !DILocalVariable(name: "region", arg: 1, scope: !193, file: !0, line: 11, type: !117)
!196 = !DILocation(line: 11, column: 15, scope: !193)
!197 = !DILocalVariable(name: "offset", arg: 2, scope: !193, file: !0, line: 11, type: !10)
!198 = !DILocation(line: 11, column: 42, scope: !193)
!199 = !DILocalVariable(name: "value", arg: 3, scope: !193, file: !0, line: 11, type: !10)
!200 = !DILocation(line: 11, column: 56, scope: !193)
!201 = !DILocation(line: 12, column: 3, scope: !193)
!202 = !DILocation(line: 12, column: 3, scope: !193)
!203 = !DILocation(line: 12, column: 3, scope: !193)
!204 = !DILocation(line: 12, column: 3, scope: !193)
!205 = !{!107, !117, !10}
!206 = !DISubroutineType(types: !205)
!207 = distinct !DISubprogram(name: "select-span", linkageName: "topal.tail.component.topal.fn.select_2dspan.41", scope: !0, file: !0, line: 32, type: !206, scopeLine: 32, spFlags: DISPFlagDefinition, unit: !2)
!208 = !DILocation(line: 32, column: 1, scope: !207)
!209 = !DILocalVariable(name: "region", arg: 1, scope: !207, file: !0, line: 32, type: !117)
!210 = !DILocation(line: 32, column: 21, scope: !207)
!211 = !DILocalVariable(name: "start", arg: 2, scope: !207, file: !0, line: 32, type: !10)
!212 = !DILocation(line: 32, column: 48, scope: !207)
!213 = !DILocation(line: 33, column: 13, scope: !207)
!214 = !DILocalVariable(name: "cursor", scope: !207, file: !0, line: 33, type: !107)
!215 = !DILocation(line: 33, column: 3, scope: !207)
!216 = !DILocation(line: 34, column: 13, scope: !207)
!217 = !DILocalVariable(name: "length", scope: !207, file: !0, line: 34, type: !107)
!218 = !DILocation(line: 34, column: 3, scope: !207)
!219 = !DILocation(line: 35, column: 32, scope: !207)
!220 = !DILocation(line: 35, column: 13, scope: !207)
!221 = !DILocalVariable(name: "result", scope: !207, file: !0, line: 35, type: !107)
!222 = !DILocation(line: 35, column: 3, scope: !207)
!223 = !DILocation(line: 36, column: 12, scope: !207)
!224 = !DILocalVariable(name: "phase", scope: !207, file: !0, line: 36, type: !107)
!225 = !DILocation(line: 36, column: 3, scope: !207)
!226 = !DILocation(line: 37, column: 9, scope: !207)
!227 = !DILocation(line: 37, column: 32, scope: !207)
!228 = !DILocation(line: 37, column: 3, scope: !207)
!229 = !DILocation(line: 37, column: 3, scope: !207)
!230 = !DILocation(line: 37, column: 3, scope: !207)
!231 = !{!107, !117, !10, !10}
!232 = !DISubroutineType(types: !231)
!233 = distinct !DISubprogram(name: "maybe-select", linkageName: "topal.tail.component.topal.fn.maybe_2dselect.42", scope: !0, file: !0, line: 39, type: !232, scopeLine: 39, spFlags: DISPFlagDefinition, unit: !2)
!234 = !DILocation(line: 39, column: 1, scope: !233)
!235 = !DILocalVariable(name: "region", arg: 1, scope: !233, file: !0, line: 39, type: !117)
!236 = !DILocation(line: 39, column: 22, scope: !233)
!237 = !DILocalVariable(name: "start", arg: 2, scope: !233, file: !0, line: 39, type: !10)
!238 = !DILocation(line: 39, column: 49, scope: !233)
!239 = !DILocalVariable(name: "length", arg: 3, scope: !233, file: !0, line: 39, type: !10)
!240 = !DILocation(line: 39, column: 62, scope: !233)
!241 = !DILocation(line: 40, column: 3, scope: !233)
!242 = !DILocation(line: 40, column: 3, scope: !233)
!243 = !DILocation(line: 40, column: 3, scope: !233)
!244 = !DILocation(line: 41, column: 15, scope: !233)
!245 = !DILocation(line: 41, column: 15, scope: !233)
!246 = !DILocation(line: 42, column: 16, scope: !233)
!247 = !DILocation(line: 40, column: 3, scope: !233)
!248 = !DILocation(line: 40, column: 3, scope: !233)
!249 = !DILocation(line: 40, column: 3, scope: !233)
!250 = !{!107, !117, !10, !10, !10, !10, !10}
!251 = !DISubroutineType(types: !250)
!252 = distinct !DISubprogram(name: "extend-span", linkageName: "topal.tail.component.topal.fn.extend_2dspan.43", scope: !0, file: !0, line: 44, type: !251, scopeLine: 44, spFlags: DISPFlagDefinition, unit: !2)
!253 = !DILocation(line: 44, column: 1, scope: !252)
!254 = !DILocalVariable(name: "region", arg: 1, scope: !252, file: !0, line: 44, type: !117)
!255 = !DILocation(line: 44, column: 21, scope: !252)
!256 = !DILocalVariable(name: "cursor", arg: 2, scope: !252, file: !0, line: 44, type: !10)
!257 = !DILocation(line: 44, column: 48, scope: !252)
!258 = !DILocalVariable(name: "start", arg: 3, scope: !252, file: !0, line: 44, type: !10)
!259 = !DILocation(line: 44, column: 62, scope: !252)
!260 = !DILocalVariable(name: "length", arg: 4, scope: !252, file: !0, line: 44, type: !10)
!261 = !DILocation(line: 44, column: 75, scope: !252)
!262 = !DILocalVariable(name: "provenance", arg: 5, scope: !252, file: !0, line: 44, type: !10)
!263 = !DILocation(line: 44, column: 89, scope: !252)
!264 = !DILocalVariable(name: "physical", arg: 6, scope: !252, file: !0, line: 44, type: !10)
!265 = !DILocation(line: 44, column: 107, scope: !252)
!266 = !DILocation(line: 45, column: 8, scope: !252)
!267 = !DILocalVariable(name: "a", scope: !252, file: !0, line: 45, type: !107)
!268 = !DILocation(line: 45, column: 3, scope: !252)
!269 = !DILocation(line: 46, column: 8, scope: !252)
!270 = !DILocalVariable(name: "b", scope: !252, file: !0, line: 46, type: !107)
!271 = !DILocation(line: 46, column: 3, scope: !252)
!272 = !DILocation(line: 47, column: 8, scope: !252)
!273 = !DILocalVariable(name: "c", scope: !252, file: !0, line: 47, type: !107)
!274 = !DILocation(line: 47, column: 3, scope: !252)
!275 = !DILocation(line: 48, column: 8, scope: !252)
!276 = !DILocalVariable(name: "d", scope: !252, file: !0, line: 48, type: !107)
!277 = !DILocation(line: 48, column: 3, scope: !252)
!278 = !DILocation(line: 49, column: 27, scope: !252)
!279 = !DILocation(line: 49, column: 8, scope: !252)
!280 = !DILocalVariable(name: "e", scope: !252, file: !0, line: 49, type: !107)
!281 = !DILocation(line: 49, column: 3, scope: !252)
!282 = !DILocation(line: 50, column: 19, scope: !252)
!283 = !DILocation(line: 50, column: 41, scope: !252)
!284 = !DILocation(line: 50, column: 32, scope: !252)
!285 = !DILocation(line: 50, column: 13, scope: !252)
!286 = !DILocalVariable(name: "stored", scope: !252, file: !0, line: 50, type: !107)
!287 = !DILocation(line: 50, column: 3, scope: !252)
!288 = !DILocation(line: 51, column: 3, scope: !252)
!289 = !DILocation(line: 52, column: 15, scope: !252)
!290 = !DILocation(line: 52, column: 15, scope: !252)
!291 = !DILocation(line: 53, column: 16, scope: !252)
!292 = !DILocation(line: 51, column: 3, scope: !252)
!293 = !DILocation(line: 51, column: 3, scope: !252)
!294 = !DILocation(line: 51, column: 3, scope: !252)
!295 = !{!107, !10, !10}
!296 = !DISubroutineType(types: !295)
!297 = distinct !DISubprogram(name: "aligned", linkageName: "topal.tail.component.topal.fn.aligned.45", scope: !0, file: !0, line: 55, type: !296, scopeLine: 55, spFlags: DISPFlagDefinition, unit: !2)
!298 = !DILocation(line: 55, column: 1, scope: !297)
!299 = !DILocalVariable(name: "physical", arg: 1, scope: !297, file: !0, line: 55, type: !10)
!300 = !DILocation(line: 55, column: 17, scope: !297)
!301 = !DILocalVariable(name: "alignment", arg: 2, scope: !297, file: !0, line: 55, type: !10)
!302 = !DILocation(line: 55, column: 33, scope: !297)
!303 = !DILocation(line: 56, column: 3, scope: !297)
!304 = !DILocation(line: 56, column: 3, scope: !297)
!305 = !DILocation(line: 56, column: 3, scope: !297)
!306 = !DILocation(line: 56, column: 3, scope: !297)
!307 = !DILocation(line: 57, column: 15, scope: !297)
!308 = !DILocation(line: 58, column: 17, scope: !297)
!309 = !DILocation(line: 58, column: 17, scope: !297)
!310 = !DILocation(line: 58, column: 17, scope: !297)
!311 = !DILocation(line: 58, column: 17, scope: !297)
!312 = !DILocation(line: 58, column: 17, scope: !297)
!313 = !DILocation(line: 56, column: 3, scope: !297)
!314 = !DILocation(line: 56, column: 3, scope: !297)
!315 = !DILocation(line: 56, column: 3, scope: !297)
!316 = !{!107, !117, !10}
!317 = !DISubroutineType(types: !316)
!318 = distinct !DISubprogram(name: "skip", linkageName: "topal.tail.component.topal.fn.skip.68", scope: !0, file: !0, line: 27, type: !317, scopeLine: 27, spFlags: DISPFlagDefinition, unit: !2)
!319 = !DILocation(line: 27, column: 1, scope: !318)
!320 = !DILocalVariable(name: "region", arg: 1, scope: !318, file: !0, line: 27, type: !117)
!321 = !DILocation(line: 27, column: 14, scope: !318)
!322 = !DILocalVariable(name: "cursor", arg: 2, scope: !318, file: !0, line: 27, type: !10)
!323 = !DILocation(line: 27, column: 41, scope: !318)
!324 = !DILocation(line: 28, column: 10, scope: !318)
!325 = !DILocalVariable(name: "run", scope: !318, file: !0, line: 28, type: !107)
!326 = !DILocation(line: 28, column: 3, scope: !318)
!327 = !DILocation(line: 29, column: 30, scope: !318)
!328 = !DILocation(line: 29, column: 11, scope: !318)
!329 = !DILocalVariable(name: "next", scope: !318, file: !0, line: 29, type: !107)
!330 = !DILocation(line: 29, column: 3, scope: !318)
!331 = !DILocation(line: 30, column: 3, scope: !318)
!332 = !DILocation(line: 30, column: 3, scope: !318)
!333 = !DILocation(line: 30, column: 3, scope: !318)
!334 = !{!107, !117, !10, !10, !10}
!335 = !DISubroutineType(types: !334)
!336 = distinct !DISubprogram(name: "start-span", linkageName: "topal.tail.component.topal.fn.start_2dspan.69", scope: !0, file: !0, line: 60, type: !335, scopeLine: 60, spFlags: DISPFlagDefinition, unit: !2)
!337 = !DILocation(line: 60, column: 1, scope: !336)
!338 = !DILocalVariable(name: "region", arg: 1, scope: !336, file: !0, line: 60, type: !117)
!339 = !DILocation(line: 60, column: 20, scope: !336)
!340 = !DILocalVariable(name: "cursor", arg: 2, scope: !336, file: !0, line: 60, type: !10)
!341 = !DILocation(line: 60, column: 47, scope: !336)
!342 = !DILocalVariable(name: "provenance", arg: 3, scope: !336, file: !0, line: 60, type: !10)
!343 = !DILocation(line: 60, column: 61, scope: !336)
!344 = !DILocalVariable(name: "physical", arg: 4, scope: !336, file: !0, line: 60, type: !10)
!345 = !DILocation(line: 60, column: 79, scope: !336)
!346 = !DILocation(line: 61, column: 23, scope: !336)
!347 = !DILocation(line: 61, column: 23, scope: !336)
!348 = !DILocation(line: 61, column: 3, scope: !336)
!349 = !DILocation(line: 61, column: 3, scope: !336)
!350 = !DILocation(line: 62, column: 15, scope: !336)
!351 = !DILocation(line: 62, column: 15, scope: !336)
!352 = !DILocation(line: 63, column: 16, scope: !336)
!353 = !DILocation(line: 63, column: 16, scope: !336)
!354 = !DILocation(line: 61, column: 3, scope: !336)
!355 = !DILocation(line: 61, column: 3, scope: !336)
!356 = !DILocation(line: 61, column: 3, scope: !336)
!357 = !{!107, !117, !10, !10, !10}
!358 = !DISubroutineType(types: !357)
!359 = distinct !DISubprogram(name: "free-cell", linkageName: "topal.tail.component.topal.fn.free_2dcell.70", scope: !0, file: !0, line: 65, type: !358, scopeLine: 65, spFlags: DISPFlagDefinition, unit: !2)
!360 = !DILocation(line: 65, column: 1, scope: !359)
!361 = !DILocalVariable(name: "region", arg: 1, scope: !359, file: !0, line: 65, type: !117)
!362 = !DILocation(line: 65, column: 19, scope: !359)
!363 = !DILocalVariable(name: "cursor", arg: 2, scope: !359, file: !0, line: 65, type: !10)
!364 = !DILocation(line: 65, column: 46, scope: !359)
!365 = !DILocalVariable(name: "provenance", arg: 3, scope: !359, file: !0, line: 65, type: !10)
!366 = !DILocation(line: 65, column: 60, scope: !359)
!367 = !DILocalVariable(name: "physical", arg: 4, scope: !359, file: !0, line: 65, type: !10)
!368 = !DILocation(line: 65, column: 78, scope: !359)
!369 = !DILocation(line: 66, column: 13, scope: !359)
!370 = !DILocalVariable(name: "length", scope: !359, file: !0, line: 66, type: !10)
!371 = !DILocation(line: 66, column: 3, scope: !359)
!372 = !DILocation(line: 67, column: 31, scope: !359)
!373 = !DILocation(line: 67, column: 17, scope: !359)
!374 = !DILocation(line: 67, column: 17, scope: !359)
!375 = !DILocation(line: 67, column: 17, scope: !359)
!376 = !DILocation(line: 67, column: 64, scope: !359)
!377 = !DILocation(line: 67, column: 64, scope: !359)
!378 = !DILocation(line: 67, column: 51, scope: !359)
!379 = !DILocation(line: 67, column: 51, scope: !359)
!380 = !DILocation(line: 67, column: 51, scope: !359)
!381 = !DILocation(line: 67, column: 11, scope: !359)
!382 = !DILocalVariable(name: "same", scope: !359, file: !0, line: 67, type: !107)
!383 = !DILocation(line: 67, column: 3, scope: !359)
!384 = !DILocation(line: 68, column: 9, scope: !359)
!385 = !DILocation(line: 68, column: 9, scope: !359)
!386 = !DILocation(line: 68, column: 3, scope: !359)
!387 = !DILocation(line: 68, column: 3, scope: !359)
!388 = !DILocation(line: 69, column: 44, scope: !359)
!389 = !DILocation(line: 69, column: 63, scope: !359)
!390 = !DILocation(line: 69, column: 15, scope: !359)
!391 = !DILocation(line: 69, column: 15, scope: !359)
!392 = !DILocation(line: 70, column: 16, scope: !359)
!393 = !DILocation(line: 70, column: 16, scope: !359)
!394 = !DILocation(line: 68, column: 3, scope: !359)
!395 = !DILocation(line: 68, column: 3, scope: !359)
!396 = !DILocation(line: 68, column: 3, scope: !359)
!397 = !{!107, !117, !10}
!398 = !DISubroutineType(types: !397)
!399 = distinct !DISubprogram(name: "search-cell", linkageName: "topal.tail.component.topal.fn.search_2dcell.75", scope: !0, file: !0, line: 72, type: !398, scopeLine: 72, spFlags: DISPFlagDefinition, unit: !2)
!400 = !DILocation(line: 72, column: 1, scope: !399)
!401 = !DILocalVariable(name: "region", arg: 1, scope: !399, file: !0, line: 72, type: !117)
!402 = !DILocation(line: 72, column: 21, scope: !399)
!403 = !DILocalVariable(name: "cursor", arg: 2, scope: !399, file: !0, line: 72, type: !10)
!404 = !DILocation(line: 72, column: 48, scope: !399)
!405 = !DILocation(line: 73, column: 11, scope: !399)
!406 = !DILocalVariable(name: "base", scope: !399, file: !0, line: 73, type: !10)
!407 = !DILocation(line: 73, column: 3, scope: !399)
!408 = !DILocation(line: 74, column: 15, scope: !399)
!409 = !DILocalVariable(name: "identity", scope: !399, file: !0, line: 74, type: !10)
!410 = !DILocation(line: 74, column: 3, scope: !399)
!411 = !DILocation(line: 75, column: 31, scope: !399)
!412 = !DILocation(line: 75, column: 17, scope: !399)
!413 = !DILocalVariable(name: "provenance", scope: !399, file: !0, line: 75, type: !10)
!414 = !DILocation(line: 75, column: 3, scope: !399)
!415 = !DILocation(line: 76, column: 29, scope: !399)
!416 = !DILocation(line: 76, column: 15, scope: !399)
!417 = !DILocalVariable(name: "physical", scope: !399, file: !0, line: 76, type: !10)
!418 = !DILocation(line: 76, column: 3, scope: !399)
!419 = !DILocation(line: 77, column: 9, scope: !399)
!420 = !DILocation(line: 77, column: 9, scope: !399)
!421 = !DILocation(line: 77, column: 9, scope: !399)
!422 = !DILocation(line: 77, column: 23, scope: !399)
!423 = !DILocation(line: 77, column: 23, scope: !399)
!424 = !DILocation(line: 77, column: 3, scope: !399)
!425 = !DILocation(line: 77, column: 3, scope: !399)
!426 = !DILocation(line: 78, column: 15, scope: !399)
!427 = !DILocation(line: 78, column: 15, scope: !399)
!428 = !DILocation(line: 79, column: 16, scope: !399)
!429 = !DILocation(line: 79, column: 16, scope: !399)
!430 = !DILocation(line: 77, column: 3, scope: !399)
!431 = !DILocation(line: 77, column: 3, scope: !399)
!432 = !DILocation(line: 77, column: 3, scope: !399)
!433 = !{!107, !117, !10}
!434 = !DISubroutineType(types: !433)
!435 = distinct !DISubprogram(name: "complete", linkageName: "topal.tail.component.topal.fn.complete.79", scope: !0, file: !0, line: 22, type: !434, scopeLine: 22, spFlags: DISPFlagDefinition, unit: !2)
!436 = !DILocation(line: 22, column: 1, scope: !435)
!437 = !DILocalVariable(name: "region", arg: 1, scope: !435, file: !0, line: 22, type: !117)
!438 = !DILocation(line: 22, column: 18, scope: !435)
!439 = !DILocalVariable(name: "result", arg: 2, scope: !435, file: !0, line: 22, type: !10)
!440 = !DILocation(line: 22, column: 45, scope: !435)
!441 = !DILocation(line: 23, column: 12, scope: !435)
!442 = !DILocalVariable(name: "value", scope: !435, file: !0, line: 23, type: !107)
!443 = !DILocation(line: 23, column: 3, scope: !435)
!444 = !DILocation(line: 24, column: 12, scope: !435)
!445 = !DILocalVariable(name: "phase", scope: !435, file: !0, line: 24, type: !107)
!446 = !DILocation(line: 24, column: 3, scope: !435)
!447 = !DILocation(line: 25, column: 3, scope: !435)
!448 = !DILocation(line: 25, column: 3, scope: !435)
!449 = !DILocation(line: 25, column: 3, scope: !435)
!450 = !{!107, !117}
!451 = !DISubroutineType(types: !450)
!452 = distinct !DISubprogram(name: "search", linkageName: "topal.tail.component.topal.fn.search.80", scope: !0, file: !0, line: 81, type: !451, scopeLine: 81, spFlags: DISPFlagDefinition, unit: !2)
!453 = !DILocation(line: 81, column: 1, scope: !452)
!454 = !DILocalVariable(name: "region", arg: 1, scope: !452, file: !0, line: 81, type: !117)
!455 = !DILocation(line: 81, column: 15, scope: !452)
!456 = !DILocation(line: 82, column: 13, scope: !452)
!457 = !DILocalVariable(name: "cursor", scope: !452, file: !0, line: 82, type: !10)
!458 = !DILocation(line: 82, column: 3, scope: !452)
!459 = !DILocation(line: 83, column: 13, scope: !452)
!460 = !DILocation(line: 83, column: 3, scope: !452)
!461 = !DILocation(line: 83, column: 3, scope: !452)
!462 = !DILocation(line: 83, column: 3, scope: !452)
!463 = !DILocation(line: 84, column: 15, scope: !452)
!464 = !DILocation(line: 84, column: 15, scope: !452)
!465 = !DILocation(line: 85, column: 16, scope: !452)
!466 = !DILocation(line: 85, column: 16, scope: !452)
!467 = !DILocation(line: 83, column: 3, scope: !452)
!468 = !DILocation(line: 83, column: 3, scope: !452)
!469 = !DILocation(line: 83, column: 3, scope: !452)
!470 = !{!107, !117, !10}
!471 = !DISubroutineType(types: !470)
!472 = distinct !DISubprogram(name: "maybe-complete", linkageName: "topal.tail.component.topal.fn.maybe_2dcomplete.104", scope: !0, file: !0, line: 87, type: !471, scopeLine: 87, spFlags: DISPFlagDefinition, unit: !2)
!473 = !DILocation(line: 87, column: 1, scope: !472)
!474 = !DILocalVariable(name: "region", arg: 1, scope: !472, file: !0, line: 87, type: !117)
!475 = !DILocation(line: 87, column: 24, scope: !472)
!476 = !DILocalVariable(name: "processed", arg: 2, scope: !472, file: !0, line: 87, type: !10)
!477 = !DILocation(line: 87, column: 51, scope: !472)
!478 = !DILocation(line: 88, column: 16, scope: !472)
!479 = !DILocation(line: 88, column: 3, scope: !472)
!480 = !DILocation(line: 88, column: 3, scope: !472)
!481 = !DILocation(line: 88, column: 3, scope: !472)
!482 = !DILocation(line: 88, column: 3, scope: !472)
!483 = !DILocation(line: 89, column: 33, scope: !472)
!484 = !DILocation(line: 89, column: 15, scope: !472)
!485 = !DILocation(line: 89, column: 15, scope: !472)
!486 = !DILocation(line: 90, column: 16, scope: !472)
!487 = !DILocation(line: 88, column: 3, scope: !472)
!488 = !DILocation(line: 88, column: 3, scope: !472)
!489 = !DILocation(line: 88, column: 3, scope: !472)
!490 = !{!107, !117, !10, !10}
!491 = !DISubroutineType(types: !490)
!492 = distinct !DISubprogram(name: "advance-commit", linkageName: "topal.tail.component.topal.fn.advance_2dcommit.105", scope: !0, file: !0, line: 92, type: !491, scopeLine: 92, spFlags: DISPFlagDefinition, unit: !2)
!493 = !DILocation(line: 92, column: 1, scope: !492)
!494 = !DILocalVariable(name: "region", arg: 1, scope: !492, file: !0, line: 92, type: !117)
!495 = !DILocation(line: 92, column: 24, scope: !492)
!496 = !DILocalVariable(name: "cursor", arg: 2, scope: !492, file: !0, line: 92, type: !10)
!497 = !DILocation(line: 92, column: 51, scope: !492)
!498 = !DILocalVariable(name: "processed", arg: 3, scope: !492, file: !0, line: 92, type: !10)
!499 = !DILocation(line: 92, column: 65, scope: !492)
!500 = !DILocation(line: 93, column: 30, scope: !492)
!501 = !DILocation(line: 93, column: 11, scope: !492)
!502 = !DILocalVariable(name: "next", scope: !492, file: !0, line: 93, type: !107)
!503 = !DILocation(line: 93, column: 3, scope: !492)
!504 = !DILocation(line: 94, column: 32, scope: !492)
!505 = !DILocation(line: 94, column: 13, scope: !492)
!506 = !DILocalVariable(name: "length", scope: !492, file: !0, line: 94, type: !107)
!507 = !DILocation(line: 94, column: 3, scope: !492)
!508 = !DILocation(line: 95, column: 3, scope: !492)
!509 = !DILocation(line: 95, column: 3, scope: !492)
!510 = !DILocation(line: 96, column: 39, scope: !492)
!511 = !DILocation(line: 96, column: 15, scope: !492)
!512 = !DILocation(line: 96, column: 15, scope: !492)
!513 = !DILocation(line: 97, column: 16, scope: !492)
!514 = !DILocation(line: 95, column: 3, scope: !492)
!515 = !DILocation(line: 95, column: 3, scope: !492)
!516 = !DILocation(line: 95, column: 3, scope: !492)
!517 = !{!107, !117, !10, !10}
!518 = !DISubroutineType(types: !517)
!519 = distinct !DISubprogram(name: "commit-cell", linkageName: "topal.tail.component.topal.fn.commit_2dcell.106", scope: !0, file: !0, line: 99, type: !518, scopeLine: 99, spFlags: DISPFlagDefinition, unit: !2)
!520 = !DILocation(line: 99, column: 1, scope: !519)
!521 = !DILocalVariable(name: "region", arg: 1, scope: !519, file: !0, line: 99, type: !117)
!522 = !DILocation(line: 99, column: 21, scope: !519)
!523 = !DILocalVariable(name: "cursor", arg: 2, scope: !519, file: !0, line: 99, type: !10)
!524 = !DILocation(line: 99, column: 48, scope: !519)
!525 = !DILocalVariable(name: "identity", arg: 3, scope: !519, file: !0, line: 99, type: !10)
!526 = !DILocation(line: 99, column: 62, scope: !519)
!527 = !DILocation(line: 100, column: 18, scope: !519)
!528 = !DILocation(line: 100, column: 3, scope: !519)
!529 = !DILocation(line: 100, column: 3, scope: !519)
!530 = !DILocation(line: 101, column: 47, scope: !519)
!531 = !DILocation(line: 101, column: 15, scope: !519)
!532 = !DILocation(line: 101, column: 15, scope: !519)
!533 = !DILocation(line: 102, column: 16, scope: !519)
!534 = !DILocation(line: 100, column: 3, scope: !519)
!535 = !DILocation(line: 100, column: 3, scope: !519)
!536 = !DILocation(line: 100, column: 3, scope: !519)
!537 = !{!107, !117, !10}
!538 = !DISubroutineType(types: !537)
!539 = distinct !DISubprogram(name: "allocate-cell", linkageName: "topal.tail.component.topal.fn.allocate_2dcell.107", scope: !0, file: !0, line: 104, type: !538, scopeLine: 104, spFlags: DISPFlagDefinition, unit: !2)
!540 = !DILocation(line: 104, column: 1, scope: !539)
!541 = !DILocalVariable(name: "region", arg: 1, scope: !539, file: !0, line: 104, type: !117)
!542 = !DILocation(line: 104, column: 23, scope: !539)
!543 = !DILocalVariable(name: "cursor", arg: 2, scope: !539, file: !0, line: 104, type: !10)
!544 = !DILocation(line: 104, column: 50, scope: !539)
!545 = !DILocation(line: 105, column: 11, scope: !539)
!546 = !DILocalVariable(name: "base", scope: !539, file: !0, line: 105, type: !10)
!547 = !DILocation(line: 105, column: 3, scope: !539)
!548 = !DILocation(line: 106, column: 12, scope: !539)
!549 = !DILocation(line: 106, column: 12, scope: !539)
!550 = !DILocation(line: 106, column: 12, scope: !539)
!551 = !DILocation(line: 106, column: 12, scope: !539)
!552 = !DILocalVariable(name: "free", scope: !539, file: !0, line: 106, type: !107)
!553 = !DILocation(line: 106, column: 3, scope: !539)
!554 = !DILocation(line: 107, column: 26, scope: !539)
!555 = !DILocation(line: 107, column: 12, scope: !539)
!556 = !DILocation(line: 107, column: 40, scope: !539)
!557 = !DILocation(line: 107, column: 12, scope: !539)
!558 = !DILocation(line: 107, column: 12, scope: !539)
!559 = !DILocation(line: 107, column: 12, scope: !539)
!560 = !DILocalVariable(name: "same", scope: !539, file: !0, line: 107, type: !107)
!561 = !DILocation(line: 107, column: 3, scope: !539)
!562 = !DILocation(line: 108, column: 3, scope: !539)
!563 = !DILocation(line: 108, column: 3, scope: !539)
!564 = !DILocation(line: 109, column: 44, scope: !539)
!565 = !DILocation(line: 109, column: 15, scope: !539)
!566 = !DILocation(line: 109, column: 15, scope: !539)
!567 = !DILocation(line: 110, column: 16, scope: !539)
!568 = !DILocation(line: 108, column: 3, scope: !539)
!569 = !DILocation(line: 108, column: 3, scope: !539)
!570 = !DILocation(line: 108, column: 3, scope: !539)
!571 = !{!107, !117, !10}
!572 = !DISubroutineType(types: !571)
!573 = distinct !DISubprogram(name: "release-cell", linkageName: "topal.tail.component.topal.fn.release_2dcell.131", scope: !0, file: !0, line: 112, type: !572, scopeLine: 112, spFlags: DISPFlagDefinition, unit: !2)
!574 = !DILocation(line: 112, column: 1, scope: !573)
!575 = !DILocalVariable(name: "region", arg: 1, scope: !573, file: !0, line: 112, type: !117)
!576 = !DILocation(line: 112, column: 22, scope: !573)
!577 = !DILocalVariable(name: "cursor", arg: 2, scope: !573, file: !0, line: 112, type: !10)
!578 = !DILocation(line: 112, column: 49, scope: !573)
!579 = !DILocation(line: 113, column: 11, scope: !573)
!580 = !DILocalVariable(name: "base", scope: !573, file: !0, line: 113, type: !10)
!581 = !DILocation(line: 113, column: 3, scope: !573)
!582 = !DILocation(line: 114, column: 11, scope: !573)
!583 = !DILocation(line: 114, column: 35, scope: !573)
!584 = !DILocation(line: 114, column: 11, scope: !573)
!585 = !DILocation(line: 114, column: 11, scope: !573)
!586 = !DILocation(line: 114, column: 11, scope: !573)
!587 = !DILocalVariable(name: "own", scope: !573, file: !0, line: 114, type: !107)
!588 = !DILocation(line: 114, column: 3, scope: !573)
!589 = !DILocation(line: 115, column: 32, scope: !573)
!590 = !DILocation(line: 115, column: 18, scope: !573)
!591 = !DILocation(line: 115, column: 46, scope: !573)
!592 = !DILocation(line: 115, column: 18, scope: !573)
!593 = !DILocation(line: 115, column: 18, scope: !573)
!594 = !DILocation(line: 115, column: 18, scope: !573)
!595 = !DILocation(line: 115, column: 67, scope: !573)
!596 = !DILocation(line: 115, column: 67, scope: !573)
!597 = !DILocation(line: 115, column: 67, scope: !573)
!598 = !DILocation(line: 115, column: 11, scope: !573)
!599 = !DILocalVariable(name: "same", scope: !573, file: !0, line: 115, type: !107)
!600 = !DILocation(line: 115, column: 3, scope: !573)
!601 = !DILocation(line: 116, column: 3, scope: !573)
!602 = !DILocation(line: 116, column: 3, scope: !573)
!603 = !DILocation(line: 117, column: 15, scope: !573)
!604 = !DILocation(line: 117, column: 15, scope: !573)
!605 = !DILocation(line: 118, column: 16, scope: !573)
!606 = !DILocation(line: 116, column: 3, scope: !573)
!607 = !DILocation(line: 116, column: 3, scope: !573)
!608 = !DILocation(line: 116, column: 3, scope: !573)
!609 = !{!107, !117, !10, !107}
!610 = !DISubroutineType(types: !609)
!611 = distinct !DISubprogram(name: "commit-selected", linkageName: "topal.tail.component.topal.fn.commit_2dselected.132", scope: !0, file: !0, line: 120, type: !610, scopeLine: 120, spFlags: DISPFlagDefinition, unit: !2)
!612 = !DILocation(line: 120, column: 1, scope: !611)
!613 = !DILocalVariable(name: "region", arg: 1, scope: !611, file: !0, line: 120, type: !117)
!614 = !DILocation(line: 120, column: 25, scope: !611)
!615 = !DILocalVariable(name: "cursor", arg: 2, scope: !611, file: !0, line: 120, type: !10)
!616 = !DILocation(line: 120, column: 52, scope: !611)
!617 = !DILocalVariable(name: "allocating", arg: 3, scope: !611, file: !0, line: 120, type: !107)
!618 = !DILocation(line: 120, column: 66, scope: !611)
!619 = !DILocation(line: 121, column: 3, scope: !611)
!620 = !DILocation(line: 122, column: 15, scope: !611)
!621 = !DILocation(line: 122, column: 15, scope: !611)
!622 = !DILocation(line: 123, column: 16, scope: !611)
!623 = !DILocation(line: 123, column: 16, scope: !611)
!624 = !DILocation(line: 121, column: 3, scope: !611)
!625 = !DILocation(line: 121, column: 3, scope: !611)
!626 = !DILocation(line: 121, column: 3, scope: !611)
!627 = !{!107, !117, !107}
!628 = !DISubroutineType(types: !627)
!629 = distinct !DISubprogram(name: "commit", linkageName: "topal.tail.component.topal.fn.commit.133", scope: !0, file: !0, line: 125, type: !628, scopeLine: 125, spFlags: DISPFlagDefinition, unit: !2)
!630 = !DILocation(line: 125, column: 1, scope: !629)
!631 = !DILocalVariable(name: "region", arg: 1, scope: !629, file: !0, line: 125, type: !117)
!632 = !DILocation(line: 125, column: 16, scope: !629)
!633 = !DILocalVariable(name: "allocating", arg: 2, scope: !629, file: !0, line: 125, type: !107)
!634 = !DILocation(line: 125, column: 43, scope: !629)
!635 = !DILocation(line: 126, column: 13, scope: !629)
!636 = !DILocalVariable(name: "cursor", scope: !629, file: !0, line: 126, type: !10)
!637 = !DILocation(line: 126, column: 3, scope: !629)
!638 = !DILocation(line: 127, column: 28, scope: !629)
!639 = !DILocation(line: 127, column: 18, scope: !629)
!640 = !DILocation(line: 127, column: 18, scope: !629)
!641 = !DILocation(line: 127, column: 48, scope: !629)
!642 = !DILocation(line: 127, column: 70, scope: !629)
!643 = !DILocation(line: 127, column: 48, scope: !629)
!644 = !DILocation(line: 127, column: 48, scope: !629)
!645 = !DILocation(line: 127, column: 12, scope: !629)
!646 = !DILocalVariable(name: "valid", scope: !629, file: !0, line: 127, type: !107)
!647 = !DILocation(line: 127, column: 3, scope: !629)
!648 = !DILocation(line: 128, column: 3, scope: !629)
!649 = !DILocation(line: 129, column: 15, scope: !629)
!650 = !DILocation(line: 129, column: 15, scope: !629)
!651 = !DILocation(line: 130, column: 16, scope: !629)
!652 = !DILocation(line: 128, column: 3, scope: !629)
!653 = !DILocation(line: 128, column: 3, scope: !629)
!654 = !DILocation(line: 128, column: 3, scope: !629)
!655 = !{!107, !117}
!656 = !DISubroutineType(types: !655)
!657 = distinct !DISubprogram(name: "begin-release", linkageName: "topal.tail.component.topal.fn.begin_2drelease.167", scope: !0, file: !0, line: 132, type: !656, scopeLine: 132, spFlags: DISPFlagDefinition, unit: !2)
!658 = !DILocation(line: 132, column: 1, scope: !657)
!659 = !DILocalVariable(name: "region", arg: 1, scope: !657, file: !0, line: 132, type: !117)
!660 = !DILocation(line: 132, column: 22, scope: !657)
!661 = !DILocation(line: 133, column: 12, scope: !657)
!662 = !DILocalVariable(name: "start", scope: !657, file: !0, line: 133, type: !10)
!663 = !DILocation(line: 133, column: 3, scope: !657)
!664 = !DILocation(line: 134, column: 13, scope: !657)
!665 = !DILocalVariable(name: "cursor", scope: !657, file: !0, line: 134, type: !107)
!666 = !DILocation(line: 134, column: 3, scope: !657)
!667 = !DILocation(line: 135, column: 13, scope: !657)
!668 = !DILocalVariable(name: "length", scope: !657, file: !0, line: 135, type: !107)
!669 = !DILocation(line: 135, column: 3, scope: !657)
!670 = !DILocation(line: 136, column: 32, scope: !657)
!671 = !DILocation(line: 136, column: 13, scope: !657)
!672 = !DILocalVariable(name: "result", scope: !657, file: !0, line: 136, type: !107)
!673 = !DILocation(line: 136, column: 3, scope: !657)
!674 = !DILocation(line: 137, column: 12, scope: !657)
!675 = !DILocalVariable(name: "phase", scope: !657, file: !0, line: 137, type: !107)
!676 = !DILocation(line: 137, column: 3, scope: !657)
!677 = !DILocation(line: 138, column: 9, scope: !657)
!678 = !DILocation(line: 138, column: 32, scope: !657)
!679 = !DILocation(line: 138, column: 3, scope: !657)
!680 = !DILocation(line: 138, column: 3, scope: !657)
!681 = !DILocation(line: 138, column: 3, scope: !657)
!682 = !{!107, !117, !10}
!683 = !DISubroutineType(types: !682)
!684 = distinct !DISubprogram(name: "maybe-begin-release", linkageName: "topal.tail.component.topal.fn.maybe_2dbegin_2drelease.168", scope: !0, file: !0, line: 140, type: !683, scopeLine: 140, spFlags: DISPFlagDefinition, unit: !2)
!685 = !DILocation(line: 140, column: 1, scope: !684)
!686 = !DILocalVariable(name: "region", arg: 1, scope: !684, file: !0, line: 140, type: !117)
!687 = !DILocation(line: 140, column: 29, scope: !684)
!688 = !DILocalVariable(name: "processed", arg: 2, scope: !684, file: !0, line: 140, type: !10)
!689 = !DILocation(line: 140, column: 56, scope: !684)
!690 = !DILocation(line: 141, column: 16, scope: !684)
!691 = !DILocation(line: 141, column: 3, scope: !684)
!692 = !DILocation(line: 141, column: 3, scope: !684)
!693 = !DILocation(line: 141, column: 3, scope: !684)
!694 = !DILocation(line: 141, column: 3, scope: !684)
!695 = !DILocation(line: 142, column: 15, scope: !684)
!696 = !DILocation(line: 142, column: 15, scope: !684)
!697 = !DILocation(line: 143, column: 16, scope: !684)
!698 = !DILocation(line: 141, column: 3, scope: !684)
!699 = !DILocation(line: 141, column: 3, scope: !684)
!700 = !DILocation(line: 141, column: 3, scope: !684)
!701 = !{!107, !117, !10, !10}
!702 = !DISubroutineType(types: !701)
!703 = distinct !DISubprogram(name: "validated-cell", linkageName: "topal.tail.component.topal.fn.validated_2dcell.169", scope: !0, file: !0, line: 145, type: !702, scopeLine: 145, spFlags: DISPFlagDefinition, unit: !2)
!704 = !DILocation(line: 145, column: 1, scope: !703)
!705 = !DILocalVariable(name: "region", arg: 1, scope: !703, file: !0, line: 145, type: !117)
!706 = !DILocation(line: 145, column: 24, scope: !703)
!707 = !DILocalVariable(name: "cursor", arg: 2, scope: !703, file: !0, line: 145, type: !10)
!708 = !DILocation(line: 145, column: 51, scope: !703)
!709 = !DILocalVariable(name: "physical", arg: 3, scope: !703, file: !0, line: 145, type: !10)
!710 = !DILocation(line: 145, column: 65, scope: !703)
!711 = !DILocation(line: 146, column: 16, scope: !703)
!712 = !DILocalVariable(name: "processed", scope: !703, file: !0, line: 146, type: !10)
!713 = !DILocation(line: 146, column: 3, scope: !703)
!714 = !DILocation(line: 147, column: 27, scope: !703)
!715 = !DILocation(line: 147, column: 8, scope: !703)
!716 = !DILocalVariable(name: "a", scope: !703, file: !0, line: 147, type: !107)
!717 = !DILocation(line: 147, column: 3, scope: !703)
!718 = !DILocation(line: 148, column: 27, scope: !703)
!719 = !DILocation(line: 148, column: 8, scope: !703)
!720 = !DILocalVariable(name: "b", scope: !703, file: !0, line: 148, type: !107)
!721 = !DILocation(line: 148, column: 3, scope: !703)
!722 = !DILocation(line: 149, column: 8, scope: !703)
!723 = !DILocalVariable(name: "c", scope: !703, file: !0, line: 149, type: !107)
!724 = !DILocation(line: 149, column: 3, scope: !703)
!725 = !DILocation(line: 150, column: 12, scope: !703)
!726 = !DILocation(line: 150, column: 3, scope: !703)
!727 = !DILocation(line: 150, column: 3, scope: !703)
!728 = !DILocation(line: 151, column: 44, scope: !703)
!729 = !DILocation(line: 151, column: 15, scope: !703)
!730 = !DILocation(line: 151, column: 15, scope: !703)
!731 = !DILocation(line: 152, column: 16, scope: !703)
!732 = !DILocation(line: 150, column: 3, scope: !703)
!733 = !DILocation(line: 150, column: 3, scope: !703)
!734 = !DILocation(line: 150, column: 3, scope: !703)
!735 = !{!107, !117, !10}
!736 = !DISubroutineType(types: !735)
!737 = distinct !DISubprogram(name: "validate-cell", linkageName: "topal.tail.component.topal.fn.validate_2dcell.170", scope: !0, file: !0, line: 154, type: !736, scopeLine: 154, spFlags: DISPFlagDefinition, unit: !2)
!738 = !DILocation(line: 154, column: 1, scope: !737)
!739 = !DILocalVariable(name: "region", arg: 1, scope: !737, file: !0, line: 154, type: !117)
!740 = !DILocation(line: 154, column: 23, scope: !737)
!741 = !DILocalVariable(name: "cursor", arg: 2, scope: !737, file: !0, line: 154, type: !10)
!742 = !DILocation(line: 154, column: 50, scope: !737)
!743 = !DILocation(line: 155, column: 11, scope: !737)
!744 = !DILocalVariable(name: "base", scope: !737, file: !0, line: 155, type: !10)
!745 = !DILocation(line: 155, column: 3, scope: !737)
!746 = !DILocation(line: 156, column: 11, scope: !737)
!747 = !DILocation(line: 156, column: 35, scope: !737)
!748 = !DILocation(line: 156, column: 11, scope: !737)
!749 = !DILocation(line: 156, column: 11, scope: !737)
!750 = !DILocation(line: 156, column: 11, scope: !737)
!751 = !DILocalVariable(name: "own", scope: !737, file: !0, line: 156, type: !107)
!752 = !DILocation(line: 156, column: 3, scope: !737)
!753 = !DILocation(line: 157, column: 26, scope: !737)
!754 = !DILocation(line: 157, column: 12, scope: !737)
!755 = !DILocation(line: 157, column: 40, scope: !737)
!756 = !DILocation(line: 157, column: 12, scope: !737)
!757 = !DILocation(line: 157, column: 12, scope: !737)
!758 = !DILocation(line: 157, column: 12, scope: !737)
!759 = !DILocalVariable(name: "same", scope: !737, file: !0, line: 157, type: !107)
!760 = !DILocation(line: 157, column: 3, scope: !737)
!761 = !DILocation(line: 158, column: 29, scope: !737)
!762 = !DILocation(line: 158, column: 15, scope: !737)
!763 = !DILocalVariable(name: "physical", scope: !737, file: !0, line: 158, type: !10)
!764 = !DILocation(line: 158, column: 3, scope: !737)
!765 = !DILocation(line: 159, column: 13, scope: !737)
!766 = !DILocation(line: 159, column: 13, scope: !737)
!767 = !DILocation(line: 159, column: 13, scope: !737)
!768 = !DILocation(line: 159, column: 13, scope: !737)
!769 = !DILocalVariable(name: "first", scope: !737, file: !0, line: 159, type: !107)
!770 = !DILocation(line: 159, column: 3, scope: !737)
!771 = !DILocation(line: 160, column: 30, scope: !737)
!772 = !DILocation(line: 160, column: 30, scope: !737)
!773 = !DILocation(line: 160, column: 17, scope: !737)
!774 = !DILocation(line: 160, column: 17, scope: !737)
!775 = !DILocation(line: 160, column: 17, scope: !737)
!776 = !DILocalVariable(name: "contiguous", scope: !737, file: !0, line: 160, type: !107)
!777 = !DILocation(line: 160, column: 3, scope: !737)
!778 = !DILocation(line: 161, column: 18, scope: !737)
!779 = !DILocation(line: 161, column: 47, scope: !737)
!780 = !DILocation(line: 161, column: 58, scope: !737)
!781 = !DILocation(line: 161, column: 41, scope: !737)
!782 = !DILocation(line: 161, column: 36, scope: !737)
!783 = !DILocation(line: 161, column: 12, scope: !737)
!784 = !DILocalVariable(name: "valid", scope: !737, file: !0, line: 161, type: !107)
!785 = !DILocation(line: 161, column: 3, scope: !737)
!786 = !DILocation(line: 162, column: 3, scope: !737)
!787 = !DILocation(line: 163, column: 15, scope: !737)
!788 = !DILocation(line: 163, column: 15, scope: !737)
!789 = !DILocation(line: 164, column: 16, scope: !737)
!790 = !DILocation(line: 162, column: 3, scope: !737)
!791 = !DILocation(line: 162, column: 3, scope: !737)
!792 = !DILocation(line: 162, column: 3, scope: !737)
!793 = !{!107, !117}
!794 = !DISubroutineType(types: !793)
!795 = distinct !DISubprogram(name: "validate-release", linkageName: "topal.tail.component.topal.fn.validate_2drelease.171", scope: !0, file: !0, line: 166, type: !794, scopeLine: 166, spFlags: DISPFlagDefinition, unit: !2)
!796 = !DILocation(line: 166, column: 1, scope: !795)
!797 = !DILocalVariable(name: "region", arg: 1, scope: !795, file: !0, line: 166, type: !117)
!798 = !DILocation(line: 166, column: 25, scope: !795)
!799 = !DILocation(line: 167, column: 13, scope: !795)
!800 = !DILocalVariable(name: "cursor", scope: !795, file: !0, line: 167, type: !10)
!801 = !DILocation(line: 167, column: 3, scope: !795)
!802 = !DILocation(line: 168, column: 31, scope: !795)
!803 = !DILocation(line: 168, column: 21, scope: !795)
!804 = !DILocation(line: 168, column: 21, scope: !795)
!805 = !DILocation(line: 168, column: 51, scope: !795)
!806 = !DILocation(line: 168, column: 73, scope: !795)
!807 = !DILocation(line: 168, column: 51, scope: !795)
!808 = !DILocation(line: 168, column: 51, scope: !795)
!809 = !DILocation(line: 168, column: 15, scope: !795)
!810 = !DILocalVariable(name: "interval", scope: !795, file: !0, line: 168, type: !107)
!811 = !DILocation(line: 168, column: 3, scope: !795)
!812 = !DILocation(line: 169, column: 29, scope: !795)
!813 = !DILocation(line: 169, column: 29, scope: !795)
!814 = !DILocation(line: 169, column: 29, scope: !795)
!815 = !DILocation(line: 169, column: 12, scope: !795)
!816 = !DILocalVariable(name: "valid", scope: !795, file: !0, line: 169, type: !107)
!817 = !DILocation(line: 169, column: 3, scope: !795)
!818 = !DILocation(line: 170, column: 3, scope: !795)
!819 = !DILocation(line: 171, column: 15, scope: !795)
!820 = !DILocation(line: 171, column: 15, scope: !795)
!821 = !DILocation(line: 172, column: 16, scope: !795)
!822 = !DILocation(line: 170, column: 3, scope: !795)
!823 = !DILocation(line: 170, column: 3, scope: !795)
!824 = !DILocation(line: 170, column: 3, scope: !795)
!825 = !{!107, !117, !10}
!826 = !DISubroutineType(types: !825)
!827 = distinct !DISubprogram(name: "phase-step", linkageName: "topal.tail.component.topal.fn.phase_2dstep.225", scope: !0, file: !0, line: 174, type: !826, scopeLine: 174, spFlags: DISPFlagDefinition, unit: !2)
!828 = !DILocation(line: 174, column: 1, scope: !827)
!829 = !DILocalVariable(name: "region", arg: 1, scope: !827, file: !0, line: 174, type: !117)
!830 = !DILocation(line: 174, column: 20, scope: !827)
!831 = !DILocalVariable(name: "phase", arg: 2, scope: !827, file: !0, line: 174, type: !10)
!832 = !DILocation(line: 174, column: 47, scope: !827)
!833 = !DILocation(line: 176, column: 5, scope: !827)
!834 = !DILocation(line: 176, column: 5, scope: !827)
!835 = !DILocation(line: 176, column: 5, scope: !827)
!836 = !DILocation(line: 176, column: 15, scope: !827)
!837 = !DILocation(line: 177, column: 5, scope: !827)
!838 = !DILocation(line: 177, column: 5, scope: !827)
!839 = !DILocation(line: 177, column: 5, scope: !827)
!840 = !DILocation(line: 177, column: 15, scope: !827)
!841 = !DILocation(line: 178, column: 5, scope: !827)
!842 = !DILocation(line: 178, column: 5, scope: !827)
!843 = !DILocation(line: 178, column: 5, scope: !827)
!844 = !DILocation(line: 178, column: 15, scope: !827)
!845 = !DILocation(line: 179, column: 5, scope: !827)
!846 = !DILocation(line: 179, column: 5, scope: !827)
!847 = !DILocation(line: 179, column: 5, scope: !827)
!848 = !DILocation(line: 179, column: 15, scope: !827)
!849 = !DILocation(line: 180, column: 5, scope: !827)
!850 = !DILocation(line: 180, column: 5, scope: !827)
!851 = !DILocation(line: 180, column: 5, scope: !827)
!852 = !DILocation(line: 181, column: 15, scope: !827)
!853 = !DILocation(line: 175, column: 3, scope: !827)
!854 = !DILocation(line: 175, column: 3, scope: !827)
!855 = !DILocation(line: 175, column: 3, scope: !827)
!856 = !{!107, !117}
!857 = !DISubroutineType(types: !856)
!858 = distinct !DISubprogram(name: "step", linkageName: "topal.tail.component.topal.fn.step.226", scope: !0, file: !0, line: 183, type: !857, scopeLine: 183, spFlags: DISPFlagDefinition, unit: !2)
!859 = !DILocation(line: 183, column: 1, scope: !858)
!860 = !DILocalVariable(name: "region", arg: 1, scope: !858, file: !0, line: 183, type: !117)
!861 = !DILocation(line: 183, column: 13, scope: !858)
!862 = !DILocation(line: 184, column: 11, scope: !858)
!863 = !DILocation(line: 184, column: 11, scope: !858)
!864 = !DILocalVariable(name: "size", scope: !858, file: !0, line: 184, type: !10)
!865 = !DILocation(line: 184, column: 3, scope: !858)
!866 = !DILocation(line: 185, column: 12, scope: !858)
!867 = !DILocalVariable(name: "cells", scope: !858, file: !0, line: 185, type: !10)
!868 = !DILocation(line: 185, column: 3, scope: !858)
!869 = !DILocation(line: 186, column: 12, scope: !858)
!870 = !DILocalVariable(name: "count", scope: !858, file: !0, line: 186, type: !10)
!871 = !DILocation(line: 186, column: 3, scope: !858)
!872 = !DILocation(line: 187, column: 15, scope: !858)
!873 = !DILocalVariable(name: "identity", scope: !858, file: !0, line: 187, type: !10)
!874 = !DILocation(line: 187, column: 3, scope: !858)
!875 = !DILocation(line: 188, column: 37, scope: !858)
!876 = !DILocation(line: 188, column: 30, scope: !858)
!877 = !DILocation(line: 188, column: 21, scope: !858)
!878 = !DILocation(line: 188, column: 21, scope: !858)
!879 = !DILocation(line: 188, column: 51, scope: !858)
!880 = !DILocation(line: 188, column: 51, scope: !858)
!881 = !DILocation(line: 188, column: 15, scope: !858)
!882 = !DILocalVariable(name: "geometry", scope: !858, file: !0, line: 188, type: !107)
!883 = !DILocation(line: 188, column: 3, scope: !858)
!884 = !DILocation(line: 189, column: 21, scope: !858)
!885 = !DILocation(line: 189, column: 21, scope: !858)
!886 = !DILocation(line: 189, column: 35, scope: !858)
!887 = !DILocation(line: 189, column: 35, scope: !858)
!888 = !DILocation(line: 189, column: 15, scope: !858)
!889 = !DILocalVariable(name: "issuance", scope: !858, file: !0, line: 189, type: !107)
!890 = !DILocation(line: 189, column: 3, scope: !858)
!891 = !DILocation(line: 190, column: 3, scope: !858)
!892 = !DILocation(line: 190, column: 3, scope: !858)
!893 = !DILocation(line: 191, column: 35, scope: !858)
!894 = !DILocation(line: 191, column: 15, scope: !858)
!895 = !DILocation(line: 191, column: 15, scope: !858)
!896 = !DILocation(line: 192, column: 16, scope: !858)
!897 = !DILocation(line: 190, column: 3, scope: !858)
!898 = !DILocation(line: 190, column: 3, scope: !858)
!899 = !DILocation(line: 190, column: 3, scope: !858)
!900 = !{!10, !117}
!901 = !DISubroutineType(types: !900)
!902 = distinct !DISubprogram(name: "step-status", linkageName: "topal.tail.component.topal.fn.step_2dstatus.449", scope: !0, file: !0, line: 194, type: !901, scopeLine: 194, spFlags: DISPFlagDefinition, unit: !2)
!903 = !DILocation(line: 194, column: 1, scope: !902)
!904 = !DILocalVariable(name: "region", arg: 1, scope: !902, file: !0, line: 194, type: !117)
!905 = !DILocation(line: 194, column: 20, scope: !902)
!906 = !DILocalVariable(name: "zero", scope: !902, file: !0, line: 195, type: !10)
!907 = !DILocation(line: 195, column: 3, scope: !902)
!908 = !DILocalVariable(name: "invalid", scope: !902, file: !0, line: 196, type: !10)
!909 = !DILocation(line: 196, column: 3, scope: !902)
!910 = !DILocation(line: 197, column: 3, scope: !902)
!911 = !DILocation(line: 197, column: 3, scope: !902)
!912 = !DILocation(line: 198, column: 15, scope: !902)
!913 = !DILocation(line: 199, column: 16, scope: !902)
!914 = !DILocation(line: 197, column: 3, scope: !902)
!915 = !DILocation(line: 197, column: 3, scope: !902)
!916 = !DILocation(line: 197, column: 3, scope: !902)
!917 = !{!10, !117, !10}
!918 = !DISubroutineType(types: !917)
!919 = distinct !DISubprogram(name: "next-status", linkageName: "topal.tail.component.topal.fn.next_2dstatus.450", scope: !0, file: !0, line: 201, type: !918, scopeLine: 201, spFlags: DISPFlagDefinition, unit: !2)
!920 = !DILocation(line: 201, column: 1, scope: !919)
!921 = !DILocalVariable(name: "region", arg: 1, scope: !919, file: !0, line: 201, type: !117)
!922 = !DILocation(line: 201, column: 21, scope: !919)
!923 = !DILocalVariable(name: "status", arg: 2, scope: !919, file: !0, line: 201, type: !10)
!924 = !DILocation(line: 201, column: 48, scope: !919)
!925 = !DILocalVariable(name: "invalid", scope: !919, file: !0, line: 202, type: !10)
!926 = !DILocation(line: 202, column: 3, scope: !919)
!927 = !DILocation(line: 203, column: 3, scope: !919)
!928 = !DILocation(line: 203, column: 3, scope: !919)
!929 = !DILocation(line: 203, column: 3, scope: !919)
!930 = !DILocation(line: 203, column: 3, scope: !919)
!931 = !DILocation(line: 204, column: 15, scope: !919)
!932 = !DILocation(line: 204, column: 15, scope: !919)
!933 = !DILocation(line: 205, column: 16, scope: !919)
!934 = !DILocation(line: 203, column: 3, scope: !919)
!935 = !DILocation(line: 203, column: 3, scope: !919)
!936 = !DILocation(line: 203, column: 3, scope: !919)
!937 = !{null, !117, !10, !10, !10}
!938 = !DISubroutineType(types: !937)
!939 = distinct !DISubprogram(name: "frame-policy [tail step]", linkageName: "topal_tail_step_component_v1", scope: !0, file: !0, line: 214, type: !938, scopeLine: 214, spFlags: DISPFlagDefinition, unit: !2)
!940 = !DILocation(line: 214, column: 5, scope: !939)
!941 = !DILocation(line: 214, column: 26, scope: !939)
!942 = !DILocalVariable(name: "region", arg: 1, scope: !939, file: !0, line: 214, type: !117)
!943 = !DILocation(line: 214, column: 26, scope: !939)
!944 = !DILocation(line: 214, column: 53, scope: !939)
!945 = !DILocalVariable(name: "remaining", arg: 2, scope: !939, file: !0, line: 214, type: !10)
!946 = !DILocation(line: 214, column: 53, scope: !939)
!947 = !DILocation(line: 214, column: 70, scope: !939)
!948 = !DILocalVariable(name: "unused", arg: 3, scope: !939, file: !0, line: 214, type: !10)
!949 = !DILocation(line: 214, column: 70, scope: !939)
!950 = !DILocation(line: 214, column: 84, scope: !939)
!951 = !DILocalVariable(name: "status", arg: 4, scope: !939, file: !0, line: 214, type: !10)
!952 = !DILocation(line: 214, column: 84, scope: !939)
!953 = !DILocation(line: 216, column: 5, scope: !939)
!954 = !DILocation(line: 216, column: 5, scope: !939)
!955 = !DILocation(line: 216, column: 5, scope: !939)
!956 = !DILocation(line: 216, column: 15, scope: !939)
!957 = !DILocation(line: 216, column: 15, scope: !939)
!958 = !DILocation(line: 216, column: 15, scope: !939)
!959 = !DILocation(line: 217, column: 37, scope: !939)
!960 = !DILocation(line: 217, column: 60, scope: !939)
!961 = !DILocation(line: 217, column: 15, scope: !939)
!962 = !DILocation(line: 217, column: 15, scope: !939)
!963 = !DILocation(line: 217, column: 15, scope: !939)
!964 = !DILocation(line: 217, column: 15, scope: !939)
!965 = !DILocation(line: 217, column: 15, scope: !939)
!966 = !{i32 2, !"Dwarf Version", i32 5}
!967 = !{i32 2, !"Debug Info Version", i32 3}
!968 = !{!"topalc 0.1.0"}
