use language (version is v0.1, features is (systems))
pub find-zero is fn ((region : KernelByteRegion, remaining : Nat, offset : Nat, state : Nat)) -> Nat : Decreases remaining
  remaining
    <= 0 then offset
    otherwise find-zero(region, remaining - 1, offset + 1, state)
