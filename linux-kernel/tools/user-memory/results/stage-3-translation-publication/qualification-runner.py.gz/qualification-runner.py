import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo=Path.cwd()
base=repo/'linux-kernel/.cache/x86_64'
location=json.loads((base/'translation-publication-run-location.json').read_bytes())
build=Path(location['build'])
native=json.loads((Path(location['work'])/'run.json').read_bytes())
assert native['exit_code']==0 and not native['source_changes_during_run'] and not native['artifacts_changed']
output=base/'translation-publication-checks'
output.mkdir(exist_ok=False)
readers=repo/'linux-kernel/tools/user-memory'
previous=repo/'linux-kernel/tools/user-memory/results/stage-3-owner-intervals'
digest=lambda raw:hashlib.sha256(raw).hexdigest()
commands=[]
def run(label,args):
    start=time.monotonic()
    result=subprocess.run([sys.executable]+list(map(str,args)),cwd=repo,
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (output/(label+'.log')).write_bytes(result.stdout)
    commands.append(dict(label=label,command=[sys.executable]+list(map(str,args)),exit_code=result.returncode,
        seconds=time.monotonic()-start,log_sha256=digest(result.stdout)))
    (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    assert result.returncode==0,(label,result.stdout[-4000:].decode(errors='replace'))
    print(label+' passed',flush=True)
run('models',['-m','unittest','discover','-s',readers,'-v'])
assert b'Ran 177 tests' in (output/'models.log').read_bytes()
run('layout',[readers/'inspect_translation_publication.py',build,output/'layout.json'])
run('publication',[readers/'readback_translation_publication.py',build,output/'publication.json'])
run('owners',[previous/'readback-owner-boundaries.py',build,build/'source-user-extents/observations.json',output/'owners.json'])
run('metadata',[previous/'readback-source-metadata.py',build,output/'metadata'])
run('controls',[readers/'control_translation_publication.py',build,output/'controls'])
serial=(build/'source-user-extents/serial.log').read_bytes()
import gzip
old=gzip.decompress((previous/'native/observation/serial.log.gz').read_bytes())
assert old==serial and len(serial)==7606
report=dict(passed=True,models=177,offline_controls=18,new_native_execution=True,
    serial_bytes=len(serial),serial_sha256=digest(serial),complete_console_equals_preceding_native=True,
    kernel_sha256=native['artifact_hashes_before']['kernel.elf'],commands=commands,
    scope='Bounded Python-only checks over the completed new same-kernel ordinary VM run; not a full new Rust/compiler/production qualification')
(output/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
