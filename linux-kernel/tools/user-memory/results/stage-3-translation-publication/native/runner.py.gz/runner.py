"""Run only the authorized unchanged-kernel metadata VM with new read-only probes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo=Path.cwd()
base=repo/'linux-kernel/.cache/x86_64'
original=base/'user-extent-source-metadata-2408345-1794470644696506965'
work=base/('translation-publication-native-'+str(time.time_ns()))
work.mkdir()
build=work/'build'
build.mkdir()
for path in original.iterdir():
    if path.name!='source-user-extents':(build/path.name).symlink_to(path)
names=['linux-kernel/tools/user-memory/'+n for n in ['translation_publication.py',
    'test_translation_publication.py','inspect_translation_publication.py','qemu_publication_trace.py']]
names+=['linux-kernel/labs/qemu/x86_64/'+n for n in ['user_extent_translation_observer.py','user_extent_source_inspect.py','frame_root_inspect.py']]
digest=lambda raw:hashlib.sha256(raw).hexdigest()
def hashes():return {name:digest((repo/name).read_bytes()) for name in names}
artifacts=['kernel.elf','bzImage','initramfs.cpio','provider.o','dispatch.o','dispatch.ll','runtime.o',
    'target.o','static-elf-abi-fixture.elf','source-user.elf','user-owners.json','source-component.json']
def artifact_hashes():return {name:digest((build/name).read_bytes()) for name in artifacts}
before=hashes()
inputs=artifact_hashes()
env=dict(os.environ,TOPAL_TEST_EXTENT_OWNERS='metadata',TOPAL_TEST_EXTENT_TRANSLATIONS='metadata',
    PYTHONDONTWRITEBYTECODE='1')
env.pop('TOPAL_TEST_EXTENT_INTERVALS',None)
command=[sys.executable,str(repo/'linux-kernel/labs/qemu/x86_64/user_extent_source_inspect.py'),str(build)]
(base/'translation-publication-run-location.json').write_text(json.dumps(dict(work=str(work),build=str(build)),indent=2)+'\n')
print('native record: '+str(work),flush=True)
start=time.monotonic()
with (work/'test.log').open('wb') as handle:
    result=subprocess.run(command,cwd=repo,env=env,stdout=handle,stderr=subprocess.STDOUT)
after=hashes()
final_inputs=artifact_hashes()
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
cgroup=Path('/sys/fs/cgroup'+group)
resources={name:(cgroup/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
record=dict(command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
    source_hashes_before=before,source_hashes_after=after,source_changes_during_run=before!=after,
    artifact_hashes_before=inputs,artifact_hashes_after=final_inputs,artifacts_changed=inputs!=final_inputs,
    observer_environment={name:env[name] for name in ['TOPAL_TEST_EXTENT_OWNERS','TOPAL_TEST_EXTENT_TRANSLATIONS']},
    resources=resources,scope='Unchanged-kernel ordinary four-iteration metadata VM plus local heap translation publication probes; no guest register/memory assignments or host/VM boundary changes')
(work/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print((work/'test.log').read_text()[-7000:],flush=True)
print(json.dumps(record),flush=True)
assert not record['source_changes_during_run'] and not record['artifacts_changed']
assert resources['memory.swap.max']=='0'
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
sys.exit(result.returncode)
