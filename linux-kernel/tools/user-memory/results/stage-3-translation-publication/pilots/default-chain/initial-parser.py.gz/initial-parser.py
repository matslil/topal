"""Parse saved QEMU TCG CPU states immediately following the publisher INVLPG.

These are execution-log observations, not a TLB dump or general CPU exclusion.
"""
import re


def parse(raw,site):
    text=raw.decode('ascii')
    starts=list(re.finditer(r'^Trace ([0-9]+): [^\n]*\[([0-9a-f]+)/([0-9a-f]+)/[^\]]+\][^\n]*\n',text,re.M))
    result=[]
    for i,header in enumerate(starts):
        cpu,_,pc=header.groups()
        pc=int(pc,16)
        assert pc==site,'unexpected CPU trace PC'
        block=text[header.end():starts[i+1].start() if i+1<len(starts) else len(text)]
        def value(name):
            values=re.findall(r'\b'+name+r'\s*=([0-9a-fA-F]+)',block)
            assert len(values)==1,('missing or duplicate CPU state',name)
            return int(values[0],16)
        assert value('RIP')==site and value('CS')&3==0
        result.append(dict(cpu=int(cpu),index=value('RCX'),address=value('RAX'),
            cr0=value('CR0'),cr3=value('CR3'),cr4=value('CR4'),efer=value('EFER'),flags=value('RFL')))
    assert not raw or starts,'unparsed nonempty CPU trace'
    return result
