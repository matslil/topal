set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/translation-cpu-log-default-chain-pilot/build/kernel.elf"
target remote 127.0.0.1:47989
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/translation-cpu-log-default-chain-pilot/build/pilot/observations.json'
profile={'passed': True, 'kernel_sha256': '47b785aca3794d171d508a3fdbb616057a613016c1783ca9ec95236dbba2199f', 'function_sha256': '019d80d15a88e149c052d72b8d1d40897361bb0593e0b0f8c23a63262f7ceb53', 'function': {'name': 'm.publish', 'info': 2, 'section': 3, 'value': 45160080, 'size': 149}, 'source_sha256': 'cd788d52b2a66f15f80b1a8b6d668d0501f50daed73f5e0151e21d953f5713be', 'dispatch_ir_sha256': '1bfddb07fb32196a9d60aac0b5ea684daa69232f27c67cbaf251733bc7b5114a', 'erase_entry': 45160032, 'inspector_sha256': '115b4b7a707ae85e66168e79f81948f85c6b2b4584b66ac0e9fcd68ce388dc26', 'sites': {'entry': 45160080, 'stored': 45160177, 'invalidated': 45160195, 'returning': 45160228}, 'sites_meaning': {'stored': 'After the first locked publication barrier and before any INVLPG iteration', 'invalidated': 'Immediately after INVLPG and before index/address increments', 'returning': 'After the second locked barrier and complete epilogue, before RET'}, 'scope': 'Exact current 149-byte publisher layout, linked PTE-helper call and source/compiled IR binding; not arbitrary-code decoding, continuous CPU state, AP/DMA/async or complete compiler correctness'}

import gdb,json
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
record=dict(passed=False,full_guest_retirement_complete=False,publications=[])
pending=None
class Entered(gdb.Breakpoint):
    def stop(self):
        global pending
        assert pending is None
        pending=dict(old=reg('rdi'),new=reg('rsi'),base=reg('rdx'),thread=list(gdb.selected_thread().ptid),
            cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'))
        return False
class Returned(gdb.Breakpoint):
    def stop(self):
        global pending
        assert pending is not None
        pending.update(final_address=reg('rax'),final_index=reg('rcx'))
        assert pending['final_index']==max(pending['old'],pending['new'])
        assert pending['final_address']==0x5f7000+pending['final_index']*4096
        record['publications'].append(pending)
        pending=None
        if len(record['publications'])<2:return False
        record.update(passed=True,scope='Two ordinary initial heap publications; default block chaining and read-only CPU logging. Stopped before complete guest retirement')
        with open(observation_path,'w') as handle:json.dump(record,handle,indent=2)
        print('FRAME_ROOT_GDB_PASS')
        gdb.execute('detach')
        gdb.execute('quit')
Entered('*'+hex(profile['sites']['entry']),internal=True)
Returned('*'+hex(profile['sites']['returning']),internal=True)
gdb.execute('continue')

end
