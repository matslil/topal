"""Qualify per-page CPU logging with default block chaining on two publications."""
import hashlib
import json
from pathlib import Path
import sys

repo=Path.cwd()
base=repo/'linux-kernel/.cache/x86_64'
source=base/'user-extent-source-metadata-2408345-1794470644696506965'
work=base/'translation-cpu-log-default-chain-pilot'
work.mkdir(exist_ok=False)
build=work/'build'
build.mkdir()
for path in source.iterdir():
    if path.name!='source-user-extents':(build/path.name).symlink_to(path)
sys.path.insert(0,str(repo/'linux-kernel/tools/user-memory'))
from inspect_translation_publication import inspect
from qemu_publication_trace import parse
profile=inspect(build)
sys.path.insert(0,str(repo/'linux-kernel/labs/qemu/x86_64'))
import frame_root_inspect as harness
original=harness.topal_gate.qemu_command
def command(*args,**kwargs):
    site=profile['sites']['invalidated']
    return original(*args,**kwargs)+['-d','cpu,exec,tid','-dfilter',hex(site)+'..'+hex(site),
        '-D',str(build/'pilot/cpu-%d.log')]
harness.topal_gate.qemu_command=command
harness.GDB_PROGRAM=r'''
import gdb,json
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
record=dict(passed=False,full_guest_retirement_complete=False,publications=[])
pending=None
class Entered(gdb.Breakpoint):
    def stop(self):
        global pending
        assert pending is None
        pending=dict(old=reg('rdi'),new=reg('rsi'),base=reg('rdx'),thread=list(gdb.selected_thread().ptid),
            cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'))
        return False
class Returned(gdb.Breakpoint):
    def stop(self):
        global pending
        assert pending is not None
        pending.update(final_address=reg('rax'),final_index=reg('rcx'))
        assert pending['final_index']==max(pending['old'],pending['new'])
        assert pending['final_address']==0x5f7000+pending['final_index']*4096
        record['publications'].append(pending)
        pending=None
        if len(record['publications'])<2:return False
        record.update(passed=True,scope='Two ordinary initial heap publications; default block chaining and read-only CPU logging. Stopped before complete guest retirement')
        with open(observation_path,'w') as handle:json.dump(record,handle,indent=2)
        print('FRAME_ROOT_GDB_PASS')
        gdb.execute('detach')
        gdb.execute('quit')
Entered('*'+hex(profile['sites']['entry']),internal=True)
Returned('*'+hex(profile['sites']['returning']),internal=True)
gdb.execute('continue')
'''
sys.argv=[sys.argv[0],str(build)]
harness.main(work_name='pilot',program_prefix='profile='+repr(profile)+'\n',expect_backing=False,guest_timeout_seconds=300)
observed=json.loads((build/'pilot/observations.json').read_bytes())
assert [(row['old'],row['new']) for row in observed['publications']]==[(0,1),(1,34)]
events=[]
logs=[]
for path in sorted((build/'pilot').glob('cpu-*.log')):
    raw=path.read_bytes()
    parsed=parse(raw,profile['sites']['invalidated'])
    assert len(parsed)==sum(line.startswith(b'Trace ') for line in raw.splitlines())
    events+=parsed
    logs.append(dict(file=path.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
cursor=0
for row in observed['publications']:
    for i in range(max(row['old'],row['new'])):
        event=events[cursor]
        assert event['index']==i and event['address']==0x5f7000+i*4096 and event['cpu']==0
        assert (event['cr0'],event['cr3'],event['cr4'])==tuple(row[k] for k in ['cr0','cr3','cr4'])
        cursor+=1
assert cursor==len(events)==35
report=dict(passed=True,post_invlpg_states=len(events),publications=2,logs=logs,
    full_guest_retirement_complete=False,scope='Installed-version CPU-log capability pilot with default block chaining; no complete guest/caller/lifetime qualification')
(work/'readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
