"""Qualify installed QEMU CPU logging on the first ordinary heap publication."""
import hashlib
import json
from pathlib import Path
import sys

repo=Path.cwd()
base=repo/'linux-kernel/.cache/x86_64'
source=base/'user-extent-source-metadata-2408345-1794470644696506965'
work=base/'translation-cpu-log-pilot'
work.mkdir(exist_ok=False)
build=work/'build'
build.mkdir()
for path in source.iterdir():
    if path.name!='source-user-extents':(build/path.name).symlink_to(path)
sys.path.insert(0,str(repo/'linux-kernel/tools/user-memory'))
from inspect_translation_publication import inspect
profile=inspect(build)
sys.path.insert(0,str(repo/'linux-kernel/labs/qemu/x86_64'))
import frame_root_inspect as harness
original=harness.topal_gate.qemu_command
def command(*args,**kwargs):
    lo=profile['sites']['entry']
    hi=profile['sites']['returning']
    return original(*args,**kwargs)+['-d','cpu,exec,nochain,tid','-dfilter',hex(lo)+'..'+hex(hi),
        '-D',str(build/'pilot/cpu-%d.log')]
harness.topal_gate.qemu_command=command
harness.GDB_PROGRAM=r'''
import gdb,hashlib,json
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
record=dict(passed=False,full_guest_retirement_complete=False)
class Entered(gdb.Breakpoint):
    def stop(self):
        record.update(old=reg('rdi'),new=reg('rsi'),base=reg('rdx'),thread=list(gdb.selected_thread().ptid),
            cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'))
        assert record['old']==0 and record['new']==1
        self.enabled=False
        return False
class Returned(gdb.Breakpoint):
    def stop(self):
        record.update(passed=True,final_address=reg('rax'),final_index=reg('rcx'),
            scope='First ordinary heap-publication pilot stopped before return; not complete application retirement')
        assert record['final_address']==0x5f8000 and record['final_index']==1
        with open(observation_path,'w') as handle:json.dump(record,handle,indent=2)
        print('FRAME_ROOT_GDB_PASS')
        gdb.execute('detach')
        gdb.execute('quit')
Entered('*'+hex(profile['sites']['entry']),internal=True)
Returned('*'+hex(profile['sites']['returning']),internal=True)
gdb.execute('continue')
'''
sys.argv=[sys.argv[0],str(build)]
harness.main(work_name='pilot',program_prefix='profile='+repr(profile)+'\n',expect_backing=False,guest_timeout_seconds=300)
print(json.dumps(json.loads((build/'pilot/observations.json').read_bytes())))
for path in sorted((build/'pilot').glob('cpu-*.log')):
    data=path.read_bytes()
    print(path.name,len(data),hashlib.sha256(data).hexdigest())
    print(data.decode()[:5000])
