"""Read-only observations of local heap publication and invalidation retirement."""
from pathlib import Path

MODEL=(Path(__file__).resolve().parents[3]/'tools/user-memory/translation_publication.py').read_text()
PROGRAM='translation_model={}\nexec('+repr(MODEL)+',translation_model)\n'+r'''
translation_active=None
translation_request=None
translation_records=[]
translation_requests=[]
translation_return_points={}

def translation_capture():
    root,low=word(context+24),word(context+112)
    assert 0<root<=(1<<30)-5*4096 and root%4096==0
    assert 0<low<=(1<<30)-4096 and low%4096==0
    return dict(context=dict(address=context,root=root,low=low),state=state(),
        tokens=words(address('topal_x86_frame_mm_tokens_v1'),6),
        tables={str(at):words(at,512) for at in [root,root+4096,root+8192,root+12288,root+16384,low]},
        thread=list(gdb.selected_thread().ptid),cr0=reg('cr0'),cr3=reg('cr3'),cr4=reg('cr4'),
        cs=reg('cs'),flags=reg('eflags'))

class TranslationPublication(Checked):
    def __init__(self,kind,site):
        self.kind=kind
        super().__init__('*'+hex(site),internal=True)

    def observe(self):
        global translation_active
        assert translation_request is not None
        if self.kind=='entry':
            assert translation_active is None and translation_request['publication_index'] is None
            translation_active=dict(old_count=reg('rdi'),new_count=reg('rsi'),new_base=reg('rdx'),
                before=translation_capture(),entry_stack=reg('rsp'),entry_return_address=word(reg('rsp')),
                invalidations=[],published_before_invalidations=False,final_barrier_observed=False)
        elif self.kind=='stored':
            row=translation_active
            assert row is not None and not row['published_before_invalidations'] and not row['invalidations']
            row['stored']=translation_capture()
            translation_model['published'](row['before'],row['stored'],row['old_count'],row['new_count'],row['new_base'])
            row['published_before_invalidations']=True
        elif self.kind=='invalidated':
            row=translation_active
            assert row is not None and row['published_before_invalidations']
            index=reg('rcx')
            assert index==len(row['invalidations']) and reg('rax')==0x5f7000+index*4096
            row['invalidations'].append(dict(index=index,address=reg('rax'),thread=list(gdb.selected_thread().ptid)))
        else:
            assert self.kind=='returning' and translation_active is not None
            row=translation_active
            row.update(after=translation_capture(),return_stack=reg('rsp'),return_address=word(reg('rsp')),
                final_barrier_observed=True)
            row['comparison']=translation_model['check'](row)
            translation_request['publication_index']=len(translation_records)
            translation_records.append(row)
            translation_active=None
        return False

class TranslationRequest(Checked):
    def observe(self):
        global translation_request
        assert translation_request is None and translation_active is None
        stack=reg('rsp')
        site=word(stack)
        translation_request=dict(operation=reg('rdi'),request=reg('rsi'),before=translation_capture(),
            entry_stack=stack,entry_return_address=site,publication_index=None,erase=None,release=None)
        assert translation_request['operation'] in [5,6,7]
        if site not in translation_return_points:
            translation_return_points[site]=TranslationRequestReturned('*'+hex(site),internal=True)
        translation_return_points[site].enabled=True
        return False

class TranslationRequestReturned(Checked):
    def observe(self):
        global translation_request
        row=translation_request
        assert row is not None and translation_active is None
        assert reg('rsp')==row['entry_stack']+8 and reg('rip')==row['entry_return_address']
        row.update(after=translation_capture(),result=reg('rax'))
        index=row['publication_index']
        if index is not None:
            publication=translation_records[index]
            assert row['before']['state'][2]==publication['old_count']
            assert row['after']['state'][2]==publication['new_count']
            if publication['old_count']:
                assert row['erase'] is not None and row['release'] is not None
            else:assert row['erase'] is row['release'] is None
        else:
            assert row['before']['state'][2:]==row['after']['state'][2:]
            assert row['erase'] is row['release'] is None
        translation_requests.append(row)
        translation_request=None
        self.enabled=False
        return False

class TranslationErase(Checked):
    def observe(self):
        if translation_request is None:return False
        row=translation_request
        assert translation_active is None and row['publication_index'] is not None
        assert row['erase'] is None and row['release'] is None
        publication=translation_records[row['publication_index']]
        old=publication['before']['state']
        assert reg('rdi')==old[3] and reg('rsi')==old[2] and old[2]>0
        token=words(address('topal_x86_frame_mm_tokens_v1'),3)
        registry=words(address('topal_x86_frame_registry_v1')+token[2]*64,8)
        assert registry[:2]==token[:2] and registry[3]==old[2] and registry[6:]==[0,1]
        row['erase']=dict(base=reg('rdi'),count=reg('rsi'),old_token=token,old_registry=registry,
            after_publication_index=row['publication_index'],thread=list(gdb.selected_thread().ptid))
        return False

class TranslationRelease(Checked):
    def observe(self):
        if translation_request is None:return False
        row=translation_request
        assert translation_active is None and row['erase'] is not None and row['release'] is None
        assert reg('rsi')==address('topal_x86_frame_mm_tokens_v1')
        erase=row['erase']
        raw=memory(erase['base'],erase['count']*4096)
        assert raw==bytes(len(raw))
        row['release']=dict(base=erase['base'],count=erase['count'],erased_bytes=len(raw),
            erased_sha256=hashlib.sha256(raw).hexdigest(),after_publication_index=row['publication_index'],
            thread=list(gdb.selected_thread().ptid))
        return False

def install_translation_observation():
    if translation_profile is None:return
    assert component['mode']=='metadata'
    for kind,site in translation_profile['sites'].items():TranslationPublication(kind,site)
    TranslationRequest('*topal_frame_memory_request_v1',internal=True)
    TranslationErase('*'+hex(translation_profile['erase_entry']),internal=True)
    TranslationRelease('*topal_frame_allocator_release_v1',internal=True)

def translation_observation_complete():
    if translation_profile is None:return
    assert translation_active is translation_request is None
    assert translation_records and translation_requests
    assert all(not point.enabled for point in translation_return_points.values())
    observed['translation_publication_observation']=dict(passed=True,records=translation_records,
        requests=translation_requests,profile=translation_profile,
        model_sha256=hashlib.sha256(translation_model_source.encode()).hexdigest(),
        scope='Actual local heap publication and post-INVLPG/final-barrier boundaries, plus unpin/erase/release ordering in ordinary requests; not TLB introspection, all CPUs, continuous mode, DMA/async or complete stable lifetime qualification')
'''
