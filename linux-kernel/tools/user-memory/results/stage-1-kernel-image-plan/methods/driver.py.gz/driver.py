import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'linux-kernel/tools/process-memory'))
from run_policy_failure import watched,hashes
out=ROOT/'linux-kernel/.cache/x86_64/kernel-image-plan-models-stage-1';out.mkdir(exist_ok=False)
paths=sorted(set(watched())|{'linux-kernel/design/kernel-image-protection.md','linux-kernel/design/decision-register.md',
    'docs/systems-profile.md','se/requirements.md','spec/systems-profile.md','src/topal-compiler/se-requirements.md'})
before=hashes(paths);commands={};began=time.monotonic()
group=next(x.split(':',2)[2] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'))
resources=Path('/sys/fs/cgroup')/group.lstrip('/');assert 'topal-bounded-' in group and (resources/'memory.swap.max').read_text().strip()=='0'
for label,count in [('user-memory',271),('process-memory',82)]:
    argv=['rtk','proxy','python3','-B','-m','unittest','discover','-s','linux-kernel/tools/'+label,'-p','test_*.py']
    result=subprocess.run(argv,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True)
    (out/(label+'.stdout.log')).write_bytes(result.stdout);(out/(label+'.stderr.log')).write_bytes(result.stderr)
    commands[label]=dict(argv=argv,exit_code=result.returncode,tests=count)
    assert result.returncode==0 and ('Ran '+str(count)+' tests').encode() in result.stderr,result.stderr.decode()
changed=subprocess.check_output(['rtk','proxy','git','diff','--name-only','01f8ddec88592ca19fcf0a57fdb9ab622e7c11f4','--','src'],cwd=ROOT).decode().splitlines()
assert changed==['src/topal-compiler/se-requirements.md'],changed
after=hashes(paths);assert before==after
report=dict(passed=True,commands=commands,source_hashes_before=before,source_hashes_after=after,seconds=time.monotonic()-began,
    native_or_compiler_code_changed=False,new_native_execution=False,qualification_complete=False,
    scope='TK-DEC-285 semantic design and portable role/subdivision/alias descriptions; no native owners, mapper, publication or protected context',
    resources={n:(resources/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']})
(out/'run.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:report[k] for k in ['passed','seconds','commands','resources']}))
