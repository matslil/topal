import gzip,json,os,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'linux-kernel/tools/process-memory'))
from archive_publication import closed_archive
from readback_process import digest as fact
from run_policy_failure import hashes
run=ROOT/'linux-kernel/.cache/x86_64/kernel-image-plan-models-stage-1'
base=ROOT/'linux-kernel/tools/user-memory/results/stage-3-calendar-placement'
assert fact(closed_archive(base))['sha256']=='4f1c2497b4eac3b7765ce4e7967083b225c3dfdbed46af266fd0dc337e1718bc'
b=json.loads((base/'report.json').read_text());q=json.loads((run/'run.json').read_text())
assert q['passed'] and q['source_hashes_before']==q['source_hashes_after']
assert hashes(q['source_hashes_before'])==q['source_hashes_before']
out=ROOT/'linux-kernel/tools/user-memory/results/stage-1-kernel-image-plan';out.mkdir(exist_ok=False)
manifest={}
def save(name,raw):
    p=(out/name).resolve();assert p.is_relative_to(out) and name not in manifest
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);manifest[name]=fact(raw)
def packed(name,raw):save(name+'.gz',gzip.compress(raw,mtime=0))
sources={};shared=0
for name,sha in q['source_hashes_before'].items():
    data=(ROOT/name).read_bytes();old=b['sources'].get(name)
    if old and old['sha256']==sha:
        p=(base if old['location']=='archive' else ROOT)/old['path'];raw=p.read_bytes()
        assert fact(raw)['sha256']==old['packed_sha256'] and gzip.decompress(raw)==data
        sources[name]=dict(old,location='repository',path=p.relative_to(ROOT).as_posix());shared+=1
    else:
        packed('sources/'+name,data)
        sources[name]=dict(location='archive',path='sources/'+name+'.gz',packed_sha256=manifest['sources/'+name+'.gz']['sha256'],**fact(data))
for p in sorted(run.iterdir()):
    assert p.is_file();packed('qualification/'+p.name,p.read_bytes())
packed('methods/driver.py',(ROOT/'linux-kernel/.cache/x86_64/run-kernel-image-plan-models.py').read_bytes())
packed('methods/collector.py',Path(__file__).read_bytes())
report=dict(passed=True,schema='topal.kernel-image-plan-model/1',sources=sources,shared_sources=shared,overlays=len(sources)-shared,
    dependency=dict(path=base.relative_to(ROOT).as_posix(),manifest=fact((base/'manifest.json').read_bytes())),
    qualification=q,qualification_complete=False,new_native_execution=False,
    scope='TK-DEC-285 design and supplied-description role/subdivision/alias models; no live ownership, hardware publication or protected-context qualification')
save('report.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
script=r'''import gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
a=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();root=a.parents[4]
assert work.is_relative_to(root/'linux-kernel');work.mkdir(parents=True,exist_ok=False)
report=json.loads((a/'report.json').read_text());manifest=json.loads((a/'manifest.json').read_text())
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
assert {p.relative_to(a).as_posix() for p in a.rglob('*') if p.is_file()}==set(manifest)|{'manifest.json'}
for name,row in manifest.items():
    p=(a/name).resolve();assert p.is_relative_to(a) and fact(p.read_bytes())==row
for name,row in report['sources'].items():
    base=a if row['location']=='archive' else root;p=(base/row['path']).resolve();assert p.is_relative_to(base)
    compressed=p.read_bytes();assert fact(compressed)['sha256']==row['packed_sha256']
    raw=gzip.decompress(compressed);assert fact(raw)=={k:row[k] for k in ['bytes','sha256']}
    target=(work/name).resolve();assert target.is_relative_to(work)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
sys.path.insert(0,str(work/'linux-kernel/tools/process-memory'))
from archive_publication import closed_archive
assert fact(closed_archive(root/report['dependency']['path']))==report['dependency']['manifest']
for label,count in [('user-memory',271),('process-memory',82)]:
    command=['rtk','proxy','python3','-B','-m','unittest','discover','-s','linux-kernel/tools/'+label,'-p','test_*.py']
    result=subprocess.run(command,cwd=work,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True)
    (work/(label+'.stdout.log')).write_bytes(result.stdout);(work/(label+'.stderr.log')).write_bytes(result.stderr)
    assert result.returncode==0 and ('Ran '+str(count)+' tests').encode() in result.stderr,result.stderr.decode()
(work/'replayed.json').write_text(json.dumps(dict(passed=True,models=353,new_native_execution=False,qualification_complete=False),indent=2)+'\n')
print('Frozen kernel-image planning sources and353models passed; no guest execution')
'''
save('methods/replay.py',script.encode())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');closed_archive(out)
frozen=ROOT/'linux-kernel/.cache/x86_64/kernel-image-plan-frozen'
result=subprocess.run(['rtk','proxy','python3','-B',str(out/'methods/replay.py'),str(out),str(frozen)],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True)
(frozen.parent/'kernel-image-plan-replay.stdout.log').write_bytes(result.stdout)
(frozen.parent/'kernel-image-plan-replay.stderr.log').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode()
assert hashes(q['source_hashes_before'])==q['source_hashes_before']
group=next(x.split(':',2)[2] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'))
resources=Path('/sys/fs/cgroup')/group.lstrip('/')
review=dict(passed=True,archive_manifest=fact((out/'manifest.json').read_bytes()),entries=len(manifest),sources=len(sources),shared_sources=shared,overlays=len(sources)-shared,
    frozen_replay=True,models=353,new_native_execution=False,qualification_complete=False,
    resources={n:(resources/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']})
with out.with_name(out.name+'-review.json').open('x') as stream:stream.write(json.dumps(review,indent=2,sort_keys=True)+'\n')
print(json.dumps(review))
