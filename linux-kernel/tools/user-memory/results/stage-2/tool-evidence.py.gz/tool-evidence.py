from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,sys
root=Path.cwd();out=root/'linux-kernel/tools/user-memory/results/stage-2'
r=json.loads((out/'qualification.json').read_text())
assert r['complete'] and r['passed']
sha=lambda b:hashlib.sha256(b).hexdigest()
record=dict(scope='Supplementary executable/version readback after the retained cohort; version text alone is not build provenance',tools=[])
guest=next(c for c in r['components'] if c['label'].startswith('current-') and 'kernel.elf' in c['files'])
info=guest['files']['target-llc.command.json']
packed=(out/info['file']).read_bytes();assert sha(packed)==info['sha256']
raw=gzip.decompress(packed);assert sha(raw)==info['uncompressed_sha256']
llvm=Path(json.loads(raw)['argv'][0]).parent
programs=[sys.executable,shutil.which('cargo'),shutil.which('rustc'),shutil.which('cc'),shutil.which('qemu-system-x86_64'),shutil.which('gdb'),str(llvm/'llc'),str(llvm/'opt'),str(llvm/'llvm-objdump'),str(llvm/'rust-lld')]
for program in programs:
    path=Path(program).resolve();digest=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):digest.update(block)
    p=subprocess.run([program,'--version'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    record['tools'].append(dict(invocation=program,path=str(path),sha256=digest.hexdigest(),version_exit=p.returncode,version=p.stdout.decode(errors='replace')))
manifest=json.loads((root/'linux-kernel/labs/qemu/x86_64/manifest.json').read_text())
firmware=Path(manifest['firmware']['path'])
record['firmware']=dict(path=str(firmware),sha256=sha(firmware.read_bytes()),manifest=manifest['firmware'])
(out/'supporting-tools.json').write_text(json.dumps(record,indent=2)+'\n')
print('SUPPLEMENTARY_TOOL_EVIDENCE',len(programs))
