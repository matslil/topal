from pathlib import Path
import collections, gzip, hashlib, json, re, struct

root=Path('/home/mats/git/topal')
out=root/'linux-kernel/tools/user-memory/results/stage-2'
r=json.loads((out/'qualification.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert r['complete'] and r['passed'] and not r['stage_complete']
assert r['schema']=='topal-owned-user-extent-functional/1'
def read(info):
    packed=(out/info['file']).read_bytes();assert sha(packed)==info['sha256']
    raw=gzip.decompress(packed)
    assert sha(raw)==info['uncompressed_sha256'] and len(raw)==info['bytes']
    return raw
for name,info in r['snapshots'].items():
    assert name!='topal-as-dsl.md'
    assert sha(read(info))==r['sources'][name]==sha((root/name).read_bytes()),name
for info in r['verification_inputs'].values():read(info)
read(r['runner'])
logs={c['label']:read(c['log']).decode() for c in r['commands']}
assert all(c['exit_code']==0 for c in r['commands'])
totals=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',logs['selected-functional-tests'])
assert all(tuple(map(int,t))[1:4]==(0,0,0) for t in totals)
assert sum(int(t[0]) for t in totals)==r['rust_tests'] and len(totals)==r['rust_targets']
assert len(totals)==1 and int(totals[0][4])==r['rust_filtered'] and r['rust_tests']==3
assert 'Ran 17 tests' in logs['model'] and logs['model'].rstrip().endswith('OK')
assert r['resources']['memory.swap.max']=='0'
events=dict(line.split() for line in r['resources']['memory.events'].splitlines())
assert all(int(events[n])==0 for n in ('oom','oom_kill','oom_group_kill'))

class Elf:
    def __init__(self,b):
        self.b=b;assert b[:6]==b'\x7fELF\x02\x01'
        h=struct.unpack_from('<16sHHIQQQIHHHHHH',b)
        assert h[2]==62
        self.entry=h[4]
        self.sections=[struct.unpack_from('<IIQQQQIIQQ',b,h[6]+i*h[11]) for i in range(h[12])]
        self.names=self.data(self.sections[h[13]])
        self.loads=[struct.unpack_from('<IIQQQQQQ',b,h[5]+i*h[9]) for i in range(h[10])]
        self.loads=[p for p in self.loads if p[0]==1]
        self.symbols=[]
        for s in self.sections:
            if s[1]!=2:continue
            names=self.data(self.sections[s[6]])
            for at in range(s[4],s[4]+s[5],s[9]):
                n,kind,other,index,value,size=struct.unpack_from('<IBBHQQ',b,at)
                self.symbols.append(dict(name=names[n:].split(b'\0',1)[0].decode(),index=index,value=value,size=size))
    def data(self,s):return self.b[s[4]:s[4]+s[5]]
    def name(self,s):return self.names[s[0]:].split(b'\0',1)[0].decode()
    def symbol(self,name):
        got=[s for s in self.symbols if s['name']==name and s['index']]
        assert len(got)==1,(name,got)
        return got[0]
    def relocations(self):
        for s in self.sections:
            if s[1]!=4:continue
            for at in range(s[4],s[4]+s[5],s[9]):
                offset,info,addend=struct.unpack_from('<QQq',self.b,at)
                yield s[7],offset,self.symbols[info>>32]['name'],info&0xffffffff,addend

def derive_owners(raw):
    e=Elf(raw);text=next(i for i,s in enumerate(e.sections) if e.name(s)=='.text.topal.systems.root')
    b=e.data(e.sections[text]);rel=[x for x in e.relocations() if x[0]==text]
    enter=next(x[1] for x in rel if x[2]=='topal_x86_systems_static_image_process_enter')
    active={};allocations=[];calls=0
    for _,at,name,kind,addend in rel:
        if at>=enter or name!='topal_x86_frame_gateway_v1':continue
        assert kind==4 and addend==-4 and b[at-1]==0xe8
        def imm(opcode):
            pos=b.rfind(opcode,max(0,at-52),at)
            assert pos>=0
            return struct.unpack_from('<Q',b,pos+2)[0]
        op=imm(b'\x48\xbf')
        if op==0:continue
        assert op in (1,2,3,4)
        a=imm(b'\x48\xbe');align=imm(b'\x48\xba')
        tokens=[x for x in rel if at-24<=x[1]<at and x[2]=='topal_x86_frame_root_tokens_v1' and b[x[1]-3:x[1]]==b'\x48\x8d\x0d']
        assert len(tokens)==1
        off=tokens[0][4]+4;assert off>=0 and off%24==0
        slot=off//24;calls+=1
        if op==1:
            assert slot not in active and a>0 and align>0
            active[slot]=[a,align,0];allocations.append(slot)
        elif op==2:
            assert active[slot][2]==0
            del active[slot]
        elif op==3:
            assert a in (0,1);active[slot][2]+=1 if a else -1
            assert active[slot][2]>=0
        else:assert slot in active
    hierarchy=[s for s in allocations if s in active and active[s]==[5,1,1]][-1]
    roles=[]
    for count,pins,chosen in [(5,1,hierarchy),(1,1,None),(503,1,None),(2,2,None)]:
        slots=[s for s,v in active.items() if v==[count,1,pins] and (chosen is None or s==chosen)]
        assert len(slots)==1,(count,slots,active)
        roles.append(dict(slot=slots[0],count=count,pins=pins))
    return dict(roles=roles,token_bytes=e.symbol('topal_x86_frame_root_tokens_v1')['size']),calls,len(allocations)

# Reconstruct observations from complete actual table and owner bytes. This
# reader does not import the native generator or trust its expected verdict.
MASK=((1<<52)-1)&-4096;KNOWN=MASK|(1<<63)|0x67
def owner_valid(owner,count,pins,n):
    t=owner['token'];rec=owner['record'];cells=owner['cells']
    assert t[0]==1 and 0<t[1] and 0<=t[2]<n
    assert rec[:2]==t[:2] and rec[3:5]==[count,1] and rec[5]>0 and rec[6:]==[pins,1]
    assert 0<=rec[2] and rec[2]+count<=n
    assert len(cells)==count*3 and cells[0::3]==[t[1]]*count and cells[1::3]==[rec[5]]*count
    assert cells[2::3]==list(range(cells[2],cells[2]+count))
    assert owner['physical']==cells[2]*4096 and cells[2]+count<=1<<18

def verdict(c,before,paging):
    a,l,w=c['start'],c['length'],c['write']
    assert 0<=a<1<<64 and 0<=l<1<<64 and w in (0,1)
    if a+l>=1<<64:return 1,0
    if l==0:return 0,0
    if a>=1<<47 or a+l>1<<47:return 1,0
    if paging['cr0']&0x80010001!=0x80010001 or paging['cr4']&31592448:return 4,0
    roles=before['roles'];tables=before['tables'];st=before['state'];n=before['allocator'][3]
    for o,(count,pins) in zip(roles,[(5,1),(1,1),(503,1),(2,2)]):
        owner_valid(o,count,pins,n);assert o['token'][1]<before['allocator'][2]
    expected_tables={roles[0]['physical']:4,roles[0]['physical']+4096:3,
        roles[0]['physical']+8192:2,roles[0]['physical']+12288:2,
        roles[0]['physical']+16384:1,roles[1]['physical']:1}
    assert {int(p):t['level'] for p,t in tables.items()}==expected_tables
    assert all(len(t['words'])==512 for t in tables.values())
    owned=roles.copy()
    if before['heap']:
        owner_valid(before['heap'],st[2],1,n)
        assert before['heap']['token'][1]<before['allocator'][2]
        owned.append(before['heap'])
    spans=[(o['physical'],o['physical']+o['record'][3]*4096) for o in owned]
    for i,(lo,hi) in enumerate(spans):assert all(hi<=a or b<=lo for a,b in spans[:i])
    checked=0
    for page in range(a&-4096,a+l,4096):
        table=roles[0]['physical']
        for level in (4,3,2,1):
            assert str(table) in tables and tables[str(table)]['level']==level
            word=tables[str(table)]['words'][(page>>((level-1)*9+12))&511]
            if not word&1:return 2,checked
            if word&~KNOWN:return 4,checked
            required=7 if w else 5
            if word&required!=required:return 3,checked
            physical=word&MASK
            if level>1:table=physical;continue
            if 0x400000<=page<0x5f7000:
                base=roles[2]['physical']+page-0x400000
                writable=page>=(0x5ed000 if before['phase']>=9 else 0x5e5000)
            elif 0x7fe000<=page<0x800000:
                base=roles[3]['physical']+page-0x7fe000;writable=True
            else:
                assert before['heap'] and 0x5f7000<=page<0x5f7000+st[2]*4096
                base=st[3]+page-0x5f7000;writable=True
            assert physical==base and str(physical) not in tables
            if w and not writable:return 3,checked
        checked+=1
    return 0,checked

current=[];archive_files=0;archive_bytes=0;development=[]
for item in r['components']:
    files={name:read(info) for name,info in item['files'].items()}
    archive_files+=len(files);archive_bytes+=sum(map(len,files.values()))
    if not item['label'].startswith('current-'):
        development.append(item['label']);continue
    current.append((item,files))
    for name,data in files.items():
        if name.endswith('.command.json') and not name.endswith('qemu.command.json'):
            assert json.loads(data)['exit_code']==0,name
    if 'client.stdout.log' in files:
        c=json.loads(files['client.stdout.log']);assert c['passed'] and c['permission_cases']==8192 and c['calls']==8243
        assert files['fixture.c']==read(r['snapshots']['linux-kernel/labs/qemu/x86_64/user_extent_component.c'])
        assert json.loads(files['component-cost.json'])=={'topal_x86_owned_user_extent_v1':72}
    if 'kernel.elf' not in files:continue
    guest=files;guest_item=item
    owners,calls,root_allocated=derive_owners(files['root.o']);assert owners==json.loads(files['user-owners.json'])
    elf=Elf(files['kernel.elf']);bz=files['bzImage']
    assert bz[0x202:0x206]==b'HdrS' and struct.unpack_from('<H',bz,0x206)[0]==0x20f
    setup=(bz[0x1f1]+1)*512
    for p in elf.loads:
        assert p[3]==p[4] and p[5]<=p[6]
        raw=elf.b[p[2]:p[2]+p[5]];at=setup+p[3]-0x100000
        assert bz[at:at+len(raw)]==raw
        assert not any(bz[at+len(raw):at+p[6]])
    assert elf.entry==elf.symbol('_topal_kernel_entry')['value']
    assert elf.symbol('topal_x86_kernel_reservation_end_v1')['value']==max(p[3]+p[6] for p in elf.loads)
    cpio=files['initramfs.cpio'];cursor=0;members={}
    while True:
        assert cpio[cursor:cursor+6]==b'070701'
        fields=[int(cpio[cursor+6+i*8:cursor+14+i*8],16) for i in range(13)]
        size,namesize=fields[6],fields[11]
        at=cursor+110;name=cpio[at:at+namesize]
        assert name.endswith(b'\0') and b'\0' not in name[:-1]
        at=(at+namesize+3)&-4;raw=cpio[at:at+size]
        assert len(raw)==size
        cursor=(at+size+3)&-4
        if name==b'TRAILER!!!\0':assert size==0;break
        assert name not in members;members[name]=raw
    assert set(members)=={b'init\0',b'static-user.elf\0'}
    assert members[b'init\0']==files['baseline/initial-user.elf']
    assert members[b'static-user.elf\0']==files['baseline/static-user.elf']==files['static-elf-abi-fixture.elf']
    assert not any(cpio[cursor:])
    inspection=json.loads(files['frame-inspection.json']);paths=inspection['paths'];frames=inspection['frames_with_inline_push']
    for name,n in paths.items():
        if name in ('topal_tail_owner_invoke_v1','topal_x86_frame_gateway_abort_v1'):continue
        assert n==frames[name]+8+max((paths[c] for c in inspection['calls'][name]),default=0),name
    assert paths['topal_frame_kernel_dispatch_v1']==2096
    assert inspection['syscall_adapter']['combined_stack_bound_bytes']==2176
    assert inspection['user_extent_probe']['complete_stack_bytes']==2272<=4096
    observation=json.loads(files['user-extents/observations.json'])
    assert observation['passed'] and len(observation['memory'])==80
    assert observation['probe_counts']==[44,324,24,16]
    assert observation['native_extent_trace_samples']==1
    assert observation['syscall_caller_cfi_registers_checked']
    assert observation['wp_transitions']==[dict(before=0x80000011,after=0x80010011)]
    assert observation['paging']['cr0']&0x10000
    assert 'EFER=0000000000000d01' in observation['paging']['registers']
    status=collections.Counter()
    for c in observation['user_extents']:
        expected,pages=verdict(c,c['before'],observation['paging'])
        assert (c['result'],c['expected'],c['checked_pages'])==(expected,expected,pages)
        assert c['sp']&15==8 and c['epoch'][0]>0 and c['epoch'][1]==12
        assert c['before']['epoch']==c['epoch']
        status[c['result']]+=1
    assert status=={0:208,1:44,2:28,3:44}
    negatives={name.split('/')[0].removeprefix('user-extent-fault-'):json.loads(data)
               for name,data in files.items() if name.startswith('user-extent-fault-') and name.endswith('/observations.json')}
    assert len(negatives)==0
    for mode,o in negatives.items():
        assert o['passed'] and o['component_boundary'] and not o['completed_guest']
        assert o['fault']['mode']==mode and o['fault']['injected']!=o['fault']['old']
        expected=('normal-rejection' if mode.startswith(('user-','write-','absent-')) or mode in ('huge','leaf-format') else
                  'pre-entry-refusal' if mode in ('return-site','busy','epoch-zero','address-space','context-self') else 'fatal-retirement')
        assert o['disposition']==expected
    # Exact generated body and checked offsets are retained with the real ELF.
    target=files['target.ll'].decode()
    template=read(r['snapshots']['src/topal-compiler/src/runtime/kernel_user_extent_target.ll']).decode()
    for name,role in zip(['HIERARCHY_OFFSET','LOW_OFFSET','IMAGE_OFFSET','STACK_OFFSET'],owners['roles']):
        template=template.replace('{{'+name+'}}',str(role['slot']*24))
    template=template.replace('{{ROOT_TOKEN_SLOTS}}',str(owners['token_bytes']//24))
    assert target.endswith(template)
    assert 'u.heap_owner' in inspection['calls']['topal_x86_user_extent_backing_v1']
    assert set(inspection['calls']['u.heap_owner'])=={'u.owner','t.word','u.require'}
    guard=template.split('define internal i64 @u.heap_owner',1)[1].split('define i64 @topal_x86_user_extent_backing_v1',1)[0]
    assert f'%more = icmp ult i64 %i,{owners["token_bytes"]//24}' in guard
    assert '%distinct = icmp ne i64 %identity,%root_identity' in guard
    assert 'call void @u.require(i1 %distinct)' in guard
    assert '%root_identity = call i64 @t.word(ptr %token,i64 1)' in guard
    assert 'br i1 %more,label %slot,label %done' in guard
    assert 'ret i64 %base' in guard
    for c in observation['user_extents']:
        if c['before']['heap']:assert c['before']['heap']['token'][1]>root_allocated
    walker=read(r['snapshots']['src/topal-compiler/src/runtime/kernel_user_extent.ll'])
    assert files['extent.ll'].endswith(walker)
    for name in ['topal_x86_owned_user_extent_v1','topal_frame_kernel_dispatch_v1','topal_x86_user_extent_call_v1','topal_x86_user_extent_probe_v1']:
        sym=elf.symbol(name);assert sym['size']>0
        assert name in observation['native_extent_trace']

assert len(current)==2 and len(development)==0
failed=out.with_name('stage-2-initial-interrupt-failure')
fr=json.loads((failed/'qualification.json').read_text())
assert not fr['complete'] and not fr['passed']
changed=sorted(n for n in r['sources'] if r['sources'][n]!=fr['sources'][n])
assert changed==['src/topal-compiler/src/runtime/kernel_user_extent_target.ll','src/topal-compiler/src/systems_user_extent.rs','src/topal-compiler/src/systems_user_extent_tests.rs'],changed
assert fr['commands'][-1]['label']=='workspace-tests' and fr['commands'][-1]['exit_code']==101
def failed_read(info):
    packed=(failed/info['file']).read_bytes();assert sha(packed)==info['sha256']
    raw=gzip.decompress(packed)
    assert sha(raw)==info['uncompressed_sha256'] and len(raw)==info['bytes']
    return raw
for name,info in fr['snapshots'].items():assert sha(failed_read(info))==fr['sources'][name]
for info in fr['verification_inputs'].values():failed_read(info)
failed_read(fr['runner'])
for c in fr['commands']:failed_read(c['log'])
assert '370 passed; 1 failed;' in failed_read(fr['commands'][-1]['log']).decode()
failure_evidence=json.loads((failed/'failure-evidence.json').read_text())
assert not failure_evidence['passed'] and len(failure_evidence['components'])==5
repeats=0
for component in failure_evidence['components']:
    for name,info in component['files'].items():
        raw=failed_read(info)
        if name.endswith('/retry.log'):
            assert raw.rstrip().endswith(b'FRAME_TARGET_PASS interrupts');repeats+=1
assert repeats==4
result=dict(schema='topal-owned-user-extent-functional-readback/1',passed=True,stage_complete=False,changed_since_prior_cohort=changed,
    source_inputs=len(r['sources']),rust_tests=r['rust_tests'],rust_targets=r['rust_targets'],model_tests=17,
    prior_guarded_native_calls=8243,prior_permission_cases=8192,native_guest_calls=324,actual_mm_operations=80,
    negative_component_boundaries=0,prior_negative_component_boundaries=21,independently_derived_root_gateway_calls=calls,
    actual_owners=owners,native_results=dict(status),complete_probe_path_bytes=2272,
    wp_transitions=observation['wp_transitions'],archived_files=archive_files,archived_uncompressed_bytes=archive_bytes,
    failed_workspace_cohorts=1,exact_image_interrupt_repeats=4,
    development_scope='Prior failed four-thread cohort and four isolated repeats are retained. Three source inputs changed afterward; no new deliberate guest-state controls were executed. The stopped serial cohort remains separate.',
    scope='Selected ordinary-functional checkpoint: byte/ELF/boot-resource/root-instruction/flat permission and static heap-owner-domain readback by the same agent. Not full workspace execution, completed Stage2, independent human review, all-caller production or full Linux acceptance.')
(out/'independent-readback.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
