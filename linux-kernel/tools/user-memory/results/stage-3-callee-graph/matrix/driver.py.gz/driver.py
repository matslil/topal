"""Source-frozen saved-code callee inspection and surrounding qualification."""
import ast
from copy import deepcopy
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import hashes,watched,VALIDATIONS
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
source=(cache/'run-caller-retirement-stage.py').read_text()
node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='compiler_reference')
reference_function=ast.get_source_segment(source,node)
exec(compile(reference_function,'<guarded-compiler-reference>','exec'))
output=cache/'callee-graph-stage';output.mkdir(exist_ok=False)
build=cache/'process-mm-interface-regression-2549665-1794594222197528254'
prior=root/'linux-kernel/tools/process-memory/results/stage-3-interface-callers'
prior_review=json.loads((prior.parent/(prior.name+'-review.json')).read_bytes())
prior_report=json.loads((prior/'report.json').read_bytes())
assert prior_review['passed'] and prior_review['archive_manifest']==fact((prior/'manifest.json').read_bytes())
assert prior_review['archive_manifest']['sha256']=='0d5697ba20e1ceddf5c12187daaa82b21f34872e1e04325edc5df020224cf7ea'
artifacts={}
for name in ['kernel.elf','process-access-inventory.json','callback-bindings.json']:
    raw=(build/name).read_bytes();assert fact(raw)==prior_report['cohorts']['poll']['files'][name]
    assert raw==gzip.decompress((prior/'native/poll'/(name+'.gz')).read_bytes())
    artifacts[name]=fact(raw)
paths=watched();before=hashes(paths);reference=compiler_reference(paths)
script=Path(__file__).read_bytes();(output/'driver.py').write_bytes(script)
(output/'compiler-reference-function.py').write_text(reference_function+'\n')
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
def resources():return {name:(directory/name).read_text().strip() for name in
    ['memory.max','memory.swap.max','memory.peak','memory.events']}
report=dict(passed=False,compiler_reference=reference,source_hashes_before=before,artifacts=artifacts,
    prior_archive_manifest=prior_review['archive_manifest'],commands={},validation={},controls=[],
    group=group,resource_samples=[resources()],
    scope='Fresh two-decoder saved-code graph from the unchanged earlier kernel plus six fresh surrounding checks. No VM/compiler rebuild/full compiler rerun. Conditional declared-root/callback/table/call-return graph only; full entry/lifecycle/ownership/runtime/publication/Linux qualification remains open.')
environment=dict(os.environ,RUST_MIN_STACK='16777216',PYTHONDONTWRITEBYTECODE='1',RUST_TEST_THREADS='2',
    TMPDIR=str(cache/'interface-callers-validation-tmp'))
for name in list(environment):
    if name.startswith('TOPAL_TEST_'):environment.pop(name)
log=(output/'driver.log').open('w',buffering=1);start=time.monotonic();failure=0
def progress():
    report['resource_samples'].append(resources())
    (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
def command(label,arguments):
    argv=['rtk','proxy',*map(str,arguments)];began=time.monotonic()
    with (output/(label+'.stdout.log')).open('w') as out,(output/(label+'.stderr.log')).open('w') as err:
        result=subprocess.run(argv,cwd=root,env=environment,stdout=out,stderr=err)
    report['commands'][label]=dict(argv=argv,exit_code=result.returncode,elapsed_seconds=time.monotonic()-began)
    (output/(label+'.command.json')).write_text(json.dumps(report['commands'][label],indent=2)+'\n')
    print(label,result.returncode,file=log,flush=True);progress()
    if result.returncode:raise RuntimeError('command failed: '+label)
    return (output/(label+'.stdout.log')).read_bytes()
progress()
try:
    llvm=json.loads((build/'process-access-disassembly.command.json').read_bytes())['argv'][0]
    command('llvm-version',[llvm,'--version']);command('gnu-version',['objdump','--version'])
    command('llvm',[llvm,'-d','-z','--x86-asm-syntax=intel',build/'kernel.elf'])
    command('gnu',['objdump','-d','-z','-w','-Mintel','--insn-width=16',build/'kernel.elf'])
    recovery_args=[];recovered=[]
    for address in [45864290,45841237]:
        first=str(address)+'-llvm';second=str(address)+'-gnu'
        command(first,[llvm,'-d','-z','--x86-asm-syntax=intel','--start-address='+str(address),
            '--stop-address='+str(address+128),build/'kernel.elf'])
        command(second,['objdump','-d','-z','-w','-Mintel','--insn-width=16','--start-address='+str(address),
            '--stop-address='+str(address+128),build/'kernel.elf'])
        recovery_args+=['--recovery',str(address),str(output/(first+'.stdout.log')),str(output/(second+'.stdout.log'))]
        recovered.append((address,(output/(first+'.stdout.log')).read_bytes(),(output/(second+'.stdout.log')).read_bytes()))
    command('inventory',['python3','-B','linux-kernel/tools/user-memory/inspect_callee_graph.py',build,
        output/'llvm.stdout.log',output/'gnu.stdout.log',output/'inventory.json',*recovery_args])
    value=json.loads((output/'inventory.json').read_bytes())
    assert value['passed'] and value['selected_edge_set_closed'] and not value['frontiers']
    assert value['qualification_complete'] is False and len(value['assumptions'])==4
    assert value['reached_instructions']==71457 and value['reached_bytes']==386870
    assert len(value['roots'])==14 and len(value['callbacks'])==len(value['guarded_tables'])==6
    assert sum(len(row['targets']) for row in value['guarded_tables'])==98
    assert value['process_helpers']=={'88215':False,'94687':True}
    sys.path.insert(0,str(root/'linux-kernel/tools/user-memory'))
    from inspect_call_inventory import Elf
    from inspect_callee_graph import callbacks,entries
    from inventory_paging_controls import decode
    elf=Elf(build/'kernel.elf');graph=json.loads((build/'process-access-inventory.json').read_bytes())
    binding=json.loads((build/'callback-bindings.json').read_bytes());process,body=elf.function(graph['function'])
    section=elf.sections[process['section']];code=elf.section_bytes(process['section'])
    first=decode((output/'llvm.stdout.log').read_text(),section[3],code)
    second=decode((output/'gnu.stdout.log').read_text(),section[3],code)
    def reject(label,change):
        altered=deepcopy(binding);change(altered)
        try:callbacks(elf,altered,graph,process,body,first,second)
        except (ValueError,AssertionError,KeyError,OverflowError) as error:
            report['controls'].append(dict(name=label,rejected=True,reason=str(error)))
        else:raise AssertionError('accepted callback control '+label)
    reject('wrong-kernel',lambda r:r.update(kernel_sha256='0'*64))
    reject('wrong-root-call',lambda r:r.update(root_call_offset=r['root_call_offset']+1))
    reject('missing-callback-slot',lambda r:r['callbacks'].pop())
    reject('missing-process-call-site',lambda r:r['sites'].pop())
    reject('wrong-root-argument',lambda r:r['callbacks'][0].update(argument=r['callbacks'][0]['argument']+1))
    reject('wrong-root-lea',lambda r:r['callbacks'][0].update(root_lea_offset=r['callbacks'][0]['root_lea_offset']+1))
    reject('wrong-registration-load',lambda r:r['callbacks'][0].update(registration_load_offset=r['callbacks'][0]['registration_load_offset']+1))
    reject('wrong-registration-slot-store',lambda r:r['callbacks'][0].update(registration_store_offset=r['callbacks'][0]['registration_store_offset']+1))
    reject('wrong-callback-slot',lambda r:r['sites'][0].update(gs_slot=r['sites'][0]['gs_slot']+8))
    reject('wrong-target',lambda r:r['callbacks'][0].update(target=r['callbacks'][0]['target']+1))
    wrong=deepcopy(graph);wrong['roots'].append(dict(offset=88215,source='invented entry'))
    try:entries(elf,wrong,process,body)
    except ValueError as error:report['controls'].append(dict(name='invented-process-root',rejected=True,reason=str(error)))
    else:raise AssertionError('accepted invented root')
    assert len(report['controls'])==11
    for name,arguments in VALIDATIONS.items():
        if name=='compiler-units':continue
        report['validation'][name]=dict(status='running');progress()
        command(name,arguments)
        report['validation'][name]=dict(report['commands'][name],status='complete');progress()
except BaseException:
    report['failure']=traceback.format_exc();print(report['failure'],file=log,flush=True);failure=1
finally:
    after=hashes(paths);same=before==after and paths==watched();same_driver=script==Path(__file__).read_bytes()
    report.update(passed=not failure and len(report['validation'])==6 and same and same_driver,
        exit_code=failure,source_hashes_after=after,source_changes_during_run=not same,
        driver_unchanged=same_driver,elapsed_seconds=time.monotonic()-start,resources=resources())
    (output/'run.json').write_text(json.dumps(report,indent=2)+'\n');log.close()
print(json.dumps(dict(passed=report['passed'],elapsed_seconds=report['elapsed_seconds'])))
raise SystemExit(failure or int(not report['passed']))
