"""Close the saved-code archive and replay final and historical readers."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64';matrix=cache/'callee-graph-stage'
archive=root/'linux-kernel/tools/user-memory/results/stage-3-callee-graph'
replay=cache/'callee-graph-frozen-replay'
build=cache/'process-mm-interface-regression-2549665-1794594222197528254'
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
began=time.monotonic();run=json.loads((matrix/'run.json').read_bytes())
assert run['passed'] and run['exit_code']==0 and run['driver_unchanged']
assert run['source_hashes_before']==run['source_hashes_after'] and not run['source_changes_during_run']
assert len(run['validation'])==6 and all(row['status']=='complete' and row['exit_code']==0 for row in run['validation'].values())
inventory=json.loads((matrix/'inventory.json').read_bytes())
assert inventory['selected_edge_set_closed'] and not inventory['qualification_complete']
archive.mkdir(exist_ok=False);manifest={}
def save(name,raw):
    target=archive/name;assert target.resolve().is_relative_to(archive)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);manifest[name]=fact(raw)
def packed(name,raw):save(name+'.gz',gzip.compress(raw,mtime=0))
report=dict(passed=True,schema='topal-saved-callee-graph-archive/1',sources={},artifacts={},
    inventory=fact((matrix/'inventory.json').read_bytes()),compiler_reference=run['compiler_reference'],
    scope='Fresh saved-code conditional graph and archived source/model replay, not a new VM, compiler rebuild, full kernel entry/CFI/lifetime proof or public activation.')
for name,sha in run['source_hashes_before'].items():
    raw=(root/name).read_bytes();assert fact(raw)['sha256']==sha
    report['sources'][name]=fact(raw);packed('inputs/'+name,raw)
for name,expected in run['artifacts'].items():
    raw=(build/name).read_bytes();assert fact(raw)==expected
    report['artifacts'][name]=fact(raw);packed('native/'+name,raw)
for path in matrix.rglob('*'):
    if path.is_file():packed('matrix/'+path.relative_to(matrix).as_posix(),path.read_bytes())
history=cache/'callee-graph-recovery'
for path in history.rglob('*'):
    if path.is_file():packed('history/recovery/'+path.relative_to(history).as_posix(),path.read_bytes())
for label in ['callee-graph-pilot','callee-graph-pilot-2']:
    packed('history/'+label+'/failed-pilot.py',(cache/label/'failed-pilot.py').read_bytes())
    for stem in ['llvm.command.json','llvm.stderr.log']:
        packed('history/'+label+'/'+stem,(cache/label/stem).read_bytes())
packed('history/callee-graph-pilot-3/pilot.py',(cache/'probe-callee-graph.py').read_bytes())
packed('history/callee-graph-pilot-3/report.json',(cache/'callee-graph-pilot-3/report.json').read_bytes())
save('history/notices.json',(json.dumps(dict(
    initial_pilot=dict(exit_code=1,notice='IndexError: list index out of range',
        source='Tool-returned notice; complete initial stderr was not saved as a file',
        context='inventory_process_accesses.py decoded_rows indexed an empty word list after an isolated prefix'),
    second_pilot=dict(exit_code=1,notice='AssertionError',
        source='Tool-returned branch-reader assertion; no complete stderr or failing row was saved',
        context='The later pilot retains a REX-prefixed table jump as an unsupported transfer'),
    recovery=dict(exit_code=1,notice='ValueError: decoder instruction boundary/bytes differ',
        stderr='history/recovery/1.stderr.log.gz',
        context='Complete raw stderr, commands, recovery windows and pre-fix reader sources retained; final reader leaves the decoder stop-tail unapplied'),
    resource_scope='Exact resource counters for these earlier method failures were not retained. No zero-event claim applies to them.'),indent=2)+'\n').encode())
for stage in ['stage-3-interface-callers','stage-3-prelude-stat']:
    previous=root/'linux-kernel/tools/process-memory/results'/stage
    for name in ['manifest.json','report.json']:
        save('references/'+stage+'/'+name,(previous/name).read_bytes())
    save('references/'+stage+'/review.json',(previous.parent/(stage+'-review.json')).read_bytes())
    if stage=='stage-3-prelude-stat':
        for name in ['compiler-units.stdout.log','compiler-units.stderr.log']:
            save('references/'+stage+'/'+name+'.gz',(previous/'matrix/validation'/(name+'.gz')).read_bytes())
packed('collection/collector.py',Path(__file__).read_bytes())
save('report.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
replay.mkdir(exist_ok=False)
def restore(target,name,expected=None):
    assert target.resolve().is_relative_to(replay)
    raw=gzip.decompress((archive/(name+'.gz')).read_bytes())
    if expected is not None:assert fact(raw)==expected
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
for label in ['qualified','historical']:
    task=replay/label
    for name,expected in report['sources'].items():restore(task/name,'inputs/'+name,expected)
    if label=='historical':
        for name in ['callee_control.py','inspect_callee_graph.py']:
            path='linux-kernel/tools/user-memory/'+name
            restore(task/path,'history/recovery/failure-inputs/'+path)
    native=task/'linux-kernel/.cache/x86_64/native'
    for name,expected in report['artifacts'].items():restore(native/name,'native/'+name,expected)
    for name in ['llvm.stdout.log','gnu.stdout.log']:
        restore(task/name,'matrix/'+name)
    command=['rtk','proxy','python3','-B','linux-kernel/tools/user-memory/inspect_callee_graph.py',
        str(native),str(task/'llvm.stdout.log'),str(task/'gnu.stdout.log'),str(task/'inventory.json')]
    for address in [45864290,45841237]:
        names=[str(address)+'-'+suffix+'.stdout.log' for suffix in ['llvm','gnu']]
        for name in names:restore(task/name,'matrix/'+name)
        command+=['--recovery',str(address),str(task/names[0]),str(task/names[1])]
    result=subprocess.run(command,cwd=task,capture_output=True,text=True)
    (replay/(label+'.stdout.log')).write_text(result.stdout);(replay/(label+'.stderr.log')).write_text(result.stderr)
    if label=='qualified':
        assert result.returncode==0,result.stderr[-5000:]
        assert json.loads((task/'inventory.json').read_bytes())==inventory
        for name,count in [('user-memory',219),('process-memory',82)]:
            tests=subprocess.run(['rtk','proxy','python3','-B','-m','unittest','discover',
                '-s','linux-kernel/tools/'+name,'-p','test_*.py'],cwd=task,capture_output=True,text=True)
            (replay/(name+'.stdout.log')).write_text(tests.stdout);(replay/(name+'.stderr.log')).write_text(tests.stderr)
            assert tests.returncode==0 and f'Ran {count} tests in ' in tests.stderr and tests.stderr.rstrip().endswith('OK'),tests.stderr
    else:
        assert result.returncode!=0 and 'ValueError: decoder instruction boundary/bytes differ' in result.stderr
    print('frozen reader',label,'expected outcome verified',flush=True)
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
record=dict(passed=True,archive_manifest=fact((archive/'manifest.json').read_bytes()),
    exact_inventory_equal=True,user_models=219,process_models=82,original_recovery_failure_reproduced=True,
    elapsed_seconds=time.monotonic()-began,resources=resources,
    scope='Frozen Python-only graph/model replay and original recovery-reader refusal from archived sources/bytes. No new decoder process, compiler or VM; earlier pilot notices retain narrower historical evidence.')
(replay/'replayed.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(passed=True,entries=len(manifest),sources=len(report['sources']),elapsed_seconds=record['elapsed_seconds'])),flush=True)
