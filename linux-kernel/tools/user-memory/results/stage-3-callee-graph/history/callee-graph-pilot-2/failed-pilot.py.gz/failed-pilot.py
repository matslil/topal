"""Pilot linked direct/callback traversal; all residual boundaries stay open."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path.cwd();sys.path.insert(0,str(root/'linux-kernel/tools/user-memory'))
from inspect_call_inventory import Elf
from inventory_process_accesses import decoded_rows,branch
from inventory_paging_controls import decode,prefix_fragment
build=root/'linux-kernel/.cache/x86_64/process-mm-interface-regression-2549665-1794594222197528254'
out=root/'linux-kernel/.cache/x86_64/callee-graph-pilot-2';out.mkdir(exist_ok=False)
elf=Elf(build/'kernel.elf');graph=json.loads((build/'process-access-inventory.json').read_bytes())
bindings=json.loads((build/'callback-bindings.json').read_bytes())
section_index,section=next((i,s) for i,s in enumerate(elf.sections) if s[2]&4 and s[5])
start=section[3];body=elf.section_bytes(section_index)
tool=json.loads((build/'process-access-disassembly.command.json').read_bytes())['argv'][0]
argv=['rtk','proxy','objdump','-d','-z','-w','-Mintel','--insn-width=16',str(build/'kernel.elf')]
result=subprocess.run(argv,capture_output=True);assert result.returncode==0,result.stderr
(out/'llvm.stdout.log').write_bytes(result.stdout);(out/'llvm.stderr.log').write_bytes(result.stderr)
(out/'llvm.command.json').write_text(json.dumps(dict(argv=argv,exit_code=result.returncode),indent=2)+'\n')
decoded=decode(result.stdout.decode(),start,body);rows={}
for address,row in decoded.items():
    text=row['instruction'];words=text.split()
    while words and words[0] in ['rep','repne','repe','repnz','repz','lock']:words.pop(0)
    mnemonic=words[0] if words else '<prefix>'
    if mnemonic.startswith(('call','jmp','j','loop')):
        import re
        text=re.sub(r'^(\w+\s+)([0-9a-f]+)(?=\s|$)',r'\g<1>0x\2',' '.join(words))
    rows[address-start]=dict(offset=address-start,size=row['size'],bytes=row['bytes'],instruction=text,mnemonic=mnemonic)
process=graph['function_address'];roots=[process+r['offset'] for r in graph['roots']]
targets={process+r['offset']:elf.symbols[r['native_export']]['value'] for r in bindings['sites']}
for r in graph['instructions']:
    at=process+r['offset']-start;rows[at]=dict(r,offset=at)
seen={};occupied={};pending=roots[:];unknown=[];indirect=[];outside=[];edges=[]
terminals=Counter();recovered=[];functions={}
while pending:
    address=pending.pop();at=address-start
    if address in seen:continue
    if not 0<=at<len(body):outside.append(address);continue
    if at not in rows or '<unknown>' in rows[at]['instruction']:
        cmd=['rtk','proxy',tool,'-d','--x86-asm-syntax=intel','--start-address='+str(address),
            '--stop-address='+str(min(address+128,start+len(body))),str(build/'kernel.elf')]
        result=subprocess.run(cmd,capture_output=True);assert result.returncode==0
        recovered_rows=decoded_rows(result.stdout.decode(),dict(value=start),body)
        label='recovery-'+str(len(recovered));(out/(label+'.log')).write_bytes(result.stdout)
        recovered.append(dict(address=address,label=label))
        rows.update(recovered_rows)
    row=rows.get(at)
    if row is None or '<unknown>' in row['instruction'] or row['mnemonic'] in ['.byte','.word','<prefix>'] or '(bad)' in row['instruction']:
        unknown.append(dict(address=address,row=row));continue
    for byte in range(address,address+row['size']):
        assert byte not in occupied,('overlap',address,occupied.get(byte))
        occupied[byte]=address
    seen[address]=row;name=row['mnemonic']
    if name in ['ret','retq','retf','iret','iretq','sysret','sysretq','hlt','ud2','int','int3','syscall','sysenter','sysexit']:
        terminals[name]+=1;continue
    if name.startswith('j') or name.startswith('loop') or name=='call':
        target=branch(row)
        if target is None:
            if address in targets:
                destination=targets[address];pending.append(destination)
                edges.append(dict(source=address,target=destination,kind='retained-callback-registration-assumption'))
            else:indirect.append(dict(address=address,instruction=row['instruction']))
        else:
            offset,destination=target;assert destination==start+offset
            edges.append(dict(source=address,target=destination,kind='direct-transfer'));pending.append(destination)
        if name=='jmp':continue
    following=address+row['size'];pending.append(following)
    edges.append(dict(source=address,target=following,kind='call-return-assumption' if name=='call' else 'fallthrough'))
for symbol in elf.defined_symbols:
    if symbol['info']&15==2 and symbol['section']==section_index:
        addresses=[at for at in seen if symbol['value']<=at<symbol['value']+symbol['size']]
        if addresses:functions.setdefault(symbol['name'],[]).append(dict(address=symbol['value'],bytes=symbol['size'],reached=len(addresses)))
report=dict(passed=not unknown and not outside,kernel_sha256=hashlib.sha256(elf.data).hexdigest(),
    roots=roots,reached_instructions=len(seen),reached_bytes=len(occupied),functions=functions,
    indirect=indirect,unknown=unknown,outside=outside,recovered=recovered,terminals=dict(terminals),
    selected_missing_reached={str(offset):process+offset in seen for offset in [88215,94687]},
    callback_edges=len(targets),edges=edges,
    scope='Pilot direct/callback overapproximation only, with registration and call-return assumptions, unresolved nested indirect/entry/exception/effect/lifetime boundaries; not unreachability or ownership qualification.')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['edges','functions']},indent=2))
print('FUNCTION_NAMES',list(functions))
