"""Recover actual declared starts, preserving every decoder command and round."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
build=cache/'process-mm-interface-regression-2549665-1794594222197528254'
work=cache/'callee-graph-recovery';work.mkdir(exist_ok=False)
llvm=Path(json.loads((build/'process-access-disassembly.command.json').read_bytes())['argv'][0])
full_llvm=cache/'callee-graph-pilot/llvm.stdout.log';full_gnu=cache/'callee-graph-pilot-3/llvm.stdout.log'
sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
    ['linux-kernel/tools/user-memory/callee_control.py','linux-kernel/tools/user-memory/inspect_callee_graph.py']}
recoveries=[];known=set()
for number in range(16):
    output=work/(str(number)+'.json')
    argv=['rtk','proxy','python3','-B','linux-kernel/tools/user-memory/inspect_callee_graph.py',
        str(build),str(full_llvm),str(full_gnu),str(output)]
    for address,first,second in recoveries:argv+=['--recovery',str(address),str(first),str(second)]
    result=subprocess.run(argv,capture_output=True)
    (work/(str(number)+'.stdout.log')).write_bytes(result.stdout)
    (work/(str(number)+'.stderr.log')).write_bytes(result.stderr)
    (work/(str(number)+'.command.json')).write_text(json.dumps(dict(argv=argv,exit_code=result.returncode),indent=2)+'\n')
    assert result.returncode==0,result.stderr.decode()[-5000:]
    report=json.loads(output.read_bytes());print(result.stdout.decode().strip(),flush=True)
    if not report['frontiers']:break
    missing=[row['address'] for row in report['frontiers'] if row['reason']=='missing decoder start' and row['address'] not in known]
    if not missing:break
    for address in missing:
        known.add(address);paths=[]
        for label,tool in [('llvm',llvm),('gnu','objdump')]:
            arguments=['-d','-z','--x86-asm-syntax=intel'] if label=='llvm' else ['-d','-z','-w','-Mintel','--insn-width=16']
            command=['rtk','proxy',str(tool),*arguments,'--start-address='+str(address),
                '--stop-address='+str(address+128),str(build/'kernel.elf')]
            result=subprocess.run(command,capture_output=True);stem=str(address)+'-'+label
            path=work/(stem+'.stdout.log');path.write_bytes(result.stdout);paths.append(path)
            (work/(stem+'.stderr.log')).write_bytes(result.stderr)
            (work/(stem+'.command.json')).write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
            assert result.returncode==0,result.stderr
        recoveries.append((address,*paths))
else:raise AssertionError('unexpected decoder recovery growth')
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for name,sha in sources.items())
record=dict(passed=True,sources=sources,final_inventory=str(output.relative_to(root)),
    selected_edge_set_closed=report['selected_edge_set_closed'],frontiers=report['frontiers'],
    recoveries=[dict(address=address,llvm=str(first.relative_to(root)),gnu=str(second.relative_to(root)))
        for address,first,second in recoveries],
    scope='Saved first-party code and exact decoder recovery commands only; no VM, code activation, runtime invariants or complete entry/ownership qualification.')
(work/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
