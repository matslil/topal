"""Collect a composable archive, explicitly retaining the two pinned dependencies."""
import gzip
import hashlib
import json
from pathlib import Path
import time

root=Path.cwd();source=root/'linux-kernel/.cache/x86_64/boot-entry-stage-2'
output=root/'linux-kernel/tools/user-memory/results/stage-3-boot-entries'
output.mkdir(exist_ok=False)
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def put(name,raw):
    path=output/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(gzip.compress(raw,mtime=0) if name.endswith('.gz') else raw)
run=json.loads((source/'run.json').read_bytes());assert run['passed']
assert run['source_hashes_before']==run['source_hashes_after']
for name,expected in run['source_hashes_before'].items():
    raw=(root/name).read_bytes();assert fact(raw)==expected
    put('sources/'+name+'.gz',raw)
for name in ['run.json','driver.py','boot.json','graph.json','boot.stdout.log','boot.stderr.log',
             'graph.stdout.log','graph.stderr.log','user-memory.stdout.log','user-memory.stderr.log',
             'process-memory.stdout.log','process-memory.stderr.log']:
    put('qualification/'+name+'.gz',(source/name).read_bytes())
failed=root/'linux-kernel/.cache/x86_64/boot-entry-stage'
for name in ['run.json','driver.py','boot.json','boot.stdout.log','boot.stderr.log']:
    put('history/incorrect-bss-counterexample/'+name+'.gz',(failed/name).read_bytes())
put('history/incorrect-bss-counterexample/notice.txt',
    b'The first driver selected the end of the first PT_LOAD file range and called it BSS. That segment had no BSS, so the mutation landed in an unchecked payload gap and correctly did not reject. The final driver selects an actual memsz>filesz segment. This was an observer-fixture failure, not a guest or AI safeguard failure. No kernel check was changed.\n')
for label,folder in [('callee','linux-kernel/tools/user-memory/results/stage-3-callee-graph'),
                     ('native','linux-kernel/tools/process-memory/results/stage-3-interface-callers')]:
    put('references/'+label+'-manifest.json',(root/folder/'manifest.json').read_bytes())
report=dict(passed=True,schema='topal.saved-boot-entry-stage/1',results=run['results'],
    upstream_inputs=run['upstream_inputs'],source_hashes=run['source_hashes_before'],
    dependencies=['../stage-3-callee-graph','../../../process-memory/results/stage-3-interface-callers'],
    qualification_elapsed_seconds=run['elapsed_seconds'],qualification_resources=run['resource_samples'][-1],
    models={'user-memory':229,'process-memory':82},offline_image_counterexamples=len(run['controls']),
    risk='Observation correctness is security-sensitive, but this stage changes only host readers/tests and descriptive reports. Single-agent self-review, counterexamples, exact frozen replay and explicit limits; no independent human security review.',
    failure_history='The retained initial driver misidentified a payload gap as BSS; corrected selection preserves the actual BSS check.',
    scope='Composable saved-byte evidence archive. The two pinned existing archives are required dependencies, not copied or claimed freshly rebuilt. No VM/compiler/disassembler rerun, production provenance or complete entry/lifetime qualification.')
put('report.json',(json.dumps(report,indent=2)+'\n').encode())
manifest={str(path.relative_to(output)):fact(path.read_bytes()) for path in sorted(output.rglob('*')) if path.is_file()}
put('manifest.json',(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode())
print(json.dumps(dict(entries=len(manifest),manifest=fact((output/'manifest.json').read_bytes()),results=run['results'])))
