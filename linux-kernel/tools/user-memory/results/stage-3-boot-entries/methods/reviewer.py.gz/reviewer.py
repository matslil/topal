"""Self-review and frozen replay of the composable saved boot-entry archive."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
archive=root/'linux-kernel/tools/user-memory/results/stage-3-boot-entries'
output=cache/'boot-entry-frozen-replay';output.mkdir(exist_ok=False)
frozen=output/'root';frozen.mkdir()
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(path,raw):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
# Finalize the unpublished collection with the exact collection/review methods.
for label,path in [('collector',cache/'collect-boot-entry-stage.py'),('reviewer',Path(__file__))]:
    write(archive/('methods/'+label+'.py.gz'),gzip.compress(path.read_bytes(),mtime=0))
manifest={str(path.relative_to(archive)):fact(path.read_bytes()) for path in sorted(archive.rglob('*'))
          if path.is_file() and path.name!='manifest.json'}
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
manifest_raw=(archive/'manifest.json').read_bytes()
for name,expected in manifest.items():assert fact((archive/name).read_bytes())==expected
report=json.loads((archive/'report.json').read_bytes())
run=json.loads(gzip.decompress((archive/'qualification/run.json.gz').read_bytes()))
assert run['passed'] and run['source_hashes_before']==run['source_hashes_after']==report['source_hashes']
prior=root/'linux-kernel/tools/user-memory/results/stage-3-callee-graph'
prior_raw=(prior/'manifest.json').read_bytes()
assert fact(prior_raw)['sha256']=='45227f2173edcfad8a5e9d083dd0b2c0da05bd9bc49b553579a728941c9ebb3e'
prior_manifest=json.loads(prior_raw)
restored=0
for name,expected in prior_manifest.items():
    if name.startswith('inputs/'):
        raw=(prior/name).read_bytes();assert fact(raw)==expected
        write(frozen/name[len('inputs/'):-3],gzip.decompress(raw));restored+=1
for name,expected in report['source_hashes'].items():
    raw=gzip.decompress((archive/('sources/'+name+'.gz')).read_bytes())
    assert fact(raw)==expected==fact((root/name).read_bytes())
    write(frozen/name,raw)
for path,row in report['upstream_inputs'].items():
    raw=(root/path).read_bytes();assert fact(raw)==row['compressed']
    assert fact(gzip.decompress(raw))==row['content']
    write(frozen/path,raw)
    folder=(root/path).parent
    while folder.name not in ['stage-3-callee-graph','stage-3-interface-callers']:folder=folder.parent
    raw_manifest=(folder/'manifest.json').read_bytes()
    assert fact(raw_manifest)['sha256']==row['manifest_sha256']
    write(frozen/(folder/'manifest.json').relative_to(root),raw_manifest)
environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
script=frozen/'linux-kernel/tools/user-memory/run_boot_entry_stage.py'
destination=frozen/'linux-kernel/.cache/replay'
argv=['rtk','proxy','python3','-B',str(script),str(destination)]
started=time.monotonic()
with (output/'stdout.log').open('w') as out,(output/'stderr.log').open('w') as err:
    result=subprocess.run(argv,cwd=frozen,env=environment,stdout=out,stderr=err)
assert result.returncode==0,(output/'stdout.log').read_text()+(output/'stderr.log').read_text()
replay=json.loads((destination/'run.json').read_bytes())
assert replay['passed'] and replay['results']==report['results']
assert replay['controls']==run['controls'] and replay['source_hashes_before']==report['source_hashes']
for name in ['boot.json','graph.json']:
    assert fact((destination/name).read_bytes())==fact(gzip.decompress((archive/('qualification/'+name+'.gz')).read_bytes()))
failed=json.loads(gzip.decompress((archive/'history/incorrect-bss-counterexample/run.json.gz').read_bytes()))
assert not failed['passed'] and 'accepted image counterexample nonzero-bss' in failed['failure']
assert all(row['rejected'] for row in run['controls']) and len(run['controls'])==13
for suite,count in [('user-memory',229),('process-memory',82)]:
    text=(destination/(suite+'.stderr.log')).read_text()
    assert 'Ran '+str(count)+' tests' in text and text.rstrip().endswith('OK')
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
review=dict(passed=True,archive_manifest=fact(manifest_raw),archive_entries=len(manifest),
    upstream_manifests=[fact((archive/('references/'+name+'-manifest.json')).read_bytes()) for name in ['callee','native']],
    restored_upstream_inputs=restored,current_source_overlays=len(report['source_hashes']),
    frozen_replay=dict(argv=argv,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,
                       results=replay['results'],source_hashes_stable=replay['source_hashes_before']==replay['source_hashes_after']),
    offline_image_counterexamples=13,models={'user-memory':229,'process-memory':82},
    historical_driver_failure_preserved=True,resources=resources,
    assessment='Single-agent observation-only self-review. Structural checks and frozen results reproduce; no independent human security assessment. Complete effects/entries/lifetime/publication remain unqualified.',
    next_action='Repair or stop advertising the absent independent 64-bit boot route using the approved systems-only authority. Preserve the validated setup/protected route and verify real guest boot separately. The 45861106 decoder disagreement and 88215/94687 native gaps remain unresolved.')
target=archive.parent/'stage-3-boot-entries-review.json'
target.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review))
