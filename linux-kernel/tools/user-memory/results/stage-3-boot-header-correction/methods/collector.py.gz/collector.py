"""Collect exact validated sources and fresh native bytes for the header fix."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64';run_folder=cache/'boot-header-correction-selected'
run=json.loads((run_folder/'run.json').read_bytes())
assert run['passed'] and run['driver_unchanged'] and run['source_hashes_before']==run['source_hashes_after']
archive=root/'linux-kernel/tools/user-memory/results/stage-3-boot-header-correction'
archive.mkdir(exist_ok=False)
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def put(name,raw,compress=True):
    target=archive/(name+'.gz' if compress else name)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
for name,sha in run['source_hashes_before'].items():
    raw=(root/name).read_bytes();assert fact(raw)['sha256']==sha
    put('inputs/'+name,raw)
for path in run_folder.iterdir():
    if path.is_file():put('qualification/'+path.name,path.read_bytes())
interrupted=cache/'boot-header-correction'
for path in interrupted.iterdir():
    if path.is_file():put('history/interrupted-full-suite/'+path.name,path.read_bytes())
put('history/interrupted-full-suite/scope.txt',
    b'Intentional validation-selection stop: the full compiler suite includes legacy native debugger-injected inconsistent kernel-state cases (frame_memory_fault_inspect.py), outside this stage\'s chosen ordinary-interface/model validation constraint. The original wrapper session ended 241 after stopping its exact scope; no full-suite pass is claimed. Some individual tests passed before interruption. Whether an injected case reached before stopping is not established. This was not an AI safeguard notice, OOM or build failure. Pre-stop accounting is retained; sock_throttled was 78, so no all-events-zero claim applies.\n')
build=root/run['native_build']
argv=['rtk','proxy','python3','-B','linux-kernel/tools/process-memory/readback_publication.py',str(build)]
started=time.monotonic()
with (archive/'readback.stdout.log').open('w') as out,(archive/'readback.stderr.log').open('w') as err:
    result=subprocess.run(argv,cwd=root,stdout=out,stderr=err)
assert result.returncode==0,(archive/'readback.stderr.log').read_text()
readback=dict(argv=argv,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started)
put('readback.command.json',(json.dumps(readback,indent=2)+'\n').encode(),False)
files={}
for path in sorted(build.rglob('*')):
    if path.is_file():
        assert not path.is_symlink(),'review native symlink before archival'
        name=str(path.relative_to(build));raw=path.read_bytes()
        put('native/'+name,raw);files[name]=fact(raw)
prior=root/'linux-kernel/tools/process-memory/results/stage-3-interface-callers'
raw=(prior/'manifest.json').read_bytes()
assert fact(raw)['sha256']=='0d5697ba20e1ceddf5c12187daaa82b21f34872e1e04325edc5df020224cf7ea'
put('reference/manifest.json',raw,False)
for name in ['kernel.elf','bzImage']:
    raw=(prior/('native/poll/'+name+'.gz')).read_bytes()
    assert fact(raw)==json.loads((prior/'manifest.json').read_bytes())['native/poll/'+name+'.gz']
    put('reference/'+name+'.gz',raw,False)
put('methods/collector.py',Path(__file__).read_bytes())
resources={}
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
resources={n:(directory/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']}
report=dict(passed=True,schema='topal.boot-header-correction/1',
    requirements=['TOPAL-SYSTEMS-ARTIFACT-001','TOPAL-COMP-SYSTEMS-ARTIFACT-001','LK-X64-BOOT-001'],
    source_hashes=run['source_hashes_before'],native_files=files,comparison=run['comparison'],
    qualification=dict(elapsed_seconds=run['elapsed_seconds'],commands=run['commands'],resources=run['resource_samples'][-1]),
    readback=readback,collection_resources=resources,
    risk='Moderate adapter compatibility change: cease advertising an unimplemented entry, while exact native comparison proves all payload bytes and the kernel unchanged. No memory protection, privilege or core-language semantic change. Single-agent design/formalization/implementation/self-review; independent human security review is not claimed.',
    interrupted_full_suite='Original full compiler run intentionally stopped and incomplete; exact driver, partial outputs/run and pre-stop resource notice retained. Legacy debugger-injected native cases remain coverage obligations, not passed checks or an explanation of any AI safeguard.',
    scope='One fresh source-built process-MM component VM, two targeted compiler tests and surrounding checks. Full compiler suite intentionally incomplete. The component has no production boot provenance; this is not production reconstruction, separate 64-bit loader qualification or complete Linux acceptance.')
put('report.json',(json.dumps(report,indent=2)+'\n').encode(),False)
manifest={str(p.relative_to(archive)):fact(p.read_bytes()) for p in sorted(archive.rglob('*')) if p.is_file()}
put('manifest.json',(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode(),False)
print(json.dumps(dict(passed=True,entries=len(manifest),native_files=len(files),sources=len(report['source_hashes']),manifest=fact((archive/'manifest.json').read_bytes()),comparison=run['comparison'])))
