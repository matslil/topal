"""Verify the complete correction archive and replay saved native readback."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
archive=root/'linux-kernel/tools/user-memory/results/stage-3-boot-header-correction'
output=cache/'boot-header-correction-replay-2';output.mkdir(exist_ok=False)
frozen=output/'root';frozen.mkdir()
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(path,raw):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
write(archive/'methods/reviewer.py.gz',gzip.compress(Path(__file__).read_bytes(),mtime=0))
manifest={str(p.relative_to(archive)):fact(p.read_bytes()) for p in sorted(archive.rglob('*'))
          if p.is_file() and p!=archive/'manifest.json'}
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
manifest_raw=(archive/'manifest.json').read_bytes()
for name,value in manifest.items():assert fact((archive/name).read_bytes())==value
report=json.loads((archive/'report.json').read_bytes())
run=json.loads(gzip.decompress((archive/'qualification/run.json.gz').read_bytes()))
assert run['passed'] and run['driver_unchanged']
assert report['source_hashes']==run['source_hashes_before']==run['source_hashes_after']
for name,sha in report['source_hashes'].items():
    raw=gzip.decompress((archive/('inputs/'+name+'.gz')).read_bytes())
    # Replay the recorded qualification inputs independently of later results
    # documentation or worktree edits. The separate index audit binds all
    # changed implementation/contract files and the post-validation summary.
    assert fact(raw)['sha256']==sha
    write(frozen/name,raw)
build=frozen/'linux-kernel/.cache/native'
for name,value in report['native_files'].items():
    raw=gzip.decompress((archive/('native/'+name+'.gz')).read_bytes())
    assert fact(raw)==value;write(build/name,raw)
reference_raw=(archive/'reference/manifest.json').read_bytes()
assert fact(reference_raw)['sha256']=='0d5697ba20e1ceddf5c12187daaa82b21f34872e1e04325edc5df020224cf7ea'
reference=json.loads(reference_raw)
for name in ['kernel.elf','bzImage']:
    assert fact((archive/('reference/'+name+'.gz')).read_bytes())==reference['native/poll/'+name+'.gz']
old=gzip.decompress((archive/'reference/bzImage.gz').read_bytes());image=(build/'bzImage').read_bytes()
kernel=(build/'kernel.elf').read_bytes()
assert kernel==gzip.decompress((archive/'reference/kernel.elf.gz').read_bytes())
assert len(old)==len(image) and old[:0x236]==image[:0x236] and old[0x237:]==image[0x237:]
assert old[0x236]==1 and image[0x236]==0
del old,image,kernel
commands={};environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
def command(name,args):
    argv=['rtk','proxy',*map(str,args)];start=time.monotonic()
    with (output/(name+'.stdout.log')).open('w') as out,(output/(name+'.stderr.log')).open('w') as err:
        result=subprocess.run(argv,cwd=frozen,env=environment,stdout=out,stderr=err)
    commands[name]=dict(argv=argv,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
    assert result.returncode==0,(output/(name+'.stderr.log')).read_text()
command('boot',['python3','-B',frozen/'linux-kernel/tools/user-memory/inspect_boot_entries.py',
                build/'kernel.elf',build/'bzImage',output/'boot.json'])
assert (output/'boot.json').read_bytes()==gzip.decompress((archive/'qualification/boot.json.gz').read_bytes())
original=(build/'process-mm-users/publication-readback.json').read_bytes()
command('native-readback',['python3','-B',frozen/'linux-kernel/tools/process-memory/readback_publication.py',build])
assert (build/'process-mm-users/publication-readback.json').read_bytes()==original
for name,count in [('user-memory',230),('process-memory',82)]:
    command(name,['python3','-B','-m','unittest','discover','-s',frozen/'linux-kernel/tools'/name,'-p','test_*.py'])
    text=(output/(name+'.stderr.log')).read_text()
    assert 'Ran '+str(count)+' tests' in text and text.rstrip().endswith('OK')
for name in ['compiler-header','compiler-publication']:
    compiler=gzip.decompress((archive/('qualification/'+name+'.stdout.log.gz')).read_bytes()).decode()
    assert '1 passed; 0 failed;' in compiler
assert all(row['exit_code']==0 for row in report['qualification']['commands'].values())
assert len(report['qualification']['commands'])==9
notice=json.loads(gzip.decompress((archive/'history/interrupted-full-suite/intentional-stop.json.gz').read_bytes()))
assert 'Intentional stop' in notice['reason'] and 'sock_throttled 78' in notice['resources_before_stop']['memory.events']
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
resources={n:(directory/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']}
review=dict(passed=True,archive_manifest=fact(manifest_raw),entries=len(manifest),
    sources=len(report['source_hashes']),native_files=len(report['native_files']),
    comparison=report['comparison'],frozen_commands=commands,resources=resources,
    compiler_receipt='Two actual targeted compiler test commands each passed one test. Full compiler suite intentionally interrupted, not passed. Frozen review does not rerun Cargo or VM.',
    risk=report['risk'],scope=report['scope'],
    remaining='Independent 64-bit loader support, all entry/effect/lifetime/ownership/production reconstruction and full initial Linux/distribution/container/VM-host acceptance remain incomplete.')
target=archive.parent/'stage-3-boot-header-correction-review.json'
target.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review))
