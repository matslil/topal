import gzip,json,os,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'linux-kernel/tools/user-memory'),str(ROOT/'linux-kernel/tools/process-memory')]
from run_calendar_data import verify_dependency,unpack
from run_policy_failure import hashes
from readback_process import digest as fact
from archive_publication import closed_archive
run=ROOT/'linux-kernel/.cache/x86_64/calendar-data-stage-4'
out=ROOT/'linux-kernel/tools/user-memory/results/stage-3-calendar-data'
replay=ROOT/'linux-kernel/.cache/x86_64/calendar-data-frozen'
q=json.loads((run/'run.json').read_text());assert q['passed'] and q['source_hashes_before']==q['source_hashes_after']
assert hashes(q['source_hashes_before'])==q['source_hashes_before']
for p,h in q['dependencies'].items():verify_dependency(ROOT/p,h)
group=next(l.split(':',2)[2] for l in Path('/proc/self/cgroup').read_text().splitlines() if l.startswith('0::'))
resources=Path('/sys/fs/cgroup')/group.lstrip('/');assert 'topal-bounded-' in group and (resources/'memory.swap.max').read_text().strip()=='0'
out.mkdir(exist_ok=False);manifest={}
def save(name,raw):
    p=out/name;assert p.resolve().is_relative_to(out) and name not in manifest
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);manifest[name]=fact(raw)
def packed(name,raw):save(name+'.gz',gzip.compress(raw,mtime=0))
def local_ref(name,raw):
    packed(name,raw);return dict(location='archive',path=name+'.gz',packed_sha256=manifest[name+'.gz']['sha256'],**fact(raw))
base=ROOT/'linux-kernel/tools/process-memory/results/stage-3-exec-failures'
b=json.loads((base/'report.json').read_text());sources={};shared=0
for name,sha in q['source_hashes_before'].items():
    raw=(ROOT/name).read_bytes()
    if b['selected_inputs'].get(name)==sha:
        folder=ROOT/b['dependency']['path'] if b['input_origins'][name]=='base' else base
        path=folder/('inputs/'+name+'.gz');data=path.read_bytes()
        assert gzip.decompress(data)==raw
        sources[name]=dict(location='repository',path=str(path.relative_to(ROOT)),packed_sha256=fact(data)['sha256'],**fact(raw));shared+=1
    else:sources[name]=local_ref('sources/'+name,raw)
artifacts={}
for name,spec in q['artifacts'].items():
    raw=unpack(spec);assert raw==(run/name).read_bytes()
    if name=='historical/kernel.elf':artifacts[name]=local_ref('artifacts/'+name,raw)
    else:
        assert any((ROOT/spec['path']).is_relative_to(ROOT/p) for p in q['dependencies'])
        artifacts[name]=dict(location='repository',**spec)
for name in ['historical','current']:
    for path in sorted((run/name).glob('*-explicit.*')):packed('observations/'+name+'/'+path.name,path.read_bytes())
for name in ['run.json','user.stdout.log','user.stderr.log','process.stdout.log','process.stderr.log']:
    packed('qualification/'+name,(run/name).read_bytes())
history=ROOT/'linux-kernel/.cache/x86_64'
for name in ['failed-closure-driver.py','failure.txt']:
    packed('history/legacy-manifest/'+name,(history/'calendar-data-stage-1'/name).read_bytes())
packed('history/callback-shape/failure.txt',(history/'calendar-data-stage-3/failure.txt').read_bytes())
for path in sorted((history/'calendar-data-stage-3/failure-inputs').glob('*.py')):
    packed('history/callback-shape/'+path.name,path.read_bytes())
packed('methods/collector.py',Path(__file__).read_bytes())
report=dict(passed=True,schema='topal.calendar-data-context/1',dependencies=q['dependencies'],sources=sources,
            artifacts=artifacts,qualification=q,shared_sources=shared,overlays=len(sources)-shared,
            qualification_complete=False,scope='Data/consumer context and conditional graph checks; no native execution, global exclusion or public activation')
save('report.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
script=r'''import gzip,json,os,subprocess,sys
from pathlib import Path
a=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();root=a.parents[4]
assert work.is_relative_to(root/'linux-kernel');work.mkdir(parents=True,exist_ok=False)
report=json.loads((a/'report.json').read_text())
import hashlib
def load(row):
    p=(a if row['location']=='archive' else root)/row['path'];data=p.read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['packed_sha256']
    raw=gzip.decompress(data);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];return raw
manifest=json.loads((a/'manifest.json').read_text())
assert {p.relative_to(a).as_posix() for p in a.rglob('*') if p.is_file()}==set(manifest)|{'manifest.json'}
for name,row in manifest.items():
    p=(a/name).resolve();assert p.is_relative_to(a);raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
for name,row in report['sources'].items():
    p=(work/name).resolve();assert p.is_relative_to(work);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(load(row))
for name,row in report['artifacts'].items():
    p=work/'evidence'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(load(row))
for case in ['historical','current']:
    for decoder in ['llvm','gnu']:
        name=case+'/'+decoder+'-explicit.stdout.log'
        (work/'evidence'/name).write_bytes(gzip.decompress((a/('observations/'+name+'.gz')).read_bytes()))
sys.path[:0]=[str(work/'linux-kernel/tools/user-memory'),str(work/'linux-kernel/tools/process-memory')]
from run_calendar_data import inspect_case,controls,verify_dependency
from inspect_calendar_data import context,FUNCTION
from inspect_call_inventory import Elf
for p,h in report['dependencies'].items():verify_dependency(root/p,h)
actual={}
for name,address in [('historical',0x2bbaa5d),('current',45861106)]:
    folder=work/'evidence'/name;value=inspect_case(folder,address,name=='current')
    expected=report['qualification']['cases'][name]
    assert value=={k:v for k,v in expected.items() if k!='explicit_start_decoders'}
    e=Elf(folder/'kernel.elf');s,b=e.function(FUNCTION)
    for decoder in ['llvm','gnu']:
        row=context((folder/(decoder+'-explicit.stdout.log')).read_bytes(),b,s['value'],address)
        assert row==[expected['explicit_start_decoders'][decoder]]
    actual[name]=value
assert controls(work/'evidence/current')==report['qualification']['controls']
from archive_publication import closed_archive
try:closed_archive(root/'linux-kernel/tools/user-memory/results/stage-3-paging-controls')
except ValueError as error:assert str(error)=='archive file closure'
else:raise AssertionError('original flat-manifest refusal not reproduced')
namespace={'__name__':'retained_callback_reader'}
raw=gzip.decompress((a/'history/callback-shape/calendar_data.py.gz').read_bytes());exec(compile(raw,'retained-calendar-data.py','exec'),namespace)
graph=json.loads((work/'evidence/current/graph.json').read_text())
try:namespace['guarded_entries'](graph,actual['current']['tables']['year_consumer'])
except TypeError as error:assert 'string indices must be integers' in str(error)
else:raise AssertionError('original callback-shape error not reproduced')
environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
for directory in ['user-memory','process-memory']:
    result=subprocess.run(['rtk','proxy','python3','-m','unittest','discover','-s','linux-kernel/tools/'+directory,'-p','test_*.py'],cwd=work,env=environment,capture_output=True)
    (work/(directory+'.stdout.log')).write_bytes(result.stdout);(work/(directory+'.stderr.log')).write_bytes(result.stderr)
    assert result.returncode==0,(directory,result.stderr.decode())
(work/'replayed.json').write_text(json.dumps(dict(passed=True,cases=actual,controls=report['qualification']['controls'],original_failures_reproduced=2,models=337,new_native_execution=False),indent=2)+'\n')
print('Frozen calendar data, graph, source binding, four controls, original reader failures and337models passed')
'''
save('methods/replay.py',script.encode())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');closed_archive(out)
result=subprocess.run(['rtk','proxy','python3',str(out/'methods/replay.py'),str(out),str(replay)],env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True)
(replay.parent/'calendar-data-replay.stdout.log').write_bytes(result.stdout);(replay.parent/'calendar-data-replay.stderr.log').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode()
assert hashes(q['source_hashes_before'])==q['source_hashes_before']
review=dict(passed=True,archive_manifest=fact((out/'manifest.json').read_bytes()),entries=len(manifest),sources=len(sources),shared_sources=shared,overlays=len(sources)-shared,
    frozen_replay=True,original_reader_failures_reproduced=2,models=337,new_native_execution=False,
    resources={n:(resources/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']})
with out.with_name(out.name+'-review.json').open('x') as stream:stream.write(json.dumps(review,indent=2,sort_keys=True)+'\n')
print(json.dumps(review))
