"""Collect unchanged linked code listings from two installed disassemblers."""
import hashlib
import json
from pathlib import Path
import subprocess

root=Path('linux-kernel/.cache/x86_64')
build=root/'translation-publication-native-1794477598358838483/build'
work=root/'paging-mode-inventory'
work.mkdir(exist_ok=True)
tool=Path(json.loads((build/'process-access-disassembly.command.json').read_text())['argv'][0])
commands={
    'llvm':[str(tool),'-d','-z','--x86-asm-syntax=intel',str(build/'kernel.elf')],
    'gnu':['objdump','-d','-z','-M','intel','--insn-width=16',str(build/'kernel.elf')],
}
digest=lambda raw:hashlib.sha256(raw).hexdigest()
for name,command in commands.items():
    with (work/(name+'.stdout.log')).open('wb') as out,(work/(name+'.stderr.log')).open('wb') as err:
        result=subprocess.run(command,stdout=out,stderr=err)
    (work/(name+'.command.json')).write_text(json.dumps(dict(argv=command,exit_code=result.returncode),indent=2)+'\n')
    assert result.returncode==0,name
    version=subprocess.check_output([command[0],'--version'])
    (work/(name+'.version.log')).write_bytes(version)
    print(json.dumps(dict(name=name,bytes=(work/(name+'.stdout.log')).stat().st_size,
        sha256=digest((work/(name+'.stdout.log')).read_bytes()))))
