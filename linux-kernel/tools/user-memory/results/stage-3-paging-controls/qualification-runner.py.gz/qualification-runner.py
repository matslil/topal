"""Run only saved-code inventory and its selected negative reader cases."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo=Path.cwd()
work=repo/'linux-kernel/.cache/x86_64/paging-mode-inventory'
build=repo/'linux-kernel/.cache/x86_64/translation-publication-native-1794477598358838483/build'
names=['linux-kernel/tools/user-memory/'+name for name in [
    'inventory_paging_controls.py','test_paging_controls.py','inspect_call_inventory.py']]
digest=lambda raw:hashlib.sha256(raw).hexdigest()
def source_hashes():return {name:digest((repo/name).read_bytes()) for name in names}
inputs={'kernel.elf':build/'kernel.elf','process-access-inventory.json':build/'process-access-inventory.json',
    'llvm.stdout.log':work/'llvm.stdout.log','gnu.stdout.log':work/'gnu.stdout.log'}
def input_hashes():return {name:digest(path.read_bytes()) for name,path in inputs.items()}
before=source_hashes()
before_inputs=input_hashes()
commands=[('models',[sys.executable,'-m','unittest','discover','-s','linux-kernel/tools/user-memory','-p','test_paging_controls.py','-v']),
    ('inventory',[sys.executable,'linux-kernel/tools/user-memory/inventory_paging_controls.py',
        str(inputs['kernel.elf']),str(inputs['llvm.stdout.log']),str(inputs['gnu.stdout.log']),
        str(inputs['process-access-inventory.json']),str(work/'inventory.json')])]
rows=[]
for label,command in commands:
    start=time.monotonic()
    with (work/(label+'.log')).open('wb') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    rows.append(dict(label=label,argv=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
        log_sha256=digest((work/(label+'.log')).read_bytes())))
    assert result.returncode==0,rows[-1]
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
cgroup=Path('/sys/fs/cgroup'+group)
resources={name:(cgroup/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
record=dict(passed=True,source_hashes_before=before,source_hashes_after=source_hashes(),
    input_hashes_before=before_inputs,input_hashes_after=input_hashes(),commands=rows,resources=resources,
    new_native_execution=False,scope='New saved linked-code inventory and nine reader counterexample tests; not guest execution or complete mode/ownership qualification')
assert record['source_hashes_before']==record['source_hashes_after']
assert record['input_hashes_before']==record['input_hashes_after']
assert resources['memory.swap.max']=='0' and all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
(work/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
