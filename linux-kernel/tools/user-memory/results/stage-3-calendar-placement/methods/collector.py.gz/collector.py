"""Archive a completed calendar-placement scope; never repeat native tests."""
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / 'linux-kernel/tools/user-memory'),
                str(ROOT / 'linux-kernel/tools/process-memory')]
from archive_publication import closed_archive
from readback_process import digest as fact
from run_policy_failure import hashes

run = ROOT / 'linux-kernel/.cache/x86_64/calendar-placement-stage-1'
out = ROOT / 'linux-kernel/tools/user-memory/results/stage-3-calendar-placement'
frozen = ROOT / 'linux-kernel/.cache/x86_64/calendar-placement-frozen'
q = json.loads((run / 'run.json').read_text())
assert q['passed'] and q['source_hashes_before'] == q['source_hashes_after']
assert hashes(q['source_hashes_before']) == q['source_hashes_before']
assert set(q['native_builds']) == set(q['placement']) == {'child-exec', 'applications'}
assert q['applications']['passed'] and q['applications']['complete_corpus']
assert q['applications']['workloads'] == len(q['applications']['summaries']) == 51
assert len(q['commands']) == 11 and all(row['exit_code'] == 0 for row in q['commands'].values())
assert q['placement']['child-exec']['kernel_sha256'] == q['placement']['applications']['kernel_sha256']
assert all(q['placement'][name]['passed'] for name in q['placement'])
assert int(q['resources']['memory.swap.max']) == 0
assert 0 < int(q['resources']['memory.peak']) <= int(q['resources']['memory.max'])
assert all(int(line.split()[1]) == 0 for line in q['resources']['memory.events'].splitlines())
group = next(line.split(':', 2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines()
             if line.startswith('0::'))
resources = Path('/sys/fs/cgroup') / group.lstrip('/')
assert 'topal-bounded-' in group and (resources / 'memory.swap.max').read_text().strip() == '0'

base = ROOT / 'linux-kernel/tools/user-memory/results/stage-3-calendar-data'
base_manifest = closed_archive(base)
assert fact(base_manifest)['sha256'] == '8508c497126423f0c99dbc71e4c1093fbc7bc67ffa21106b2bdca0a4f3e21ec3'
b = json.loads((base / 'report.json').read_text())
out.mkdir(exist_ok=False)
manifest = {}


def save(name, raw):
    path = (out / name).resolve()
    assert path.is_relative_to(out) and name not in manifest
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    manifest[name] = fact(raw)


def packed(name, raw):
    save(name + '.gz', gzip.compress(raw, mtime=0))


sources = {}
shared = 0
for name, sha in q['source_hashes_before'].items():
    raw = (ROOT / name).read_bytes()
    assert fact(raw)['sha256'] == sha
    previous = b['sources'].get(name)
    if previous and previous['sha256'] == sha:
        path = (base if previous['location'] == 'archive' else ROOT) / previous['path']
        compressed = path.read_bytes()
        assert fact(compressed)['sha256'] == previous['packed_sha256']
        assert gzip.decompress(compressed) == raw
        sources[name] = dict(previous, location='repository', path=str(path.relative_to(ROOT)))
        shared += 1
    else:
        packed('sources/' + name, raw)
        sources[name] = dict(location='archive', path='sources/' + name + '.gz',
                             packed_sha256=manifest['sources/' + name + '.gz']['sha256'], **fact(raw))

# Keep all native build inputs and artifacts, and complete per-workload observer
# records. The frozen replay must not rely on an ephemeral original cache path.
build_files = {}
for cohort, name in q['native_builds'].items():
    build = (ROOT / name).resolve()
    assert build.is_relative_to(ROOT / 'linux-kernel')
    files = [path for path in sorted(build.iterdir()) if path.is_file()]
    folder = build / ('process-mm-users' if cohort == 'child-exec' else 'process-mm-applications')
    files += [path for path in sorted(folder.rglob('*')) if path.is_file()]
    build_files[cohort] = {}
    for path in files:
        relative = path.relative_to(build).as_posix()
        raw = path.read_bytes()
        build_files[cohort][relative] = fact(raw)
        packed('native/' + cohort + '/' + relative, raw)
        del raw
for path in sorted(run.iterdir()):
    if path.is_file():
        packed('qualification/' + path.name, path.read_bytes())
for path in sorted((run / 'reference').iterdir()):
    if path.is_file():
        packed('reference/' + path.name, path.read_bytes())
packed('methods/collector.py', Path(__file__).read_bytes())
replay = ROOT / 'linux-kernel/.cache/x86_64/replay-calendar-placement.py'
save('methods/replay.py', replay.read_bytes())
report = dict(passed=True, schema='topal.calendar-data-placement/1', sources=sources,
              shared_sources=shared, overlays=len(sources) - shared, qualification=q,
              build_files=build_files,
              dependency=dict(path=base.relative_to(ROOT).as_posix(), manifest=fact(base_manifest)),
              qualification_complete=False, hardware_permissions_proved=False,
              scope='Selected current-source compiler and ordinary native regressions, exact Gregorian-data/layout transformation and frozen saved-record replay; not full compiler, hardware immutability, complete entries or public kernel qualification')
save('report.json', (json.dumps(report, indent=2, sort_keys=True) + '\n').encode())
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
closed_archive(out)
result = subprocess.run(['rtk', 'proxy', 'python3', str(out / 'methods/replay.py'), str(out), str(frozen)],
                        env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), capture_output=True)
(frozen.parent / 'calendar-placement-replay.stdout.log').write_bytes(result.stdout)
(frozen.parent / 'calendar-placement-replay.stderr.log').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode()
assert hashes(q['source_hashes_before']) == q['source_hashes_before']
review = dict(passed=True, archive_manifest=fact((out / 'manifest.json').read_bytes()),
              entries=len(manifest), sources=len(sources), shared_sources=shared,
              overlays=len(sources) - shared, frozen_replay=True,
              replay=json.loads((frozen / 'replayed.json').read_text()),
              new_native_execution=False, qualification_complete=False,
              resources={name: (resources / name).read_text().strip() for name in
                         ['memory.max', 'memory.swap.max', 'memory.peak', 'memory.events']})
with out.with_name(out.name + '-review.json').open('x') as stream:
    stream.write(json.dumps(review, indent=2, sort_keys=True) + '\n')
print(json.dumps(review))
