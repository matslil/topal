"""Bound fresh decoder listings and native helper coverage to the closed archive."""
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT / 'linux-kernel/tools/user-memory'),
                str(ROOT / 'linux-kernel/tools/process-memory')]
from archive_publication import closed_archive
from inspect_call_inventory import Elf, verify_calls
from inventory_paging_controls import inventory
from readback_process import digest as fact
from run_policy_failure import hashes

archive = ROOT / 'linux-kernel/tools/user-memory/results/stage-3-calendar-placement'
assert fact(closed_archive(archive))['sha256'] == '4f1c2497b4eac3b7765ce4e7967083b225c3dfdbed46af266fd0dc337e1718bc'
report = json.loads((archive / 'report.json').read_text())
q = report['qualification']
assert q['passed'] and hashes(q['source_hashes_before']) == q['source_hashes_before']
build = ROOT / q['native_builds']['applications']
output = ROOT / 'linux-kernel/.cache/x86_64/calendar-placement-followup-stage-1'
output.mkdir(exist_ok=False)
group = next(line.split(':', 2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines()
             if line.startswith('0::'))
resources = Path('/sys/fs/cgroup') / group.lstrip('/')
assert 'topal-bounded-' in group and (resources / 'memory.swap.max').read_text().strip() == '0'
commands = {}


def command(name, arguments):
    argv = ['rtk', 'proxy', *map(str, arguments)]
    result = subprocess.run(argv, cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), capture_output=True)
    (output / (name + '.stdout.log')).write_bytes(result.stdout)
    (output / (name + '.stderr.log')).write_bytes(result.stderr)
    commands[name] = dict(argv=argv, exit_code=result.returncode)
    (output / (name + '.command.json')).write_text(json.dumps(commands[name], indent=2) + '\n')
    assert result.returncode == 0, (name, result.stderr.decode())
    return result.stdout


llvm = json.loads((ROOT / 'linux-kernel/tools/user-memory/results/stage-3-paging-controls/llvm.command.json').read_text())['argv'][0]
for name, executable in [('llvm', llvm), ('gnu', 'objdump')]:
    command(name + '-version', [executable, '--version'])
first = command('llvm', [llvm, '-d', '-z', '--x86-asm-syntax=intel', build / 'kernel.elf'])
second = command('gnu', ['objdump', '-d', '-z', '-M', 'intel', '--insn-width=16', build / 'kernel.elf'])
graph_raw = (build / 'process-access-inventory.json').read_bytes()
assert fact(graph_raw) == report['build_files']['applications']['process-access-inventory.json']
graph = json.loads(graph_raw)
result = inventory(build / 'kernel.elf', first, second, graph)
(output / 'paging-controls.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
elf = Elf(build / 'kernel.elf')
assert fact(elf.data)['sha256'] == q['placement']['applications']['kernel_sha256']
calls_raw = (build / 'extent-call-inventory.json').read_bytes()
assert fact(calls_raw) == report['build_files']['applications']['extent-call-inventory.json']
calls = json.loads(calls_raw)
verify_calls(elf, calls)
declared = {row['offset']: row for row in calls['calls']}
covered = set()
cases = {}
for name in q['applications']['summaries']:
    path = 'process-mm-applications/' + name + '/observations.json'
    raw = (build / path).read_bytes()
    assert fact(raw) == report['build_files']['applications'][path]
    observed = json.loads(raw)
    coverage = observed['extent_call_coverage']
    assert observed['passed'] and coverage['observation_passed']
    assert coverage['kernel_sha256'] == result['kernel_sha256']
    assert coverage['inventory_sha256'] == fact(calls_raw)['sha256']
    offsets = {row['offset'] for row in coverage['reached']}
    assert offsets and offsets <= set(declared)
    cases[name] = sorted(offsets)
    covered |= offsets
    del raw, observed, coverage
coverage = dict(passed=True, kernel_sha256=result['kernel_sha256'],
                inventory=fact(calls_raw), declared=len(declared), reached=len(covered),
                unsampled=[declared[offset] for offset in sorted(set(declared) - covered)],
                cases=cases, scope='Union of selected helper-entry observations in the 51 archived workloads on this exact kernel. Not all caller paths, normal-return/lifetime coverage, inclusion of predecessor native observations or public qualification.')
(output / 'helper-coverage.json').write_text(json.dumps(coverage, indent=2, sort_keys=True) + '\n')
after = hashes(q['source_hashes_before'])
assert after == q['source_hashes_before']
receipt = dict(passed=True, commands=commands,
               source_hashes_before=q['source_hashes_before'], source_hashes_after=after,
               kernel_sha256=result['kernel_sha256'], graph=fact(graph_raw),
               paging_summary={key: result[key] for key in ['llvm_instruction_rows', 'gnu_instruction_rows',
                   'selected_controls', 'full_decoder_control_agreement', 'unmatched_control_addresses',
                   'embedded_or_alternate_candidates']},
               helper_summary={key: coverage[key] for key in ['declared', 'reached', 'unsampled']},
               new_native_execution=False, qualification_complete=False,
               resources={name: (resources / name).read_text().strip() for name in
                          ['memory.max', 'memory.swap.max', 'memory.peak', 'memory.events']})
(output / 'run.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: receipt[key] for key in ['passed', 'paging_summary', 'helper_summary', 'resources']}))
