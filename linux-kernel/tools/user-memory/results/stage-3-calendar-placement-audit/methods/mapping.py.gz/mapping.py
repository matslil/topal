"""Read selected current-kernel mapping samples; never modify or execute a guest.

This is a saved-record diagnostic for the fixed current layout, not a general
x86 page-table validator, continuous observation or protection qualification.
Invoke through the standard bounded wrapper after the native driver finishes.
"""
import hashlib
import json
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'linux-kernel/tools/user-memory'))
from inspect_call_inventory import Elf

PAGE = 4096
ADDRESS = ((1 << 52) - 1) & -PAGE
run = ROOT / 'linux-kernel/.cache/x86_64/calendar-placement-stage-1'
output = ROOT / 'linux-kernel/.cache/x86_64/calendar-placement-mappings-stage-1.json'
q = json.loads((run / 'run.json').read_text())
assert q['passed'] and q['source_hashes_before'] == q['source_hashes_after']
group = next(line.split(':', 2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines()
             if line.startswith('0::'))
resources = Path('/sys/fs/cgroup') / group.lstrip('/')
assert 'topal-bounded-' in group and (resources / 'memory.swap.max').read_text().strip() == '0'


def fact(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


parser_path = 'linux-kernel/tools/user-memory/inspect_call_inventory.py'
assert fact((ROOT / parser_path).read_bytes())['sha256'] == q['source_hashes_before'][parser_path]
build = (ROOT / q['native_builds']['child-exec']).resolve()
assert build.is_relative_to(ROOT / 'linux-kernel')
elf = Elf(build / 'kernel.elf')
kernel = fact(elf.data)
assert kernel['sha256'] == q['placement']['child-exec']['kernel_sha256']
assert kernel['sha256'] == q['placement']['applications']['kernel_sha256']
assert kernel['sha256'] == 'd8f937bdb2a4ad17cf4c20bca8c83c691af4fd3204b7316cdec1c713cffaf997'
offset = struct.unpack_from('<Q', elf.data, 32)[0]
width, count = struct.unpack_from('<HH', elf.data, 54)
assert width == 56 and offset + width * count <= len(elf.data)
loads = []
points = {}
for i in range(count):
    kind, flags, file_offset, virtual, physical, files, memory, alignment = struct.unpack_from('<IIQQQQQQ', elf.data, offset + i * width)
    if kind != 1:
        continue
    assert virtual == physical and 0 < memory and files <= memory
    assert file_offset + files <= len(elf.data)
    loads.append(dict(index=i, flags=flags, start=virtual, end=virtual + memory,
                      file_bytes=files, memory_bytes=memory, alignment=alignment))
    points['LOAD-' + str(i) + '-first'] = virtual
    points['LOAD-' + str(i) + '-last'] = virtual + memory - 1
assert [[row['start'], row['end']] for row in loads] == q['applications']['facts']['kernel_spans']
for name in ['topal_x86_realtime_years_v1', 'topal_x86_realtime_months_v1']:
    symbol = elf.symbols[name]
    points[name + '-first'] = symbol['value']
    points[name + '-last'] = symbol['value'] + symbol['size'] - 1


def selected_walk(sample, virtual):
    if sample['cr0'] & 0x80000001 != 0x80000001 or not sample['cr4'] & 32 or sample['cr4'] & (1 << 12):
        return dict(resolved=False, reason='record does not match the selected four-level paging mode')
    tables = sample['tables']
    root = sample['cr3'] & ADDRESS
    table = root
    path = []
    for level, shift in [(4, 39), (3, 30), (2, 21)]:
        words = tables.get(str(table))
        if words is None:
            return dict(resolved=False, reason='actual CR3 path not captured', root=root, path=path)
        assert len(words) == 512
        index = (virtual >> shift) & 511
        entry = words[index]
        path.append(dict(level=level, table=table, index=index, entry=entry))
        if not entry & 1:
            return dict(resolved=False, reason='not present', root=root, path=path)
        if level == 2:
            if not entry & 128:
                return dict(resolved=False, reason='requires a 4 KiB table extension to this diagnostic', root=root, path=path)
            physical = (entry & ADDRESS & -(1 << 21)) + (virtual & ((1 << 21) - 1))
            return dict(resolved=True, root=root, path=path, large_leaf_bytes=1 << 21,
                        physical=physical, identity=physical == virtual,
                        writable_bits_set_at_all_levels=all(row['entry'] & 2 for row in path),
                        user_bits_set_at_all_levels=all(row['entry'] & 4 for row in path),
                        XD_clear_at_all_levels=all(not row['entry'] & (1 << 63) for row in path))
        assert not entry & 128, 'this current-layout diagnostic expects no upper-level large leaf'
        table = entry & ADDRESS


observations = build / 'process-mm-users/observations.json'
raw = observations.read_bytes()
observation_fact = fact(raw)
observed = json.loads(raw)
del raw
assert observed['passed'] and observed['events']
rows = []
for i, event in enumerate(observed['events']):
    for side in ['before', 'after']:
        sample = event[side]
        assert sample['kernel_spans'] == q['applications']['facts']['kernel_spans']
        mappings = {name: selected_walk(sample, address) for name, address in points.items()}
        rows.append(dict(event=i, operation=event['operation'], side=side,
                         cr0=sample['cr0'], cr3=sample['cr3'], cr4=sample['cr4'],
                         CS=sample['cs'], context_root=sample['context']['root'],
                         CR0_WP=bool(sample['cr0'] & (1 << 16)),
                         mappings=mappings))
resolved = [mapping for row in rows for mapping in row['mappings'].values() if mapping['resolved']]
unresolved = [dict(event=row['event'], side=row['side'], point=name, **mapping)
              for row in rows for name, mapping in row['mappings'].items() if not mapping['resolved']]
report = dict(passed=True, schema='topal.calendar-mapping-samples/1', kernel=kernel,
              observation=observation_fact, parser=fact((ROOT / parser_path).read_bytes()),
              method=fact(Path(__file__).read_bytes()), loads=loads, points=points, samples=rows,
              summary=dict(boundary_samples=len(rows), point_walks=len(rows) * len(points),
                  resolved=len(resolved), unresolved=len(unresolved),
                  all_walks_resolved=not unresolved,
                  all_resolved_identity=bool(resolved) and all(row['identity'] for row in resolved),
                  all_resolved_writable_bits_set=bool(resolved) and all(row['writable_bits_set_at_all_levels'] for row in resolved),
                  all_resolved_XD_clear=bool(resolved) and all(row['XD_clear_at_all_levels'] for row in resolved),
                  any_resolved_user_accessible=any(row['user_bits_set_at_all_levels'] for row in resolved)),
              unresolved=unresolved, EFER_sampled=False, continuous_lifetime_proved=False,
              hardware_protection_qualified=False, new_native_execution=False,
              scope='Selected current-kernel ELF load/calendar endpoints at saved process-MM before/after event boundaries. Raw entries and CR0/CR3/CR4 are retained; this is not a general page-table validation, an execution experiment or a continuous permission/immutability proof.',
              resources={name: (resources / name).read_text().strip() for name in
                         ['memory.max', 'memory.swap.max', 'memory.peak', 'memory.events']})
with output.open('x') as stream:
    stream.write(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report['summary']))
