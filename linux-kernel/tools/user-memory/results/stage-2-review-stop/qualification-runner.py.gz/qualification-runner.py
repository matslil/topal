from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,sys,time,uuid

root=Path.cwd()
out=root/'linux-kernel/tools/user-memory/results/stage-2'
assert not out.exists(),'never overwrite an earlier cohort'
out.mkdir(parents=True)
scratch=root/'linux-kernel/.cache'/('tk283-stage2-'+uuid.uuid4().hex[:8]);scratch.mkdir()
alias=Path('/tmp')/scratch.name;alias.symlink_to(scratch,target_is_directory=True)
env=dict(os.environ,TMPDIR=str(alias),RUST_MIN_STACK='16777216',CARGO_BUILD_JOBS='1')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
foreign_sha='7ae95c260622412ceba6eb9f45d68f616cdc091a1d71d6c0a08b5875bb2c31dd'
foreign=gzip.decompress((root/f'linux-kernel/.cache/qualification-external/{foreign_sha}.gz').read_bytes())
assert sha(foreign)==foreign_sha
def store(name,raw):
    assert foreign not in raw,'external qualification executable may not enter Git'
    compressed=gzip.compress(raw,mtime=0);target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(compressed)
    return dict(file=str(target.relative_to(out)),sha256=sha(compressed),uncompressed_sha256=sha(raw),bytes=len(raw))
names=subprocess.check_output(['git','ls-files'],text=True).splitlines()
names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','src','linux-kernel'],text=True).splitlines()
factual={'linux-kernel/step-4-owned-user-extents.md','se/traceability.md','linux-kernel/design/decision-register.md'}
names=sorted({n for n in names if n not in factual and not (n.startswith('linux-kernel/') and '/results/' in n)})
assert 'topal-as-dsl.md' not in names
record=dict(schema='topal-owned-user-extent-native/1',decision='TK-DEC-283',stage=2,complete=False,passed=False,
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    source_scope='Frozen worktree, not clean-checkout execution; commit identity must be checked after the stage commit.',
    acceptance_scope='Native walk, compiler-derived actual owners, scoped target and owning gateway; guarded host calls, actual full-root QEMU and isolated negative boundaries. All-caller production integration/publication, general MM and original distribution/container/VM-host acceptance remain unfinished.',
    retry_scope='A preceding four-thread workspace cohort failed one old interrupt-negative debugger assertion without OOM or kill; retained separately. Four exact-image isolated repeats passed. This full retry serializes test execution; underlying root cause is not established.',
    risk='High: ownership, permissions, privilege state and physical caller retirement. Single-agent authority/diff review plus independent model/byte/state/ELF readback and actual GDB/QEMU controls; no independent human review claimed.',
    sources={n:sha((root/n).read_bytes()) for n in names},snapshots={},verification_inputs={},commands=[],components=[],
    scratch=str(scratch),alias=str(alias),runner=store('qualification-runner.py',Path(__file__).read_bytes()),
    foreign_payload_guard=dict(sha256=foreign_sha,scope='Byte-exclusion audit input only; not a guest/build dependency and never archived'))
for name,digest in record['sources'].items():record['snapshots'][name]=store('inputs/'+digest,(root/name).read_bytes())
for name in sorted(factual):record['verification_inputs'][name]=store('verification/'+name,(root/name).read_bytes())
relative=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
group=Path('/sys/fs/cgroup')/relative.lstrip('/')
assert 'topal-bounded-' in relative and (group/'memory.swap.max').read_text().strip()=='0'
def save():
    record['resources']={n:(group/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']}
    (out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
def unchanged():
    assert all(sha((root/n).read_bytes())==digest for n,digest in record['sources'].items()),'frozen source changed'
def command(label,args):
    unchanged();start=time.monotonic()
    p=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label,command=args,exit_code=p.returncode,seconds=time.monotonic()-start,
                                  log=store('logs/'+label,p.stdout)))
    save();print(label,'EXIT',p.returncode,'SECONDS',round(time.monotonic()-start,2),flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-7000:],flush=True);raise SystemExit(p.returncode)
    unchanged();return p.stdout

print('FROZEN_SOURCE_INPUTS',len(names),'SCRATCH',scratch,flush=True);save()
command('format',['cargo','fmt','--all','--','--check'])
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','src'],text=True).splitlines()
rust=sorted({n for n in changed if n.endswith('.rs')})
command('included-format',['rustfmt','--edition','2024','--check',*rust])
command('source-size',['python3','scripts/check_rust_file_sizes.py'])
command('workspace-check',['cargo','check','--locked','--workspace','--all-targets','-j1'])
models=command('model',['python3','-m','unittest','discover','-s','linux-kernel/tools/user-memory','-v'])
assert b'Ran 17 tests' in models and models.rstrip().endswith(b'OK')
tests=command('workspace-tests',['cargo','test','--locked','--workspace','--all-targets','-j1','--','--test-threads=1'])
totals=re.findall(rb'test result: ok\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out',tests)
assert totals and all(tuple(map(int,row))[1:]==(0,0,0,0) for row in totals)
record['rust_tests']=sum(int(row[0]) for row in totals);record['rust_targets']=len(totals)
command('doc-tests',['cargo','test','--locked','--workspace','--doc','-j1','--','--test-threads=1'])
command('whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab','diff','--check'])

def archive(directory,label,scope):
    assert directory.is_dir(),directory
    item=dict(label=label,scope=scope,directory=str(directory),files={},excluded=[])
    for path in sorted(directory.rglob('*')):
        if not path.is_file():continue
        name=str(path.relative_to(directory))
        # The host C client can link third-party CRT objects. Retain its own
        # source, native object and exact compile/run logs; rebuild the client.
        if name=='probe':item['excluded'].append(dict(name=name,reason='host-linked client executable; regenerate from retained source/command'));continue
        raw=path.read_bytes();digest=sha(raw)
        item['files'][name]=store('component-bytes/'+digest,raw)
    record['components'].append(item);save()

new_dirs=sorted(p for p in scratch.iterdir() if p.is_dir() and p.name.startswith('user-extent-'))
assert len(new_dirs)==3,[(p.name) for p in new_dirs]
for index,directory in enumerate(new_dirs):
    archive(directory,'current-'+directory.name.split('-'+str(os.getpid()))[0]+'-'+str(index),
            'Current frozen-source full workspace test cohort; exact native/observer inputs and original logs retained')
guests=[p for p in new_dirs if p.name.startswith('user-extent-root-')]
assert len(guests)==1
guest=guests[0]
positive=json.loads((guest/'user-extents/observations.json').read_text())
assert positive['passed'] and len(positive['user_extents'])==324 and len(positive['memory'])==80
assert positive['probe_counts']==[44,324,24,16]
assert positive['wp_transitions'] and all(t['after']==t['before']|(1<<16) for t in positive['wp_transitions'])
fault_dirs=sorted(guest.glob('user-extent-fault-*'));assert len(fault_dirs)==21
assert all((lambda r:r['passed'] and r['component_boundary'] and not r['completed_guest'])(json.loads((p/'observations.json').read_text())) for p in fault_dirs)
record['current_evidence']=dict(native_calls=324,actual_memory_operations=80,negative_boundaries=21,
    probe_counts=positive['probe_counts'],wp_transitions=positive['wp_transitions'])

prior=root/'linux-kernel/.cache/tk283-native-dev-01a67f67'
for name,label,scope in [
 ('user-extent-root-2163420-1794263421640495723','development-before-wp-initialization',
  'Failed preliminary VM: actual CR0.WP was absent and native target correctly returned unsupported. Guest initialization subsequently added. Original native/observer outputs retained; complete modified Rust source was not frozen at this development point.'),
 ('user-extent-root-2164079-1794263646501643385','development-first-positive-and-controls',
  'Preliminary positive 324-call/80-MM VM plus isolated controls. Observer variants are recorded in each actual debugger script. Full source correspondence is established only by the current cohort.')]:
    archive(prior/name,label,scope)
unchanged()
events=dict(line.split() for line in (group/'memory.events').read_text().splitlines())
assert all(int(events[n])==0 for n in ['oom','oom_kill','oom_group_kill'])
record.update(complete=True,passed=True);save()
print('OWNED_USER_EXTENT_NATIVE_STAGE2_PASS',record['rust_tests'],record['rust_targets'],len(record['components']),flush=True)
