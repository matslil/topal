"""Frozen replay and limited retained-assertion review, never native execution."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
archive=root/'linux-kernel/tools/user-memory/results/stage-3-gateway-admission'
base=archive.parent/'stage-3-boot-header-correction'
output=cache/'gateway-admission-frozen-replay';output.mkdir(exist_ok=False)
frozen=output/'root';frozen.mkdir()
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(path,raw):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
manifest=json.loads((archive/'manifest.json').read_bytes())
assert {str(p.relative_to(archive)) for p in archive.rglob('*') if p.is_file()}==set(manifest)|{'manifest.json'}
for name,expected in manifest.items():assert fact((archive/name).read_bytes())==expected
method=gzip.compress(Path(__file__).read_bytes(),mtime=0)
write(archive/'methods/reviewer.py.gz',method);manifest['methods/reviewer.py.gz']=fact(method)
(archive/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
manifest_raw=(archive/'manifest.json').read_bytes()
report=json.loads((archive/'report.json').read_bytes())
run=json.loads(gzip.decompress((archive/'qualification/run.json.gz').read_bytes()))
assert report['source_inputs']==run['source_hashes_before']==run['source_hashes_after']
assert run['passed'] and report['totals']==dict(kernels=4,model_cases=20504,guard_counterexamples=36,
    retained_diagnostic_assertions=36,user_memory_models=248,process_memory_models=82)
base_raw=(base/'manifest.json').read_bytes();assert fact(base_raw)==report['base_manifest']
assert fact(base_raw)['sha256']=='243cf390588cbc17687c36fbee82abc13003ae9b17c4cd984f8f2dd82d140fe4'
base_manifest=json.loads(base_raw)
restored=0
for name,expected in base_manifest.items():
    if name.startswith('inputs/'):
        raw=(base/name).read_bytes();assert fact(raw)==expected
        write(frozen/name[len('inputs/'):-3],gzip.decompress(raw));restored+=1
for name,expected in report['source_overlays'].items():
    raw=gzip.decompress((archive/('inputs/'+name+'.gz')).read_bytes());assert fact(raw)==expected
    write(frozen/name,raw)
for name,expected in report['source_inputs'].items():assert fact((frozen/name).read_bytes())==expected
commands={};environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
def command(label,args):
    argv=['rtk','proxy',*map(str,args)];began=time.monotonic()
    with (output/(label+'.stdout.log')).open('w') as out,(output/(label+'.stderr.log')).open('w') as err:
        result=subprocess.run(argv,cwd=frozen,env=environment,stdout=out,stderr=err)
    commands[label]=dict(argv=argv,exit_code=result.returncode,elapsed_seconds=time.monotonic()-began)
    assert result.returncode==0,(output/(label+'.stderr.log')).read_text()
sys.path.insert(0,str(frozen/'linux-kernel/tools/user-memory'))
from run_gateway_admission import mutation_controls
for key,value in report['kernels'].items():
    raw=gzip.decompress((archive/('kernels/'+key+'.elf.gz')).read_bytes())
    assert fact(raw)['sha256']==key
    kernel=output/(key+'.elf');kernel.write_bytes(raw)
    destination=output/(key+'.json')
    command(key,['python3','-B',frozen/'linux-kernel/tools/user-memory/inspect_gateway_admission.py',kernel,destination])
    assert fact(destination.read_bytes())==value['report']
    assert destination.read_bytes()==gzip.decompress((archive/('qualification/'+key+'.json.gz')).read_bytes())
    assert mutation_controls(kernel)==run['controls'][key]
    assert fact(kernel.read_bytes())['sha256']==key
retained={};boot_bindings={}
for label,modes in report['legacy'].items():
    role=report['roles'][label];kernel_key=role['identity']['sha256']
    image=gzip.decompress((archive/('legacy/'+label+'/bzImage.gz')).read_bytes())
    provenance=archive/('legacy/'+label+'/boot-provenance.json.gz')
    if provenance.exists():
        record=json.loads(gzip.decompress(provenance.read_bytes()))
        assert record['linked_kernel_sha256']==kernel_key and record['boot_image_sha256']==fact(image)['sha256']
        assert record['schema'].endswith('/154')
        boot_bindings[label]=dict(schema=record['schema'],kernel_sha256=kernel_key,boot_image=fact(image),
            scope='Retained predecessor public artifact record, not activation or publication of the current owned/process-MM selection.')
    retained[label]={}
    for mode,item in modes.items():
        prefix='legacy/'+label+'/memory-'+mode+'/'
        blobs={}
        for name,expected in item['files'].items():
            raw=gzip.decompress((archive/(prefix+name+'.gz')).read_bytes())
            assert fact(raw)==expected;blobs[name]=raw
        state=json.loads(blobs['observations.json'])
        assert state['passed'] is True and state['mode']==mode
        assert ('FRAME_MEMORY_FAULT_GDB_PASS '+mode).encode() in blobs['gdb.stdout.log']
        assert b'FRAME_ROOT_GDB_PASS' in blobs['gdb.stdout.log']
        argv=json.loads(blobs['qemu.command.json'])
        # Compare the retained original path as data; do not access or execute it.
        image_path=Path(argv[argv.index('-kernel')+1])
        expected_suffix=Path(role['kernel']).parent/'bzImage'
        assert image_path.as_posix().endswith('/'+expected_suffix.as_posix())
        if mode=='no-fit':assert state['ordinary_no_fit'] and state['guest_state_modified'] is False
        elif mode in ['partial-source','published-unpin']:
            assert all(state[key] for key in ['performed_effects_retained','physical_caller_retired','process_not_resumed'])
        else:assert state['refused_without_retirement_claim']
        retained[label][mode]=dict(completed_assertions=True,observations=fact(blobs['observations.json']))
partial=gzip.decompress((archive/'history/interrupted-full-suite/compiler-units.stdout.log.gz').read_bytes()).decode()
assert 'test result:' not in partial
for name in ['systems_frame_target::memory_tests::frame_memory_uses_actual_syscall_requests_and_whole_exec_exit_release',
             'systems_frame_publication::guest_tests::frame_reconstruction_binds_actual_loads_and_executes_syscall_memory',
             'systems_frame_publication::artifact_tests::frame_artifact_publishes_complete_sources_and_reconstructs_at_boot']:
    assert 'test '+name+' ... ok' in partial
for name,count in [('user-memory',248),('process-memory',82)]:
    command(name,['python3','-B','-m','unittest','discover','-s',frozen/'linux-kernel/tools'/name,'-p','test_*.py'])
    text=(output/(name+'.stderr.log')).read_text();assert f'Ran {count} tests' in text and text.rstrip().endswith('OK')
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
resources={name:(directory/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.peak','memory.events']}
review=dict(passed=True,archive_manifest=fact(manifest_raw),archive_entries=len(manifest),
    base_manifest=fact(base_raw),restored_base_inputs=restored,source_overlays=len(report['source_overlays']),
    frozen_commands=commands,totals=report['totals'],retained_assertions=retained,predecessor_boot_records=boot_bindings,
    resources=resources,assessment=report['risk'],
    evidence_limit='Retained mode completion is now established for three predecessor kernels. Full CPU inputs and all before/after data were not retained, so producer assertions are not independently replayed native semantics. No new guest or debugger invocation. Full compiler command remains interrupted; its three relevant individual tests did finish.',
    remaining='Other gateway operation paths, genuine owner/caller/fresh-entry/mode/lifetime/async/exception facts, post-admission fatal effects and complete original Linux acceptance remain unqualified. No legacy check/test or production gate was removed.')
target=archive.parent/'stage-3-gateway-admission-review.json';target.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(dict(passed=True,archive_manifest=review['archive_manifest'],entries=len(manifest),
    totals=review['totals'],source_overlays=review['source_overlays'],predecessor_boot_records=boot_bindings,resources=resources)))
