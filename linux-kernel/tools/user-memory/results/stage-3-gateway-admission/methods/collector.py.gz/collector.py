"""Collect composable host-model evidence and original retained diagnostics."""
import gzip
import hashlib
import json
from pathlib import Path

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
source=cache/'gateway-admission-stage-4'
archive=root/'linux-kernel/tools/user-memory/results/stage-3-gateway-admission'
archive.mkdir(exist_ok=False)
base=root/'linux-kernel/tools/user-memory/results/stage-3-boot-header-correction'
def fact(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def put(name,raw,compressed=True):
    path=archive/(name+'.gz' if compressed else name);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(gzip.compress(raw,mtime=0) if compressed else raw)
run=json.loads((source/'run.json').read_bytes())
assert run['passed'] and run['source_hashes_before']==run['source_hashes_after']
base_raw=(base/'manifest.json').read_bytes()
assert fact(base_raw)['sha256']=='243cf390588cbc17687c36fbee82abc13003ae9b17c4cd984f8f2dd82d140fe4'
base_manifest=json.loads(base_raw);reused={};overlays={}
for name,expected in run['source_hashes_before'].items():
    raw=(root/name).read_bytes();assert fact(raw)==expected
    key='inputs/'+name+'.gz'
    if key in base_manifest:
        compressed=(base/key).read_bytes();assert fact(compressed)==base_manifest[key]
        same=gzip.decompress(compressed)==raw
    else:same=False
    if same:reused[name]=expected
    else:put('inputs/'+name,raw);overlays[name]=expected
put('references/base-manifest.json',base_raw,False)
for path in source.iterdir():
    if path.is_file():put('qualification/'+path.name,path.read_bytes())
for key,record in run['kernels'].items():
    role=next(value for value in run['roles'].values() if value['identity']['sha256']==key)
    raw=(root/role['kernel']).read_bytes();assert fact(raw)==role['identity']
    put('kernels/'+key+'.elf',raw)
for label,records in run['legacy'].items():
    folder=(root/run['roles'][label]['kernel']).parent
    for name in ['bzImage','initramfs.cpio','static-elf-abi-fixture.elf','root.t','root-tokens.json','boot-provenance.json']:
        path=folder/name
        if path.is_file():put('legacy/'+label+'/'+name,path.read_bytes())
    for mode,record in records.items():
        for name,expected in record['files'].items():
            raw=(folder/('memory-'+mode)/name).read_bytes();assert fact(raw)==expected
            put('legacy/'+label+'/memory-'+mode+'/'+name,raw)
interrupted=cache/'boot-header-correction'
for name in ['driver.py','run.json','compiler-units.stdout.log','compiler-units.stderr.log','intentional-stop.json']:
    put('history/interrupted-full-suite/'+name,(interrupted/name).read_bytes())
put('methods/collector.py',Path(__file__).read_bytes())
report=dict(passed=True,schema='topal.gateway-admission-stage/1',
    requirements=['TOPAL-SYSTEMS-FRAME-POLICY-BINDING-001','TOPAL-COMP-SYSTEMS-FRAME-POLICY-BINDING-001'],
    base_archive='../stage-3-boot-header-correction',base_manifest=fact(base_raw),
    source_inputs=run['source_hashes_before'],reused_inputs=reused,source_overlays=overlays,
    kernels=run['kernels'],roles=run['roles'],legacy=run['legacy'],
    qualification=dict(elapsed_seconds=run['elapsed_seconds'],resources=run['resource_samples'][-1],commands=run['commands']),
    totals=dict(kernels=len(run['kernels']),model_cases=sum(row['cases'] for row in run['kernels'].values()),
        guard_counterexamples=sum(len(rows) for rows in run['controls'].values()),
        retained_diagnostic_assertions=sum(len(rows) for rows in run['legacy'].values()),
        user_memory_models=248,process_memory_models=82),
    review_notes='Independent predicate versus strict saved-byte interpreter. Self-review found initial CF/ZF initialization needed to come from input flags; corrected and regression added before publication. Explicit entry=0/high-only word controls added. Actual modeled prefixes start with CMP, so the initialization correction did not change their earlier pilot outcomes. No production or legacy test change.',
    risk='Security-sensitive observation, with limited flag projection and explicit unsupported cases. Single-agent design/implementation/self-review, independent hand-encoded counterexamples, 36 weakened-guard controls and frozen replay; no independent human security review claimed. qualification_complete remains false.',
    scope='Fresh host model and retained assertion inventory only. Nine pre-admission modes are modeled for brk/exec reset/completion; other operations, fresh-entry/owner/hardware/lifetime assumptions and post-admission fatal effects remain separate. Retained diagnostics confirm past execution, not new VM runs or complete state replay. Full compiler command remains interrupted; no original security check, test or production gate is removed.')
put('report.json',(json.dumps(report,indent=2)+'\n').encode(),False)
manifest={str(p.relative_to(archive)):fact(p.read_bytes()) for p in sorted(archive.rglob('*')) if p.is_file()}
put('manifest.json',(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode(),False)
print(json.dumps(dict(passed=True,entries=len(manifest),manifest=fact((archive/'manifest.json').read_bytes()),
    reused=len(reused),overlays=len(overlays),totals=report['totals'])))
