"""Source-frozen compiler and native regression for truthful boot advertisement."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

root=Path.cwd();cache=root/'linux-kernel/.cache/x86_64'
sys.path.insert(0,str(root/'linux-kernel/tools/process-memory'))
from run_policy_failure import watched,hashes,VALIDATIONS
sys.path.insert(0,str(root/'linux-kernel/tools/user-memory'))
from inspect_boot_entries import inspect
output=cache/'boot-header-correction';output.mkdir(exist_ok=False)
temporary=output/'temporary';temporary.mkdir()
paths=sorted(set(watched())|{'linux-kernel/design/x86-boot-adapter.md','spec/systems-profile.md',
    'src/topal-compiler/se-requirements.md'})
before=hashes(paths);script=Path(__file__).read_bytes();(output/'driver.py').write_bytes(script)
group=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
directory=Path('/sys/fs/cgroup')/group.lstrip('/')
assert 'topal-bounded-' in group and (directory/'memory.swap.max').read_text().strip()=='0'
def resources():return {n:(directory/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']}
report=dict(passed=False,source_hashes_before=before,commands={},resource_samples=[resources()],
    scope='Fresh full compiler suite and surrounding checks plus one actual process-MM Q35 component VM. Packaging advertisement changes; no core language or kernel instruction change is intended. Native fixture is unpublished, not production reconstruction.')
environment=dict(os.environ,RUST_MIN_STACK='16777216',PYTHONDONTWRITEBYTECODE='1',RUST_TEST_THREADS='2',TMPDIR=str(temporary))
for name in list(environment):
    if name.startswith('TOPAL_TEST_'):environment.pop(name)
def save():
    report['resource_samples'].append(resources())
    (output/'run.json').write_text(json.dumps(report,indent=2)+'\n')
def command(name,args,extra=None):
    began=time.monotonic();argv=['rtk','proxy',*map(str,args)]
    with (output/(name+'.stdout.log')).open('w') as out,(output/(name+'.stderr.log')).open('w') as err:
        result=subprocess.run(argv,cwd=root,env=dict(environment,**(extra or {})),stdout=out,stderr=err)
    report['commands'][name]=dict(argv=argv,environment=extra or {},exit_code=result.returncode,elapsed_seconds=time.monotonic()-began)
    save();print(name,result.returncode,flush=True)
    if result.returncode:raise RuntimeError('failed '+name)
began=time.monotonic();failure=0;save()
try:
    for name,args in VALIDATIONS.items():command(name,args)
    args=['cargo','test','-p','topal-compiler','--lib','--locked','-j1',
        'systems_frame_target::root_tests::process_mm_fork_handoff_and_exit_preserve_independent_heap_owners',
        '--','--ignored','--exact','--test-threads=1','--nocapture']
    command('native',args,{'TOPAL_TEST_PROCESS_MM_PUBLICATION':'1'})
    text=(output/'native.stdout.log').read_text()+(output/'native.stderr.log').read_text()
    builds=[Path(value.strip()) for value in re.findall(r'actual frame source root: ([^\n]+)',text)]
    assert len(builds)==1,builds
    build=builds[0];report['native_build']=str(build.relative_to(root))
    kernel=(build/'kernel.elf').read_bytes();image=(build/'bzImage').read_bytes()
    prior=root/'linux-kernel/tools/process-memory/results/stage-3-interface-callers'
    manifest_raw=(prior/'manifest.json').read_bytes()
    assert hashlib.sha256(manifest_raw).hexdigest()=='0d5697ba20e1ceddf5c12187daaa82b21f34872e1e04325edc5df020224cf7ea'
    manifest=json.loads(manifest_raw)
    def prior_bytes(name):
        raw=(prior/('native/poll/'+name+'.gz')).read_bytes()
        assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==manifest['native/poll/'+name+'.gz']
        return gzip.decompress(raw)
    assert kernel==prior_bytes('kernel.elf')
    old=prior_bytes('bzImage');assert len(old)==len(image)
    differences=[i for i,(a,b) in enumerate(zip(old,image)) if a!=b]
    assert differences==[0x236] and old[0x236]==1 and image[0x236]==0,differences
    boot=inspect(build/'kernel.elf',image)
    assert boot['header']['xloadflags']==0 and boot['advertised_64bit_entry']['advertised'] is False
    assert boot['advertised_64bit_entry']['qualified'] is False and boot['advertised_64bit_entry']['blocker'] is None
    (output/'boot.json').write_text(json.dumps(boot,indent=2)+'\n')
    report['comparison']=dict(kernel_sha256=hashlib.sha256(kernel).hexdigest(),
        old_image_sha256=hashlib.sha256(old).hexdigest(),new_image_sha256=hashlib.sha256(image).hexdigest(),
        image_bytes=len(image),changed_offsets=differences,boot_provenance_present=(build/'boot-provenance.json').exists())
except BaseException:
    failure=1;report['failure']=traceback.format_exc();print(report['failure'],flush=True)
finally:
    report['source_hashes_after']=hashes(paths)
    report.update(elapsed_seconds=time.monotonic()-began,driver_unchanged=script==Path(__file__).read_bytes(),
        passed=not failure and before==report['source_hashes_after'] and script==Path(__file__).read_bytes())
    save()
print(json.dumps({k:report.get(k) for k in ['passed','elapsed_seconds','native_build','comparison','failure']}))
raise SystemExit(failure or int(not report['passed']))
