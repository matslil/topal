set pagination off
file /home/mats/git/topal/linux-kernel/.cache/x86_64/user-extent-source-storage-2391049-1794459629440117879/kernel.elf
python
graph_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/user-extent-source-storage-2391049-1794459629440117879/process-access-inventory.json'
kernel_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/user-extent-source-storage-2391049-1794459629440117879/kernel.elf'
output_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/stack-retirement-readbacks/baseline-linear/transcript.json'

import gdb,json,hashlib
from pathlib import Path
graph=json.loads(Path(graph_path).read_text())
assert hashlib.sha256(Path(kernel_path).read_bytes()).hexdigest()==graph['kernel_sha256']
base=graph['function_address']
rows=gdb.selected_inferior().architecture().disassemble(base,base+graph['function_bytes'])
transcript=[dict(offset=row['addr']-base,size=row['length'],assembly=row['asm']) for row in rows]
raw=(json.dumps(transcript,sort_keys=True)+'\n').encode()
Path(output_path).write_bytes(raw)
print(json.dumps(dict(passed=True,rows=len(transcript),sha256=hashlib.sha256(raw).hexdigest())))

end
quit
