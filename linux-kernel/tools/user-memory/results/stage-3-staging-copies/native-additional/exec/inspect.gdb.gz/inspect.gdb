set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/user-extent-source-exec-2361657-1794442846200280714/kernel.elf"
target remote 127.0.0.1:46381
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/user-extent-source-exec-2361657-1794442846200280714/source-user-extents/observations.json'
component={'base': 5701632, 'command_source_sha256': 'cac5afad81808c0123175a2de8b1e799c70579f9a5ef81445bb3a66433f9e3ef', 'conservative_user_stack_bytes': 1304, 'entry': 5708672, 'exec_source_sha256': '60605da3006e86b576892c157e83031061172466c121dde0a8a81a7977c6a634', 'file_source_sha256': '757a45600b38e0746659781ba6e14aa5a90ec9d378cf364fd555299890ef92fa', 'image_sha256': 'a09cd7d430d5671c5a269bb183e15d54d25e08b51a3c73a46ce51dd688f40a6c', 'linked_sha256': 'c92b8f656af7754fca5585be7e3d877113117ae5934ef8a2d66e124a03ab03a0', 'mode': 'exec', 'pipe_source_sha256': None, 'poll_source_sha256': None, 'scope': 'source-built ordinary syscall component in a freshly generated first-party ABI witness; not an arbitrary-program loader or production qualification', 'serial_source_sha256': None, 'shell_source_sha256': '574462c620fb4e2db01bc4140e98377f52d4add8eddc3e4a9fa0428d2a3d8db4', 'signal_source_sha256': None, 'source_sha256': '49758cc99552709eb1fe062b26dbcb189ae93ead0755139a56f0dd532017ca6c', 'stack_frame_costs': {'command-cases': 104, 'exec-cases': 152, 'file-cases': 400, 'shell-cases': 168, 'source-cases': 496, 'startup-cases': 168}, 'startup': 5702592, 'startup_call': 5711328, 'startup_source_sha256': '2c5171f997c27d084883f6dce969747c191ab41649864e5c1d73f2367bb574aa', 'storage_source_sha256': None, 'syscall': 5711280, 'syscall4': 5711296, 'text_bytes': 9893}
immutable_head='7f454c4602010103000000000000000002003e000100000080654a00000000004000000000000000000000000000000000000000400038000b000000000000000100000004000000000000000000000000004000000000000000400000000000e006000000000000e0060000000000000010000000000000010000000500000000100000000000000010400000000000001040000000000085b218000000000085b21800000000000010000000000000010000000400000000d018000000000000d058000000000000d0580000000000407005000000000040700500000000000010000000000000010000000600000060461e000000000060565e0000000000'
serial_sites=None
serial_patterns=[('544f50414c5f534f555243455f53455249414c5f410a', '5561626364656667'), ('544f50414c5f534f555243455f53455249414c5f420a', '3132333435363738')]
extent_inventory=None
native_sites={'halt': 45795254, 'exits': [45689968, 45691612]}

import gdb
import hashlib
import json
import struct
import traceback

def reg(name): return int(gdb.parse_and_eval('$'+name)) & ((1<<64)-1)
def address(name): return int(gdb.parse_and_eval('(unsigned long long)&'+name))
def memory(pointer, size): return bytes(gdb.selected_inferior().read_memory(pointer, size)) if size else b''
def words(pointer, count): return list(struct.unpack('<'+'Q'*count, memory(pointer, count*8)))
def word(pointer): return words(pointer, 1)[0]
def signed(value): return value if value < (1<<63) else value-(1<<64)
def state(): return words(address('topal_x86_frame_mm_state_v1'), 4)
def prefix(pages): return hashlib.sha256(memory(0x5f7000, pages*4096)).hexdigest()
def credentials_pointer():
    return word(context+920)+96 if memory(context+896,1)[0] == 1 else 0x7fff18
def file_controls():
    return (memory(context+472,152)+memory(context+736,160)).hex()

context = address('topal_bootstrap_storage') + 512
current = pending = startup_current = bridge_current = None
component_returns = {}
syscall_returns = {}
observed = dict(passed=False, executions=[], startup_executions=[], file_executions=[], shell_executions=[], command_executions=[], poll_executions=[], bridge_returns=[])
callee = ['rbx', 'rbp', 'r12', 'r13', 'r14', 'r15']

class Checked(gdb.Breakpoint):
    def stop(self):
        try:
            return self.observe()
        except Exception:
            traceback.print_exc()
            observed['observer_failure'] = traceback.format_exc()
            observed['active_startup'] = startup_current
            observed['active_bridge'] = bridge_current
            with open(observation_path, 'w') as handle:
                json.dump(observed, handle, indent=2)
            return True

class SourceReturned(Checked):
    def observe(self):
        global current
        self.enabled = False
        assert current and pending is None and reg('cs') & 3 == 3
        assert reg('rax') == 0, ('source case failed', reg('rax'), current)
        assert reg('rsp') == current['stack']+8
        assert {name:reg(name) for name in callee} == current['callee']
        after = state()
        assert after[1:3] == current['before'][1:3], (after, current['before'])
        assert prefix(after[2]) == current['prefix_before']
        assert word(context+904) == current['snapshot']
        assert hashlib.sha256(memory(current['snapshot']+0x9e00,512)).hexdigest() == current['command_before']
        if component.get('mode') == 'exec':
            return exec_returned(current,after)
        if component.get('mode') == 'signals':
            return signal_returned(current,after)
        if component.get('mode') == 'pipes':
            return pipe_returned(current,after)
        if component.get('mode') == 'storage':
            return storage_returned(current,after)
        if component.get('mode') == 'serial':
            return serial_returned(current,after)
        calls = current['calls']
        expected_numbers = [12,12,63,63,63,63,63,63,63,1,1,1,1]
        original = current['before'][1]
        expected_results = [original,0x63a000,0,0]+[-14]*5+[0,-9,-22,-14]
        if component.get('mode') == 'transfers':
            expected_numbers += [1,1,1,79]
            expected_results += [-14,24,24,len(current['cwd_expected'])//2]
            assert [row['args'] for row in calls[13:17]] == [
                [1,0x639fff,2],[1,0x5ffff8,24],[1,0x638ff8,24],[0x638fff,5,0]]
            assert word(word(context+928)+40) == current['cwd_before']
            assert calls[16]['output_hex'] == current['cwd_expected']
        assert [row['number'] for row in calls] == expected_numbers+[12], calls
        expected_results += [original]
        assert [row['result'] for row in calls] == expected_results, calls
        assert [row['args'][0] for row in calls[2:9]] == [
            0x5ffff8,0x638ff8,0x639fff,0x63a000,(1<<64)-1,0x400000,0x800000]
        assert calls[0]['args'][0] == 0 and calls[1]['args'][0] == 0x63a000
        assert [row['args'] for row in calls[9:13]] == [
            [1,(1<<64)-1,0],[0,(1<<64)-1,0],
            [1,(1<<64)-1,257],[1,(1<<64)-1,1]]
        assert calls[-1]['args'][0] == original
        current['after'] = after
        observed['executions'].append(current)
        print('SOURCE_USER_CASES_PASS', len(observed['executions']), len(calls), flush=True)
        current = None
        return False

class SourceEntered(Checked):
    def observe(self):
        global current
        assert current is None and pending is None
        assert reg('cs') & 3 == 3 and reg('cr0') & (1<<16)
        stack = reg('rsp')
        assert 0x7fe000 <= stack < 0x800000 and stack % 16 == 8
        return_site = word(stack)
        assert 0x4e0000 <= return_site < 0x4e8000
        before = state()
        assert before[1] == 0x5f7000+before[2]*4096
        snapshot = word(context+904)
        assert snapshot
        current = dict(stack=stack, before=before, prefix_before=prefix(before[2]),
                       callee={name:reg(name) for name in callee}, calls=[],
                       snapshot=snapshot,
                       command_before=hashlib.sha256(memory(snapshot+0x9e00,512)).hexdigest())
        if component.get('mode') == 'transfers':
            current['cwd_before'] = word(word(context+928)+40)
            current['cwd_expected'] = {3:b'/\0',4:b'/bin\0',6:b'/tmp\0'}[current['cwd_before']].hex()
        if component.get('mode') == 'signals':
            current['table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
        if component.get('mode') == 'pipes':
            current['pipe_table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
            current['_pipe_initial'] = memory(word(context+928)+PIPE_BASE,PIPE_BYTES).hex()
        if component.get('mode') == 'storage':
            current['storage_table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
            current['_storage_initial'] = memory(word(context+928)+STORAGE_BASE,STORAGE_BYTES).hex()
        if component.get('mode') == 'serial':
            current['serial_table_before_sha256'] = hashlib.sha256(memory(word(context+928),8192)).hexdigest()
            current['serial_received']=[]
            current['serial_markers']=0
        if return_site not in component_returns:
            component_returns[return_site] = SourceReturned('*'+hex(return_site), internal=True)
        component_returns[return_site].enabled = True
        return False

class SyscallReturned(Checked):
    def observe(self):
        global pending
        self.enabled = False
        assert (current or startup_current) and pending and reg('cs') & 3 == 3
        pending['result'] = signed(reg('rax'))
        pending['phase_after'] = memory(context+104,1)[0]
        copy_source_syscall_returned(pending)
        staged_source_syscall_returned(pending)
        if current and component.get('mode') == 'transfers' and pending['number'] == 79:
            expected = bytes.fromhex(current['cwd_expected'])
            assert pending['result'] == len(expected), pending
            pending['output_hex'] = memory(pending['args'][0],len(expected)).hex()
            assert pending['output_hex'] == current['cwd_expected'], pending
        if current and component.get('mode') == 'exec' and pending['number'] == 59:
            observe_exec_result(pending)
        if current and component.get('mode') == 'signals' and pending['number'] in [13,14]:
            observe_signal_result(pending)
        if current and component.get('mode') == 'pipes' and pending['number'] != 12:
            pipe_result(pending)
        if current and component.get('mode') == 'storage' and pending['number'] != 12:
            storage_result(pending)
        if current and component.get('mode') == 'serial' and pending['number'] != 12:
            serial_result(pending)
        if startup_current and startup_current.get('kind') == 'poll':
            observe_poll_result(pending)
        if startup_current and startup_current.get('kind') in ['shell','command']:
            observe_shell_result(pending)
        if startup_current and startup_current.get('kind') == 'file':
            n = pending['number']
            result = pending['result']
            if (n in [5,262] and result == 0) or (n == 217 and result > 0):
                pointer = pending['args'][2 if n == 262 else 1]
                pending['output_hex'] = memory(pointer,result if n == 217 else 144).hex()
        if pending['result'] in [-14,-22] or pending['number'] == 12:
            assert pending['phase_after'] == pending['phase_before'], pending
        if startup_current and startup_current.get('kind') == 'file' and pending['result'] == -14:
            assert file_controls() == pending['controls_before'], pending
        (current or startup_current)['calls'].append(pending)
        pending = None
        return False

class SyscallEntered(Checked):
    def __init__(self, specification, count):
        super().__init__(specification, internal=True)
        self.count = count

    def observe(self):
        global pending
        assert (current or startup_current) and pending is None and reg('cs') & 3 == 3
        pending = dict(number=reg('rdi'),
                       args=[reg(name) for name in ['rsi','rdx','rcx','r8'][:self.count]],
                       phase_before=memory(context+104,1)[0])
        copy_source_syscall_entered(pending)
        staged_source_syscall_entered(pending)
        if current and component.get('mode') == 'exec' and pending['number'] == 59:
            observe_exec_request(pending)
        if current and component.get('mode') == 'signals' and pending['number'] in [13,14]:
            observe_signal_request(pending)
        if current and component.get('mode') == 'pipes' and pending['number'] != 12:
            pipe_request(pending)
        if current and component.get('mode') == 'storage' and pending['number'] != 12:
            storage_request(pending)
        if current and component.get('mode') == 'serial' and pending['number'] != 12:
            serial_request(pending)
        if startup_current and startup_current.get('kind') == 'poll':
            observe_poll_request(pending)
        if startup_current and startup_current.get('kind') in ['shell','command']:
            observe_shell_request(pending)
        if startup_current and startup_current.get('kind') == 'file':
            pending['controls_before'] = file_controls()
            if pending['number'] in [257,262] and pending['args'][1] == 0x637ff8:
                data = memory(0x637ff8,64)
                pending['pathname_hex'] = data[:data.index(0)+1].hex()
        return_site = word(reg('rsp'))
        assert component['base'] <= return_site < component['base']+component['text_bytes']
        if return_site not in syscall_returns:
            syscall_returns[return_site] = SyscallReturned('*'+hex(return_site), internal=True)
        syscall_returns[return_site].enabled = True
        return False

class StartupReturned(Checked):
    def observe(self):
        global startup_current
        self.enabled = False
        row = startup_current
        if row and row.get('kind') == 'poll':
            return poll_returned(row)
        if row and row.get('kind') in ['shell','command']:
            return shell_returned(row)
        if row and row.get('kind') == 'file':
            return file_returned(row)
        assert row and current is None and pending is None
        assert reg('cs') & 3 == 3 and reg('rsp') == row['stack']+8
        assert {name:reg(name) for name in callee} == row['callee']
        assert credentials_pointer() == row['credentials_pointer']
        assert words(row['credentials_pointer'],8) == row['credentials']
        n = row['number']
        expected = -2 if n == 262 else (8 if n == 318 else 0)
        assert signed(reg('rax')) == expected, ('startup source failed', signed(reg('rax')), row)
        after = state()
        assert after[1:3] == row['before'][1:3]
        assert prefix(after[2]) == row['prefix_before']
        calls = row['calls']
        assert calls[0]['number'] == calls[1]['number'] == calls[-1]['number'] == 12
        assert calls[0]['args'][0] == 0 and calls[1]['args'][0] == 0x63a000
        assert [calls[i]['result'] for i in [0,1,-1]] == [row['before'][1],0x63a000,row['before'][1]]
        assert calls[-1]['args'][0] == row['before'][1]
        assert all(call['number'] == n for call in calls[2:-1])
        if n == 262:
            assert [call['result'] for call in calls[2:-1]] == [-14]*4+[-2]
            assert [call['args'][1] for call in calls[2:-1]] == [
                0x63a000,(1<<64)-1,0x800000,0x639fff,0x638ff8]
            assert calls[-2]['args'][2] == (1<<64)-1
            assert memory(row['destination'],144).hex() == row['output_before']
        else:
            errors = calls[2:-2]
            if n == 318:
                assert [call['result'] for call in errors[:3]] == [0,-22,-22]
                assert [call['args'][:3] for call in errors[:3]] == [
                    [(1<<64)-1,0,1],[(1<<64)-1,8,8],[(1<<64)-1,17,1]]
                errors = errors[3:]
            assert [call['result'] for call in errors] == [-14]*5
            index = 3 if n == 302 else (1 if n == 157 else 0)
            assert [call['args'][index] for call in errors] == [
                0x63a000,(1<<64)-1,0x400000,0x800000,0x639fff]
            assert calls[-2]['args'][index] == (0x5ffff8 if n == 302 else 0x638ff8)
            assert calls[-2]['result'] == expected
            output = memory(row['destination'],8 if n == 318 else 16)
            if n == 302: assert output == struct.pack('<QQ',0x800000,(1<<64)-1)
            if n == 157: assert output == b'busybox'+bytes(9)
            row['output_after'] = output.hex()
        row['after'] = after
        row['phase_after'] = memory(context+104,1)[0]
        expected_phase = {302:6,318:6,157:10,262:12}[n]
        # Exec retains an active descriptor/namespace owner. Its general
        # pathname service runs before the sealed startup fallback and does
        # not advance that fallback's phase.
        if n == 262 and row['table_active']:
            expected_phase = row['phase_before']
        assert row['phase_after'] == expected_phase, row
        observed['startup_executions'].append(row)
        print('SOURCE_STARTUP_CASES_PASS', len(observed['startup_executions']), n, len(calls), flush=True)
        startup_current = None
        return False

class StartupEntered(Checked):
    def observe(self):
        global startup_current
        assert current is startup_current is pending is None
        assert reg('cs') & 3 == 3 and reg('cr0') & (1<<16)
        stack = reg('rsp')
        assert 0x7fe000 <= stack < 0x800000 and stack % 16 == 8
        return_site = word(stack)
        assert component['base'] <= return_site < component['base']+component['text_bytes']
        args = [reg(name) for name in ['rsi','rdx','rcx','r8']]
        n = reg('rdi')
        if component.get('mode') == 'poll':
            return poll_entered(n,args,stack,return_site)
        if (n == 0 and (args[0] == 0 or args[2] == 1)) or n in [1,13,16,63,79,80]:
            return shell_entered(n,args,stack,return_site)
        if n in [5,257,217,0] or (n == 262 and args[1] != 0x4a6900):
            return file_entered(n,args,stack,return_site)
        assert n in [302,318,157,262]
        destination = args[{302:3,318:0,157:1,262:2}[n]]
        before = state()
        startup_current = dict(number=n,args=args,stack=stack,before=before,
            prefix_before=prefix(before[2]),callee={name:reg(name) for name in callee},
            calls=[],destination=destination,
            output_before=memory(destination,144 if n == 262 else (8 if n == 318 else 16)).hex(),
            phase_before=memory(context+104,1)[0],
            table_active=word(word(context+928)) == 1,
            credentials_pointer=credentials_pointer(),credentials=words(credentials_pointer(),8))
        assert startup_current['credentials'] == [11,0,12,0,13,0,14,0]
        assert startup_current['phase_before'] == ({302:5,318:6,157:9,262:11}[n])
        if return_site not in component_returns:
            component_returns[return_site] = StartupReturned('*'+hex(return_site), internal=True)
        component_returns[return_site].enabled = True
        return False

class BridgeReturned(Checked):
    def observe(self):
        global bridge_current
        self.enabled = False
        row = bridge_current
        assert row and current is startup_current is pending is None
        assert reg('rsp') == row['stack']+8 and reg('cs') & 3 == 3
        assert {name:reg(name) for name in row['registers']} == row['registers']
        assert credentials_pointer() == row['credentials_pointer']
        assert words(row['credentials_pointer'],8) == [11,0,12,0,13,0,14,0]
        observed['bridge_returns'].append(row)
        bridge_current = None
        return False

class BridgeEntered(Checked):
    def observe(self):
        global bridge_current
        assert current is startup_current is pending is bridge_current is None
        stack = reg('rsp')
        site = word(stack)
        assert 0x4a6100 <= site < 0x4b0000
        bridge_current = dict(stack=stack,return_site=site,credentials_pointer=credentials_pointer(),
            registers={name:reg(name) for name in callee+['rdi','rsi','rdx','r10','r8','r9']})
        if site not in component_returns:
            component_returns[site] = BridgeReturned('*'+hex(site), internal=True)
        component_returns[site].enabled = True
        return False

def file_entered(n,args,stack,return_site):
    global startup_current
    assert word(word(context+928)) == 0, 'bounded file fixture must precede table activation'
    before = state()
    assert before[1:3] == [0x619000,34]
    destination = args[2] if n == 262 else args[1]
    size = 0 if n == 257 else (512 if n == 217 else (128 if n == 0 else 144))
    path = None
    if n in [257,262]:
        data = memory(args[1],64)
        path = data[:data.index(0)+1].hex()
    startup_current = dict(kind='file',number=n,args=args,stack=stack,before=before,
        prefix_before=prefix(before[2]),callee={name:reg(name) for name in callee},calls=[],
        destination=destination,output_before=memory(destination,size).hex(),
        output_size=size,path=path,credentials_pointer=credentials_pointer(),
        credentials=words(credentials_pointer(),8),phase_before=memory(context+104,1)[0],
        controls_before=file_controls())
    assert startup_current['credentials'] == [11,0,12,0,13,0,14,0]
    if return_site not in component_returns:
        component_returns[return_site] = StartupReturned('*'+hex(return_site), internal=True)
    component_returns[return_site].enabled = True
    return False

def file_returned(row):
    global startup_current
    assert current is None and pending is None and reg('cs') & 3 == 3
    assert reg('rsp') == row['stack']+8
    assert {name:reg(name) for name in callee} == row['callee']
    assert credentials_pointer() == row['credentials_pointer']
    assert words(row['credentials_pointer'],8) == row['credentials']
    after = state()
    assert after[1:3] == row['before'][1:3]
    assert prefix(after[2]) == row['prefix_before']
    n = row['number']
    calls = row['calls']
    assert calls[0]['number'] == calls[1]['number'] == calls[-1]['number'] == 12
    assert [calls[i]['args'][0] for i in [0,1,-1]] == [0,0x63a000,0x619000]
    assert [calls[i]['result'] for i in [0,1,-1]] == [0x619000,0x63a000,0x619000]
    actions = calls[2:-1]
    assert all(c['number'] == n for c in actions)
    path = bytes.fromhex(row['path']) if row['path'] else None
    if n in [257,262]:
        assert [c['args'][1] for c in actions[:4]] == [0x63a000,(1<<64)-1,0x800000,0x639fff]
        assert [c['result'] for c in actions[:4]] == [-14]*4
        actions = actions[4:]
        assert all(c['args'][1] == 0x637ff8 and c['pathname_hex'] == row['path'] for c in actions)
    if n == 257:
        expected = -2 if path == b'/dev/tty\0' else 3
        assert len(actions) == 1 and actions[0]['result'] == expected
    elif n == 0:
        expected = 0
        assert [c['args'][1] for c in actions] == [(1<<64)-1,(1<<47)-4096-127,0x63a000]
        assert [c['result'] for c in actions] == [-14,-14,0]
    elif n == 262 and path == b'/var/spool/mail/root\0':
        expected = -2
        assert len(actions) == 1 and actions[0]['result'] == -2 and actions[0]['args'][2] == 0x63a000
    elif n == 217 and len(actions) == 1:
        expected = 0
        assert actions[0]['args'][1] == 0x63a000 and actions[0]['result'] == 0
    else:
        expected = actions[-1]['result']
        assert expected in ([72,80] if n == 217 else [0])
        index = 2 if n == 262 else 1
        assert [c['args'][index] for c in actions[:-1]] == [0x63a000,(1<<64)-1,0x400000,0x800000,0x639fff]
        assert [c['result'] for c in actions[:-1]] == [-14]*5
        actual = 0x639fb0 if n == 217 else (0x5ffff8 if n == 5 and row['args'][0] == 1 else 0x638ff8)
        assert actions[-1]['args'][index] == actual
        size = expected if n == 217 else 144
        assert memory(row['destination'],size).hex() == actions[-1]['output_hex']
        before = bytes.fromhex(row['output_before'])
        assert memory(row['destination']+size,len(before)-size) == before[size:]
        row['output_after'] = memory(row['destination'],size).hex()
    assert signed(reg('rax')) == expected, ('file source failed',signed(reg('rax')),row)
    if 'output_after' not in row:
        assert memory(row['destination'],row['output_size']).hex() == row['output_before']
    row['after'] = after
    row['phase_after'] = memory(context+104,1)[0]
    observed['file_executions'].append(row)
    print('SOURCE_FILE_CASES_PASS',len(observed['file_executions']),n,len(calls),flush=True)
    startup_current = None
    return False


def protected_controls():
    return (memory(context+152,104)+memory(context+416,8)).hex()+file_controls()
def command_state():
    snapshot = word(context+904)
    assert snapshot
    return memory(snapshot+0x9e00,512).hex()
def masked_prefix(pages,pointer,size):
    data = bytearray(memory(0x5f7000,pages*4096))
    left,right=max(pointer,0x5f7000),min(pointer+size,0x5f7000+len(data))
    if right>left: data[left-0x5f7000:right-0x5f7000] = bytes(right-left)
    return hashlib.sha256(data).hexdigest()
def shell_shape(n,args):
    a,b,c,d=args
    if n==16: return False,0,c
    input = n in [1,80] or (n==13 and b!=0)
    size = 390 if n==63 else (32 if n==13 else (2 if n in [79,80] else c))
    pointer = (b if b else c) if n==13 else (a if n in [63,79,80] else b)
    return input,size,pointer

def shell_entered(n,args,stack,return_site):
    global startup_current
    command = n==0 and args[0]==0
    input,size,pointer = (False,args[2],args[1]) if command else shell_shape(n,args)
    before = state()
    assert before[1:3]==[0x619000,34]
    write_pointer,write_size = (0,0) if input else (pointer,size)
    startup_current = dict(kind='command' if command else 'shell',number=n,args=args,
        stack=stack,before=before,callee={name:reg(name) for name in callee},calls=[],
        input=bool(input),size=size,pointer=pointer,
        original_bytes=memory(pointer,size if size else 1).hex(),
        write_pointer=write_pointer,write_size=write_size,
        prefix_before=masked_prefix(before[2],write_pointer,write_size),
        credentials_pointer=credentials_pointer(),credentials=words(credentials_pointer(),8),
        phase_before=memory(context+104,1)[0],queue_before=command_state())
    assert startup_current['credentials']==[11,0,12,0,13,0,14,0]
    if return_site not in component_returns:
        component_returns[return_site]=StartupReturned('*'+hex(return_site),internal=True)
    component_returns[return_site].enabled=True
    return False

def observe_shell_request(call):
    call['protected_before']=protected_controls()
    call['queue_before']=command_state()
    row=startup_current
    if row['kind']=='shell' and row['input'] and call['number']==row['number']:
        index=1 if call['number'] in [1,13] else 0
        pointer=call['args'][index]
        if pointer in [0x638ff8,0x638fff] or component['base']<=pointer<component['base']+component['text_bytes']:
            call['input_hex']=memory(pointer,row['size']).hex()

def observe_shell_result(call):
    row=startup_current
    call['queue_after']=command_state()
    if call['result']==-14:
        assert protected_controls()==call['protected_before'],call
    if row['kind']=='shell' and not row['input'] and call['number']==row['number'] and call['result']>=0:
        n=call['number']
        if n!=16:
            index=2 if n==13 else (0 if n in [63,79] else 1)
            call['output_hex']=memory(call['args'][index],row['size']).hex()

def shell_returned(row):
    global startup_current
    assert current is None and pending is None and reg('cs')&3==3
    assert reg('rsp')==row['stack']+8
    assert {name:reg(name) for name in callee}==row['callee']
    assert credentials_pointer()==row['credentials_pointer']
    assert words(row['credentials_pointer'],8)==row['credentials']
    after=state()
    assert after[1:3]==row['before'][1:3]
    assert masked_prefix(after[2],row['write_pointer'],row['write_size'])==row['prefix_before']
    calls=row['calls']
    assert [calls[i]['number'] for i in [0,1,-1]]==[12,12,12]
    assert [calls[i]['args'][0] for i in [0,1,-1]]==[0,0x63a000,0x619000]
    assert [calls[i]['result'] for i in [0,1,-1]]==[0x619000,0x63a000,0x619000]
    if row['kind']=='command':
        command_returned(row)
    else:
        n,args,size,input=row['number'],row['args'],row['size'],row['input']
        actions=calls[2:-1]
        assert all(call['number']==n for call in actions)
        if n==16:
            expected=-25
            assert len(actions)==1 and actions[0]['args'][2]==(1<<64)-1
            assert memory(row['pointer'],1).hex()==row['original_bytes']
        else:
            index=1 if n in [1,13,0] and (n!=13 or input) else (2 if n==13 else 0)
            bad=[0x63a000,(1<<64)-1,0x800000,0x63b000 if size==1 else 0x639fff]
            if not input: bad.append(0x400000)
            assert [call['args'][index] for call in actions[:-1]]==bad
            assert [call['result'] for call in actions[:-1]]==[-14]*len(bad)
            expected=size if n in [0,1,79] else 0
            good=actions[-1]
            assert good['result']==expected
            if input:
                assert good['input_hex']==row['original_bytes']
                if n==13: assert component['base']<=good['args'][index]<component['base']+component['text_bytes']
                assert memory(row['pointer'],size).hex()==row['original_bytes']
            else:
                assert memory(row['pointer'],size).hex()==good['output_hex']
            row['output_after']=memory(row['pointer'],size).hex()
        assert signed(reg('rax'))==expected,('shell case failed',signed(reg('rax')),row)
        observed['shell_executions'].append(row)
        print('SOURCE_SHELL_CASES_PASS',len(observed['shell_executions']),n,len(calls),flush=True)
    row['after']=after
    row['phase_after']=memory(context+104,1)[0]
    startup_current=None
    return False

def command_returned(row):
    actions=row['calls'][2:-1]
    assert [call['number'] for call in actions]==[0]*10
    count=row['args'][2]
    assert [call['args'][1] for call in actions]==[
        (1<<64)-1,0x63a000,(1<<64)-1,0x400000,0x800000,0x639fff,
        0x638ff8,(1<<64)-1,0x639fff,0x638ff9]
    assert [call['args'][2] for call in actions]==[0]+[count]*5+[1,0,count,count]
    assert [call['result'] for call in actions[:9]]==[0]+[-14]*5+[1,0,-14]
    rest=actions[-1]['result']
    assert rest>0 and signed(reg('rax'))==rest+1
    assert all(call['phase_after']==call['phase_before'] for call in actions[:-1])
    assert actions[0]['queue_before']==actions[0]['queue_after']
    assert actions[1]['queue_after']==actions[2]['queue_after']==actions[3]['queue_after']==actions[4]['queue_after']==actions[5]['queue_after']
    assert actions[6]['queue_after']==actions[7]['queue_after']==actions[8]['queue_after']
    serial=count==23
    def queue(call):
        data=bytes.fromhex(call['queue_after'])
        return data[:256],struct.unpack_from('<QQQ',data,256)
    if serial:
        queued=queue(actions[1]); short=queue(actions[6]); complete=queue(actions[-1])
        assert queued[1][1]==23 and short[1][1]==22 and complete[1][1]==0
        assert short[0][:22]==queued[0][1:23] and short[0][22:]==bytes(234)
        assert complete[0]==bytes(256)
    else:
        assert queue(actions[1])[1][0]==0 and queue(actions[6])[1][0]==1
        assert queue(actions[-1])[1][0]==0
    before=bytes.fromhex(row['original_bytes'])
    total=rest+1
    assert memory(row['pointer']+total,len(before)-total)==before[total:]
    row['delivered_hex']=memory(row['pointer'],total).hex()
    observed['command_executions'].append(row)
    print('SOURCE_COMMAND_CASES_PASS',len(observed['command_executions']),total,len(row['calls']),flush=True)



def exec_protected():
    table = word(context+928)
    assert word(table) == 1
    return dict(table_sha256=hashlib.sha256(memory(table,8192)).hexdigest(),
        registrations=memory(context+152,104).hex(),
        shell=memory(context+416,8).hex(),files=memory(context+736,160).hex(),
        command=memory(word(context+904)+0x9e00,512).hex(),
        snapshot=word(context+904),auxiliary=word(context+920))

def observe_exec_request(call):
    call['protected_before'] = exec_protected()
    assert memory(word(context+904)+0x9800,0x600) == bytes(0x600)
    name,argv,envp = call['args']
    def candidate(address,size):
        # Read only the candidate's actual mapped portion, including code data.
        if component['base'] <= address < component['base']+component['text_bytes']:
            return memory(address,min(size,component['base']+component['text_bytes']-address))
        if 0x5f7000 <= address < 0x63a000:
            return memory(address,min(size,0x63a000-address))
        return b''
    call['pathname_prefix_hex'] = candidate(name,256).hex()
    call['argv_prefix_hex'] = candidate(argv,72).hex()
    call['environment_prefix_hex'] = candidate(envp,136).hex()

def observe_exec_result(call):
    assert call['result'] in [-14,-2,-36,-22,-7],call
    assert exec_protected() == call['protected_before'],call
    assert memory(word(context+904)+0x9800,0x600) == bytes(0x600)
    call['private_staging_zero'] = True
    call['protected_state_unchanged'] = True

def exec_returned(row,after):
    global current
    calls = row['calls']
    assert [c['number'] for c in calls] == [12,12]+[59]*29+[12]
    assert [calls[i]['args'][0] for i in [0,1,-1]] == [0,0x63a000,0x619000]
    assert [calls[i]['result'] for i in [0,1,-1]] == [0x619000,0x63a000,0x619000]
    actions=calls[2:-1]
    expected = [-14]*5+[-2,-36]+[-14]*10+[-22,-7,-7]+[-14]*6+[-7]*3
    assert len(expected)==29
    assert [c['result'] for c in actions] == expected
    assert all(c['private_staging_zero'] and c['protected_state_unchanged'] for c in actions)
    assert [c['args'][0] for c in actions[:5]] == [0,0x63a000,(1<<64)-1,0x800000,0x639fff]
    assert [c['args'][1] for c in actions[7:12]] == [0,0x63a000,(1<<64)-4,0x800000,0x639ffc]
    assert actions[12]['args'][1] == 0x5ffffc
    assert actions[13]['args'][:2] == [0x638ff8,0x637ffc]
    assert component['base'] <= actions[14]['args'][1] < component['base']+component['text_bytes']
    assert actions[16]['args'][1] == 0x639ff0
    assert actions[23]['args'][2] == 0x639ffc
    assert actions[25]['args'][2] == 0x639ff0
    row['after'] = after
    observed['executions'].append(row)
    print('SOURCE_EXEC_CASES_PASS',len(observed['executions']),len(actions),flush=True)
    current = None
    return False



def signal_read(pointer,size):
    if component['base'] <= pointer < component['base']+component['text_bytes']:
        return memory(pointer,min(size,component['base']+component['text_bytes']-pointer))
    if 0x5f7000 <= pointer < 0x63a000:
        return memory(pointer,min(size,0x63a000-pointer))
    if pointer == 0x400000:
        return memory(pointer,size)
    return b''

def signal_writable(pointer,size):
    return 0x5f7000 <= pointer and pointer+size <= 0x63a000

def signal_context():
    return (memory(context+152,104)+memory(context+416,8)+memory(context+736,160)+
            memory(word(context+904)+0x9e00,512)).hex()

def signal_state(table):
    return dict(blocked=struct.unpack_from('<Q',table,32)[0],
        action10=list(struct.unpack_from('<4Q',table,1792+9*32)))

def observe_signal_request(call):
    table=memory(word(context+928),8192)
    assert word(word(context+928)) == 1
    assert table[1408:1664] == bytes(256)
    call['_table_before'] = table.hex()
    call['state_before'] = signal_state(table)
    call['context_before'] = signal_context()
    size=32 if call['number']==13 else 8
    _,new,old,_=call['args']
    call['input_hex'] = signal_read(new,size).hex() if new else ''
    call['old_output_prefix_before'] = signal_read(old,size).hex() if old else ''

def observe_signal_result(call):
    table=bytearray.fromhex(call.pop('_table_before'))
    number=call['number']
    selector,new,old,sigsetsize=call['args']
    size=32 if number==13 else 8
    input_bytes=bytes.fromhex(call['input_hex'])
    expected=0
    output=None
    committed=False
    if sigsetsize!=8: expected=-22
    elif new and len(input_bytes)!=size: expected=-14
    elif number==13:
        if not 1<=selector<=64 or (new and selector in [9,19]): expected=-22
        else:
            at=1792+(selector-1)*32
            output=bytes(table[at:at+32])
            if new:
                handler,flags,restorer,mask=struct.unpack('<4Q',input_bytes)
                table[at:at+32]=struct.pack('<4Q',handler,flags&0xdc000807,restorer,mask&~0x40100)
                committed=True
    else:
        output=bytes(table[32:40])
        if new:
            if selector not in [0,1,2]: expected=-22
            else:
                requested=struct.unpack('<Q',input_bytes)[0]&~0x40100
                previous=struct.unpack('<Q',output)[0]
                value=[previous|requested,previous&~requested,requested][selector]
                table[32:40]=struct.pack('<Q',value)
                committed=True
    if expected==0 and old:
        if signal_writable(old,size):
            assert memory(old,size)==output,call
            call['output_hex']=output.hex()
        else: expected=-14
    assert call['result']==expected,call
    actual=memory(word(context+928),8192)
    assert actual==bytes(table),call
    assert signal_context()==call['context_before'],call
    if expected<0 and old:
        assert signal_read(old,size).hex()==call['old_output_prefix_before'],call
    assert actual[1408:1664]==bytes(256)
    call['state_after']=signal_state(actual)
    call['committed']=committed
    call['complete_table_verified']=True
    call['private_staging_zero']=True

def signal_returned(row,after):
    global current
    calls=row['calls']
    assert [c['number'] for c in calls]==[12,12]+[13]*23+[14]*23+[12]
    assert [calls[i]['result'] for i in [0,1,-1]]==[0x619000,0x63a000,0x619000]
    actions=calls[2:-1]
    assert all(c['complete_table_verified'] and c['private_staging_zero'] for c in actions)
    assert sum(c['result']==-14 for c in actions)==22
    assert sum(c['result']==-22 for c in actions)==6
    assert sum(c['result']==0 for c in actions)==18
    assert sum(c['committed'] for c in actions)==10
    assert sum(c['committed'] and c['result']==-14 for c in actions)==2
    assert hashlib.sha256(memory(word(context+928),8192)).hexdigest()==row['table_before_sha256']
    row['after']=after
    observed['executions'].append(row)
    print('SOURCE_SIGNAL_CASES_PASS',len(observed['executions']),len(actions),flush=True)
    current=None
    return False



def poll_controls():
    return dict(registrations=memory(context+152,104).hex(),header=memory(context+416,8).hex(),
        stat_staging=memory(context+472,152).hex(),file=memory(context+736,160).hex(),queue=command_state())

def poll_bytes(pointer,size):
    if component['base']<=pointer<component['base']+component['text_bytes']:
        return memory(pointer,min(size,component['base']+component['text_bytes']-pointer))
    if 0x5f7000<=pointer<0x63a000:
        return memory(pointer,min(size,0x63a000-pointer))
    if pointer==0x400000: return memory(pointer,size)
    return b''

def poll_entered(n,args,stack,return_site):
    global startup_current
    assert n==0 and args[0]==3 and args[2]==1
    index=len(observed['poll_executions'])
    assert memory(context+416,1)==b'\x01'
    assert memory(context+888,4)==bytes([22+index,index,0,0])
    assert word(word(context+928))==0
    before=state()
    assert before[1:3]==[0x619000,34]
    startup_current=dict(kind='poll',number=n,args=args,stack=stack,before=before,
        index=index,callee={name:reg(name) for name in callee},calls=[],
        prefix_before=prefix(before[2]),credentials_pointer=credentials_pointer(),
        credentials=words(credentials_pointer(),8),controls_before=poll_controls())
    if return_site not in component_returns:
        component_returns[return_site]=StartupReturned('*'+hex(return_site),internal=True)
    component_returns[return_site].enabled=True
    return False

def observe_poll_request(call):
    call['controls_before']=poll_controls()
    n,args=call['number'],call['args']
    if n==7: call['input_hex']=poll_bytes(args[0],8).hex()
    if n==0: call['output_before']=poll_bytes(args[1],1).hex()

def observe_poll_result(call):
    expected=dict(call['controls_before'])
    fields=bytearray.fromhex(expected['file'])
    n,args,result=call['number'],call['args'],call['result']
    if n==7:
        assert args[1:3]==[1,(1<<64)-1]
        if result==1:
            assert struct.unpack('<iH',bytes.fromhex(call['input_hex'])[:6])==(3,1)
            after=memory(args[0],8)
            assert after[:6]==bytes.fromhex(call['input_hex'])[:6] and after[6:]==b'\x01\0'
            call['output_hex']=after.hex()
            fields[891-736]=1
        else:
            assert result==-14
            assert poll_bytes(args[0],8).hex()==call['input_hex']
    elif n==0:
        assert args[0]==3 and args[2]==1
        if result==1:
            assert fields[891-736]==1
            value=bytes([b'\x7fELF'[fields[889-736]]])
            assert memory(args[1],1)==value
            call['output_hex']=value.hex()
            fields[888-736]+=1
            fields[889-736]+=1
            fields[891-736]=0
        else:
            assert result==-14 and poll_bytes(args[1],1).hex()==call['output_before']
    else: assert n==12
    expected['file']=fields.hex()
    actual=poll_controls()
    assert actual==expected,call
    call['controls_after']=actual

def poll_returned(row):
    global startup_current
    assert current is pending is None and signed(reg('rax'))==1
    assert reg('rsp')==row['stack']+8 and reg('cs')&3==3
    assert {name:reg(name) for name in callee}==row['callee']
    assert words(row['credentials_pointer'],8)==row['credentials']
    assert state()[1:3]==row['before'][1:3] and prefix(34)==row['prefix_before']
    calls=row['calls']
    assert [c['number'] for c in calls]==[12,12]+[7]*8+[0]*5+[12]
    assert [calls[i]['result'] for i in [0,1,-1]]==[0x619000,0x63a000,0x619000]
    assert [c['result'] for c in calls[2:-1]]==[-14]*5+[1,-14,1]+[-14]*4+[1]
    assert memory(row['args'][1],1)==bytes([b'\x7fELF'[row['index']]])
    assert memory(context+888,4)==bytes([23+row['index'],row['index']+1,0,0])
    row['after']=state()
    observed['poll_executions'].append(row)
    print('SOURCE_POLL_CASES_PASS',len(observed['poll_executions']),len(calls),flush=True)
    startup_current=None
    return False



extent_first_reach = {}

class ExtentFirstReach(Checked):
    def __init__(self, row):
        super().__init__('*'+hex(extent_inventory['address']+row['offset']), internal=True)
        self.row = row

    def observe(self):
        self.enabled = False
        assert reg('cs') & 3 == 0 and reg('cr0') & (1<<16)
        offset = self.row['offset']
        assert offset not in extent_first_reach
        extent_first_reach[offset] = dict(offset=offset, target=self.row['target'],
            candidate=reg('r8'), length=reg('r9'), phase=memory(context+104,1)[0])
        return False

def extent_coverage_complete():
    if extent_inventory is None:
        return
    for name, complete in [('callbacks',callback_coverage_complete),
                           ('copies',copy_observation_complete),
                           ('staged',staged_observation_complete)]:
        if name in selected_extent_observers():
            complete()
    calls = extent_inventory['calls']
    assert extent_first_reach and set(extent_first_reach) <= {row['offset'] for row in calls}
    observed['extent_call_coverage'] = dict(
        observation_passed=True, total_sites=len(calls), reached_sites=len(extent_first_reach),
        reached=[extent_first_reach[offset] for offset in sorted(extent_first_reach)],
        unreached=[row for row in calls if row['offset'] not in extent_first_reach],
        kernel_sha256=extent_inventory['kernel_sha256'],
        inventory_sha256=extent_inventory['inventory_sha256'],
        scope='First reach before helper invocation in this selected execution only; no successful-admission, return, every-length/error-path, direct-access/dominance or production qualification claim')

def selected_extent_observers():
    groups = extent_inventory.get('native_observers',['callbacks','copies','staged'])
    assert groups and len(groups) == len(set(groups))
    assert set(groups) <= {'callbacks','copies','staged'}
    return groups

def install_extent_coverage():
    if extent_inventory is not None:
        for name, install in [('callbacks',install_callback_observation),
                              ('copies',install_copy_observation),
                              ('staged',install_staged_observation)]:
            if name in selected_extent_observers():
                install()
        assert address(extent_inventory['function']) == extent_inventory['address']
        if not extent_inventory.get('source_scoped_staged'):
            for row in extent_inventory['calls']:
                ExtentFirstReach(row)

import hashlib

callback_active = None
callback_registered = None
callback_counts = {}
callback_samples = {}
callback_live_sections = {}
callback_callee_registers = ['rbx','rbp','r12','r13','r14','r15']

def callback_translation(pointer):
    assert not (reg('cr4') & (1<<12))
    table = reg('cr3') & 0x000ffffffffff000
    path = []
    user, writable, noexecute = True, True, False
    for shift in [39,30,21,12]:
        assert table % 4096 == 0 and table < 0x40000000
        entry = word(table + ((pointer>>shift)&511)*8)
        assert entry & 1
        user = user and bool(entry&4)
        writable = writable and bool(entry&2)
        noexecute = noexecute or bool(entry&(1<<63))
        path.append(dict(shift=shift,table=table,entry=entry))
        if shift == 12 or (shift in [30,21] and entry&128):
            physical = (entry & (0x000fffffffffffff & ~((1<<shift)-1))) | (pointer&((1<<shift)-1))
            assert physical == pointer and not user and not noexecute
            return dict(path=path,physical=physical,effective_user=user,
                        effective_write=writable,effective_execute=not noexecute)
        table = entry & 0x000ffffffffff000
    raise AssertionError('missing translation leaf')

class CallbackRegistration(Checked):
    def observe(self):
        global callback_registered
        self.enabled = False
        assert callback_registered is None and reg('cs')&3 == 0
        assert word(reg('rsp')+8) == context
        rows = []
        for row in extent_inventory['callback_bindings']['callbacks']:
            actual = word(reg('rsp')+row['entry_stack_offset'])
            assert actual == row['target'] == address(row['native_export'])
            rows.append(dict(gs_slot=row['gs_slot'],argument=row['argument'],target=actual))
        callback_registered = rows
        return False

class CallbackReturned(Checked):
    def __init__(self, site):
        super().__init__('*'+hex(site['return_address']),internal=True)
        self.site = site

    def observe(self):
        global callback_active
        assert callback_active is not None and callback_active['site']==self.site['offset']
        before = callback_active
        assert reg('cs')&3 == 0 and reg('cr0')&(1<<16)
        assert reg('cr3') == before['cr3'] and reg('rsp') == before['rsp']
        assert [reg(r) for r in callback_callee_registers] == before['callee_registers']
        assert memory(context+296,64) == before['captured']
        assert memory(context+952,56) == before['registry']
        assert memory(before['table'],8192) == before['table_bytes']
        assert memory(context+104,1)[0] == before['phase']
        slot = self.site['gs_slot']
        callback_counts[self.site['offset']] = callback_counts.get(self.site['offset'],0)+1
        if self.site['offset'] not in callback_samples:
            callback_samples[self.site['offset']] = dict(
                offset=self.site['offset'],gs_slot=slot,target=before['target'],
                arguments=before['arguments'],result=reg('rax'),
                supervisor_translation=before['translation'],
                callee_registers_preserved=True,captured_arguments_preserved=True,
                callback_registry_preserved=True,complete_process_table_preserved=True)
        callback_active = None
        return False

class CallbackEntered(Checked):
    def __init__(self, site, row):
        super().__init__('*'+hex(site['address']),internal=True)
        self.site, self.row = site, row

    def observe(self):
        global callback_active
        assert callback_registered is not None and callback_active is None
        assert reg('cs')&3 == 0 and reg('cr0')&(1<<16) and not (reg('eflags')&0x200)
        row, site = self.row, self.site
        assert reg('rax') == word(context+row['gs_slot']) == row['target']
        assert reg('rsp') % 16 == 0
        translation = callback_translation(reg('rax'))
        if row['gs_slot'] not in callback_live_sections:
            checked = []
            for section in row['sections']:
                actual = hashlib.sha256(memory(section['address'],section['bytes'])).hexdigest()
                assert actual == section['linked_sha256']
                checked.append(dict(address=section['address'],bytes=section['bytes'],sha256=actual))
            callback_live_sections[row['gs_slot']] = checked
        if row['gs_slot'] == 952:
            # The complete file-open plan packs eight Boolean facts. Anonymous
            # creation has its own exact write/mutable/create combination.
            assert reg('rdi') < 256
            if site['offset'] == 226667:
                assert reg('rdi') == 1 | 8 | 32
        elif row['gs_slot'] == 984:
            assert reg('rdi') <= 0xffffffff
        elif row['gs_slot'] == 976:
            table = word(context+928)
            assert word(table)==1 and word(table+48)==1 and word(table+24)>=64
            assert reg('rdi') == word(table+16)
            assert [reg(r) for r in ['rsi','rdx','rcx']] == [64,62,16]
            assert memory(reg('rdi'),64).hex() == extent_inventory['callback_header_hex']
        elif row['gs_slot'] == 992:
            assert reg('rsi') == word(context+1000) and reg('rsi')
            assert reg('rdx') == word(context+256) == context and reg('rcx') == row['target']
        table = word(context+928)
        assert table
        callback_active = dict(site=site['offset'],target=reg('rax'),cr3=reg('cr3'),rsp=reg('rsp'),
            callee_registers=[reg(r) for r in callback_callee_registers],
            arguments=[reg(r) for r in ['rdi','rsi','rdx','rcx','r8','r9']],
            captured=memory(context+296,64),registry=memory(context+952,56),
            table=table,table_bytes=memory(table,8192),phase=memory(context+104,1)[0],
            translation=translation)
        return False

def install_callback_observation():
    if extent_inventory is None:
        return
    bindings = extent_inventory['callback_bindings']
    assert bindings['passed'] and bindings['kernel_sha256'] == extent_inventory['kernel_sha256']
    rows = {row['gs_slot']:row for row in bindings['callbacks']}
    CallbackRegistration('*'+hex(extent_inventory['address']),internal=True)
    for site in bindings['sites']:
        CallbackEntered(site,rows[site['gs_slot']])
        CallbackReturned(site)

def callback_coverage_complete():
    if extent_inventory is None:
        return
    assert callback_registered is not None and callback_active is None and callback_counts
    sites = extent_inventory['callback_bindings']['sites']
    observed['callback_observation'] = dict(passed=True,registered=callback_registered,
        counts=[dict(offset=offset,count=callback_counts[offset]) for offset in sorted(callback_counts)],
        samples=[callback_samples[offset] for offset in sorted(callback_samples)],
        live_sections=[dict(gs_slot=slot,sections=callback_live_sections[slot]) for slot in sorted(callback_live_sections)],
        unreached=[site for site in sites if site['offset'] not in callback_counts],
        scope='Actual callback registration/targets, supervisor-executable mapping, first-role live bytes and observed ABI/private-state preservation; not every callee path, hardware read-only protection, arbitrary pointer authority, complete memory effects or lifetime proof')

copy_pending = None
copy_active = None
copy_counts = {}
copy_samples = {}
copy_start_breakpoints = {}
copy_finish_breakpoints = {}
copy_call_breakpoints = {}
copy_result_breakpoints = {}
copy_source_scope = None
copy_source_refusals = []
copy_register_names = ['rax','rcx','rdx','rbx','rsp','rbp','rsi','rdi','r8','r9','r10','r11','r12','r13','r14','r15']
copy_preserved = [2,3,5,6,7,8,9,12,13,14,15]

def copy_source_enabled():
    return extent_inventory is not None and extent_inventory.get('source_scoped_copies',False)

def copy_source_syscall_entered(call):
    global copy_source_scope
    if not copy_source_enabled():
        return
    assert copy_source_scope is None and copy_pending is copy_active is None
    copy_source_scope = dict(number=call['number'],args=list(call['args']),
        phase_before=call['phase_before'],refusals=[])
    for points in [copy_call_breakpoints,copy_result_breakpoints,copy_start_breakpoints]:
        for point in points.values():
            assert not point.enabled
            point.enabled = call['number'] != 12
    assert not any(point.enabled for point in copy_finish_breakpoints.values())

def copy_source_syscall_returned(call):
    global copy_source_scope
    if not copy_source_enabled():
        return
    assert copy_source_scope is not None and copy_pending is copy_active is None
    scope = copy_source_scope
    assert (scope['number'],scope['args']) == (call['number'],call['args'])
    for event in scope['refusals']:
        assert call['result'] == -14 and call['phase_after'] == scope['phase_before']
        assert event['candidate'] in call['args']
        copy_source_refusals.append(dict(**event,number=call['number'],args=call['args'],
            result=call['result'],phase_before=scope['phase_before'],phase_after=call['phase_after']))
    for points in [copy_call_breakpoints,copy_result_breakpoints,copy_start_breakpoints]:
        for point in points.values(): point.enabled = False
    assert not any(point.enabled for point in copy_finish_breakpoints.values())
    copy_source_scope = None

def copy_mode(before=None):
    result = [reg('cr0'),reg('cr3'),reg('cr4')]
    assert reg('cs')&3 == 0 and result[0]&(1<<16) and not reg('eflags')&0x200
    assert not result[2]&(1<<12)
    if before is not None:
        assert result == before
    return result

def copy_mapping(pointer):
    table = reg('cr3') & 0x000ffffffffff000
    path, user, writable = [], True, True
    for shift in [39,30,21,12]:
        assert table % 4096 == 0 and table < 0x40000000
        entry = word(table+((pointer>>shift)&511)*8)
        assert entry&1
        user, writable = user and bool(entry&4), writable and bool(entry&2)
        path.append([table,shift,entry&~0x60])
        if shift == 12 or (shift in [30,21] and entry&128):
            physical = (entry & (0x000fffffffffffff & ~((1<<shift)-1))) | (pointer&((1<<shift)-1))
            return dict(path=path,physical=physical,user=user,writable=writable,leaf_shift=shift)
        table = entry & 0x000ffffffffff000
    raise AssertionError('missing copy translation')

def copy_range(pointer, size, user, writable):
    # Observation budget only, not a kernel limit or a grant of access.
    assert 0 <= size <= 0x40000 and pointer+size < 1<<64
    result = []
    remaining, at = size, pointer
    while remaining:
        amount = min(remaining,4096-(at&4095))
        mapping = copy_mapping(at)
        assert mapping['user'] == user and (not writable or mapping['writable'])
        if user:
            assert mapping['leaf_shift'] == 12
        else:
            assert mapping['physical'] == at
        assert mapping['physical']+amount <= 0x40000000
        result.append(dict(pointer=at,size=amount,**mapping))
        remaining, at = remaining-amount, at+amount
    return result

class CopyAdmissionCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row = row

    def observe(self):
        global copy_pending
        assert copy_pending is None and copy_active is None
        row = self.row
        copy_counts[row['name']]['attempts'] += 1
        copy_pending = dict(name=row['name'],candidate=reg('r8'),size=reg('r9'),
            registers=[reg(r) for r in copy_register_names],mode=copy_mode(),rsp=reg('rsp'),
            captured=memory(context+296,64),accepted=False)
        if copy_source_enabled():
            assert copy_source_scope is not None
            if row['call_offset'] not in extent_first_reach:
                extent_first_reach[row['call_offset']] = dict(offset=row['call_offset'],
                    target=next(r['target'] for r in extent_inventory['calls'] if r['offset']==row['call_offset']),
                    candidate=reg('r8'),length=reg('r9'),phase=memory(context+104,1)[0])
        return False

class CopyAdmissionResult(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['carry_gate']),internal=True)
        self.row = row

    def observe(self):
        global copy_pending
        assert copy_pending is not None and copy_pending['name'] == self.row['name']
        before = copy_pending
        copy_mode(before['mode'])
        assert reg('rsp') == before['rsp'] and word(reg('rsp')-8) == 0
        assert all(reg(copy_register_names[i]) == before['registers'][i] for i in copy_preserved)
        assert memory(context+296,64) == before['captured']
        if reg('eflags')&1:
            copy_counts[self.row['name']]['refused'] += 1
            if copy_source_enabled():
                copy_source_scope['refusals'].append(dict(name=before['name'],
                    call_offset=self.row['call_offset'],candidate=before['candidate'],size=before['size'],
                    helper_registers_preserved=True,captured_arguments_preserved=True))
            copy_pending = None
        else:
            copy_counts[self.row['name']]['admitted'] += 1
            copy_pending['accepted'] = True
        return False

class CopyStarted(Checked):
    def __init__(self,group):
        super().__init__('*'+hex(extent_inventory['address']+group['copy_offset']),internal=True)
        self.group = group

    def observe(self):
        global copy_active
        assert copy_pending is not None and copy_pending['accepted'] and copy_active is None
        # A debugger can revisit the REP PC between iterations. Observe its
        # initial state once, then resume ordinary execution to the completion
        # boundary; re-enable this breakpoint for the next invocation there.
        self.enabled = False
        copy_finish_breakpoints[self.group['copy_offset']].enabled = True
        assert copy_pending['name'] in self.group['cases']
        row = copy_rows[copy_pending['name']]
        before = copy_pending
        copy_mode(before['mode'])
        assert reg('rsp') == before['rsp'] and not reg('eflags')&(1<<10)
        assert memory(context+296,64) == before['captured']
        source, target, elements = reg('rsi'),reg('rdi'),reg('rcx')
        size = elements*row['copy_width']
        assert size == before['size'] and size < 1<<64
        assert (source if row['admitted_direction'] == 'read' else target) == before['candidate']
        source_map = copy_range(source,size,row['admitted_direction']=='read',False)
        target_map = copy_range(target,size,row['admitted_direction']=='write',True)
        assert all(a['physical']+a['size'] <= b['physical'] or b['physical']+b['size'] <= a['physical']
                   for a in source_map for b in target_map)
        tables = {entry[0] for m in source_map+target_map for entry in m['path']}
        assert all(m['physical']+m['size'] <= table or table+4096 <= m['physical']
                   for m in source_map+target_map for table in tables)
        payload = memory(source,size) if size else b''
        copy_active = dict(name=row['name'],source=source,target=target,size=size,
            elements=elements,source_map=source_map,target_map=target_map,payload=payload)
        return False

class CopyFinished(Checked):
    def __init__(self,group,size):
        super().__init__('*'+hex(extent_inventory['address']+group['copy_offset']+size),internal=True)
        self.group = group
        self.enabled = False

    def observe(self):
        global copy_active,copy_pending
        assert copy_active is not None and copy_pending is not None
        active, before = copy_active,copy_pending
        assert active['name'] == before['name'] and active['name'] in self.group['cases']
        row = copy_rows[active['name']]
        copy_mode(before['mode'])
        assert reg('rsp') == before['rsp'] and not reg('eflags')&(1<<10)
        assert reg('rcx') == 0 and reg('rsi') == active['source']+active['size']
        assert reg('rdi') == active['target']+active['size']
        assert memory(context+296,64) == before['captured']
        assert copy_range(active['source'],active['size'],row['admitted_direction']=='read',False) == active['source_map']
        assert copy_range(active['target'],active['size'],row['admitted_direction']=='write',True) == active['target_map']
        payload = memory(active['target'],active['size']) if active['size'] else b''
        assert payload == active['payload']
        counts = copy_counts[row['name']]
        counts['completed'] += 1
        counts['bytes'] += active['size']
        if row['name'] not in copy_samples:
            copy_samples[row['name']] = dict(name=row['name'],call_offset=row['call_offset'],
                copy_offset=row['copy_offset'],source=active['source'],target=active['target'],
                size=active['size'],elements=active['elements'],mode=before['mode'],
                source_map=active['source_map'],target_map=active['target_map'],
                payload_sha256=hashlib.sha256(payload).hexdigest(),
                helper_registers_preserved=True,captured_arguments_preserved=True,
                translation_observations_equal=True,exact_payload_equal=True)
        copy_active,copy_pending = None,None
        self.enabled = False
        copy_start_breakpoints[self.group['copy_offset']].enabled = True
        return False

def install_copy_observation():
    global copy_rows
    audits = [extent_inventory['copy_transfer_audit']]
    if extent_inventory.get('staging_copy_audit') is not None:
        audits.append(extent_inventory['staging_copy_audit'])
    if copy_source_enabled():
        assert extent_inventory.get('staging_copy_audit') is not None
        audits = [extent_inventory['staging_copy_audit']]
    assert all(a['passed'] and a['kernel_sha256'] == extent_inventory['kernel_sha256'] for a in audits)
    rows = [r for a in audits for r in a['cases']]
    groups = [g for a in audits for g in a['copy_groups']]
    copy_rows = {r['name']:r for r in rows}
    assert len(copy_rows) == len(rows) and len({g['copy_offset'] for g in groups}) == len(groups)
    for row in rows:
        copy_counts[row['name']] = dict(attempts=0,admitted=0,refused=0,completed=0,bytes=0)
        copy_call_breakpoints[row['name']] = CopyAdmissionCalled(row)
        copy_result_breakpoints[row['name']] = CopyAdmissionResult(row)
    for group in groups:
        sizes = {copy_rows[name]['copy_size'] for name in group['cases']}
        assert len(sizes) == 1
        copy_start_breakpoints[group['copy_offset']] = CopyStarted(group)
        copy_finish_breakpoints[group['copy_offset']] = CopyFinished(group,next(iter(sizes)))
    if copy_source_enabled():
        for points in [copy_call_breakpoints,copy_result_breakpoints,copy_start_breakpoints]:
            for point in points.values(): point.enabled = False

def copy_observation_complete():
    assert copy_pending is None and copy_active is None
    assert copy_source_scope is None
    assert sum(row['completed'] for row in copy_counts.values()) > 0
    assert all(row['attempts'] == row['admitted']+row['refused'] and row['admitted'] == row['completed']
               for row in copy_counts.values())
    observed['copy_transfer_observation'] = dict(passed=True,counts=copy_counts,
        samples=[copy_samples[name] for name in sorted(copy_samples)],
        unreached=[name for name,row in copy_counts.items() if not row['attempts']],
        kernel_sha256=extent_inventory['kernel_sha256'],
        audit_sha256=extent_inventory['staging_copy_audit_sha256'] if copy_source_enabled() else extent_inventory['copy_transfer_audit_sha256'],
        audit_kind='staging' if copy_source_enabled() else ('legacy-and-staging' if extent_inventory.get('staging_copy_audit') is not None else 'legacy'),
        scope='Every selected observed admission result and REP start/completion: preserved helper registers/captured arguments, actual candidate/count/DF, equal copied bytes, user/supervisor permissions, no observed physical overlap with counterparty/translation storage and unchanged boundary translation/control observations. Read-only GDB observation, not continuous check-to-copy stability, complete table/backing ownership, every possible path or production qualification')
    if extent_inventory.get('staging_copy_audit') is not None:
        observed['copy_transfer_observation']['staging_audit_sha256'] = extent_inventory['staging_copy_audit_sha256']
    if copy_source_enabled():
        assert len(copy_source_refusals) == sum(row['refused'] for row in copy_counts.values())
        observed['copy_transfer_observation']['source_syscall_refusals'] = copy_source_refusals
        observed['copy_transfer_observation']['source_syscall_scoped'] = True

staged_pending = None
staged_active = None
staged_counts = {}
staged_samples = {}
staged_start_breakpoints = {}
staged_finish_breakpoints = {}
staged_call_breakpoints = {}
staged_result_breakpoints = {}
staged_source_scope = None
staged_refusal_events = []

def staged_source_enabled():
    return extent_inventory is not None and extent_inventory.get('source_scoped_staged',False)

def staged_source_number(row):
    if row['direction'] == 'read':
        return 1
    if row['name'] == 'named-stat':
        return 262
    return {390:63,144:5,72:217,80:217}[row['length']]

def staged_source_syscall_entered(call):
    global staged_source_scope
    if not staged_source_enabled():
        return
    assert staged_source_scope is None and staged_pending is staged_active is None
    staged_source_scope = dict(number=call['number'],args=list(call['args']),
        phase_before=call['phase_before'],refusals=[])
    for row in extent_inventory['staged_transfer_audit']['cases']:
        enabled = staged_source_number(row) == call['number']
        for points in [staged_call_breakpoints,staged_result_breakpoints,staged_start_breakpoints]:
            assert not points[row['name']].enabled
            points[row['name']].enabled = enabled
        assert not staged_finish_breakpoints[row['name']].enabled

def staged_source_syscall_returned(call):
    global staged_source_scope
    if not staged_source_enabled():
        return
    assert staged_source_scope is not None and staged_pending is staged_active is None
    scope = staged_source_scope
    assert (scope['number'],scope['args']) == (call['number'],call['args'])
    for event in scope['refusals']:
        assert call['result'] == -14 and call['phase_after'] == scope['phase_before']
        index = 0 if call['number'] == 63 else (2 if call['number'] == 262 else 1)
        assert event['candidate'] == call['args'][index]
        staged_refusal_events.append(dict(**event,number=call['number'],args=call['args'],
            result=call['result'],phase_before=scope['phase_before'],phase_after=call['phase_after']))
    for name in staged_counts:
        for points in [staged_call_breakpoints,staged_result_breakpoints,staged_start_breakpoints]:
            points[name].enabled = False
        assert not staged_finish_breakpoints[name].enabled
    staged_source_scope = None

class StagedCalled(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['call_offset']),internal=True)
        self.row = row

    def observe(self):
        global staged_pending
        assert staged_pending is None and staged_active is None
        assert copy_pending is None and copy_active is None
        row = self.row
        assert reg('r9') == row['length'] and reg('gs_base') == context
        staged_counts[row['name']]['attempts'] += 1
        staged_pending = dict(name=row['name'],candidate=reg('r8'),size=reg('r9'),
            registers=[reg(r) for r in copy_register_names],mode=copy_mode(),rsp=reg('rsp'),
            captured=memory(context+296,64),accepted=False)
        if staged_source_enabled():
            assert staged_source_scope is not None
            assert staged_source_number(row) == staged_source_scope['number']
            counter = row['counterpart']
            pointer = context+counter['offset'] if counter['kind']=='gs' else counter['address']
            staged_pending['counterpart'] = pointer
            staged_pending['counterpart_before'] = memory(pointer,row['length'])
            if row['call_offset'] not in extent_first_reach:
                extent_first_reach[row['call_offset']] = dict(offset=row['call_offset'],
                    target=next(r['target'] for r in extent_inventory['calls'] if r['offset']==row['call_offset']),
                    candidate=reg('r8'),length=reg('r9'),phase=memory(context+104,1)[0])
        return False

class StagedResult(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['carry_gate']),internal=True)
        self.row = row

    def observe(self):
        global staged_pending
        assert staged_pending is not None and staged_pending['name'] == self.row['name']
        before = staged_pending
        copy_mode(before['mode'])
        assert reg('gs_base') == context
        assert reg('rsp') == before['rsp'] and word(reg('rsp')-8) == 0
        assert all(reg(copy_register_names[i]) == before['registers'][i] for i in copy_preserved)
        assert memory(context+296,64) == before['captured']
        if reg('eflags')&1:
            staged_counts[self.row['name']]['refused'] += 1
            if staged_source_enabled():
                data = memory(before['counterpart'],before['size'])
                assert data == before['counterpart_before']
                staged_source_scope['refusals'].append(dict(name=before['name'],
                    call_offset=self.row['call_offset'],candidate=before['candidate'],size=before['size'],
                    counterpart=before['counterpart'],counterpart_sha256=hashlib.sha256(data).hexdigest(),
                    counterpart_unchanged=True,helper_registers_preserved=True,captured_arguments_preserved=True))
            staged_pending = None
        else:
            staged_counts[self.row['name']]['admitted'] += 1
            staged_pending['accepted'] = True
        return False

class StagedStarted(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['start_offset']),internal=True)
        self.row = row

    def observe(self):
        global staged_active
        row = self.row
        assert staged_pending is not None and staged_pending['accepted'] and staged_active is None
        assert staged_pending['name'] == row['name']
        self.enabled = False
        staged_finish_breakpoints[row['name']].enabled = True
        before = staged_pending
        copy_mode(before['mode'])
        assert reg('gs_base') == context
        assert reg('rsp') == before['rsp'] and memory(context+296,64) == before['captured']
        assert reg(copy_register_names[row['user_register']]) == before['candidate']
        if row['index_register'] is not None:
            assert reg(copy_register_names[row['index_register']]) == 0
        counter = row['counterpart']
        counterpart = context+counter['offset'] if counter['kind']=='gs' else counter['address']
        source,target = (before['candidate'],counterpart) if row['direction']=='read' else (counterpart,before['candidate'])
        size = before['size']
        source_map = copy_range(source,size,row['direction']=='read',False)
        target_map = copy_range(target,size,row['direction']=='write',True)
        assert all(a['physical']+a['size'] <= b['physical'] or b['physical']+b['size'] <= a['physical']
                   for a in source_map for b in target_map)
        tables = {entry[0] for m in source_map+target_map for entry in m['path']}
        assert all(m['physical']+m['size'] <= table or table+4096 <= m['physical']
                   for m in source_map+target_map for table in tables)
        staged_active = dict(name=row['name'],source=source,target=target,size=size,
            source_map=source_map,target_map=target_map,payload=memory(source,size))
        return False

class StagedFinished(Checked):
    def __init__(self,row):
        super().__init__('*'+hex(extent_inventory['address']+row['end_offset']),internal=True)
        self.row = row
        self.enabled = False

    def observe(self):
        global staged_pending,staged_active
        row = self.row
        assert staged_pending is not None and staged_active is not None
        before,active = staged_pending,staged_active
        assert before['name'] == active['name'] == row['name']
        copy_mode(before['mode'])
        assert reg('gs_base') == context
        assert reg('rsp') == before['rsp'] and memory(context+296,64) == before['captured']
        assert reg(copy_register_names[row['user_register']]) == before['candidate']
        if row['index_register'] is not None:
            assert reg(copy_register_names[row['index_register']]) == row['length']
        assert copy_range(active['source'],active['size'],row['direction']=='read',False) == active['source_map']
        assert copy_range(active['target'],active['size'],row['direction']=='write',True) == active['target_map']
        payload = memory(active['target'],active['size'])
        assert payload == active['payload']
        counts = staged_counts[row['name']]
        counts['completed'] += 1
        counts['bytes'] += active['size']
        if row['name'] not in staged_samples:
            staged_samples[row['name']] = dict(name=row['name'],call_offset=row['call_offset'],
                start_offset=row['start_offset'],end_offset=row['end_offset'],
                source=active['source'],target=active['target'],size=active['size'],mode=before['mode'],
                source_map=active['source_map'],target_map=active['target_map'],
                payload_sha256=hashlib.sha256(payload).hexdigest(),
                helper_registers_preserved=True,captured_arguments_preserved=True,
                candidate_preserved=True,exact_payload_equal=True,translation_observations_equal=True)
        staged_pending,staged_active = None,None
        self.enabled = False
        staged_start_breakpoints[row['name']].enabled = True
        return False

def install_staged_observation():
    audit = extent_inventory['staged_transfer_audit']
    assert audit['passed'] and audit['kernel_sha256'] == extent_inventory['kernel_sha256']
    for row in audit['cases']:
        staged_counts[row['name']] = dict(attempts=0,admitted=0,refused=0,completed=0,bytes=0)
        staged_call_breakpoints[row['name']] = StagedCalled(row)
        staged_result_breakpoints[row['name']] = StagedResult(row)
        staged_start_breakpoints[row['name']] = StagedStarted(row)
        staged_finish_breakpoints[row['name']] = StagedFinished(row)
        if staged_source_enabled():
            for points in [staged_call_breakpoints,staged_result_breakpoints,staged_start_breakpoints]:
                points[row['name']].enabled = False

def staged_observation_complete():
    assert staged_pending is None and staged_active is None
    assert staged_source_scope is None
    assert sum(row['completed'] for row in staged_counts.values()) > 0
    assert all(row['attempts']==row['admitted']+row['refused'] and row['admitted']==row['completed']
               for row in staged_counts.values())
    observed['staged_transfer_observation'] = dict(passed=True,counts=staged_counts,
        samples=[staged_samples[name] for name in sorted(staged_samples)],
        unreached=[name for name,row in staged_counts.items() if not row['completed']],
        kernel_sha256=extent_inventory['kernel_sha256'],
        audit_sha256=extent_inventory['staged_transfer_audit_sha256'],
        scope='Every selected observed admission/transfer boundary: actual candidate/count and finite-loop indices, helper/captured argument preservation, exact payload equality, complete covered user/supervisor permissions and unchanged control/translation observations allowing hardware A/D. Observed source/destination ranges do not overlap each other or table pages on these translation paths. Not continuous stability, complete owner/counterpart authority, every syscall path or production qualification')
    if staged_source_enabled():
        assert len(staged_refusal_events) == sum(row['refused'] for row in staged_counts.values())
        observed['staged_transfer_observation']['source_syscall_refusals'] = staged_refusal_events
        observed['staged_transfer_observation']['source_syscall_scoped'] = True



PIPE_BASE=0x3e000
PIPE_BYTES=0x5000

def pipe_context():
    return (memory(context+152,104)+memory(context+416,8)+memory(context+736,160)+
            memory(word(context+904)+0x9e00,512)).hex()

def pipe_visible(pointer,size):
    for start,end in [(component['base'],component['base']+component['text_bytes']),
                      (0x5f7000,0x63a000),(0x400000,0x401000)]:
        if start<=pointer<end:
            return memory(pointer,min(size,end-pointer))
    return b''

def pipe_request(call):
    table=word(context+928)
    assert word(table)==1 and memory(table+1408,256)==bytes(256)
    call['_table_before']=memory(table,8192).hex()
    call['_pipe_before']=memory(table+PIPE_BASE,PIPE_BYTES).hex()
    call['context_before']=pipe_context()
    n=call['number']
    args=call['args']
    if n in [22,293]: pointer,size=args[0],8
    elif n==16: pointer,size=args[2],4
    else: pointer,size=args[1],min(args[2],16)
    if n!=3:
        call['buffer_before']=pipe_visible(pointer,size).hex()
        call['buffer_pointer']=pointer
        call['window_pointer']=pointer-1
        call['window_before']=pipe_visible(pointer-1,size+2).hex()
    if n in [0,1,3,16]:
        description=word(table+64+args[0]*16)
        assert 1<=description<=16
        call['description_index']=description
        call['description_before']=words(table+320+(description-1)*64,8)

def pipe_result(call):
    table=word(context+928)
    before_table=bytearray.fromhex(call.pop('_table_before'))
    before=bytearray.fromhex(call.pop('_pipe_before'))
    after=memory(table+PIPE_BASE,PIPE_BYTES)
    n,result=call['number'],call['result']
    args=call['args']
    expected_table=bytearray(before_table)
    expected=bytearray(before)
    output=b''
    if result<0:
        assert result in [-14,-11]
        if n!=3:
            assert pipe_visible(call['buffer_pointer'],len(bytes.fromhex(call['buffer_before']))).hex()==call['buffer_before']
    elif n in [22,293]:
        assert result==0
        free=[fd for fd in range(16) if struct.unpack_from('<Q',before_table,64+fd*16)[0]==0]
        pair=list(struct.unpack('<II',memory(args[0],8)))
        assert pair==free[:2]
        generation=struct.unpack_from('<Q',before,512)[0]+1
        index=next(i for i in range(4) if before[i*128:i*128+128]==bytes(128))
        current['pipe_index']=index
        call['pair']=pair
        call['generation']=generation
        call['object_index']=index
        descs=[struct.unpack_from('<Q',memory(table,8192),64+fd*16)[0] for fd in pair]
        assert descs[0]!=descs[1] and all(1<=d<=16 for d in descs)
        for endpoint,(fd,description) in enumerate(zip(pair,descs)):
            assert before_table[320+(description-1)*64:320+description*64]==bytes(64)
            struct.pack_into('<QQ',expected_table,64+fd*16,description,0)
            struct.pack_into('<8Q',expected_table,320+(description-1)*64,
                             5+endpoint,1,0x800|endpoint,0,generation,0,0,0)
        record=list(struct.unpack_from('<16Q',after,index*128))
        assert record[:9]==[1,generation,*descs,0,0,0,0,0o10600]
        assert record[9]==record[10]==record[11]==record[12]>0 and record[13:]==[0]*3
        expected[index*128:index*128+128]=after[index*128:index*128+128]
        struct.pack_into('<Q',expected,512,generation)
        output=struct.pack('<II',*pair)
    else:
        index=current['pipe_index']
        at=index*128
        ring=0x1000+index*4096
        cursor,count=struct.unpack_from('<QQ',before,at+32)
        if n==16:
            assert result==0 and args[1]==0x541b
            output=struct.pack('<I',count)
            assert memory(args[2],4)==output
        elif n in [0,1] and result>0:
            assert result<=args[2]
            if n==0:
                assert result==min(args[2],count)
                output=bytes(before[ring+(cursor+i)%4096] for i in range(result))
                assert memory(args[1],result)==output
                for i in range(result): expected[ring+(cursor+i)%4096]=0
                struct.pack_into('<QQ',expected,at+32,(cursor+result)%4096,count-result)
                timestamp_offsets=[72]
                call['output_hex']=output.hex()
            else:
                assert result==min(args[2],4096-count)
                data=bytes.fromhex(call['buffer_before'])
                assert len(data)>=result
                for i in range(result): expected[ring+(cursor+count+i)%4096]=data[i]
                struct.pack_into('<Q',expected,at+40,count+result)
                timestamp_offsets=[80,88]
            for offset in timestamp_offsets:
                assert struct.unpack_from('<Q',after,at+offset)[0]>0
                expected[at+offset:at+offset+8]=after[at+offset:at+offset+8]
        elif n==3:
            assert result==0 and call['description_before'][1]==1
            description=call['description_index']
            expected_table[64+args[0]*16:80+args[0]*16]=bytes(16)
            expected_table[320+(description-1)*64:320+description*64]=bytes(64)
            offset=16 if call['description_before'][0]==5 else 24
            struct.pack_into('<Q',expected,at+offset,0)
            if struct.unpack_from('<QQ',expected,at+16)==(0,0):
                expected[at:at+128]=bytes(128)
                expected[ring:ring+4096]=bytes(4096)
        else:
            assert n==0 and result==0 and count==0
    assert after==bytes(expected), (n,result,'FIFO bytes changed outside permitted transition')
    assert memory(table,8192)==bytes(expected_table), (n,result,'descriptor/staging change')
    assert pipe_context()==call['context_before']
    if n!=3:
        window=bytearray.fromhex(call['window_before'])
        if output:
            assert 1+len(output)<=len(window)
            window[1:1+len(output)]=output
        assert pipe_visible(call['window_pointer'],len(window))==bytes(window), (n,result,'user copy window')
        call['copy_window_verified']=True
    call['complete_fifo_state_verified']=True
    call['complete_table_verified']=True
    call['pipe_state_after_sha256']=hashlib.sha256(after).hexdigest()

def pipe_returned(row,after):
    global current
    calls=row['calls']
    assert len(calls)==36
    assert {n:sum(c['number']==n for c in calls) for n in [12,293,16,1,0,3]}=={
        12:3,293:6,16:10,1:6,0:9,3:2}
    actions=[c for c in calls if c['number']!=12]
    assert sum(c['result']==-14 for c in actions)==19
    assert sum(c['result']==-11 for c in actions)==1
    assert all(c['complete_fifo_state_verified'] and c['complete_table_verified'] for c in actions)
    table=word(context+928)
    assert hashlib.sha256(memory(table,8192)).hexdigest()==row['pipe_table_before_sha256']
    shared=memory(table+PIPE_BASE,PIPE_BYTES)
    old=bytearray.fromhex(row.pop('_pipe_initial'))
    struct.pack_into('<Q',old,512,struct.unpack_from('<Q',old,512)[0]+1)
    assert shared==bytes(old), 'FIFO object/ring not retired exactly; only generation history may advance'
    row['after']=after
    row['pipe_retirement_verified']=True
    observed['executions'].append(row)
    print('SOURCE_PIPE_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current=None
    return False



STORAGE_BASE=0x43000
STORAGE_BYTES=0x9000

def storage_word(data,offset): return struct.unpack_from('<Q',data,offset)[0]
def storage_put(data,offset,value): struct.pack_into('<Q',data,offset,value)

def storage_request(call):
    table=word(context+928)
    assert word(table)==1 and memory(table+1408,256)==bytes(256)
    call['_table_before']=memory(table,8192).hex()
    call['_storage_before']=memory(table+STORAGE_BASE,STORAGE_BYTES).hex()
    call['context_before']=pipe_context()
    n,args=call['number'],call['args']
    if n==257:
        raw=pipe_visible(args[1],64)
        path=raw[:raw.index(0)+1]
        call['path_hex']=path.hex()
        pointer,size=args[1],len(path)
    elif n in [0,1,17,18,217]:
        pointer,size=args[1],min(args[2],48)
    else:
        pointer=size=None
    if pointer is not None:
        call['buffer_before']=pipe_visible(pointer,size).hex()
        call['buffer_pointer']=pointer
        call['window_pointer']=pointer-1
        call['window_before']=pipe_visible(pointer-1,size+2).hex()
    if n!=257:
        index=word(table+64+args[0]*16)
        assert 1<=index<=16
        call['description_index']=index
        call['description_before']=words(table+320+(index-1)*64,8)

def storage_result(call):
    table=word(context+928)
    before_table=bytearray.fromhex(call.pop('_table_before'))
    before=bytearray.fromhex(call.pop('_storage_before'))
    actual=memory(table+STORAGE_BASE,STORAGE_BYTES)
    expected=bytearray(before)
    expected_table=bytearray(before_table)
    n,args,result=call['number'],call['args'],call['result']
    output=b''
    if result<0:
        assert result in [-14,-22]
        if 'buffer_pointer' in call:
            raw=bytes.fromhex(call['buffer_before'])
            assert pipe_visible(call['buffer_pointer'],len(raw))==raw
    elif n==257:
        free=[i for i in range(16) if storage_word(before_table,64+i*16)==0]
        assert result==free[0]
        index=word(table+64+result*16)
        assert 1<=index<=16
        at=320+(index-1)*64
        assert before_table[at:at+64]==bytes(64)
        path=bytes.fromhex(call['path_hex'])
        flags=args[2]
        if flags==0x410002:
            assert path==b'/tmp\0'
            identity=storage_word(before,0)
            slot=next(i for i in range(4) if before[256+i*128:384+i*128]==bytes(128))
            object_at=256+slot*128
            record=list(struct.unpack_from('<16Q',actual,object_at))
            mode=0o100000|(args[3]&0o7777&~storage_word(before_table,1664))
            assert record[:4]==[1,identity,0,mode]
            assert record[4]==record[5]==record[6]>0
            assert record[7:]==[0,1]+[0]*7
            expected[object_at:object_at+128]=actual[object_at:object_at+128]
            storage_put(expected,0,identity+1)
            kind=7
            call['object_identity']=identity
            call['object_slot']=slot
        else:
            assert (path,flags) in [(b'/bin/busybox\0',0),(b'/tmp\0',0x10000)]
            kind,identity=(3,5) if flags==0 else (4,6)
        status=(flags&~(0x80000|0x100|0x40|0x80|0x200))|0x8000
        struct.pack_into('<8Q',expected_table,at,kind,1,status,0,identity,0,0,0)
        struct.pack_into('<QQ',expected_table,64+result*16,index,0)
        call['fresh_description_verified']=True
    else:
        desc=call['description_before']
        desc_at=320+(call['description_index']-1)*64
        kind,_,_,position,identity,*_=desc
        if n==8:
            assert args[2] in [0,1]
            expected_position=args[1]+(position if args[2]==1 else 0)
            assert result==expected_position
            storage_put(expected_table,desc_at+24,result)
        elif n==217:
            assert kind==4 and identity==6 and position==0 and result==48
            records=bytearray(48)
            for i,(inode,name) in enumerate([(6,b'.\0'),(3,b'..\0')]):
                struct.pack_into('<QQHB',records,i*24,inode,i+1,24,4)
                records[i*24+19:i*24+19+len(name)]=name
            output=bytes(records)
            cursor=next((i+2 for i in range(4) if storage_word(before,64+i*16)),6)
            storage_put(expected_table,desc_at+24,cursor)
        elif n==3:
            assert result==0 and desc[1]==1
            expected_table[64+args[0]*16:80+args[0]*16]=bytes(16)
            expected_table[desc_at:desc_at+64]=bytes(64)
            if kind==7:
                object_at=next(256+i*128 for i in range(4)
                    if storage_word(before,256+i*128)==1 and storage_word(before,264+i*128)==identity)
                assert storage_word(before,object_at+56)==0
                for slot in range(8):
                    page=1024+slot*32
                    if storage_word(before,page)==identity:
                        assert before[24+slot]==1
                        expected[24+slot]=0
                        expected[page:page+32]=bytes(32)
                        expected[4096+slot*4096:8192+slot*4096]=bytes(4096)
                expected[object_at:object_at+128]=bytes(128)
        elif n in [0,1,17,18]:
            offset=args[3] if n in [17,18] else position
            if kind==3:
                assert n==17 and result==min(args[2],256,storage_word(before_table,24)-offset)
                output=bytes.fromhex(immutable_head)[offset:offset+result]
                assert len(output)==result
            else:
                assert kind==7
                object_at=next(256+i*128 for i in range(4)
                    if storage_word(before,256+i*128)==1 and storage_word(before,264+i*128)==identity)
                size=storage_word(before,object_at+16)
                writing=n in [1,18]
                if writing:
                    assert result==min(args[2],256,4096-offset%4096)
                else:
                    assert result==min(args[2],256,4096-offset%4096,max(size-offset,0))
                if result:
                    pages=[i for i in range(8) if storage_word(before,1024+i*32)==identity
                           and storage_word(before,1032+i*32)==offset//4096]
                    if writing and not pages:
                        pages=[i for i in range(8) if storage_word(actual,1024+i*32)==identity
                               and storage_word(actual,1032+i*32)==offset//4096]
                        assert len(pages)==1
                        slot=pages[0]
                        assert before[24+slot]==0 and before[1024+slot*32:1056+slot*32]==bytes(32)
                        assert before[4096+slot*4096:8192+slot*4096]==bytes(4096)
                        expected[24+slot]=1
                        struct.pack_into('<4Q',expected,1024+slot*32,identity,offset//4096,0,0)
                    if pages:
                        assert len(pages)==1
                        start=4096+pages[0]*4096+offset%4096
                    if writing:
                        data=bytes.fromhex(call['buffer_before'])[:result]
                        assert len(data)==result
                        expected[start:start+result]=data
                        storage_put(expected,object_at+16,max(size,offset+result))
                        for timestamp in [40,48]:
                            assert storage_word(actual,object_at+timestamp)>0
                            expected[object_at+timestamp:object_at+timestamp+8]=actual[object_at+timestamp:object_at+timestamp+8]
                    else:
                        output=bytes(before[start:start+result]) if pages else bytes(result)
                    if n in [0,1]: storage_put(expected_table,desc_at+24,offset+result)
            if n in [17,18]:
                assert word(table+desc_at+24)==position
                call['positional_position_preserved']=True
        else:
            raise AssertionError(('unexpected storage call',n,result))
    assert actual==bytes(expected), (n,result,'filesystem mutation outside selected contract')
    assert memory(table,8192)==bytes(expected_table), (n,result,'description/staging mutation')
    assert pipe_context()==call['context_before']
    if 'window_before' in call:
        window=bytearray.fromhex(call['window_before'])
        if output:
            assert 1+len(output)<=len(window)
            window[1:1+len(output)]=output
            assert memory(call['buffer_pointer'],len(output))==output
            call['output_hex']=output.hex()
        assert pipe_visible(call['window_pointer'],len(window))==bytes(window), (n,result,'copy window')
        call['copy_window_verified']=True
    call['complete_storage_state_verified']=True
    call['complete_table_verified']=True

def storage_returned(row,after):
    global current
    calls=row['calls']
    assert len(calls)==52
    assert {n:sum(c['number']==n for c in calls) for n in [12,257,1,8,0,17,18,3,217]}=={
        12:3,257:3,1:5,8:5,0:7,17:15,18:5,3:3,217:6}
    actions=[c for c in calls if c['number']!=12]
    assert sum(c['result']==-14 for c in actions)==28
    assert sum(c['result']==-22 for c in actions)==1
    assert all(c['complete_storage_state_verified'] and c['complete_table_verified'] for c in actions)
    table=word(context+928)
    assert hashlib.sha256(memory(table,8192)).hexdigest()==row['storage_table_before_sha256']
    expected=bytearray.fromhex(row.pop('_storage_initial'))
    storage_put(expected,0,storage_word(expected,0)+1)
    assert memory(table+STORAGE_BASE,STORAGE_BYTES)==bytes(expected), 'filesystem reclamation/history'
    row['after']=after
    row['storage_retirement_verified']=True
    observed['executions'].append(row)
    print('SOURCE_STORAGE_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current=None
    return False



class SerialAdmission(Checked):
    def observe(self):
        assert current and pending and pending['number']==0 and pending['args'][0]==0
        assert reg('cs')&3==0 and reg('cr0')&(1<<16)
        assert reg('r8')==pending['args'][1] and reg('r9')==min(pending['args'][2],256)
        assert 'extent_call' not in pending
        pending['extent_call']=dict(candidate=reg('r8'),length=reg('r9'))
        return False

class SerialByte(Checked):
    def observe(self):
        assert current and pending and pending['number']==0 and pending['args'][0]==0
        assert reg('cs')&3==0 and reg('cr0')&(1<<16) and reg('rdx')&0xffff==0x3f8
        assert 'extent_call' in pending
        assert reg('rsi')==word(context+928)+1408+len(pending['uart_bytes'])
        pending['uart_bytes'].append(reg('rax')&255)
        assert len(pending['uart_bytes'])<=pending['extent_call']['length']
        return False

def serial_request(call):
    table=word(context+928)
    assert word(table)==1 and memory(table+1408,256)==bytes(256)
    call['table_before_sha256']=hashlib.sha256(memory(table,8192)).hexdigest()
    call['context_before']=pipe_context()
    n,args=call['number'],call['args']
    assert n in [0,1]
    call['uart_bytes']=[]
    size=min(args[2],256)
    call['buffer_before']=pipe_visible(args[1],size).hex()
    call['window_pointer']=args[1]-1
    call['window_before']=pipe_visible(args[1]-1,size+2).hex()

def serial_result(call):
    table=word(context+928)
    n,args,result=call['number'],call['args'],call['result']
    output=b''
    data=bytes(call['uart_bytes'])
    expected=b''.join(bytes.fromhex(payload) for _,payload in serial_patterns)
    if n==1:
        marker=bytes.fromhex(serial_patterns[current['serial_markers']][0])
        assert args[0]==1 and result==args[2]==len(marker)
        assert bytes.fromhex(call['buffer_before'])==marker and not data
        current['serial_markers']+=1
    elif result<0:
        assert result in [-14,-9] and not data
        assert pipe_visible(args[1],len(bytes.fromhex(call['buffer_before']))).hex()==call['buffer_before']
    elif result==0:
        assert args[0]==0 and args[2]==0 and not data and 'extent_call' not in call
    else:
        assert args[0]==0 and 0<result<=min(args[2],256) and len(data)==result
        start=len(current['serial_received'])
        assert data==expected[start:start+result]
        assert memory(args[1],result)==data
        current['serial_received']+=list(data)
        output=data
        call['output_hex']=data.hex()
    window=bytearray.fromhex(call['window_before'])
    if output:
        assert 1+len(output)<=len(window)
        window[1:1+len(output)]=output
    assert pipe_visible(call['window_pointer'],len(window))==bytes(window)
    assert hashlib.sha256(memory(table,8192)).hexdigest()==call['table_before_sha256']
    assert pipe_context()==call['context_before']
    assert call['phase_after']==call['phase_before']
    call['copy_window_verified']=True
    call['complete_table_verified']=True
    call['native_input_verified']=True

def serial_returned(row,after):
    global current
    calls=row['calls']
    assert 16<=len(calls)<=29
    assert sum(c['number']==12 for c in calls)==3 and sum(c['number']==1 for c in calls)==2
    assert all(c['number'] in [0,1,12] for c in calls)
    assert sum(c['result']==-14 for c in calls)==5
    assert sum(c['result']==-9 for c in calls)==2
    assert row['serial_markers']==2
    assert bytes(row['serial_received'])==b'Uabcdefg12345678'
    requests=[c for c in calls if c['number']!=12]
    assert all(c['copy_window_verified'] and c['complete_table_verified'] and c['native_input_verified'] for c in requests)
    large=[c for c in requests if c['number']==0 and c['args'][2]==512]
    assert len(large)==1 and large[0]['extent_call']==dict(candidate=0x639f00,length=256)
    assert hashlib.sha256(memory(word(context+928),8192)).hexdigest()==row['serial_table_before_sha256']
    row['after']=after
    row['serial_input_verified']=True
    observed['executions'].append(row)
    print('SOURCE_SERIAL_CASES_PASS',len(observed['executions']),len(calls),flush=True)
    current=None
    return False

def install_serial_observation():
    if component.get('mode')=='serial':
        SerialAdmission('*'+hex(serial_sites['admission']),internal=True)
        SerialByte('*'+hex(serial_sites['byte_received']),internal=True)


class Complete(Checked):
    def observe(self):
        assert current is startup_current is pending is bridge_current is None and observed['executions']
        numbers = [row['number'] for row in observed['startup_executions']]
        if component.get('mode') in ['exec','signals','poll','pipes','storage','serial']:
            assert len(observed['executions']) == 4
            assert all(not observed[key] for key in [
                'startup_executions','file_executions','shell_executions','command_executions'])
        else:
            assert numbers and len(numbers) % 5 == 0
        assert numbers == [302,318,318,157,262]*(len(numbers)//5)
        assert [row['number'] for row in observed['file_executions']] == ([] if component.get('mode') in ['exec','signals','poll','pipes','storage','serial'] else [
            5,257,262,257,5,0,257,5,217,217,262,257,5,217,217,262,262,262,257,257]
        )
        assert len(observed['command_executions']) == (0 if component.get('mode') in ['exec','signals','poll','pipes','storage','serial'] else 5)
        assert len(observed['shell_executions']) == (0 if component.get('mode') in ['exec','signals','poll','pipes','storage','serial'] else 38)
        assert len(observed['poll_executions']) == (4 if component.get('mode') == 'poll' else 0)
        assert len(observed['bridge_returns']) == len(numbers)+len(observed['file_executions'])+len(observed['shell_executions'])+len(observed['command_executions'])+len(observed['poll_executions'])
        assert state() == [0,0,0,0]
        assert memory(address('topal_x86_frame_mm_tokens_v1'), 48) == bytes(48)
        assert word(context+904) == 0 and memory(context+152,16) == bytes(16)
        assert memory(context+416,8) == bytes(8)
        for snapshot in {row['snapshot'] for row in observed['executions']}:
            assert memory(snapshot+0x9e00,512) == bytes(512)
        extent_coverage_complete()
        observed['passed'] = True
        with open(observation_path, 'w') as handle:
            json.dump(observed, handle, indent=2)
        return True

class InvariantHalt(Checked):
    def observe(self):
        observed['invariant_failure'] = dict(phase=memory(context+104,1)[0],
            heap=state(),current=current,pending=pending)
        with open(observation_path, 'w') as handle:
            json.dump(observed, handle, indent=2)
        print('SOURCE_USER_INVARIANT_FAILURE', observed['invariant_failure'], flush=True)
        return True

try:
    install_extent_coverage()
    install_serial_observation()
    SourceEntered('*'+hex(component['entry']), internal=True)
    StartupEntered('*'+hex(component['startup']), internal=True)
    BridgeEntered('*'+hex(component['startup_call']), internal=True)
    SyscallEntered('*'+hex(component['syscall']), 3)
    SyscallEntered('*'+hex(component['syscall4']), 4)
    InvariantHalt('*'+hex(native_sites['halt']), internal=True)
    Complete('*topal_x86_systems_fatal', internal=True)
    gdb.execute('continue')
    assert observed['passed']
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:
    traceback.print_exc()
    gdb.execute('quit 1')

end
