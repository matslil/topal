set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/tk283-staging-library-1794436636760343297/temporary/user-extent-callers-2343520-1794440017348382910/kernel.elf"
target remote 127.0.0.1:48167
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/tk283-staging-library-1794436636760343297/temporary/user-extent-callers-2343520-1794440017348382910/user-extent-callers/observations.json'
import sys
sys.path.insert(0,'/home/mats/git/topal/linux-kernel/tools/user-memory')
owner_bindings={'roles': [{'count': 5, 'pins': 1, 'slot': 7}, {'count': 1, 'pins': 1, 'slot': 6}, {'count': 503, 'pins': 1, 'slot': 5}, {'count': 2, 'pins': 2, 'slot': 8}], 'token_bytes': 336}
user_assertions=[5771297, 5771341, 5771373, 5771384, 5771395, 5771427, 5771438, 5771449, 5771507, 5771539, 5771580, 5775412, 5775440, 5775495, 5775550, 5775605, 5775630, 5775659, 5775679, 5779508, 5779536, 5779591, 5779646, 5779701, 5779730, 5783604, 5783632, 5783687, 5783742, 5783797, 5783826, 5787700, 5787728, 5787783, 5787838, 5787893, 5787918, 5787947, 5787967, 5791796, 5791824, 5791887, 5791942, 5791997, 5792007, 5792078, 5792088, 5792098, 5792130, 5792171, 5795892, 5795920, 5795983, 5796038, 5796093, 5796103, 5796174, 5796184, 5796194, 5796226, 5796267, 5799988, 5800016, 5800079, 5800134, 5800189, 5800199, 5800270, 5800280, 5800290, 5800322, 5800363, 5804084, 5804112, 5804175, 5804230, 5804285, 5804295, 5804366, 5804376, 5804386, 5804418, 5804459, 5750836, 5750864, 5750927, 5750982, 5751037, 5751047, 5751118, 5751128, 5751138, 5751170, 5751211, 5754932, 5754960, 5755023, 5755078, 5755133, 5755143, 5755214, 5755224, 5755234, 5755266, 5755307, 5759028, 5759056, 5759119, 5759174, 5759229, 5759239, 5759310, 5759320, 5759330, 5759362, 5759403, 5763124, 5763152, 5763215, 5763270, 5763325, 5763335, 5763406, 5763416, 5763426, 5763458, 5763499, 5701684, 5701712, 5701957, 5702022, 5702087, 5702115, 5702125, 5702135, 5702145, 5702155, 5702165, 5702175, 5702185, 5702195, 5702205, 5702215, 5702225, 5702235, 5702245, 5702255, 5702265, 5702275, 5702285, 5702295, 5702310, 5705780, 5705808, 5706077, 5706142, 5706207, 5706235, 5706245, 5706255, 5706265, 5706275, 5706285, 5706295, 5706305, 5706315, 5706325, 5706335, 5706345, 5706355, 5706365, 5706375, 5706385, 5706395, 5706405, 5706415, 5706425, 5706435, 5706445, 5706460, 5709876, 5709904, 5710019, 5710084, 5710157, 5710222, 5710287, 5710297, 5710378, 5710388, 5710398, 5710430, 5710466, 5710476, 5710486, 5710496, 5710506, 5710521, 5713972, 5714000, 5714179, 5714244, 5714317, 5714382, 5714447, 5714457, 5714538, 5714548, 5714558, 5714590, 5714626, 5714636, 5714646, 5714656, 5714666, 5714676, 5714686, 5714696, 5714706, 5714716, 5714726, 5714736, 5714746, 5714761, 5718068, 5718096, 5718275, 5718340, 5718413, 5718478, 5718543, 5718553, 5718634, 5718644, 5718654, 5718686, 5718722, 5718732, 5718742, 5718752, 5718762, 5718772, 5718782, 5718792, 5718802, 5718812, 5718822, 5718832, 5718842, 5718857, 5722164, 5722192, 5722371, 5722436, 5722509, 5722574, 5722639, 5722649, 5722730, 5722740, 5722750, 5722782, 5722818, 5722828, 5722838, 5722848, 5722858, 5722868, 5722878, 5722888, 5722898, 5722908, 5722918, 5722928, 5722938, 5722953, 5570612, 5570640, 5570737, 5570792, 5570802, 5570812, 5570840, 5570855, 5574708, 5574736, 5574833, 5574896, 5574906, 5574961, 5574971, 5574981, 5575009, 5575024, 5578804, 5578832, 5578929, 5578992, 5579002, 5579057, 5579067, 5579077, 5579105, 5579120, 5582900, 5582928, 5583025, 5583080, 5583090, 5583100, 5583128, 5583143, 5586996, 5587024, 5587121, 5587184, 5587194, 5587249, 5587259, 5587269, 5587297, 5587312, 5591092, 5591120, 5591217, 5591280, 5591290, 5591345, 5591355, 5591365, 5591393, 5591408, 5595188, 5595216, 5595313, 5595376, 5595386, 5595441, 5595451, 5595461, 5595489, 5595504, 5599284, 5599312, 5599409, 5599472, 5599482, 5599537, 5599547, 5599557, 5599585, 5599600, 5603380, 5603408, 5603505, 5603568, 5603578, 5603633, 5603643, 5603653, 5603681, 5603696, 5607476, 5607504, 5607601, 5607664, 5607674, 5607729, 5607739, 5607749, 5607777, 5607792, 5611572, 5611600, 5611697, 5611760, 5611770, 5611825, 5611835, 5611845, 5611873, 5611888, 5615668, 5615696, 5615793, 5615856, 5615866, 5615921, 5615931, 5615941, 5615969, 5615984, 5619764, 5619792, 5619889, 5619952, 5619962, 5620017, 5620027, 5620037, 5620065, 5620080, 5623860, 5623888, 5623985, 5624048, 5624058, 5624113, 5624123, 5624133, 5624161, 5624176, 5627956, 5627984, 5628081, 5628144, 5628154, 5628209, 5628219, 5628229, 5628257, 5628272, 5632052, 5632080, 5632177, 5632240, 5632250, 5632305, 5632315, 5632325, 5632353, 5632368, 5636148, 5636176, 5636273, 5636336, 5636346, 5636401, 5636411, 5636421, 5636449, 5636464, 5640244, 5640272, 5640369, 5640432, 5640442, 5640497, 5640507, 5640517, 5640545, 5640560, 5644340, 5644368, 5644465, 5644528, 5644538, 5644593, 5644603, 5644613, 5644641, 5644656, 5648436, 5648464, 5648561, 5648624, 5648634, 5648689, 5648699, 5648709, 5648737, 5648752, 5505076, 5505104, 5505185, 5505248, 5505258, 5505313, 5505341, 5505356, 5509172, 5509200, 5509281, 5509344, 5509354, 5509409, 5509437, 5509452, 5513307, 5513362, 5513368, 5517364, 5517392, 5517473, 5517536, 5517546, 5517601, 5517629, 5517644, 5521460, 5521488, 5521543, 5521598, 5521717, 5521727, 5521737, 5521747, 5521757, 5521767, 5521777, 5521787, 5521797, 5521868, 5521878, 5521888, 5521908, 5521928, 5521948, 5521968, 5521988, 5522008, 5522028, 5522048, 5522068, 5522109, 5525590, 5525596, 5529652, 5529680, 5529761, 5529824, 5529834, 5529889, 5529917, 5529932, 5533748, 5533776, 5533831, 5533886, 5534005, 5534015, 5534025, 5534035, 5534045, 5534055, 5534065, 5534075, 5534085, 5534156, 5534166, 5534176, 5534196, 5534216, 5534236, 5534256, 5534276, 5534296, 5534316, 5534336, 5534356, 5534376, 5534417, 5537878, 5537884, 5541940, 5541968, 5542049, 5542112, 5542122, 5542177, 5542205, 5542220, 5546036, 5546064, 5546145, 5546208, 5546218, 5546273, 5546301, 5546316, 5439540, 5439568, 5439649, 5439712, 5439722, 5439777, 5439805, 5439820, 5443670, 5443676, 5447732, 5447760, 5447815, 5447870, 5447933, 5447943, 5448014, 5448024, 5448034, 5448044, 5448054, 5448064, 5448074, 5448084, 5448094, 5448104, 5448114, 5448124, 5448134, 5448144, 5448154, 5448164, 5448174, 5448184, 5448194, 5448204, 5448214, 5448224, 5448234, 5448244, 5448254, 5448264, 5448274, 5448284, 5448294, 5448304, 5448314, 5448324, 5448334, 5448344, 5448354, 5448395, 5451828, 5451856, 5451911, 5451966, 5452029, 5452039, 5452110, 5452120, 5452130, 5452140, 5452150, 5452160, 5452170, 5452180, 5452190, 5452200, 5452210, 5452220, 5452230, 5452240, 5452250, 5452260, 5452270, 5452280, 5452290, 5452300, 5452310, 5452320, 5452330, 5452340, 5452350, 5452360, 5452370, 5452380, 5452390, 5452400, 5452410, 5452420, 5452430, 5452440, 5452450, 5452491, 5455924, 5455952, 5456033, 5456096, 5456106, 5456161, 5456189, 5456204, 5460020, 5460048, 5460103, 5460158, 5460221, 5460231, 5460302, 5460312, 5460322, 5460332, 5460342, 5460352, 5460362, 5460372, 5460382, 5460392, 5460402, 5460412, 5460422, 5460432, 5460442, 5460452, 5460462, 5460472, 5460482, 5460492, 5460502, 5460512, 5460522, 5460532, 5460542, 5460552, 5460562, 5460572, 5460582, 5460592, 5460602, 5460612, 5460622, 5460632, 5460642, 5460683, 5464150, 5464156, 5468246, 5468252, 5472342, 5472348, 5476438, 5476444, 5480500, 5480528, 5480609, 5480672, 5480682, 5480737, 5480765, 5480780, 5484601, 5484629, 5484684, 5484739, 5484810, 5484820, 5484830, 5484840, 5484881, 5488697, 5488725, 5488780, 5488835, 5488906, 5488916, 5488926, 5488936, 5488977, 5492793, 5492821, 5492876, 5492931, 5493002, 5493012, 5493022, 5493032, 5493073, 5496889, 5496917, 5496972, 5497027, 5497098, 5497108, 5497118, 5497128, 5497169, 5374009, 5374037, 5374099, 5374161, 5374231, 5374241, 5374319, 5374329, 5374339, 5374349, 5374359, 5374449, 5374519, 5374529, 5374539, 5374549, 5374559, 5374569, 5374579, 5374589, 5374599, 5374609, 5374619, 5374662, 5378105, 5378133, 5378195, 5378257, 5378327, 5378337, 5378415, 5378425, 5378435, 5378445, 5378455, 5378545, 5378615, 5378625, 5378635, 5378645, 5378655, 5378698, 5382201, 5382229, 5382291, 5382353, 5382423, 5382433, 5382511, 5382521, 5382531, 5382541, 5382551, 5382641, 5382711, 5382721, 5382731, 5382741, 5382751, 5382761, 5382771, 5382781, 5382791, 5382801, 5382811, 5382821, 5382831, 5382841, 5382851, 5382861, 5382871, 5382881, 5382891, 5382901, 5382911, 5382921, 5382931, 5382941, 5382951, 5382961, 5382971, 5382981, 5382991, 5383001, 5383011, 5383021, 5383031, 5383041, 5383051, 5383061, 5383071, 5383081, 5383091, 5383101, 5383111, 5383121, 5383131, 5383141, 5383151, 5383161, 5383171, 5383181, 5383191, 5383201, 5383211, 5383221, 5383231, 5383241, 5383251, 5383261, 5383271, 5383281, 5383291, 5383301, 5383311, 5383321, 5383331, 5383341, 5383351, 5383361, 5383371, 5383381, 5383391, 5383401, 5383411, 5383421, 5383431, 5383441, 5383451, 5383461, 5383471, 5383481, 5383491, 5383501, 5383511, 5383521, 5383531, 5383541, 5383551, 5383561, 5383571, 5383581, 5383591, 5383601, 5383611, 5383621, 5383631, 5383641, 5383651, 5383661, 5383671, 5383681, 5383691, 5383701, 5383711, 5383721, 5383731, 5383741, 5383751, 5383761, 5383771, 5383781, 5383791, 5383801, 5383811, 5383821, 5383831, 5383841, 5383851, 5383861, 5383871, 5383881, 5383891, 5383901, 5383911, 5383921, 5383931, 5383941, 5383951, 5383961, 5383971, 5383981, 5383991, 5384001, 5384011, 5384021, 5384031, 5384041, 5384051, 5384061, 5384071, 5384081, 5384091, 5384101, 5384111, 5384121, 5384131, 5384141, 5384151, 5384161, 5384171, 5384181, 5384191, 5384201, 5384211, 5384221, 5384231, 5384241, 5384251, 5384261, 5384271, 5384281, 5384291, 5384301, 5384311, 5384321, 5384331, 5384341, 5384351, 5384361, 5384371, 5384381, 5384391, 5384401, 5384411, 5384421, 5384431, 5384441, 5384451, 5384461, 5384471, 5384481, 5384491, 5384501, 5384511, 5384521, 5384531, 5384541, 5384551, 5384561, 5384571, 5384581, 5384591, 5384601, 5384611, 5384621, 5384631, 5384641, 5384651, 5384661, 5384671, 5384681, 5384691, 5384701, 5384711, 5384721, 5384731, 5384741, 5384751, 5384761, 5384771, 5384781, 5384791, 5384801, 5384811, 5384821, 5384831, 5384841, 5384851, 5384861, 5384871, 5384881, 5384891, 5384901, 5384911, 5384921, 5384931, 5384941, 5384951, 5384961, 5384971, 5384981, 5384991, 5385001, 5385011, 5385021, 5385031, 5385041, 5385051, 5385061, 5385071, 5385081, 5385091, 5385101, 5385111, 5385121, 5385131, 5385141, 5385151, 5385161, 5385171, 5385181, 5385191, 5385201, 5385211, 5385221, 5385231, 5385241, 5385251, 5385261, 5385271, 5385281, 5385291, 5385301, 5385311, 5385321, 5385331, 5385341, 5385351, 5385361, 5385371, 5385381, 5385391, 5385401, 5385411, 5385421, 5385431, 5385441, 5385451, 5385461, 5385471, 5385481, 5385491, 5385501, 5385511, 5385521, 5385531, 5385541, 5385551, 5385561, 5385571, 5385581, 5385591, 5385601, 5385611, 5385621, 5385631, 5385641, 5385684, 5386297, 5386325, 5386387, 5386449, 5386519, 5386529, 5386607, 5386617, 5386627, 5386637, 5386647, 5386737, 5386807, 5386817, 5386827, 5386837, 5386847, 5386857, 5386867, 5386877, 5386887, 5386897, 5386907, 5386917, 5386927, 5386937, 5386947, 5386957, 5386967, 5386977, 5386987, 5386997, 5387007, 5387017, 5387027, 5387037, 5387080, 5390393, 5390421, 5390483, 5390545, 5390615, 5390625, 5390703, 5390713, 5390723, 5390733, 5390743, 5390833, 5390903, 5390913, 5390923, 5390933, 5390943, 5390953, 5390963, 5390973, 5390983, 5390993, 5391003, 5391013, 5391023, 5391033, 5391043, 5391053, 5391063, 5391073, 5391083, 5391093, 5391103, 5391113, 5391123, 5391166]
startup_only=False
startup_completion_site=5787969
shell_only=False
shell_completion_site=5796269
stat_only=False
stat_completion_site=5751213
stat_pages=[5750784, 5754880, 5758976, 5763072]
statat_only=False
statat_completion_site=5702312
statat_pages=[5701632, 5705728, 5709824, 5713920, 5718016, 5722112]
write_pages=[5570560, 5574656, 5578752, 5582848, 5586944, 5591040, 5595136, 5599232, 5603328, 5607424, 5611520, 5615616, 5619712, 5623808, 5627904, 5632000, 5636096, 5640192, 5644288, 5648384]
write_lengths=[1, 4, 40, 1, 109, 4, 6, 4, 4, 5, 13, 13, 19, 17, 13, 13, 14, 4, 2, 4]
file_cases=[{'count': 9, 'number': 257, 'page': 5505024, 'result': -2}, {'count': 13, 'number': 257, 'page': 5509120, 'result': 3}, {'count': 0, 'number': 0, 'page': 5513216, 'result': 0}, {'count': 2, 'number': 257, 'page': 5517312, 'result': 3}, {'count': 72, 'number': 217, 'page': 5521408, 'result': 72}, {'count': 0, 'number': 217, 'page': 5525504, 'result': 0}, {'count': 6, 'number': 257, 'page': 5529600, 'result': 3}, {'count': 80, 'number': 217, 'page': 5533696, 'result': 80}, {'count': 0, 'number': 217, 'page': 5537792, 'result': 0}, {'count': 13, 'number': 257, 'page': 5541888, 'result': 3}, {'count': 13, 'number': 257, 'page': 5545984, 'result': 3}]
shell_io_cases=[{'argument': 6, 'count': 32, 'direction': 0, 'number': 13, 'page': 5439488, 'result': 0}, {'argument': 2, 'count': 0, 'direction': None, 'number': 16, 'page': 5443584, 'result': -25}, {'argument': 2, 'count': 32, 'direction': 1, 'number': 13, 'page': 5447680, 'result': 0}, {'argument': 2, 'count': 32, 'direction': 1, 'number': 13, 'page': 5451776, 'result': 0}, {'argument': 6, 'count': 32, 'direction': 0, 'number': 13, 'page': 5455872, 'result': 0}, {'argument': 2, 'count': 32, 'direction': 1, 'number': 13, 'page': 5459968, 'result': 0}, {'argument': 2, 'count': 0, 'direction': None, 'number': 16, 'page': 5464064, 'result': -25}, {'argument': 2, 'count': 0, 'direction': None, 'number': 16, 'page': 5468160, 'result': -25}, {'argument': 2, 'count': 0, 'direction': None, 'number': 16, 'page': 5472256, 'result': -25}, {'argument': 2, 'count': 0, 'direction': None, 'number': 16, 'page': 5476352, 'result': -25}, {'argument': 7, 'count': 2, 'direction': 0, 'number': 80, 'page': 5480448, 'result': 0}, {'argument': 6, 'count': 1, 'direction': 1, 'number': 0, 'page': 5484544, 'result': 1}, {'argument': 6, 'count': 1, 'direction': 1, 'number': 0, 'page': 5488640, 'result': 1}, {'argument': 6, 'count': 1, 'direction': 1, 'number': 0, 'page': 5492736, 'result': 1}, {'argument': 6, 'count': 1, 'direction': 1, 'number': 0, 'page': 5496832, 'result': 1}]
command_cases=[{'capacity': 1023, 'length': 11, 'page': 5373952}, {'capacity': 1023, 'length': 5, 'page': 5378048}, {'capacity': 1023, 'length': 294, 'page': 5382144}, {'capacity': 1023, 'length': 24, 'page': 5386240}, {'capacity': 23, 'length': 23, 'page': 5390336}]
serial_command=b'exec /bin/busybox true\n'
focused=False
shell_io_only=False

import gdb,json,traceback,hashlib,struct

observed=dict(passed=False,calls=[],memory=[],source_trace=None)
pending=None
preserved=['rbx','rbp','r12','r13','r14','r15']
def value(s):return int(gdb.parse_and_eval(s))
symbol_addresses={}
def address(s):
    if s not in symbol_addresses:
        symbol_addresses[s]=value('(unsigned long long)&'+s)
    return symbol_addresses[s]
def memory(p,n):return bytes(gdb.selected_inferior().read_memory(p,n))
def words(p,n):
    b=memory(p,n*8)
    return list(struct.unpack('<%dQ'%n,b))
def word(p):return words(p,1)[0]
def zeros(p,n):assert memory(p,n)==bytes(n),(hex(p),n)
def context():return address('topal_bootstrap_storage')+512
def state():return words(address('topal_x86_frame_mm_state_v1'),4)
def ptes():
    c=context();low=word(c+112);root=word(c+24)
    return words(low+0xfb8,9)+words(root+0x4000,510)
def token():return words(address('topal_x86_frame_mm_tokens_v1'),3)
def fail():
    traceback.print_exc()
    if pending and isinstance(pending.get('data_before'),bytes):
        pending['data_before_sha256']=hashlib.sha256(pending.pop('data_before')).hexdigest()
    observed['pending']=pending
    observed['backtrace']=gdb.execute('bt',to_string=True)
    with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
    gdb.execute('quit 1')
def privileged():assert value('$cs')&3==0 and value('$eflags')&0x600==0

class Source(gdb.Breakpoint):
    def stop(self):
        try:
            assert pending and pending['op']>=5
            trace=gdb.execute('bt',to_string=True)
            assert 'topal_frame_memory_request_v1' in trace and 'topal_x86_frame_gateway_v1' in trace,trace
            assert 'topal_x86_systems_static_image_process_enter' in trace,trace
            frame=gdb.newest_frame()
            while frame and frame.name()!='topal_x86_frame_gateway_v1':frame=frame.older()
            assert frame and frame.older(),trace
            for r,n in pending['registers'].items():
                assert int(frame.older().read_register(r))==n,(r,trace)
            observed['source_trace']=trace
            observed['syscall_caller_cfi_registers_checked']=True
            self.enabled=False
        except Exception:fail()
        return False
source=Source('*topal_tail_step_component_v1');source.enabled=False

class Gate(gdb.Breakpoint):
    def __init__(self,name,role):super().__init__('*'+name);self.role=role
    def stop(self):
        global pending
        try:
            privileged()
            if self.role=='entry':
                assert pending is None
                pending=dict(op=value('$rdi'),request=value('$rsi')&((1<<64)-1),sp=value('$rsp'),
                    registers={r:value('$'+r) for r in preserved})
                if pending['op']>=5:
                    op=pending['op'];assert op in [5,6,7]
                    c=context();epoch=words(address('topal_x86_frame_mm_epoch_v1'),2)
                    assert word(c)==(2 if op==6 else 1)
                    assert pending['sp']&15==8 and pending['sp']+16==word(c+8)
                    assert value('$cr3')==word(c+(16 if op==6 else 24))
                    if op!=6:assert value('$gs_base')==c
                    name={5:'brk',6:'cleanup',7:'exec'}[op]
                    assert word(pending['sp'])==address('topal_x86_frame_mm_'+name+'_return_v1')
                    assert epoch[0]>0 and epoch[1] in ({12} if op==5 else {59} if op==7 else {60,231})
                    pending['epoch']=epoch
                    pending['captured']=words(c+296,15)
                    pending['before']=state();pending['token_before']=token()
                    n=pending['before'][2];base=pending['before'][3]
                    pending['data_before']=memory(base,n*4096) if n else b''
                    pending['ptes_before']=ptes()
                    if observed['source_trace'] is None and op==5 and pending['request']:
                        source.enabled=True
                print('FRAME_MEMORY_ENTER',len(observed['calls']),pending['op'],pending['request'],flush=True)
                return False
            assert pending is not None
            assert value('$rsp')==pending['sp']
            for r,n in pending['registers'].items():assert value('$'+r)==n,r
            for r in ['rcx','rdx','rsi','rdi','r8','r9','r10','r11']:assert value('$'+r)==0,r
            zeros(pending['sp']-4000,4000)
            for name,size in [('private',65528),('stack',4096),('facts',24),('output',56),('gateway_recovery',48)]:
                zeros(address('topal_x86_frame_'+name+'_v1'),size)
            if pending['op']>=5:
                c=context();op=pending['op'];result=value('$rax')
                before=pending['before'];after=state();now=token();pages=ptes()
                assert words(c+296,15)==pending['captured']
                zeros(address('topal_x86_frame_mm_tokens_v1')+24,24)
                zeros(address('topal_x86_frame_details_v1'),32)
                oldBreak=before[1] if before[0] else 0x5f7000
                if op==5:
                    request=pending['request']
                    if not request or not 0x5f7000<=request<=0x7fe000:
                        assert result==oldBreak
                        assert now==pending['token_before'] and pages==pending['ptes_before']
                    else:
                        assert result in [oldBreak,request]
                        if result!=request:
                            assert after==before and now==pending['token_before'] and pages==pending['ptes_before']
                    assert after[0]==1 and after[1]==result
                    assert after[2]==(result-0x5f7000+4095)//4096
                    kept=min(before[2],after[2])*4096
                    if kept:assert memory(after[3],kept)==pending['data_before'][:kept]
                    if after[2]>before[2]:zeros(after[3]+before[2]*4096,(after[2]-before[2])*4096)
                else:
                    assert result==1 and after==[0,0,0,0] and now==[0,0,0]
                for i,pte in enumerate(pages):
                    expected=(after[3]+i*4096)|0x8000000000000007 if i<after[2] else 0
                    assert pte & ~0x60==expected,(i,hex(pte),hex(expected))
                if after[2]:
                    issuer,identity,slot=now
                    assert issuer==1 and identity>0
                    reg=words(address('topal_x86_frame_registry_v1')+slot*64,8)
                    assert reg[:2]==[issuer,identity] and reg[3]==after[2] and reg[6:]==[1,1]
                    start=reg[2]
                    data=words(address('topal_x86_frame_table_v1')+128+start*24,after[2]*3)
                    assert data[0::3]==[identity]*after[2]
                    assert data[2::3]==list(range(after[3]//4096,after[3]//4096+after[2]))
                if before[2] and now!=pending['token_before']:
                    # The old physical extent is retired before it becomes free.
                    zeros(before[3],before[2]*4096)
                    old=pending['token_before'];n=word(address('topal_x86_frame_context_v1')+24)
                    registry=words(address('topal_x86_frame_registry_v1'),n*8)
                    assert all(registry[i+7]!=1 or registry[i+1]!=old[1] for i in range(0,len(registry),8))
                pending['after']=after;pending['token_after']=now;pending['result']=result
                pending['data_before_sha256']=hashlib.sha256(pending.pop('data_before')).hexdigest()
                observed['memory'].append(pending.copy())
            observed['calls'].append(pending);pending=None
        except Exception:
            if pending and isinstance(pending.get('data_before'),bytes):
                pending['data_before_sha256']=hashlib.sha256(pending.pop('data_before')).hexdigest()
            fail()
        return False

class Unexpected(gdb.Breakpoint):
    def stop(self):
        try:raise AssertionError('unexpected memory failure: '+self.location)
        except Exception:fail()
        return True

class Complete(gdb.Breakpoint):
    def stop(self):
        try:
            privileged();assert pending is None
            assert observed['source_trace'] is not None
            assert any(c['op']==7 for c in observed['memory']) and sum(c['op']==6 for c in observed['memory'])==1
            assert len([c for c in observed['memory'] if c['op']==5])>=10
            assert state()==[0,0,0,0]
            zeros(address('topal_x86_frame_mm_tokens_v1'),48)
            n=word(address('topal_x86_frame_context_v1')+24)
            registry=words(address('topal_x86_frame_registry_v1'),n*8)
            live=[registry[i:i+8] for i in range(0,len(registry),8) if registry[i+7]]
            assert len(live)==1 and live[0][3]==5 and live[0][6]==1,live
            start=live[0][2];identity=live[0][1]
            table=words(address('topal_x86_frame_table_v1')+128,n*3)
            assert table[0::3]==[identity if start<=i<start+5 else 0 for i in range(n)]
            assert value('$cr3')==table[start*3+2]*4096
            observed.update(passed=True,n=n,live=live)
            with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
            return True
        except Exception:fail()

import model as extent_model

observed['user_extents']=[]
observed['native_extent_trace']=None
observed['wp_transitions']=[]
observed['scope']='Unpublished full-root native extent/owner component; no all-caller or publication qualification'
extent_snapshot=None

class WriteProtection(gdb.Breakpoint):
    def __init__(self,symbol,ready):super().__init__('*'+symbol);self.ready=ready
    def stop(self):
        try:
            privileged();actual=value('$cr0')
            if not self.ready:
                assert not observed['wp_transitions'] or 'after' in observed['wp_transitions'][-1]
                assert value('$rax')==actual
                observed['wp_transitions'].append(dict(before=actual))
            else:
                assert observed['wp_transitions'] and 'after' not in observed['wp_transitions'][-1]
                assert actual==observed['wp_transitions'][-1]['before'] | (1<<16)
                observed['wp_transitions'][-1]['after']=actual
        except Exception:fail()
        return False
WriteProtection('topal_x86_user_extent_wp_before_v1',False)
WriteProtection('topal_x86_user_extent_wp_ready_v1',True)

def physical_owner(token_address,count,pins):
    t=words(token_address,3);issuer,identity,index=t
    n=word(address('topal_x86_frame_context_v1')+24)
    assert issuer==1 and identity>0 and index<n
    r=words(address('topal_x86_frame_registry_v1')+index*64,8)
    assert r[:2]==t[:2] and r[3:5]==[count,1] and r[5]>0 and r[6:]==[pins,1]
    assert 0<=r[2] and r[2]+count<=n
    cells=words(address('topal_x86_frame_table_v1')+128+r[2]*24,count*3)
    assert cells[0::3]==[identity]*count and cells[1::3]==[r[5]]*count
    assert cells[2::3]==list(range(cells[2],cells[2]+count))
    assert cells[2]+count<=1<<18
    return dict(token=t,record=r,cells=cells,physical=cells[2]*4096)

def snapshot():
    c=context();root=word(c+24);st=state()
    roles=[physical_owner(address('topal_x86_frame_root_tokens_v1')+r['slot']*24,
                          r['count'],r['pins']) for r in owner_bindings['roles']]
    assert roles[0]['physical']==root and roles[1]['physical']==word(c+112)
    assert roles[3]['physical']+4096==word(c+912)
    # Distinct full static allocations, even though the stack has two pins.
    spans=[(r['physical'],r['physical']+len(r['cells'])//3*4096) for r in roles]
    for i,(a,b) in enumerate(spans):
        assert all(b<=x or y<=a for x,y in spans[:i])
    table_roles={root:4,root+4096:3,root+8192:2,root+12288:2,root+16384:1,roles[1]['physical']:1}
    tables={p:extent_model.Table(level,tuple(words(p,512))) for p,level in table_roles.items()}
    phase=memory(c+104,1)[0]
    writable=493 if phase>=9 else 485
    backing={0x400000+i*4096:extent_model.Backing(roles[2]['physical']+i*4096,writable=i>=writable)
             for i in range(503)}
    backing.update({0x7fe000+i*4096:extent_model.Backing(roles[3]['physical']+i*4096) for i in range(2)})
    heap=None
    if st[2]:
        assert st[0]==1 and st[2]<=519
        heap=physical_owner(address('topal_x86_frame_mm_tokens_v1'),st[2],1)
        assert heap['physical']==st[3]
        for a,b in spans:assert st[3]+st[2]*4096<=a or b<=st[3]
        backing.update({0x5f7000+i*4096:extent_model.Backing(st[3]+i*4096) for i in range(st[2])})
    epoch=words(address('topal_x86_frame_mm_epoch_v1'),2)
    cr0=value('$cr0');cr4=value('$cr4')
    # The target separately observes EFER and BSP; record raw monitor evidence
    # on the first call as well as these independent paging-control checks.
    if 'paging' not in observed:
        observed['paging']=dict(cr0=cr0,cr4=cr4,registers=gdb.execute('monitor info registers',to_string=True))
    qualified=all(cr0&(1<<bit) for bit in [0,16,31]) and not any(cr4&(1<<bit) for bit in [12,17,21,22,23,24])
    obs=extent_model.Observation(root,value('$cr3'),epoch[0],epoch[0],tables,backing,
        frozenset(table_roles),privileged=value('$cs')&3==0,critical=value('$eflags')&0x600==0,
        stable=True,mode='la48-small' if qualified else 'unqualified-mode')
    fingerprints=dict(roles=roles,heap=heap,phase=phase,state=st,
        tables={str(p):dict(level=t.level,words=list(t.words)) for p,t in tables.items()},
        allocator=words(address('topal_x86_frame_context_v1'),16),
        tokens=words(address('topal_x86_frame_mm_tokens_v1'),6),
        epoch=epoch,captured=words(c+296,15),
        image_fingerprint=backing_fingerprint(roles[2]['physical'],503*4096,0x400000),
        stack_fingerprint=backing_fingerprint(roles[3]['physical'],8192,0x7fe000),
        heap_fingerprint=backing_fingerprint(st[3],st[2]*4096,0x5f7000))
    return obs,fingerprints

MemoryGate=Gate
class Gate(MemoryGate):
    def stop(self):
        global pending,extent_snapshot
        if self.role=='entry' and value('$rdi')!=8 or self.role!='entry' and pending and pending['op']!=8:
            return super().stop()
        try:
            privileged()
            if self.role=='entry':
                assert pending is None
                c=context();sp=value('$rsp');epoch=words(address('topal_x86_frame_mm_epoch_v1'),2)
                assert sp&15==8 and sp+16<=word(c+8)<=0x180000
                assert word(c)==1 and word(c+256)==c and value('$gs_base')==c
                assert value('$cr3')==word(c+24) and epoch[0]>0 and 0<=epoch[1]<(1<<32)
                assert word(sp)==address('topal_x86_user_extent_return_v1')
                start=value('$rsi')&((1<<64)-1);length=value('$rdx')&((1<<64)-1);write=value('$rcx')
                assert write in [0,1] and value('$r8')==0
                obs,extent_snapshot=snapshot()
                expected=extent_model.admit(obs,start,length,write=bool(write))
                status={extent_model.Status.EMPTY:0,extent_model.Status.ADMITTED:0,
                    extent_model.Status.RANGE:1,extent_model.Status.ABSENT:2,
                    extent_model.Status.PERMISSION:3,extent_model.Status.UNSUPPORTED:4}[expected.status]
                pending=dict(op=8,start=start,length=length,write=write,sp=sp,epoch=epoch,
                    expected=status,checked_pages=expected.checked_pages,
                    registers={r:value('$'+r) for r in preserved},before=extent_snapshot)
                return False
            assert pending and pending['op']==8
            assert value('$rsp')==pending['sp']
            for r,n in pending['registers'].items():assert value('$'+r)==n,r
            for r in ['rcx','rdx','rsi','rdi','r8','r9','r10','r11']:assert value('$'+r)==0,r
            zeros(pending['sp']-4000,4000)
            for name,size in [('private',65528),('stack',4096),('facts',24),('output',56),
                              ('gateway_recovery',48),('details',32)]:
                zeros(address('topal_x86_frame_'+name+'_v1'),size)
            assert word(address('topal_frame_allocator_active_v1'))==0
            assert word(address('topal_x86_tail_boundary_active_v1'))==0
            assert snapshot()[1]==extent_snapshot
            result=value('$rax');assert result==pending['expected'],(result,pending['expected'],observed['paging'])
            pending['result']=result
            observed['user_extents'].append(pending);observed['calls'].append(pending)
            pending=None;extent_snapshot=None
        except Exception:fail()
        return False


import gzip
helper_pending=None
caller_return_points={}
sample_whole_backing=False
whole_backing_keys=set()
extent_records=gzip.open(observation_path+'.extent-records.jsonl.gz','wt',encoding='utf-8')
observed['extent_records_file']=observation_path+'.extent-records.jsonl.gz'
observed['whole_backing_sample_count']=0
observed['helper_calls']=[]
observed['process_cleanup_checked']=False
observed['startup_outputs_checked']=False
observed['shell_outputs_checked']=False
observed['stat_outputs_checked']=False
observed['stat_staging_samples']=[]
observed['statat_paths_checked']=False
observed['statat_staging_samples']=[]
observed['statat_user_results']=[]
observed['write_staging_samples']=[]
observed['write_user_results']=[]
observed['file_staging_samples']=[]
observed['file_user_results']=[]
observed['command_user_results']=[]
command_case_by_page={row['page']:i for i,row in enumerate(command_cases)}

observed['shell_io_user_results']=[]
shell_io_case_by_page={row['page']:i for i,row in enumerate(shell_io_cases)}
shell_io_argument_registers={2:'rdx',6:'rsi',7:'rdi'}
file_case_by_page={row['page']:i for i,row in enumerate(file_cases)}
observed['symbol_resolution_scope']='Only immutable linked kernel ELF symbol locations are memoized; all runtime contents and registers are freshly read'
observed['scope']='Private shared-caller migration with ordinary ABI buffers; direct callers and canonical publication remain unqualified'
observed['byte_observation_scope']='Fresh complete ownership/translation state for every call; covered bytes on every call and whole backing for each ABI/direction plus every new split-page/cross-table buffer'
helper_registers=preserved+['rdx','rsi','rdi','r8','r9']

def backing_fingerprint(base,size,user_base):
    scope='whole-backing' if sample_whole_backing else 'covered-bytes'
    start=helper_pending['start'];length=helper_pending['length']
    if sample_whole_backing:offset,count=0,size
    elif start+length>1<<64:offset,count=0,0
    else:
        lower=max(start,user_base);upper=min(start+length,user_base+size)
        offset,count=(lower-user_base,upper-lower) if lower<upper else (0,0)
    return dict(scope=scope,physical_start=base+offset,byte_count=count,
                sha256=hashlib.sha256(memory(base+offset,count) if count else b'').hexdigest())

base_fail=fail
def fail():
    observed['helper_pending']=helper_pending
    if not extent_records.closed:extent_records.flush()
    base_fail()

user_scope_active=None
user_scope_entry=None
user_scope_points={}
user_scope_exits={}
observed['assertion_scopes_entered']=0
observed['assertion_scopes_completed']=0
observed['user_assertions_checked']=0
observed['repeated_entry_notifications']=[]

def close_user_scope(page):
    global user_scope_active,user_scope_entry
    if user_scope_active is None:return
    assert user_scope_active==page
    for point in user_scope_points[page]:point.enabled=False
    user_scope_exits[page].enabled=False
    user_scope_active=None
    user_scope_entry=None
    observed['assertion_scopes_completed']+=1

class UserAssertion(gdb.Breakpoint):
    def stop(self):
        try:
            assert user_scope_active==value('$rip')&-4096
            observed['user_assertions_checked']+=1
            if user_scope_active in command_case_by_page:
                case=command_case_by_page[user_scope_active]
                site=value('$rip')
                number=words(address('topal_x86_frame_mm_epoch_v1'),2)[1]
                if number==0 and value('$rcx')==site-6:
                    assert value('$cs')&3==3 and memory(site-6,2)==bytes.fromhex('483d')
                    c=context()
                    assert memory(c+296,120)==bytes(120)
                    state=word(c+904)+0x9e00
                    cursor,length,match=words(state+256,3)
                    assert length<=256 and memory(state+length,256-length)==bytes(256-length)
                    result=value('$rax')&((1<<64)-1)
                    if result>>63:result-=1<<64
                    observed['command_user_results'].append(dict(case=case,site=site,
                        pointer=value('$rsi'),count=value('$rdx'),result=result,cursor=cursor,
                        pending=memory(state,length).hex() if length else '',prefix=match,
                        phase=memory(c+104,1)[0],owner=memory(c+418,1)[0]))
                    print('COMMAND_READ_RESULT',case,hex(value('$rsi')),value('$rdx'),result,flush=True)
            if user_scope_active in stat_pages or user_scope_active in statat_pages:
                assert value('$cs')&3==3
                c=context();console=memory(c+472,144);other=memory(c+744,144)
                assert console==other==bytes(144)
                is_stat=user_scope_active in stat_pages
                cases=stat_pages if is_stat else statat_pages
                field='stat_staging_samples' if is_stat else 'statat_staging_samples'
                observed[field].append(dict(
                    case=cases.index(user_scope_active),site=value('$rip'),
                    console_sha256=hashlib.sha256(console).hexdigest(),
                    other_sha256=hashlib.sha256(other).hexdigest()))
                site=value('$rip')
                if not is_stat and words(address('topal_x86_frame_mm_epoch_v1'),2)[1]==262 and memory(site-6,2)==bytes.fromhex('483d'):
                    result=value('$rax')&((1<<64)-1)
                    if result>>63:result-=1<<64
                    observed['statat_user_results'].append(dict(case=cases.index(user_scope_active),site=site,result=result))
            if user_scope_active in write_pages:
                assert value('$cs')&3==3
                case=write_pages.index(user_scope_active)
                c=context()
                banner=memory(c+624,112)
                transfer=memory(c+744,144)
                assert banner==bytes(112) and transfer==bytes(144),case
                site=value('$rip')
                observed['write_staging_samples'].append(dict(case=case,site=site,
                    banner_sha256=hashlib.sha256(banner).hexdigest(),
                    transfer_sha256=hashlib.sha256(transfer).hexdigest()))
                if words(address('topal_x86_frame_mm_epoch_v1'),2)[1]==1 and memory(site-6,2)==bytes.fromhex('483d'):
                    result=value('$rax')&((1<<64)-1)
                    if result>>63:result-=1<<64
                    observed['write_user_results'].append(dict(case=case,site=site,result=result))
            if user_scope_active in shell_io_case_by_page:
                case=shell_io_case_by_page[user_scope_active]
                config=shell_io_cases[case]
                site=value('$rip')
                number=words(address('topal_x86_frame_mm_epoch_v1'),2)[1]
                if number==config['number'] and value('$rcx')==site-6:
                    assert value('$cs')&3==3
                    assert memory(site-6,2)==bytes.fromhex('483d')
                    c=context()
                    assert memory(c+296,120)==bytes(120)
                    assert memory(c+744,144)==bytes(144)
                    result=value('$rax')&((1<<64)-1)
                    if result>>63:result-=1<<64
                    pointer=value('$'+shell_io_argument_registers[config['argument']])&((1<<64)-1)
                    state_after=dict(phase=memory(c+104,1)[0],
                        action=memory(c+417,1)[0],header=list(memory(c+888,5)),
                        child=[word(c+offset) for offset in [168,176,224,232]])
                    observed['shell_io_user_results'].append(dict(case=case,site=site,
                        number=number,pointer=pointer,result=result,state=state_after))
                    print('SHELL_IO_SYSCALL_RESULT',case,number,hex(pointer),result,flush=True)
            if user_scope_active in file_case_by_page:
                assert value('$cs')&3==3
                case=file_case_by_page[user_scope_active]
                c=context()
                first,second=memory(c+472,144),memory(c+744,144)
                assert first==second==bytes(144),case
                site=value('$rip')
                observed['file_staging_samples'].append(dict(case=case,site=site,
                    first_sha256=hashlib.sha256(first).hexdigest(),
                    second_sha256=hashlib.sha256(second).hexdigest()))
                number=words(address('topal_x86_frame_mm_epoch_v1'),2)[1]
                # SYSRET restores the original arguments and clears the
                # kernel capture slots. Observe the restored user registers.
                if number==file_cases[case]['number'] and value('$rcx')==site-6:
                    assert memory(site-6,2)==bytes.fromhex('483d')
                    assert memory(c+296,120)==bytes(120)
                    result=value('$rax')&((1<<64)-1)
                    if result>>63:result-=1<<64
                    arguments=[value('$'+name)&((1<<64)-1) for name in ['rdi','rsi','rdx']]
                    observed['file_user_results'].append(dict(case=case,site=site,result=result,
                        number=number,arguments=arguments))
                    print('FILE_SYSCALL_RESULT',case,number,hex(arguments[1]),result,flush=True)
        except Exception:fail()
        if value('$eflags')&64:return False
        observed['ordinary_user_assertion_failure']=dict(
            registers={name:value('$'+name) for name in ['rip','rax','rdi','rsi','rdx','eflags']},
            entry=words(address('topal_x86_frame_mm_epoch_v1'),2),
            phase=memory(context()+104,1)[0],helper=helper_pending)
        try:raise AssertionError(observed['ordinary_user_assertion_failure'])
        except Exception:fail()
        return True
for site in user_assertions:
    point=UserAssertion('*'+hex(site),internal=True);point.enabled=False
    user_scope_points.setdefault(site&-4096,[]).append(point)

class UserScopeExit(gdb.Breakpoint):
    def __init__(self,page,site):
        super().__init__('*'+hex(site),internal=True);self.page=page;self.enabled=False
    def stop(self):
        try:close_user_scope(self.page)
        except Exception:fail()
        return False

class UserScopeEnter(gdb.Breakpoint):
    def __init__(self,page):super().__init__('*'+hex(page),internal=True);self.page=page
    def stop(self):
        global user_scope_active,user_scope_entry
        try:
            cs=value('$cs')
            entry=dict(page=self.page,sp=value('$rsp'),cs=cs,
                       epoch=words(address('topal_x86_frame_mm_epoch_v1'),2),
                       assertions=observed['user_assertions_checked'])
            assert cs&3==3,entry
            if user_scope_active==self.page:
                # Resuming a breakpoint while arming its assertion sites can
                # produce another stop at the same unadvanced entry.
                assert entry==user_scope_entry,(entry,user_scope_entry)
                assert not observed['repeated_entry_notifications'] or observed['repeated_entry_notifications'][-1]!=entry,entry
                observed['repeated_entry_notifications'].append(entry)
                return False
            assert user_scope_active is None,(entry,user_scope_entry)
            # These are the fixture's actual two-byte assertion instructions.
            # A block entry rearms them on every invocation/generation; its
            # final assertion continuation disarms them only after execution.
            for point in user_scope_points[self.page]:
                site=int(point.location[1:],16)
                assert memory(site,2)==bytes.fromhex('75fe')
                point.enabled=True
            user_scope_exits[self.page].enabled=True
            user_scope_active=self.page
            user_scope_entry=entry
            observed['assertion_scopes_entered']+=1
        except Exception:fail()
        return False

for page in user_scope_points:
    last=max(site for site in user_assertions if site&-4096==page)
    user_scope_exits[page]=UserScopeExit(page,last+2)
    UserScopeEnter(page)

class CallerReturned(gdb.Breakpoint):
    def stop(self):
        global helper_pending
        # A Python stop callback that resumes execution does not consume a
        # temporary breakpoint. Disable this observation explicitly, then
        # rearm the same object at its next call instead of accumulating
        # thousands of disabled observers for byte-by-byte pathname checks.
        self.enabled=False
        try:
            assert helper_pending and helper_pending.get('returned')
            assert value('$rsp')==helper_pending['sp']+8
            assert word(helper_pending['sp'])==0
            assert bool(value('$eflags')&1)==bool(helper_pending['result'])
            for name,number in helper_pending['registers'].items():assert value('$'+name)==number,name
            helper_pending['caller_return_erased']=True
            observed['helper_calls'].append(helper_pending);helper_pending=None
        except Exception:fail()
        return False

class Helper(gdb.Breakpoint):
    def __init__(self,symbol,direction,returning):
        super().__init__('*'+symbol);self.direction=direction;self.returning=returning
    def stop(self):
        global helper_pending
        try:
            privileged()
            if not self.returning:
                assert helper_pending is None
                sp=value('$rsp');site=word(sp)
                assert memory(site,9)==bytes.fromhex('48c74424f800000000')
                helper_pending=dict(sp=sp,site=site,direction=self.direction,
                    start=value('$r8')&((1<<64)-1),length=value('$r9')&((1<<64)-1),
                    registers={r:value('$'+r) for r in helper_registers})
                if site not in caller_return_points:
                    caller_return_points[site]=CallerReturned('*'+hex(site+9),internal=True)
                else:caller_return_points[site].enabled=True
            else:
                assert helper_pending and pending is None and self.direction==helper_pending['direction']
                assert value('$rsp')==helper_pending['sp']
                for name,number in helper_pending['registers'].items():assert value('$'+name)==number,name
                result=value('$rax');assert result==helper_pending['native_result']
                assert bool(value('$eflags')&1)==bool(result)
                gate=helper_pending['gateway_sp']
                zeros(gate-4000,4000)
                zeros(gate,helper_pending['sp']-gate)
                assert word(helper_pending['sp'])==helper_pending['site']
                helper_pending.update(returned=True,result=result)
        except Exception:fail()
        return False

ExtentGate=Gate
class Gate(ExtentGate):
    def stop(self):
        global sample_whole_backing
        is_extent=(self.role=='entry' and value('$rdi')==8) or (self.role!='entry' and pending and pending['op']==8)
        if is_extent and self.role=='entry':
            try:
                assert helper_pending and 'gateway_sp' not in helper_pending
                assert value('$rsi')&((1<<64)-1)==helper_pending['start']
                assert value('$rdx')&((1<<64)-1)==helper_pending['length']
                assert value('$rcx')==helper_pending['direction']
                helper_pending['gateway_sp']=value('$rsp')
                helper_pending['epoch']=words(address('topal_x86_frame_mm_epoch_v1'),2)
                key=(helper_pending['epoch'][1],helper_pending['direction'])
                sample_whole_backing=key not in whole_backing_keys or (
                    (helper_pending['start'],helper_pending['length']) in [
                        (0x5ffff8,16),(0x638ff8,16),(0x638ffc,8),(0x638ff8,390),(0x638fff,2),(0x638ff8,144),
                        (0x637ff8,144),(0x638ffc,5),(0x638ffc,13),(0x638ffc,18),(0x638ffc,21)]
                    or (helper_pending['epoch'][1]==1 and helper_pending['start']==0x638fff)
                    or (helper_pending['epoch'][1] in [217,257] and
                        helper_pending['start'] in [0x638fff,0x638ff8,0x639f80]))
            except Exception:fail()
        result=super().stop()
        if is_extent and self.role=='return':
            call=observed['user_extents'][-1]
            if call['epoch'][1] in [63,79]:call['process_phase']=call['before']['phase']
            if call['epoch'][1]==5 and call['before']['captured'][0]&-4096 in stat_pages:
                call['stat_fixture_case']=stat_pages.index(call['before']['captured'][0]&-4096)
            if call['epoch'][1]==262 and call['before']['captured'][0]&-4096 in statat_pages:
                call['statat_fixture_case']=statat_pages.index(call['before']['captured'][0]&-4096)
            if call['epoch'][1]==1 and call['before']['captured'][0]&-4096 in write_pages:
                call['write_fixture_case']=write_pages.index(call['before']['captured'][0]&-4096)
            if call['before']['captured'][0]&-4096 in file_case_by_page:
                case=file_case_by_page[call['before']['captured'][0]&-4096]
                assert call['epoch'][1]==file_cases[case]['number']
                call['file_fixture_case']=case
            if call['before']['captured'][0]&-4096 in shell_io_case_by_page:
                case=shell_io_case_by_page[call['before']['captured'][0]&-4096]
                assert call['epoch'][1]==shell_io_cases[case]['number']
                call['shell_io_fixture_case']=case
            if call['before']['captured'][0]&-4096 in command_case_by_page:
                case=command_case_by_page[call['before']['captured'][0]&-4096]
                assert call['epoch'][1]==0
                call['command_fixture_case']=case
            helper_pending['native_result']=call['result']
            # Archive every full observation after its independent before/after
            # comparison; keep only its identity in the in-memory history.
            # Otherwise thousands of byte checks retain duplicate page tables.
            record=json.dumps(call,sort_keys=True,separators=(',',':'))
            extent_records.write(record+'\n')
            call['before']=dict(archive_record=len(observed['user_extents'])-1,
                record_sha256=hashlib.sha256(record.encode()).hexdigest(),
                byte_scope='whole-backing' if sample_whole_backing else 'covered-bytes')
            if sample_whole_backing:observed['whole_backing_sample_count']+=1
            whole_backing_keys.add((helper_pending['epoch'][1],helper_pending['direction']))
            if len(observed['user_extents'])%64==0:
                print('CALLER_PROGRESS',len(observed['user_extents']),flush=True)
            sample_whole_backing=False
        return result

class NativeTrace(gdb.Breakpoint):
    def stop(self):
        try:
            assert pending and pending['op']==8 and helper_pending
            trace=gdb.execute('bt',to_string=True)
            for name in ['topal_x86_owned_user_extent_v1','topal_frame_kernel_dispatch_v1',
                         'topal_x86_frame_gateway_v1','topal_x86_user_extent_call_v1',
                         'topal_x86_systems_static_image_process_enter']:
                assert name in trace,(name,trace)
            frame=gdb.newest_frame()
            while frame and frame.name() not in ['topal_x86_user_extent_readable_v1','topal_x86_user_extent_writable_v1']:
                frame=frame.older()
            assert frame and frame.older(),trace
            for name in preserved:assert int(frame.older().read_register(name))==helper_pending['registers'][name],name
            sp=helper_pending['sp'];r=helper_pending['registers']
            assert words(sp-48,5)==[r[n] for n in ['r9','r8','rdi','rsi','rdx']]
            assert word(sp-8)==r['rbp']
            observed['native_extent_trace']=trace;observed['native_extent_trace_samples']=1
            self.enabled=False
        except Exception:fail()
        return False

BaseComplete=Complete

def caller_history_checked():
    assert user_scope_active is None
    assert observed['assertion_scopes_entered']==observed['assertion_scopes_completed']
    assert observed['user_assertions_checked']>0
    assert helper_pending is None and pending is None and observed['native_extent_trace']
    assert len(observed['helper_calls'])==len(observed['user_extents'])>=4
    actual_return_observers=sum(isinstance(b,CallerReturned) for b in gdb.breakpoints())
    assert actual_return_observers==len({h['site'] for h in observed['helper_calls']})
    observed['return_observer_sites']=actual_return_observers
    assert observed['wp_transitions'] and value('$cr0')&(1<<16)
    observed['shared_caller_registers_and_retirement_checked']=True

def startup_outputs_checked():
    pairs={(c['start'],c['length'],c['write'],c['epoch'][1],c['result']) for c in observed['user_extents']}
    for number,length,valid in [(302,16,0x638ff8),(318,8,0x638ffc),(157,16,0x638ff8)]:
        for pointer,status in [(valid,0),(0x63a000,2),(0x401000,3)]:
            expected=(pointer,length,1,number,status)
            assert expected in pairs,(expected,pairs)
    observed['startup_outputs_checked']=True

def shell_outputs_checked(full):
    calls=observed['user_extents']
    phases=[19,20,26,30] if full else [19,20]
    for phase in phases:
        number,length,valid,partial=(63,390,0x638ff8,0x639ff8) if phase==19 else (79,2,0x638fff,0x639fff)
        for pointer,status in [(valid,0),(0x63a000,2),(0x401000,3),(partial,2)]:
            assert any(c.get('process_phase')==phase and c['epoch'][1]==number and
                       (c['start'],c['length'],c['write'],c['result'])==(pointer,length,1,status)
                       for c in calls),(phase,number,hex(pointer),status)
    observed['shell_output_phases_checked']=phases
    observed['shell_outputs_checked']=True

def stat_outputs_checked(full):
    cases=[0,1,2,3] if full else [0]
    for case in cases:
        calls=[c for c in observed['user_extents'] if c.get('stat_fixture_case')==case]
        assert len(calls)==4,(case,len(calls))
        for pointer,status in [(0x638ff8,0),(0x63a000,2),(0x401000,3),(0x639ff8,2)]:
            assert any((c['start'],c['length'],c['write'],c['result'])==(pointer,144,1,status)
                       for c in calls),(case,hex(pointer),status)
        assert sum(s['case']==case for s in observed['stat_staging_samples'])>=11
    observed['stat_fixture_cases_checked']=cases
    observed['stat_outputs_checked']=True
    observed['stat_output_scope']='Four ordinary fixture descriptor paths; external-shell pwd dispatch guards and newfstatat remain separately unqualified'

def statat_paths_checked(full):
    cases=list(range(6)) if full else [0]
    for case in cases:
        calls=[c for c in observed['user_extents'] if c.get('statat_fixture_case')==case]
        length=[18,21,5,13,13,13][case]
        for pointer,status in [(0x63a000,2),(0x639ffe,2),(0x638ffc,0)]:
            assert any((c['start'],c['length'],c['write'],c['result'])==(pointer,length,0,status) for c in calls),(case,hex(pointer),status)
        if case<2:
            assert all(c['write']==0 for c in calls),case
            expected=-2
        else:
            for pointer,status in [(0x637ff8,0),(0x63a000,2),(0x401000,3),(0x639ff8,2)]:
                assert any((c['start'],c['length'],c['write'],c['result'])==(pointer,144,1,status) for c in calls),(case,hex(pointer),status)
            expected=0
        results={r['result'] for r in observed['statat_user_results'] if r['case']==case}
        assert {-14,expected}<=results,(case,results)
        assert sum(s['case']==case for s in observed['statat_staging_samples'])>=7
    observed['statat_fixture_cases_checked']=cases
    observed['statat_paths_checked']=True
    observed['statat_scope']='Six ordinary fixture paths; external-shell missing-root dispatch remains separately unqualified'

def write_inputs_checked(full):
    cases=list(range(len(write_pages))) if full else [0]
    for case in cases:
        count=write_lengths[case]
        calls=[c for c in observed['user_extents'] if c.get('write_fixture_case')==case]
        outcomes={(c['start'],c['length'],c['result']) for c in calls}
        assert calls and all(c['write']==0 for c in calls),case
        assert {(0x63a000,count,2),(0x638fff,count,0)}<=outcomes,(case,outcomes)
        if count>1:assert (0x639fff,count,2) in outcomes,(case,outcomes)
        assert all(c['length']==count for c in calls),case
        results={row['result'] for row in observed['write_user_results'] if row['case']==case}
        assert {-14,count}<=results,(case,results)
        assert sum(s['case']==case for s in observed['write_staging_samples'])>=7,case
    observed['write_fixture_cases_checked']=cases

def file_transfers_checked():
    assert len(file_cases)==11
    for case,config in enumerate(file_cases):
        number,count,result=(config[k] for k in ('number','count','result'))
        calls=[c for c in observed['user_extents'] if c.get('file_fixture_case')==case]
        actual=[(c['start'],c['length'],c['write'],c['result']) for c in calls]
        results=[r for r in observed['file_user_results'] if r['case']==case]
        if number==257:
            expected=[(0x63a000,count,0,2),(0x639fff,count,0,2),(0x638fff,count,0,0)]
            returns=[(0x63a000,-14),(0x639fff,-14),(0x638fff,result)]
            assert all(r['arguments'][0]&0xffffffff==0xffffff9c for r in results)
        elif count:
            assert number==217 and count in [72,80]
            start=0x638ff8 if count==72 else 0x639f80
            expected=[(0x63a000,count,1,2),(0x401000,count,1,3),(0x639ff8,count,1,2),(start,count,1,0)]
            returns=[(0x63a000,-14),(0x401000,-14),(0x639ff8,-14),(start,result)]
        else:
            expected=[]
            returns=[(0x63a000,0)]
            if number==0:returns.insert(0,((1<<47)-4096-127,-14))
        if number in [0,217]:
            assert all(r['arguments'][0]==3 and r['arguments'][2]==(128 if number==0 else 512) for r in results)
        assert actual==expected,(case,actual,expected)
        assert [(r['arguments'][1],r['result']) for r in results]==returns,(case,results,returns)
        assert sum(s['case']==case for s in observed['file_staging_samples'])>=len(returns)+1
    observed['file_fixture_cases_checked']=list(range(len(file_cases)))

def shell_io_checked():
    assert len(shell_io_cases)==15
    for case,config in enumerate(shell_io_cases):
        number,count,direction,result=(config[k] for k in ('number','count','direction','result'))
        calls=[c for c in observed['user_extents'] if c.get('shell_io_fixture_case')==case]
        actual=[(c['start'],c['length'],c['write'],c['result']) for c in calls]
        results=[r for r in observed['shell_io_user_results'] if r['case']==case]
        expected=[]
        if direction is None:
            assert count==0 and number==16 and result==-25
            returns=[(0x63a000,-25)]
        else:
            assert direction in [0,1] and count in [1,2,32]
            invalid=[(0x63a000,2)]
            if direction==1:invalid.append((0x401000,3))
            if count>1:invalid.append((0x639fff,2))
            expected=[(start,count,direction,status) for start,status in invalid]
            expected.append((0x638fff,count,direction,0))
            returns=[(start,-14) for start,status in invalid]+[(0x638fff,result)]
            assert len({json.dumps(r['state'],sort_keys=True) for r in results[:-1]})==1
            if number==0:
                assert results[-1]['state']['header'][1]==results[0]['state']['header'][1]+1
        assert actual==expected,(case,actual,expected)
        assert [(r['pointer'],r['result']) for r in results]==returns,(case,results,returns)
    observed['shell_io_fixture_cases_checked']=list(range(len(shell_io_cases)))

def command_reads_checked():
    assert [r['length'] for r in command_cases]==[11,5,294,24,len(serial_command)]
    for case,spec in enumerate(command_cases):
        length,capacity=spec['length'],spec['capacity']
        suffix=length-2
        calls=[c for c in observed['user_extents'] if c.get('command_fixture_case')==case]
        actual=[(c['start'],c['length'],c['write'],c['result']) for c in calls]
        expected=[(0x63a000,length,1,2),(0x639fff,length,1,2),(0x638fff,2,1,0),
                  (0x63a000,suffix,1,2),(0x63a000-suffix,suffix,1,0)]
        assert actual==expected,(case,actual,expected)
        results=[r for r in observed['command_user_results'] if r['case']==case]
        returns=[(0x63a000,0,0),(0x63a000,capacity,-14),(0x639fff,length,-14),
                 (0x638fff,2,2),(0x63a000,capacity,-14),(0x63a000-suffix,capacity,suffix)]
        assert [(r['pointer'],r['count'],r['result']) for r in results]==returns,(case,results,returns)
        phase=[26,28,29,30,31][case]
        assert [(r['phase'],r['owner']) for r in results]==[(phase,case+1)]*5+[
            ([27,28,29,30,32][case],case+2)]
        if case==4:
            assert [r['cursor'] for r in results]==[0]*6
            expected_pending=[b'',serial_command,serial_command,serial_command[2:],serial_command[2:],b'']
            assert [bytes.fromhex(r['pending']) for r in results]==expected_pending
            assert [r['prefix'] for r in results]==[0,6,6,6,6,6]
        else:
            assert [r['cursor'] for r in results]==[0,0,0,2,2,0]
            assert all(not r['pending'] and not r['prefix'] for r in results)
    observed['command_fixture_cases_checked']=list(range(len(command_cases)))

class Complete(BaseComplete):
    def stop(self):
        try:
            assert not focused,'focused fixture did not reach its user continuation'
            caller_history_checked()
            startup_outputs_checked()
            shell_outputs_checked(True)
            stat_outputs_checked(True)
            statat_paths_checked(True)
            write_inputs_checked(True)
            file_transfers_checked()
            shell_io_checked()
            command_reads_checked()
            pairs={(c['start'],c['length'],c['write'],c['epoch'][1],c['result']) for c in observed['user_extents']}
            for expected in [(0x5ffff8,16,1,229,0),(0x638ff8,16,1,229,0),
                             (0x638ff8,16,0,35,0),(0x638ff8,16,1,228,0)]:
                assert expected in pairs,(expected,pairs)
            extent_records.close()
        except Exception:fail()
        result=super().stop()
        observed['process_cleanup_checked']=True
        with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
        return result

class StartupComplete(gdb.Breakpoint):
    def stop(self):
        try:
            assert startup_only and value('$cs')&3==3
            # This focused endpoint is also the final assertion continuation;
            # close idempotently, independent of breakpoint callback order.
            close_user_scope(startup_completion_site&-4096)
            caller_history_checked()
            startup_outputs_checked()
            c=context();heap=state()
            assert heap[:3]==[1,0x619000,34],heap
            assert memory(c+104,1)[0]==10
            # Refused output requests did not consume the initial seed or a
            # generator result, and the two valid requests consumed two only.
            assert word(c+264)==2 and memory(c+184,1)[0]==3
            for at,want in [(0x7fff18,11),(0x7fff20,0),(0x7fff28,12),(0x7fff30,0),
                            (0x7fff38,13),(0x7fff40,0),(0x7fff48,14),(0x7fff50,0)]:
                assert word(at)==want,('startup metadata',hex(at),word(at),want)
            destination=value('$r12')
            assert words(destination,2)==[int.from_bytes(b'busybox\0','little'),0]
            observed['startup_context']=dict(heap=heap,phase=10,random_requests=2)
            observed['scope']='Focused normal startup output/mapping/adapter component; whole-process cleanup and publication are not checked'
            observed['passed']=True
            extent_records.close()
            with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
            return True
        except Exception:fail()

if startup_only:StartupComplete('*'+hex(startup_completion_site),internal=True)

class ShellComplete(gdb.Breakpoint):
    def stop(self):
        try:
            assert shell_only and value('$cs')&3==3
            close_user_scope(shell_completion_site&-4096)
            caller_history_checked()
            startup_outputs_checked()
            shell_outputs_checked(False)
            write_inputs_checked(False)
            assert state()[:3]==[1,0x619000,34]
            assert memory(context()+104,1)[0]==21
            assert memory(value('$r12'),2)==b'/\0'
            observed['scope']='Focused normal startup/uname/initial-getcwd component; later getcwd branches, whole-process cleanup and publication are not checked'
            observed['passed']=True
            extent_records.close()
            with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
            return True
        except Exception:fail()

if shell_only:ShellComplete('*'+hex(shell_completion_site),internal=True)

class StatComplete(gdb.Breakpoint):
    def stop(self):
        try:
            assert stat_only and value('$cs')&3==3
            close_user_scope(stat_completion_site&-4096)
            caller_history_checked()
            startup_outputs_checked()
            shell_outputs_checked(False)
            stat_outputs_checked(False)
            assert state()[:3]==[1,0x619000,34]
            c=context();assert memory(c+104,1)[0]==26 and memory(c+616,1)[0]==1
            expected=[0,1,1,0x2180,0,0x4400,0,4096]+[0]*10
            assert words(value('$r12'),18)==expected
            observed['scope']='Focused normal console-fstat/startup component; remaining descriptor cases, whole-process cleanup and publication are not checked'
            observed['passed']=True
            extent_records.close()
            with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
            return True
        except Exception:fail()

if stat_only:StatComplete('*'+hex(stat_completion_site),internal=True)

class StatAtComplete(gdb.Breakpoint):
    def stop(self):
        try:
            assert statat_only and value('$cs')&3==3
            close_user_scope(statat_completion_site&-4096)
            caller_history_checked()
            startup_outputs_checked()
            statat_paths_checked(False)
            assert state()[:3]==[1,0x619000,34]
            assert memory(context()+104,1)[0]==12
            assert memory(value('$r12'),144)==bytes([0xa5])*144
            observed['scope']='Focused normal optional-config pathname/absence/error-order component; later stat paths, whole-process cleanup and publication are not checked'
            observed['passed']=True
            extent_records.close()
            with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
            return True
        except Exception:fail()

if statat_only:StatAtComplete('*'+hex(statat_completion_site),internal=True)

class ShellIoComplete(gdb.Breakpoint):
    def stop(self):
        try:
            assert shell_io_only and value('$cs')&3==3
            assert memory(command_completion_site-2,2)==bytes.fromhex('75fe')
            close_user_scope(command_completion_site&-4096)
            caller_history_checked()
            startup_outputs_checked()
            shell_outputs_checked(True)
            stat_outputs_checked(True)
            statat_paths_checked(True)
            write_inputs_checked(True)
            file_transfers_checked()
            shell_io_checked()
            command_reads_checked()
            assert state()[:3]==[1,0x619000,34]
            c=context()
            assert memory(c+104,1)[0]==32
            assert memory(c+418,1)[0]==6 and memory(c+743,1)[0]==10
            assert memory(c+296,120)==bytes(120)
            observed['scope']='Ordinary first-image shell calls through serial input'
            observed['focused_command_continuation']=command_completion_site
            observed['passed']=True
            extent_records.close()
            with open(observation_path,'w') as f:json.dump(observed,f,indent=2)
            return True
        except Exception:fail()

if shell_io_only:ShellIoComplete('*'+hex(command_completion_site),internal=True)

for direction,name in [(0,'readable'),(1,'writable')]:
    Helper('topal_x86_user_extent_'+name+'_v1',direction,False)
    Helper('topal_x86_user_extent_'+name+'_return_v1',direction,True)
NativeTrace("*'u.owner'")
Unexpected('*topal_x86_user_extent_caller_abort_v1')

try:
    Gate('topal_x86_frame_gateway_v1','entry')
    Gate('topal_x86_frame_gateway_return_reclaimed_v1','return')
    for symbol in ['topal_x86_frame_gateway_refused_v1','topal_x86_frame_gateway_fatal_reclaimed_v1','topal_x86_frame_gateway_late_reclaimed_v1']:
        Unexpected('*'+symbol)
    Complete('*topal_x86_systems_fatal')
    gdb.execute('continue')
    assert observed['passed']
    print('FRAME_ROOT_GDB_PASS')
    print('FRAME_MEMORY_GDB_PASS',len(observed['memory']))
    gdb.execute('detach')
except Exception:fail()

end
