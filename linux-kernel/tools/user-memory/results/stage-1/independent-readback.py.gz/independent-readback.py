from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,sys,uuid

root=Path.cwd();out=root/'linux-kernel/tools/user-memory/results/stage-1'
record=json.loads((out/'qualification.json').read_text())
assert record['complete'] and record['passed'] and record['stage']==1
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(info):
 compressed=(out/info['file']).read_bytes();assert sha(compressed)==info['sha256']
 raw=gzip.decompress(compressed);assert sha(raw)==info['uncompressed_sha256'] and len(raw)==info['bytes']
 return raw
assert len(record['sources'])==49
snapshots={name:read(record['snapshots'][name]) for name in record['sources']}
for name,digest in record['sources'].items():
 assert name!='topal-as-dsl.md' and sha(snapshots[name])==digest and snapshots[name]==(root/name).read_bytes()
for name,raw in snapshots.items():
 if name.endswith(('.rs','.ll','.t')):
  assert raw==subprocess.check_output(['git','show',record['base_commit']+':'+name]),name
expected={'model','coverage','format','rust-file-size','whitespace'}
assert {c['label'] for c in record['commands']}==expected and len(record['commands'])==5
for command in record['commands']:
 assert command['exit_code']==0
 raw=read(command['log'])
 if command['label']=='model':
  assert re.search(rb'Ran 17 tests in [0-9.]+s\n\nOK\n\Z',raw)
  assert raw.count(b' ... ok\n')==17
 if command['label']=='coverage':
  assert b'test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in raw
assert read(record['runner'])
assert record['production_code_unchanged']
assert record['permission_cases']==8192 and record['model_tests']==17 and record['coverage_tests']==4
events=dict(line.split() for line in record['resources']['memory.events'].splitlines())
assert record['resources']['memory.swap.max']=='0'
assert all(int(events[n])==0 for n in ['oom','oom_kill','oom_group_kill'])
scratch=root/'linux-kernel/.cache'/('tk283-model-readback-'+uuid.uuid4().hex[:8]);scratch.mkdir()
for name in ['model.py','test_model.py']:
 (scratch/name).write_bytes(snapshots['linux-kernel/tools/user-memory/'+name])
p=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(scratch),'-v'],
 env=dict(os.environ,PYTHONPATH=str(scratch)),cwd=scratch,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
assert p.returncode==0 and b'Ran 17 tests' in p.stdout,p.stdout
compressed=gzip.compress(p.stdout,mtime=0);(out/'readback-model.log.gz').write_bytes(compressed)
readback=dict(passed=True,source_inputs=len(snapshots),commands=5,archived_model_replay_tests=17,
 production_source_bytes_equal_base=True,
 replay=dict(file='readback-model.log.gz',sha256=sha(compressed),uncompressed_sha256=sha(p.stdout)),
 scope='Independent snapshot/log/production-source identity readback and isolated archived-model replay; not independent human or native security review.')
# Check only links in this increment's changed/new Markdown, not historical
# external links or old result-tree documentation.
names=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','linux-kernel'],text=True).splitlines()
checked=0
for name in names:
 if not name.endswith('.md') or '/results/' in name:continue
 path=root/name
 for target in re.findall(r'\[[^\]]*\]\(([^)\s]+)\)',path.read_text()):
  if target.startswith(('https:','http:','mailto:','#')):continue
  target=target.split('#',1)[0]
  assert (path.parent/target).exists(),(name,target)
  checked+=1
readback['local_markdown_targets']=checked
code=Path(__file__).read_bytes();compressed=gzip.compress(code,mtime=0)
(out/'independent-readback.py.gz').write_bytes(compressed)
readback['reader']=dict(file='independent-readback.py.gz',sha256=sha(compressed),uncompressed_sha256=sha(code))
(out/'independent-readback.json').write_text(json.dumps(readback,indent=2)+'\n')
print('OWNED_USER_EXTENT_STAGE1_READBACK_PASS',len(snapshots),checked)
