from pathlib import Path
import hashlib,json,tarfile

root=Path.cwd()
archive=root/'linux-kernel/.cache/qemu-x86_64/downloads/linux-7.2.9.tar.xz'
source=root/'linux-kernel/.cache/qemu-x86_64/sources/linux-7.2.9'
expected=json.loads((root/'linux-kernel/labs/qemu/x86_64/manifest.json').read_text())['inputs']['linux']['sha256']
digest=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
assert digest==expected
names={
 'arch/x86/include/asm/uaccess_64.h':['__access_ok','valid_user_address','__untagged_addr'],
 'include/linux/uaccess.h':['raw_copy_to_user','raw_copy_from_user','copy_from_user'],
 'arch/x86/include/asm/pgtable_types.h':['_PAGE_PRESENT','_PAGE_RW','_PAGE_USER','_PAGE_PSE','_PAGE_NX'],
 'Documentation/mm/page_tables.rst':['Page Tables'],
}
files={}
with tarfile.open(archive,'r|xz') as tar:
 for member in tar:
  name=member.name.removeprefix('linux-7.2.9/')
  if name not in names:continue
  data=tar.extractfile(member).read()
  assert data==(source/name).read_bytes(),name
  text=data.decode()
  for symbol in names[name]:assert symbol in text,(name,symbol)
  files[name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),
   archive_member=member.name,cached_bytes_match_pinned_archive=True,research_symbols=names[name])
assert set(files)==set(names)
record=dict(schema='topal-linux-user-memory-research/1',decision='TK-DEC-283',architecture='x86_64',
 linux_release='7.2.9',archive=dict(url='https://cdn.kernel.org/pub/linux/kernel/v7.x/linux-7.2.9.tar.xz',
 sha256=digest,actual_digest_verified=True),source_files=files,
 facts=dict(range_filter_is_separate_from_residency_and_copy=True,
  raw_copy_result_is_remaining_byte_count=True,raw_copy_stays_inside_declared_extent=True,
  partial_copy_does_not_authorize_unwritten_suffix=True,tagging_is_mode_dependent=True),
 scope='Primary-source identities and interface facts only. No Linux implementation copied; no native or VM qualification.')
out=root/'linux-kernel/knowledge/x86_64/user-memory-research.json'
out.write_text(json.dumps(record,indent=2)+'\n')
print('PINNED_USER_MEMORY_RESEARCH_PASS',len(files),digest)
