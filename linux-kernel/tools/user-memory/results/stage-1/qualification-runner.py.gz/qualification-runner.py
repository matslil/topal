from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,sys,time,uuid

root=Path.cwd()
out=root/'linux-kernel/tools/user-memory/results/stage-1'
assert not out.exists(),'retain prior attempts; never overwrite'
out.mkdir(parents=True)
scratch=root/'linux-kernel/.cache'/('tk283-stage1-'+uuid.uuid4().hex[:8]);scratch.mkdir()
alias=Path('/tmp')/scratch.name;alias.symlink_to(scratch,target_is_directory=True)
env=dict(os.environ,TMPDIR=str(alias),RUST_MIN_STACK='16777216',CARGO_BUILD_JOBS='1')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
names=[
 'AGENTS.md','docs/systems-profile.md','se/requirements.md','se/test-strategy.md',
 'se/core-language-coverage.md','se/tool-conformance.md','spec/systems-profile.md',
 'src/topal-compiler/se-requirements.md',
 'src/topal-language/tests/core_language_coverage.rs','scripts/run_bounded.py',
 'scripts/check_rust_file_sizes.py','linux-kernel/baseline.md',
 'linux-kernel/design/kernel-elements.md','linux-kernel/design/dynamic-frame-memory.md',
 'linux-kernel/design/frame-policy-kernel-binding.md','linux-kernel/design/owned-user-extents.md',
 'linux-kernel/knowledge/catalog.md','linux-kernel/knowledge/x86_64/user-memory.md',
 'linux-kernel/knowledge/x86_64/user-memory-research.json',
 'linux-kernel/tools/user-memory/model.py','linux-kernel/tools/user-memory/test_model.py',
 'linux-kernel/tools/user-memory/README.md','linux-kernel/labs/qemu/x86_64/manifest.json',
 'src/topal-compiler/src/systems_provider_emit_process_entry.rs',
 'src/topal-compiler/src/runtime/kernel_frame_memory.ll',
]
names+=subprocess.check_output(['git','ls-files','--','src/topal-compiler/src/systems_process*.rs'],text=True).splitlines()
names=sorted(set(names));assert 'topal-as-dsl.md' not in names
def store(name,raw):
 compressed=gzip.compress(raw,mtime=0);target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(compressed)
 return dict(file=str(target.relative_to(out)),sha256=sha(compressed),uncompressed_sha256=sha(raw),bytes=len(raw))
record=dict(schema='topal-owned-user-extent-model/1',decision='TK-DEC-283',stage=1,
 complete=False,passed=False,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 scope='Contract, independent model and pinned source facts only; no production/native/VM behavior changed or qualified.',
 risk='High at eventual ownership/permission/lifetime boundary; single-agent authority/diff review and independent flat permission lattice/read-trace cases; no independent reviewer claimed.',
 sources={n:sha((root/n).read_bytes()) for n in names},snapshots={},commands=[],scratch=str(scratch),
 runner=store('qualification-runner.py',Path(__file__).read_bytes()))
for name,digest in record['sources'].items():record['snapshots'][name]=store('inputs/'+digest,(root/name).read_bytes())
relative=next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
group=Path('/sys/fs/cgroup')/relative.lstrip('/')
assert 'topal-bounded-' in relative and (group/'memory.swap.max').read_text().strip()=='0'
def save():
 record['resources']={n:(group/n).read_text().strip() for n in ['memory.max','memory.swap.max','memory.peak','memory.events']}
 (out/'qualification.json').write_text(json.dumps(record,indent=2)+'\n')
def unchanged():
 assert all(sha((root/n).read_bytes())==digest for n,digest in record['sources'].items()),'frozen input changed'
def command(label,args):
 unchanged();start=time.monotonic();p=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 record['commands'].append(dict(label=label,command=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=store('logs/'+label,p.stdout)))
 save();print(label,'EXIT',p.returncode,flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-6000:],flush=True);raise SystemExit(p.returncode)
 unchanged();return p.stdout
save()
model=command('model',['python3','-m','unittest','discover','-s','linux-kernel/tools/user-memory','-v'])
assert b'Ran 17 tests' in model and model.rstrip().endswith(b'OK')
coverage=command('coverage',['cargo','test','--locked','-j1','-p','topal-language','--test','core_language_coverage','--','--test-threads=4'])
assert b'4 passed; 0 failed; 0 ignored' in coverage
command('format',['cargo','fmt','--all','--','--check'])
command('rust-file-size',['python3','scripts/check_rust_file_sizes.py'])
command('whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab','diff','--check'])
# Guard this stage's exact scope: Rust/native/Topal production code must match
# the preceding commit. This does not claim a fresh execution of that code.
tracked=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert all(not n.endswith(('.rs','.ll','.t')) for n in tracked),tracked
record['production_code_unchanged']=True
record['model_tests']=17;record['permission_cases']=8192;record['coverage_tests']=4
events=dict(line.split() for line in (group/'memory.events').read_text().splitlines())
assert all(int(events[n])==0 for n in ['oom','oom_kill','oom_group_kill'])
record.update(complete=True,passed=True);save()
print('OWNED_USER_EXTENT_STAGE1_PASS',len(names),flush=True)
