"""Check debugger range-watch support using an ordinary brk mapping edit."""
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path('linux-kernel/labs/qemu/x86_64').resolve()))
import frame_root_inspect as harness

build=Path(sys.argv[1]).resolve()
component=json.loads((build/'source-component.json').read_text())
harness.GDB_PROGRAM=r'''
import gdb,json,traceback
observed=dict(passed=False,scope='Range watchpoint support on an ordinary brk edit only; no complete workload or lifetime qualification')
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
def memory(at,size):return bytes(gdb.selected_inferior().read_memory(at,size))
class Watch(gdb.Breakpoint):
    def __init__(self,at):
        self.at=at
        self.before=memory(at,4096)
        super().__init__('*(unsigned char (*)[4096])'+hex(at),type=gdb.BP_WATCHPOINT,wp_class=gdb.WP_WRITE,internal=True)
        observed['watch_type']=self.type
        observed['watch_info']=dict(number=self.number,type=self.type,enabled=self.enabled,expression=self.expression)
        assert self.type==gdb.BP_HARDWARE_WATCHPOINT,observed['watch_info']
    def stop(self):
        try:
            actual=memory(self.at,4096)
            assert actual!=self.before
            observed.update(passed=True,rip=reg('rip'),cs=reg('cs'),address=self.at,
                changed_bytes=[i for i,(a,b) in enumerate(zip(self.before,actual)) if a!=b],
                before=self.before.hex(),after=actual.hex())
            with open(observation_path,'w') as handle:json.dump(observed,handle,indent=2)
            return True
        except Exception:
            traceback.print_exc()
            return True
class Source(gdb.Breakpoint):
    def stop(self):
        try:
            self.enabled=False
            assert reg('cs')&3==3
            observed['root']=reg('cr3')
            Watch(reg('cr3')+16384)
            return False
        except Exception:
            traceback.print_exc()
            return True
try:
    Source('*'+hex(source_entry),internal=True)
    gdb.execute('continue')
    assert observed['passed'],observed
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:
    traceback.print_exc()
    with open(observation_path,'w') as handle:json.dump(observed,handle,indent=2)
    gdb.execute('quit 1')
'''
label=sys.argv.pop(2) if len(sys.argv)>2 else 'owner-watch-pilot-complete'
harness.main(work_name=label,program_prefix=f'source_entry={component["entry"]!r}\n',
    expect_backing=False,input_scope='ordinary brk range-watch positive control',guest_timeout_seconds=180)
