set pagination off
set confirm off
set remotetimeout 10
file "/home/mats/git/topal/linux-kernel/.cache/x86_64/user-extent-source-metadata-2405098-1794468401556501854/kernel.elf"
target remote 127.0.0.1:49005
python
token_bytes=336
observation_path='/home/mats/git/topal/linux-kernel/.cache/x86_64/user-extent-source-metadata-2405098-1794468401556501854/owner-watch-pilot/observations.json'
source_entry=5708800

import gdb,json,traceback
observed=dict(passed=False,scope='Range watchpoint support on an ordinary brk edit only; no complete workload or lifetime qualification')
def reg(name):return int(gdb.parse_and_eval('$'+name))&((1<<64)-1)
def memory(at,size):return bytes(gdb.selected_inferior().read_memory(at,size))
class Watch(gdb.Breakpoint):
    def __init__(self,at):
        self.at=at
        self.before=memory(at,4096)
        super().__init__('*(unsigned char (*)[4096])'+hex(at),type=gdb.BP_WATCHPOINT,wp_class=gdb.WP_WRITE,internal=True)
        observed['watch_type']=self.type
        observed['watch_info']=gdb.execute('info breakpoints '+str(self.number),to_string=True)
        assert self.type==gdb.BP_HARDWARE_WATCHPOINT,observed['watch_info']
    def stop(self):
        try:
            actual=memory(self.at,4096)
            assert actual!=self.before
            observed.update(passed=True,rip=reg('rip'),cs=reg('cs'),address=self.at,
                changed_bytes=[i for i,(a,b) in enumerate(zip(self.before,actual)) if a!=b],
                before=self.before.hex(),after=actual.hex())
            with open(observation_path,'w') as handle:json.dump(observed,handle,indent=2)
            return True
        except Exception:
            traceback.print_exc()
            return True
class Source(gdb.Breakpoint):
    def stop(self):
        try:
            self.enabled=False
            assert reg('cs')&3==3
            observed['root']=reg('cr3')
            Watch(reg('cr3')+16384)
            return False
        except Exception:
            traceback.print_exc()
            return True
try:
    Source('*'+hex(source_entry),internal=True)
    gdb.execute('continue')
    assert observed['passed'],observed
    print('FRAME_ROOT_GDB_PASS')
    gdb.execute('detach')
except Exception:
    traceback.print_exc()
    with open(observation_path,'w') as handle:json.dump(observed,handle,indent=2)
    gdb.execute('quit 1')

end
